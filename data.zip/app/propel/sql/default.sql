
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- account_detail
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `account_detail`;

CREATE TABLE `account_detail`
(
    `id` INTEGER NOT NULL,
    `discount_on` VARCHAR(255),
    `key_account_manager` VARCHAR(255),
    `debtor_number` VARCHAR(255),
    `special_client_billing_information` TEXT,
    `most_important_criteria` VARCHAR(255),
    `project_manager_criteria` VARCHAR(255),
    `updates_criteria` VARCHAR(255),
    `negative_check_criteria` VARCHAR(255),
    `incentive_criteria` VARCHAR(255),
    `send_criteria` VARCHAR(255),
    `translator_criteria` VARCHAR(255),
    `moderator_criteria` VARCHAR(255),
    `others_criteria` VARCHAR(255),
    `documents_criteria` VARCHAR(255),
    `sales_criteria` VARCHAR(255),
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`id`),
    CONSTRAINT `account_detail_ibfk_1`
        FOREIGN KEY (`id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- am_reason_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `am_reason_type`;

CREATE TABLE `am_reason_type`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `label` VARCHAR(255) NOT NULL,
    `is_am` TINYINT DEFAULT 0,
    `is_pm` TINYINT DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- banque
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `banque`;

CREATE TABLE `banque`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `banque` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `banque` (`banque`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- calcul
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `calcul`;

CREATE TABLE `calcul`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8) NOT NULL,
    `numero_etude` CHAR(9) NOT NULL,
    `date_debut` DATE NOT NULL,
    `date_fin` DATE NOT NULL,
    `annee` VARCHAR(4) NOT NULL,
    `id_etape` INTEGER(8) NOT NULL,
    `id_pm` INTEGER(8) NOT NULL,
    `prix_vente` DECIMAL(15,2) NOT NULL,
    `prix_revient` DECIMAL(15,2) NOT NULL,
    `prix_revient_reel` DECIMAL(15,2) NOT NULL,
    `date_envoi_facture` DATE,
    `date_reglement` DATE,
    `type_etude` INTEGER NOT NULL,
    `periode_cutoff` VARCHAR(7) NOT NULL,
    `id_qq` INTEGER(8) NOT NULL,
    `id_bm` INTEGER(8) NOT NULL,
    `account_id` INTEGER,
    `a_payer_client` DECIMAL(15,2) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `date_debut` (`date_debut`),
    INDEX `date_fin` (`date_fin`),
    INDEX `annee` (`annee`),
    INDEX `date_envoi_facture` (`date_envoi_facture`),
    INDEX `date_reglement` (`date_reglement`),
    INDEX `periode_cutoff` (`periode_cutoff`),
    INDEX `id_etape` (`id_etape`),
    INDEX `id_pm` (`id_pm`),
    INDEX `numero_etude` (`numero_etude`),
    INDEX `id_bm` (`id_bm`),
    INDEX `calcul_fi_38c569` (`account_id`),
    INDEX `calcul_fi_fed96e` (`job_id`),
    CONSTRAINT `calcul_fk_38c569`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `calcul_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- categorie_prestation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `categorie_prestation`;

CREATE TABLE `categorie_prestation`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `categorie` VARCHAR(50) NOT NULL,
    `category` VARCHAR(50) NOT NULL,
    `ordre` INTEGER(3) NOT NULL,
    `nb_item_initiaux` INTEGER(2) NOT NULL,
    `consolidation` VARCHAR(50) NOT NULL,
    `remise` VARCHAR(1) NOT NULL,
    `timesheet_ok` VARCHAR(1) NOT NULL,
    `module_ok` VARCHAR(1) NOT NULL,
    `practivity_ok` VARCHAR(1) NOT NULL,
    `budget_ok` VARCHAR(1) DEFAULT 'Y' NOT NULL,
    `cost_ok` VARCHAR(1) DEFAULT 'Y' NOT NULL,
    `interviewer_activity_ok` VARCHAR(1) DEFAULT 'N' NOT NULL,
    `article1` VARCHAR(255) NOT NULL,
    `role` VARCHAR(255) NOT NULL,
    `unite_travail` VARCHAR(255) NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `qual_2019` TINYINT,
    `qual_rebate` TINYINT,
    `qual_rebate_2019` TINYINT,
    `qual_2020` TINYINT,
    `qual_2020_credit` TINYINT,
    `qual_2019_platform` TINYINT,
    `qual_platform_tech_only` TINYINT,
    `qual_on_total` TINYINT,
    `qual_rebate_on_total_wo_incentive` TINYINT,
    `qual_rebate_on_total` TINYINT,
    `quant_2019` TINYINT,
    `quant_rebate` TINYINT,
    `quant_rebate_2019` TINYINT,
    `quant_2020` TINYINT,
    `quant_2020_credit` TINYINT,
    `quant_on_total` TINYINT,
    `quant_rebate_on_total` TINYINT,
    `quant_rebate_on_total_wo_incentive` TINYINT,
    `qual_rebate_2019_plus_platform` TINYINT,
    `quant_2019_all_recruiting` TINYINT,
    `quant_2019_plus_pm_plus_platform` TINYINT,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `categorie_prestation_u_e912aa` (`categorie`, `category`, `consolidation`, `type`),
    INDEX `activite` (`timesheet_ok`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- coefficient
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `coefficient`;

CREATE TABLE `coefficient`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `coefficient` DECIMAL(3,2) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- confirmation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `confirmation`;

CREATE TABLE `confirmation`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `confirmation` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- markup
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `markup`;

CREATE TABLE `markup`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `markup` DECIMAL(3,2) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dernier_acces
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dernier_acces`;

CREATE TABLE `dernier_acces`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_user` INTEGER(8) NOT NULL,
    `id_etude` INTEGER(8) NOT NULL,
    `date_heure` DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_user` (`id_user`, `id_etude`),
    INDEX `dernier_acces_ibfi_2` (`id_etude`),
    CONSTRAINT `dernier_acces_ibfk_1`
        FOREIGN KEY (`id_user`)
        REFERENCES `user` (`id`),
    CONSTRAINT `dernier_acces_ibfk_2`
        FOREIGN KEY (`id_etude`)
        REFERENCES `etude` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dhtmlx_data
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dhtmlx_data`;

CREATE TABLE `dhtmlx_data`
(
    `sheetid` VARCHAR(191) DEFAULT '' NOT NULL,
    `columnid` INTEGER(8) DEFAULT 0 NOT NULL,
    `rowid` INTEGER(8) DEFAULT 0 NOT NULL,
    `data` VARCHAR(255),
    `style` VARCHAR(255),
    `parsed` VARCHAR(255),
    `calc` VARCHAR(255),
    PRIMARY KEY (`sheetid`,`columnid`,`rowid`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dhtmlx_header
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dhtmlx_header`;

CREATE TABLE `dhtmlx_header`
(
    `sheetid` VARCHAR(255) DEFAULT '' NOT NULL,
    `columnid` INTEGER DEFAULT 0 NOT NULL,
    `label` VARCHAR(255),
    `width` INTEGER,
    PRIMARY KEY (`sheetid`,`columnid`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dhtmlx_sheet
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dhtmlx_sheet`;

CREATE TABLE `dhtmlx_sheet`
(
    `sheetid` VARCHAR(255) NOT NULL,
    `userid` INTEGER,
    `name` VARCHAR(255),
    `key` VARCHAR(255),
    `cfg` VARCHAR(512),
    PRIMARY KEY (`sheetid`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dhtmlx_triggers
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dhtmlx_triggers`;

CREATE TABLE `dhtmlx_triggers`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `sheetid` VARCHAR(255),
    `trigger` VARCHAR(10),
    `source` VARCHAR(10),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- dhtmlx_user
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `dhtmlx_user`;

CREATE TABLE `dhtmlx_user`
(
    `userid` INTEGER NOT NULL AUTO_INCREMENT,
    `apikey` VARCHAR(255),
    `email` VARCHAR(255),
    `secret` VARCHAR(64),
    `pass` VARCHAR(64),
    PRIMARY KEY (`userid`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- document
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `document` VARCHAR(255) NOT NULL,
    `document_br` VARCHAR(255) NOT NULL,
    `type` CHAR NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- duree
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `duree`;

CREATE TABLE `duree`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `dureeNum` INTEGER(3) NOT NULL,
    `dureeText` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `dureeNum` (`dureeNum`),
    UNIQUE INDEX `dureeText` (`dureeText`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- event
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `sams_event_id` VARCHAR(50) NOT NULL,
    `job_id` INTEGER,
    `bid_job_id` INTEGER,
    `bid_job_archive_id` INTEGER,
    `ref_room_id` INTEGER,
    `ref_time_slot_id` INTEGER,
    `event_status_id` INTEGER,
    `date` DATE,
    `confirmed_date` DATE,
    `active_date` DATE,
    `event_methodology_id` INTEGER,
    `status` TINYINT DEFAULT 0,
    `comments` TEXT,
    `facility_note` TEXT,
    `site_id` INTEGER(8),
    `account_id` INTEGER,
    `account_sf_id` VARCHAR(255),
    `activity_currency` VARCHAR(255),
    `all_day_event` TINYINT(1) DEFAULT 0 NOT NULL,
    `archived` TINYINT(1) DEFAULT 0 NOT NULL,
    `assigned_to_id` INTEGER,
    `cancelled` TINYINT(1) DEFAULT 0 NOT NULL,
    `recurring_event` TINYINT(1) DEFAULT 0 NOT NULL,
    `is_deleted` TINYINT(1) DEFAULT 0 NOT NULL,
    `is_deleted_c` TINYINT(1) DEFAULT 0 NOT NULL,
    `description` TEXT,
    `duration_minutes` INTEGER,
    `end_date_time` DATETIME,
    `record_type_id` INTEGER,
    `event_sub_type_id` INTEGER,
    `job_status` VARCHAR(30),
    `location_c` VARCHAR(50),
    `reminder_date` DATE,
    `reminder_set` TINYINT(1) DEFAULT 0 NOT NULL,
    `start_date_time` DATETIME,
    `subject` VARCHAR(255),
    `recurrence_time_zone` VARCHAR(255),
    `created_by_sf_id` VARCHAR(255) NOT NULL,
    `pmtool_updated` TINYINT(1) DEFAULT 0 NOT NULL,
    `event_holder_id` INTEGER,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    `is_group` TINYINT(1) DEFAULT 0 NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `event_ibfi_7` (`event_holder_id`),
    INDEX `event_ibfi_1` (`job_id`),
    INDEX `event_ibfi_10` (`bid_job_id`),
    INDEX `event_ibfi_11` (`ref_room_id`),
    INDEX `event_ibfi_12` (`event_status_id`),
    INDEX `event_ibfi_13` (`ref_time_slot_id`),
    INDEX `event_ibfi_2` (`event_methodology_id`),
    INDEX `event_ibfi_3` (`account_id`),
    INDEX `event_ibfi_4` (`assigned_to_id`),
    INDEX `event_ibfi_5` (`record_type_id`),
    INDEX `event_ibfi_6` (`event_sub_type_id`),
    INDEX `event_fi_36b1e8` (`site_id`),
    CONSTRAINT `event_ibfk_7`
        FOREIGN KEY (`event_holder_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `event_ibfk_1`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`),
    CONSTRAINT `event_ibfk_10`
        FOREIGN KEY (`bid_job_id`)
        REFERENCES `sf_opportunity_bid_job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `event_ibfk_11`
        FOREIGN KEY (`ref_room_id`)
        REFERENCES `ref_room` (`id`),
    CONSTRAINT `event_ibfk_12`
        FOREIGN KEY (`event_status_id`)
        REFERENCES `ref_event_status` (`id`),
    CONSTRAINT `event_ibfk_13`
        FOREIGN KEY (`ref_time_slot_id`)
        REFERENCES `ref_time_slot` (`id`),
    CONSTRAINT `event_ibfk_2`
        FOREIGN KEY (`event_methodology_id`)
        REFERENCES `ref_event_methodology` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `event_ibfk_3`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `event_ibfk_4`
        FOREIGN KEY (`assigned_to_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `event_ibfk_5`
        FOREIGN KEY (`record_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `event_ibfk_6`
        FOREIGN KEY (`event_sub_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `event_fk_36b1e8`
        FOREIGN KEY (`site_id`)
        REFERENCES `ref_site` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_etape
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_etape`;

CREATE TABLE `ref_etape`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `etape` VARCHAR(30) NOT NULL,
    `sf_label` VARCHAR(255) NOT NULL,
    `id_groupe` INTEGER(3) NOT NULL,
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `etape` (`etape`),
    INDEX `etape_ibfi_1` (`id_groupe`),
    CONSTRAINT `etape_ibfk_1`
        FOREIGN KEY (`id_groupe`)
        REFERENCES `groupe` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude`;

CREATE TABLE `etude`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `numero_etude` CHAR(32) NOT NULL,
    `reference_client` VARCHAR(30) NOT NULL,
    `master_project_sf_id` VARCHAR(255),
    `theme` VARCHAR(255),
    `date_debut` DATE NOT NULL,
    `date_fin` DATE NOT NULL,
    `annee` VARCHAR(4) NOT NULL,
    `rst` TINYINT(1) DEFAULT 0 NOT NULL,
    `cli` TINYINT(1) DEFAULT 0 NOT NULL,
    `gqs` TINYINT(1) DEFAULT 0 NOT NULL,
    `ins` TINYINT(1) DEFAULT 0 NOT NULL,
    `hut` TINYINT(1) DEFAULT 0 NOT NULL,
    `display_total_only` TINYINT(1) DEFAULT 0 NOT NULL,
    `id_pm` INTEGER(8),
    `id_etape` INTEGER(8),
    `prix_revient_initial` DECIMAL(15,2) NOT NULL,
    `prix_revient_actualise` DECIMAL(15,2) NOT NULL,
    `prix_vente_initial` DECIMAL(15,2) NOT NULL,
    `prix_vente_actualise` DECIMAL(15,2) NOT NULL,
    `consolidated_invoice` TINYINT(1) DEFAULT 0 NOT NULL,
    `send_csat_quest` TINYINT(1) DEFAULT 0,
    `is_send_csat_quest_mail` TINYINT(1) DEFAULT 1 NOT NULL,
    `numero_facture` VARCHAR(50),
    `dont_set_am_auto` TINYINT(1) DEFAULT 0 NOT NULL,
    `set_am_reason` VARCHAR(255),
    `am_reason_type_id` INTEGER(8),
    `date_envoi_facture` DATE,
    `date_reglement` DATE,
    `commentaire` LONGTEXT,
    `industry_id` INTEGER(8) NOT NULL,
    `periode_cutoff` VARCHAR(7) NOT NULL,
    `theme_br` VARCHAR(255) NOT NULL,
    `area_id` INTEGER(8),
    `id_sams_study` VARCHAR(50) NOT NULL,
    `recrutement_objectif` INTEGER(4) DEFAULT 0 NOT NULL,
    `id_location_pnl` INTEGER(3),
    `id_master_project_location_pnl` INTEGER(3),
    `recrutement_objectif_pr` INTEGER(4) NOT NULL,
    `id_bm` INTEGER(8),
    `extra_info` TEXT,
    `account_id` INTEGER,
    `account_manager_id` INTEGER(8),
    `project_specialty_sponsor_id` INTEGER(8),
    `language` VARCHAR(3),
    `remise_taux` DECIMAL(4,2),
    `client_discount_percentage` DECIMAL(4,2),
    `end_client_discount_percentage` DECIMAL(4,2),
    `client_quant_discount_percentage` DECIMAL(4,2),
    `end_client_quant_discount_percentage` DECIMAL(4,2),
    `sample_plan` LONGTEXT,
    `isToInvoice` TINYINT(1) DEFAULT 0,
    `file_path` VARCHAR(255),
    `account_leader_id` INTEGER(8),
    `account_pm_id` INTEGER(8),
    `am_email` VARCHAR(50),
    `client_portal_ready` TINYINT(1) DEFAULT 1,
    `length_of_interview` VARCHAR(255),
    `sunshine_act` VARCHAR(250),
    `is_consolidated` TINYINT(1) DEFAULT 0,
    `sharepoint_folder` VARCHAR(255),
    `multi_phase` TINYINT(1) DEFAULT 0 NOT NULL,
    `po_number` VARCHAR(255) NOT NULL,
    `currencies` VARCHAR(255),
    `sms_relance` TINYINT(1) DEFAULT 0 NOT NULL,
    `id_etude_group` INTEGER(8),
    `gms` VARCHAR(1) NOT NULL,
    `kol` VARCHAR(1) NOT NULL,
    `room_rental` TINYINT(1) DEFAULT 0,
    `recruits_offsite` TINYINT(1) DEFAULT 0,
    `study_specification` LONGTEXT,
    `is_study_specification` TINYINT(1) DEFAULT 0,
    `additional_notes` LONGTEXT,
    `project_comment` LONGTEXT,
    `end_client_id` INTEGER,
    `end_client_contact_id` INTEGER,
    `contact_id` INTEGER,
    `contact_client_pm_id` INTEGER,
    `master_project_number` VARCHAR(255),
    `proposed_loi` DOUBLE DEFAULT 0,
    `opportunity_id` INTEGER,
    `si_job_type_id` INTEGER,
    `best_effort` TINYINT(1) DEFAULT 0,
    `job_status_sf_id` INTEGER,
    `booked_by_sf_id` VARCHAR(255),
    `created_by_sf_id` VARCHAR(255),
    `account_manager_sf_id` VARCHAR(255),
    `created_date` DATETIME,
    `job_qualification_id` INTEGER,
    `proposed_n` DOUBLE DEFAULT 0,
    `german_job_type_id` INTEGER,
    `created_by_comment` VARCHAR(255),
    `focus_vision` TINYINT(1),
    `si_eu_job_type` TINYINT,
    `intermediate_client_id` INTEGER,
    `intermediate_client_contact_id` INTEGER,
    `us_global_qual_gms_id` INTEGER,
    `facilty_note` TEXT,
    `currency_iso_code_id` INTEGER,
    `client_list_deletion_id` INTEGER,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `numero_etude` (`numero_etude`),
    UNIQUE INDEX `unique_master_project_sf_id` (`master_project_sf_id`),
    INDEX `numero_facture` (`numero_facture`),
    INDEX `theme` (`theme`),
    INDEX `date_envoi_facture` (`date_envoi_facture`, `date_reglement`),
    INDEX `annee` (`annee`),
    INDEX `date_reglement` (`date_reglement`),
    INDEX `periode_cutoff` (`periode_cutoff`),
    INDEX `id_sams_study` (`id_sams_study`),
    INDEX `etude_ibfi_4` (`us_global_qual_gms_id`),
    INDEX `etude_fi_309001` (`account_leader_id`),
    INDEX `etude_fi_dec5e2` (`account_pm_id`),
    INDEX `etude_fi_9719af` (`intermediate_client_id`),
    INDEX `etude_ibfi_35` (`id_etape`),
    INDEX `etude_ibfi_40` (`contact_id`),
    INDEX `etude_ibfi_41` (`opportunity_id`),
    INDEX `etude_ibfi_44` (`job_status_sf_id`),
    INDEX `etude_ibfi_49` (`job_qualification_id`),
    INDEX `etude_ibfi_50` (`si_job_type_id`),
    INDEX `etude_ibfi_51` (`end_client_contact_id`),
    INDEX `etude_ibfi_52` (`german_job_type_id`),
    INDEX `etude_fi_872751` (`end_client_id`),
    INDEX `etude_fi_38c569` (`account_id`),
    INDEX `etude_fi_8c6c9f` (`industry_id`),
    INDEX `etude_fi_e84360` (`id_location_pnl`),
    INDEX `etude_fi_b4e50f` (`id_master_project_location_pnl`),
    INDEX `etude_ibfi_55` (`contact_client_pm_id`),
    INDEX `etude_fi_3f2323` (`id_bm`),
    INDEX `etude_fi_a19bbf` (`id_pm`),
    INDEX `etude_fi_64028b` (`id_etude_group`),
    INDEX `etude_fi_eb6f39` (`area_id`),
    INDEX `etude_ibfi_61` (`currency_iso_code_id`),
    INDEX `etude_ibfi_1` (`client_list_deletion_id`),
    INDEX `etude_fi_5113a9` (`created_by_id`),
    INDEX `etude_fi_18236f` (`updated_by_id`),
    INDEX `etude_ibfi_62` (`intermediate_client_contact_id`),
    INDEX `etude_fi_97795a` (`account_manager_id`),
    INDEX `etude_fi_f7b233` (`project_specialty_sponsor_id`),
    INDEX `etude_fi_fde5b0` (`am_reason_type_id`),
    CONSTRAINT `etude_ibfk_4`
        FOREIGN KEY (`us_global_qual_gms_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_309001`
        FOREIGN KEY (`account_leader_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `etude_fk_dec5e2`
        FOREIGN KEY (`account_pm_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `etude_fk_9719af`
        FOREIGN KEY (`intermediate_client_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_35`
        FOREIGN KEY (`id_etape`)
        REFERENCES `ref_etape` (`id`),
    CONSTRAINT `etude_ibfk_40`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_41`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_44`
        FOREIGN KEY (`job_status_sf_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_49`
        FOREIGN KEY (`job_qualification_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_50`
        FOREIGN KEY (`si_job_type_id`)
        REFERENCES `ref_si_job_type` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_51`
        FOREIGN KEY (`end_client_contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_52`
        FOREIGN KEY (`german_job_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_872751`
        FOREIGN KEY (`end_client_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_38c569`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_8c6c9f`
        FOREIGN KEY (`industry_id`)
        REFERENCES `ref_industry` (`id`),
    CONSTRAINT `etude_fk_e84360`
        FOREIGN KEY (`id_location_pnl`)
        REFERENCES `ref_location` (`id`),
    CONSTRAINT `etude_fk_b4e50f`
        FOREIGN KEY (`id_master_project_location_pnl`)
        REFERENCES `project_location_prefix` (`id`),
    CONSTRAINT `etude_ibfk_55`
        FOREIGN KEY (`contact_client_pm_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_3f2323`
        FOREIGN KEY (`id_bm`)
        REFERENCES `user` (`id`),
    CONSTRAINT `etude_fk_a19bbf`
        FOREIGN KEY (`id_pm`)
        REFERENCES `user` (`id`),
    CONSTRAINT `etude_fk_64028b`
        FOREIGN KEY (`id_etude_group`)
        REFERENCES `etude_group` (`id`),
    CONSTRAINT `etude_fk_eb6f39`
        FOREIGN KEY (`area_id`)
        REFERENCES `ref_area` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_61`
        FOREIGN KEY (`currency_iso_code_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_1`
        FOREIGN KEY (`client_list_deletion_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_5113a9`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_18236f`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_ibfk_62`
        FOREIGN KEY (`intermediate_client_contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_fk_97795a`
        FOREIGN KEY (`account_manager_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `etude_fk_f7b233`
        FOREIGN KEY (`project_specialty_sponsor_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `etude_fk_fde5b0`
        FOREIGN KEY (`am_reason_type_id`)
        REFERENCES `am_reason_type` (`id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_sample_source
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_sample_source`;

CREATE TABLE `etude_sample_source`
(
    `sample_source_id` INTEGER NOT NULL,
    `etude_id` INTEGER NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`sample_source_id`,`etude_id`),
    INDEX `etude_sample_source_ibfi_2` (`etude_id`),
    CONSTRAINT `etude_sample_source_ibfk_1`
        FOREIGN KEY (`sample_source_id`)
        REFERENCES `ref_sample_source` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `etude_sample_source_ibfk_2`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_methodology`;

CREATE TABLE `etude_methodology`
(
    `methodology_id` INTEGER NOT NULL,
    `etude_id` INTEGER NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`methodology_id`,`etude_id`),
    INDEX `etude_methodology_ibfi_2` (`etude_id`),
    CONSTRAINT `etude_methodology_ibfk_1`
        FOREIGN KEY (`methodology_id`)
        REFERENCES `ref_methodology` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `etude_methodology_ibfk_2`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `job_methodology`;

CREATE TABLE `job_methodology`
(
    `methodology_id` INTEGER NOT NULL,
    `job_id` INTEGER NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`methodology_id`,`job_id`),
    INDEX `job_methodology_ibfi_2` (`job_id`),
    CONSTRAINT `job_methodology_ibfk_1`
        FOREIGN KEY (`methodology_id`)
        REFERENCES `ref_methodology` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_methodology_ibfk_2`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- last_acces_opportunity
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `last_acces_opportunity`;

CREATE TABLE `last_acces_opportunity`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_user` INTEGER(8) NOT NULL,
    `id_opportunity` INTEGER(8) NOT NULL,
    `date_heure` DATETIME NOT NULL,
    `position` INTEGER(8) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `last_acces_opportunity_ibfi_1` (`id_user`),
    INDEX `last_acces_opportunity_ibfi_2` (`id_opportunity`),
    CONSTRAINT `last_acces_opportunity_ibfk_1`
        FOREIGN KEY (`id_user`)
        REFERENCES `user` (`id`),
    CONSTRAINT `last_acces_opportunity_ibfk_2`
        FOREIGN KEY (`id_opportunity`)
        REFERENCES `sf_opportunity` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job_costs
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `job_costs`;

CREATE TABLE `job_costs`
(
    `id` INTEGER(10) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8),
    `devis_ok` INTEGER(2) NOT NULL,
    `source` TINYINT NOT NULL,
    `categorie_prestation_id` INTEGER(8),
    `sous_type_prestation` CHAR(255) NOT NULL,
    `unit_price` DECIMAL(15,2) NOT NULL,
    `quantite_pr` DECIMAL(8,2) NOT NULL,
    `prix_revient` DECIMAL(15,2) NOT NULL,
    `prix_vente_unitaire_location` DECIMAL(15,2),
    `paid` DECIMAL(15,2) NOT NULL,
    `coefficiant` DECIMAL(3,2) NOT NULL,
    `fournisseur_nom` VARCHAR(255) NOT NULL,
    `comment_pm` TEXT NOT NULL,
    `not_synchronized` TINYINT(1) DEFAULT 0 NOT NULL,
    `date_creation` DATE NOT NULL,
    `heure_creation` TIME NOT NULL,
    `date_entry_fnr` DATE,
    `payment_of_performance` VARCHAR(7) NOT NULL,
    `date_paiement_fnr` DATE,
    `date_invoice_fnr` DATE,
    `ref_facture_fnr` VARCHAR(255) NOT NULL,
    `internal_ref` VARCHAR(255) NOT NULL,
    `invoice_received_date` DATE,
    `comment_fnr` TEXT NOT NULL,
    `fournisseur_id` INTEGER(10),
    `po_number` VARCHAR(255) NOT NULL,
    `email_sent` TINYINT(1) DEFAULT 0 NOT NULL,
    `second_invoice` TINYINT(1) DEFAULT 0 NOT NULL,
    `second_invoice_date` DATE,
    `second_payment_date` DATE,
    `second_supplier_ref` VARCHAR(255),
    `created_by_comment` VARCHAR(255),
    `date` DATE,
    `order` INTEGER NOT NULL,
    `group` INTEGER DEFAULT 0,
    `group_title` VARCHAR(50),
    `resp_location_id` INTEGER,
    `is_on_budget` TINYINT(1) DEFAULT 0,
    `respondent_type_id` INTEGER,
    `methodology_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `devis_ok` (`devis_ok`),
    INDEX `sf_bid_cost_ibfi_1` (`resp_location_id`),
    INDEX `sf_job_cost_ibfi_2` (`respondent_type_id`),
    INDEX `sf_job_cost_ibfi_3` (`methodology_id`),
    INDEX `job_costs_fi_fed96e` (`job_id`),
    INDEX `job_costs_fi_de120b` (`categorie_prestation_id`),
    INDEX `job_costs_fi_558905` (`fournisseur_id`),
    CONSTRAINT `sf_bid_cost_ibfk_1`
        FOREIGN KEY (`resp_location_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_job_cost_ibfk_2`
        FOREIGN KEY (`respondent_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_job_cost_ibfk_3`
        FOREIGN KEY (`methodology_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_costs_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_costs_fk_de120b`
        FOREIGN KEY (`categorie_prestation_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_costs_fk_558905`
        FOREIGN KEY (`fournisseur_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job_item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `job_item`;

CREATE TABLE `job_item`
(
    `id` INTEGER(10) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8) NOT NULL,
    `sf_id` VARCHAR(255),
    `sf_ignore` TINYINT(1) DEFAULT 0 NOT NULL,
    `devis_ok` INTEGER(2) NOT NULL,
    `categorie_prestation_id` INTEGER(8),
    `sous_type_prestation` CHAR(255) NOT NULL,
    `quantite_pr` DECIMAL(8,3) NOT NULL,
    `coefficiant_pr` DECIMAL(3,2) NOT NULL,
    `prix_revient_unitaire` DECIMAL(15,2) NOT NULL,
    `prix_revient` DECIMAL(15,2) NOT NULL,
    `quantite_pv` DECIMAL(8,3) NOT NULL,
    `prix_vente_unitaire_location` DECIMAL(15,2),
    `prix_vente_unitaire` DECIMAL(15,2) NOT NULL,
    `prix_vente` DECIMAL(15,2) NOT NULL,
    `fournisseur` VARCHAR(255) NOT NULL,
    `paye` DECIMAL(15,2) NOT NULL,
    `comment_pm` TEXT NOT NULL,
    `date_creation` DATE NOT NULL,
    `heure_creation` TIME NOT NULL,
    `date_log` DATETIME NOT NULL,
    `user_log_id` INTEGER(8),
    `etape_log_id` INTEGER(8),
    `discount_comment` TEXT,
    `discount_percent` DECIMAL(8,2),
    `discount_exclude` TINYINT(1) DEFAULT 0,
    `discount_auto` TINYINT(1) DEFAULT 0,
    `date` DATE,
    `order` INTEGER NOT NULL,
    `group` INTEGER DEFAULT 0,
    `group_title` VARCHAR(50),
    `super_group` INTEGER DEFAULT 0,
    `super_group_title` VARCHAR(50),
    `api_exposed_at` DATETIME,
    `down_payment` TINYINT(1) DEFAULT 0,
    `unit` DECIMAL(15,2),
    `date_facture_fnr` DATE NOT NULL,
    `ref_facture_fnr` VARCHAR(255) NOT NULL,
    `ref_facture_int` VARCHAR(255) NOT NULL,
    `comment_fnr` TEXT NOT NULL,
    `id_fichiers` TEXT,
    `markup` DECIMAL(3,2),
    `sams_id` VARCHAR(255),
    `pmtool_updated` TINYINT(1) DEFAULT 0 NOT NULL,
    `zero_value_confirmed` TINYINT(1) DEFAULT 0,
    `vendor_id` INTEGER(10) COMMENT 'Fournisseur',
    `resp_location_id` INTEGER,
    `respondent_type_id` INTEGER,
    `methodology_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `unique_sams_id` (`sams_id`),
    INDEX `devis_ok` (`devis_ok`),
    INDEX `sf_bid_job_item_ibfi_4` (`vendor_id`),
    INDEX `job_item_fi_fed96e` (`job_id`),
    INDEX `job_item_fi_de120b` (`categorie_prestation_id`),
    INDEX `job_item_fi_4d366f` (`user_log_id`),
    INDEX `job_item_fi_7b0e52` (`etape_log_id`),
    INDEX `sf_bid_item_ibfi_1` (`resp_location_id`),
    INDEX `sf_job_item_ibfi_2` (`respondent_type_id`),
    INDEX `sf_job_item_ibfi_3` (`methodology_id`),
    CONSTRAINT `sf_bid_job_item_ibfk_4`
        FOREIGN KEY (`vendor_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_item_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_item_fk_de120b`
        FOREIGN KEY (`categorie_prestation_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_item_fk_4d366f`
        FOREIGN KEY (`user_log_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_item_fk_7b0e52`
        FOREIGN KEY (`etape_log_id`)
        REFERENCES `ref_etape` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_bid_item_ibfk_1`
        FOREIGN KEY (`resp_location_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_job_item_ibfk_2`
        FOREIGN KEY (`respondent_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_job_item_ibfk_3`
        FOREIGN KEY (`methodology_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_master
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_master`;

CREATE TABLE `etude_master`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `numero_etude` CHAR(9) NOT NULL,
    `reference_client` TEXT NOT NULL,
    `theme` VARCHAR(255),
    `date_debut` DATE NOT NULL,
    `date_fin` DATE NOT NULL,
    `annee` VARCHAR(4) NOT NULL,
    `id_pm` INTEGER(8) NOT NULL,
    `id_etape` INTEGER(8) NOT NULL,
    `prix_revient_initial` DECIMAL(15,2) NOT NULL,
    `prix_revient_actualise` DECIMAL(15,2) NOT NULL,
    `prix_vente_initial` DECIMAL(15,2) NOT NULL,
    `prix_vente_actualise` DECIMAL(15,2) NOT NULL,
    `numero_facture` VARCHAR(50),
    `date_envoi_facture` DATE,
    `date_reglement` DATE,
    `commentaire` TEXT,
    `industry_id` INTEGER(8) NOT NULL,
    `periode_cutoff` VARCHAR(7) NOT NULL,
    `theme_br` VARCHAR(255) NOT NULL,
    `area_id` INTEGER(4),
    `id_qq` INTEGER(8) NOT NULL,
    `id_sams_study` VARCHAR(50) NOT NULL,
    `recrutement_objectif` INTEGER(3) NOT NULL,
    `id_location_pnl` INTEGER(3) NOT NULL,
    `durationStudy` VARCHAR(10) NOT NULL,
    `recrutement_objectif_pr` INTEGER(3) NOT NULL,
    `id_bm` INTEGER(8) NOT NULL,
    `account_id` INTEGER,
    `remise_taux` DECIMAL(4,2),
    `language` VARCHAR(3),
    `kol` VARCHAR(1),
    `sms_relance` VARCHAR(1),
    `gms` VARCHAR(1),
    PRIMARY KEY (`id`),
    UNIQUE INDEX `numero_etude` (`numero_etude`),
    INDEX `language` (`language`, `kol`),
    INDEX `sms_relance` (`sms_relance`),
    INDEX `id_pm` (`id_pm`),
    INDEX `numero_facture` (`numero_facture`),
    INDEX `theme` (`theme`),
    INDEX `date_envoi_facture` (`date_envoi_facture`, `date_reglement`),
    INDEX `annee` (`annee`),
    INDEX `date_reglement` (`date_reglement`),
    INDEX `periode_cutoff` (`periode_cutoff`),
    INDEX `id_qq` (`id_qq`),
    INDEX `id_sams_study` (`id_sams_study`),
    INDEX `id_loc_pnl` (`id_location_pnl`),
    INDEX `id_bm` (`id_bm`),
    INDEX `etude_master_fi_eb6f39` (`area_id`),
    INDEX `etude_master_fi_38c569` (`account_id`),
    INDEX `etude_master_fi_8c6c9f` (`industry_id`),
    INDEX `etude_master_fi_5a5505` (`id_etape`),
    CONSTRAINT `etude_master_fk_eb6f39`
        FOREIGN KEY (`area_id`)
        REFERENCES `ref_area` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_master_fk_38c569`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `etude_master_fk_8c6c9f`
        FOREIGN KEY (`industry_id`)
        REFERENCES `ref_industry` (`id`),
    CONSTRAINT `etude_master_fk_5a5505`
        FOREIGN KEY (`id_etape`)
        REFERENCES `ref_etape` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_industry
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_industry`;

CREATE TABLE `ref_industry`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255) NOT NULL,
    `actif` TINYINT(1) DEFAULT 1,
    `phone` VARCHAR(255) DEFAULT '30',
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `libelle` (`libelle`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- facture
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `facture`;

CREATE TABLE `facture`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_etude` INTEGER(8) NOT NULL,
    `project_invoice_type` TINYINT,
    `numero_suite` INTEGER(2) NOT NULL,
    `numero_facture` VARCHAR(255) NOT NULL,
    `date` DATE NOT NULL,
    `montant` DECIMAL(15,2) NOT NULL,
    `texte_facture` TEXT NOT NULL,
    `is_deleted` TINYINT(1) DEFAULT 0 NOT NULL,
    `taux_change` DECIMAL(10,5) NOT NULL,
    `id_document` INTEGER(8) NOT NULL,
    `language` VARCHAR(2),
    `external_reference` VARCHAR(255),
    `symbole_monnaie` VARCHAR(255),
    `job_id` INTEGER,
    `paid_amount` DECIMAL(15,2) NOT NULL,
    `payment_date` DATE NOT NULL,
    `is_send` TINYINT(1) DEFAULT 0,
    `contact_id` INTEGER,
    PRIMARY KEY (`id`),
    INDEX `id_document` (`id_document`),
    INDEX `facture_fi_fed96e` (`job_id`),
    INDEX `facture_fi_fc95b7` (`contact_id`),
    INDEX `facture_ibfi_5` (`id_etude`),
    CONSTRAINT `facture_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `facture_fk_fc95b7`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `facture_ibfk_5`
        FOREIGN KEY (`id_etude`)
        REFERENCES `etude` (`id`)
        ON DELETE CASCADE,
    CONSTRAINT `facture_ibfk_7`
        FOREIGN KEY (`id_document`)
        REFERENCES `document` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- formulaire
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `formulaire`;

CREATE TABLE `formulaire`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `nom` VARCHAR(255) NOT NULL,
    `champs` TEXT NOT NULL,
    `texte` TEXT NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `nom` (`nom`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fournisseur
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `fournisseur`;

CREATE TABLE `fournisseur`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `qualite` VARCHAR(20) NOT NULL,
    `nom` VARCHAR(50) NOT NULL,
    `prenom` VARCHAR(50) NOT NULL,
    `tel` VARCHAR(50) NOT NULL,
    `portable` VARCHAR(50) NOT NULL,
    `fax` VARCHAR(50) NOT NULL,
    `adresse` VARCHAR(255) NOT NULL,
    `id_ville` INTEGER(8),
    `email` VARCHAR(255) NOT NULL,
    `societe` VARCHAR(255) NOT NULL,
    `tarif` VARCHAR(255) NOT NULL,
    `notes` TEXT NOT NULL,
    `coefficient_id` INTEGER NOT NULL,
    `numero_ss` VARCHAR(15) NOT NULL,
    `ne_le` DATE NOT NULL,
    `ne_a` VARCHAR(255) NOT NULL,
    `numero_entreprise` VARCHAR(255) NOT NULL,
    `nationalite` VARCHAR(255) NOT NULL,
    `taux_horaire` DECIMAL(6,2) NOT NULL,
    `phoneroom_hourly_rate` DECIMAL(6,2) NOT NULL,
    `adresse2` VARCHAR(255) NOT NULL,
    `email2` VARCHAR(255) NOT NULL,
    `active` VARCHAR(1) NOT NULL,
    `id_banque` INTEGER,
    `nom_compte` VARCHAR(50) NOT NULL,
    `banque_code` VARCHAR(50) NOT NULL,
    `numero_compte` VARCHAR(50) NOT NULL,
    `iban` VARCHAR(50) NOT NULL,
    `bic` VARCHAR(50) NOT NULL,
    `id_pays` INTEGER(8),
    `taxable` CHAR NOT NULL,
    `employe` CHAR(2) NOT NULL,
    `id_sams` INTEGER(8) NOT NULL,
    `numero_credit` VARCHAR(255) NOT NULL,
    `avg_hours_per_day` DECIMAL(5,2) DEFAULT 0.00 NOT NULL,
    `holidays_per_year` DECIMAL(5,2) DEFAULT 0.00 NOT NULL,
    `start_extra_hours` DECIMAL(5,2) DEFAULT 0.00 NOT NULL,
    `debit_hours_monday` DECIMAL(5,2),
    `debit_hours_tuesday` DECIMAL(5,2),
    `debit_hours_wednesday` DECIMAL(5,2),
    `debit_hours_thursday` DECIMAL(5,2),
    `debit_hours_friday` DECIMAL(5,2),
    `debit_hours_saturday` DECIMAL(5,2),
    `debit_hours_sunday` DECIMAL(5,2),
    `max_hours_per_week` DECIMAL(5,2),
    `max_hours_per_month` DECIMAL(5,2),
    `including_extra_hours` DECIMAL(5,2),
    `correction_extra_hours` DECIMAL(5,2) DEFAULT 0.00 NOT NULL,
    `pt_controle_nb_etude` INTEGER(2) NOT NULL,
    `pt_controle_ids_etude` VARCHAR(255) NOT NULL,
    `agreement` TINYINT(1),
    `account_id` INTEGER,
    `discount_exclude` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `unique_account` (`account_id`),
    INDEX `nom` (`nom`),
    INDEX `prenom` (`prenom`),
    INDEX `adresse` (`adresse`),
    INDEX `numero_entreprise` (`numero_entreprise`),
    INDEX `active` (`active`),
    INDEX `employe` (`employe`),
    INDEX `id_sams` (`id_sams`),
    INDEX `fournisseur_fi_53a765` (`coefficient_id`),
    INDEX `fournisseur_fi_4ce93d` (`id_ville`),
    INDEX `fournisseur_fi_10a181` (`id_banque`),
    INDEX `fournisseur_fi_a942dd` (`id_pays`),
    CONSTRAINT `fournisseur_fk_53a765`
        FOREIGN KEY (`coefficient_id`)
        REFERENCES `coefficient` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `fournisseur_fk_4ce93d`
        FOREIGN KEY (`id_ville`)
        REFERENCES `ville` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `fournisseur_fk_10a181`
        FOREIGN KEY (`id_banque`)
        REFERENCES `banque` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `fournisseur_fk_a942dd`
        FOREIGN KEY (`id_pays`)
        REFERENCES `pays` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `sf_account_id`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fournisseur_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `fournisseur_type`;

CREATE TABLE `fournisseur_type`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `fournisseur_type` VARCHAR(255) NOT NULL,
    `fournisseur_type_br` VARCHAR(255) NOT NULL,
    `schedule` VARCHAR(1) NOT NULL,
    `id_categorie` INTEGER(8) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `fournisseur_type` (`fournisseur_type`),
    INDEX `schedule` (`schedule`),
    INDEX `id_categorie` (`id_categorie`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fournisseur_type_fournisseur
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `fournisseur_type_fournisseur`;

CREATE TABLE `fournisseur_type_fournisseur`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_fournisseur` INTEGER(8) NOT NULL,
    `id_fournisseur_type` INTEGER(8) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `id_fournisseur` (`id_fournisseur`),
    INDEX `id_fournisseur_type` (`id_fournisseur_type`),
    CONSTRAINT `fournisseur_type_fournisseur_ibfk_1`
        FOREIGN KEY (`id_fournisseur`)
        REFERENCES `fournisseur` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- groupe
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `groupe`;

CREATE TABLE `groupe`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `groupe` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- groupe_etape
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `groupe_etape`;

CREATE TABLE `groupe_etape`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_groupe` INTEGER(8) NOT NULL,
    `id_etape` INTEGER(8) NOT NULL,
    `ancien_droit` VARCHAR(1) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_groupe` (`id_groupe`, `id_etape`, `ancien_droit`),
    INDEX `groupe_etape_ibfi_2` (`id_etape`),
    CONSTRAINT `groupe_etape_ibfk_1`
        FOREIGN KEY (`id_groupe`)
        REFERENCES `groupe` (`id`),
    CONSTRAINT `groupe_etape_ibfk_2`
        FOREIGN KEY (`id_etape`)
        REFERENCES `ref_etape` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- groupe_etape_droit
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `groupe_etape_droit`;

CREATE TABLE `groupe_etape_droit`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_groupe` INTEGER(8) NOT NULL,
    `id_etape` INTEGER(8) NOT NULL,
    `etude_save` TINYINT(1) NOT NULL,
    `etude_next_step` TINYINT(1) NOT NULL,
    `budget_save` TINYINT(1) NOT NULL,
    `budget_insert_line` TINYINT(1) NOT NULL,
    `budget_delete_line` TINYINT(1) NOT NULL,
    `budget_clone_line` TINYINT(1) NOT NULL,
    `budget_modify_line` TINYINT(1) NOT NULL,
    `costs_save` TINYINT(1) NOT NULL,
    `costs_insert_line` TINYINT(1) NOT NULL,
    `costs_delete_line` TINYINT(1) NOT NULL,
    `costs_modify_line` TINYINT(1) NOT NULL,
    `costs_add_po` TINYINT(1) NOT NULL,
    `costs_invoice_payment_dates` TINYINT(1) NOT NULL,
    `module_save` TINYINT(1) NOT NULL,
    `ancien_droit` INTEGER(1) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_groupe` (`id_groupe`, `id_etape`, `ancien_droit`),
    CONSTRAINT `groupe_etape_droit_fk_a4e794`
        FOREIGN KEY (`id_groupe`)
        REFERENCES `groupe` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- groupe_programme
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `groupe_programme`;

CREATE TABLE `groupe_programme`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_groupe` INTEGER(8) NOT NULL,
    `id_programme` INTEGER(8) NOT NULL,
    `ancien_droit` VARCHAR(1) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `id_groupe` (`id_groupe`, `id_programme`, `ancien_droit`),
    INDEX `ancien_droit` (`ancien_droit`),
    INDEX `groupe_programme_ibfi_2` (`id_programme`),
    CONSTRAINT `groupe_programme_ibfk_1`
        FOREIGN KEY (`id_groupe`)
        REFERENCES `groupe` (`id`),
    CONSTRAINT `groupe_programme_ibfk_2`
        FOREIGN KEY (`id_programme`)
        REFERENCES `programme` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- imputation_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `imputation_type`;

CREATE TABLE `imputation_type`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `imputation` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `job`;

CREATE TABLE `job`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `etude_id` INTEGER NOT NULL,
    `pm_id` INTEGER(8),
    `technical_pm_id` INTEGER(8),
    `bid_job_id` INTEGER,
    `pm_reason_type_id` INTEGER(8),
    `set_pm_reason` VARCHAR(255),
    `location_id` INTEGER NOT NULL,
    `location_prefix_id` INTEGER,
    `platform_id` INTEGER(8),
    `job_sf_id` VARCHAR(15),
    `facility_rating_id` INTEGER,
    `facility_staff_id` INTEGER,
    `project_management_id` INTEGER,
    `recruitment_rating_id` INTEGER,
    `catering_rating` VARCHAR(255),
    `rating_comments` TEXT,
    `sample_size` TEXT,
    `sf_ignore` TINYINT(1) DEFAULT 0 NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    `pmtool_updated` TINYINT(1) DEFAULT 0,
    `id_sams_job` VARCHAR(50) NOT NULL,
    `on_site_recruits` DOUBLE DEFAULT 0,
    `number_shows` INTEGER NOT NULL,
    `off_site_recruits` DOUBLE DEFAULT 0,
    `real_number_of_interviews` VARCHAR(255),
    `bonus_per_recruit` DECIMAL(8,2) NOT NULL,
    `account_manager_id` INTEGER(8),
    `per_hour` VARCHAR(50),
    `per_group` VARCHAR(50),
    `per_day` VARCHAR(50),
    `multimarket_in_calculation` VARCHAR(50),
    `is_multimarket` TINYINT(1) DEFAULT 0,
    `api_exposed_at` DATETIME,
    `start_date` DATE,
    `end_date` DATE,
    `client_project_number` VARCHAR(30),
    `status_id` INTEGER,
    `po_job_number` VARCHAR(50),
    `fd_checked` TINYINT(1) DEFAULT 0 NOT NULL,
    `pm_checked` TINYINT(1) DEFAULT 0 NOT NULL,
    `am_checked` TINYINT(1) DEFAULT 0 NOT NULL,
    `acct_checked` TINYINT(1) DEFAULT 0 NOT NULL,
    `pm_checked_at` DATETIME,
    `room_count` DECIMAL(8,2) DEFAULT 0,
    `acct_invoiced` TINYINT(1) DEFAULT 0,
    `invoice_date` DATETIME,
    `invoice_number` VARCHAR(50),
    `job_comments` TEXT,
    `initial_revenue` DECIMAL(15,2) NOT NULL,
    `initial_cost` DECIMAL(15,2) NOT NULL,
    `am_was_checked` TINYINT(1),
    `country_id` INTEGER,
    `proposed_billing_date` DATE NOT NULL,
    `end_date_reason_id` INTEGER(8),
    `name` VARCHAR(150),
    `offsite_location_id` INTEGER,
    `call_center_id` INTEGER,
    `coronavirus_effected` TINYINT(1) DEFAULT 0,
    `lost_revenue` DECIMAL(15,2) DEFAULT 0,
    `job_slug` VARCHAR(500),
    `active_date` DATE,
    `rush_request_checked` TINYINT(1) DEFAULT 0,
    `rejected_checked` TINYINT(1) DEFAULT 0,
    `unlock_request_checked` TINYINT(1) DEFAULT 0,
    `rejected_reason` TEXT,
    `unlock_reason` TEXT,
    `room_rental_only` TINYINT(1) DEFAULT 0,
    `updated_by_id` INTEGER,
    `audit_complete` TINYINT(1) DEFAULT 0,
    `project_cordinator_id` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `sf_id` (`job_sf_id`),
    INDEX `job_fi_18236f` (`updated_by_id`),
    INDEX `job_fi_c29731` (`project_cordinator_id`),
    INDEX `job_ibfi_1` (`etude_id`),
    INDEX `job_ibfi_2` (`location_id`),
    INDEX `location_prefix_ibfi_2` (`location_prefix_id`),
    INDEX `platforms_ibfi_2` (`platform_id`),
    INDEX `job_ibfi_3` (`pm_id`),
    INDEX `job_ibfi_13` (`technical_pm_id`),
    INDEX `job_ibfi_4` (`facility_rating_id`),
    INDEX `job_ibfi_5` (`facility_staff_id`),
    INDEX `job_ibfi_6` (`project_management_id`),
    INDEX `job_ibfi_7` (`recruitment_rating_id`),
    INDEX `job_ibfi_8` (`account_manager_id`),
    INDEX `job_ibfi_9` (`status_id`),
    INDEX `job_ibfi_10` (`country_id`),
    INDEX `job_ibfi_11` (`end_date_reason_id`),
    INDEX `job_fi_a9e9ed` (`offsite_location_id`),
    INDEX `job_ibfi_12` (`bid_job_id`),
    INDEX `job_ibfi_33` (`call_center_id`),
    INDEX `job_fi_bcacb9` (`pm_reason_type_id`),
    CONSTRAINT `job_fk_18236f`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_fk_c29731`
        FOREIGN KEY (`project_cordinator_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_ibfk_1`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_ibfk_2`
        FOREIGN KEY (`location_id`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `location_prefix_ibfk_2`
        FOREIGN KEY (`location_prefix_id`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `platforms_ibfk_2`
        FOREIGN KEY (`platform_id`)
        REFERENCES `platforms` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_ibfk_3`
        FOREIGN KEY (`pm_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_ibfk_13`
        FOREIGN KEY (`technical_pm_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_ibfk_4`
        FOREIGN KEY (`facility_rating_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_5`
        FOREIGN KEY (`facility_staff_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_6`
        FOREIGN KEY (`project_management_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_7`
        FOREIGN KEY (`recruitment_rating_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_8`
        FOREIGN KEY (`account_manager_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `job_ibfk_9`
        FOREIGN KEY (`status_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_10`
        FOREIGN KEY (`country_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_11`
        FOREIGN KEY (`end_date_reason_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_fk_a9e9ed`
        FOREIGN KEY (`offsite_location_id`)
        REFERENCES `ref_site` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_ibfk_12`
        FOREIGN KEY (`bid_job_id`)
        REFERENCES `sf_opportunity_bid_job` (`id`),
    CONSTRAINT `job_ibfk_33`
        FOREIGN KEY (`call_center_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `job_fk_bcacb9`
        FOREIGN KEY (`pm_reason_type_id`)
        REFERENCES `am_reason_type` (`id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- job_sample_sources
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `job_sample_sources`;

CREATE TABLE `job_sample_sources`
(
    `sample_source_id` INTEGER NOT NULL,
    `job_id` INTEGER NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`sample_source_id`,`job_id`),
    INDEX `job_sample_sources_ibfi_2` (`job_id`),
    CONSTRAINT `job_sample_sources_ibfk_1`
        FOREIGN KEY (`sample_source_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `job_sample_sources_ibfk_2`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- interviewer_activity
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `interviewer_activity`;

CREATE TABLE `interviewer_activity`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8),
    `id_fournisseur` INTEGER(8) NOT NULL,
    `id_section` INTEGER(8) NOT NULL,
    `date` DATE NOT NULL,
    `start_time` CHAR(5) NOT NULL,
    `end_time` CHAR(5) NOT NULL,
    `unit_cost` DECIMAL(8,2) NOT NULL,
    `quantity` DECIMAL(8,2) NOT NULL,
    `cost` DECIMAL(8,2) NOT NULL,
    `valide` CHAR NOT NULL,
    `a_supprimer` TINYINT(1) DEFAULT 0 NOT NULL,
    `payed` TINYINT(1),
    PRIMARY KEY (`id`),
    INDEX `id_section` (`id_section`),
    INDEX `valide` (`valide`),
    INDEX `interviewer_activity_fi_fed96e` (`job_id`),
    INDEX `interviewer_activity_fi_128be8` (`id_fournisseur`),
    CONSTRAINT `interviewer_activity_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `interviewer_activity_fk_128be8`
        FOREIGN KEY (`id_fournisseur`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `interviewer_activity_fk_cca3fc`
        FOREIGN KEY (`id_section`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_site
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_site`;

CREATE TABLE `ref_site`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `lieu` VARCHAR(50) NOT NULL,
    `adresse` VARCHAR(255) NOT NULL,
    `id_ville` INTEGER(8),
    `plan` VARCHAR(255) NOT NULL,
    `metro` VARCHAR(255) NOT NULL,
    `gare` VARCHAR(255) NOT NULL,
    `hotel` TEXT NOT NULL,
    `streaming` VARCHAR(255) NOT NULL,
    `tel` VARCHAR(255) NOT NULL,
    `fax` VARCHAR(255) NOT NULL,
    `complement` VARCHAR(255) NOT NULL,
    `sams_location` VARCHAR(255),
    `pt_controle_nb_etude` INTEGER(2) NOT NULL,
    `pt_controle_ids_etude` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `ref_site_fi_4ce93d` (`id_ville`),
    CONSTRAINT `ref_site_fk_4ce93d`
        FOREIGN KEY (`id_ville`)
        REFERENCES `ville` (`id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_location
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_location`;

CREATE TABLE `ref_location`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `active` TINYINT(1) DEFAULT 1,
    `country_code` VARCHAR(10),
    `location_group` VARCHAR(20),
    `gqs_available` TINYINT(1) DEFAULT 1,
    `on_site` TINYINT(1) DEFAULT 0 NOT NULL,
    `prefix` VARCHAR(20),
    `project_location_prefix_id` INTEGER(8),
    PRIMARY KEY (`id`),
    INDEX `ref_location_fi_b08bdc` (`project_location_prefix_id`),
    CONSTRAINT `ref_location_fk_b08bdc`
        FOREIGN KEY (`project_location_prefix_id`)
        REFERENCES `project_location_prefix` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- module
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module`
(
    `id` INTEGER(10) NOT NULL AUTO_INCREMENT,
    `event_id` INTEGER(8),
    `sams_module_id` VARCHAR(50) NOT NULL,
    `date_creation` DATE NOT NULL,
    `heure_creation` TIME NOT NULL,
    `status` VARCHAR(2) NOT NULL,
    `numero_ligne` INTEGER(3) NOT NULL,
    `id_client` VARCHAR(255) NOT NULL,
    `debut` VARCHAR(5) NOT NULL,
    `duree_id` INTEGER(8),
    `site_id` INTEGER(8),
    `quota_id` INTEGER(8),
    `repondant_id` INTEGER(8),
    `incentive` DECIMAL(8,2) NOT NULL,
    `no_cheque` VARCHAR(50) NOT NULL,
    `date_confirmation` DATE,
    `paiement` VARCHAR(1) NOT NULL,
    `annule` VARCHAR(1) NOT NULL,
    `date_rescreening` DATE,
    `date_scintex` DATE,
    `date_creation_cheque` DATE,
    `quality_check` VARCHAR(1) NOT NULL,
    `sms_reponse` TEXT NOT NULL,
    `sms_send` TINYINT(1) DEFAULT 0 NOT NULL,
    `sms_receive` TINYINT(1) DEFAULT 0 NOT NULL,
    `a_supprimer` VARCHAR(1),
    `date` DATE,
    `id_type` INTEGER(8) NOT NULL,
    `confirmation_id` INTEGER(8),
    `sams_participation_status` VARCHAR(64),
    `sams_created_at` DATETIME,
    `date_gdpr_consent` DATE,
    `homework_received` TINYINT(1) DEFAULT 0 NOT NULL,
    `nda_received` TINYINT(1) DEFAULT 0 NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `bloc` (`status`),
    INDEX `annule` (`annule`),
    INDEX `date_creation_cheque` (`date_creation_cheque`),
    INDEX `quality_check` (`quality_check`),
    INDEX `sams_module_id` (`sams_module_id`),
    INDEX `module_fi_b54508` (`event_id`),
    INDEX `module_fi_2c34ec` (`duree_id`),
    INDEX `module_fi_36b1e8` (`site_id`),
    INDEX `module_fi_f00007` (`quota_id`),
    INDEX `module_fi_533a40` (`repondant_id`),
    INDEX `module_fi_3314b2` (`confirmation_id`),
    CONSTRAINT `module_fk_b54508`
        FOREIGN KEY (`event_id`)
        REFERENCES `event` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `module_fk_2c34ec`
        FOREIGN KEY (`duree_id`)
        REFERENCES `duree` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `module_fk_36b1e8`
        FOREIGN KEY (`site_id`)
        REFERENCES `ref_site` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `module_fk_f00007`
        FOREIGN KEY (`quota_id`)
        REFERENCES `quota` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `module_fk_533a40`
        FOREIGN KEY (`repondant_id`)
        REFERENCES `repondant` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `module_fk_3314b2`
        FOREIGN KEY (`confirmation_id`)
        REFERENCES `confirmation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- module_fournisseur
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `module_fournisseur`;

CREATE TABLE `module_fournisseur`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `module_id` INTEGER(8) NOT NULL,
    `categorie_prestation_id` INTEGER(8) NOT NULL,
    `fournisseur_id` INTEGER(8) NOT NULL,
    `unit_price` DECIMAL(8,2) NOT NULL,
    `quantite` DECIMAL(8,2) NOT NULL,
    `cout` DECIMAL(8,2) NOT NULL,
    `coefficient` DECIMAL(3,2) NOT NULL,
    `frais` DECIMAL(8,2) NOT NULL,
    `paiement` VARCHAR(1) NOT NULL,
    `date_debut` DATE,
    `date_fin` DATE,
    `fournisseur_confirmer_id` INTEGER(8),
    PRIMARY KEY (`id`),
    INDEX `paiement` (`paiement`),
    INDEX `module_fournisseur_fi_2c6483` (`module_id`),
    INDEX `module_fournisseur_fi_de120b` (`categorie_prestation_id`),
    INDEX `module_fournisseur_fi_558905` (`fournisseur_id`),
    INDEX `module_fournisseur_fi_b173a9` (`fournisseur_confirmer_id`),
    CONSTRAINT `module_fournisseur_fk_2c6483`
        FOREIGN KEY (`module_id`)
        REFERENCES `module` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `module_fournisseur_fk_de120b`
        FOREIGN KEY (`categorie_prestation_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `module_fournisseur_fk_558905`
        FOREIGN KEY (`fournisseur_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `module_fournisseur_fk_b173a9`
        FOREIGN KEY (`fournisseur_confirmer_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- numero
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `numero`;

CREATE TABLE `numero`
(
    `numero` INTEGER(8) NOT NULL,
    `type` VARCHAR(32) NOT NULL,
    PRIMARY KEY (`type`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- pays
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `pays`;

CREATE TABLE `pays`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `pays` VARCHAR(20) NOT NULL,
    `drapeau` VARCHAR(50) NOT NULL,
    `code_monnaie` VARCHAR(3) NOT NULL,
    `change_euro` DECIMAL(10,5) NOT NULL,
    `symbole_monnaie` VARCHAR(3) NOT NULL,
    `generic` TINYINT(1) DEFAULT 1,
    `is_contact` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `pays` (`pays`),
    INDEX `code_monnaie` (`code_monnaie`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- phoneroom_activity
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `phoneroom_activity`;

CREATE TABLE `phoneroom_activity`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8),
    `id_location_pr` INTEGER(8) NOT NULL,
    `fournisseur_id` INTEGER(8) NOT NULL,
    `id_target` INTEGER(8),
    `id_section` INTEGER(8) NOT NULL,
    `date` DATE NOT NULL,
    `start_time` TIME NOT NULL,
    `end_time` TIME NOT NULL,
    `break_time` INTEGER(2) NOT NULL,
    `nb_heure` DECIMAL(5,2) NOT NULL,
    `unit_rate` DECIMAL(8,2) NOT NULL,
    `bonus` DECIMAL(8,2) NOT NULL,
    `cout` DECIMAL(8,2) NOT NULL,
    `valide` CHAR NOT NULL,
    `nb_recruitment` DECIMAL(5,2) NOT NULL,
    `phone_station` INTEGER(2) NOT NULL,
    `a_supprimer` VARCHAR(1) NOT NULL,
    `payed` TINYINT(1),
    PRIMARY KEY (`id`),
    INDEX `valide` (`valide`),
    INDEX `phoneroom_activity_fi_fed96e` (`job_id`),
    INDEX `phoneroom_activity_fi_558905` (`fournisseur_id`),
    INDEX `phoneroom_activity_fi_cca3fc` (`id_section`),
    INDEX `phoneroom_activity_fi_5891c2` (`id_target`),
    CONSTRAINT `phoneroom_activity_fk_fed96e`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `phoneroom_activity_fk_558905`
        FOREIGN KEY (`fournisseur_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `phoneroom_activity_fk_cca3fc`
        FOREIGN KEY (`id_section`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE,
    CONSTRAINT `phoneroom_activity_fk_5891c2`
        FOREIGN KEY (`id_target`)
        REFERENCES `phoneroom_target` (`id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- phoneroom_target
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `phoneroom_target`;

CREATE TABLE `phoneroom_target`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `target` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- programme
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `programme`;

CREATE TABLE `programme`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `programme` VARCHAR(50) NOT NULL,
    `php` VARCHAR(50) NOT NULL,
    `ordre` INTEGER(3) NOT NULL,
    `aide` TEXT NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `programme` (`programme`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- quota
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `quota`;

CREATE TABLE `quota`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `quota` VARCHAR(255) NOT NULL,
    `quotaBr` VARCHAR(255) NOT NULL,
    `quotaAlias` VARCHAR(255) NOT NULL,
    `quotaForArea` VARCHAR(1),
    `quotaForOther` VARCHAR(1),
    PRIMARY KEY (`id`),
    UNIQUE INDEX `quota` (`quota`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- reglement
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `reglement`;

CREATE TABLE `reglement`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_etude` INTEGER(8) NOT NULL,
    `reference` VARCHAR(255) NOT NULL,
    `date` DATE,
    `montant` DECIMAL(15,2) NOT NULL,
    `id_document` INTEGER(8) NOT NULL,
    `id_banque` INTEGER(8),
    PRIMARY KEY (`id`),
    INDEX `reglement_ibfi_6` (`id_etude`),
    INDEX `reglement_ibfi_7` (`id_document`),
    INDEX `reglement_ibfi_8` (`id_banque`),
    CONSTRAINT `reglement_ibfk_6`
        FOREIGN KEY (`id_etude`)
        REFERENCES `etude` (`id`)
        ON DELETE CASCADE,
    CONSTRAINT `reglement_ibfk_7`
        FOREIGN KEY (`id_document`)
        REFERENCES `document` (`id`),
    CONSTRAINT `reglement_ibfk_8`
        FOREIGN KEY (`id_banque`)
        REFERENCES `banque` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- repondant
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `repondant`;

CREATE TABLE `repondant`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `qualite` VARCHAR(20) NOT NULL,
    `nom` VARCHAR(50) NOT NULL,
    `prenom` VARCHAR(50) NOT NULL,
    `tel` VARCHAR(50) NOT NULL,
    `portable` VARCHAR(50) NOT NULL,
    `fax` VARCHAR(50) NOT NULL,
    `adresse` VARCHAR(255) NOT NULL,
    `id_ville` INTEGER(8),
    `email` VARCHAR(255) NOT NULL,
    `societe` VARCHAR(255) NOT NULL,
    `notes` TEXT NOT NULL,
    `adresse2` VARCHAR(255) NOT NULL,
    `email2` VARCHAR(255) NOT NULL,
    `active` VARCHAR(1) NOT NULL,
    `no_rpps` VARCHAR(11) NOT NULL,
    `rating` VARCHAR(1) NOT NULL,
    `siret` VARCHAR(255),
    `bic` VARCHAR(255),
    `iban` VARCHAR(255),
    `sams_respondent_id` VARCHAR(64),
    `kontoinhaber` VARCHAR(255),
    `practice_type` TINYINT,
    PRIMARY KEY (`id`),
    INDEX `nom` (`nom`),
    INDEX `adresse` (`adresse`),
    INDEX `prenom` (`prenom`),
    INDEX `societe` (`societe`),
    INDEX `no_rpps` (`no_rpps`),
    INDEX `active` (`active`),
    INDEX `repondant_ibfi_1` (`id_ville`),
    CONSTRAINT `repondant_ibfk_1`
        FOREIGN KEY (`id_ville`)
        REFERENCES `ville` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- repondant_quota
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `repondant_quota`;

CREATE TABLE `repondant_quota`
(
    `id_repondant` INTEGER(8) NOT NULL,
    `id_quota` INTEGER(8) NOT NULL,
    PRIMARY KEY (`id_repondant`,`id_quota`),
    INDEX `repondant_quota_fi_497cfd` (`id_quota`),
    CONSTRAINT `repondant_quota_fk_72f87d`
        FOREIGN KEY (`id_repondant`)
        REFERENCES `repondant` (`id`),
    CONSTRAINT `repondant_quota_fk_497cfd`
        FOREIGN KEY (`id_quota`)
        REFERENCES `quota` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- suivimajtable
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `suivimajtable`;

CREATE TABLE `suivimajtable`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `operation` VARCHAR(20) NOT NULL,
    `date` DATETIME,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `operation` (`operation`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- temps_presence
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `temps_presence`;

CREATE TABLE `temps_presence`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_user` INTEGER(8) NOT NULL,
    `is_for` TINYINT DEFAULT 0 NOT NULL,
    `date` DATE NOT NULL,
    `heure_arrivee` TIME,
    `heure_depart` TIME,
    `duree_pause` INTEGER(2),
    `nb_heure` DECIMAL(5,2) NOT NULL,
    `extra_hours` DECIMAL(5,2) DEFAULT 0.00 NOT NULL,
    `debit_hours` DECIMAL(5,2),
    `max_hours_week` DECIMAL(5,2),
    `max_hours_month` DECIMAL(5,2),
    `including_extra_hours` DECIMAL(5,2),
    `day_type` CHAR DEFAULT 'W' NOT NULL,
    `period` VARCHAR(7) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `date` (`date`),
    INDEX `period` (`period`),
    INDEX `is_for` (`is_for`),
    INDEX `temps_presence_fi_f2a591` (`id_user`),
    CONSTRAINT `temps_presence_fk_f2a591`
        FOREIGN KEY (`id_user`)
        REFERENCES `user` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- time_sheet
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `time_sheet`;

CREATE TABLE `time_sheet`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_user` INTEGER(8) NOT NULL,
    `cutoff_periode` VARCHAR(10) NOT NULL,
    `date` DATE NOT NULL,
    `id_categorie` INTEGER(8) NOT NULL,
    `nb_heure` DECIMAL(5,2) NOT NULL,
    `id_etude` INTEGER(8) NOT NULL,
    `id_imputation` INTEGER(8) NOT NULL,
    `a_supprimer` VARCHAR(1) NOT NULL,
    `valide` CHAR NOT NULL,
    `id_error` INTEGER(8) NOT NULL,
    `cout` DECIMAL(8,2) NOT NULL,
    `taux_horaire` DECIMAL(8,2) NOT NULL,
    `id_location` INTEGER(8) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `cutoff_periode` (`cutoff_periode`),
    INDEX `a_supprimer` (`a_supprimer`),
    INDEX `valide` (`valide`),
    INDEX `id_error` (`id_error`),
    INDEX `time_sheet_fi_f2a591` (`id_user`),
    INDEX `time_sheet_fi_5a46b4` (`id_location`),
    CONSTRAINT `time_sheet_fk_f2a591`
        FOREIGN KEY (`id_user`)
        REFERENCES `user` (`id`),
    CONSTRAINT `time_sheet_fk_5a46b4`
        FOREIGN KEY (`id_location`)
        REFERENCES `ref_location` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_methodology`;

CREATE TABLE `ref_methodology`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `typeEtudeOrdre` INTEGER(3) NOT NULL,
    `typeEtude` VARCHAR(255) NOT NULL,
    `typeEtudeBr` VARCHAR(255) NOT NULL,
    `typeEtudeAlias` VARCHAR(255) NOT NULL,
    `id_duree` INTEGER(8),
    `consolidation` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `actif` TINYINT(1) DEFAULT 1,
    `job_qualification_id` INTEGER(8),
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `typeEtudeAlias` (`typeEtudeAlias`),
    INDEX `ref_methodology_fi_2de4ce` (`id_duree`),
    INDEX `ref_methodology_fi_0a576d` (`job_qualification_id`),
    CONSTRAINT `ref_methodology_fk_2de4ce`
        FOREIGN KEY (`id_duree`)
        REFERENCES `duree` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `ref_methodology_fk_0a576d`
        FOREIGN KEY (`job_qualification_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- user
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `mail` VARCHAR(50) NOT NULL,
    `phone` VARCHAR(50),
    `nom` VARCHAR(50) NOT NULL,
    `prenom` VARCHAR(50) NOT NULL,
    `initials` VARCHAR(50) NOT NULL,
    `id_groupe` INTEGER(8),
    `raw_roles` TEXT,
    `id_coordinateur` INTEGER(8),
    `statut` CHAR NOT NULL,
    `fournisseur_id` INTEGER(8),
    `employe` CHAR NOT NULL,
    `is_seller` TINYINT(1) DEFAULT 0,
    `can_edit_event` TINYINT(1) DEFAULT 0,
    `allow_duplicate_contacts` TINYINT(1) DEFAULT 0,
    `is_room_rental` TINYINT(1) DEFAULT 0,
    `is_bad_payer_mail_receiver` TINYINT(1) DEFAULT 0,
    `is_account_change_mail_receiver` TINYINT(1) DEFAULT 0,
    `is_pm_team_leader` TINYINT(1) DEFAULT 0,
    `id_location` INTEGER(8),
    `id_location_pr` INTEGER(8),
    `sf_id` VARCHAR(255) DEFAULT '' NOT NULL,
    `default_sf` TINYINT(1) DEFAULT 0,
    `notes` VARCHAR(255) DEFAULT '',
    `pm_notes` VARCHAR(255) DEFAULT '',
    `default_date_format` VARCHAR(255) DEFAULT '',
    `calendar_view` TINYINT DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `mail` (`mail`),
    INDEX `nom` (`nom`),
    INDEX `id_coordinateur` (`id_coordinateur`),
    INDEX `fournisseur_id` (`fournisseur_id`),
    INDEX `employe` (`employe`),
    INDEX `id_location` (`id_location`),
    INDEX `user_fi_d6f22c` (`id_location_pr`),
    INDEX `user_fi_a4e794` (`id_groupe`),
    CONSTRAINT `user_fk_d6f22c`
        FOREIGN KEY (`id_location_pr`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE SET NULL
        ON DELETE CASCADE,
    CONSTRAINT `user_fk_a4e794`
        FOREIGN KEY (`id_groupe`)
        REFERENCES `groupe` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `user_fk_8478e0`
        FOREIGN KEY (`id_coordinateur`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `user_fk_558905`
        FOREIGN KEY (`fournisseur_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `user_fk_5a46b4`
        FOREIGN KEY (`id_location`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ville
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ville`;

CREATE TABLE `ville`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `cp` VARCHAR(40) NOT NULL,
    `ville` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `cp` (`cp`, `ville`),
    INDEX `cp_2` (`cp`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity`;

CREATE TABLE `sf_opportunity`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `sf_id` VARCHAR(255),
    `sf_ignore` TINYINT(1) DEFAULT 0 NOT NULL,
    `n_sample_size` DOUBLE DEFAULT 0,
    `account_sf_id` VARCHAR(255),
    `contact_sf_id` VARCHAR(255),
    `account_id` INTEGER,
    `contact_id` INTEGER,
    `job_created_date` DATETIME,
    `bidnumber` VARCHAR(255),
    `bid_revenue` DECIMAL(15,2) DEFAULT 0,
    `bid_number` VARCHAR(255),
    `client_bid_number` TEXT,
    `project_number` VARCHAR(30),
    `currencies` VARCHAR(255),
    `file_path` VARCHAR(255),
    `client_type_id` INTEGER,
    `close_date` DATETIME,
    `created_by_id` VARCHAR(255),
    `created_date` DATETIME,
    `us_global_qual_gms_id` INTEGER,
    `incidence_rate` DOUBLE DEFAULT 0,
    `industry_id` INTEGER,
    `job_qualification_id` INTEGER,
    `loi_option_1` DOUBLE DEFAULT 0,
    `loi_option_2` DOUBLE DEFAULT 0,
    `max_ir` DOUBLE DEFAULT 0,
    `min_ir` DOUBLE DEFAULT 0,
    `notes_or_comments` TEXT,
    `account_coordinator` VARCHAR(40),
    `currency_iso_code_id` INTEGER,
    `study_specification` LONGTEXT,
    `is_study_specification` TINYINT(1) DEFAULT 0,
    `opportunity_subject` VARCHAR(80),
    `opportunity_english_subject` VARCHAR(80),
    `opportunity_name` VARCHAR(255),
    `end_client_id` INTEGER,
    `end_client_sf_id` VARCHAR(255),
    `end_client_rep_id` INTEGER,
    `end_client_rep_sf_id` VARCHAR(255),
    `end_client_contact_id` INTEGER,
    `end_client_contact_sf_id` VARCHAR(255),
    `intermediate_client_id` INTEGER,
    `other_location` VARCHAR(50),
    `probability` DOUBLE DEFAULT 0,
    `proposed_n` DOUBLE DEFAULT 0,
    `rebid` DOUBLE DEFAULT 0,
    `client_discount_percentage` DECIMAL(4,2),
    `end_client_discount_percentage` DECIMAL(4,2),
    `client_quant_discount_percentage` DECIMAL(4,2),
    `end_client_quant_discount_percentage` DECIMAL(4,2),
    `stage_name_id` INTEGER,
    `estimated_commissioning_date` DATE,
    `bid_value` VARCHAR(255),
    `gqs_gms` TINYINT(1),
    `zendesk_ticket_id` VARCHAR(255),
    `zendesk` TINYINT(1),
    `include_account_manager` TINYINT(1),
    `include_opp_owner` TINYINT(1),
    `report_end_client` TINYINT(1),
    `apply_discount` TINYINT(1),
    `platform_id` INTEGER,
    `specifics_id` INTEGER,
    `nb_of_survey` INTEGER,
    `programming_complexity` TINYINT DEFAULT 4,
    `response_time` VARCHAR(255),
    `room_rental` TINYINT(1) DEFAULT 0,
    `translator_equipment` TINYINT(1) DEFAULT 0,
    `streaming` TINYINT(1) DEFAULT 0,
    `pc_rental` TINYINT(1) DEFAULT 0,
    `usability_lab` TINYINT(1) DEFAULT 0,
    `simtrans` TINYINT(1) DEFAULT 0,
    `note_taker` TINYINT(1) DEFAULT 0,
    `additional_QA` TINYINT(1) DEFAULT 0,
    `catering_resp` TINYINT(1) DEFAULT 0,
    `catering_client` TINYINT(1) DEFAULT 0,
    `recruits_offsite` TINYINT(1) DEFAULT 0,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    `pmtool_updated` TINYINT(1) DEFAULT 0,
    `api_exposed_at` DATETIME,
    `sample_plan` LONGTEXT,
    `pmtool_created_by_id` INTEGER,
    `first_created_by_id` INTEGER,
    `account_manager_id` INTEGER,
    `specialty_sponsor_id` INTEGER,
    `sharepoint_folder` VARCHAR(255) NOT NULL,
    `is_deleted` TINYINT(1) DEFAULT 0,
    `delete_at` DATETIME,
    `deleted_by_id` INTEGER,
    `coronavirus_effected` TINYINT(1) DEFAULT 0,
    `lost_revenue` DECIMAL(15,2) DEFAULT 0,
    `is_template` TINYINT(1) DEFAULT 0,
    `template_type` TINYINT DEFAULT 2,
    `template_scope` TINYINT DEFAULT 2,
    `template_title` VARCHAR(500),
    `copied_template_id` INTEGER,
    `copied_template_at` DATETIME,
    `is_quick_opportunity` TINYINT(1) DEFAULT 0,
    `print_currency` TINYINT,
    `facilty_note` TEXT,
    `pre_task` TEXT,
    `external_comment` TEXT,
    `length` TEXT,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `sf_id` (`sf_id`),
    INDEX `sf_opportunity_ibfi_1` (`account_id`),
    INDEX `sf_opportunity_ibfi_2` (`contact_id`),
    INDEX `sf_opportunity_ibfi_3` (`client_type_id`),
    INDEX `sf_opportunity_ibfi_4` (`us_global_qual_gms_id`),
    INDEX `in_opportunity_ibfi_5` (`industry_id`),
    INDEX `sf_opportunity_ibfi_6` (`job_qualification_id`),
    INDEX `sf_opportunity_ibfi_7` (`currency_iso_code_id`),
    INDEX `sf_opportunity_ibfi_8` (`end_client_id`),
    INDEX `sf_opportunity_ibfi_16` (`end_client_rep_id`),
    INDEX `sf_opportunity_ibfi_9` (`end_client_contact_id`),
    INDEX `sf_opportunity_ibfi_17` (`intermediate_client_id`),
    INDEX `sf_opportunity_ibfi_11` (`stage_name_id`),
    INDEX `sf_opportunity_ibfi_12` (`platform_id`),
    INDEX `sf_opportunity_ibfi_13` (`specifics_id`),
    INDEX `sf_opportunity_ibfi_14` (`pmtool_created_by_id`),
    INDEX `sf_opportunity_fi_ab268f` (`first_created_by_id`),
    INDEX `sf_opportunity_ibfi_15` (`account_manager_id`),
    INDEX `sf_opportunity_ibfi_20` (`specialty_sponsor_id`),
    INDEX `sf_opportunity_ibfi_18` (`deleted_by_id`),
    INDEX `sf_opportunity_ibfi_19` (`copied_template_id`),
    CONSTRAINT `sf_opportunity_ibfk_1`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_3`
        FOREIGN KEY (`client_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_4`
        FOREIGN KEY (`us_global_qual_gms_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `in_opportunity_ibfk_5`
        FOREIGN KEY (`industry_id`)
        REFERENCES `ref_industry` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_6`
        FOREIGN KEY (`job_qualification_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_7`
        FOREIGN KEY (`currency_iso_code_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_8`
        FOREIGN KEY (`end_client_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_16`
        FOREIGN KEY (`end_client_rep_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_9`
        FOREIGN KEY (`end_client_contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_17`
        FOREIGN KEY (`intermediate_client_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_11`
        FOREIGN KEY (`stage_name_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_12`
        FOREIGN KEY (`platform_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_13`
        FOREIGN KEY (`specifics_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_14`
        FOREIGN KEY (`pmtool_created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_fk_ab268f`
        FOREIGN KEY (`first_created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_ibfk_15`
        FOREIGN KEY (`account_manager_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `sf_opportunity_ibfk_20`
        FOREIGN KEY (`specialty_sponsor_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `sf_opportunity_ibfk_18`
        FOREIGN KEY (`deleted_by_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `sf_opportunity_ibfk_19`
        FOREIGN KEY (`copied_template_id`)
        REFERENCES `sf_opportunity` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid`;

CREATE TABLE `sf_opportunity_bid`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `opportunity_id` INTEGER NOT NULL,
    `label` VARCHAR(255) DEFAULT '',
    `study_specification` LONGTEXT,
    `is_preferred` TINYINT(1) DEFAULT 0,
    `is_chosen` TINYINT(1) DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_ibfi_1` (`opportunity_id`),
    INDEX `sf_opportunity_bid_ibfi_2` (`created_by_id`),
    INDEX `sf_opportunity_bid_ibfi_3` (`updated_by_id`),
    CONSTRAINT `sf_opportunity_bid_ibfk_1`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_ibfk_2`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_ibfk_3`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid_job
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid_job`;

CREATE TABLE `sf_opportunity_bid_job`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `bid_id` INTEGER NOT NULL,
    `is_multimarket` VARCHAR(50),
    `per_hour` VARCHAR(50),
    `per_group` VARCHAR(50),
    `per_day` VARCHAR(50),
    `multimarket_in_calculation` VARCHAR(50),
    `name` VARCHAR(150),
    `location_id` INTEGER NOT NULL,
    `on_site_recruits` DOUBLE DEFAULT 0,
    `off_site_recruits` DOUBLE DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `product_id` INTEGER(8),
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_ibfi_1` (`bid_id`),
    INDEX `sf_opportunity_bid_job_ibfi_2` (`location_id`),
    INDEX `sf_opportunity_bid_job_ibfi_3` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_ibfi_4` (`updated_by_id`),
    INDEX `product_ibfi_9` (`product_id`),
    CONSTRAINT `sf_opportunity_bid_job_ibfk_1`
        FOREIGN KEY (`bid_id`)
        REFERENCES `sf_opportunity_bid` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_2`
        FOREIGN KEY (`location_id`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_3`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_4`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `product_ibfk_9`
        FOREIGN KEY (`product_id`)
        REFERENCES `platforms` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid_job_item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid_job_item`;

CREATE TABLE `sf_opportunity_bid_job_item`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `bid_job_id` INTEGER NOT NULL,
    `event_id` INTEGER,
    `section_id` INTEGER COMMENT 'Category prestation',
    `title` VARCHAR(255) NOT NULL,
    `vendor_id` INTEGER(10) COMMENT 'Fournisseur',
    `resp_location_id` INTEGER,
    `methodology_id` INTEGER,
    `date` DATE,
    `selling_qty` DECIMAL(8,3),
    `selling_unit_price` DECIMAL(15,2),
    `unit` DECIMAL(15,2),
    `selling_price` DECIMAL(15,2),
    `cost_qty` INTEGER,
    `cost_unit_price` DECIMAL(15,2),
    `cost_location_unit_price` DECIMAL(15,2),
    `cost_rate` DECIMAL(8,2),
    `cost_price` DECIMAL(15,2),
    `discount_comment` TEXT,
    `discount_percent` DECIMAL(8,2),
    `discount_exclude` TINYINT(1) DEFAULT 0,
    `discount_auto` TINYINT(1) DEFAULT 0,
    `pm_comment` TEXT,
    `order` INTEGER NOT NULL,
    `group` INTEGER DEFAULT 0,
    `group_title` VARCHAR(50),
    `super_group` INTEGER DEFAULT 0,
    `super_group_title` VARCHAR(50),
    `first_discount_percentage` DECIMAL(4,2),
    `second_discount_percentage` DECIMAL(4,2),
    `first_discount_section_id` INTEGER,
    `second_discount_section_id` INTEGER,
    `respondent_type_id` INTEGER,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_1` (`bid_job_id`),
    INDEX `sf_opportunity_bid_job_item_fi_b54508` (`event_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_3` (`section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_4` (`vendor_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_5` (`resp_location_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_6` (`methodology_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_12` (`first_discount_section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_13` (`second_discount_section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_9` (`respondent_type_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_7` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_8` (`updated_by_id`),
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_1`
        FOREIGN KEY (`bid_job_id`)
        REFERENCES `sf_opportunity_bid_job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_item_fk_b54508`
        FOREIGN KEY (`event_id`)
        REFERENCES `event` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_3`
        FOREIGN KEY (`section_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_4`
        FOREIGN KEY (`vendor_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_5`
        FOREIGN KEY (`resp_location_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_6`
        FOREIGN KEY (`methodology_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_12`
        FOREIGN KEY (`first_discount_section_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_13`
        FOREIGN KEY (`second_discount_section_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_9`
        FOREIGN KEY (`respondent_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_7`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_8`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- event_bidjobitem
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `event_bidjobitem`;

CREATE TABLE `event_bidjobitem`
(
    `event_id` INTEGER NOT NULL,
    `bid_job_item_id` INTEGER NOT NULL,
    PRIMARY KEY (`event_id`,`bid_job_item_id`),
    INDEX `fichier_bidjobitem_ibfi_2` (`bid_job_item_id`),
    CONSTRAINT `event_bidjobitem_ibfk_1`
        FOREIGN KEY (`event_id`)
        REFERENCES `event` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `fichier_bidjobitem_ibfk_2`
        FOREIGN KEY (`bid_job_item_id`)
        REFERENCES `sf_opportunity_bid_job_item` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_account
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_account`;

CREATE TABLE `sf_account`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    `pmtool_created_date` DATETIME,
    `pmtool_updated_date` DATETIME,
    `flat_rate` TINYINT DEFAULT 0,
    `sf_id` VARCHAR(255),
    `parent_id` VARCHAR(255),
    `is_person_account` TINYINT(1) DEFAULT 0,
    `record_type` VARCHAR(255),
    `name` VARCHAR(255),
    `name_legal` VARCHAR(70),
    `owner_profile_name` TEXT,
    `type` VARCHAR(10),
    `cms_client_id` DOUBLE DEFAULT 0,
    `client_id` DOUBLE DEFAULT 0,
    `client_type_id` INTEGER,
    `client_source_id` INTEGER,
    `client_portal_ready` TINYINT(1) DEFAULT 0,
    `multimarket` TEXT,
    `industry_id` INTEGER,
    `phone` VARCHAR(255),
    `fax` VARCHAR(255),
    `website` VARCHAR(255),
    `status_id` INTEGER,
    `bad_payer` VARCHAR(3),
    `last_job_completed` TEXT,
    `number_of_employees` INTEGER(8) DEFAULT 0,
    `staff_preferences` TEXT,
    `billing_street` TEXT,
    `billing_address` TEXT,
    `billing_city` VARCHAR(40),
    `billing_state` VARCHAR(40),
    `billing_zip` VARCHAR(40),
    `billing_country` VARCHAR(40),
    `team` TEXT,
    `team_lisa` TEXT,
    `sponsor` VARCHAR(255),
    `eu_sponsor` VARCHAR(255),
    `quant_sponsor` VARCHAR(255),
    `x2nd_qual_sponsor` VARCHAR(255),
    `x2nd_quant_sponsor` VARCHAR(255),
    `relationship_status_id` INTEGER,
    `discount_program_id` INTEGER,
    `discount_percentage_id` INTEGER,
    `eu_discount_percentage_id` INTEGER,
    `quant_discount_percentage_id` INTEGER,
    `discount_notes` TEXT,
    `accounting_note` TEXT,
    `lead_pm` VARCHAR(255),
    `pm_team` TEXT,
    `pm_account_type` VARCHAR(20),
    `pm_average_score` DOUBLE DEFAULT 0,
    `pm_average_score_3` DOUBLE DEFAULT 0,
    `annual_revenue` VARCHAR(20),
    `annual_revenue_converted` VARCHAR(20),
    `annual_revenue_currency` VARCHAR(20),
    `annual_revenue_converted_currency` VARCHAR(20),
    `field_Manager` VARCHAR(2),
    `mas_500_id` VARCHAR(12),
    `number` VARCHAR(40),
    `x90_days_since_last_bid` TEXT,
    `x4_year_bid` TEXT,
    `bid_discount_comments` TEXT,
    `of_bids_ytd` DOUBLE DEFAULT 0,
    `description` TEXT,
    `receive_invoice_via_id` INTEGER,
    `do_not_solicit` TINYINT(1) DEFAULT 0,
    `free_dvd` TINYINT(1) DEFAULT 0,
    `credit_hold` TINYINT(1) DEFAULT 0,
    `credit_terms` TEXT,
    `vat` VARCHAR(20),
    `conversion_rate` DOUBLE DEFAULT 0,
    `facility_average_score` DOUBLE DEFAULT 0,
    `facility_average_score_3` DOUBLE DEFAULT 0,
    `recruit_average_score` DOUBLE DEFAULT 0,
    `recruit_average_score_3` DOUBLE DEFAULT 0,
    `average_rating` DOUBLE DEFAULT 0,
    `need_for_po_numbers_to_start_recruiting` VARCHAR(3),
    `terms_conditions` LONGTEXT,
    `agreement_start_date` DATETIME,
    `agreement_end_date` DATETIME,
    `spreadsheet_sops` TEXT,
    `financial_alert` TEXT,
    `facility_sops` TEXT,
    `training_information` VARCHAR(2),
    `rr` TINYINT(1) DEFAULT 0,
    `ss` TINYINT(1) DEFAULT 0,
    `notes` VARCHAR(20),
    `spoc_notes` TEXT,
    `no_ai_needed` TINYINT(1) DEFAULT 0,
    `octopuce_record_id` VARCHAR(30),
    `top_150` VARCHAR(4),
    `coe` VARCHAR(5),
    `end_client_vertical_id` INTEGER,
    `other` DOUBLE DEFAULT 0,
    `currency_iso_code_id` INTEGER,
    `division` VARCHAR(255),
    `high_alert` TINYINT(1) DEFAULT 0,
    `alert_message` TEXT,
    `pharmaceutical` DOUBLE DEFAULT 0,
    `rebate` TINYINT(1),
    `last_modified_by_id` VARCHAR(255),
    `source` VARCHAR(255),
    `sic_description` TEXT,
    `last_activity_date` DATETIME,
    `last_modified_date` DATETIME,
    `create_by_id` VARCHAR(255),
    `created_date` DATETIME,
    `pmtool_updated` TINYINT(1) DEFAULT 0,
    `sponsor_2020` VARCHAR(255),
    `aspen_finn_sponsor` VARCHAR(255),
    `accounting_email` VARCHAR(255),
    `accounting_attn` VARCHAR(255),
    `pod_qual_id` INTEGER,
    `pod_quant_id` INTEGER,
    `discount_token_max` INTEGER,
    `discount_token_count` INTEGER,
    `quant_discount_program_id` INTEGER,
    `ar_payment_terms_id` INTEGER,
    `ai_payment_terms_id` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `sf_id` (`sf_id`),
    INDEX `pmtool_updated` (`pmtool_updated`),
    INDEX `sf_account_ibfi_1` (`client_type_id`),
    INDEX `sf_account_ibfi_2` (`client_source_id`),
    INDEX `sf_account_ibfi_5` (`industry_id`),
    INDEX `sf_account_ibfi_6` (`status_id`),
    INDEX `sf_account_ibfi_7` (`relationship_status_id`),
    INDEX `sf_account_ibfi_8` (`discount_program_id`),
    INDEX `sf_account_ibfi_9` (`discount_percentage_id`),
    INDEX `sf_account_ibfi_10` (`eu_discount_percentage_id`),
    INDEX `sf_account_ibfi_14` (`quant_discount_percentage_id`),
    INDEX `sf_account_ibfi_11` (`receive_invoice_via_id`),
    INDEX `sf_account_ibfi_12` (`end_client_vertical_id`),
    INDEX `sf_account_ibfi_13` (`currency_iso_code_id`),
    INDEX `sf_account_ibfi_15` (`pod_qual_id`),
    INDEX `sf_account_ibfi_16` (`pod_quant_id`),
    INDEX `sf_account_ibfi_17` (`quant_discount_program_id`),
    INDEX `sf_account_ibfi_18` (`ar_payment_terms_id`),
    INDEX `sf_account_ibfi_19` (`ai_payment_terms_id`),
    CONSTRAINT `sf_account_ibfk_1`
        FOREIGN KEY (`client_type_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_2`
        FOREIGN KEY (`client_source_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_5`
        FOREIGN KEY (`industry_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_6`
        FOREIGN KEY (`status_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_7`
        FOREIGN KEY (`relationship_status_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_8`
        FOREIGN KEY (`discount_program_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_9`
        FOREIGN KEY (`discount_percentage_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_10`
        FOREIGN KEY (`eu_discount_percentage_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_14`
        FOREIGN KEY (`quant_discount_percentage_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_11`
        FOREIGN KEY (`receive_invoice_via_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_12`
        FOREIGN KEY (`end_client_vertical_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_13`
        FOREIGN KEY (`currency_iso_code_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_15`
        FOREIGN KEY (`pod_qual_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_16`
        FOREIGN KEY (`pod_quant_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_17`
        FOREIGN KEY (`quant_discount_program_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_18`
        FOREIGN KEY (`ar_payment_terms_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_account_ibfk_19`
        FOREIGN KEY (`ai_payment_terms_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_contact
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_contact`;

CREATE TABLE `sf_contact`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    `pmtool_created_date` DATETIME,
    `pmtool_updated_date` DATETIME,
    `sf_id` VARCHAR(255),
    `account_sf_id` VARCHAR(255),
    `account_id` INTEGER,
    `client_id` VARCHAR(20),
    `cms_contact_id` VARCHAR(20),
    `title` VARCHAR(128),
    `first_name` VARCHAR(40),
    `last_name` VARCHAR(80),
    `account_name` TEXT,
    `primary_contact` TEXT,
    `owner` VARCHAR(255),
    `owner_alias` VARCHAR(255),
    `created_alias` DATETIME,
    `last_modified_alias` DATETIME,
    `owner_role_display` VARCHAR(255),
    `owner_role_name` VARCHAR(255),
    `data_com_key` VARCHAR(255),
    `email_bounced_reason` TEXT,
    `email_bounced_date` DATETIME,
    `is_person_account` TINYINT(1) DEFAULT 0,
    `birthdate` DATETIME,
    `phone` VARCHAR(255),
    `mobile_phone` VARCHAR(255),
    `fax` VARCHAR(255),
    `email` VARCHAR(255),
    `is_email_bounced` TINYINT(1) DEFAULT 0,
    `home_phone` VARCHAR(240),
    `other_phone` VARCHAR(255),
    `assistant_name` VARCHAR(40),
    `assistant_phone` VARCHAR(255),
    `can_be_duplicated` TINYINT(1) DEFAULT 0,
    `salutation_id` INTEGER,
    `linkedin` VARCHAR(255),
    `contact_status_id` INTEGER,
    `image_name` VARCHAR(40),
    `contact_preferences` TEXT,
    `moderator` TINYINT(1) DEFAULT 0,
    `no_client_portal` VARCHAR(1),
    `company_influencer` TINYINT(1) DEFAULT 0,
    `additional_email` VARCHAR(255),
    `reports_to_id` VARCHAR(255),
    `has_opted_out_of_email` TINYINT(1) DEFAULT 0,
    `do_not_solicit` TINYINT(1) DEFAULT 0,
    `client_space_log_in` TINYINT(1) DEFAULT 0,
    `client_space_tour` TINYINT(1) DEFAULT 0,
    `department` VARCHAR(40),
    `mailing_street` TEXT,
    `mailing_address` TEXT,
    `mailing_city` VARCHAR(40),
    `mailing_state` VARCHAR(80),
    `mailing_postal_code` VARCHAR(20),
    `mailing_country` VARCHAR(80),
    `other_street` TEXT,
    `other_address` TEXT,
    `other_city` VARCHAR(40),
    `other_state` VARCHAR(80),
    `other_postal_code` VARCHAR(20),
    `other_country` VARCHAR(80),
    `language_preference_id` INTEGER,
    `the_wall_id` INTEGER,
    `description` TEXT,
    `field_management` VARCHAR(3),
    `gift_code_id` INTEGER,
    `lead_source_id` INTEGER,
    `lead_source_description` TEXT,
    `alert_message` TEXT,
    `currency_iso_code_id` INTEGER,
    `act_on_lead_score` DOUBLE DEFAULT 0,
    `direct_number` VARCHAR(255),
    `hidden_dupecheck` VARCHAR(255),
    `tw_lead_source_id` INTEGER,
    `import_id` VARCHAR(30),
    `owner_id` TEXT,
    `last_modified_by_id` VARCHAR(255),
    `last_modified_date` DATETIME,
    `last_cu_request_date` DATETIME,
    `last_cu_update_date` DATETIME,
    `last_activity` DATETIME,
    `last_activity_date` DATETIME,
    `last_modified_dts` DATETIME,
    `created_by_profile_name` TEXT,
    `created_by_id` VARCHAR(255),
    `created_date` DATETIME,
    `added_by_id` INTEGER,
    `system_modstamp` DATETIME,
    `pmtool_updated` TINYINT(1) DEFAULT 0,
    `pay_id` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `sf_id` (`sf_id`),
    INDEX `pmtool_updated` (`pmtool_updated`),
    INDEX `sf_contact_ibfi_10` (`account_id`),
    INDEX `sf_contact_ibfi_1` (`salutation_id`),
    INDEX `sf_contact_ibfi_2` (`contact_status_id`),
    INDEX `sf_contact_ibfi_3` (`language_preference_id`),
    INDEX `sf_contact_ibfi_4` (`the_wall_id`),
    INDEX `sf_contact_ibfi_5` (`gift_code_id`),
    INDEX `sf_contact_ibfi_6` (`lead_source_id`),
    INDEX `sf_contact_ibfi_7` (`currency_iso_code_id`),
    INDEX `sf_contact_ibfi_8` (`tw_lead_source_id`),
    INDEX `sf_contact_ibfi_9` (`added_by_id`),
    INDEX `pays_ibfi_10` (`pay_id`),
    CONSTRAINT `sf_contact_ibfk_10`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_1`
        FOREIGN KEY (`salutation_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_2`
        FOREIGN KEY (`contact_status_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_3`
        FOREIGN KEY (`language_preference_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_4`
        FOREIGN KEY (`the_wall_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_5`
        FOREIGN KEY (`gift_code_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_6`
        FOREIGN KEY (`lead_source_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_7`
        FOREIGN KEY (`currency_iso_code_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_8`
        FOREIGN KEY (`tw_lead_source_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_contact_ibfk_9`
        FOREIGN KEY (`added_by_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `pays_ibfk_10`
        FOREIGN KEY (`pay_id`)
        REFERENCES `pays` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce`;

CREATE TABLE `sf_ref_salesforce`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `table` TINYINT DEFAULT 0 NOT NULL,
    `label` VARCHAR(255),
    `field` VARCHAR(255) NOT NULL,
    `value` VARCHAR(255) NOT NULL,
    `actif` TINYINT(1) DEFAULT 1,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_opportunity_services
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_opportunity_services`;

CREATE TABLE `sf_ref_salesforce_opportunity_services`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`opportunity_id`),
    INDEX `sf_ref_salesforce_opportunity_services_ibfi_2` (`opportunity_id`),
    CONSTRAINT `sf_ref_salesforce_opportunity_services_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_opportunity_services_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_opportunity_sector
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_opportunity_sector`;

CREATE TABLE `sf_ref_salesforce_opportunity_sector`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`opportunity_id`),
    INDEX `sf_ref_salesforce_opportunity_sector_ibfi_2` (`opportunity_id`),
    CONSTRAINT `sf_ref_salesforce_opportunity_sector_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_opportunity_sector_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_opportunity_closed_lost_reason_v2
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_opportunity_closed_lost_reason_v2`;

CREATE TABLE `sf_ref_salesforce_opportunity_closed_lost_reason_v2`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`opportunity_id`),
    INDEX `sf_ref_salesforce_opportunity_closed_lost_reason_v2_ibfi_2` (`opportunity_id`),
    CONSTRAINT `sf_ref_salesforce_opportunity_closed_lost_reason_v2_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_opportunity_closed_lost_reason_v2_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_methodology`;

CREATE TABLE `sf_opportunity_methodology`
(
    `ref_methodology_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_methodology_id`,`opportunity_id`),
    INDEX `sf_opportunity_methodology_ibfi_2` (`opportunity_id`),
    CONSTRAINT `sf_opportunity_methodology_ibfk_1`
        FOREIGN KEY (`ref_methodology_id`)
        REFERENCES `ref_methodology` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_methodology_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_location
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_location`;

CREATE TABLE `sf_opportunity_location`
(
    `ref_location_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_location_id`,`opportunity_id`),
    INDEX `sf_opportunity_location_ibfi_2` (`opportunity_id`),
    CONSTRAINT `sf_opportunity_location_ibfk_1`
        FOREIGN KEY (`ref_location_id`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_location_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- opportunity_sample_source
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `opportunity_sample_source`;

CREATE TABLE `opportunity_sample_source`
(
    `sample_source_id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `created_date` DATETIME,
    `updated_date` DATETIME,
    PRIMARY KEY (`sample_source_id`,`opportunity_id`),
    INDEX `opportunity_sample_source_ibfi_2` (`opportunity_id`),
    CONSTRAINT `opportunity_sample_source_ibfk_1`
        FOREIGN KEY (`sample_source_id`)
        REFERENCES `ref_sample_source` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `opportunity_sample_source_ibfk_2`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_schlesinger_events
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_schlesinger_events`;

CREATE TABLE `sf_ref_salesforce_contact_schlesinger_events`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_schlesinger_events_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_schlesinger_events_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_schlesinger_events_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_possible_primary_job_location
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_possible_primary_job_location`;

CREATE TABLE `sf_ref_salesforce_contact_possible_primary_job_location`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_possible_primary_job_location_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_possible_primary_job_location_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_possible_primary_job_location_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_area_of_interest
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_area_of_interest`;

CREATE TABLE `sf_ref_salesforce_contact_area_of_interest`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_area_of_interest_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_area_of_interest_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_area_of_interest_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_marketing_audience
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_marketing_audience`;

CREATE TABLE `sf_ref_salesforce_contact_marketing_audience`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_marketing_audience_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_marketing_audience_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_marketing_audience_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_methodology`;

CREATE TABLE `sf_ref_salesforce_contact_methodology`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_methodology_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_methodology_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_methodology_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_contact_contact_source
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_contact_contact_source`;

CREATE TABLE `sf_ref_salesforce_contact_contact_source`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `contact_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`contact_id`),
    INDEX `sf_ref_salesforce_contact_contact_source_ibfi_2` (`contact_id`),
    CONSTRAINT `sf_ref_salesforce_contact_contact_source_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_contact_contact_source_ibfk_2`
        FOREIGN KEY (`contact_id`)
        REFERENCES `sf_contact` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_areas_of_research
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_areas_of_research`;

CREATE TABLE `sf_ref_salesforce_account_areas_of_research`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_areas_of_research_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_areas_of_research_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_areas_of_research_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_country_of_use
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_country_of_use`;

CREATE TABLE `sf_ref_salesforce_account_country_of_use`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_country_of_use_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_country_of_use_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_country_of_use_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_regularly_uses_another_vendor_for
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_regularly_uses_another_vendor_for`;

CREATE TABLE `sf_ref_salesforce_account_regularly_uses_another_vendor_for`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_regularly_uses_another_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_regularly_uses_another_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_regularly_uses_another_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_regularly_uses_sa_for
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_regularly_uses_sa_for`;

CREATE TABLE `sf_ref_salesforce_account_regularly_uses_sa_for`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_regularly_uses_sa_for_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_regularly_uses_sa_for_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_regularly_uses_sa_for_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_products_and_services_used
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_products_and_services_used`;

CREATE TABLE `sf_ref_salesforce_account_products_and_services_used`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_products_and_services_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_products_and_services_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_products_and_services_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_agreement_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_agreement_type`;

CREATE TABLE `sf_ref_salesforce_account_agreement_type`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_agreement_type_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_agreement_type_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_agreement_type_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_account_sub_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_account_sub_type`;

CREATE TABLE `sf_ref_salesforce_account_sub_type`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `account_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`account_id`),
    INDEX `sf_ref_salesforce_account_sub_type_ibfi_2` (`account_id`),
    CONSTRAINT `sf_ref_salesforce_account_sub_type_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_account_sub_type_ibfk_2`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_job_services
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_job_services`;

CREATE TABLE `sf_ref_salesforce_job_services`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `job_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`job_id`),
    INDEX `sf_ref_salesforce_job_services_ibfi_2` (`job_id`),
    CONSTRAINT `sf_ref_salesforce_job_services_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_job_services_ibfk_2`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_ref_salesforce_etude_sector
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_ref_salesforce_etude_sector`;

CREATE TABLE `sf_ref_salesforce_etude_sector`
(
    `ref_salesforce_id` INTEGER NOT NULL,
    `etude_id` INTEGER NOT NULL,
    `api_created_date` DATETIME,
    `api_updated_date` DATETIME,
    PRIMARY KEY (`ref_salesforce_id`,`etude_id`),
    INDEX `sf_ref_salesforce_etude_sector_ibfi_2` (`etude_id`),
    CONSTRAINT `sf_ref_salesforce_etude_sector_ibfk_1`
        FOREIGN KEY (`ref_salesforce_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_ref_salesforce_etude_sector_ibfk_2`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_sample_source
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_sample_source`;

CREATE TABLE `ref_sample_source`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `actif` TINYINT(1) DEFAULT 1,
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `libelle` (`libelle`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_area
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_area`;

CREATE TABLE `ref_area`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `sector_id` INTEGER(8),
    `libelle` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `actif` TINYINT(1) DEFAULT 1,
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `libelle` (`libelle`),
    INDEX `ref_area_ibfi_1` (`sector_id`),
    CONSTRAINT `ref_area_ibfk_1`
        FOREIGN KEY (`sector_id`)
        REFERENCES `sf_ref_salesforce` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_discount_on
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_discount_on`;

CREATE TABLE `ref_discount_on`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `actif` TINYINT(1) DEFAULT 1,
    `ordre` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `libelle` (`libelle`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_si_job_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_si_job_type`;

CREATE TABLE `ref_si_job_type`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `label` VARCHAR(255) NOT NULL,
    `sf_label` VARCHAR(255),
    `active` TINYINT(1) DEFAULT 1,
    `rank` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `label` (`label`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_event_methodology
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_event_methodology`;

CREATE TABLE `ref_event_methodology`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `label` VARCHAR(255) NOT NULL,
    `sams_label` VARCHAR(255),
    `active` TINYINT(1) DEFAULT 1,
    `localisation` VARCHAR(255),
    `localisation2` VARCHAR(255),
    `text` TEXT,
    `rank` INTEGER,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `label` (`label`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- cheques_historique
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `cheques_historique`;

CREATE TABLE `cheques_historique`
(
    `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
    `no_cheque` VARCHAR(255),
    `montant_cheque` DECIMAL(10,2),
    `date_creation_cheque` DATE,
    `date_annulation_cheque` DATE,
    `id_repondant` INTEGER,
    `id_etude` INTEGER,
    `id_module` INTEGER,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_checklist_validation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_checklist_validation`;

CREATE TABLE `etude_checklist_validation`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `etude_checklist_id` INTEGER NOT NULL,
    `etude_id` INTEGER NOT NULL,
    `is_check` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `etude_checklist_validation_u_540f35` (`etude_checklist_id`, `etude_id`),
    INDEX `etude_checklist_validation_ibfi_2` (`etude_id`),
    CONSTRAINT `etude_checklist_validation_ibfk_1`
        FOREIGN KEY (`etude_checklist_id`)
        REFERENCES `ref_etude_checklist` (`id`),
    CONSTRAINT `etude_checklist_validation_ibfk_2`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fournisseur_notation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `fournisseur_notation`;

CREATE TABLE `fournisseur_notation`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `fournisseur_id` INTEGER(8) NOT NULL,
    `date` DATE NOT NULL,
    `pm_id` INTEGER(8) NOT NULL,
    `note_qualite_prestation` INTEGER(2) NOT NULL,
    `note_rapidite_action` INTEGER(2) NOT NULL,
    `note_respect_delai` INTEGER(2) NOT NULL,
    `note_communication` INTEGER(2) NOT NULL,
    `note_rapport_qualite_prix` INTEGER(2) NOT NULL,
    `note_flexibilite` INTEGER(2) NOT NULL,
    `validation` CHAR(2) DEFAULT '' NOT NULL,
    `liste_id_etude` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `pm_id` (`pm_id`, `validation`),
    INDEX `fournisseur_notation_fi_558905` (`fournisseur_id`),
    CONSTRAINT `fournisseur_notation_fk_609c22`
        FOREIGN KEY (`pm_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `fournisseur_notation_fk_558905`
        FOREIGN KEY (`fournisseur_id`)
        REFERENCES `fournisseur` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- lieu_notation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `lieu_notation`;

CREATE TABLE `lieu_notation`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `site_id` INTEGER(8) NOT NULL,
    `date` DATE NOT NULL,
    `pm_id` INTEGER(8) NOT NULL,
    `note_qualite_prestation` INTEGER(2) NOT NULL,
    `note_rapidite_action` INTEGER(2) NOT NULL,
    `note_respect_delai` INTEGER(2) NOT NULL,
    `note_communication` INTEGER(2) NOT NULL,
    `note_rapport_qualite_prix` INTEGER(2) NOT NULL,
    `note_flexibilite` INTEGER(2) NOT NULL,
    `validation` CHAR(2) DEFAULT '' NOT NULL,
    `liste_id_etude` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `pm_id` (`pm_id`, `validation`),
    INDEX `lieu_notation_fi_36b1e8` (`site_id`),
    CONSTRAINT `lieu_notation_fk_609c22`
        FOREIGN KEY (`pm_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `lieu_notation_fk_36b1e8`
        FOREIGN KEY (`site_id`)
        REFERENCES `ref_site` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_etude_checklist_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_etude_checklist_type`;

CREATE TABLE `ref_etude_checklist_type`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `sort` INTEGER NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_etude_checklist
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_etude_checklist`;

CREATE TABLE `ref_etude_checklist`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `libelle` VARCHAR(255) NOT NULL,
    `etude_etape_id` INTEGER,
    `groupe_id` INTEGER,
    `etude_checklist_type_id` INTEGER,
    `sort` INTEGER NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `ref_etude_checklist_ibfi_3` (`groupe_id`),
    INDEX `ref_etude_checklist_ibfi_1` (`etude_etape_id`),
    INDEX `ref_etude_checklist_ibfi_2` (`etude_checklist_type_id`),
    CONSTRAINT `ref_etude_checklist_ibfk_3`
        FOREIGN KEY (`groupe_id`)
        REFERENCES `groupe` (`id`),
    CONSTRAINT `ref_etude_checklist_ibfk_1`
        FOREIGN KEY (`etude_etape_id`)
        REFERENCES `ref_etape` (`id`),
    CONSTRAINT `ref_etude_checklist_ibfk_2`
        FOREIGN KEY (`etude_checklist_type_id`)
        REFERENCES `ref_etude_checklist_type` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- repondant_blacklist
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `repondant_blacklist`;

CREATE TABLE `repondant_blacklist`
(
    `repondant_id` INTEGER(8) NOT NULL,
    `account_id` INTEGER(8) NOT NULL,
    PRIMARY KEY (`repondant_id`,`account_id`),
    INDEX `repondant_blacklist_fi_38c569` (`account_id`),
    CONSTRAINT `repondant_blacklist_fk_533a40`
        FOREIGN KEY (`repondant_id`)
        REFERENCES `repondant` (`id`),
    CONSTRAINT `repondant_blacklist_fk_38c569`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- fichier
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `fichier`;

CREATE TABLE `fichier`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `fichier_original` VARCHAR(255),
    `fichier` VARCHAR(255) NOT NULL,
    `mime_type` VARCHAR(255),
    `extension` VARCHAR(10),
    `type` TINYINT DEFAULT 0,
    `lang` TINYINT DEFAULT 0,
    `date_creation` DATETIME,
    `date_maj` DATETIME,
    `is_visible` TINYINT DEFAULT 1,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_item_fichier
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_item_fichier`;

CREATE TABLE `etude_item_fichier`
(
    `job_item_id` INTEGER NOT NULL,
    `fichier_id` INTEGER NOT NULL,
    PRIMARY KEY (`job_item_id`,`fichier_id`),
    INDEX `job_item_fichier_fi_bd7f50` (`fichier_id`),
    CONSTRAINT `job_item_fichier_fk_26e26c`
        FOREIGN KEY (`job_item_id`)
        REFERENCES `job_item` (`id`),
    CONSTRAINT `job_item_fichier_fk_bd7f50`
        FOREIGN KEY (`fichier_id`)
        REFERENCES `fichier` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_group
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_group`;

CREATE TABLE `etude_group`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `theme` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- etude_fichier
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `etude_fichier`;

CREATE TABLE `etude_fichier`
(
    `etude_id` INTEGER NOT NULL,
    `fichier_id` INTEGER NOT NULL,
    PRIMARY KEY (`etude_id`,`fichier_id`),
    INDEX `fichier_fichier_ibfi_2` (`fichier_id`),
    CONSTRAINT `etude_fichier_ibfk_1`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`),
    CONSTRAINT `fichier_fichier_ibfk_2`
        FOREIGN KEY (`fichier_id`)
        REFERENCES `fichier` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- opportunity_fichier
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `opportunity_fichier`;

CREATE TABLE `opportunity_fichier`
(
    `opportunity_id` INTEGER NOT NULL,
    `fichier_id` INTEGER NOT NULL,
    PRIMARY KEY (`opportunity_id`,`fichier_id`),
    INDEX `fichier_fichier_ibfi_2879` (`fichier_id`),
    CONSTRAINT `opportunity_fichier_ibfk_1`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`),
    CONSTRAINT `fichier_fichier_ibfk_2879`
        FOREIGN KEY (`fichier_id`)
        REFERENCES `fichier` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- log_event
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `log_event`;

CREATE TABLE `log_event`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `object_id` INTEGER(8) NOT NULL,
    `user_id` INTEGER(8) NOT NULL,
    `date` DATETIME NOT NULL,
    `event` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `user_event_log_fi_1` (`user_id`),
    CONSTRAINT `user_event_log_fk_1`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- log_job
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `log_job`;

CREATE TABLE `log_job`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `job_id` INTEGER(8) NOT NULL,
    `job_item_id` INTEGER(8),
    `job_cost_id` INTEGER(8),
    `user_id` INTEGER(8) NOT NULL,
    `date` DATETIME NOT NULL,
    `changed_column` VARCHAR(255) NOT NULL,
    `initial_value` TEXT(255),
    `new_value` VARCHAR(255),
    PRIMARY KEY (`id`),
    INDEX `job_log_fi_1` (`job_id`),
    INDEX `job_item_log_fi_1` (`job_item_id`),
    INDEX `job_cost_log_fi_1` (`job_cost_id`),
    INDEX `user_log_fi_1` (`user_id`),
    CONSTRAINT `job_log_fk_1`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`),
    CONSTRAINT `job_item_log_fk_1`
        FOREIGN KEY (`job_item_id`)
        REFERENCES `job_item` (`id`)
        ON DELETE SET NULL,
    CONSTRAINT `job_cost_log_fk_1`
        FOREIGN KEY (`job_cost_id`)
        REFERENCES `job_costs` (`id`)
        ON DELETE SET NULL,
    CONSTRAINT `user_log_fk_1`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- spoc_project_manager
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `spoc_project_manager`;

CREATE TABLE `spoc_project_manager`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `sf_id` VARCHAR(255) DEFAULT '' NOT NULL,
    `user_id` INTEGER(8),
    `type` TINYINT,
    `instance` TINYINT,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- log_project_status
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `log_project_status`;

CREATE TABLE `log_project_status`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `etude_id` INTEGER(8) NOT NULL,
    `job_id` INTEGER(8),
    `user_id` INTEGER(8),
    `date` DATETIME NOT NULL,
    `status` VARCHAR(255) NOT NULL,
    `am_checked` TINYINT(1) DEFAULT 0,
    `pm_checked` TINYINT(1) DEFAULT 0,
    `acct` TINYINT(1) DEFAULT 0,
    `fd_checked` TINYINT(1) DEFAULT 0,
    `acct_inv_checked` TINYINT(1) DEFAULT 0,
    `audit_complete` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `etude_log_fi_1` (`etude_id`),
    INDEX `job_logs_fi_1` (`job_id`),
    INDEX `user_project_log_fi_1` (`user_id`),
    CONSTRAINT `etude_log_fk_1`
        FOREIGN KEY (`etude_id`)
        REFERENCES `etude` (`id`),
    CONSTRAINT `job_logs_fk_1`
        FOREIGN KEY (`job_id`)
        REFERENCES `job` (`id`),
    CONSTRAINT `user_project_log_fk_1`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- consolidated_project
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `consolidated_project`;

CREATE TABLE `consolidated_project`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `project_name` VARCHAR(255) NOT NULL,
    `fr_project_id` INTEGER(8),
    `uk_project_id` INTEGER(8),
    `es_project_id` INTEGER(8),
    `de_project_id` INTEGER(8),
    `us_project_id` INTEGER(8),
    `euro` VARCHAR(25),
    `pound` VARCHAR(25),
    `dollar` VARCHAR(25),
    PRIMARY KEY (`id`),
    UNIQUE INDEX `consolidated_project_u_248c80` (`project_name`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- spoc_datas
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `spoc_datas`;

CREATE TABLE `spoc_datas`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `slug` VARCHAR(255) NOT NULL,
    `team_notes` TEXT NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `spoc_datas_u_019dad` (`slug`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_room
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_room`;

CREATE TABLE `ref_room`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `location_id` INTEGER(8),
    `order` INTEGER,
    `active` TINYINT(1) DEFAULT 1,
    `room_count` DECIMAL(15,2) NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `location_room_fi_1` (`location_id`),
    CONSTRAINT `location_room_fk_1`
        FOREIGN KEY (`location_id`)
        REFERENCES `ref_location` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_event_status
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_event_status`;

CREATE TABLE `ref_event_status`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `color` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- user_calendar_location
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `user_calendar_location`;

CREATE TABLE `user_calendar_location`
(
    `user_id` INTEGER(8) NOT NULL,
    `location_id` INTEGER(8) NOT NULL,
    PRIMARY KEY (`user_id`,`location_id`),
    INDEX `user_calendar_location_fi_5c009c` (`location_id`),
    CONSTRAINT `user_calendar_location_fk_29554a`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `user_calendar_location_fk_5c009c`
        FOREIGN KEY (`location_id`)
        REFERENCES `ref_location` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ref_time_slot
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `ref_time_slot`;

CREATE TABLE `ref_time_slot`
(
    `id` INTEGER(3) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- news_update
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `news_update`;

CREATE TABLE `news_update`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `news_title` VARCHAR(255) NOT NULL,
    `site_name` VARCHAR(255) NOT NULL,
    `news_text` VARCHAR(1000) NOT NULL,
    `news_url` VARCHAR(1000),
    `picture_id` INTEGER(8) NOT NULL,
    `user_id` INTEGER(8) NOT NULL,
    `status` TINYINT DEFAULT 0,
    `created_at` DATETIME NOT NULL,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `news_update_fi_29554a` (`user_id`),
    INDEX `news_update_fi_913642` (`picture_id`),
    CONSTRAINT `news_update_fk_29554a`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`),
    CONSTRAINT `news_update_fk_913642`
        FOREIGN KEY (`picture_id`)
        REFERENCES `news_images` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- news_images
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `news_images`;

CREATE TABLE `news_images`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `image_name` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- project_location_prefix
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `project_location_prefix`;

CREATE TABLE `project_location_prefix`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(20) NOT NULL,
    `prefix` VARCHAR(10) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `name` (`name`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- platforms
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `platforms`;

CREATE TABLE `platforms`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `active` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `name` (`name`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- country_holiday
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `country_holiday`;

CREATE TABLE `country_holiday`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `country_code` VARCHAR(50) NOT NULL,
    `day_holiday` DATE NOT NULL,
    `name_holiday` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- discount_program
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `discount_program`;

CREATE TABLE `discount_program`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `active` TINYINT(1) DEFAULT 0,
    `groupe` TINYINT NOT NULL,
    `type` TINYINT NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `name` (`name`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- categorie_prestation_discount
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `categorie_prestation_discount`;

CREATE TABLE `categorie_prestation_discount`
(
    `categorie_prestation_id` INTEGER(8) NOT NULL,
    `discount_program_id` INTEGER(8) NOT NULL,
    `value` TINYINT,
    PRIMARY KEY (`categorie_prestation_id`,`discount_program_id`),
    INDEX `categorie_prestation_discount_fi_80d42f` (`discount_program_id`),
    CONSTRAINT `categorie_prestation_discount_fk_de120b`
        FOREIGN KEY (`categorie_prestation_id`)
        REFERENCES `categorie_prestation` (`id`),
    CONSTRAINT `categorie_prestation_discount_fk_80d42f`
        FOREIGN KEY (`discount_program_id`)
        REFERENCES `discount_program` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- user_log
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `user_id` INTEGER(8),
    `session_value` VARCHAR(255) NOT NULL,
    `login_at` DATETIME,
    `logged_out_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `user_userdata_log_fi_1` (`user_id`),
    CONSTRAINT `user_userdata_log_fk_1`
        FOREIGN KEY (`user_id`)
        REFERENCES `user` (`id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid_archive
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid_archive`;

CREATE TABLE `sf_opportunity_bid_archive`
(
    `id` INTEGER NOT NULL,
    `opportunity_id` INTEGER NOT NULL,
    `label` VARCHAR(255) DEFAULT '',
    `study_specification` LONGTEXT,
    `is_preferred` TINYINT(1) DEFAULT 0,
    `is_chosen` TINYINT(1) DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    `archived_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_ibfi_1` (`opportunity_id`),
    INDEX `sf_opportunity_bid_ibfi_2` (`created_by_id`),
    INDEX `sf_opportunity_bid_ibfi_3` (`updated_by_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid_job_archive
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid_job_archive`;

CREATE TABLE `sf_opportunity_bid_job_archive`
(
    `id` INTEGER NOT NULL,
    `bid_id` INTEGER NOT NULL,
    `is_multimarket` VARCHAR(50),
    `per_hour` VARCHAR(50),
    `per_group` VARCHAR(50),
    `per_day` VARCHAR(50),
    `multimarket_in_calculation` VARCHAR(50),
    `name` VARCHAR(150),
    `location_id` INTEGER NOT NULL,
    `on_site_recruits` DOUBLE DEFAULT 0,
    `off_site_recruits` DOUBLE DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `product_id` INTEGER(8),
    `created_at` DATETIME,
    `updated_at` DATETIME,
    `archived_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_ibfi_1` (`bid_id`),
    INDEX `sf_opportunity_bid_job_ibfi_2` (`location_id`),
    INDEX `sf_opportunity_bid_job_ibfi_3` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_ibfi_4` (`updated_by_id`),
    INDEX `product_ibfi_9` (`product_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- sf_opportunity_bid_job_item_archive
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `sf_opportunity_bid_job_item_archive`;

CREATE TABLE `sf_opportunity_bid_job_item_archive`
(
    `id` INTEGER NOT NULL,
    `bid_job_id` INTEGER NOT NULL,
    `event_id` INTEGER,
    `section_id` INTEGER COMMENT 'Category prestation',
    `title` VARCHAR(255) NOT NULL,
    `vendor_id` INTEGER(10) COMMENT 'Fournisseur',
    `resp_location_id` INTEGER,
    `methodology_id` INTEGER,
    `date` DATE,
    `selling_qty` DECIMAL(8,3),
    `selling_unit_price` DECIMAL(15,2),
    `unit` DECIMAL(15,2),
    `selling_price` DECIMAL(15,2),
    `cost_qty` INTEGER,
    `cost_unit_price` DECIMAL(15,2),
    `cost_location_unit_price` DECIMAL(15,2),
    `cost_rate` DECIMAL(8,2),
    `cost_price` DECIMAL(15,2),
    `discount_comment` TEXT,
    `discount_percent` DECIMAL(8,2),
    `discount_exclude` TINYINT(1) DEFAULT 0,
    `discount_auto` TINYINT(1) DEFAULT 0,
    `pm_comment` TEXT,
    `order` INTEGER NOT NULL,
    `group` INTEGER DEFAULT 0,
    `group_title` VARCHAR(50),
    `super_group` INTEGER DEFAULT 0,
    `super_group_title` VARCHAR(50),
    `first_discount_percentage` DECIMAL(4,2),
    `second_discount_percentage` DECIMAL(4,2),
    `first_discount_section_id` INTEGER,
    `second_discount_section_id` INTEGER,
    `respondent_type_id` INTEGER,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    `archived_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_1` (`bid_job_id`),
    INDEX `sf_opportunity_bid_job_item_fi_b54508` (`event_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_3` (`section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_4` (`vendor_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_5` (`resp_location_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_6` (`methodology_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_12` (`first_discount_section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_13` (`second_discount_section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_9` (`respondent_type_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_7` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_8` (`updated_by_id`)
) ENGINE=InnoDB;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
