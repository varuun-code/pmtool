SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_event_status`;

INSERT INTO `ref_event_status` (`id`, `name`, `color`) VALUES
(1, 'On Hold', '#da63e8'),
(2, 'Confirmed', '#049E27'),
(3, 'Active', '#04209E'),
(4, 'Cancelled Billed', '#800000'),
(5, 'Tentative', '#808080'),
(6, 'Cancelled non-Billed', '#4c0854'),
(7, 'Closed', '#000000'),
(8, 'Released', '#FF7D33');

SET FOREIGN_KEY_CHECKS = 1;