TRUNCATE `fournisseur_type`;
INSERT INTO `fournisseur_type` (`fournisseur_type`, `fournisseur_type_br`, `schedule`, `id_categorie`) VALUES
('External recruiter','External recruiter','',7),
('Catering ','Catering','',6),
('Moderator','Moderator','',8),
('Interviewer POS/Inhome','Interviewer POS/Inhome','',8),
('Notetaking / Transcripts','Notetaking / Transcripts','',10),
('Intepreter/Sim translator','Intepreter/Sim translator','',24),
('Translator','Translator','',4),
('External facility','External facility','',9),
('Technology provider','Technology provider','',9),
('Interviewer Quant Facility','Interviewer Quant Facility','',9),
('Interviewer Phone Room','Interviewer Phone Room','',9),
('Interviewer Data processing','Interviewer Data processing','',9),
('Interviewer QA','Interviewer QA','',9),
('Interviewer Projectassistant','Interviewer Projectassistant','',9);
