SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `user`;
INSERT INTO `user` (`id`, `mail`, `nom`, `prenom`, `id_groupe`, `id_coordinateur`, `statut`, `fournisseur_id`, `employe`, `id_location`, `id_location_pr`, `default_sf`, `sf_id`) VALUES
(NULL, 'support@spyrit.net', 'Spyrit', 'Support', '4', 0, 'A', 0, '', 1, NULL, 0, ''),
(NULL, 'support+1@spyrit.net', 'Spyrit', 'Support', '4', 0, 'A', 0, '', 1, NULL, 1, 'test');
SET FOREIGN_KEY_CHECKS = 1;