SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `phoneroom_target`;
INSERT INTO `phoneroom_target` (`target`) VALUES
('1 B2C'),
('2 HC'),
('3 B2B');
SET FOREIGN_KEY_CHECKS = 1;