SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_si_job_type`;
INSERT INTO `ref_si_job_type` (`label`, `sf_label`, `active`, `rank`) VALUES
('Wave','Wave',1,1),
('Tracker','Tracker',1,2),
('NA','NA',1,3);
SET FOREIGN_KEY_CHECKS = 1;