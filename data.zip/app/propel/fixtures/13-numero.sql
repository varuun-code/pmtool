TRUNCATE `numero`;
INSERT INTO `numero` (`numero`, `type`) VALUES
(0,'cmde_fnr'),
(0,'etude'),
(0,'facture');