SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `coefficient`;
INSERT INTO `coefficient` (`coefficient`) VALUES
(1.00),
(0.40);
SET FOREIGN_KEY_CHECKS = 1;