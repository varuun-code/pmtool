TRUNCATE `ref_discount_on`;
INSERT INTO `ref_discount_on` (`libelle`, `sf_label`, `actif`, `ordre`) VALUES
('Facility + Recruitment',NULL,1,1),
('Total invoice excl. incentives',NULL,1,2),
('Total invoice',NULL,1,3),
('Facility only',NULL,1,4);