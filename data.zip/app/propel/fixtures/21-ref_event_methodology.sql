SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_event_methodology`;
INSERT INTO `ref_event_methodology` (`label`, `sams_label`, `active`, `rank`) VALUES
('Group','Group',1,1),
('Internet','Internet',1,2),
('NA','NA',1,3),
('One-on-One','One-on-One',1,4),
('SAQ','SAQ',1,5),
('Telephone','Telephone',1,6),
('Client Briefing','Client Briefing',1,7),
('OBB','OBB',1,8),
('Duo','Duo',1,9),
('Triad','Triad',1,10),
('Webcam','Webcam',1,11),
('Field','Field',1,12);
SET FOREIGN_KEY_CHECKS = 1;