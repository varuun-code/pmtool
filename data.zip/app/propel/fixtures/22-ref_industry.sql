SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_industry`;
INSERT INTO `ref_industry` (`libelle`, `sf_label`, `actif`, `ordre`) VALUES
('Healthcare','Healthcare',1,6),
('Financial Services / Insurances','Financial Services / Insurance',1,3),
('Media / Film / Gaming','Entertainment',1,2),
('Consumer','CPG /FMCG',1,7),
('Other','Other',1,5),
('IT / Tech / Internet / PC / Mobile Phones','Technology',1,4),
('Automotive / Transportation / Travel','Automotive',1,1),
('Test','',0,NULL);
SET FOREIGN_KEY_CHECKS = 1;