SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `confirmation`;
INSERT INTO `confirmation` (`confirmation`) VALUES
('E-mail'),('Fax'),('Phone'),('Postal Letter + E-mail'),('Postal Letter');
SET FOREIGN_KEY_CHECKS = 1;