TRUNCATE `suivimajtable`;
INSERT INTO `suivimajtable` (`operation`, `date`) VALUES
('initTable','2017-12-01 02:03:04'),
('saveDb','2017-12-02 04:05:06');
