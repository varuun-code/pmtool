TRUNCATE `imputation_type`;
INSERT INTO `imputation_type` (`imputation`) VALUES
('IT / Tech'),
('Administration '),
('Sales'),
('Data Base / Panel'),
('Accounting'),
('Marketing');
