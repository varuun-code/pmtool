SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_etape`;
INSERT INTO `ref_etape` (`id`, `etape`, `sf_label`, `ordre`, `id_groupe`) VALUES
(1,'Master Project creation','Active',1,9),
(2,'Ongoing','Active',4,2),
(3,'Invoiced','Closed',7,3),
(4,'Paid','Closed',8,3),
(8,'Budget creation','Active',2,6),
(10,'To invoice','Active',6,1),
(11,'Cancelled','Cancelled-Non-Billed',99,3),
(12,'Standby','Postponed',98,3),
(13,'Master Project finished','Active',5,9),
(14,'To Confirm','Active',3,1);
SET FOREIGN_KEY_CHECKS = 1;