SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `duree`;
INSERT INTO `duree` (`dureeNum`, `dureeText`) VALUES
(15,'15 Min.'),
(20,'20 Min.'),
(50,'50 Min.'),
(60,'60 Min.'),
(75,'75 Min.'),
(105,'1H45'),
(135,'2H15'),
(150,'2H30'),
(180,'3H00'),
(195,'3H15'),
(210,'3H30'),
(240,'4H00'),
(270,'4H30'),
(300,'5H00'),
(360,'6H00'),
(480,'8H00');
SET FOREIGN_KEY_CHECKS = 1;