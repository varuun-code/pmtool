SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_methodology`;
INSERT INTO `ref_methodology` (`typeEtudeOrdre`, `typeEtude`, `typeEtudeBr`, `typeEtudeAlias`, `id_duree`, `consolidation`, `sf_label`, `actif`, `job_qualification_id`) VALUES
(60,'Room Rental','Room Rental','RR',1,'1 - Qual',NULL,0,354),
(160,'Data processing/Analysis quant/Other quant','Data processing/Analysis quant/Other quant','DP QT',0,'2 - Quant','Other Quant',1,385),
(10,'Focus Groups','Focus Groups','FG',0,'1 - Qual','Focus Group',1,354),
(100,'Inhome Test quant','Inhome Test quant','INHOME',1,'2 - Quant',NULL,0,385),
(110,'Point-of-sale/on-street/count','Point-of-sale/on-street/count','POS',0,'2 - Quant','Intercepts',1,385),
(70,'Moderation/Report/Analysis qual/Other Qual','Moderation/Report/Analysis qual/Other Qual','MOD',0,'1 - Qual','Other Qual',1,354),
(180,'Online qual','Online qual','ON QL',1,'1 - Oual','Online Bulletin Board',1,354),
(170,'Online quant','Online quant','ON QT',1,'3 - Online','Online Survey',1,371),
(30,'Recruits off-site','Recruits off-site','EXTR',1,'1 - Qual',NULL,0,354),
(40,'Recruits for other location','Recruits for other location','RFAL',1,'1 - Qual',NULL,0,354),
(130,'Intheatre/Screening','Intheatre/Screening','RA',0,'2 - Quant','Intheatre/Screening',1,385),
(190,'Other','Other','OTHER',1,'4 - Other',NULL,0,354),
(90,'Offline quant (CLT quant / HUT )','Offline quant (CLT quant / HUT )','CLT',0,'2 - Quant','CLT',1,385),
(150,'Phone','Phone','TEL',1,'2 - Quant',NULL,0,385),
(20,'IDIs','IDIs','IDI',0,'1 - Qual','IDI',1,354),
(140,'Count','Count','COUNT',1,'2 - Quant',NULL,0,385),
(80,'Report/Analysis qual','Report/Analysis qual','DP QL',1,'1 - Qual',NULL,0,354),
(50,'TDIs','TDIs','TDI',0,'1 - Qual','TDI',1,354),
(120,'Intheatre','Intheatre','OWIT',1,'2 - Quant',NULL,0,385),
(0,'','CATI','CATI',1,'2 - Quant','CATI',1,385);
SET FOREIGN_KEY_CHECKS = 1;