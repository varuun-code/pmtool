SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_sample_source`;
INSERT INTO `ref_sample_source` (`libelle`, `sf_label`, `actif`, `ordre`) VALUES
('Client list','Client list',1,1),
('Client list exclude','Client list exclude',1,2),
('Database','Database',1,3),
('External','External',1,4),
('TBD','TBD',1,5),
('Not applicable','Not applicable',1,6);
SET FOREIGN_KEY_CHECKS = 1;