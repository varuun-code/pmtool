SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_room`;

INSERT INTO `ref_room` (`id`, `name`, `location_id`)
VALUES
	(1, 'Room 1', 1),
	(2, 'Room 2', 1);

SET FOREIGN_KEY_CHECKS = 1;