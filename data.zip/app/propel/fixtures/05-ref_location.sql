SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE `ref_location`;
INSERT INTO `ref_location` (id, libelle, sf_label) VALUES
(1,'National','National');
SET FOREIGN_KEY_CHECKS = 1;