<?php

use Propel\Generator\Manager\MigrationManager;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1551452348.
 * Generated on 2019-03-01 15:59:08 by pmtool
 */
class PropelMigration_1551452348
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

CREATE INDEX `sf_opportunity_ibfi_13` ON `sf_opportunity` (`platform_id`);

CREATE INDEX `sf_opportunity_ibfi_14` ON `sf_opportunity` (`specifics_id`);

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_13`
    FOREIGN KEY (`platform_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_14`
    FOREIGN KEY (`specifics_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `user`
  CHANGE `sf_id` `sf_id` VARCHAR(255) DEFAULT \'\' NOT NULL;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_13`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_14`;

DROP INDEX `sf_opportunity_ibfi_13` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_14` ON `sf_opportunity`;

ALTER TABLE `user`
  CHANGE `sf_id` `sf_id` VARCHAR(255) NOT NULL;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}