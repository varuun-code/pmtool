<?php

use Propel\Generator\Manager\MigrationManager;
use Propel\Runtime\Propel;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1545829698.
 * Generated on 2018-12-26 14:08:18 by root
 */
class PropelMigration_1545829698
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
        $con = Propel::getConnection();
        $query = '
SELECT `sf_opportunity`.`id` AS o_id, `sf_account`.`id` AS a_id
FROM `sf_opportunity`
LEFT JOIN `sf_account` ON `sf_opportunity`.`end_client_sf_id` = `sf_account`.`sf_id`
WHERE `end_client_sf_id` IS NOT NULL
';

        $stmnt = $con->prepare($query);
        $stmnt->execute();

        $queryUpdate = 'UPDATE `sf_opportunity` SET `end_client_id` = :end_client_id WHERE `id` = :o_id';

        $con->beginTransaction();
        while ($opportunity = $stmnt->fetch(PDO::FETCH_ASSOC)) {
            $stmntUpdate = $con->prepare($queryUpdate);
            $stmntUpdate->bindParam(':end_client_id', $opportunity['a_id'], PDO::PARAM_INT);
            $stmntUpdate->bindParam(':o_id', $opportunity['o_id'], PDO::PARAM_INT);
            $stmntUpdate->execute();
        }
        $con->commit();
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_1`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_10`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_2`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_3`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_4`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_5`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_7`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_8`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_9`;

DROP INDEX `sf_opportunity_ibfi_9` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_1` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_2` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_3` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_4` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_5` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_7` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_10` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity`;

ALTER TABLE `sf_opportunity`

  CHANGE `end_client` `end_client_sf_id` VARCHAR(255),

  ADD `opportunity_english_subject` VARCHAR(80) AFTER `opportunity_subject`,

  ADD `opportunity_name` VARCHAR(255) AFTER `opportunity_english_subject`,

  ADD `end_client_id` INTEGER AFTER `opportunity_name`,

  ADD `end_client_contact_id` INTEGER AFTER `end_client_sf_id`,

  ADD `end_client_contact_sf_id` VARCHAR(255) AFTER `end_client_contact_id`,

  ADD `closed_lost_reason_id` INTEGER AFTER `end_client_contact_sf_id`,

  ADD `bid_value` VARCHAR(255) AFTER `stage_name_id`,

  ADD `gqs_gms` TINYINT(1) AFTER `bid_value`,

  ADD `zendesk_ticket_id` VARCHAR(255) AFTER `gqs_gms`,

  ADD `zendesk` VARCHAR(255) AFTER `zendesk_ticket_id`,

  ADD `include_account_manager` TINYINT(1) AFTER `zendesk`,

  ADD `include_opp_owner` TINYINT(1) AFTER `include_account_manager`,

  ADD `report_end_client` TINYINT(1) AFTER `include_opp_owner`,

  ADD `apply_discount` TINYINT(1) AFTER `report_end_client`,

  ADD `platform_id` INTEGER AFTER `apply_discount`,

  ADD `specifics_id` INTEGER AFTER `platform_id`,

  ADD `response_time` VARCHAR(255) AFTER `specifics_id`;

CREATE INDEX `sf_opportunity_ibfi_9` ON `sf_opportunity` (`end_client_contact_id`);

CREATE INDEX `sf_opportunity_ibfi_1` ON `sf_opportunity` (`account_id`);

CREATE INDEX `sf_opportunity_ibfi_2` ON `sf_opportunity` (`contact_id`);

CREATE INDEX `sf_opportunity_ibfi_3` ON `sf_opportunity` (`client_type_id`);

CREATE INDEX `sf_opportunity_ibfi_4` ON `sf_opportunity` (`us_global_qual_gms_id`);

CREATE INDEX `sf_opportunity_ibfi_5` ON `sf_opportunity` (`industry_id`);

CREATE INDEX `sf_opportunity_ibfi_7` ON `sf_opportunity` (`currency_iso_code_id`);

CREATE INDEX `sf_opportunity_ibfi_10` ON `sf_opportunity` (`closed_lost_reason_id`);

CREATE INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity` (`end_client_id`);

CREATE INDEX `sf_opportunity_ibfi_6` ON `sf_opportunity` (`job_qualification_id`);

CREATE INDEX `sf_opportunity_ibfi_11` ON `sf_opportunity` (`stage_name_id`);

CREATE INDEX `sf_opportunity_ibfi_12` ON `sf_opportunity` (`pmtool_created_by_id`);

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_1`
    FOREIGN KEY (`account_id`)
    REFERENCES `sf_account` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_10`
    FOREIGN KEY (`closed_lost_reason_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_2`
    FOREIGN KEY (`contact_id`)
    REFERENCES `sf_contact` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_3`
    FOREIGN KEY (`client_type_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_4`
    FOREIGN KEY (`us_global_qual_gms_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_5`
    FOREIGN KEY (`industry_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_7`
    FOREIGN KEY (`currency_iso_code_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_8`
    FOREIGN KEY (`end_client_id`)
    REFERENCES `sf_account` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_9`
    FOREIGN KEY (`end_client_contact_id`)
    REFERENCES `sf_contact` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_6`
    FOREIGN KEY (`job_qualification_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_11`
    FOREIGN KEY (`stage_name_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_12`
    FOREIGN KEY (`pmtool_created_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_6`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_11`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_12`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_1`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_10`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_2`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_3`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_4`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_5`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_7`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_8`;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_9`;

DROP INDEX `sf_opportunity_ibfi_6` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_11` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_12` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_9` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_1` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_2` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_3` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_4` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_5` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_7` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_10` ON `sf_opportunity`;

DROP INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity`;

ALTER TABLE `sf_opportunity`

  CHANGE `end_client_sf_id` `end_client` VARCHAR(255),

  DROP `opportunity_english_subject`,

  DROP `end_client_id`,

  DROP `opportunity_name`,

  DROP `end_client_contact_id`,

  DROP `end_client_contact_sf_id`,

  DROP `closed_lost_reason_id`,

  DROP `bid_value`,

  DROP `gqs_gms`,

  DROP `zendesk_ticket_id`,

  DROP `zendesk`,

  DROP `include_account_manager`,

  DROP `include_opp_owner`,

  DROP `report_end_client`,

  DROP `apply_discount`,

  DROP `platform_id`,

  DROP `specifics_id`,

  DROP `response_time`;

CREATE INDEX `sf_opportunity_ibfi_9` ON `sf_opportunity` (`account_id`);

CREATE INDEX `sf_opportunity_ibfi_1` ON `sf_opportunity` (`client_type_id`);

CREATE INDEX `sf_opportunity_ibfi_2` ON `sf_opportunity` (`us_global_qual_gms_id`);

CREATE INDEX `sf_opportunity_ibfi_3` ON `sf_opportunity` (`industry_id`);

CREATE INDEX `sf_opportunity_ibfi_4` ON `sf_opportunity` (`job_qualification_id`);

CREATE INDEX `sf_opportunity_ibfi_5` ON `sf_opportunity` (`currency_iso_code_id`);

CREATE INDEX `sf_opportunity_ibfi_7` ON `sf_opportunity` (`stage_name_id`);

CREATE INDEX `sf_opportunity_ibfi_10` ON `sf_opportunity` (`contact_id`);

CREATE INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity` (`pmtool_created_by_id`);

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_1`
    FOREIGN KEY (`client_type_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_10`
    FOREIGN KEY (`contact_id`)
    REFERENCES `sf_contact` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_2`
    FOREIGN KEY (`us_global_qual_gms_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_3`
    FOREIGN KEY (`industry_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_4`
    FOREIGN KEY (`job_qualification_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_5`
    FOREIGN KEY (`currency_iso_code_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_7`
    FOREIGN KEY (`stage_name_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_8`
    FOREIGN KEY (`pmtool_created_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_9`
    FOREIGN KEY (`account_id`)
    REFERENCES `sf_account` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}
