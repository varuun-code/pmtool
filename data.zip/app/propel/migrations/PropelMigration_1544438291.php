<?php

use Propel\Generator\Manager\MigrationManager;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1544438291.
 * Generated on 2018-12-10 11:38:11 by root
 */
class PropelMigration_1544438291
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity`

  ADD `pmtool_created_by_id` INTEGER AFTER `pmtool_updated`;

CREATE INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity` (`pmtool_created_by_id`);

ALTER TABLE `sf_opportunity` ADD CONSTRAINT `sf_opportunity_ibfk_8`
    FOREIGN KEY (`pmtool_created_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity` DROP FOREIGN KEY `sf_opportunity_ibfk_8`;

DROP INDEX `sf_opportunity_ibfi_8` ON `sf_opportunity`;

ALTER TABLE `sf_opportunity`

  DROP `pmtool_created_by_id`;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}