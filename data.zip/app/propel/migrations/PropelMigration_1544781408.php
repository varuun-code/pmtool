<?php

use Propel\Generator\Manager\MigrationManager;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1544781408.
 * Generated on 2018-12-14 10:56:48 by root
 */
class PropelMigration_1544781408
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE `sf_opportunity_bid`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `opportunity_id` INTEGER NOT NULL,
    `is_preferred` TINYINT(1) DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_ibfi_1` (`opportunity_id`),
    INDEX `sf_opportunity_bid_ibfi_2` (`created_by_id`),
    INDEX `sf_opportunity_bid_ibfi_3` (`updated_by_id`),
    CONSTRAINT `sf_opportunity_bid_ibfk_1`
        FOREIGN KEY (`opportunity_id`)
        REFERENCES `sf_opportunity` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_ibfk_2`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_ibfk_3`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `sf_opportunity_bid_job`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `bid_id` INTEGER NOT NULL,
    `location_id` INTEGER NOT NULL,
    `on_site_recruits` DOUBLE DEFAULT 0,
    `off_site_recruits` DOUBLE DEFAULT 0,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_ibfi_1` (`bid_id`),
    INDEX `sf_opportunity_bid_job_ibfi_2` (`location_id`),
    INDEX `sf_opportunity_bid_job_ibfi_3` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_ibfi_4` (`updated_by_id`),
    CONSTRAINT `sf_opportunity_bid_job_ibfk_1`
        FOREIGN KEY (`bid_id`)
        REFERENCES `sf_opportunity_bid` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_2`
        FOREIGN KEY (`location_id`)
        REFERENCES `ref_location` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_3`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_ibfk_4`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE `sf_opportunity_bid_job_item`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `bid_job_id` INTEGER NOT NULL,
    `category_id` INTEGER COMMENT \'Category / Equipment\',
    `section_id` INTEGER COMMENT \'Category prestation\',
    `title` VARCHAR(255) NOT NULL,
    `vendor_id` INTEGER(10) COMMENT \'Fournisseur\',
    `resp_location` INTEGER,
    `methodology_id` INTEGER,
    `date` DATE,
    `selling_qty` INTEGER,
    `selling_unit_price` DECIMAL(8,2),
    `selling_price` DECIMAL(8,2),
    `cost_qty` INTEGER,
    `cost_unit_price` DECIMAL(8,2),
    `cost_price` DECIMAL(8,2),
    `discount_comment` TEXT,
    `discount_percent` DECIMAL(8,2),
    `discount_exclude` VARCHAR(255),
    `pm_comment` TEXT,
    `created_by_id` INTEGER,
    `updated_by_id` INTEGER,
    `created_at` DATETIME,
    `updated_at` DATETIME,
    PRIMARY KEY (`id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_1` (`section_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_2` (`vendor_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_3` (`created_by_id`),
    INDEX `sf_opportunity_bid_job_item_ibfi_4` (`updated_by_id`),
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_1`
        FOREIGN KEY (`section_id`)
        REFERENCES `categorie_prestation` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_2`
        FOREIGN KEY (`vendor_id`)
        REFERENCES `fournisseur` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_3`
        FOREIGN KEY (`created_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `sf_opportunity_bid_job_item_ibfk_4`
        FOREIGN KEY (`updated_by_id`)
        REFERENCES `user` (`id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `sf_opportunity_bid`;

DROP TABLE IF EXISTS `sf_opportunity_bid_job`;

DROP TABLE IF EXISTS `sf_opportunity_bid_job_item`;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}
