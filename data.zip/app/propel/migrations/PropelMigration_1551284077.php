<?php

use Propel\Generator\Manager\MigrationManager;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1551284077.
 * Generated on 2019-02-27 17:14:37 by pmtool
 */
class PropelMigration_1551284077
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity_bid`

  ADD `label` VARCHAR(255) DEFAULT \'\' AFTER `opportunity_id`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_1`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_2`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_3`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_4`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_1` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_2` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_3` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_4` ON `sf_opportunity_bid_job_item`;

ALTER TABLE `sf_opportunity_bid_job_item`

  CHANGE `resp_location` `resp_location_id` INTEGER,

  CHANGE `discount_exclude` `discount_exclude` TINYINT(1) DEFAULT 0,

  ADD `cost_rate` DECIMAL(8,2) AFTER `cost_unit_price`,

  ADD `order` INTEGER NOT NULL AFTER `pm_comment`,

  ADD `group` INTEGER DEFAULT 0 AFTER `order`;

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_1` ON `sf_opportunity_bid_job_item` (`bid_job_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_2` ON `sf_opportunity_bid_job_item` (`category_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_3` ON `sf_opportunity_bid_job_item` (`section_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_4` ON `sf_opportunity_bid_job_item` (`vendor_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_5` ON `sf_opportunity_bid_job_item` (`resp_location_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_6` ON `sf_opportunity_bid_job_item` (`methodology_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_7` ON `sf_opportunity_bid_job_item` (`created_by_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_8` ON `sf_opportunity_bid_job_item` (`updated_by_id`);

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_1`
    FOREIGN KEY (`bid_job_id`)
    REFERENCES `sf_opportunity_bid_job` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_2`
    FOREIGN KEY (`category_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_3`
    FOREIGN KEY (`section_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_4`
    FOREIGN KEY (`vendor_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_5`
    FOREIGN KEY (`resp_location_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_6`
    FOREIGN KEY (`methodology_id`)
    REFERENCES `sf_ref_salesforce` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_7`
    FOREIGN KEY (`created_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_8`
    FOREIGN KEY (`updated_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `sf_opportunity_bid`

  DROP `label`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_5`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_6`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_7`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_8`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_1`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_2`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_3`;

ALTER TABLE `sf_opportunity_bid_job_item` DROP FOREIGN KEY `sf_opportunity_bid_job_item_ibfk_4`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_5` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_6` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_7` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_8` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_1` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_2` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_3` ON `sf_opportunity_bid_job_item`;

DROP INDEX `sf_opportunity_bid_job_item_ibfi_4` ON `sf_opportunity_bid_job_item`;

ALTER TABLE `sf_opportunity_bid_job_item`

  CHANGE `resp_location_id` `resp_location` INTEGER,

  CHANGE `discount_exclude` `discount_exclude` VARCHAR(255),

  DROP `cost_rate`,

  DROP `order`,

  DROP `group`;

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_1` ON `sf_opportunity_bid_job_item` (`section_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_2` ON `sf_opportunity_bid_job_item` (`vendor_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_3` ON `sf_opportunity_bid_job_item` (`created_by_id`);

CREATE INDEX `sf_opportunity_bid_job_item_ibfi_4` ON `sf_opportunity_bid_job_item` (`updated_by_id`);

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_1`
    FOREIGN KEY (`section_id`)
    REFERENCES `categorie_prestation` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_2`
    FOREIGN KEY (`vendor_id`)
    REFERENCES `fournisseur` (`id`)
    ON UPDATE CASCADE
    ON DELETE SET NULL;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_3`
    FOREIGN KEY (`created_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE;

ALTER TABLE `sf_opportunity_bid_job_item` ADD CONSTRAINT `sf_opportunity_bid_job_item_ibfk_4`
    FOREIGN KEY (`updated_by_id`)
    REFERENCES `user` (`id`)
    ON UPDATE CASCADE
    ON DELETE CASCADE;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}