<?php

use Propel\Generator\Manager\MigrationManager;

/**
 * Data object containing the SQL and PHP code to migrate the database
 * up to version 1542635208.
 * Generated on 2018-11-19 14:46:48 by pyguerder
 */
class PropelMigration_1542635208
{
    public $comment = '';

    public function preUp(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postUp(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    public function preDown(MigrationManager $manager)
    {
        // add the pre-migration code here
    }

    public function postDown(MigrationManager $manager)
    {
        // add the post-migration code here
    }

    /**
     * Get the SQL statements for the Up migration
     *
     * @return array list of the SQL strings to execute for the Up migration
     *               the keys being the datasources
     */
    public function getUpSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `societe`;

DROP TABLE IF EXISTS `societe_contact`;

DROP INDEX `id_societe` ON `calcul`;

ALTER TABLE `calcul`

  DROP `id_societe`;

DROP INDEX `id_client` ON `etude`;

ALTER TABLE `etude`

  DROP `id_societe`;

DROP INDEX `id_client` ON `etude_master`;

ALTER TABLE `etude_master`

  DROP `id_societe`;

ALTER TABLE `facture`

  DROP `id_societe_detail`;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

    /**
     * Get the SQL statements for the Down migration
     *
     * @return array list of the SQL strings to execute for the Down migration
     *               the keys being the datasources
     */
    public function getDownSQL()
    {
        return array (
  'default' => '
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `calcul`

  ADD `id_societe` INTEGER(8) AFTER `annee`;

CREATE INDEX `id_societe` ON `calcul` (`id_societe`);

ALTER TABLE `etude`

  ADD `id_societe` INTEGER(8) AFTER `annee`;

CREATE INDEX `id_client` ON `etude` (`id_societe`);

ALTER TABLE `etude_master`

  ADD `id_societe` INTEGER(8) AFTER `annee`;

CREATE INDEX `id_client` ON `etude_master` (`id_societe`);

ALTER TABLE `facture`

  ADD `id_societe_detail` INTEGER(8) AFTER `montant`;

CREATE TABLE `societe`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `account_id` INTEGER,
    `societe` VARCHAR(255) NOT NULL,
    `societe_short` VARCHAR(50) NOT NULL,
    `type` VARCHAR(1) DEFAULT \'C\' NOT NULL,
    `id_pays` INTEGER(8) NOT NULL,
    `tva` VARCHAR(20) NOT NULL,
    `type_remise` VARCHAR(2) NOT NULL,
    `remise` DECIMAL(4,2) NOT NULL,
    `number` VARCHAR(50) NOT NULL,
    `information` TEXT NOT NULL,
    PRIMARY KEY (`id`),
    INDEX `societe` (`societe`),
    INDEX `id_pays` (`id_pays`),
    INDEX `number` (`number`)
) ENGINE=InnoDB;

CREATE TABLE `societe_contact`
(
    `id` INTEGER(8) NOT NULL AUTO_INCREMENT,
    `id_societe` INTEGER(8),
    `type_contact` VARCHAR(1) NOT NULL,
    `nom` VARCHAR(30) NOT NULL,
    `prenom` VARCHAR(30) NOT NULL,
    `mail` VARCHAR(100) NOT NULL,
    `adresse` TEXT NOT NULL,
    `telephone` VARCHAR(50) NOT NULL,
    `fax` VARCHAR(50) NOT NULL,
    `departement` VARCHAR(50) NOT NULL,
    `id_old` INTEGER(8) NOT NULL,
    `contact_id` INTEGER,
    `account_id` INTEGER,
    PRIMARY KEY (`id`),
    INDEX `id_old` (`id_old`),
    INDEX `societe_contact_fi_38c569` (`account_id`),
    INDEX `societe_contact_ibfi_1` (`id_societe`),
    CONSTRAINT `societe_contact_fk_38c569`
        FOREIGN KEY (`account_id`)
        REFERENCES `sf_account` (`id`)
        ON UPDATE CASCADE
        ON DELETE SET NULL,
    CONSTRAINT `societe_contact_ibfk_1`
        FOREIGN KEY (`id_societe`)
        REFERENCES `societe` (`id`)
) ENGINE=InnoDB;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
',
);
    }

}