<?php

//setlocale(LC_TIME, 'fr_FR.utf8');

// Country & currency for this instance
$config['instance'] = 'PMTOOL_US'; // Consumed / Schmiedl / PMTOOL_ES / PMTOOL_UK
$config['currency'] = '$';

?>
