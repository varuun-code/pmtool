<?php

namespace Security;

use KnpU\OAuth2ClientBundle\Client\ClientRegistry;
use KnpU\OAuth2ClientBundle\Client\OAuth2ClientInterface;
use KnpU\OAuth2ClientBundle\Security\Authenticator\SocialAuthenticator;
use League\OAuth2\Client\Token\AccessToken;
use Manager\MailManager;
use Model\User;
use Model\UserQuery;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\User\UserProviderInterface;

class TwentyTwentyIdentityAuthenticator extends SocialAuthenticator
{
    const ID_TOKEN = 'id_token';
    const CLIENT_NAME = '2020_identity';

    private $clientRegistry;
    private $mailManager;
    private $oauth2client;
    private $router;
    private $session;

    public function __construct(ClientRegistry $clientRegistry, OAuth2ClientInterface $oauth2client,
        RouterInterface $router, SessionInterface $session, MailManager $mailManager)
    {
        $this->clientRegistry = $clientRegistry;
        $this->mailManager = $mailManager;
        $this->oauth2client = $oauth2client;
        $this->router = $router;
        $this->session = $session;
    }

    public function supports(Request $request)
    {
        // continue ONLY if the current ROUTE matches the check ROUTE
        return 'connect_2020_check' === $request->attributes->get('_route');
    }

    public function getCredentials(Request $request)
    {
        return $this->fetchAccessToken($this->oauth2client);
    }

    public function getUser($credentials, UserProviderInterface $userProvider)
    {
        /** @var AccessToken $credentials */
        $token = $credentials->getToken();

        $values = $credentials->getValues();
        $this->session->set(self::ID_TOKEN, $values['id_token'] ?? '');

        // decode JWT; for signature verification, use a real lib
        $data = json_decode(base64_decode(str_replace('_', '/', str_replace('-', '+', explode('.', $token)[1]))), true);
        $email = $data['email'] ?? '';

        $existingUser = $email ? UserQuery::create()->findOneByMail($email) : null;

        if ($existingUser) {
            $status = $existingUser->getStatut();
            if (User::STATUS_ACTIVE === $status) {
                return $existingUser;
            }

            if (User::STATUS_EXPIRED === $status) {
                throw new AuthenticationException('Your account has been disabled. Please contact the administrator.');
            }

            if (User::STATUS_LOCKED === $status) {
                throw new AuthenticationException('Your account is locked. Please contact the administrator.');
            }
        }

        throw new AuthenticationException('This user does not exist. Please contact the administrator.');
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey)
    {
        $targetUrl = $this->router->generate('default');

        return new RedirectResponse($targetUrl);
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    {
        /** @var Session $session */
        $session = $this->session;
        $session->getFlashBag()->add('danger', $exception->getMessage());
        $targetUrl = $this->router->generate('main_login');

        return new RedirectResponse($targetUrl);
    }

    /**
     * Called when authentication is needed, but it's not sent.
     * This redirects to the 'login'.
     */
    public function start(Request $request, AuthenticationException $authException = null)
    {
        $url = $this->clientRegistry->getClient(self::CLIENT_NAME)->getOAuth2Provider()->getAuthorizationUrl();

        return new RedirectResponse($url, Response::HTTP_TEMPORARY_REDIRECT);
    }
}
