<?php

namespace Security;

use Model\UserLogQuery;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Logout\LogoutSuccessHandlerInterface;

class LogoutListener implements LogoutSuccessHandlerInterface
{
    private $oauth2_logout_url;
    private $urlGenerator;

    public function __construct(UrlGeneratorInterface $urlGenerator, string $oauth2_logout_url)
    {
        $this->oauth2_logout_url = $oauth2_logout_url;
        $this->urlGenerator = $urlGenerator;
    }

    public function onLogoutSuccess(Request $request): RedirectResponse
    {
        $session = $request->getSession();
        $loginLogout = UserLogQuery::Create()
                       ->filterBySessionValue($session->getId())->findOne();
        if ($loginLogout) {
            $dateTime = new \DateTime();
            $loginLogout->setLogOutAt($dateTime);
            $loginLogout->save();
        }
        $signout_endpoint = $this->oauth2_logout_url;
        $signout_endpoint .= (false === strpos($signout_endpoint, '?') ? '?' : '&').http_build_query([
            'id_token_hint' => $session->get(TwentyTwentyIdentityAuthenticator::ID_TOKEN, ''),
            'post_logout_redirect_uri' => $this->urlGenerator->generate('main_login', [], UrlGeneratorInterface::ABSOLUTE_URL),
        ]);

        $session->invalidate();

        return new RedirectResponse($signout_endpoint);
    }
}
