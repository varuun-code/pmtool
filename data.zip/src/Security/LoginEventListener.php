<?php

namespace Security;

use Model\User;
use Model\UserLog;
use Symfony\Component\HttpFoundation\Session\SessionInterface;
use Symfony\Component\Security\Core\Security;

class LoginEventListener
{
    private $session;
    private $security;

    public function __construct(SessionInterface $session, Security $security)
    {
        $this->session = $session;
        $this->security = $security;
    }

    public function onSecurityInteractiveLogin()
    {
        $user = $this->security->getUser();
        $userId = $user instanceof User ? $user->getId() : null;

        $loginLogoutDetails = new UserLog();
        $loginLogoutDetails->setUserId($userId);
        $loginLogoutDetails->setSessionValue($this->session->getId());
        $dateTime = new \DateTime();
        $loginLogoutDetails->setLoginAt($dateTime);
        $loginLogoutDetails->save();
    }
}
