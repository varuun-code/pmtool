<?php

namespace SalesForceBundle\Tests\Controller;

use DateTime;
use Model\AccountQuery;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\ContactQuery;
use Model\Etape;
use Model\Etude;
use Model\Event;
use Model\EventQuery;
use Model\IndustryQuery;
use Model\Job;
use Model\JobItem;
use Model\JobItemQuery;
use Model\JobQuery;
use Model\LocationQuery;
use Model\OpportunityQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoomQuery;
use Model\RefSalesForce;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Propel;
use SoapClient;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class DefaultControllerTest extends WebTestCase
{
    const FUNCTIONS = [
        'createOpportunityResponse createOpportunity(createOpportunity $parameters)',
        'updateOpportunityResponse updateOpportunity(updateOpportunity $parameters)',
        'getUpdatedOpportunitiesResponse getUpdatedOpportunities(getUpdatedOpportunities $parameters)',
        'createAccountResponse createAccount(createAccount $parameters)',
        'updateAccountResponse updateAccount(updateAccount $parameters)',
        'deleteAccountResponse deleteAccount(deleteAccount $parameters)',
        'void mergeAccounts(mergeAccounts $parameters)',
        'getNewRecruitmentsResponse getNewRecruitments(getNewRecruitments $parameters)',
        'getUpdatedAccountsResponse getUpdatedAccounts(getUpdatedAccounts $parameters)',
        'getUpdatedEventsResponse getUpdatedEvents(getUpdatedEvents $parameters)',
        'createContactResponse createContact(createContact $parameters)',
        'updateContactResponse updateContact(updateContact $parameters)',
        'deleteContactResponse deleteContact(deleteContact $parameters)',
        'void mergeContacts(mergeContacts $parameters)',
        'getUpdatedContactsResponse getUpdatedContacts(getUpdatedContacts $parameters)',
        'getNewContactsResponse getNewContacts(getNewContacts $parameters)',
        'getNewEventsResponse getNewEvents(getNewEvents $parameters)',
        'getNewJobItemsResponse getNewJobItems(getNewJobItems $parameters)',
        'getNewJobsResponse getNewJobs(getNewJobs $parameters)',
        'getNewOpportunitiesResponse getNewOpportunities(getNewOpportunities $parameters)',
        'getUpdatedRecruitmentsResponse getUpdatedRecruitments(getUpdatedRecruitments $parameters)',
        'getUpdatedJobsResponse getUpdatedJobs(getUpdatedJobs $parameters)',
        'updateJobResponse updateJob(updateJob $parameters)',
        'updateJobItemResponse updateJobItem(updateJobItem $parameters)',
        'updateRecruitmentResponse updateRecruitment(updateRecruitment $parameters)',
        'updateEventResponse updateEvent(updateEvent $parameters)',
    ];
    const TYPES = ['Account', 'Contact', 'Event', 'Job', 'JobItem', 'Opportunity'];

    private $client;
    private $expiration;
    private $types;
    private $soapClient;
    private $wsdl;

    protected function setUp(): void
    {
        $this->client = $this->client ?? static::createClient(['debug' => true]);
        $domain = $this->client->getContainer()->getParameter('router.request_context.host');
        $protocol = $this->client->getContainer()->getParameter('router.request_context.scheme');
        $this->expiration = $this->client->getContainer()->getParameter('api_exposure_expiration');
        $this->wsdl = "$protocol://$domain/api/salesforce/soap?wsdl";
        $this->soapClient = $this->soapClient ?? new SoapClient($this->wsdl, ['trace' => 1]);

        Propel::closeConnections();
    }

    public function testWSDL()
    {
        $this->client->request('GET', $this->wsdl);
        $response = $this->client->getResponse();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertEquals(self::FUNCTIONS, $this->soapClient->__getFunctions());
    }

    private function assertRespectsDTO($result, $type)
    {
        $this->assertEqualsCanonicalizing(array_keys($result[0] ?? $result), $this->getTypes()[$type]);
    }

    private function getTypes()
    {
        if ($this->types) {
            return $this->types;
        }

        $result = [];
        foreach ($this->soapClient->__getTypes() as $type) {
            $matches = null;
            if (preg_match('/^struct./', $type)) {
                preg_match('/struct (\w+)/', $type, $matches);
                $name = $matches[1];
                $attributes = [];
                if (in_array($name, self::TYPES)) {
                    $lines = array_slice(explode("\n", $type), 1, -1);
                    foreach ($lines as $line) {
                        $line = preg_match('/ (\w+) (\w+);/', $line, $matches);
                        // $subtype = array_values(preg_grep("/^\w+ $matches[1]/", $types));
                        $attributes[] = $matches[2];
                    }
                    $result[$name] = $attributes;
                }
            }
        }
        $this->types = $result;
        $this->assertCount(6, $result);

        return $result;
    }

    private function makeTestFunction($functionName, $data = [])
    {
        $result = new \stdClass();
        try {
            $result = $this->soapClient->__soapCall($functionName, $data);
            if (!$result || !property_exists($result, $functionName.'Result')) {
                echo 'Req: '.$this->soapClient->__getLastRequest()."\nResp: ".$this->soapClient->__getLastResponse()."\n";
                echo 'Logs: '.shell_exec('tail var/logs/api_scribe*');
                echo 'Headers: '.$this->soapClient->__getLastResponseHeaders()."\n";
                $result = new \stdClass();
            }
        } catch (\Exception $e) {
            echo 'Exception... '.$e->getMessage()."\nReq: ".$this->soapClient->__getLastRequest()."\nResp: ".$this->soapClient->__getLastResponse()."\nHeaders: ".$this->soapClient->__getLastResponseHeaders();
            var_dump($result);
        } catch (\SoapFault $e) {
            echo 'SoapFault... '.$e->getMessage()."\nReq: ".$this->soapClient->__getLastRequest()."\nResp: ".$this->soapClient->__getLastResponse()."\nHeaders: ".$this->soapClient->__getLastResponseHeaders();
            var_dump($result);
        }
        $type = $functionName.'Result';
        $this->assertObjectHasAttribute($type, $result);

        $response = $this->soapClient->__getLastResponse();
        $response = preg_replace("/(<\/?)(\w+):([^>]*>)/", '$1$2$3', $response);
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $response);
        $xml = new \SimpleXMLElement($clean_xml, LIBXML_NOCDATA);
        $body = $xml->xpath('//Body')[0];
        $array = json_decode(json_encode((array) $body), true);
        $result = $array['ns1'.$functionName.'Response'][$type];

        return is_string($result) ? $result : (is_array($result) ? current($result) : null);
    }

    private function createJob(string $sfId = '')
    {
        $etude = $this->createStudy();
        $location = LocationQuery::create()->findOne();

        return (new Job())->setEtude($etude)->setJobLocation($location)->setSfIgnore(false)->setPmId(1)
            ->setJobSfId($sfId ?: null)->setEtude($etude)->setAcctChecked(true);
    }

    private function createEvent(Job $job, $samsId)
    {
        $refRoom = RefRoomQuery::create()->findOne();
        $status = RefEventStatusQuery::create()->findOne();

        return (new Event())->setPmtoolUpdated(true)->setSamsEventId($samsId)->setJob($job)->setRefEventStatus($status)
            ->setStartDateTime(new DateTime())->setEndDateTime(new DateTime())->setRefRoom($refRoom);
    }

    private function createStudy()
    {
        $industry = IndustryQuery::create()->findOne();
        $val = 'test'.uniqid();
        $date = new \DateTime();

        return (new Etude())->setNumeroEtude($val)->setReferenceClient($val)->setTheme($val)
            ->setDateFin($date)->setIndustry($industry)->setIdEtape(Etape::INVOICED)
            ->setDateDebut($date)->setPeriodeCutoff($date->format('Y-m'));
    }

    public function testCreateAndDeleteAccount()
    {
        $id = uniqid();
        $result = $this->makeTestFunction('createAccount', ['parameters' => ['sf_id' => $id, 'account' => [
            'Id' => $id,
            'High_Alert__c' => 'false',
            'sponsor_2020' => 'test1',
            'aspen_finn_sponsor' => 'test2',
            'accounting_email' => 'test3',
            'accounting_attn' => 'test4',
            'pod_qual' => 'test5',
            'pod_quant' => 'test6',
            'sub_types' => 'test7;test8',
            'quant_discount_program' => 'program',
        ]]]);
        $this->assertIsNumeric($result);
        $this->makeTestFunction('deleteAccount', ['parameters' => ['pmtool_id' => $result]]);
    }

    public function testCreateAndDeleteContact()
    {
        $id = uniqid();
        $result = $this->makeTestFunction('createContact', ['parameters' => ['sf_id' => $id, 'contact' => [
            'Id' => $id,
            'marketing_audiences' => 'test1;test2',
        ]]]);
        $this->assertIsNumeric($result);
        $this->makeTestFunction('deleteContact', ['parameters' => ['pmtool_id' => $result]]);
    }

    /**
     * Checks that invalid data still produce a createOpportunityResult.
     */
    public function testCreateOpportunityError()
    {
        $id = uniqid();
        $result = $this->makeTestFunction('createOpportunity', ['parameters' => ['sf_id' => $id, 'opportunity' => ['Id' => $id, 'Industry__c' => 'test']]]);
        $this->assertStringContainsString('is not valid', $result);
    }

    public function testCreateOpportunity()
    {
        $id = uniqid();
        $result = $this->makeTestFunction('createOpportunity', [
            'parameters' => [
                'sf_id' => $id,
                'opportunity' => [
                    'Id' => $id,
                    'opportunity_owner' => 'test',
                    'specialty_sales_rep' => 'test',
                ],
            ],
        ]);
//         echo $this->soapClient->__getLastResponse()."\n\n".$this->soapClient->__getLastResponseHeaders();
        $this->assertIsNumeric($result);
    }

    public function testUpdateEvent()
    {
        $event = EventQuery::create()->filterBySamsEventId('', Criteria::NOT_EQUAL)
            ->filterByJobId(null, Criteria::ISNOTNULL)->findOneOrCreate();
        if ($event->isNew()) {
            $job = $this->createJob();
            $event->setJob($job)->setSamsEventId(uniqid())->save();
            $job->save();
        }

        $result = $this->makeTestFunction('updateEvent', ['parameters' => ['id' => $event->getId(), 'event' => [
            'sams_event_id' => $event->getSamsEventId(),
            'all_day_event' => true,
            'archived' => true,
            'assigned_to' => 'test',
            'cancelled' => true,
            'created_date' => '2013-09-29T18:46:19',
            'start_date_time' => '2014-09-29T18:46:19',
            'end_date_time' => '2015-09-29T18:46:19',
            'event_sub_type' => 'abc',
            'record_type' => 'def',
            'recurring_event' => true,
            'is_deleted' => true,
            'is_deleted_c' => true,
            'reminder_set' => true,
            'created_by_sf_id' => 'test',
            'location_c' => 'National',
            'event_methodology' => 'Internet',
            'status' => 'Closed',
            'job_sf_id' => $event->getJob()->getJobSfId(),
            'room' => 'Room 1',
        ]]]);
//         echo $this->soapClient->__getLastResponse()."\n\n".$this->soapClient->__getLastResponseHeaders();
        $this->assertEquals('success', $result);
    }

    /**
     * This is to ease debugging (unskip it and uncomment the end).
     */
    public function testCreateOpportunityFull()
    {
        $id = uniqid();
        $result = $this->makeTestFunction('createOpportunity', ['parameters' => ['sf_id' => $id, 'opportunity' => [
            'Id' => $id,
            'N_Sample_Size__c' => '0',
            'AccountId' => '0011g00000d0nSNAAY',
            'ContactId' => '0031g00000MYwAZAA1',
            'account_id' => '18551',
            'contact_id' => '55945',
            'Job_created_Date' => '',
            'BidNumber__c' => '----------',
            'Bid_Revenue__c' => '500',
            'Bid_Number__c' => 'Bid10-0344111',
            'Client_Bid_Number__c' => 'client bid number',
            'Project_Number__c' => 'test client project number',
            'Client_Type' => 'Qualitiative – existing clients',
            'CloseDate' => '2019-07-11T11:26:08.000000+02:00',
            'opportunity_owner' => '005a000000AtlTi',
            'CreatedDate' => '2019-04-15T11:29:01',
            'US_Global_Qual_GMS__c' => '',
            'incidence_rate' => '10',
            'nb_of_survey' => '11',
            'programming_complexity' => 'High',
            'Industry__c' => 'Healthcare',
            'Job_Qualification__c' => 'Qual',
            'LOI_Option_1__c' => '0',
            'LOI_Option_2__c' => '0',
            'Max_IR__c' => '0',
            'Min_IR__c' => '0',
            'Notes_or_COmments__c' => 'test comment US',
            'Account_Coordinator__c' => 'test opp coordinator',
            'CurrencyIsoCode' => '',
            'Opportunity_Subject__c' => 'test opp from PM-Tool US',
            'OpportunityEnglishSubject' => '',
            'OpportunityName' => 'PMTOOL-OPPTY-6',
            'end_client_id' => '301',
            'end_client_sf_id' => '001a000001VsTMIAA3',
            'end_client_contact_id' => '62',
            'EndClientContactId' => '003a000002R8BnzAAF',
            'Other_Location__c' => 'test other location US',
            'probability' => '20',
            'Proposed_N__c' => '0',
            'Rebid__c' => '0',
            'StageName' => 'Bid',
            'BidValue' => '300',
            'GqsGms' => '1',
            'ZendeskTicketId' => '',
            'Zendesk' => '0',
            'IncludeAccountManager' => 'false',
            'IncludeOppOwner' => 'false',
            'ReportEndClient' => '0',
            'ApplyDiscount' => '1',
            'PlatformId' => '',
            'SpecificsId' => '',
            'ResponseTime' => '2',
            'api_created_date' => '2019-04-12',
            'api_updated_date' => '2019-04-12',
            'pmtool_created_date' => '',
            'pmtool_updated_date' => '',
            'pmtool_updated' => '0',
            'created_by_sf_id' => 'test',
            'account_manager' => '',
            'Services__c' => 'Project Management;Recruiting;Facial Coding',
            'Sector__c' => 'Consumer',
            'methodologies' => 'Focus Group;TDI',
            'Location__c' => 'France National;Bastille',
            'end_client_rep_sf_id' => '003a000002R6epYAAR',
            'specialty_sales_rep' => 'test',
        ]]]);
        // echo $this->soapClient->__getLastResponse()."\n\n".$this->soapClient->__getLastResponseHeaders();
        $this->assertIsNumeric($result);
    }

    public function testGetNewOpportunities()
    {
        $opportunity = OpportunityQuery::create()
            ->filterBySfIgnore(false)
            ->filterBySfId(null, Criteria::ISNULL)
            ->filterByApiUpdatedDate(new \DateTime($this->expiration), Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->findOneOrCreate();
        if ($opportunity->isNew()) {
            $opportunity->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('getNewOpportunities');
        $this->assertNotEquals(0, $result);
        $this->assertRespectsDTO($result, 'Opportunity');
    }

    public function testGetUpdatedJobs()
    {
        $job = JobQuery::create()->filterByJobSfId(null, Criteria::ISNOTNULL)->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid())->setJobSfId(uniqid());
        }
        $job->setPmtoolUpdated(true)->save();
        $result = $this->makeTestFunction('getUpdatedJobs');
        $this->assertGreaterThanOrEqual(1, count($result));
    }

    public function testGetUpdatedOpportunities()
    {
        $this->makeTestFunction('getUpdatedOpportunities');
    }

    public function testGetUpdatedRecruitments()
    {
        $job = JobQuery::create()
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid());
            $job->save(); // for Pipelines
        }
        $recruitment = CategoriePrestation::getRecruitment();
        $jobItem = JobItemQuery::create()
            ->filterBySamsId(null, Criteria::ISNOTNULL)
            ->filterByPmtoolUpdated(true)
            ->filterByJob($job)
            ->filterByCategoriePrestation($recruitment)
            ->findOne();
        if (!$jobItem) {
            $jobItem = (new JobItem())
                ->setCategoriePrestation($recruitment)
                ->setSamsId(uniqid())
                ->setPrixVente(123)
                ->setPmtoolUpdated(true)
                ->setJob($job);
            $jobItem->save(); // for Pipelines
        }
        $result = $this->makeTestFunction('getUpdatedRecruitments');
        $this->assertGreaterThanOrEqual(1, count($result));
    }

    public function testGetUpdatedAccounts()
    {
        $account = AccountQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterBySfId(null, Criteria::ISNOTNULL)
            ->findOneOrCreate();
        if ($account->isNew()) { // For Pipelines
            $account->setPmtoolUpdated(true)->setSfId(uniqid())->save();
        }
        $result = $this->makeTestFunction('getUpdatedAccounts');
        $this->assertNotEquals(0, $result);
        $this->markTestIncomplete();
        $this->assertRespectsDTO($result, 'Account');
    }

    public function testGetUpdatedContacts()
    {
        $contact = ContactQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterBySfId(null, Criteria::ISNOTNULL)
            ->findOneOrCreate();
        if ($contact->isNew()) { // For Pipelines
            $contact->setPmtoolUpdated(true)->setSfId(uniqid())->save();
        }
        $result = $this->makeTestFunction('getUpdatedContacts');
        $this->assertNotEquals(0, $result);
        $this->markTestIncomplete();
        $this->assertRespectsDTO($result, 'Contact');
    }

    public function testGetUpdatedEvents()
    {
        $job = JobQuery::create()
            ->filterBySfIgnore(false)
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->filterByAcctChecked(true)
            ->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid());
            $job->save(); // for Pipelines
        }
        $event = EventQuery::create()
            ->filterByJob($job)
            ->filterByPmtoolUpdated(true)
            ->filterBySamsEventId('', Criteria::NOT_EQUAL)
            ->filterByStartDateTime(null, Criteria::ISNOTNULL)
            ->filterByEndDateTime(null, Criteria::ISNOTNULL)
            ->filterByRefRoomId(null, Criteria::ISNOTNULL)
            ->findOne();
        if (!$event) { // For Pipelines
            $this->createEvent($job, uniqid())->save();
        }
        $result = $this->makeTestFunction('getUpdatedEvents');
//         echo $this->soapClient->__getLastResponse()."\n\n".$this->soapClient->__getLastResponseHeaders();
        $this->assertNotEquals(0, $result);
        $this->assertRespectsDTO($result, 'Event');
    }

    public function testGetNewContacts()
    {
        $contact = ContactQuery::create()->findOneOrCreate();
        if ($contact->isNew()) {
            $contact->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('getNewContacts');
        $this->markTestIncomplete();
        $this->assertRespectsDTO($result, 'Contact');
    }

    public function testGetNewJobItems()
    {
        $job = JobQuery::create()
            ->filterBySfIgnore(false)
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->filterByAcctChecked(true)
            ->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid());
            $job->save(); // for Pipelines
        }
        $jobItem = JobItemQuery::create()
            ->filterByJob($job)
            ->filterByPrixVente(0, Criteria::NOT_EQUAL)
            ->filterBySfId(null, Criteria::ISNULL)
            ->filterByUpdatedAt(new \DateTime($this->expiration), Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->findOne();
        if (!$jobItem) {
            $cat = CategoriePrestationQuery::create()->findOne();
            $jobItem = (new JobItem())
                ->setCategoriePrestation($cat)
                ->setPrixVente(123)
                ->setJob($job);
            $jobItem->save(); // for Pipelines
        }
        $result = $this->makeTestFunction('getNewJobItems');
        $this->assertRespectsDTO($result, 'JobItem');
    }

    public function testGetNewEvents()
    {
        $job = JobQuery::create()
            ->filterBySfIgnore(false)
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->filterByAcctChecked(true)
            ->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid());
            $job->save(); // for Pipelines
        }
        $event = EventQuery::create()
            ->useRefEventStatusQuery()
                ->filterByName([RefEventStatus::TENTATIVE, RefEventStatus::RELEASED], Criteria::NOT_IN)
            ->endUse()
            ->filterByJob($job)
            ->filterBySamsEventId('')
            ->filterByStartDateTime(null, Criteria::ISNOTNULL)
            ->filterByEndDateTime(null, Criteria::ISNOTNULL)
            ->filterByRefRoomId(null, Criteria::ISNOTNULL)
            ->findOne();
        if (!$event) {
            $event = $this->createEvent($job, '');
            $event->save(); // for Pipelines
        }
        $result = $this->makeTestFunction('getNewEvents');

        $this->assertRespectsDTO($result, 'Event');
    }

    public function testGetNewJobs()
    {
        $job = JobQuery::create()
            ->useStatusQuery()
                ->filterByValue(RefSalesForce::JOB_STATUSES_SALESFORCE, Criteria::IN)
            ->endUse()
            ->filterBySfIgnore(false)
            ->filterByJobSfId(null, Criteria::ISNULL)
            ->filterByApiUpdatedDate(new \DateTime($this->expiration), Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->findOne();
        if (!$job) {
            $job = $this->createJob();
            $job->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('getNewJobs');
        $this->markTestIncomplete();
        $this->assertRespectsDTO($result, 'Job');
    }

    public function testGetNewRecruitments()
    {
        $job = JobQuery::create()
            ->filterBySfIgnore(false, Criteria::EQUAL)
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->findOne();
        if (!$job) {
            $job = $this->createJob(uniqid());
            $job->save(); // for Pipelines
        }
        $recruitment = CategoriePrestation::getRecruitment();
        $jobItem = JobItemQuery::create()
            ->filterBySamsId(null)
            ->filterByJob($job)
            ->filterByCategoriePrestation($recruitment)
            ->filterByUpdatedAt('24 hours ago', Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->findOne();
        if (!$jobItem) {
            $jobItem = (new JobItem())
                ->setCategoriePrestation($recruitment)
                ->setPrixVente(123)
                ->setJob($job);
            $jobItem->save(); // for Pipelines
        }
        $result = $this->makeTestFunction('getNewRecruitments');
//         echo $this->soapClient->__getLastResponse()."\n\n".$this->soapClient->__getLastResponseHeaders();
        $this->assertRespectsDTO($result, 'JobItem');
    }

    public function testUpdateAccount()
    {
        $account = AccountQuery::create()->findOneOrCreate();
        if ($account->isNew()) {
            $account->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateAccount', [
            'parameters' => [
                'pmtool_id' => $account->getId(),
                'account' => [
                    'Id' => uniqid(),
                    'Type' => 'Test',
                    'Products_and_Services_Used__c' => '',
                    'quant_discount_program' => 'program',
                ],
            ],
        ]);
        $this->assertEquals('success', $result);
    }

    public function testUpdateContact()
    {
        $contact = ContactQuery::create()->findOneOrCreate();
        if ($contact->isNew()) {
            $contact->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateContact', [
            'parameters' => [
                'pmtool_id' => $contact->getId(),
                'contact' => [
                    'Id' => uniqid(),
                    'marketing_audiences' => '',
                ],
            ],
        ]);
        $this->assertEquals('success', $result);
    }

    public function testUpdateJob()
    {
        $job = JobQuery::create()->findOneOrCreate();
        if ($job->isNew()) {
            $job = $this->createJob(uniqid())->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateJob', ['parameters' => [
            'pmtool_id' => $job->getId(),
            'job' => ['Id' => uniqid(), 'Name' => uniqid(), 'master_project_sf_id' => uniqid()],
        ]]);
        $this->assertEquals('success', $result);
    }

    public function testUpdateJobItem()
    {
        $jobItem = JobItemQuery::create()->findOneOrCreate();
        if ($jobItem->isNew()) {
            $job = $this->createJob(uniqid());
            $jobItem->setJob($job)->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateJobItem', ['parameters' => ['pmtool_id' => $jobItem->getId(), 'sf_id' => uniqid()]]);
        $this->assertEquals('success', $result);
    }

    public function testUpdateOpportunity()
    {
        $opportunity = OpportunityQuery::create()->findOneOrCreate();
        if ($opportunity->isNew()) {
            $opportunity->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateOpportunity', [
            'parameters' => [
                'pmtool_id' => $opportunity->getId(),
                'opportunity' => [
                    'Id' => uniqid(),
                    'opportunity_owner' => 'test',
                    'specialty_sales_rep' => 'test',
                    'Services__c' => '',
                ],
            ],
        ]);
        $this->assertEquals('success', $result);
    }

    public function testUpdateRecruitment()
    {
        $jobItem = JobItemQuery::create()->findOneOrCreate();
        if ($jobItem->isNew()) {
            $job = $this->createJob(uniqid());
            $jobItem->setJob($job)->save(); // for Pipelines
        }

        $result = $this->makeTestFunction('updateRecruitment', ['parameters' => ['pmtool_id' => $jobItem->getId(), 'sams_id' => uniqid()]]);
        $this->assertEquals('success', $result);
    }
}
