<?php

namespace SalesForceBundle\Controller;

use SalesForceBundle\Helper\ComplexTypeStrategy\MyArrayOfTypeSequence;
use SalesForceBundle\Services\SoapLogger;
use SalesForceBundle\Services\SoapServices;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Zend\Soap\AutoDiscover;
use Zend\Soap\Server;

/**
 * @Route("/api/salesforce")
 */
class SoapServerController extends AbstractController
{
    /**
     * @Route("/soap", name="soap_salesforce_api")
     */
    public function soapAction(SoapServices $services, SoapLogger $logger, Request $request): Response
    {
        // No cache
        ini_set('soap.wsdl_cache_enable', 0);
        ini_set('soap.wsdl_cache_ttl', 0);

        $url = $this->generateUrl('soap_salesforce_api', [], UrlGeneratorInterface::ABSOLUTE_URL);

        if (null !== $request->get('wsdl')) {
            $autodiscover = (new AutoDiscover(new MyArrayOfTypeSequence()))
                ->setOperationBodyStyle(['use' => 'literal'])->setBindingStyle(['style' => 'document'])
                ->setClass($services)
                ->setUri($url);

            $response = new Response();
            $response->headers->set('Content-Type', 'text/xml');
            $response->setContent($autodiscover->toXml());

            return $response;
        }

        $server = (new Server(null, ['location' => $url, 'uri' => $url]))
            ->setDebugMode(true)
            ->setClass($services)
            ->setReturnResponse(true);
        $logger->setServer($server);

        try {
            $serverHandleResponse = $server->handle();
        } catch (\SoapFault $e) {
            $serverHandleResponse = $e;
        }
        if ($serverHandleResponse instanceof \SoapFault) {
            $error = $serverHandleResponse->getCode().' : '.$serverHandleResponse->getMessage().' '.$serverHandleResponse->getFile().' '.$serverHandleResponse->getLine();
            // $error .= $serverHandleResponse->getTraceAsString();
            if ('Invalid XML' == $serverHandleResponse->getMessage()) {
                return new Response('Invalid XML', 400);
            }
            $logger->getLogger()->addCritical($error);
            if ('Empty request' != $serverHandleResponse->getMessage()) { // ignore empty request (default case)
                throw $serverHandleResponse;
            }
        }

        return new Response($server->getResponse(), 200, ['Content-Type' => 'text/xml']);
    }
}
