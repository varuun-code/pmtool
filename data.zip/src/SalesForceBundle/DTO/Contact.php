<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for Contact.
 */
class Contact
{
    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $Id;

    /** @var string */
    public $AccountId;

    /** @var string */
    public $Salutation;

    /** @var string */
    public $FirstName;

    /** @var string */
    public $LastName;

    /** @var string */
    public $Added_By__c;

    /** @var string */
    public $AccountName__c;

    /** @var string */
    public $Title;

    /** @var string */
    public $LinkedIn__c;

    /** @var string */
    public $Contact_Status__c;

    /** @var string */
    public $Primary_Contact__c;

    /** @var string */
    public $Image_Name__c;

    /** @var string */
    public $Contact_Preferences__c;

    /** @var string */
    public $Moderator__c;

    /** @var string */
    public $No_Client_Portal__c;

    /** @var string */
    public $Phone;

    /** @var string */
    public $Fax;

    /** @var string */
    public $MobilePhone;

    /** @var string */
    public $Email;

    /** @var string */
    public $CanBeDuplicated;

    /** @var string */
    public $Company_Influencer__c;

    /** @var string */
    public $Additional_Email__c;

    /** @var string */
    public $ReportsToId;

    /** @var string */
    public $HasOptedOutOfEmail;

    /** @var string */
    public $Do_Not_Solicit__c;

    /** @var string */
    public $Client_Space_Log_In__c;

    /** @var string */
    public $Client_Space_Tour__c;

    /** @var string */
    public $MailingStreet;

    /** @var string */
    public $MailingAddress;

    /** @var string */
    public $MailingCity;

    /** @var string */
    public $MailingState;

    /** @var string */
    public $MailingPostalCode;

    /** @var string */
    public $MailingCountry;

    /** @var string */
    public $OtherStreet;

    /** @var string */
    public $OtherAddress;

    /** @var string */
    public $OtherCity;

    /** @var string */
    public $OtherState;

    /** @var string */
    public $OtherPostalCode;

    /** @var string */
    public $OtherCountry;

    /** @var string */
    public $HomePhone;

    /** @var string */
    public $OtherPhone;

    /** @var string */
    public $AssistantName;

    /** @var string */
    public $AssistantPhone;

    /** @var string */
    public $Field_Management__c;

    /** @var string */
    public $Language_preference__c;

    /** @var string */
    public $Schlesinger_Events__c;

    /** @var string */
    public $The_Wall__c;

    /** @var string */
    public $Description;

    /** @var string */
    public $Possible_Primary_Job_Location__c;

    /** @var string */
    public $Area_of_Interest__c;

    /** @var string */
    public $Methodology__c;

    /** @var string */
    public $Gift_Code__c;

    /** @var string */
    public $LeadSource;

    /** @var string */
    public $Lead_Source_description__c;

    /** @var string */
    public $LastCURequestDate;

    /** @var string */
    public $LastCUUpdateDate;

    /** @var string */
    public $Birthdate;

    /** @var string */
    public $rrpu__Alert_Message__c;

    /** @var string */
    public $CreatedById;

    /** @var string */
    public $CreatedDate;

    /** @var string */
    public $LastModifiedById;

    /** @var string */
    public $LastModifiedDate;

    /** @var string */
    public $IsPersonAccount;

    /** @var string */
    public $LastActivity;

    /** @var string */
    public $LastActivityDate;

    /** @var string */
    public $CurrencyIsoCode;

    /** @var string */
    public $IsEmailBounced;

    /** @var string */
    public $Act_On_lead_Score__c;

    /** @var string */
    public $CLIENTID__c;

    /** @var string */
    public $CMS_Contact_ID__c;

    /** @var string */
    public $Contact_Source__c;

    /** @var string */
    public $Created_by_Profile_Name__c;

    /** @var string */
    public $Department__c;

    /** @var string */
    public $Direct_Number__c;

    /** @var string */
    public $hidden_dupecheck__c;

    /** @var string */
    public $Import_ID__c;

    /** @var string */
    public $Last_Activity_Date__c;

    /** @var string */
    public $LastModifiedDTS__c;

    /** @var string */
    public $Owner_Id__c;

    /** @var string */
    public $TW_Lead_Source__c;

    /** @var string */
    public $Name;

    /** @var string */
    public $SystemModstamp;

    /** @var string */
    public $marketing_audiences;
}
