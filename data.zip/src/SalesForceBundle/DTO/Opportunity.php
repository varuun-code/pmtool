<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for Opportunity.
 */
class Opportunity
{
    /** @var string */
    public $Id;

    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $N_Sample_Size__c;

    /** @var string */
    public $AccountId;

    /** @var string */
    public $ContactId;

    /** @var string */
    public $Job_created_Date;

    /** @var string */
    public $BidNumber__c;

    /** @var string */
    public $Bid_Revenue__c;

    /** @var string */
    public $Bid_Number__c;

    /** @var string */
    public $Client_Bid_Number__c;

    /** @var string */
    public $Project_Number__c;

    /** @var string */
    public $Client_Type;

    /** @var string */
    public $CloseDate;

    /** @var string */
    public $Closed_Lost_Reason_v2__c;

    /** @var string */
    public $CreatedDate;

    /** @var string */
    public $US_Global_Qual_GMS__c;

    /** @var string */
    public $incidence_rate;

    /** @var string */
    public $nb_of_survey;

    /** @var string */
    public $programming_complexity;

    /** @var string */
    public $Industry__c;

    /** @var string */
    public $Job_Qualification__c;

    /** @var string */
    public $Location__c;

    /** @var string */
    public $LOI_Option_1__c;

    /** @var string */
    public $LOI_Option_2__c;

    /** @var string */
    public $Max_IR__c;

    /** @var string */
    public $Min_IR__c;

    /** @var string */
    public $Notes_or_COmments__c;

    /** @var string */
    public $Account_Coordinator__c;

    /** @var string */
    public $CurrencyIsoCode;

    /** @var string */
    public $Opportunity_Subject__c;

    /** @var string */
    public $Other_Location__c;

    /** @var string */
    public $Probability;

    /** @var string */
    public $Proposed_N__c;

    /** @var string */
    public $Rebid__c;

    /** @var string */
    public $Sector__c;

    /** @var string */
    public $Services__c;

    /** @var string */
    public $StageName;

    /** @var string */
    public $OpportunityName;

    /** @var string */
    public $OpportunityEnglishSubject;

    /** @var string */
    public $BidValue;

    /** @var string */
    public $ZendeskTicketId;

    /** @var string */
    public $Zendesk;

    /** @var string */
    public $GqsGms;

    /** @var string */
    public $IncludeAccountManager;

    /** @var string */
    public $IncludeOppOwner;

    /** @var string */
    public $ApplyDiscount;

    /** @var string */
    public $PlatformId;

    /** @var string */
    public $SpecificsId;

    /** @var string */
    public $ResponseTime;

    /** @var string */
    public $opportunity_owner;

    /** @var string */
    public $account_manager;

    /** @var string */
    public $methodologies;

    /** @var string */
    public $end_client_contact_id;

    /** @var string */
    public $api_created_date;

    /** @var string */
    public $api_updated_date;

    /** @var string */
    public $end_client_id;

    /** @var string */
    public $end_client_sf_id;

    /** @var string */
    public $created_by_sf_id;

    /** @var string */
    public $pmtool_created_date;

    /** @var string */
    public $pmtool_updated;

    /** @var string */
    public $pmtool_updated_date;

    /** @var string */
    public $end_client_rep_sf_id;

    /** @var string */
    public $estimated_commissioning_date;

    /** @var string */
    public $Coronavirus_Effected;

    /** @var string */
    public $Lost_Revenue;

    /** @var string */
    public $specialty_sales_rep;

    /** @var string */
    public $printCurrency;
}
