<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for JobItem.
 */
class JobItem
{
    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $job_sf_id;

    /** @var string */
    public $master_project_number;

    /** @var string */
    public $category;

    /** @var string */
    public $section;

    /** @var string */
    public $vendor_id;

    /** @var string */
    public $respondent_type;

    /** @var string */
    public $respondent_location;

    /** @var string */
    public $methodology;

    /** @var string */
    public $date;

    /** @var string */
    public $quantity;

    /** @var string */
    public $unit_price;

    /** @var string */
    public $price;

    /** @var string */
    public $discount_comment;

    /** @var string */
    public $discount_percent;

    /** @var string */
    public $discount_exclude;

    /** @var string */
    public $title;

    /** @var string */
    public $type;

    /** @var string */
    public $acct_invoiced;

    /** @var string */
    public $invoice_date;

    /** @var string */
    public $invoice_number;

    /** @var string */
    public $paid_amount;

    /** @var string */
    public $paid_date;

    /** @var string */
    public $specific_reference;

    /** @var string */
    public $job_comments;

    /** @var string */
    public $markup;

    /** @var string */
    public $costs;

    /** @var string */
    public $pm_checked;

    /** @var string */
    public $fd_checked;

    /** @var string */
    public $am_checked;

    /** @var string */
    public $acct_checked;
}
