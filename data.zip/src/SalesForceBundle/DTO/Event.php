<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for Event.
 */
class Event
{
    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $account_id;

    /** @var string */
    public $activity_currency;

    /** @var string */
    public $sams_event_id;

    /** @var string */
    public $all_day_event;

    /** @var string */
    public $archived;

    /** @var string */
    public $assigned_to;

    /** @var string */
    public $cancelled;

    /** @var string */
    public $created_date;

    /** @var string */
    public $recurring_event;

    /** @var string */
    public $is_deleted;

    /** @var string */
    public $is_deleted_c;

    /** @var string */
    public $description;

    /** @var string */
    public $event_date;

    /** @var string */
    public $duration_minutes;

    /** @var string */
    public $end_date_time;

    /** @var string */
    public $record_type;

    /** @var string */
    public $event_sub_type;

    /** @var string */
    public $job_status;

    /** @var string */
    public $location_c;

    /** @var string */
    public $job_sf_id;

    /** @var string */
    public $reminder_date;

    /** @var string */
    public $reminder_set;

    /** @var string */
    public $room;

    /** @var string */
    public $start_date_time;

    /** @var string */
    public $subject;

    /** @var string */
    public $recurrence_time_zone;

    /** @var string */
    public $created_by_sf_id;

    /** @var string */
    public $event_methodology;
}
