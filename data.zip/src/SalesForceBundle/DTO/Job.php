<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for Job.
 */
class Job
{
    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $Id;

    /** @var string */
    public $master_project_sf_id;

    /** @var string */
    public $Location__c;

    /** @var string */
    public $Methodology__c;

    /** @var string */
    public $Consumed_Study__c;

    /** @var string */
    public $German_Job_Type__c;

    /** @var string */
    public $Client_Ref__c;

    /** @var string */
    public $Job_Name_Subject__c;

    /** @var string */
    public $Job_Start_Date__c;

    /** @var string */
    public $Job_End_Date__c;

    /** @var string */
    public $Account_ID__c;

    /** @var string */
    public $PM__c;

    /** @var string */
    public $Job_Category__c;

    /** @var string */
    public $Job_Type__c;

    /** @var string */
    public $Name;

    /** @var string */
    public $GMS_Job__c;

    /** @var string */
    public $End_Client__c;

    /** @var string */
    public $Contact_ID__c;

    /** @var string */
    public $End_Client_Contact__c;

    /** @var string */
    public $On_Site_Recruits__c;

    /** @var string */
    public $Off_Site_Recruits__c;

    /** @var string */
    public $Proposed_LOI__c;

    /** @var string */
    public $Proposed_N__c;

    /** @var string */
    public $Master_Project_Number__c;

    /** @var string */
    public $SI_Job_Type__c;

    /** @var string */
    public $Recruitment_Method__c;

    /** @var string */
    public $Opportunity__c;

    /** @var string */
    public $Respondent_Type__c;

    /** @var string */
    public $Services__c;

    /** @var string */
    public $Best_Effort__c;

    /** @var string */
    public $Booked_By__c;

    /** @var string */
    public $CreatedById;

    /** @var string */
    public $Account_Manager_COE__c;

    /** @var string */
    public $CreatedDate;

    /** @var string */
    public $Facility_Rating__c;

    /** @var string */
    public $Facility_Staff_Service__c;

    /** @var string */
    public $Project_Management__c;

    /** @var string */
    public $Recruitment__c;

    /** @var string */
    public $Rating_Comments__c;

    /** @var string */
    public $Job_Qualification__c;

    /** @var string */
    public $start_date;

    /** @var string */
    public $end_date;

    /** @var string */
    public $client_project_number;

    /** @var string */
    public $status;

    /** @var string */
    public $po_job_number;

    /** @var string */
    public $pm_checked;

    /** @var string */
    public $fd_checked;

    /** @var string */
    public $am_checked;

    /** @var string */
    public $acct_checked;

    /** @var string */
    public $room_count;

    /** @var string */
    public $budget_cost;

    /** @var string */
    public $budget_revenue;

    /** @var string */
    public $job_sample_size;

    /** @var string */
    public $project_account_manager_sf_id;

    /** @var string */
    public $project_sales_manager_sf_id;

    /** @var string */
    public $client_list_deletion;

    /** @var string */
    public $proposed_billing_date;

    /** @var string */
    public $job_sample_sources;

    /** @var string */
    public $country;

    /** @var string */
    public $area;

    /** @var string */
    public $offsite_location;

    /** @var string */
    public $end_date_reason;

    /** @var string */
    public $account_leader;

    /** @var string */
    public $account_pm;

    /** @var string */
    public $am_email;

    /** @var string */
    public $sunshine_act;

    /** @var string */
    public $client_portal_ready;

    /** @var string */
    public $length_interview;

    /** @var string */
    public $pm_sf_id;

    /** @var string */
    public $invoice_date;

    /** @var string */
    public $invoice_number;

    /** @var string */
    public $coronavirus_effected;

    /** @var string */
    public $lost_revenue;

    /** @var string */
    public $call_center;

    /** @var string */
    public $revised_location_prefix;

    /** @var string */
    public $products;

    /** @var string */
    public $specialty_sales_rep;

    /** @var string */
    public $Recruits_Required_for_Show__c;

    /** @var string */
    public $Project_Coordinator__c;

    public function setFieldsWithArray($array)
    {
        foreach ($array as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
    }
}
