<?php

namespace SalesForceBundle\DTO;

/**
 * Data Transfer Object for Account.
 */
class Account
{
    /** @var string */
    public $pmtool_id;

    /** @var string */
    public $Id;

    /** @var string */
    public $MasterRecordId;

    /** @var string */
    public $Name;

    /** @var string */
    public $LastName;

    /** @var string */
    public $FirstName;

    /** @var string */
    public $Salutation;

    /** @var string */
    public $Type;

    /** @var string */
    public $RecordTypeId;

    /** @var string */
    public $ParentId;

    /** @var string */
    public $BillingStreet;

    /** @var string */
    public $BillingCity;

    /** @var string */
    public $BillingState;

    /** @var string */
    public $BillingPostalCode;

    /** @var string */
    public $BillingCountry;

    /** @var string */
    public $BillingLatitude;

    /** @var string */
    public $BillingLongitude;

    /** @var string */
    public $BillingAddress;

    /** @var string */
    public $ShippingStreet;

    /** @var string */
    public $ShippingCity;

    /** @var string */
    public $ShippingState;

    /** @var string */
    public $ShippingPostalCode;

    /** @var string */
    public $ShippingCountry;

    /** @var string */
    public $ShippingLatitude;

    /** @var string */
    public $ShippingLongitude;

    /** @var string */
    public $ShippingAddress;

    /** @var string */
    public $Phone;

    /** @var string */
    public $Fax;

    /** @var string */
    public $AccountNumber;

    /** @var string */
    public $Website;

    /** @var string */
    public $PhotoUrl;

    /** @var string */
    public $Industry;

    /** @var string */
    public $AnnualRevenue;

    /** @var string */
    public $NumberOfEmployees;

    /** @var string */
    public $Description;

    /** @var string */
    public $CurrencyIsoCode;

    /** @var string */
    public $OwnerId;

    /** @var string */
    public $CreatedDate;

    /** @var string */
    public $CreatedById;

    /** @var string */
    public $LastModifiedDate;

    /** @var string */
    public $LastModifiedById;

    /** @var string */
    public $SystemModstamp;

    /** @var string */
    public $LastActivityDate;

    /** @var string */
    public $LastViewedDate;

    /** @var string */
    public $LastReferencedDate;

    /** @var string */
    public $PersonContactId;

    /** @var string */
    public $IsPersonAccount;

    /** @var string */
    public $PersonMailingStreet;

    /** @var string */
    public $PersonMailingCity;

    /** @var string */
    public $PersonMailingState;

    /** @var string */
    public $PersonMailingPostalCode;

    /** @var string */
    public $PersonMailingCountry;

    /** @var string */
    public $PersonMailingLatitude;

    /** @var string */
    public $PersonMailingLongitude;

    /** @var string */
    public $PersonMailingAddress;

    /** @var string */
    public $PersonOtherStreet;

    /** @var string */
    public $PersonOtherCity;

    /** @var string */
    public $PersonOtherState;

    /** @var string */
    public $PersonOtherPostalCode;

    /** @var string */
    public $PersonOtherCountry;

    /** @var string */
    public $PersonOtherLatitude;

    /** @var string */
    public $PersonOtherLongitude;

    /** @var string */
    public $PersonOtherAddress;

    /** @var string */
    public $PersonMobilePhone;

    /** @var string */
    public $PersonHomePhone;

    /** @var string */
    public $PersonOtherPhone;

    /** @var string */
    public $PersonAssistantPhone;

    /** @var string */
    public $PersonEmail;

    /** @var string */
    public $PersonTitle;

    /** @var string */
    public $PersonDepartment;

    /** @var string */
    public $PersonAssistantName;

    /** @var string */
    public $PersonLeadSource;

    /** @var string */
    public $PersonBirthdate;

    /** @var string */
    public $PersonHasOptedOutOfEmail;

    /** @var string */
    public $PersonLastCURequestDate;

    /** @var string */
    public $PersonLastCUUpdateDate;

    /** @var string */
    public $PersonEmailBouncedReason;

    /** @var string */
    public $PersonEmailBouncedDate;

    /** @var string */
    public $Jigsaw;

    /** @var string */
    public $JigsawCompanyId;

    /** @var string */
    public $AccountSource;

    /** @var string */
    public $SicDesc;

    /** @var string */
    public $Do_Not_Solicit__c;

    /** @var string */
    public $Client_ID__c;

    /** @var string */
    public $Need_for_PO_Numbers_to_start_recruiting__c;

    /** @var string */
    public $Receive_Invoice_Via__c;

    /** @var string */
    public $Field_Manager__c;

    /** @var string */
    public $Bad_Payer__c;

    /** @var string */
    public $Free_DVD__c;

    /** @var string */
    public $Discount_Program__c;

    /** @var string */
    public $Discount_Percentage__c;

    /** @var string */
    public $Quant_Discount_Percentage__c;

    /** @var string */
    public $Discount_Notes__c;

    /** @var string */
    public $Staff_Preferences__c;

    /** @var string */
    public $Credit_Terms__c;

    /** @var string */
    public $Credit_Hold__c;

    /** @var string */
    public $Total_Opportunity__c;

    /** @var string */
    public $Total_Closed_Won_Opportunities__c;

    /** @var string */
    public $Conversion_Rate__c;

    /** @var string */
    public $Client_Type__c;

    /** @var string */
    public $Multimarket__c;

    /** @var string */
    public $Account_Status__c;

    /** @var string */
    public $Bid_Discount_Comments__c;

    /** @var string */
    public $CMS_Client_ID__c;

    /** @var string */
    public $MAS_500_ID__c;

    /** @var string */
    public $Client_Source__c;

    /** @var string */
    public $old_SF_ID__c;

    /** @var string */
    public $Account_Team_Lisa__c;

    /** @var string */
    public $Average_Rating__c;

    /** @var string */
    public $production_ID__c;

    /** @var string */
    public $Facility_SOPs__c;

    /** @var string */
    public $Spreadsheet_SOPs__c;

    /** @var string */
    public $Financial_Alert__c;

    /** @var string */
    public $Octopuce_Record_ID__c;

    /** @var string */
    public $Agreement_Type__c;

    /** @var string */
    public $Total_AV_Cost__c;

    /** @var string */
    public $Total_Client_Food_Cost__c;

    /** @var string */
    public $Total_Facility_Rental_Cost__c;

    /** @var string */
    public $Total_Misc_Cost__c;

    /** @var string */
    public $Total_Recruiting_Cost__c;

    /** @var string */
    public $Total_Respondent_Food_Cost__c;

    /** @var string */
    public $Total_Food_Cost__c;

    /** @var string */
    public $Agreement_Start_Date__c;

    /** @var string */
    public $Legal_Account_Name__c;

    /** @var string */
    public $Agreement_End_Date__c;

    /** @var string */
    public $VAT__c;

    /** @var string */
    public $LinkedIn_Account_Name__c;

    /** @var string */
    public $of_Bids_YTD__c;

    /** @var string */
    public $Quant_Sponsor__c;

    /** @var string */
    public $PM_Total_Scores__c;

    /** @var string */
    public $PM_Average_Score__c;

    /** @var string */
    public $Recruit_Total_Scores__c;

    /** @var string */
    public $Facility_Total_Scores__c;

    /** @var string */
    public $Recruit_Average_Score__c;

    /** @var string */
    public $Facility_Average_Score__c;

    /** @var string */
    public $PM_Total_Records__c;

    /** @var string */
    public $Recruit_Total_Records__c;

    /** @var string */
    public $Facility_Total_Records__c;

    /** @var string */
    public $green_light__c;

    /** @var string */
    public $PF__c;

    /** @var string */
    public $RF__c;

    /** @var string */
    public $Secondary_Account_Owner__c;

    /** @var string */
    public $Special_Account__c;

    /** @var string */
    public $Regularly_Uses_SA_for__c;

    /** @var string */
    public $Regularly_Uses_Another_Vendor_for__c;

    /** @var string */
    public $Impression_of_SA_Relationship__c;

    /** @var string */
    public $Overall__c;

    /** @var string */
    public $Total_Number_of_Locations_Offices__c;

    /** @var string */
    public $Qualitative__c;

    /** @var string */
    public $Quantitative__c;

    /** @var string */
    public $Combined__c;

    /** @var string */
    public $Pharmaceutical__c;

    /** @var string */
    public $B2B__c;

    /** @var string */
    public $Consumer__c;

    /** @var string */
    public $Other__c;

    /** @var string */
    public $US_Exclusive__c;

    /** @var string */
    public $Global__c;

    /** @var string */
    public $RR__c;

    /** @var string */
    public $Gift_exclusion_policy__c;

    /** @var string */
    public $LastModifiedDTS__c;

    /** @var string */
    public $Most_Recent_Bid__c;

    /** @var string */
    public $X90_Days_Since_Last_Bid__c;

    /** @var string */
    public $Country_Of_Residence__c;

    /** @var string */
    public $Cell__c;

    /** @var string */
    public $Date_of_Birth__c;

    /** @var string */
    public $GSK_CID__c;

    /** @var string */
    public $Training_Information__c;

    /** @var string */
    public $Ethnicity_Race__c;

    /** @var string */
    public $SS__c;

    /** @var string */
    public $Client_Portal_Ready__c;

    /** @var string */
    public $No_AI_Needed__c;

    /** @var string */
    public $X2nd_Qual_Sponsor__c;

    /** @var string */
    public $PM_Team__c;

    /** @var string */
    public $Lead_PM__c;

    /** @var string */
    public $PM_Account_Type__c;

    /** @var string */
    public $rrpu__Alert_Message__c;

    /** @var string */
    public $EU_Discount_Percentage__c;

    /** @var string */
    public $PM_Total_Scores_2__c;

    /** @var string */
    public $PM_Total_Records_2__c;

    /** @var string */
    public $PM_Average_Score_2__c;

    /** @var string */
    public $Recruit_Total_Scores_2__c;

    /** @var string */
    public $Recruit_Total_Records_2__c;

    /** @var string */
    public $Recruit_Average_Score_2__c;

    /** @var string */
    public $Last_Job__c;

    /** @var string */
    public $Last_JobId__c;

    /** @var string */
    public $Last_Job_Completed__c;

    /** @var string */
    public $Account_Owner_Profile_Name__c;

    /** @var string */
    public $Relationship_Status__c;

    /** @var string */
    public $Account_Sponsor__c;

    /** @var string */
    public $X2012__c;

    /** @var string */
    public $High_Alert__c;

    /** @var string */
    public $Top_150__c;

    /** @var string */
    public $Country_of_Use__c;

    /** @var string */
    public $Areas_of_Research__c;

    /** @var string */
    public $Products_and_Services_Used__c;

    /** @var string */
    public $Facility_Total_Scores_2__c;

    /** @var string */
    public $X2nd_Quant_Sponsor__c;

    /** @var string */
    public $Team__c;

    /** @var string */
    public $COE__c;

    /** @var string */
    public $Notes__c;

    /** @var string */
    public $Facility_Total_Records_2__c;

    /** @var string */
    public $Facility_Average_Score_2__c;

    /** @var string */
    public $Facility_Average_Score3__c;

    /** @var string */
    public $PM_Average_Score3__c;

    /** @var string */
    public $Recruit_Average_Score3__c;

    /** @var string */
    public $X4_Year_Bid__c;

    /** @var string */
    public $Terms_Conditions__c;

    /** @var string */
    public $End_Client_Vertical__c;

    /** @var string */
    public $Account_Division__c;

    /** @var string */
    public $CLIENTID__pc;

    /** @var string */
    public $Field_Management__pc;

    /** @var string */
    public $Additional_Email__pc;

    /** @var string */
    public $LinkedIn__pc;

    /** @var string */
    public $Gift_Code__pc;

    /** @var string */
    public $Possible_Primary_Job_Location__pc;

    /** @var string */
    public $Language_preference__pc;

    /** @var string */
    public $Image_Name__pc;

    /** @var string */
    public $Image__pc;

    /** @var string */
    public $Area_of_Interest__pc;

    /** @var string */
    public $Methodology__pc;

    /** @var string */
    public $Lead_Source_description__pc;

    /** @var string */
    public $Department__pc;

    /** @var string */
    public $Do_Not_Solicit__pc;

    /** @var string */
    public $Direct_Number__pc;

    /** @var string */
    public $CMS_Contact_ID__pc;

    /** @var string */
    public $Contact_Status__pc;

    /** @var string */
    public $AccountName__pc;

    /** @var string */
    public $Primary_Contact__pc;

    /** @var string */
    public $Created_by_Profile_Name__pc;

    /** @var string */
    public $hidden_dupecheck__pc;

    /** @var string */
    public $Contact_Source__pc;

    /** @var string */
    public $Moderator__pc;

    /** @var string */
    public $Octopuce_Record_ID__pc;

    /** @var string */
    public $Added_By__pc;

    /** @var string */
    public $Import_ID__pc;

    /** @var string */
    public $Contact_Preferences__pc;

    /** @var string */
    public $Schlesinger_Events__pc;

    /** @var string */
    public $Client_Space_Log_In__pc;

    /** @var string */
    public $Company_Influencer__pc;

    /** @var string */
    public $LastModifiedDTS__pc;

    /** @var string */
    public $TW_Lead_Source__pc;

    /** @var string */
    public $Act_On_lead_Score__pc;

    /** @var string */
    public $Owner_Id__pc;

    /** @var string */
    public $Client_Space_Tour__pc;

    /** @var string */
    public $rrpu__Alert_Message__pc;

    /** @var string */
    public $The_Wall__pc;

    /** @var string */
    public $No_Client_Portal__pc;

    /** @var string */
    public $Last_Activity_Date__pc;

    /** @var string */
    public $Rebate;

    /** @var string */
    public $accounting_note;

    /** @var string */
    public $flat_rate;

    /** @var string */
    public $sponsor_2020;

    /** @var string */
    public $aspen_finn_sponsor;

    /** @var string */
    public $accounting_email;

    /** @var string */
    public $accounting_attn;

    /** @var string */
    public $pod_qual;

    /** @var string */
    public $pod_quant;

    /** @var string */
    public $sub_types;

    /** @var string */
    public $quant_discount_program;

    /** @var string */
    public $discount_token_max;

    /** @var string */
    public $discount_token_count;

    /** @var string */
    public $ar_payment_terms;

    /** @var string */
    public $ai_payment_terms;
}
