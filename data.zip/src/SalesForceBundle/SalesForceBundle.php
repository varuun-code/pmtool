<?php

namespace SalesForceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalesForceBundle extends Bundle
{
}
