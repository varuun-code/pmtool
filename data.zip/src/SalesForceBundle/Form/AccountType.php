<?php

namespace SalesForceBundle\Form;

use Model\Account;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use SalesForceBundle\Services\SoapServices;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class AccountType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Account::class,
            'name' => 'account',
            'csrf_protection' => false,
            'allow_extra_fields' => true, // FIXME should be false, but there are ~147 extra fields... fix the DTO
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('sf_id', null, [
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('is_person_account', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('record_type')
            ->add('name')
            ->add('name_legal')
            ->add('parent_id')
            ->add('type')
            ->add('accounting_note')
            ->add('source')
            ->add('sic_description')
            ->add('client_type_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('client_type_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'ClientType',
            ])
            ->add('multimarket', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('industry_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('industry_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Industry',
            ])
            ->add('client_source_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('client_source_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'ClientSource',
            ])
            ->add('client_portal_ready', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('rebate', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('phone')
            ->add('fax')
            ->add('website')
            ->add('status_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('status_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Status',
            ])
            ->add('bad_payer', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('last_job_completed')
            ->add('billing_street')
            ->add('billing_address')
            ->add('billing_city')
            ->add('billing_state')
            ->add('billing_zip')
            ->add('billing_country')
            ->add('team_lisa')
            ->add('sponsor')
            ->add('x2nd_qual_sponsor')
            ->add('quant_sponsor')
            ->add('x2nd_quant_sponsor')
            ->add('relationship_status_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('relationship_status_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'RelationshipStatus',
            ])
            ->add('relationship_status')
            ->add('areas_of_researches', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('areas_of_researches'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefAreasOfResearches',
            ])
            ->add('country_of_uses', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('country_of_uses'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefCountryOfUses',
            ])
            ->add('regularly_uses_another_vendor_fors', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('regularly_uses_another_vendor_fors'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefRegularlyUsesAnotherVendorFors',
            ])
            ->add('regularly_uses_sa_fors', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('regularly_uses_sa_fors'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefRegularlyUsesSaFors',
            ])
            ->add('products_and_services_useds', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('products_and_services_useds'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefProductsAndServicesUseds',
            ])
            ->add('agreement_types', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('agreement_types'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefAgreementTypes',
            ])
            ->add('lead_pm')
            ->add('number_of_employees')
            ->add('discount_program_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('discount_program_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'DiscountProgram',
            ])
            ->add('staff_preferences')
            ->add('discount_percentage_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('discount_percentage_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'DiscountPercentage',
            ])
            ->add('eu_discount_percentage_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('eu_discount_percentage_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'EuDiscountPercentage',
            ])
            ->add('quant_discount_percentage')
            ->add('discount_notes')
            ->add('pm_team')
            ->add('pm_account_type')
            ->add('annual_revenue')
            ->add('annual_revenue_converted')
            ->add('annual_revenue_currency')
            ->add('annual_revenue_converted_currency')
            ->add('field_Manager', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('need_for_po_numbers_to_start_recruiting', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('mas_500_id')
            ->add('number')
            ->add('x90_days_since_last_bid')
            ->add('x4_year_bid')
            ->add('bid_discount_comments')
            ->add('description')
            ->add('receive_invoice_via_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('receive_invoice_via_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'ReceiveInvoiceVia',
            ])
            ->add('do_not_solicit', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('free_dvd', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('credit_hold', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('credit_terms')
            ->add('vat')
            ->add('facility_average_score')
            ->add('recruit_average_score')
            ->add('pm_average_score')
            ->add('conversion_rate')
            ->add('facility_average_score_3')
            ->add('recruit_average_score_3')
            ->add('pm_average_score_3')
            ->add('terms_conditions')
            ->add('agreement_start_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('agreement_end_date', DateType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('spreadsheet_sops')
            ->add('financial_alert')
            ->add('facility_sops')
            ->add('training_information', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('create_by_id')
            ->add('last_modified_by_id')
            ->add('rr', ChoiceType::class, [
                'property_path' => 'RR',
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('ss', ChoiceType::class, [
                'property_path' => 'SS',
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('high_alert', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('notes')
            ->add('no_ai_needed', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('flat_rate', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('octopuce_record_id')
            ->add('top_150', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('team')
            ->add('coe')
            ->add('end_client_vertical_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('end_client_vertical_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'EndClientVertical',
            ])
            ->add('owner_profile_name')
            ->add('other')
            ->add('currency_iso_code_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByAccountField('currency_iso_code_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'CurrencyIsoCode',
            ])
            ->add('division')
            ->add('last_activity_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_modified_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('of_bids_ytd')
            ->add('alert_message')
            ->add('pharmaceutical')
            ->add('average_rating')
            ->add('client_id')
            ->add('cms_client_id')
            ->add('created_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('quant_discount_percentage_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('quant_discount_percentage_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'QuantDiscountPercentage',
            ])
            ->add('sponsor_2020')
            ->add('aspen_finn_sponsor')
            ->add('accounting_email')
            ->add('accounting_attn')
            ->add('pod_qual', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('pod_qual'),
                'multiple' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('pod_quant', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('pod_quant'),
                'multiple' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('sub_types', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('sub_types'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceAccountRefSubTypes',
            ])
            ->add('quant_discount_program', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('quant_discount_program'),
                'multiple' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('ar_payment_terms', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('ar_payment_terms'),
                'multiple' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('ai_payment_terms', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveAccountField('ai_payment_terms'),
                'multiple' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('discount_token_max')
            ->add('discount_token_count')
            ->add('pmtool_updated', HiddenType::class)
            ->add('api_created_date', HiddenType::class)
            ->add('api_updated_date', HiddenType::class)
            ->add('pmtool_created_date', HiddenType::class)
            ->add('pmtool_updated_date', HiddenType::class);
    }
}
