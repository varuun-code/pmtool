<?php

namespace SalesForceBundle\Form;

use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\Opportunity;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use SalesForceBundle\Services\SoapServices;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class OpportunityType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(['instance']);
        $resolver->setDefaults([
            'data_class' => Opportunity::class,
            'name' => 'opportunity',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $data = $builder->getData();
        $builder
            ->add('id')
            ->add('sf_id', null, [
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('n_sample_size')
            ->add('account_sf_id')
            ->add('contact_sf_id')
            ->add('job_created_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('opportunity_name')
            ->add('bidnumber')
            ->add('bid_revenue')
            ->add('bid_number', null, ['property_path' => 'BidNumber2'])
            ->add('bid_value')
            ->add('gqs_gms')
            ->add('zendesk_ticket_id')
            ->add('zendesk', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('include_account_manager', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('include_opp_owner', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('report_end_client')
            ->add('apply_discount', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('platform_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('platform_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Platform',
            ])
            ->add('specifics_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('specifics_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Specifics',
            ])
            ->add('response_time')
            ->add('client_bid_number')
            ->add('project_number')
            ->add('client_type_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('client_type_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'ClientType',
            ])
            ->add('close_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('created_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('estimated_commissioning_date', DateTimeType::class, [
                'widget' => 'single_text',
                'format' => 'YYYY-MM-dd',
            ])
            ->add('us_global_qual_gms_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('us_global_qual_gms_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'UsGlobalQualGms',
            ])
            ->add('incidence_rate', NumberType::class, [
                'empty_data' => '0.0',
            ])
            ->add('nb_of_survey', NumberType::class, [
                'empty_data' => '0',
            ])
            ->add('programming_complexity', ChoiceType::class, [
                'choices' => Opportunity::getProgrammingComplexities(),
            ])
            ->add('industry', ModelType::class, [
                'query' => IndustryQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel('', Criteria::NOT_EQUAL),
                'multiple' => false,
                'class' => Industry::class,
            ])
            ->add('job_qualification_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('job_qualification_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'JobQualification',
            ])
            ->add('loi_option_1')
            ->add('loi_option_2')
            ->add('max_ir')
            ->add('min_ir')
            ->add('notes_or_comments')
            ->add('account_coordinator')
            ->add('currency_iso_code_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('currency_iso_code_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'CurrencyIsoCode',
            ])
            ->add('opportunity_subject')
            ->add('opportunity_english_subject')
            ->add('end_client_sf_id')
            ->add('end_client_contact_sf_id')
            ->add('end_client_rep_sf_id')
            ->add('other_location')
            ->add('probability')
            ->add('proposed_n')
            ->add('rebid')
            ->add('coronavirus_effected', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('lost_revenue')
            ->add('stage_name_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('stage_name_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'StageName',
            ])
            ->add('servicess', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('servicess'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceOpportunityRefServicess',
            ])
            ->add('sectors', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('sectors'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceOpportunityRefSectors',
            ])
            ->add('closed_lost_reason_v2s', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByOpportunityField('closed_lost_reason_v2s'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceOpportunityRefClosedLostReasonV2s',
            ])
            ->add('methodologies', ModelType::class, [
                'query' => MethodologyQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel(null, Criteria::ISNOTNULL),
                'multiple' => true,
                'class' => Methodology::class,
                'property_path' => 'SalesForceOpportunityMethodologies',
            ])
            ->add('locations', ModelType::class, [
                'query' => LocationQuery::create()->filterBySfLabel(null, Criteria::ISNOTNULL),
                'multiple' => true,
                'class' => Location::class,
                'property_path' => 'SalesForceOpportunityLocations',
            ])
            ->add('account_manager', ModelType::class, [
                'class' => User::class,
                'query' => UserQuery::create()->filterBySfId('', Criteria::NOT_EQUAL),
                'index_property' => 'sf_id',
                'property_path' => 'OpportunityAccountManager',
                'empty_data' => User::getDefault(),
            ])
            ->add('specialty_sales_rep', ModelType::class, [
                'class' => User::class,
                'query' => UserQuery::create()->filterBySfId('', Criteria::NOT_EQUAL),
                'index_property' => 'sf_id',
                'property_path' => 'OpportunitySpecialtySponsor',
                'expanded' => true, // we MUST set that if we want default_value = NULL
            ])
            ->add('end_client_id', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('end_client_contact_id', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('pmtool_updated', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('api_created_date', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('api_updated_date', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('pmtool_created_date', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('pmtool_updated_date', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('created_by_id', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('created_by_sf_id', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('pmtool_id', HiddenType::class, [
                'mapped' => false,
            ])
            ->add('print_currency', ChoiceType::class, [
                'choices' => ['EUR' => 'EUR', 'USD' => 'USD', 'GBP' => 'GBP'],
                'multiple' => false,
                'expanded' => false,
            ])
        ;
        if (('de' == $options['instance'] || 'es' == $options['instance']) && $data->getPmtoolCreatedById()) { // per #15868
            $builder
                ->add('opportunity_owner', HiddenType::class, [
                    'mapped' => false,
                ]);
        } else {
            $builder
                ->add('opportunity_owner', ModelType::class, [
                    'class' => User::class,
                    'query' => UserQuery::create()->filterBySfId('', Criteria::NOT_EQUAL),
                    'index_property' => 'sf_id',
                    'property_path' => 'pmtool_created_by',
                    'empty_data' => User::getDefault(),
                ]);
        }
    }
}
