<?php

namespace SalesForceBundle\Form;

use Model\Contact;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use SalesForceBundle\Services\SoapServices;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class ContactType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Contact::class,
            'name' => 'contact',
            'csrf_protection' => false,
            'allow_extra_fields' => true, // FIXME should be false, but there are ~147 extra fields... fix the DTO
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id')
            ->add('sf_id', null, [
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('account_sf_id')
            ->add('is_person_account', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('salutation_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('salutation_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Salutation',
            ])
            ->add('first_name')
            ->add('last_name')
            ->add('owner')
            ->add('owner_alias')
            ->add('owner_role_display')
            ->add('owner_role_name')
            ->add('data_com_key')
            ->add('email_bounced_reason')
            ->add('email_bounced_date', DateTimeType::class, [
                'property_path' => 'EmailBouncedDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('created_alias', DateTimeType::class, [
                'property_path' => 'CreatedAlias',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_modified_alias', DateTimeType::class, [
                'property_path' => 'LastModifiedAlias',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('added_by_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('added_by_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'AddedBy',
            ])
            ->add('account_name')
            ->add('title')
            ->add('linkedin')
            ->add('contact_status_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('contact_status_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'ContactStatus',
            ])
            ->add('primary_contact', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('image_name')
            ->add('contact_preferences')
            ->add('moderator', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('no_client_portal')
            ->add('phone')
            ->add('fax')
            ->add('mobile_phone')
            ->add('email')
            ->add('can_be_duplicated', ChoiceType::class, [
                 'choices' => SoapServices::CHOICES_BOOLEAN,
             ])
            ->add('company_influencer')
            ->add('additional_email')
            ->add('reports_to_id')
            ->add('has_opted_out_of_email', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('do_not_solicit', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('client_space_log_in', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('client_space_tour', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('mailing_street')
            ->add('mailing_address')
            ->add('mailing_city')
            ->add('mailing_state')
            ->add('mailing_postal_code')
            ->add('mailing_country')
            ->add('other_street')
            ->add('other_address')
            ->add('other_city')
            ->add('other_state')
            ->add('other_postal_code')
            ->add('other_country')
            ->add('home_phone')
            ->add('other_phone')
            ->add('assistant_name')
            ->add('assistant_phone')
            ->add('field_management', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_YN,
            ])
            ->add('language_preference_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('language_preference_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'LanguagePreference',
            ])
            ->add('schlesinger_eventss', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('schlesinger_eventss'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefSchlesingerEventss',
            ])
            ->add('the_wall_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('the_wall_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'TheWall',
            ])
            ->add('description')
            ->add('possible_primary_job_locations', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('possible_primary_job_locations'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefPossiblePrimaryJobLocations',
            ])
            ->add('area_of_interests', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('area_of_interests'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefAreaOfInterests',
            ])
            ->add('methodologies', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('methodologies'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefMethodologies',
            ])
            ->add('gift_code_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('gift_code_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'GiftCode',
            ])
            ->add('lead_source_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('lead_source_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'LeadSource',
            ])
            ->add('lead_source_description')
            ->add('last_cu_request_date', DateTimeType::class, [
                'property_path' => 'LastCuRequestDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_cu_update_date', DateTimeType::class, [
                'property_path' => 'LastCuUpdateDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('birthdate', DateTimeType::class, [
                'property_path' => 'Birthdate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('alert_message')
            ->add('created_by_id')
            ->add('created_date', DateTimeType::class, [
                'property_path' => 'CreatedDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_modified_by_id')
            ->add('last_modified_date', DateTimeType::class, [
                'property_path' => 'LastModifiedDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_activity_date', DateTimeType::class, [
                'property_path' => 'LastActivityDate',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('last_activity', DateTimeType::class, [
                'property_path' => 'LastActivity',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('currency_iso_code_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('currency_iso_code_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'CurrencyIsoCode',
            ])
            ->add('is_email_bounced', ChoiceType::class, [
                'choices' => SoapServices::CHOICES_BOOLEAN,
            ])
            ->add('act_on_lead_score')
            ->add('client_id')
            ->add('cms_contact_id')
            ->add('contact_sources', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('contact_sources'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefContactSources',
            ])
            ->add('created_by_profile_name')
            ->add('department')
            ->add('direct_number')
            ->add('hidden_dupecheck')
            ->add('import_id')
            ->add('last_modified_dts', DateTimeType::class, [
                'property_path' => 'LastModifiedDts',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('owner_id')
            ->add('tw_lead_source_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByContactField('tw_lead_source_id'),
                'multiple' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'TwLeadSource',
            ])
            ->add('system_modstamp', DateTimeType::class, [
                'property_path' => 'SystemModstamp',
                'widget' => 'single_text',
                'format' => "YYYY-MM-dd'T'HH:mm:ss",
            ])
            ->add('marketing_audiences', ModelType::class, [
                'query' => RefSalesForceQuery::create()->filterByActiveContactField('marketing_audiences'),
                'multiple' => true,
                'class' => RefSalesForce::class,
                'property_path' => 'RefSalesForceContactRefMarketingAudiences',
            ])
            ->add('account_id', HiddenType::class)
            ->add('pmtool_updated', HiddenType::class)
            ->add('api_created_date', HiddenType::class)
            ->add('api_updated_date', HiddenType::class)
            ->add('pmtool_created_date', HiddenType::class)
            ->add('pmtool_updated_date', HiddenType::class);
    }
}
