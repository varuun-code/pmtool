<?php

namespace SalesForceBundle\Helper\ComplexTypeStrategy;

use Zend\Soap\Wsdl;
use Zend\Soap\Wsdl\ComplexTypeStrategy\ArrayOfTypeSequence;

/**
 * Description of MyArrayOfTypeSequence.
 *
 * @author charleshenzel
 */
class MyArrayOfTypeSequence extends ArrayOfTypeSequence
{
    protected function getItemName($childTypeName)
    {
        switch ($childTypeName) {
            case 'tns:Contact':
                $result = 'Contact';
                break;
            case 'tns:Account':
                $result = 'Account';
                break;
            case 'tns:Opportunity':
                $result = 'Opportunity';
                break;
            case 'tns:Event':
                $result = 'Event';
                break;
            case 'tns:Job':
                $result = 'Job';
                break;
            case 'tns:JobItem':
                $result = 'JobItem';
                break;
            case 'tns:ArrayOfContact':
                $result = 'Contact';
                break;
            case 'tns:ArrayOfAccount':
                $result = 'Account';
                break;
            case 'tns:ArrayOfEvent':
                $result = 'Event';
                break;
            case 'tns:ArrayOfOpportunity':
                $result = 'Opportunity';
                break;
            case 'tns:ArrayOfJob':
                $result = 'Job';
                break;
            case 'tns:ArrayOfJobItem':
                $result = 'JobItem';
                break;
            default:
                $result = 'item';
        }

        return $result;
    }

    /**
     * Append the complex type definition to the WSDL via the context access.
     *
     * @param string $arrayType    Array type name (e.g. 'tns:ArrayOfArrayOfInt')
     * @param string $childType    Qualified array items type (e.g. 'xsd:int', 'tns:ArrayOfInt')
     * @param string $phpArrayType PHP type (e.g. 'int[][]', '\MyNamespace\MyClassName[][][]')
     */
    protected function addSequenceType($arrayType, $childType, $phpArrayType)
    {
        if (null !== $this->scanRegisteredTypes($phpArrayType)) {
            return;
        }

        // Register type here to avoid recursion
        $this->getContext()->addType($phpArrayType, $arrayType);

        $dom = $this->getContext()->toDomDocument();

        $arrayTypeName = substr($arrayType, strpos($arrayType, ':') + 1);

        $complexType = $dom->createElementNS(Wsdl::XSD_NS_URI, 'complexType');
        $this->getContext()->getSchema()->appendChild($complexType);

        $complexType->setAttribute('name', $arrayTypeName);

        $sequence = $dom->createElementNS(Wsdl::XSD_NS_URI, 'sequence');
        $complexType->appendChild($sequence);

        $element = $dom->createElementNS(Wsdl::XSD_NS_URI, 'element');
        $sequence->appendChild($element);

        $element->setAttribute('name', $this->getItemName($childType));
        $element->setAttribute('nillable', 'true');
        $element->setAttribute('type', $childType);
        $element->setAttribute('minOccurs', 0);
        $element->setAttribute('maxOccurs', 'unbounded');
    }
}
