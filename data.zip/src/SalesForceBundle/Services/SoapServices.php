<?php

namespace SalesForceBundle\Services;

use Exception;
use Manager\SharepointManager;
use Model\Account;
use Model\AccountQuery;
use Model\CategoriePrestation;
use Model\Contact;
use Model\ContactQuery;
use Model\Event;
use Model\EventQuery;
use Model\IndustryQuery;
use Model\Job;
use Model\JobItem;
use Model\JobItemQuery;
use Model\JobQuery;
use Model\LocationQuery;
use Model\Map\ContactTableMap;
use Model\Map\RefSalesForceTableMap;
use Model\MethodologyQuery;
use Model\Opportunity;
use Model\OpportunityQuery;
use Model\RefEventStatus;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Exception\PropelException;
use SalesForceBundle\Form\AccountType;
use SalesForceBundle\Form\ContactType;
use SalesForceBundle\Form\EventType;
use SalesForceBundle\Form\JobType;
use SalesForceBundle\Form\OpportunityType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormErrorIterator;
use Symfony\Component\Form\FormFactoryInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\ConstraintViolation;

class SoapServices
{
    const LIMIT = 500;

    const CHOICES_YN = [
        'Y' => 'Y',
        'Yes' => 'Yes',
        'N' => 'N',
        'No' => 'No',
    ];

    const CHOICES_BOOLEAN = [
        '1' => '1',
        '0' => '0',
        'true' => 'true',
        'false' => 'false',
    ];

    protected $expiration;
    protected $formFactory;
    protected $instance;
    protected $spManager;

    private $log;

    public function __construct(string $expiration, string $instance, FormFactoryInterface $formFactory, SoapLogger $logger, SharepointManager $spManager)
    {
        $this->expiration = $expiration;
        $this->formFactory = $formFactory;
        $this->instance = $instance;
        $this->log = $logger;
        $this->spManager = $spManager;

        ini_set('memory_limit', '1G');
    }

    private function getLog()
    {
        return $this->log->getLogger();
    }

    private function logException(Exception $e, $log = '')
    {
        $this->getLog()->addCritical($log.$e->getMessage().' '.$e->getTraceAsString());
        if ($p = $e->getPrevious()) {
            $this->getLog()->addCritical('Due to: '.$p->getMessage().' '.$p->getTraceAsString());
        }
    }

    private function logRequest()
    {
        return $this->log->logRequest();
    }

    /**
     * This service creates an opportunity based on its SalesForce Id and XML.
     *
     * @param string                            $sf_id
     * @param \SalesForceBundle\DTO\Opportunity $opportunity
     *
     * @return string
     */
    public function createOpportunity($sf_id, $opportunity)
    {
        $this->logRequest();
        $log = "CreateOpportunity for Opportunity with Salesforce id '$sf_id': ";
        if ($existing = OpportunityQuery::create()->findOneBySfId($sf_id)) {
            $this->getLog()->addNotice($log.'an Opportunity already exists with this id.');
            $response = '<createOpportunityResult>'.$existing->getId().'</createOpportunityResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormOpportunity((new Opportunity())->setSfId($sf_id), $opportunity, $log);
    }

    /**
     * This service updates an opportunity based on its PMTool Id and XML.
     *
     * @param string                            $pmtool_id
     * @param \SalesForceBundle\DTO\Opportunity $opportunity
     *
     * @return string
     */
    public function updateOpportunity($pmtool_id, $opportunity)
    {
        $this->logRequest();
        $log = "UpdateOpportunity for Opportunity with PMTool id '$pmtool_id': ";
        $existing = Opportunity::getById($pmtool_id);

        if (!$existing) {
            $this->getLog()->addNotice($log.'Opportunity not found.');
            $response = '<updateOpportunityResult></updateOpportunityResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormOpportunity($existing, $opportunity, $log);
    }

    /**
     * This service gets opportunities updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\Opportunity[]
     */
    public function getUpdatedOpportunities()
    {
        $opportunities = OpportunityQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterByIsTemplate(false)
            ->filterBySfIgnore(false)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedOpportunitiesResult>';
        foreach ($opportunities as $opportunity) {
            $response .= $opportunity->toXMLForSalesForce($this->instance);
            $opportunity->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedOpportunitiesResult>';
        $this->getLog()->addNotice('GetUpdatedOpportunities: '.$opportunities->count().' identified Opportunity(ies)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service creates an account based on its SalesForce Id and XML.
     *
     * @param string                        $sf_id
     * @param \SalesForceBundle\DTO\Account $account
     *
     * @return string
     */
    public function createAccount($sf_id, $account)
    {
        $this->logRequest();
        $log = "CreateAccount for Account with Saleforce id '$sf_id': ";
        if ($existing = AccountQuery::create()->findOneBySfId($sf_id)) {
            $this->getLog()->addNotice($log.'an Account already exists with this id.');
            $response = '<createAccountResult>'.$existing->getId().'</createAccountResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormAccount((new Account())->setSfId($sf_id), $account, $log);
    }

    /**
     * This service updates an account based on its PMTool Id and XML.
     *
     * @param string                        $pmtool_id
     * @param \SalesForceBundle\DTO\Account $account
     *
     * @return string
     */
    public function updateAccount($pmtool_id, $account)
    {
        $this->logRequest();
        $log = "UpdateAccount for Account with PMTool id '$pmtool_id': ";
        $existing = Account::getById($pmtool_id);

        if (!$existing) {
            $this->getLog()->addNotice($log.'Account not found.');
            $response = '<updateAccountResult></updateAccountResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormAccount($existing, $account, $log);
    }

    /**
     * This service deletes an account based on its PMTool Id.
     *
     * @param string $pmtool_id
     *
     * @return string
     */
    public function deleteAccount($pmtool_id)
    {
        $log = "DeleteAccount for Account with PMTool id '$pmtool_id': ";

        $account = Account::getById($pmtool_id);
        if (!$account) {
            $content = 'Account not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'deleteAccountResult');
        }

        try {
            if (!$account->isDeleteable()) {
                throw new Exception('Could not delete Account '.$pmtool_id);
            }
            $account->delete();
            $message = "Account '$pmtool_id' deleted";
            $this->getLog()->addNotice($log.$message);
            $content = 'success';
        } catch (Exception $ex) {
            $this->getLog()->addNotice($log.$ex->getMessage());
            $content = 'failure';
        }

        return new \SoapVar('<deleteAccountResult>'.$content.'</deleteAccountResult>', XSD_ANYXML);
    }

    /**
     * This service replaces an account by another one based on their two PMTool Ids.
     *
     * @param string $account_to_keep_sf_id
     * @param string $account_to_delete_sf_id
     */
    public function mergeAccounts($account_to_keep_sf_id, $account_to_delete_sf_id)
    {
        $log = "MergeAccounts for Accounts with PMTool ids '$account_to_keep_sf_id' <- '$account_to_delete_sf_id': ";

        $accountToKeep = AccountQuery::create()->findOneBySfId($account_to_keep_sf_id);
        $accountToDelete = AccountQuery::create()->findOneBySfId($account_to_delete_sf_id);
        if (!$accountToKeep) {
            $content = 'Account to keep not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'mergeAccountsResult');
        }

        if (!$accountToDelete) {
            $content = 'Account to delete not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'mergeAccountsResult');
        }

        try {
            $accountToDelete->replaceBy($accountToKeep);
            if (!$accountToDelete->isDeleteable()) {
                throw new Exception('Could not delete Account '.$account_to_delete_sf_id);
            }
            $accountToDelete->delete();
            $message = "Account '$account_to_delete_sf_id' merged with '$account_to_keep_sf_id' and deleted";
            $this->getLog()->addNotice($log.$message);
            $content = 'success';
        } catch (Exception $ex) {
            $this->getLog()->addNotice($log.$ex->getMessage());
            $content = 'failure';
        }

        return new \SoapVar($content, XSD_STRING, null, null, 'mergeAccountsResult');
    }

    /**
     * This service gets recrutiment JobItems created in PMTool.
     *
     * @return \SalesForceBundle\DTO\JobItem[]
     */
    public function getNewRecruitments()
    {
        $recruitment = CategoriePrestation::getRecruitment();
        $delta = new \DateTime($this->expiration);
        $items = JobItemQuery::create()
            ->useJobQuery()
                ->filterBySfIgnore(false, Criteria::EQUAL)
                ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByCategoriePrestation($recruitment)
            ->filterBySamsId(null, Criteria::ISNULL)
            ->filterByUpdatedAt($delta, Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->orderById(Criteria::DESC)
            ->limit(self::LIMIT)
            ->find();

        $now = new \DateTime();
        $response = '<getNewRecruitmentsResult>';
        foreach ($items as $item) {
            $response .= $item->toXMLForSalesForce();
            $item->keepUpdateDateUnchanged()->setApiExposedAt($now)->save();
        }
        $response .= '</getNewRecruitmentsResult>';

        $this->getLog()->addNotice('GetNewRecruitments: '.$items->count().' identified JobItem(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets accounts updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\Account[]
     */
    public function getUpdatedAccounts()
    {
        $accounts = AccountQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterBySfId(null, Criteria::ISNOTNULL)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedAccountsResult>';
        foreach ($accounts as $account) {
            $response .= $account->toXMLForSalesForce();
            $account->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedAccountsResult>';
        $this->getLog()->addNotice('GetUpdatedAccounts: '.$accounts->count().' identified Account(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets events updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\Event[]
     */
    public function getUpdatedEvents()
    {
        $events = EventQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterBySamsEventId('', Criteria::NOT_EQUAL)
            ->useJobQuery()
                ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByStartDateTime(null, Criteria::ISNOTNULL)
            ->filterByEndDateTime(null, Criteria::ISNOTNULL)
            ->filterByRefRoomId(null, Criteria::ISNOTNULL)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedEventsResult>';
        foreach ($events as $event) {
            $response .= $event->toXMLForSalesForce();
            $event->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedEventsResult>';
        $this->getLog()->addNotice('GetUpdatedEvents: '.$events->count().' identified Event(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service creates a contact based on its SalesForce Id and XML.
     *
     * @param string                        $sf_id
     * @param \SalesForceBundle\DTO\Contact $contact
     *
     * @return string
     */
    public function createContact($sf_id, $contact)
    {
        $this->logRequest();
        $log = "CreateContact for Contact with Salesforce id '$sf_id': ";
        if ($existing = ContactQuery::create()->findOneBySfId($sf_id)) {
            $this->getLog()->addNotice($log.'a Contact already exists with this id.');
            $response = '<createContactResult>'.$existing->getId().'</createContactResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormContact((new Contact())->setSfId($sf_id), $contact, $log);
    }

    /**
     * This service updates a contact based on its PMTool Id and XML.
     *
     * @param string                        $pmtool_id
     * @param \SalesForceBundle\DTO\Contact $contact
     *
     * @return string
     */
    public function updateContact($pmtool_id, $contact)
    {
        $this->logRequest();
        $log = "UpdateContact for Contact with PMTool id '$pmtool_id': ";

        $existing = Contact::getById($pmtool_id);
        if (!$existing) {
            $this->getLog()->addNotice($log.'Contact not found.');
            $response = '<updateContactResult></updateContactResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormContact($existing, $contact, $log);
    }

    /**
     * This service deletes a contact based on its PMTool Id.
     *
     * @param string $pmtool_id
     *
     * @return string
     */
    public function deleteContact($pmtool_id)
    {
        $log = "DeleteContact for Contact with PMTool id '$pmtool_id': ";

        $contact = Contact::getById($pmtool_id);
        if (!$contact) {
            $content = 'Contact not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'deleteContactResult');
        }

        try {
            if (!$contact->isDeleteable()) {
                throw new Exception('Could not delete Contact '.$pmtool_id);
            }
            $contact->delete();
            $message = "Contact '$pmtool_id' deleted";
            $this->getLog()->addNotice($log.$message);
            $content = 'success';
        } catch (Exception $ex) {
            $this->getLog()->addNotice($log.$ex->getMessage());
            $content = 'failure';
        }

        return new \SoapVar('<deleteContactResult>'.$content.'</deleteContactResult>', XSD_ANYXML);
    }

    /**
     * This service replaces a contact by another one based on their two PMTool Ids.
     *
     * @param string $contact_to_keep_sf_id
     * @param string $contact_to_delete_sf_id
     */
    public function mergeContacts($contact_to_keep_sf_id, $contact_to_delete_sf_id)
    {
        $log = "MergeContacts for Contacts with PMTool ids '$contact_to_keep_sf_id' <- '$contact_to_delete_sf_id': ";

        $contactToKeep = ContactQuery::create()->findOneBySfId($contact_to_keep_sf_id);
        $contactToDelete = ContactQuery::create()->findOneBySfId($contact_to_delete_sf_id);
        if (!$contactToKeep) {
            $content = 'Contact to keep not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'mergeContactsResult');
        }

        if (!$contactToDelete) {
            $content = 'Contact to delete not found';
            $this->getLog()->addNotice($log.$content);

            return new \SoapVar($content, XSD_STRING, null, null, 'mergeContactsResult');
        }

        try {
            $contactToDelete->replaceBy($contactToKeep);
            if (!$contactToDelete->isDeleteable()) {
                throw new Exception('Could not delete Contact '.$contact_to_delete_sf_id);
            }
            $contactToDelete->delete();
            $message = "Contact '$contact_to_delete_sf_id' merged with '$contact_to_keep_sf_id' and deleted";
            $this->getLog()->addNotice($log.$message);
            $content = 'success';
        } catch (Exception $ex) {
            $this->getLog()->addNotice($log.$ex->getMessage());
            $content = 'failure';
        }

        return new \SoapVar($content, XSD_STRING, null, null, 'mergeContactsResult');
    }

    /**
     * This service gets contacts updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\Contact[]
     */
    public function getUpdatedContacts()
    {
        $contacts = ContactQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterBySfId(null, Criteria::ISNOTNULL)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedContactsResult>';
        foreach ($contacts as $contact) {
            $response .= $contact->toXMLForSalesForce();
            $contact->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedContactsResult>';
        $this->getLog()->addNotice('GetUpdatedContacts: '.$contacts->count().' identified Contact(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets contacts created in PMTool.
     *
     * @return \SalesForceBundle\DTO\Contact[]
     */
    public function getNewContacts()
    {
        $contacts = ContactQuery::create()
            ->filterBySfId(null, Criteria::ISNULL)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getNewContactsResult>';
        foreach ($contacts as $contact) {
            $response .= $contact->toXMLForSalesForce();
        }
        $response .= '</getNewContactsResult>';

        $this->getLog()->addNotice('GetNewContacts: '.$contacts->count().' identified Contact(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets events created in PMTool.
     *
     * @return \SalesForceBundle\DTO\Event[]
     */
    public function getNewEvents()
    {
        $events = EventQuery::create()
            ->useRefEventStatusQuery()
                ->filterByName([RefEventStatus::TENTATIVE, RefEventStatus::RELEASED, RefEventStatus::CANCELLED_NON_BILLED], Criteria::NOT_IN)
            ->endUse()
            ->useJobQuery()
                ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByStartDateTime(null, Criteria::ISNOTNULL)
            ->filterByEndDateTime(null, Criteria::ISNOTNULL)
            ->filterByRefRoomId(null, Criteria::ISNOTNULL)
            ->filterBySamsEventId('')
            ->limit(self::LIMIT)
            ->find();

        $response = '<getNewEventsResult>';
        foreach ($events as $event) {
            $response .= $event->toXMLForSalesForce();
        }
        $response .= '</getNewEventsResult>';

        $this->getLog()->addNotice('GetNewEvents: '.$events->count().' identified Event(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets job items created in PMTool.
     *
     * @return \SalesForceBundle\DTO\JobItem[]
     */
    public function getNewJobItems()
    {
        $delta = new \DateTime($this->expiration);
        $items = JobItemQuery::create()
            ->useJobQuery()
                ->filterBySfIgnore(false, Criteria::EQUAL)
                ->filterByJobSfId(null, Criteria::ISNOTNULL)
                ->filterByAcctChecked(true)
            ->endUse()
            ->filterBySfIgnore(false, Criteria::EQUAL)
            ->filterByPrixVente(0, Criteria::NOT_EQUAL)
            ->filterBySfId(null, Criteria::ISNULL)
            ->filterByUpdatedAt($delta, Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->orderById(Criteria::DESC)
            ->limit(self::LIMIT)
            ->find();

        $now = new \DateTime();
        $response = '<getNewJobItemsResult>';
        foreach ($items as $item) {
            $response .= $item->toXMLForSalesForce();
            if (!$item->getApiExposedAt()) {
                $item->setApiExposedAt($now)->save(); // consider it changed so it is exposed during $delta
            } else {
                $item->keepUpdateDateUnchanged()->setApiExposedAt($now)->save(); // just store it was exposed
            }
        }
        $response .= '</getNewJobItemsResult>';

        $this->getLog()->addNotice('GetNewJobItems: '.$items->count().' identified JobItem(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets jobs created in PMTool.
     *
     * @return \SalesForceBundle\DTO\Job[]
     */
    public function getNewJobs()
    {
        $delta = new \DateTime($this->expiration);
        $jobs = JobQuery::create()
            ->useStatusQuery()
                ->filterByValue(RefSalesForce::JOB_STATUSES_SALESFORCE, Criteria::IN)
            ->endUse()
            ->filterBySfIgnore(false, Criteria::EQUAL)
            ->filterByJobSfId(null, Criteria::ISNULL)
            ->filterByApiUpdatedDate($delta, Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->orderById(Criteria::ASC)
            ->limit(self::LIMIT)
            ->find();

        $noMasterProjectNb = [];
        $now = new \DateTime();
        $response = '<getNewJobsResult>';
        $total = 0;
        foreach ($jobs as $job) {
            // if Project has no MP number, only allow 1 Job
            if (!$job->getEtude()->getMasterProjectNumber()) {
                $id = $job->getEtudeId();
                if (isset($noMasterProjectNb[$id])) {
                    continue;
                } else {
                    $noMasterProjectNb[$id] = true;
                }
            }
            $response .= $job->toXMLForSalesForce();
            ++$total;
            $job->keepUpdateDateUnchanged()->setApiExposedAt($now)->save();
        }
        $response .= '</getNewJobsResult>';

        $this->getLog()->addNotice('GetNewJobs: '.$total.' identified Jobs(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets opportunities created in PMTool.
     *
     * @return \SalesForceBundle\DTO\Opportunity[]
     */
    public function getNewOpportunities()
    {
        $delta = new \DateTime($this->expiration);
        $opportunities = OpportunityQuery::create()
            ->filterBySfIgnore(false)
            ->filterByIsTemplate(false)
            ->filterBySfId(null, Criteria::ISNULL)
            ->filterByApiUpdatedDate($delta, Criteria::GREATER_EQUAL)
            ->_or()
            ->filterByApiExposedAt(null, Criteria::ISNULL)
            ->orderById(Criteria::DESC)
            ->limit(self::LIMIT)
            ->find();

        $now = new \DateTime();
        $response = '<getNewOpportunitiesResult>';
        foreach ($opportunities as $opportunity) {
            $response .= $opportunity->toXMLForSalesForce($this->instance);
            $opportunity->keepUpdateDateUnchanged()->setApiExposedAt($now)->save();
        }
        $response .= '</getNewOpportunitiesResult>';

        $this->getLog()->addNotice('GetNewOpportunities: '.$opportunities->count().' identified Opportunity(ies)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets recruitment job items updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\JobItem[]
     */
    public function getUpdatedRecruitments()
    {
        $recruitment = CategoriePrestation::getRecruitment();
        $jobItems = JobItemQuery::create()
            ->filterByCategoriePrestation($recruitment)
            ->filterByPmtoolUpdated(true)
            ->filterBySamsId(null, Criteria::ISNOTNULL)
            ->orderById(Criteria::DESC)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedRecruitmentsResult>';
        foreach ($jobItems as $jobItem) {
            $response .= $jobItem->toXMLForSalesForce();
            $jobItem->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedRecruitmentsResult>';

        $this->getLog()->addNotice('GetUpdatedRecruitments: '.$jobItems->count().' identified JobItem(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service gets jobs updated in PMTool.
     *
     * @return \SalesForceBundle\DTO\Job[]
     */
    public function getUpdatedJobs()
    {
        $jobs = JobQuery::create()
            ->filterByPmtoolUpdated(true)
            ->filterByJobSfId(null, Criteria::ISNOTNULL)
            ->orderById(Criteria::DESC)
            ->limit(self::LIMIT)
            ->find();

        $response = '<getUpdatedJobsResult>';
        foreach ($jobs as $job) {
            $response .= $job->toXMLForSalesForce();
            $job->setPmtoolUpdated(false)->save();
        }
        $response .= '</getUpdatedJobsResult>';

        $this->getLog()->addNotice('GetUpdatedJobs: '.$jobs->count().' identified Job(s)');

        return new \SoapVar($response, XSD_ANYXML);
    }

    /**
     * This service updates a job based on its PMTool Id and XML.
     *
     * @param string                    $pmtool_id
     * @param \SalesForceBundle\DTO\Job $job
     *
     * @return string
     */
    public function updateJob($pmtool_id, $job)
    {
        $this->logRequest();
        $log = "UpdateJob for Job with PMTool id '$pmtool_id': ";
        $existing = Job::getById($pmtool_id);
        if (!$existing) {
            $this->getLog()->addNotice($log.'Job not found.');
            $response = '<updateJobResult></updateJobResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        return $this->processFormJob($existing, $job, $log);
    }

    /**
     * This service sets the Salesforce Id for a job item based on its PMTool Id.
     *
     * @param string $pmtool_id
     * @param string $sf_id
     *
     * @return string
     */
    public function updateJobItem($pmtool_id, $sf_id)
    {
        $tag = 'updateJobItemResult';
        $log = "UpdateJobItem '$sf_id' for JobItem with PMTool id '$pmtool_id': ";
        $jobItem = JobItemQuery::create()->findOneById($pmtool_id);
        if (!$jobItem) {
            $result = 'JobItem not found';
            $this->getLog()->addNotice($log.$result);

            return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
        }

        $result = '';
        $form = $this->formFactory->createBuilder(FormType::class, $jobItem, ['csrf_protection' => false])
            ->add('sf_id', TextType::class, [
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->getForm();

        $form->submit(['sf_id' => $sf_id]);

        if ($form->isSubmitted() && $form->isValid()) {
            $jobItem->save();
            $this->getLog()->addNotice($log.$jobItem->getId().' updated');
            $result = 'success';
        } else {
            $result = (string) $this->getFormErrors($form, JobItem::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    /**
     * This service sets the SAMS Id for a recruitment job item based on its PMTool Id.
     *
     * @param string $pmtool_id
     * @param string $sams_id
     *
     * @return string
     */
    public function updateRecruitment($pmtool_id, $sams_id)
    {
        $tag = 'updateRecruitmentResult';
        $log = "UpdateRecruitment '$sams_id' for JobItem with PMTool id '$pmtool_id': ";
        $jobItem = JobItemQuery::create()->findOneById($pmtool_id);
        if (!$jobItem) {
            $result = 'JobItem not found';
            $this->getLog()->addNotice($log.$result);

            return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
        }

        $form = $this->formFactory->createBuilder(FormType::class, $jobItem, ['csrf_protection' => false])
            ->add('sams_id', TextType::class, [
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->getForm();

        $form->submit(['sams_id' => $sams_id]);

        $result = '';
        if ($form->isSubmitted() && $form->isValid()) {
            $jobItem->save();
            $this->getLog()->addNotice($log.$jobItem->getId().' updated');
            $result = 'success';
        } else {
            $result = (string) $this->getFormErrors($form, JobItem::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    /**
     * This service updates an event based on its PMTool Id or SAMS Id and XML.
     *
     * @param string                      $id
     * @param \SalesForceBundle\DTO\Event $event
     *
     * @return string
     */
    public function updateEvent($id, $event)
    {
        $this->logRequest();
        $log = "UpdateEvent for Event with PMTool or SAMS id '$id': ";
        $existing = trim($id) ? EventQuery::create()->filterBySamsEventId($id)->_or()->filterById($id)->findOne() : null;

        if (!$existing) {
            $result = 'Event not found';
            $this->getLog()->addNotice($log.$result);
            $response = '<updateEventResult>'.$result.'</updateEventResult>';

            return new \SoapVar($response, XSD_ANYXML);
        }

        $existing->keepUpdateDateUnchanged()->setApiUpdatedDate(new \DateTime());

        return $this->processFormEvent($existing, $event, $log);
    }

    /* Event Process Form */
    private function processFormEvent(Event $event, $event_dto, $log)
    {
        $isNew = $event->isNew();
        $tag = $isNew ? 'createEventResult' : 'updateEventResult';
        if (!$event_dto) {
            $result = 'empty data';
            $this->getLog()->addNotice($log.$result);

            return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
        }

        $requestData = $this->getEventMappingArrayForForm($event->toArrayWithCollection(), $event_dto);

        $form = $this->formFactory->create(EventType::class, $event);

        $form->submit($requestData);
        $result = '';
        if ($form->isSubmitted() && $form->isValid()) {
            $event->setAccountsAndContactsFromSalesForce()
                ->setPmtoolUpdated(true); // put it to true then false so it stays false in preSave

            try {
                $event->setPmtoolUpdated(false)->save();
                $this->getLog()->addNotice($log.($isNew ? $event->getId().' created' : 'updated'));
                $result = $isNew ? $event->getId() : 'success';
            } catch (PropelException $e) {
                $this->logException($e, $log);
                $result = $e->getMessage();
            }
        } else {
            $result = (string) $this->getFormErrors($form, Opportunity::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    private function getEventMappingArrayForForm($eventArray, $event_dto)
    {
        foreach ($event_dto as $key => $value) {
            if (in_array($key, Event::FIELDS_PICKLIST) && ($value || '0' === $value)) {
                if ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_EVENT, $key, $value)) {
                    $value = $ref->getId();
                }
            } elseif (in_array($key, Event::FIELDS_USER) && $value) {
                $existing = UserQuery::create()->filterBySfId($value)->findOne();
                $value = $existing ? $value : User::getDefaultSfId();
            }

            $eventArray[$key] = $value;
        }

        return $eventArray;
    }

    /* Opportunity Process Form */
    private function processFormOpportunity(Opportunity $opportunity, $opportunity_dto, $log)
    {
        $isNew = $opportunity->isNew();
        $tag = $isNew ? 'createOpportunityResult' : 'updateOpportunityResult';
        if (!$opportunity_dto) {
            $result = 'empty data';
            $this->getLog()->addNotice($log.$result);

            return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
        }

        $result = '';
        $requestData = $this->getOpportunityMappingArrayForForm($opportunity->toArrayForForm($this->instance), $opportunity_dto);
        $form = $this->formFactory->create(OpportunityType::class, $opportunity, [
            'instance' => $this->instance, // FIXME use parameter binding instead
        ]);
        $form->submit($requestData);
        if ($form->isSubmitted() && $form->isValid()) {
            $opportunity->setAccountsAndContactsFromSalesForce()->setPmtoolUpdated(false);
            try {
                $opportunity->save();
                $this->getLog()->addNotice($log.($isNew ? $opportunity->getId().' created' : 'updated'));
                $result = $isNew ? $opportunity->getId() : 'success';
                if ($isNew) {
                    $folder = $this->spManager->createFolder($opportunity);
                    $opportunity->setSharepointFolder($folder)->save();
                }
            } catch (PropelException $e) {
                $this->logException($e, $log);
                $result = $e->getMessage();
            }
        } else {
            $result = (string) $this->getFormErrors($form, Opportunity::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    /* Account Process Form */
    private function processFormAccount(Account $account, $account_dto, $log)
    {
        $isNew = $account->isNew();
        $requestData = $this->getAccountMappingArrayForForm($account->toArrayForForm(), $account_dto);
        $form = $this->formFactory->create(AccountType::class, $account);
        $form->submit($requestData);

        $tag = $isNew ? 'createAccountResult' : 'updateAccountResult';
        $result = '';
        if ($form->isSubmitted() && $form->isValid()) {
            try {
                $account->setPmtoolUpdated(false)->save();
                $this->getLog()->addNotice($log.($isNew ? $account->getId().' created' : 'updated'));
                $result = $isNew ? $account->getId() : 'success';
            } catch (PropelException $e) {
                $this->logException($e, $log);
                $result = $e->getMessage();
            }
        } else {
            $result = (string) $this->getFormErrors($form, Account::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    /* Contact Process Form */
    private function processFormContact(Contact $contact, $contact_dto, $log)
    {
        $isNew = $contact->isNew();
        $requestData = $this->getContactMappingArrayForForm($contact->toArrayForForm(), $contact_dto);
        $form = $this->formFactory->create(ContactType::class, $contact);
        $form->submit($requestData);

        $tag = $isNew ? 'createContactResult' : 'updateContactResult';
        $result = '';
        if ($form->isSubmitted() && $form->isValid()) {
            if ($contact->getAccountSfId() && (!$contact->getAccountId() || in_array(ContactTableMap::COL_ACCOUNT_SF_ID, $contact->getModifiedColumns()))) {
                $account = AccountQuery::create()->findOneBySfId($contact->getAccountSfId());
                if ($account) {
                    $contact->setAccountId($account->getId());
                }
            }

            try {
                $contact->setPmtoolUpdated(false)->save();
                $this->getLog()->addNotice($log.($isNew ? $contact->getId().' created' : 'updated'));
                $result = $isNew ? $contact->getId() : 'success';
            } catch (PropelException $e) {
                $this->logException($e, $log);
                $result = $e->getMessage();
            }
        } else {
            $result = (string) $this->getFormErrors($form, Contact::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar("<$tag>$result</$tag>", XSD_ANYXML);
    }

    /* Job Process Form */
    private function processFormJob(Job $job, $job_dto, $log)
    {
        $requestData = $this->getJobMappingArrayForForm($job->toArrayForForm(), $job_dto);
        $form = $this->formFactory->create(JobType::class, $job);
        $form->submit($requestData);

        $result = 'success';
        if ($form->isSubmitted() && $form->isValid()) {
            $etude = $job->getEtude();
            if ($etude->getMasterProjectNumber()) {
                $ref = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_ETUDE)
                    ->filterByField('german_job_type_id')
                    ->filterByValue('Germany')
                    ->findOne();
                if ($ref) {
                    $etude->setGermanJobTypeId($ref->getId());
                }
            }
            try {
                $job->setPmtoolUpdated(false)->save();
                $this->getLog()->addNotice($log.' updated');
            } catch (PropelException $e) {
                $this->logException($e, $log);
                $result = $e->getMessage();
            }

            $etude->save();
        } else {
            $result = (string) $this->getFormErrors($form, Job::class);
            $this->getLog()->addNotice($log.$result);
        }

        return new \SoapVar('<updateJobResult>'.$result.'</updateJobResult>', XSD_ANYXML);
    }

    private function getFormErrors($iterator, $class)
    {
        $errors = $iterator instanceof FormInterface ? $iterator->getErrors(true, false) : $iterator;
        $form = $iterator instanceof FormInterface ? $iterator : $iterator->getForm();
        $serviceErrors = '';
        while ($errors->valid()) {
            $error = $errors->current();

            if (0 === $errors->count()) {
                continue;
            }

            if ($error instanceof FormErrorIterator) {
                if (0 === $error->count()) {
                    continue;
                }
                $serviceErrors .= $this->getFormErrors($error, $class);
            } else {
                $explanation = $this->getExplanation($error) ? ' ('.$this->getExplanation($error).')' : '';
                $serviceErrors .= $class::getFieldNamePmtoolToSalesForce($form->getName()).' : '.$error->getMessage().$explanation.', ';
            }
            $errors->next();
        }

        return $serviceErrors;
    }

    private function getExplanation(FormError $error)
    {
        $cause = $error->getCause();
        if ($cause instanceof ConstraintViolation) {
            echo $cause;
            $data = $cause->getInvalidValue();

            return is_array($data) ? implode(', ', array_keys($data)) : $data;
        }

        return '';
    }

    private function getOpportunityMappingArrayForForm($opportunityArray, $opportunity_dto)
    {
        foreach ($opportunity_dto as $key => $value) {
            $bddKey = Opportunity::getFieldNameSalesForceToPmtool($key);

            if ('account_manager' == $key && !$value) {
                $value = User::getDefaultSfId();
            } elseif (in_array($bddKey, Opportunity::FIELDS_MULTIPICKLIST)) {
                if ('' === $value) {
                    $value = null;
                }
                if (!$value) {
                    continue;
                }
                $multiplePickListValues = [];
                $values = explode(';', $value);
                foreach ($values as $value) {
                    if ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, $bddKey, $value)) {
                        $multiplePickListValues[] = $ref->getId();
                    }
                }
                $value = $multiplePickListValues;
            } elseif (in_array($bddKey, Opportunity::FIELDS_PICKLIST) && isset($value) && ($value || '0' === $value)) {
                if ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, $bddKey, $value)) {
                    $value = $ref->getId();
                }
            } elseif (in_array($bddKey, Opportunity::FIELDS_PICKLIST_INDUSTRIES) && $value) {
                if ($ref = IndustryQuery::create()->findOneBySfLabel($value)) {
                    $value = $ref->getId();
                }
            } elseif (in_array($bddKey, Opportunity::FIELDS_PICKLIST_USER) && $value) {
                $refs = UserQuery::create()->filterBySfId('', Criteria::NOT_EQUAL)->find()->toKeyIndex('SfId');
                $value = isset($refs[$value]) ? $value : User::getDefaultSfId();
            } elseif (in_array($bddKey, Opportunity::FIELDS_MULTIPICKLIST_LOCATIONS) && $value) {
                $multiplePickListValues = [];
                $values = explode(';', $value);
                foreach ($values as $value) {
                    if ($ref = LocationQuery::create()->findOneBySfLabel($value)) {
                        $multiplePickListValues[] = $ref->getId();
                    }
                }
                $value = $multiplePickListValues;
            } elseif (in_array($bddKey, Opportunity::FIELDS_MULTIPICKLIST_METHODOLOGIES) && $value) {
                $multiplePickListValues = [];
                $values = explode(';', $value);
                foreach ($values as $value) {
                    if ($ref = MethodologyQuery::create()->findOneBySfLabel($value)) {
                        $multiplePickListValues[] = $ref->getId();
                    }
                }
                $value = $multiplePickListValues;
            }

            $opportunityArray[$bddKey] = $value;
        }

        return $opportunityArray;
    }

    private function getAccountMappingArrayForForm($accountArray, $account_dto)
    {
        foreach ($account_dto as $key => $value) {
            $bddKey = Account::getFieldNameSalesForceToPmtool($key);

            if (in_array($bddKey, Account::FIELDS_MULTIPICKLIST)) {
                if ('' === $value) {
                    $value = null;
                }
                if (!$value) {
                    continue;
                }
                $multiplePickListValues = [];
                $values = explode(';', $value);
                foreach ($values as $value) {
                    if ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_ACCOUNT, $bddKey, $value)) {
                        $multiplePickListValues[] = $ref->getId();
                    }
                }

                $value = $multiplePickListValues;
            }

            if (in_array($bddKey, Account::FIELDS_PICKLIST) && isset($value) && ($value || '0' === $value) && ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_ACCOUNT, $bddKey, $value))) {
                $value = $ref->getId();
            }

            $accountArray[$bddKey] = $value;
        }

        return $accountArray;
    }

    private function getContactMappingArrayForForm($contactArray, $contact_dto)
    {
        foreach ($contact_dto as $key => $value) {
            $bddKey = Contact::getFieldNameSalesForceToPmtool($key);

            if (in_array($bddKey, Contact::FIELDS_MULTIPICKLIST)) {
                if ('' === $value) {
                    $value = null;
                }
                if (!$value) {
                    continue;
                }
                $multiplePickListValues = [];
                $values = explode(';', $value);
                foreach ($values as $value) {
                    if ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_CONTACT, $bddKey, $value)) {
                        $multiplePickListValues[] = $ref->getId();
                    }
                }

                $value = $multiplePickListValues;
            }

            if (in_array($bddKey, Contact::FIELDS_PICKLIST) && isset($value) && ($value || '0' === $value) && ($ref = $this->findOrUpdateRefSalesforceValue(RefSalesForceTableMap::COL_TABLE_CONTACT, $bddKey, $value))) {
                $value = $ref->getId();
            }

            $contactArray[$bddKey] = $value;
        }

        return $contactArray;
    }

    private function getJobMappingArrayForForm($jobArray, $job_dto)
    {
        foreach ($job_dto as $key => $value) {
            $bddKey = Job::getFieldNameSalesForceToPmtool($key);
            if (is_array($bddKey) && isset($bddKey['etude'])) {
                foreach ($bddKey as $bddEtudeKey) {
                    $jobArray['etude'][$bddEtudeKey] = $value;
                }
            }

            if (!is_array($bddKey) && $bddKey != $key) {
                $jobArray[$bddKey] = $value;
            }
        }

        return $jobArray;
    }

    private function findOrUpdateRefSalesforceValue($table, $field, $value)
    {
        $ref = RefSalesForceQuery::create()
            ->filterByTable($table)
            ->filterByField($field)
            ->filterByValue($value)
            ->findOneOrCreate();

        if ($ref->isNew()) {
            $ref->setTable($table)
                ->setLabel($field)
                ->setField($field)
                ->setValue($value);
        }

        $ref->setActif(true)->save();

        return $ref;
    }
}
