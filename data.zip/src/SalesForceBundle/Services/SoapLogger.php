<?php

namespace SalesForceBundle\Services;

use Monolog\Handler\StreamHandler;
use Symfony\Bridge\Monolog\Logger;
use Zend\Soap\Server;

class SoapLogger
{
    protected $instance;
    protected $log_dir;
    protected $logger;

    private $server;

    public function __construct(string $instance, string $log_dir)
    {
        $this->instance = $instance;
        $this->log_dir = $log_dir;
    }

    public function getLogger()
    {
        return $this->logger ?: $this->logger = (new Logger('api_scribe'))
            ->pushHandler(new StreamHandler($this->log_dir.'/api_scribe_'.$this->instance.'_'.date('Y-m-d').'.log'));
    }

    public function logRequest()
    {
        return $this->server ? $this->getLogger()->addNotice($this->server->getLastRequest()) : false;
    }

    public function setServer(Server $server)
    {
        $this->server = $server;

        return $this;
    }
}
