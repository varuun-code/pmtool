<?php

namespace Datagrid;

use Model\LocationQuery;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class LocationDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return LocationQuery::create();
    }

    public function configureFilter()
    {
        return [
            'libelle' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'active' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'sf_label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'gqs_available' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'GQS Available/Not available',
                    'choices' => [
                        'Available' => '1',
                        'Not available' => 0,
                    ],
                ],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'libelle';
    }

    public function getName()
    {
        return 'location';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
