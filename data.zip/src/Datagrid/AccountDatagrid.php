<?php

namespace Datagrid;

use Model\ContactQuery;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class AccountDatagrid extends PropelDatagrid
{
    public function configureFilter()
    {
        return [
            'name' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                    'data' => '',
                ],
            ],
            'name_legal' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                    'data' => '',
                ],
            ],
            'billing_country' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                    'data' => '',
                ],
            ],
            'discount_program' => [
                'type' => ModelType::class,
                'options' => [
                    'label' => 'Qual Discount Program',
                    'required' => false,
                    'multiple' => true,
                    'query' => RefSalesForceQuery::create()
                        ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                        ->filterByField('discount_program_id')
                        ->filterByActif(true)
                        ->orderByLabel(),
                    'class' => RefSalesForce::class,
                ],
            ],
        ];
    }

    public function configureQuery()
    {
        return ContactQuery::create();
    }

    public function getDefaultSortColumn()
    {
        return 'apiCreatedDate';
    }

    public function getName()
    {
        return 'sf_account';
    }

    public function getMaxPerPage()
    {
        return 15;
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }
}
