<?php

namespace Datagrid\Referentiel;

use Model\DiscountOnQuery;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class DiscountOnDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return DiscountOnQuery::create();
    }

    public function configureFilter()
    {
        return [
            'libelle' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'actif' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'sf_label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'ordre' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'ordre';
    }

    public function getName()
    {
        return 'discount-on';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
