<?php

namespace Datagrid\Referentiel;

use Model\EventMethodologyQuery;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class EventMethodologyDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return EventMethodologyQuery::create();
    }

    public function configureFilter()
    {
        return [
            'label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'active' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'sams_label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'rank' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'rank';
    }

    public function getName()
    {
        return 'event-methodology';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
