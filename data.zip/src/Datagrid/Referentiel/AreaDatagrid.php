<?php

namespace Datagrid\Referentiel;

use Model\AreaQuery;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class AreaDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return AreaQuery::create();
    }

    public function configureFilter()
    {
        return [
            'libelle' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'actif' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'sf_label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'ordre' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'sector' => [
                'type' => ModelType::class,
                'options' => [
                    'label' => 'Sector',
                    'required' => false,
                    'multiple' => true,
                    'query' => RefSalesForceQuery::create()
                        ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                        ->filterByField('sectors')
                        ->filterByActif(true)
                        ->orderByLabel(),
                    'class' => RefSalesForce::class,
                ],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'ordre';
    }

    public function getName()
    {
        return 'area';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
