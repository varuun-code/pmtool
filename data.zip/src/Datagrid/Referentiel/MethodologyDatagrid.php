<?php

namespace Datagrid\Referentiel;

use Model\MethodologyQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class MethodologyDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return MethodologyQuery::create();
    }

    public function configureFilter()
    {
        return [
            'actif' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'sf_label' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'ordre' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'typeEtudeOrdre' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'typeEtude' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'typeEtudeBr' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'typeEtudeAlias' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'consolidation' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'methodology_job_qualification' => [
                'type' => ModelType::class,
                'options' => [
                    'required' => false,
                    'label' => 'Job Qualification',
                    'placeholder' => 'Choose a job qualification',
                    'query' => RefSalesForceQuery::create()
                        ->filterByField('job_qualification_id')
                        ->filterByActif(true)
                        ->orderByLabel(),
                    'class' => RefSalesForce::class,
                ],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'ordre';
    }

    public function getName()
    {
        return 'methodology';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
