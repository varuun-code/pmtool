<?php

namespace Datagrid;

use Model\Location;
use Model\LocationQuery;
use Model\RefRoomQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class RefRoomDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return RefRoomQuery::create()->leftJoinWithLocation();
    }

    public function configureFilter()
    {
        return [
            'name' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'active' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'location' => [
                'options' => [
                    'query' => LocationQuery::create()->orderByLibelle(),
                    'required' => false,
                    'class' => Location::class,
                    'multiple' => false,
                    'expanded' => false,
                ],
                'type' => ModelType::class,
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'name';
    }

    public function getName()
    {
        return 'room';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
