<?php

namespace Datagrid;

use Model\DiscountProgramQuery;
use Model\Map\DiscountProgramTableMap;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class DiscountProgramDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return DiscountProgramQuery::create();
    }

    public function configureFilter()
    {
        return [
            'name' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
            'active' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Active/Inactive',
                    'choices' => [
                        'Active' => '1',
                        'Inactive' => 0,
                    ],
                ],
            ],
            'groupe' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Groupe',
                    'choices' => [
                        DiscountProgramTableMap::COL_GROUPE_PREFERRED => DiscountProgramTableMap::COL_GROUPE_PREFERRED,
                        DiscountProgramTableMap::COL_GROUPE_REBATE_AMOUNT => DiscountProgramTableMap::COL_GROUPE_REBATE_AMOUNT,
                        DiscountProgramTableMap::COL_GROUPE_CREDIT => DiscountProgramTableMap::COL_GROUPE_CREDIT,
                    ],
                ],
            ],
            'type' => [
                'type' => ChoiceType::class,
                'options' => [
                    'required' => false,
                    'placeholder' => 'Type',
                    'choices' => [
                        DiscountProgramTableMap::COL_TYPE_QUAL => DiscountProgramTableMap::COL_TYPE_QUAL,
                        DiscountProgramTableMap::COL_TYPE_QUANT => DiscountProgramTableMap::COL_TYPE_QUANT,
                    ],
                ],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'id';
    }

    public function getName()
    {
        return 'discountProgram';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
