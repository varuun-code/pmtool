<?php

namespace Datagrid;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\Map\OpportunityTableMap;
use Model\Opportunity;
use Model\OpportunityQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class OpportunityDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        $is_template = false;
        if (isset($this->options['is_template']) && !is_null($this->options['is_template'])) {
            $is_template = true;
        }

        $query = OpportunityQuery::create()
                ->filterByIsTemplate($is_template)
                ->filterByIsDeleted(false)
                ->_if($is_template)
                    ->filterByPmtoolCreatedById($this->options['user_id'] ?? '', Criteria::EQUAL)
                    ->_or()
                    ->filterByTemplateScope(OpportunityTableMap::COL_TEMPLATE_SCOPE_PUBLIC, Criteria::EQUAL)
                ->_endif();
        if (isset($this->options['query_number']) && !is_null($this->options['query_number'])) {
            $ids = $_SESSION['requete'][$this->options['query_number']];
            $query = $query->filterById(explode(',', $ids), Criteria::IN);
        }

        return $query;
    }

    public function configureFilter()
    {
        $is_template = false;
        if (isset($this->options['is_template']) && !is_null($this->options['is_template'])) {
            $is_template = true;
        }

        if ($is_template) {
            return [
            'template_title' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'opportunity_subject' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'template_type' => [
                'type' => ChoiceType::class,
                'options' => [
                    'label' => 'Template Type',
                    'multiple' => false,
                    'required' => false,
                    'placeholder' => 'Select a template Type',
                    'choices' => Opportunity::getTemplateTypes(),
                ],
            ],
            'template_scope' => [
                'type' => ChoiceType::class,
                'options' => [
                    'label' => 'Template Scope',
                    'multiple' => false,
                    'required' => false,
                    'placeholder' => 'Select a template Scope',
                    'choices' => Opportunity::getTemplateScopes(),
                ],
            ],
            'pmtool_created_by' => [
                'type' => Select2HiddenPropelType::class,
                'options' => [
                    'label' => 'Owner',
                    'multiple' => false,
                    'required' => false,
                    'property' => 'pmtoolCreatedBy',
                    'empty_value' => 'Select an opportunity owner',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => UserQuery::create(),
                    'choices' => 'opportunity_search_by_creator_name',
                    'init_choices' => 'opportunity_search_by_creator_name_init',
                    'class' => User::class,
                ],
            ],
            ];
        } else {
            return [
            'opportunity_subject' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'id' => [
                'type' => IntegerType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'bidnumber2' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'zendesk_ticket_id' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'account' => [
                'type' => Select2HiddenPropelType::class,
                'options' => [
                    'label' => 'Client',
                    'multiple' => false,
                    'required' => false,
                    'property' => 'getNameforPicklist',
                    'empty_value' => 'Select a client',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => AccountQuery::create(),
                    'choices' => 'account_search_by_name',
                    'init_choices' => 'account_search_by_name_init',
                    'class' => Account::class,
                ],
            ],
            'contact' => [
                'type' => Select2HiddenPropelType::class,
                'options' => [
                    'label' => 'Contact',
                    'multiple' => false,
                    'required' => false,
                    'property' => 'id',
                    'empty_value' => 'Select a contact',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => ContactQuery::create(),
                    'choices' => 'contact_search_by_name',
                    'init_choices' => 'contact_search_by_name_init',
                    'class' => Contact::class,
                    'custom_ajax_json' => "
                    ajax: {
                        url: '/index.php/contact/search-by-name',
                        datatype: 'jsonp',
                        quietMillis: 100,
                        data: function(term, page) {
                            return {
                                filters: {'AccountId': $('#filter_sf_opportunity_account').val() },
                                term: term,
                                page: page,
                                max_per_page: 10
                            };
                        },
                        results: function(data, page) {
                            var more = false;
                            if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                                more = (page * data.maxPerPage) < data.total;
                            }
                            return {
                                results: data.results,
                                more: more
                            };
                        }
                    }",
                ],
            ],
            'pmtool_created_by' => [
                'type' => Select2HiddenPropelType::class,
                'options' => [
                    'label' => 'Owner',
                    'multiple' => false,
                    'required' => false,
                    'property' => 'pmtoolCreatedBy',
                    'empty_value' => 'Select an opportunity owner',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => UserQuery::create(),
                    'choices' => 'opportunity_search_by_creator_name',
                    'init_choices' => 'opportunity_search_by_creator_name_init',
                    'class' => User::class,
                ],
            ],
            'stage_name' => [
                'type' => ModelType::class,
                'options' => [
                    'label' => 'Stage',
                    'multiple' => false,
                    'required' => false,
                    'placeholder' => 'Select a stage name',
                    'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('stage_name_id'),
                    'class' => RefSalesForce::class,
                ],
            ],
            'job_qualification' => [
                'type' => ModelType::class,
                'options' => [
                    'label' => 'Job Qualifcation',
                    'multiple' => false,
                    'required' => false,
                    'placeholder' => 'Select a job qualification',
                    'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('job_qualification_id')->filterByTable('opportunity'),
                    'class' => RefSalesForce::class,
                ],
            ],
        ];
        }
    }

    public function getName()
    {
        return 'sf_opportunity';
    }

    public function getMaxPerPage()
    {
        return 15;
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }

    public function getDefaultSortColumn()
    {
        return 'apiCreatedDate';
    }
}
