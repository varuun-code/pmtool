<?php

namespace Datagrid;

use Model\Map\NewsUpdateTableMap;
use Model\NewsUpdate;
use Model\NewsUpdateQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class NewsUpdateDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return NewsUpdateQuery::create()->filterByStatus(NewsUpdateTableMap::COL_STATUS_DELETED, Criteria::NOT_EQUAL);
    }

    public function configureFilter()
    {
        return [
            'news_title' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'site_name' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
             'status' => [
                'type' => ChoiceType::class,
                'options' => [
                    'label' => 'Status',
                    'multiple' => false,
                    'required' => false,
                    'placeholder' => 'Select a status',
                    'choices' => NewsUpdate::getStatusTypes(),
                ],
            ],
        ];
    }

    public function getName()
    {
        return 'news_update';
    }

    public function getMaxPerPage()
    {
        return 15;
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }

    public function getDefaultSortColumn()
    {
        return 'CreatedAt';
    }
}
