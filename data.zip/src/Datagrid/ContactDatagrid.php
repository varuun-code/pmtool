<?php

namespace Datagrid;

use Model\ContactQuery;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class ContactDatagrid extends PropelDatagrid
{
    public function configureFilter()
    {
        return [
            'last_name' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'first_name' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'email' => [
                'type' => TextType::class,
                'options' => [
                    'required' => false,
                ],
            ],
            'contact_status' => [
                'type' => ModelType::class,
                'options' => [
                    'label' => 'Status',
                    'required' => false,
                    'multiple' => true,
                    'query' => RefSalesForceQuery::create()
                        ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                        ->filterByField('contact_status_id')
                        ->filterByActif(true)
                        ->orderByLabel(),
                    'class' => RefSalesForce::class,
                ],
            ],
        ];
    }

    public function configureQuery()
    {
        return ContactQuery::create()->filterbyAccount($this->options['account']);
    }

    public function getDefaultSortColumn()
    {
        return 'apiCreatedDate';
    }

    public function getName()
    {
        return 'sf_contact';
    }

    public function getMaxPerPage()
    {
        return 15;
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }
}
