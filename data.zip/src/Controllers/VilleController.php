<?php

namespace Controllers;

use Model\Ville;
use Model\VilleQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VilleController extends BaseController
{
    /**
     * @Route(name="city", path="/ville")
     */
    public function indexAction(Request $request): Response
    {
        return $this->render('pmtool/pages/ville.html.twig', [
            'param' => '',
            'rechercheVilles' => '',
        ]);
    }

    /**
     * @Route(name="city_results", path="/ville/results")
     */
    public function resultsAction(Request $request): JsonResponse
    {
        $sortHeader = ['cp', 'ville'];

        $datagridIndex = '0';
        $sortColumnParameter = $request->get('iSortCol_'.$datagridIndex);
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[1];
        $sortDirection = $request->get('sSortDir_'.$datagridIndex, 'desc');
        $displayPerPage = $request->get('iDisplayLength', 50);
        $start = $request->get('iDisplayStart', 0);
        $currentPage = $request->get('sEcho', 1);
        $searchTerm = $request->get('sSearch', null);

        // FIXME SQL injections

        $queryConditions = 'FROM ville ';

        if ($searchTerm) {
            $con = Propel::getConnection();
            $searchTerm = $con->quote('%'.$searchTerm.'%');
            $searchCriteria = [
                'cp LIKE '.$searchTerm,
                'ville LIKE '.$searchTerm,
            ];
            $queryConditions = $queryConditions.' WHERE ('.implode(' OR ', $searchCriteria).') ';
        }

        $nbResults = $this->query('SELECT count(*) as nbResults '.$queryConditions);
        $rechercheVilles = $this->query('SELECT id as id_ville,cp,ville '.$queryConditions.' ORDER BY '.$sortColumn.' '.$sortDirection.' LIMIT '.$start.','.$displayPerPage);
        $totalRecords = isset($nbResults[0]) ? (int) $nbResults[0]->nbResults : 0;

        $results = [];
        $results['sEcho'] = $currentPage;

        $results['iTotalRecords'] = $totalRecords;
        $results['iTotalDisplayRecords'] = $totalRecords;

        foreach ($rechercheVilles as $rechercheVille) {
            $tmpRow = [];
            $tmpRow[] = '<span data-id="'.$rechercheVille->id_ville.'">'.$rechercheVille->cp.'</span>';
            $tmpRow[] = $rechercheVille->ville;
            $results['aaData'][] = $tmpRow;
        }

        return $this->json($results);
    }

    /**
     * Fonction utilisée pour l'autocomplete.
     *
     * @Route(name="city_search", path="/ville/searchVille")
     */
    public function searchVilleAction(Request $request): JsonResponse
    {
        $term = $request->get('term').'%';
        $villes = VilleQuery::create()
            ->filterByCp($term, Criteria::LIKE)
            ->_or()
            ->filterByVille('%'.$term, Criteria::LIKE)
            ->orderByVille()
            ->limit(100)
            ->find();
        $response = [];
        foreach ($villes as $ville) {
            $response[] = [
                'id' => $ville->getId(),
                'label' => $ville->getCp().' - '.$ville->getVille(),
                'value' => $ville->getId(),
            ];
        }

        return $this->json($response);
    }

    /**
     * @Route(name="city_detail", path="/villeDetail/editer")
     * @Route(name="city_detail_with_id", path="/villeDetail/editer/{idVille}")
     * @Route(name="city_detail_cp", path="/villeDetail/editer/{idVille}/{champsPost}")
     */
    public function editerAction(Request $request): Response
    {
        $id = $request->get('idVille');
        $champsPost = $request->get('champsPost', []);
        $ville = $id ? VilleQuery::create()->findOneById($id) : null;

        return $this->render('pmtool/pages/villeDetail.html.twig', [
            'header' => '',
            'ville' => $ville,
            'champsPost' => $champsPost,
        ]);
    }

    /**
     * @Route(name="city_detail_save", path="/villeDetail/sauvegarder")
     */
    public function saveAction(Request $request): Response
    {
        $idVille = $request->get('id_ville');
        if ($idVille) {
            $champsPost = $this->formatChampsPost($request);
            $ville = VilleQuery::create()->filterByCp($champsPost['cp'])->filterByVille($champsPost['ville'])->filterById($idVille, Criteria::NOT_EQUAL)->findOne();
            if ($ville) {
                $this->addFlash('erreur', 'City already exist !');
            } else {
                $ville = VilleQuery::create()->findOneById($idVille);
                if ($ville) {
                    $ville->setCp($champsPost['cp'])->setVille($champsPost['ville'])->save();
                    $this->addFlash('success', 'City updated');
                }
            }
        } else {
            $champsPost = $this->formatChampsPost($request);
            if ('' != $champsPost['cp'] && '' != $champsPost['ville']) {
                $ville = VilleQuery::create()->filterByCp($champsPost['cp'])->filterByVille($champsPost['ville'])->findOne();
                if ($ville) {
                    $this->addFlash('danger', 'City already exist !');
                } else {
                    (new Ville())
                        ->setCp($champsPost['cp'])
                        ->setVille($champsPost['ville'])
                        ->save();

                    $this->addFlash('success', 'City added');
                }
            } else {
                $this->addFlash('danger', 'Please provide zip code and city name!');
            }
        }

        return $this->redirect($idVille ? '/villeDetail/editer/'.$idVille : '/villeDetail/editer');
    }

    /**
     * Récupération des données postées par le formulaire.
     */
    private function formatChampsPost($request)
    {
        $champsPost = [];
        $champsPost['cp'] = $request->get('cp');
        $champsPost['ville'] = addslashes(ucwords(trim($request->get('ville'))));

        return $champsPost;
    }
}
