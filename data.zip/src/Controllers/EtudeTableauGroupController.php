<?php

namespace Controllers;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EtudeTableauGroupController extends BaseController
{
    /**
     * @Route(name="etude_table_group", path="/etudeTableauGroup")
     */
    public function indexAction(Request $request): Response
    {
        return $this->render('pmtool/pages/etudeTableauGroup.html.twig', [
            'header' => '',
            'items' => [],
        ]);
    }

    /**
     * @Route(name="etude_table_group_edit", path="/etudeTableauGroup/editer/{idEtudeGroup}")
     */
    public function editerAction(Request $request): Response
    {
        $idEtudeGroup = $request->get('idEtudeGroup');
        $items = $this->query('SELECT numero_etude,
            category,
            sous_type_prestation,
            unit_price,
            quantite_pr,
            coefficiant,
            fournisseur_nom,
            job_costs.prix_revient,
            devis_ok
                FROM etude
                LEFT JOIN job ON job.etude_id = etude.id
                LEFT JOIN job_costs ON job_costs.job_id = job.id
                LEFT JOIN categorie_prestation ON job_costs.categorie_prestation_id = categorie_prestation.id
                WHERE id_etude_group = ?
                AND job_costs.devis_ok < 5
                ORDER BY ordre,numero_etude', [$idEtudeGroup]);

        return $this->render('pmtool/pages/etudeTableauGroup.html.twig', [
            'header' => '',
            'items' => $items,
        ]);
    }
}
