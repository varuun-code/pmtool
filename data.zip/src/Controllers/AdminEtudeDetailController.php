<?php

namespace Controllers;

use Manager\SalesforceManager;
use Model\Etape;
use Model\Etude;
use Model\LogProjectStatus;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Util\DateFormat;

/**
 * FIXME merge two routes and use a Symfony form
 * FIXME use Propel.
 */
class AdminEtudeDetailController extends BaseController
{
    /**
     * @Route(name="etude_admin_etude_detail", path="/adminEtudeDetail/editer/{idEtude}", defaults={"idEtude": ""})
     */
    public function editAction(Request $request): Response
    {
        $idEtude = $request->get('idEtude');
        $adminEtudeDonnees = $this->query('SELECT etude.id as id_etude,numero_etude,reference_client,theme,account_id,
                id_pm,id_etape,sf_account.name as name,date_envoi_facture,date_reglement,discount_percentage_id,
                periode_cutoff, multi_phase
            FROM etude,sf_account
            WHERE etude.account_id = sf_account.id
            AND etude.id = ?', [$idEtude]);

        return $this->render('pmtool/pages/adminEtudeDetail.html.twig', [
            'header' => '',
            'adminEtudeDonnees' => $adminEtudeDonnees[0],
            'etapes' => Etape::getAll()->toKeyValue('Id', 'Etape'),
            'periodesCutOff' => Etude::getCutoffs()->toKeyValue('PeriodeCutoff', 'PeriodeCutoff'),
            'all_pm' => ['0' => 'Select a Project Manager'] + User::getAllPM()->toKeyValue('Id', 'NomComplet'),
        ]);
    }

    /**
     * @Route(name="etude_admin_etude_detail_save", path="/adminEtudeDetail/sauvegarder/{idEtude}", defaults={"idEtude": ""})
     */
    public function saveAction(Request $request, SalesforceManager $sfManager): Response
    {
        $idEtude = $request->get('idEtude');
        $user = $this->getUser();
        $etude = Etude::getById($idEtude);
        $dateEnvoiFacture = $request->get('date_envoi_facture');
        $dateReglement = $request->get('date_reglement');
        $idEtape = $request->get('id_etape');
        if ($etude && $request->get('id_pm')) {
            if ($idEtape) {
                $etude->setIdEtape($idEtape);
                if (Etape::TO_INVOICE === $idEtape) {
                    $etude->majNotation();
                }
            }
            $etude
                ->setReferenceClient($request->get('reference_client'))
                ->setTheme($request->get('theme'))
                ->setDateEnvoiFacture($dateEnvoiFacture ? DateFormat::getDateSQL($dateEnvoiFacture) : null)
                ->setDateReglement($dateReglement ? DateFormat::getDateSQL($dateReglement) : null)
                ->setAccountId($request->get('account_id'))
                ->setIdPm($request->get('id_pm'))
                ->setPeriodeCutoff($request->get('periode_cutoff'))
                ->save();

            if (Etape::CANCELLED == $idEtape) {
                $jobs = $etude->getJobEtudes();
                if (count($jobs) > 0) {
                    $statusCancelledNonBilled = RefSalesForceQuery::create()->filterByField('status_id')->filterByValue(RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED)->findOne();
                    foreach ($jobs as $job) {
                        $job->setStatus($statusCancelledNonBilled)->save();
                        $jobItems = $job->getJobItems();
                        foreach ($jobItems as $jobItem) {
                            $jobItem->setQuantitePv(0);
                            $jobItem->setPrixVente(0);
                            $jobItem->save();
                        }
                    }
                }
            }

            if ($response = $sfManager->updateProjectStatus($etude)) {
                $this->addFlash('warning', 'Salesforce answered: '.$response);
            } elseif ($etude->getMasterProjectSfId()) {
                $this->addFlash('success', 'Salesforce updated');
            }

            $this->addFlash('success', 'Study updated');

            (new LogProjectStatus())
                ->setEtude($etude)
                ->setStatus($etude->getEtape() ? $etude->getEtape()->getEtape() : '-')
                ->setDate(new \DateTime())
                ->setUser($user)
                ->save();
        }

        return $this->redirectToRoute('etude_admin_etude_detail', ['idEtude' => $idEtude]);
    }
}
