<?php

namespace Controllers;

use Model\Banque;
use Model\BanqueQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BanqueController extends BaseController
{
    /**
     * @Route(name="bank_list", path="/banque")
     */
    public function indexAction(): Response
    {
        return $this->render('pmtool/pages/banque.html.twig', [
            'banqueDonnees' => BanqueQuery::create()->orderByBanque()->find(),
            'param' => '',
        ]);
    }

    /**
     * @Route(name="bank_list_results", path="/banque/results/")
     */
    public function resultsAction(): JsonResponse
    {
        $sortHeader = ['banque'];

        $datagridIndex = '0';
        $sortColumnParameter = isset($_GET['iSortCol_'.$datagridIndex]) ? $_GET['iSortCol_'.$datagridIndex] : '';
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[0];
        $sortDirection = isset($_GET['sSortDir_'.$datagridIndex]) ? $_GET['sSortDir_'.$datagridIndex] : 'desc';
        $displayPerPage = isset($_GET['iDisplayLength']) ? (int) $_GET['iDisplayLength'] : 50;
        $start = isset($_GET['iDisplayStart']) ? $_GET['iDisplayStart'] : 0;
        $currentPage = isset($_GET['sEcho']) ? (int) $_GET['sEcho'] : 1;
        $searchTerm = isset($_GET['sSearch']) ? $_GET['sSearch'] : null;
        $param = isset($_GET['param']) ? $_GET['param'] : null;

        $queryConditions = 'FROM banque ';

        if ($searchTerm) {
            $con = Propel::getConnection();
            $searchTerm = $con->quote('%'.$searchTerm.'%');
            $searchCriteria = [
                'banque LIKE '.$searchTerm,
            ];

            $queryConditions = $queryConditions.' WHERE ('.implode(' OR ', $searchCriteria).') ';
        }

        if ('' != $param) {
            $queryConditions = $queryConditions.' WHERE ('.$_SESSION['requete'][$param].') ';
        }

        $nbResults = $this->query('SELECT count(*) as nbResults '.$queryConditions);
        $banquesDonnees = $this->query('SELECT id as id_banque,banque
            '.$queryConditions.' ORDER BY '.$sortColumn.' '.$sortDirection.' LIMIT '.$start.','.$displayPerPage);
        $totalRecords = isset($nbResults[0]) ? (int) $nbResults[0]->nbResults : 0;

        $results = [];
        $results['sEcho'] = $currentPage;

        $results['iTotalRecords'] = $totalRecords;
        $results['iTotalDisplayRecords'] = $totalRecords;

        foreach ($banquesDonnees as $banquesDonnee) {
            $tmpRow = [];
            $tmpRow[] = '<span data-id="'.$banquesDonnee->id_banque.'">'.$banquesDonnee->banque.'</span>';

            $results['aaData'][] = $tmpRow;
        }

        return $this->json($results);
    }

    /**
     * @Route(name="bank_list_search", path="/banque/searchBanque/")
     */
    public function searchAction(): JsonResponse
    {
        $results = [];
        $term = isset($_GET['term']) ? $_GET['term'] : '';
        $banks = $term ? BanqueQuery::create()
            ->filterByBanque('%'.$term.'%', Criteria::LIKE)
            ->find() : [];

        foreach ($banks as $bank) {
            $results[] = ['value' => $bank->getId(), 'label' => $bank->getBanque()];
        }

        return $this->json($results);
    }

    /**
     * @Route(name="bank_update", path="/banque/update/{id}/", defaults={"id": "0"})
     */
    public function updateAction(Request $request): Response
    {
        $idBanque = $request->get('id');
        $banque = null;
        $success = false;

        if ($request->isMethod('POST')) {
            $name = $request->get('banque');
            if (!$idBanque) {
                if ($name) {
                    $banque = BanqueQuery::create()->findOneByBanque($name);
                    if ($banque) {
                        $this->addFlash('danger', 'A bank already exists with this name!');
                    } else {
                        $banque = (new Banque())->setBanque($name);
                        $banque->save();
                        $this->addFlash('success', 'Bank created.');
                        $success = true;
                    }
                } else {
                    $this->addFlash('danger', 'Give Bank name !');
                }
            } else {
                $banque = Banque::getById($idBanque);
                if ($banque) {
                    $banque->setBanque($name)->save();
                    $this->addFlash('success', 'Bank updated.');
                    $success = true;
                }
            }
        } elseif ($idBanque) {
            $banque = Banque::getById($idBanque);
        }

        return $this->render('pmtool/pages/banqueDetail.html.twig', [
            'banque' => $banque,
            'success' => $success,
            'header' => '',
        ]);
    }
}
