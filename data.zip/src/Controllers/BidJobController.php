<?php

namespace Controllers;

use Form\Type\BidJobEventsType;
use Model\BidJob;
use Model\BidJobItem;
use Model\BidJobQuery;
use Model\CategoriePrestation;
use Model\Event;
use Model\EventBidJobItem;
use Model\EventBidJobItemQuery;
use Model\EventQuery;
use Model\Opportunity;
use Model\OpportunityBid;
use Model\RefEventStatusQuery;
use Model\RefSalesForce;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BidJobController extends BaseController
{
    /**
     * @Route(name="events_create_bidjob_items", path="/opportunity/event/create/bidjobitem/{opportunity_id}/{first_bid_id}/{bidjob_id}", defaults={"opportunity_id": "", "first_bid_id": "", "bidjob_id": ""})
     */
    public function eventsCreateBidJobItemsAction(Request $request): JsonResponse
    {
        if ($request->isXmlHttpRequest() && $request->isMethod('post')) {
            $bidJobId = $request->get('bidjob_id');
            $firstBidId = $request->get('first_bid_id');
            $opportunityId = $request->get('opportunity_id');
            $bidJob = BidJobQuery::create()->findPk($bidJobId);
            $firstBid = OpportunityBid::getById($firstBidId);
            $opportunity = Opportunity::getById($opportunityId);
            if (!$bidJob || !$opportunity) {
                $this->addFlash('warning', 'You cannot access this page');

                return $this->json([
                    'message' => [
                        'type' => 'danger',
                        'text' => 'You cannot access this page',
                    ],
                ]);
            }

            $isFacilityOnly = $opportunity->getRoomRental();
            $isTranslator_equipment = $opportunity->getTranslatorEquipment();
            $isStreaming = $opportunity->getStreaming();
            $isPc_rental = $opportunity->getPcRental();
            $isUsabilty_lab = $opportunity->getUsabilityLab();
            $isSimtrans = $opportunity->getSimtrans();
            $isNote_taker = $opportunity->getNoteTaker();
            $isAdditional_qa = $opportunity->getAdditionalQa();
            $isCatering_respondent = $opportunity->getCateringResp();
            $isCatering_client = $opportunity->getCateringClient();

            $bidJobItem_respLocation = RefSalesForce::getInstanceRespLocation($this->instance);
            $events = EventQuery::create()->filterByIsDeletedC(false)->filterByBidJob($bidJob)->orderByDate()->find();
            $eventDates = [];
            $eventsRooms = [];
            $iDs_eventsWithDateDuplicated = $firstOf_eventsIds_with_Date_duplicated = [];
            $eventsIds_list_toIgnore_filterByDate = [];
            $iDs_of_eventsDuplicated_byDateAndRoom = $firstOf_eventsIds_with_roomAndDate_duplicated = [];
            $eventsIds_list_toIgnore_filterByDateAndRoom = [];
            foreach ($events as $event) {
                $eventDates[] = $event->getDate('Y-m-d');
                $eventsRooms[] = $event->getRefRoom() ? $event->getRefRoom()->getName() : '';
            }

            // FIXME rewrite entirely

            $roomsDuplicatedNumbers = array_count_values($eventsRooms);
            $datesDuplicatedNumbers = array_count_values($eventDates);
            // get All ids of events with same room and same date OR with same date
            foreach ($datesDuplicatedNumbers as $date => $duplicationDateNumber) {
                if ($duplicationDateNumber > 1) {
                    $iDs_eventsWithDateDuplicated[] = EventQuery::create()
                        ->select('id')
                        ->filterByBidJobId($bidJobId)
                        ->filterByDate($date)
                        ->filterByIsDeletedC(false)
                        ->find()
                        ->getData();
                }
                foreach ($roomsDuplicatedNumbers as $roomName => $duplicationRoomNumber) {
                    if (($duplicationDateNumber > 1) && $duplicationRoomNumber > 1) {
                        $iDs_of_eventsDuplicated_byDateAndRoom[] = EventQuery::create()
                            ->select('id')
                            ->filterByBidJobId($bidJobId)
                            ->filterByDate($date)
                            ->useRefRoomQuery()
                                ->filterByName($roomName)
                            ->endUse()
                            ->filterByIsDeletedC(false)
                            ->find()
                            ->getData();
                    }
                }
            }
            // get the first of events with same ROOM and same DATE to create only one job item on the first
            foreach ($iDs_of_eventsDuplicated_byDateAndRoom as $eventId_duplicated_byDateAndRoom) {
                foreach ($eventId_duplicated_byDateAndRoom as $key2 => $eventIdFilterByDateAndRoomDuplicated) {
                    if (0 == $key2) {
                        $firstOf_eventsIds_with_roomAndDate_duplicated[] = $eventIdFilterByDateAndRoomDuplicated;
                    } else {
                        $eventsIds_list_toIgnore_filterByDateAndRoom[] = $eventIdFilterByDateAndRoomDuplicated;
                    }
                }
            }
            // get the first of events with same DATE only to create only one job item on the first
            foreach ($iDs_eventsWithDateDuplicated as $eventIdDateDuplicated) {
                foreach ($eventIdDateDuplicated as $key2 => $eventIdFilterByDateDuplicated) {
                    if (0 == $key2) {
                        $firstOf_eventsIds_with_Date_duplicated[] = $eventIdFilterByDateDuplicated;
                    } else {
                        $eventsIds_list_toIgnore_filterByDate[] = $eventIdFilterByDateDuplicated;
                    }
                }
            }

            // Delete existing EventBidJobItems and BidJobItems to recreate items
            EventBidJobItemQuery::create()->filterByEvent($events)->delete();
            $bidJobItemsInit = $bidJob->getOpportunityBidJobItems();
            foreach ($bidJobItemsInit as $itemToDelete) {
                $itemToDelete->delete();
            }

            // if quick opportunity facilityOnly [room_rental] is checked
            if ('1' == $isFacilityOnly) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('per day');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_roomAndDate_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDateAndRoom))) {
                        $eventTimeSLot = $event->getRefTimeSlot() ? $event->getRefTimeSlot()->getName() : '';
                        $eventRoomIsSalleDinter = $event->isEventRoomSalleDinter($event->getRefRoom() ? $event->getRefRoom()->getName() : '');
                        $bidJobItem_sellUnitPrice = $this->setItemSellingUnitPrice($eventTimeSLot, $eventRoomIsSalleDinter);
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, $bidJobItem_sellUnitPrice, '1', $event->getDate(), $bidJobItem_respLocation, '');
                    } else {
                        $this->addEventCollectionToItem($event, $firstOf_eventsIds_with_roomAndDate_duplicated);
                    }
                    $event->save();
                }
            }
            // if quick opportunity [translator_equipment] is checked
            if ('1' == $isTranslator_equipment) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Translation Equipment');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '80', '1', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [streaming] is checked
            if ('1' == $isStreaming) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Video Services');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '300', '1', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [pc_rental] is checked
            if ('1' == $isPc_rental) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Laptop/ iPad Rental');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '50', '1', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [usabilty_lab] is checked
            if ('1' == $isUsabilty_lab) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Other Equipment Rental');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '200', '1', $event->getDate(), $bidJobItem_respLocation, ' UX Recording (Computer/Smartphone)');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [simtrans] is checked
            if ('1' == $isSimtrans) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Sim Translation');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '0', '0', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [note_taker] is checked
            if ('1' == $isNote_taker) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Notetaker');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '0', '0', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [additional_qa] is checked
            if ('1' == $isAdditional_qa) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Qualitative Assistant');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '0', '1', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [catering_respondent] is checked
            if ('1' == $isCatering_respondent) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Respondent Lunch');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '15', '0', $event->getDate(), $bidJobItem_respLocation, '');
                        $event->save();
                    }
                }
            }
            // if quick opportunity [catering_client] is checked
            if ('1' == $isCatering_client) {
                $bidJobItemSection = CategoriePrestation::findByCategoryName('Client Lunch');
                foreach ($events as $event) {
                    if ((in_array($event->getId(), $firstOf_eventsIds_with_Date_duplicated)) || (!in_array($event->getId(), $eventsIds_list_toIgnore_filterByDate))) {
                        $this->createItemsLines($event, $bidJobId, $bidJobItemSection, '28', '0', $event->getDate(), $bidJobItem_respLocation, 'Meal Tray');
                        $event->save();
                    }
                }
            }

            $bidJob->save();
            $firstBid->save();
            $bidJob->reload(true);
            $firstBid->reload(true);

            if ($firstBid->getisPreferred()) {
                $opportunity->setBidRevenue($bidJob->getBudgetRevenue());
                $opportunity->setPmtoolUpdated(true);
            } else {
                $preferredBid = $opportunity->getPreferredBid();
                $opportunity->setBidRevenue($preferredBid->getBudgetRevenue());
            }

            $opportunity->save();
            $opportunity->reload(true);

            return $this->json([
                'message' => [
                    'type' => 'success',
                    'text' => 'Items lines created successfully',
                ],
                'data' => [
                    'opportunity_bidRevenue' => number_format($opportunity->getBidRevenue(), 2, '.', ''),
                    'budget_revenue' => $bidJob->getBudgetRevenue(),
                    'revenue_without_rebate' => $bidJob->getBudgetRevenueWithoutRebate(),
                    'budget_cost' => $bidJob->getBudgetCost(),
                    'budget_margin' => $bidJob->getBudgetMargin(),
                    'bidRevenue' => $firstBid->getBudgetRevenue(),
                    'bWithoutRebate' => $firstBid->getBudgetRevenueWithoutRebate(),
                    'bCost' => $firstBid->getBudgetCost(),
                    'marginWithDiscountPercentage' => $firstBid->getBudgetMargin().' ('.$firstBid->getBudgetMarginPercentage().'%)',
                ],
            ]);
        }

        return $this->json([
            'message' => [
                'type' => 'danger',
                'text' => 'No items created',
            ],
        ]);
    }

    /**
     * @Route(name="bid_job_event_save", path="/opportunity/save/event/{opportunity_id}/{first_bid_id}/{bidjob_id}", defaults={"opportunity_id": "", "first_bid_id": "", "bidjob_id": ""})
     */
    public function saveBidJobEventsAction(Request $request, string $createEventMaxDays): Response
    {
        $user = $this->getUser();
        $bidJob = BidJobQuery::create()->findPk($request->get('bidjob_id'));
        $firstBid = OpportunityBid::getById($request->get('first_bid_id'));
        $opportunity = Opportunity::getById($request->get('opportunity_id'));
        if (!$bidJob) {
            $this->addFlash('warning', 'You cannot access this page');

            return $this->redirectToRoute('opportunity_list');
        }

        $message = [
            'type' => 'success',
            'text' => "Events {$bidJob} updated.",
        ];

        $bidJobsByLocationId = [];
        foreach ($firstBid->getJobs() as $bidJob_) {
            $id = $bidJob_->getLocationId();
            $bidJobsByLocationId[$id] = $bidJob_;
        }

        $eventsInit = EventQuery::create()->filterByBidJobId($request->get('bidjob_id'))->filterByIsDeleted(false)->find();

        $name = 'events_bidjob_'.$bidJob->getId();
        $form = $this->createNamed($name, BidJobEventsType::class, $bidJob, ['user' => $user]);
        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                foreach ($eventsInit as $eventInit) {
                    foreach ($bidJob->getEvents() as $finalEvent) {
                        $initialRoom = $eventInit->getRefRoom();
                        $finalEvent->eventReleasedSetToDelete();
                        $finalEvent->setDate($finalEvent->getStartDateTime('Y-m-d'));
                        $initialLocationId = $initialRoom ? $initialRoom->getIdLocation() : null;
                        $finalRoom = $finalEvent->getRefRoom();
                        $finalLocationId = $finalRoom ? $finalRoom->getIdLocation() : null;

                        if ($finalRoom && $initialRoom !== $finalRoom
                            && $initialLocationId !== $finalLocationId) {
                            if ($finalLocationId && isset($bidJobsByLocationId[$finalLocationId])) {
                                $finalEvent->setBidJob($bidJobsByLocationId[$finalLocationId]);
                            } else {
                                $newBidJob = (new BidJob())
                                    ->setBidId($firstBid->getId())
                                    ->setLocation($finalRoom->getLocation());
                                $newBidJob->save();

                                $bidJobLocationName = $newBidJob->getLocation() ? $newBidJob->getLocation()->getLibelle() : '';
                                $newBidJob->setName($bidJobLocationName);
                                $newBidJob->save();

                                $finalEvent->setBidJobId($newBidJob->getId());
                            }
                        }
                        if ($finalRoom) {
                            $finalEvent->setRefRoom($finalRoom);
                        }
                    }
                }

                $bidJob->save();
                $bidJob->reload(true);
                $opportunity->save();

                $message = [
                    'type' => 'success',
                    'text' => "Event {$bidJob} saved.",
                ];
                $tpl = [
                    'form' => $form->createView(),
                    'opportunity' => $opportunity,
                    'firstBid' => $firstBid,
                    'bidJob' => $bidJob,
                    'user' => $user,
                    'createEventMaxDays' => $createEventMaxDays,
                    'eventAllStatus' => RefEventStatusQuery::create(),
                ];
                if ($request->isXmlHttpRequest()) {
                    return $this->json([
                        'html' => $this->renderTemplate('pmtool/opportunity/_events.html.twig', $tpl),
                        'message' => $message,
                    ]);
                }
            } else {
                $message = [
                    'type' => 'danger',
                    'text' => "Events {$bidJob} validation errors.",
                ];
            }
        }
        $form = $this->createNamed($name, BidJobEventsType::class, $bidJob, ['user' => $user]);

        $tpl = [
            'form' => $form->createView(),
            'opportunity' => $opportunity,
            'firstBid' => $firstBid,
            'bidJob' => $bidJob,
            'user' => $user,
            'project' => $opportunity->getEtude(),
            'createEventMaxDays' => $createEventMaxDays,
            'eventAllStatus' => RefEventStatusQuery::create(),
        ];

        if ($request->isXmlHttpRequest()) {
            return $this->json([
                'html' => $this->renderTemplate('pmtool/opportunity/_events.html.twig', $tpl),
                'message' => $message,
            ]);
        }

        return $this->render('pmtool/opportunity/_events.html.twig', $tpl);
    }

    private function createItemsLines($event, $bidJobId, $bidJobItemSection, $sellingUnitPrice, $sellingQty, $eventDate, $bidJobItem_respLocation, $title)
    {
        $bidJobItem = new BidJobItem();
        $bidJobItem->setBidJobId($bidJobId);
        $bidJobItem->setEvent($event);
        $bidJobItem->setSection($bidJobItemSection);
        $bidJobItem->setSellingUnitPrice($sellingUnitPrice);
        $bidJobItem->setSellingQty($sellingQty);
        $bidJobItem->setDate($eventDate);
        $bidJobItem->setRespLocation($bidJobItem_respLocation);
        $bidJobItem->setCostRate('1');
        $bidJobItem->setTitle($title);
        $bidJobItem->save();

        if ($bidJobItem->getCategory() == BidJobItem::CATEGORIES['facility']) {
            $bidJobItem->setGroupTitle('Facility');
            $bidJobItem->setGroup(1);
        } elseif ($bidJobItem->getCategory() == BidJobItem::CATEGORIES['food']) {
            $bidJobItem->setGroupTitle('Food');
            $bidJobItem->setGroup(2);
        } elseif ($bidJobItem->getCategory() == BidJobItem::CATEGORIES['equipment']) {
            $bidJobItem->setGroupTitle('Equipment');
            $bidJobItem->setGroup(3);
        } else {
            $bidJobItem->setGroupTitle('Services');
            $bidJobItem->setGroup(4);
        }
        $bidJobItem->save();

        $eventBidJobItem = new EventBidJobItem();
        $eventBidJobItem->setEvent($event);
        $eventBidJobItem->setBidJobItem($bidJobItem);
        $eventBidJobItem->save();
    }

    private function addEventCollectionToItem($event, $firstOf_eventsIds_with_roomAndDate_duplicated)
    {
        $eventsBidJobItems_of_allFirstEventsIds_with_roomAndDate_duplicated = EventBidJobItemQuery::create()
            ->filterByEventId($firstOf_eventsIds_with_roomAndDate_duplicated)
            ->find();

        foreach ($eventsBidJobItems_of_allFirstEventsIds_with_roomAndDate_duplicated as $eventsBidJobItem_of_firstEvent_with_roomAndDate_duplicated) {
            if ($eventsBidJobItem_of_firstEvent_with_roomAndDate_duplicated->getEvent()->getRefRoom() == $event->getRefRoom()) {
                $eventBidJobItem = new EventBidJobItem();
                $eventBidJobItem->setEvent($event);
                $eventBidJobItem->setBidJobItem($eventsBidJobItem_of_firstEvent_with_roomAndDate_duplicated->getBidJobItem());
                $eventBidJobItem->save();
            }
        }
    }

    private function setItemSellingUnitPrice($eventTimeSLot, $eventRoomIsSalleDinter)
    {
        $sellingUnitPrice = '0';
        if (Event::HALF_A_DAY == strtolower($eventTimeSLot) && $eventRoomIsSalleDinter) {
            $sellingUnitPrice = '300';
        } elseif (Event::HALF_A_DAY == strtolower($eventTimeSLot) && !$eventRoomIsSalleDinter) {
            $sellingUnitPrice = '340';
        } elseif (Event::DAY == strtolower($eventTimeSLot) && $eventRoomIsSalleDinter) {
            $sellingUnitPrice = '500';
        } elseif (Event::DAY == strtolower($eventTimeSLot) && !$eventRoomIsSalleDinter) {
            $sellingUnitPrice = '560';
        } elseif (Event::EVENING == strtolower($eventTimeSLot) && $eventRoomIsSalleDinter) {
            $sellingUnitPrice = '350';
        } elseif (Event::EVENING == strtolower($eventTimeSLot) && !$eventRoomIsSalleDinter) {
            $sellingUnitPrice = '390';
        } elseif (Event::DAY_EVENING == strtolower($eventTimeSLot) && $eventRoomIsSalleDinter) {
            $sellingUnitPrice = '770';
        } elseif (Event::DAY_EVENING == strtolower($eventTimeSLot) && !$eventRoomIsSalleDinter) {
            $sellingUnitPrice = '900';
        } elseif (Event::AFTERNOON_EVENING == strtolower($eventTimeSLot) && $eventRoomIsSalleDinter) {
            $sellingUnitPrice = '640';
        } elseif (Event::AFTERNOON_EVENING == strtolower($eventTimeSLot) && !$eventRoomIsSalleDinter) {
            $sellingUnitPrice = '710';
        }

        return $sellingUnitPrice;
    }

    /**
     * @Route(name="bidjob_manage_event_status", path="/bidjob/updateeventstatus")
     */
    public function updateEventStatusAction(Request $request): JsonResponse
    {
        $status = false;
        $message = null;
        if ($request->isXmlHttpRequest() && $request->isMethod('post')) {
            $statusId = $request->get('status', null);
            $checkedEventAr = $request->get('checkedEvent', null);
            if ($checkedEventAr) {
                foreach ($checkedEventAr as $eventId) {
                    $event = Event::getById($eventId);
                    $event->setEventStatusId($statusId)->save();
                }
                $status = true;
                $message = 'event status has been managed!';
            } else {
                $message = 'This event status can not be update.';
            }
        }

        return new JsonResponse([
            'data' => [],
            'status' => $status,
            'message' => $message,
        ]);
    }
}
