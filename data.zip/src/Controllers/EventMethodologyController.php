<?php

namespace Controllers;

use Datagrid\Referentiel\EventMethodologyDatagrid;
use Form\Type\Referentiel\EventMethodologyType;
use Model\EventMethodology;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EventMethodologyController extends BaseController
{
    /**
     * @Route(name="event_methodology_list", path="/event-methodology-list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "datagrid": "", "param1": "", "param2": ""})
     */
    public function listAction(Request $request): Response
    {
        return $this->render('pmtool/event-methodology/list.html.twig', [
            'datagrid' => (new EventMethodologyDatagrid($this->container))->execute(),
        ]);
    }

    /**
     * @Route(name="event_methodology_new", path="/event-methodology/new")
     */
    public function newAction(Request $request): Response
    {
        $object = new EventMethodology();
        $form = $this->createForm(EventMethodologyType::class, $object);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $object->save();
            $this->addFlash('success', 'New Event Methodology saved');

            return $this->redirectToRoute('event_methodology_list');
        } elseif ($form->isSubmitted()) {
            $this->addFlash('danger', "The new Event Methodology can't be saved. Check the informations and try again.");
        }

        return $this->render('pmtool/event-methodology/new.html.twig', ['form' => $form->createView()]);
    }

    /**
     * @Route(name="event_methodology_update", path="/event-methodology/{id}/edit", defaults={"id": ""})
     */
    public function editAction(Request $request, EventMethodology $object): Response
    {
        $form = $this->createForm(EventMethodologyType::class, $object)
            ->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $object->save();
            $this->addFlash('success', "Event Methodology's changes saved.");

            return $this->redirectToRoute('event_methodology_list', ['id' => $object->getId()]);
        } elseif ($form->isSubmitted()) {
            $this->addFlash('warning', "Changes can't be saved, check informations and try again");
        }

        return $this->render('pmtool/event-methodology/edit.html.twig', ['object' => $object, 'form' => $form->createView()]);
    }
}
