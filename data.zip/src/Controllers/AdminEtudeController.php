<?php

namespace Controllers;

use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * FIXME use Propel.
 */
class AdminEtudeController extends BaseController
{
    /**
     * @Route(name="etude_admin_etude", path="/adminEtude")
     */
    public function indexAction(Request $request): Response
    {
        return $this->render('pmtool/pages/adminEtude.html.twig', [
            'param' => $request->get('param'),
        ]);
    }

    /**
     * Liste des résultats d'une recherche (encodés en JSON).
     *
     * @Route(name="etude_admin_etude_results", path="/adminEtude/results/")
     */
    public function resultsAction(Request $request): JsonResponse
    {
        $sortHeader = [
            'numero_etude',
            'name',
            'reference_client',
            'theme',
            'etape',
        ];

        $datagridIndex = '0';
        $sortColumnParameter = isset($_GET['iSortCol_'.$datagridIndex]) ? $_GET['iSortCol_'.$datagridIndex] : null;
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[0];
        $sortDirection = isset($_GET['sSortDir_'.$datagridIndex]) ? $_GET['sSortDir_'.$datagridIndex] : 'desc';
        $displayPerPage = isset($_GET['iDisplayLength']) ? (int) $_GET['iDisplayLength'] : 25;
        $start = isset($_GET['iDisplayStart']) ? $_GET['iDisplayStart'] : 0;
        $currentPage = isset($_GET['sEcho']) ? (int) $_GET['sEcho'] : 1;
        $searchTerm = isset($_GET['sSearch']) ? $_GET['sSearch'] : null;
        $param = isset($_GET['param']) ? $_GET['param'] : null;

        $queryConditions = 'FROM etude,ref_etape,sf_account WHERE etude.id_etape = ref_etape.id AND etude.account_id = sf_account.id ';

        if ($searchTerm) {
            $con = Propel::getConnection();
            $searchTerm = $con->quote('%'.$searchTerm.'%');
            $searchCriteria = [
                'etude.numero_etude LIKE '.$searchTerm,
                'ref_etape.etape LIKE '.$searchTerm,
                'name LIKE '.$searchTerm,
                'reference_client LIKE '.$searchTerm,
                'etude.theme LIKE '.$searchTerm,
            ];

            $queryConditions = $queryConditions.' AND ('.implode(' OR ', $searchCriteria).') ';
        }

        if ('' != $param) {
            $queryConditions = $queryConditions.' AND ('.$_SESSION['requete'][$param].') ';
        }

        $nbResults = $this->query('SELECT count(etude.id) as nbResults '.$queryConditions);

        $rechercheEtudes = $this->query("SELECT etude.id as id_etude,numero_etude,theme,ref_etape.etape,sf_account.name as name,reference_client
        $queryConditions ORDER BY $sortColumn $sortDirection LIMIT $start, $displayPerPage");

        $totalRecords = isset($nbResults[0]) ? (int) $nbResults[0]->nbResults : 0;

        $results = [];
        $results['sEcho'] = $currentPage;

        $results['iTotalRecords'] = $totalRecords;
        $results['iTotalDisplayRecords'] = $totalRecords;

        foreach ($rechercheEtudes as $rechercheEtude) {
            $tmpRow = [];
            $tmpRow[] = '<span data-id="'.$rechercheEtude->id_etude.'">'.$rechercheEtude->numero_etude.'</span>';
            $tmpRow[] = $rechercheEtude->name;
            $tmpRow[] = $rechercheEtude->reference_client;
            $tmpRow[] = $rechercheEtude->theme;
            $tmpRow[] = $rechercheEtude->etape;

            $results['aaData'][] = $tmpRow;
        }

        return $this->json($results);
    }
}
