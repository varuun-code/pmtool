<?php

namespace Controllers;

use Model\Etape;
use Model\Etude;
use Model\Industry;
use Model\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BilanAnnuelController extends BaseController
{
    /**
     * @Route(name="yearly_report", path="/bilanAnnuel")
     */
    public function indexAction(Request $request): Response
    {
        $id_bm = $request->get('id_bm');
        $id_pm = $request->get('id_pm');
        $account_id = $request->get('account_id');
        $selection_suplementaire = '';

        if ($id_pm) {
            $selection_suplementaire .= ' AND id_pm='.$id_pm.' ';
        }
        if ($id_bm) {
            $selection_suplementaire .= ' AND id_bm='.$id_bm.' ';
        }
        if ($account_id) {
            $selection_suplementaire .= ' AND account_id ='.$account_id.' ';
        }

        /* Select Periode */
        $selectPeriodes = $request->get('selectPeriode');
        $listePeriode = null;
        if ($selectPeriodes) {
            foreach ($selectPeriodes as $value) {
                $listePeriode = '' == $listePeriode ? "'".$value."'" : $listePeriode.",'".$value."'";
            }
            $selection_suplementaire .= ' AND periode_cutoff IN('.$listePeriode.')';
        }

        /* Select Type */
        $selectTypes = $request->get('selectType');
        $listeType = null;
        if ($selectTypes) {
            foreach ($selectTypes as $value) {
                $listeType = '' == $listeType ? "'".$value."'" : $listeType.",'".$value."'";
            }
            $industriesFilter = (count($selectTypes) >= 1 && 0 != $selectTypes[0]) ? ' AND tmp.industry_id IN('.$listeType.')' : '';
            $selection_suplementaire .= $industriesFilter;
        }

        $donneesBilanAnnuel = $this->query('SELECT  SUBSTRING(periode_cutoff,1,4) as annee,
            name,
            sum(prix_vente) as SommePrixVente,
            sum(prix_revient_reel) as SommePrixRevient  FROM (
        (
        SELECT
              DISTINCT `numero_etude`,
              `j`.`id`,
              `date_debut`,
              `date_fin`,
              `annee`,
              `account_id`,
              `id_etape`,
              `id_pm`,
              `date_envoi_facture`,
              `industry_id`,
              `date_reglement`,
              `periode_cutoff`,
              `job_qualification_id`,
              `id_bm`,
              SUM(`i`.`prix_vente`)   AS `prix_vente`,
              0 AS `prix_revient_reel`
            FROM
                  `etude` `e`
                  JOIN `job` `j`      ON `j`.`etude_id`=`e`.`id`
                  JOIN `job_item` `i` ON `i`.`job_id`=`j`.`id`
            WHERE
                  `i`.`devis_ok` < 5
            GROUP BY
                  `j`.`id`
      )
      UNION
      (
          SELECT
              DISTINCT `numero_etude`,
              `j`.`id`,
              `date_debut`,
              `date_fin`,
              `annee`,
              `account_id`,
              `id_etape`,
              `id_pm`,
              `date_envoi_facture`,
              `industry_id`,
              `date_reglement`,
              `periode_cutoff`,
              `job_qualification_id`,
              `id_bm`,
              0 AS `prix_vente`,
              SUM(`c`.`prix_revient`) AS `prix_revient_reel`
            FROM
                  `etude` `e`
                  JOIN `job` `j`       ON `j`.`etude_id`=`e`.`id`
                  JOIN `job_costs` `c` ON `c`.`job_id`=`j`.`id`
            WHERE
                  `c`.`devis_ok` < 5
            GROUP BY
                  `j`.`id`
      )
) as  tmp LEFT JOIN sf_account ON tmp.account_id = sf_account.id WHERE id_etape IN ('.Etape::INVOICED.','.Etape::PAID.') '.$selection_suplementaire.
            ' GROUP BY annee desc, name WITH ROLLUP');

        return $this->render('pmtool/pages/bilanAnnuel.html.twig', [
            'donneesBilanAnnuel' => $donneesBilanAnnuel,
            'account_id' => $account_id,
            'id_pm' => $id_pm,
            'id_bm' => $id_bm,
            'type' => '',
            'selectPeriode' => $selectPeriodes,
            'programManager' => ['0' => 'All Prog. Manager'] + User::getPerGroup([2, 6, 11])->toKeyValue('Id', 'FullName'),
            'saleManager' => ['0' => 'All Sales Manager'] + User::getSellers()->toKeyValue('Id', 'FullName'),
            'periodes' => Etude::getCutoffs()->toKeyValue('PeriodeCutoff', 'PeriodeCutoff'),
            'industries' => ['0' => 'All industries'] + Industry::getAll()->toKeyValue('Id', 'Libelle'),
            'industry' => $selectTypes,
        ]);
    }
}
