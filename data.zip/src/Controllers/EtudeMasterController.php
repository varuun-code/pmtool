<?php

namespace Controllers;

use Model\AreaQuery;
use Model\CategoriePrestation;
use Model\Coefficient;
use Model\Etape;
use Model\EtudeMaster;
use Model\EtudeMasterQuery;
use Model\Groupe;
use Model\Location;
use Model\RefSalesForceQuery;
use Model\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EtudeMasterController extends BaseController
{
    /**
     * @Route(name="etude_master", path="/etudeMaster/{id}")
     */
    public function editerAction(Request $request, EtudeMaster $etudeMaster): Response
    {
        $numero_etude = $etudeMaster->getNumeroEtude();
        // Gestion des sessions et messages
        $user = $this->getUser();
        $id_groupe = $user->getIdGroupe();

        // Liste des monnaie (pour études)
        $results = $this->query("SELECT id,symbole_monnaie,change_euro FROM pays WHERE code_monnaie <> '' and generic = 1 ORDER BY code_monnaie");
        $monnaies = null;
        $symbolesMonnaie = [];
        foreach ($results as $result) {
            $monnaies[$result->change_euro.','.$result->symbole_monnaie] = $result->symbole_monnaie;
            $symbolesMonnaie[$result->id] = $result->symbole_monnaie;
        }
        $coefficients = Coefficient::getAll()->toKeyValue('Coefficient', 'Coefficient');

        // FIXME SQL injections
        $etude = $this->query('SELECT * FROM etude_master WHERE numero_etude = ?', [$numero_etude])[0];
        $etude_fille = $this->query("SELECT
            sum(prix_revient_initial) AS pri,
            sum(prix_revient_actualise) AS prr,
            sum(prix_vente_initial) AS pv,
            sum(prix_vente_actualise) AS pvr
            FROM etude
            WHERE numero_etude LIKE CONCAT(LEFT('".$numero_etude."',6),'%')");

        $items = $this->query("SELECT job_item.id,
                job.location_id,
                comment_pm,
                quantite_pr,
                quantite_pv,
                job_item.prix_vente,
                devis_ok,
                categorie_prestation_id,
                sous_type_prestation,
                coefficiant_pr,
                job_item.prix_revient
          FROM job_item
          LEFT JOIN job ON job.id = job_item.job_id
          LEFT JOIN etude ON etude.id = job.etude_id
          WHERE etude.numero_etude LIKE '$numero_etude%' AND devis_ok < 4;");

        $syntheseRubriques = $this->query("SELECT DISTINCT categorie_prestation_id,categorie,category,
            SUM(quantite_pr) AS qte,
            SUM(quantite_pr*coefficiant_pr) AS prixRevient,
            SUM(job_item.prix_vente) AS prixVente,
            SUM(paye) AS payeFournisseur,
            categorie_prestation.remise*((SUM(job_item.prix_vente)/(1-(etude.remise_taux/100)))-SUM(job_item.prix_vente)) AS montantRemise
            FROM etude
            LEFT JOIN job ON job.etude_id = etude.id
            LEFT JOIN job_item ON job_item.job_id = job.id
            LEFT JOIN categorie_prestation ON job_item.categorie_prestation_id = categorie_prestation.id
            WHERE etude.numero_etude LIKE '$numero_etude%'
            AND devis_ok < 5
            GROUP BY categorie_prestation_id
            ORDER BY ordre");

        $costs = $this->query('SELECT job.location_id,
                comment_pm,
                quantite_pr,
                devis_ok,
                categorie_prestation_id,
                sous_type_prestation,
                job_costs.prix_revient,
                fournisseur_nom,
                comment_fnr,
                ref_facture_fnr,
                fournisseur.id AS fournisseur_id,
                fournisseur.email AS fournisseur_email,
                date_entry_fnr,
                payment_of_performance,date_paiement_fnr,
                po_number, etude.id AS etude_id
          FROM job_costs
          LEFT JOIN job ON job.id = job_costs.job_id
          LEFT JOIN etude ON etude.id = job.etude_id
          LEFT JOIN fournisseur ON fournisseur.id = job_costs.fournisseur_id
          WHERE etude.numero_etude LIKE ?', [$numero_etude.'%']);

        // Consolidation du Summary : rapprochement du Budget et des Costs sur les clés Location et Section
        $summary = [];
        $results = $this->query('SELECT DISTINCT libelle AS location,categorie AS section,
            SUM(quantite_pv) AS qtePv,
            SUM(prix_vente) AS prixVente
            FROM categorie_prestation
            LEFT JOIN job_item ON job_item.categorie_prestation_id = categorie_prestation.id
            LEFT JOIN job ON job.id = job_item.job_id
            LEFT JOIN etude ON etude.id = job.etude_id
            LEFT JOIN ref_location ON ref_location.id = job.location_id
            WHERE devis_ok < 5
            AND numero_etude LIKE ?
            GROUP BY libelle,categorie', [$numero_etude.'%']);
        foreach ($results as $result) {
            $summary[$result->location][$result->section]['qtePv'] = $result->qtePv;
            $summary[$result->location][$result->section]['prixVente'] = $result->prixVente;
        }

        $results = $this->query('SELECT DISTINCT libelle AS location, categorie AS section,
            SUM(quantite_pr) AS qtePr,
            SUM(prix_revient) AS prixRevient
            FROM categorie_prestation
            LEFT JOIN job_costs ON job_costs.categorie_prestation_id = categorie_prestation.id
            LEFT JOIN job ON job.id = job_costs.job_id
            LEFT JOIN etude ON etude.id = job.etude_id
            LEFT JOIN ref_location ON ref_location.id = job.location_id
            WHERE devis_ok < 5
            AND numero_etude LIKE ?
            GROUP BY libelle,categorie', [$numero_etude.'%']);
        foreach ($results as $result) {
            $summary[$result->location][$result->section]['qtePr'] = $result->qtePr;
            $summary[$result->location][$result->section]['prixRevient'] = $result->prixRevient;
        }

        $etude->prix_revient_initial = $etude_fille[0]->pri;
        $etude->prix_revient_actualise = $etude_fille[0]->prr;
        $etude->prix_vente = $etude_fille[0]->pv;
        $etude->prix_vente_reactualise = $etude_fille[0]->pvr;

        // Diplay Etude Master Account && Account
        $etudeMasterPropel = EtudeMasterQuery::create()->findOneById($etude->id);
        $etudeMasterAccount = $etudeMasterPropel ? $etudeMasterPropel->getAccount() : null;
        $accountDetail = $etudeMasterAccount ? $etudeMasterAccount->getAccountDetail() : null;

        // Display Fews Infos for Etude Master
        $jobQualificationId = RefSalesForceQuery::create()->findOneById($etudeMasterPropel->getIdQq());
        $jobQualificationValue = $jobQualificationId->getValue();

        // Find the area
        $etudeMasterArea = AreaQuery::create()->findOneById($etudeMasterPropel->getAreaId());

        //  Find the langage
        $etudeMasterLangage = $etudeMasterPropel->getLanguage();

        // Find the sector
        $etudeSectors = RefSalesForceQuery::create()
            ->useRefSalesForceEtudeSectorQuery()
                ->filterByEtudeId($etudeMasterPropel->getId())
            ->endUse()
            ->find();
        $sector = '';
        foreach ($etudeSectors as $etudeSector) {
            $sector = $etudeSector->getValue();
        }
        $categories = CategoriePrestation::getAll()->toKeyValue('Id', 'Categorie');
        $locations = Location::getAll()->toKeyValue('Id', 'Libelle');

        $etape = Etape::get($etude->id_etape);
        $etape_etude = $etape ? $etape->getOrdre() : 0;
        $boutonActif = Groupe::boutonActif($id_groupe, $etude->id_etape);

        return $this->render('pmtool/pages/etudeMaster.html.twig', [
            'etude' => $etude,
            'previousetude' => 0,
            'nextetude' => 0,
            'id_groupe' => $id_groupe,
            'id_etape' => 0,
            'remise_taux' => 0,
            'all_pm' => ['0' => 'Select a Project Manager'] + User::getAllPM()->toKeyValue('Id', 'NomComplet'),
            'ongletDefaut' => 'etude',
            'etude_pm_location' => [],
            'numero_etude' => $numero_etude,
            'sector' => $sector,
            'etudeMasterPropel' => $etudeMasterPropel,
            'etudeMasterAccount' => $etudeMasterAccount,
            'special_client_information' => $accountDetail ? $accountDetail->getSpecialClientBillingInformation() : '',
            'etudeMasterAccountNumber' => $etudeMasterAccount ? $etudeMasterAccount->getNumber() : '',
            'etudeMasterAccountCountry' => $etudeMasterAccount ? $etudeMasterAccount->getBillingCountry() : '',
            'etudeMasterLangage' => $etudeMasterLangage ?: '',
            'jobQualificationValue' => $jobQualificationValue ?: '',
            'etudeMasterArea' => $etudeMasterArea ? $etudeMasterArea->getLibelle() : null,
            'userId' => $user->getId(),
            'location_pnls' => $locations,
            'locationPnlsJson' => json_encode(array_flip($locations)),
            'monnaies' => $monnaies,
            'symbolesMonnaie' => $symbolesMonnaie,
            'coefficients' => $coefficients,
            'coefficientsJson' => json_encode($coefficients),
            'categories' => $categories,
            'categoriesJson' => json_encode($categories),
            'items' => $items,
            'summary' => $summary,
            'syntheseRubriques' => $syntheseRubriques,
            'costs' => $costs,
            'etape_etude' => $etape_etude,
            'boutonActif' => $boutonActif,
        ]);
    }

    /**
     * @Route(name="template_tableau", path="/templateTableau")
     */
    public function templateTableau(): Response
    {
        return $this->render('pmtool/pages/templateTableau.html.twig');
    }
}
