<?php

namespace Controllers;

use Model\User;
use Propel\Runtime\Propel;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class BaseController extends AbstractController
{
    protected string $currency;
    protected string $instance;

    public function __construct(TokenStorageInterface $tokenStorage, string $currency, string $instance)
    {
        $user = $tokenStorage->getToken() ? $tokenStorage->getToken()->getUser() : null;
        $_SESSION['user'] = $user instanceof User ? $user->getId() : null;
        $this->currency = $currency;
        $this->instance = $instance;
    }

    /**
     * NB: this is a compatibility layer between old plain SQL statements and the current Propel connector.
     *
     * DEPRECATED please don't use it anymore and refactor to stop using it.
     */
    protected function query($query, $params = [], $fetch_mode = \PDO::FETCH_OBJ)
    {
        $con = Propel::getConnection();
        $stmt = $con->prepare($query);
        foreach ($params as $key => $param) {
            $stmt->bindValue($key + 1, $param);
        }
        $stmt->execute();
        $type = strtolower(mb_substr(trim($query), 0, 6));
        if ('select' != $type) {
            return true;
        }

        if (\PDO::ATTR_DEFAULT_FETCH_MODE == $fetch_mode) {
            return $stmt->fetchAll();
        }

        return $stmt->fetchAll($fetch_mode);
    }

    private function addOptions(array $options): array
    {
        $options['user'] = $this->getUser();
        $options['defaultDateFmt'] = $this->getDefaultDateFmt();
        $options['currency'] = $this->currency;
        $options['instance'] = $this->instance;

        return $options;
    }

    protected function render(string $view, array $parameters = [], Response $response = null): Response
    {
        $parameters = $this->addOptions($parameters);

        return parent::render($view, $parameters);
    }

    protected function renderTemplate(string $template, array $options = []): string
    {
        $options = $this->addOptions($options);

        return parent::renderView($template, $options);
    }

    protected function getDefaultDateFmt(): string
    {
        if (($user = $this->getUser()) && $user instanceof User && $format = $user->getDefaultDateFormat()) {
            return $format;
        }

        return 'us' === $this->instance ? 'm-d-y' : 'd-m-y';
    }

    protected function changeDateToDefaultFormat($date): string
    {
        $defaultDateFmt = $this->getDefaultDateFmt();

        return $date && '0000-00-00' != $date ? date($defaultDateFmt, strtotime($date)) : '';
    }

    protected function createNamed($name, $type, $data = null, array $options = [])
    {
        return $this->get('form.factory')->createNamed($name, $type, $data, $options);
    }
}
