<?php

namespace Controllers;

use Form\Type\UtilisateurDetailType;
use Manager\MailManager;
use Model\User;
use Model\UserQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UtilisateurDetailController extends BaseController
{
    /**
     * @Route(name="user_new", path="/user/new")
     */
    public function new(Request $request, MailManager $mailManager): Response
    {
        $user = new User();
        $form = $this->createForm(UtilisateurDetailType::class, $user);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $user = $form->getData();
                $mail = $user->getMail();
                $existing = UserQuery::create()->findOneByMail($mail);
                if (!$existing) {
                    if ($user->getMail()) {
                        $creator = $this->getUser();
                        $text = 'Access PM TOOL have just been created by '.$creator->getFullname();
                        $mailManager->send($user->getMail(), [$creator->getMail()], [], '[PMTool] New user account', $text);
                    }
                    $this->addFlash('success', 'User added');
                    $user->save();

                    return $this->redirectToRoute('user_edit', ['id' => $user->getId()]);
                }

                $this->addFlash('danger', 'A user with this e-mail already exists!');
            }
        }

        return $this->render('pmtool/pages/utilisateurDetail.html.twig', [
            'form' => $form->createView(),
            'header' => '',
            'attributes' => ['label_attr' => ['class' => 'control-label col-sm-3']],
        ]);
    }

    /**
     * @Route(name="user_edit", path="/user/{id}/edit")
     */
    public function editerAction(Request $request, MailManager $mailManager, User $user): Response
    {
        $form = $this->createForm(UtilisateurDetailType::class, $user);
        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $user = $form->getData();
                $mail = $user->getMail();
                $existing = UserQuery::create()->filterById($user->getId(), Criteria::NOT_EQUAL)->filterByMail($mail)->findOne();
                if ($existing) {
                    $this->addFlash('danger', 'Another user with this e-mail already exists!');
                } else {
                    $user->save();
                    $this->addFlash('success', 'User updated');
                }
            }
        }

        return $this->render('pmtool/pages/utilisateurDetail.html.twig', [
            'form' => $form->createView(),
            'header' => '',
            'attributes' => ['label_attr' => ['class' => 'control-label col-sm-3']],
        ]);
    }
}
