<?php

namespace Controllers;

use DateTime;
use Form\Type\TimingReportType;
use Manager\SpreadsheetManager;
use Model\CountryHolidayQuery;
use Model\Groupe;
use Model\Industry;
use Model\JobQuery;
use Model\Map\JobTableMap;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class TimingReportController extends BaseController
{
    /**
     * @Route(name="timing_report_index", path="/timing-report/index")
     */
    public function indexAction(Request $request, SpreadsheetManager $spreadsheetManager): Response
    {
        ini_set('memory_limit', '2G');
        ini_set('max_execution_time', '60');

        $user = $this->getUser();
        $form = $this->createForm(TimingReportType::class, null, ['isJobCost' => true]);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            return $this->generateSheet($request, $spreadsheetManager);
        }

        return $this->render('pmtool/pages/timingReport.html.twig', [
            'industries' => ['' => 'Select industries'] + Industry::getAll()->toKeyValue('Id', 'Libelle'),
            'industry' => $request->get('industry') ?: null,
            'rechercheEtudes' => '',
            'param' => $request->get('param'),
            'form' => $form->createView(),
            'isJobCost' => true,
            'show_button' => in_array($user->getIdGroupe(), [Groupe::MANAGING_DIRECTOR, Groupe::ACCOUNTING, Groupe::SYSTEM_ADMINISTRATOR]),
        ]);
    }

    /**
     * @Route(name="timing_report_recherche_results",
     *     path="/timing-report/recherche/results/{location}/{pm}/{sm}/{ap}/{edate}/{sdate}",
     *     defaults={"location": "", "pm": "", "sm": "", "ap": "", "edate": "", "sdate": ""} )
     */
    public function resultsAction(Request $request): JsonResponse
    {
        $sortHeader = [
            'mainEtude.numero_etude',
            'mainEtude.master_project_number',
            'po_job_number',
            'jobLocation.libelle',
            'start_date',
            'end_date',
            'pmSet.date',
            'pmSet.date',
            'pmSet.date',
            'timeToDefine',
            'timeToDefineCallC',
            'user.prenom',
            'callC.value',
            'accountPod.value',
        ];
        $location = $request->get('location');
        $sm = $request->get('sm');
        $pm = $request->get('pm');
        $ap = $request->get('ap');
        $sdate = $request->get('sdate');
        $edate = $request->get('edate');

        $defaultSort = in_array($this->instance, ['de', 'es']) ? 0 : 9;
        $datagridIndex = '0';
        $sortColumnParameter = $request->get('iSortCol_'.$datagridIndex);
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[$defaultSort];
        $sortDirection = $request->get('sSortDir_'.$datagridIndex) ?: 'desc';
        $displayPerPage = $request->get('iDisplayLength') ? (int) $request->get('iDisplayLength') : 25;
        $start = (int) $request->get('iDisplayStart');
        $currentPage = $request->get('sEcho') ? (int) $request->get('sEcho') : 1;
        $searchTerm = $request->get('sSearch') ? urldecode($request->get('sSearch')) : null;
        $searchPMToolRef = $request->get('sSearch_0');
        $searchMPNumber = $request->get('sSearch_1');
        $searchPOJobNumber = $request->get('sSearch_2');
        $searchLocation = $request->get('sSearch_3');
        $searchJobStartDate = $request->get('sSearch_4');
        $searchJobEndDate = $request->get('sSearch_5');
        $searchPmRequestDate = $request->get('sSearch_6');
        $searchPmSetDate = $request->get('sSearch_7');
        $searchCallCenterDate = $request->get('sSearch_8');
        $searchLocalPm = $request->get('sSearch_11');
        $searchCallCenter = $request->get('sSearch_12');
        $searchAccountPod = $request->get('sSearch_13');
        $paramArr = [
            'searchPMToolRef' => $searchPMToolRef,
            'searchMPNumber' => $searchMPNumber,
            'searchPOJobNumber' => $searchPOJobNumber,
            'location_id' => $location,
            'location_name' => $searchLocation,
            'sdate' => $sdate ? $sdate : $searchJobStartDate,
            'edate' => $edate ? $edate : $searchJobEndDate,
            'searchPmRequestDate' => $searchPmRequestDate,
            'searchPmSetDate' => $searchPmSetDate,
            'searchCallCenterDate' => $searchCallCenterDate,
            'pm' => $pm,
            'projectmanager' => $searchLocalPm,
            'ap' => $ap,
            'searchAccountPod' => $searchAccountPod,
            'sm' => $sm,
            'searchCallCenter' => $searchCallCenter,
            'sortColumn' => $sortColumn,
            'sortDirection' => $sortDirection,
            'searchTerm' => trim($searchTerm),
            'start' => $start,
            'displayPerPage' => $displayPerPage,
        ];

        $jobsWithLimit = $this->getTimingReportQuery($paramArr, true);
        $jobsWithOutLimit = $this->getTimingReportQuery($paramArr, false);

        $totalRecords = $jobsWithOutLimit->count();

        $results = [
            'sEcho' => $currentPage,
            'iTotalRecords' => $totalRecords,
            'iTotalDisplayRecords' => $totalRecords,
            'aaData' => [],
        ];
        $defaultDateFmt = $this->getDefaultDateFmt();
        foreach ($jobsWithLimit as $job) {
            $logProjectStatus = $job->getProjecLogStatusDateByEtude();
            $defineToDate = $this->getDiffTime($logProjectStatus['date_pm_set'], $logProjectStatus['date_pm_request']);
            $defineToCallCDate = $this->getDiffTime($logProjectStatus['date_call_center_set'], $logProjectStatus['date_pm_request']);
            $results['aaData'][] = [
                '<span data-id="'.$job->getEtudeId().'">'.$job->getEtude()->getNumeroEtude().'</span>',
                $job->getEtude()->getMasterProjectNumber(),
                $job->getIdSamsJob(),
                $job->getJobLocation()->getLibelle(),
                $job->getStartDate() ? date_format($job->getStartDate(), $defaultDateFmt) : '',
                $job->getEndDate() ? date_format($job->getEndDate(), $defaultDateFmt) : '',
                $logProjectStatus['date_pm_request'] ? date_format($logProjectStatus['date_pm_request'], 'Y-m-d H:i:s') : '',
                $logProjectStatus['date_pm_set'] ? date_format($logProjectStatus['date_pm_set'], 'Y-m-d H:i:s') : '',
                $logProjectStatus['date_call_center_set'] ? date_format($logProjectStatus['date_call_center_set'], 'Y-m-d H:i:s') : '',
                $defineToDate,
                $defineToCallCDate,
                $job->getJobProjectManager() ? ($job->getJobProjectManager()->getPreNom().' '.$job->getJobProjectManager()->getNom()) : '',
                $job->getCallCenter() ? $job->getCallCenter()->getValue() : '',
                $job->getJobPodAccount(),
            ];
        }

        return $this->json($results);
    }

    private function getTimingReportQuery($param, $limitStatus)
    {
        $firstOcc = $param['projectmanager'] ? explode(' ', $param['projectmanager']) : null;

        return JobQuery::create()
            ->distinct()
            ->_if(in_array($param['sortColumn'], ['pmSet.date', 'mainEtude.numero_etude', 'mainEtude.master_project_number', 'user.prenom', 'accountPod.value', 'timeToDefine'])
                    || $param['searchPmRequestDate']
                    || $param['searchPMToolRef']
                    || $param['searchMPNumber']
                    || $param['pm']
                    || $param['sm']
                    || $param['ap']
                    || $param['searchAccountPod']
                    )
                ->useEtudeQuery('mainEtude', Criteria::INNER_JOIN)
                    ->_if($param['searchPMToolRef'])
                        ->filterByNumeroEtude($param['searchPMToolRef'])
                    ->_endIf()
                    ->_if($param['searchMPNumber'])
                        ->filterByMasterProjectNumber($param['searchMPNumber'])
                    ->_endIf()
                    ->_if($param['pm'] || $param['projectmanager'] || in_array($param['sortColumn'], ['user.prenom']))
                        ->_if($param['pm'])
                            ->filterByIdPm($param['pm'])
                        ->_endif()
                        ->_if($param['projectmanager'])
                            ->useEtudeProjectManagerQuery()
                                ->filterByPrenom($firstOcc, Criteria::IN)
                                ->_or()
                                ->filterByNom($firstOcc, Criteria::IN)
                            ->endUse()
                        ->_endif()
                    ->_endif()
                    ->_if($param['sm'])
                        ->filterByIdBm($param['sm'])
                    ->_endif()
                    ->_if($param['ap'])
                        ->useAccountQuery()
                            ->filterByPodQualId($param['ap'], Criteria::IN)
                        ->endUse()
                    ->_endif()
                    ->_if(in_array($param['sortColumn'], ['accountPod.value']) || $param['searchAccountPod'])
                        ->useAccountQuery()
                            ->usePodQualQuery('accountPod', Criteria::LEFT_JOIN)
                                ->_if($param['searchAccountPod'])
                                    ->filterByValue($param['searchAccountPod'], Criteria::IN)
                                ->_endif()
                            ->endUse()
                        ->endUse()
                    ->_endif()
                    ->useLogProjectStatusQuery('pmSet', Criteria::LEFT_JOIN)
                        ->filterByStatus('%PM Definition Mail Sent to%', Criteria::LIKE)
                        ->_or()
                        ->filterByStatus('%Job Project Manager%', Criteria::LIKE)
                        ->_or()
                        ->filterByStatus('%call center changed%', Criteria::LIKE)
                        ->_if($param['searchPmRequestDate'])
                            ->filterByDate($param['searchPmRequestDate'], Criteria::EQUAL)
                        ->_endif()
                    ->endUse()
                ->endUse()
            ->_endif()
            ->_if($param['searchPOJobNumber'])
                ->filterByIdSamsJob($param['searchPOJobNumber'])
            ->_endif()
            ->useJobLocationQuery('jobLocation', Criteria::INNER_JOIN)
                ->_if($param['location_name'])
                    ->filterBySfLabel('%'.$param['location_name'].'%', Criteria::LIKE)
                ->_endif()
            ->endUse()
            ->_if(in_array($param['sortColumn'], ['callC.value']) || $param['searchCallCenter'])
                ->useCallCenterQuery('callC')
                    ->_if($param['searchCallCenter'])
                        ->filterByValue($param['searchCallCenter'], Criteria::IN)
                    ->_endif()
                ->endUse()
            ->_endif()
            ->_if($param['location_id'])
                ->filterByLocationId($param['location_id'])
            ->_endif()
            ->_if($param['sdate'])
                ->filterByStartDate($param['sdate'], Criteria::GREATER_EQUAL)
            ->_endif()
            ->_if($param['edate'])
                ->filterByEndDate($param['edate'], Criteria::LESS_EQUAL)
            ->_endif()
            ->_if($param['searchTerm'])
                ->useEtudeQuery('searchEtude', Criteria::INNER_JOIN)
                    ->filterByNumeroEtude($param['searchTerm'])
                    ->_or()
                    ->filterByMasterProjectNumber($param['searchTerm'])
                    ->_or()
                    ->useEtudeProjectManagerQuery('searchPmQ')
                        ->filterByPrenom($param['searchTerm'], Criteria::IN)
                        ->_or()
                        ->filterByNom($param['searchTerm'], Criteria::IN)
                    ->endUse()
                    ->_or()
                    ->useAccountQuery('searchAccount')
                        ->usePodQualQuery('searchAccountPod')
                            ->filterByValue($param['searchTerm'], Criteria::IN)
                        ->endUse()
                    ->endUse()
                ->endUse()
                ->_or()
                ->filterByIdSamsJob($param['searchTerm'])
                ->_or()
                ->useJobLocationQuery('searchJobLoc', Criteria::INNER_JOIN)
                    ->filterBySfLabel($param['searchTerm'], Criteria::EQUAL)
                ->endUse()
                ->_or()
                ->useCallCenterQuery('SearchCallC')
                    ->filterByValue($param['searchTerm'], Criteria::IN)
                ->endUse()
            ->_endif()
            ->orderBy($param['sortColumn'], 'desc' == $param['sortDirection'] ? Criteria::DESC : Criteria::ASC)
            ->_if($limitStatus)
                ->limit($param['displayPerPage'])
                ->offset($param['start'])
            ->_endif()
            ->addGroupByColumn(JobTableMap::COL_ID)
            ->find();
    }

    private function generateSheet(Request $request, SpreadsheetManager $spreadsheetManager): Response
    {
        $timingReport = $request->get('timing_report', []);
        $locationId = $timingReport['job_location'] ?? null;
        $pm = $timingReport['job_project_manager'] ?? null;
        $sm = $timingReport['salesManagers'] ?? null;
        $edate = $timingReport['edate'] ?? null;
        $sdate = $timingReport['sdate'] ?? null;
        $account_pod = $timingReport['account_pod'] ?? null;
        $paramArr = [
            'searchPMToolRef' => null,
            'searchMPNumber' => null,
            'searchPOJobNumber' => null,
            'location_id' => $locationId,
            'location_name' => null,
            'sdate' => $sdate,
            'edate' => $edate,
            'searchPmRequestDate' => null,
            'searchPmSetDate' => null,
            'searchCallCenterDate' => null,
            'pm' => $pm,
            'projectmanager' => null,
            'ap' => $account_pod,
            'searchAccountPod' => null,
            'sm' => $sm,
            'searchCallCenter' => null,
            'sortColumn' => 'mainEtude.numero_etude',
            'sortDirection' => 'desc',
            'searchTerm' => null,
            'start' => null,
            'displayPerPage' => null,
        ];
        $jobs = $this->getTimingReportQuery($paramArr, false);
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('report');

        $header = ['PM Tool reference', 'Master Project Manager', 'Job number',
        'Location', 'Job Start Date', 'Job End Date', 'Date PM Request (UTC)',
        'Date PM set (UTC)', 'Date Call Center set (UTC)', 'Time to define PM',
        'Time to define Call Center', 'Local PM', 'Call Center', 'Account Pod',
        ];
        $spreadsheetManager->setHeader($sheet, $header);
        $i = 0;
        $defaultDateFmt = $this->getDefaultDateFmt();
        foreach ($jobs as $job) {
            $logProjectStatus = $job->getProjecLogStatusDateByEtude();
            $timeToDefine = $this->getDiffTime($logProjectStatus['date_pm_set'], $logProjectStatus['date_pm_request']);
            $timeToDefineCallC = $this->getDiffTime($logProjectStatus['date_call_center_set'], $logProjectStatus['date_pm_request']);
            $spreadsheetManager->setRowData($sheet, $i + 2, [
                $job->getEtude() ? $job->getEtude()->getNumeroEtude() : '',
                $job->getEtude()->getMasterProjectNumber(),
                $job->getIdSamsJob(),
                $job->getJobLocation(),
                $job->getStartDate() ? date_format($job->getStartDate(), $defaultDateFmt) : '',
                $job->getEndDate() ? date_format($job->getEndDate(), $defaultDateFmt) : '',
                $logProjectStatus['date_pm_request'],
                $logProjectStatus['date_pm_set'],
                $logProjectStatus['date_call_center_set'],
                $timeToDefine,
                $timeToDefineCallC,
                $job->getJobProjectManager(),
                $job->getCallCenter() ? $job->getCallCenter()->getValue() : '',
                $job->getJobPodAccount(),
            ]);
            ++$i;
        }

        $spreadsheetManager->setAutoColumnWidth($sheet, 'A', 'AO');

        return $spreadsheetManager->createResponse($spreadsheet, 'Timing Report - PM');
    }

    private function getDiffTime($fromDate, $toDate)
    {
        $time = null;
        if (isset($fromDate) && isset($toDate)) {
            $daysDifference = $toDate->diff($fromDate, true)->days;
            $sundays = intval($daysDifference / 7) + ($toDate->format('N') + $daysDifference % 7 >= 7);
            $holidays = $this->getHolidays($toDate, $fromDate);
            $weekends = $sundays * 2;
            $totalNoOfHolidayHours = (($weekends + $holidays) * 24);

            $startDate = new DateTime($fromDate->format('Y-m-d H:i:s'));
            $endDate = new DateTime($toDate->format('Y-m-d H:i:s'));
            $diff = $startDate->diff($endDate);

            $time = (($diff->format('%a') * 24) + $diff->format('%h') - $totalNoOfHolidayHours).':'.$diff->format('%i').':'.$diff->format('%s');
        }

        return $time;
    }

    private function getHolidays($startDate, $endDate)
    {
        $holidayCounts = CountryHolidayQuery::create()->filterByCountryCode($this->instance)
                        ->filterByDayHoliday(['min' => $startDate, 'max' => $endDate])
                        ->count();

        return $holidayCounts;
    }
}
