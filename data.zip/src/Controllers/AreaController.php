<?php

namespace Controllers;

use Datagrid\Referentiel\AreaDatagrid;
use Form\Type\Referentiel\AreaType;
use Model\Area;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AreaController extends BaseController
{
    /**
     * @Route(name="area_list", path="/area-list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "datagrid": "", "param1": "", "param2": ""})
     */
    public function listAction(Request $request): Response
    {
        return $this->render('pmtool/area/list.html.twig', [
            'datagrid' => (new AreaDatagrid($this->container))->execute(),
        ]);
    }

    /**
     * @Route(name="area_new", path="/area/new")
     */
    public function newAction(Request $request): Response
    {
        $object = new Area();
        $form = $this->createForm(AreaType::class, $object);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $object->save();
            $this->addFlash('success', 'New Area saved');

            return $this->redirectToRoute('area_list');
        } elseif ($form->isSubmitted()) {
            $this->addFlash('danger', "The new Area can't be saved. Check the informations and try again.");
        }

        return $this->render('pmtool/area/new.html.twig', ['form' => $form->createView()]);
    }

    /**
     * @Route(name="area_update", path="/area/{id}/edit", defaults={"id": ""})
     */
    public function editAction(Request $request, Area $object): Response
    {
        $form = $this->createForm(AreaType::class, $object)
            ->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $object->save();
            $this->addFlash('success', "Area's changes saved.");

            return $this->redirectToRoute('area_list', ['id' => $object->getId()]);
        } elseif ($form->isSubmitted()) {
            $this->addFlash('warning', "Changes can't be saved, check informations and try again");
        }

        return $this->render('pmtool/area/edit.html.twig', ['object' => $object, 'form' => $form->createView()]);
    }
}
