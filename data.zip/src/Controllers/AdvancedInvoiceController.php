<?php

namespace Controllers;

use Form\Type\AdvancedInvoiceSyntheseType;
use Manager\AdvancedInvoiceManager;
use Model\Document;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdvancedInvoiceController extends BaseController
{
    /**
     * @Route(name="advanced_invoice_report", path="/advancedInvoice")
     */
    public function indexAction(Request $request, AdvancedInvoiceManager $advancedInvoiceManager): Response
    {
        $syntheseRubriques = $selection_suplementaire = '';
        $account_ids = $isSend = $date_debut = $date_fin = null;
        $sendFilter = $request->get('send');
        if ($sendFilter) {
            $selection_suplementaire = ' AND facture.is_send != 1 AND document_br in ("'.Document::ADVANCED_INVOICE.'", "'.Document::DOWNPAYMENT.'")';
        }
        $form = $this->createForm(AdvancedInvoiceSyntheseType::class);
        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $account_ids_submitted = $form->get('accounts')->getData()->toKeyValue('Id', 'Id');
                $date_debut = $form->get('dateDebut')->getData();
                $date_fin = $form->get('dateFin')->getData();
                $isSend = $form->get('send')->getData();
                $selection_suplementaire = ' ';
                if (count($account_ids_submitted)) {
                    $account_ids = implode(',', $account_ids_submitted);
                    $selection_suplementaire .= " AND account_id IN ($account_ids) ";
                }
                if (isset($date_debut) && $date_debut instanceof \DateTime) {
                    $date_debut = $date_debut->format('Y-m-d');
                    $selection_suplementaire = $selection_suplementaire." AND facture.date >='".$date_debut."' ";
                }
                if (isset($date_fin) && $date_fin instanceof \DateTime) {
                    $date_fin = $date_fin->format('Y-m-d');
                    $selection_suplementaire = $selection_suplementaire." AND facture.date <='".$date_fin."' ";
                }
                if (isset($isSend)) {
                    $selection_suplementaire = $selection_suplementaire." AND facture.is_send ='".$isSend."' ";
                }
                /** @var Form $form */
                $button = $form->getClickedButton();
                if ($button && 'export' === $button->getName()) {
                    $syntheseRubriques = $advancedInvoiceManager->getInvoices($account_ids, $date_debut, $date_fin, $isSend, $sendFilter, $selection_suplementaire);

                    return $advancedInvoiceManager->exportInvoices($syntheseRubriques);
                }
            }
        }

        if (!$syntheseRubriques) {
            $syntheseRubriques = $advancedInvoiceManager->getInvoices($account_ids, $date_debut, $date_fin, $isSend, $sendFilter, $selection_suplementaire);
        }

        return $this->render('pmtool/pages/advancedInvoice.html.twig', [
            'syntheseRubriques' => $syntheseRubriques,
            'date_debut' => $date_debut,
            'date_fin' => $date_fin,
            'form' => $form->createView(),
        ]);
    }
}
