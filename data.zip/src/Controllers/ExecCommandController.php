<?php

namespace Controllers;

use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\BufferedOutput;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\Routing\Annotation\Route;

class ExecCommandController extends Controller
{
    /**
     * @Route(name="am_checked", path="/execCommand/amChecked/{instance}")
     */
    public function amCheckedAction(Request $request, KernelInterface $kernel): Response
    {
        $instance = $request->get('instance');
        $application = new Application($kernel);
        $application->setAutoExit(false);
        $input = new ArrayInput([
            'command' => 'app:am:checked',
            'instance' => $instance,
        ]);
        $output = new BufferedOutput();
        $application->run($input, $output);
        $content = $output->fetch();

        return new Response($content);
    }

    /**
     * @Route(name="auto_refresh", path="/execCommand/autoRefresh")
     */
    public function autoRefreshAction(KernelInterface $kernel): Response
    {
        $application = new Application($kernel);
        $application->setAutoExit(false);
        $input = new ArrayInput([
            'command' => 'app:report:refresh',
        ]);
        $output = new BufferedOutput();
        $application->run($input, $output);
        $content = $output->fetch();

        return new Response($content);
    }

    /**
     * @Route(name="add_group_discount_jobs", path="/execCommand/addGroupDiscountJobs")
     */
    public function addGroupDiscountJobsAction(KernelInterface $kernel): Response
    {
        $application = new Application($kernel);
        $application->setAutoExit(false);
        $input = new ArrayInput([
            'command' => 'app:add:group-discount',
        ]);
        $output = new BufferedOutput();
        $application->run($input, $output);
        $content = $output->fetch();

        return new Response($content);
    }

    /**
     * @Route(name="clear_bid_job_items_discount", path="/execCommand/clearBidJobItemsDiscount")
     */
    public function clearBidJobItemsDiscountAction(KernelInterface $kernel): Response
    {
        $application = new Application($kernel);
        $application->setAutoExit(false);
        $input = new ArrayInput([
            'command' => 'app:clear:discount-auto',
        ]);
        $output = new BufferedOutput();
        $application->run($input, $output);
        $content = $output->fetch();

        return new Response($content);
    }
}
