<?php

namespace Controllers;

use DateTime;
use Form\Type\EtudeFacturesType;
use Form\Type\EtudeReglementsType;
use Form\Type\EtudeType;
use Importer\JobImporter;
use Manager\FileManager;
use Manager\MailManager;
use Manager\SalesforceManager;
use Manager\SpreadsheetManager;
use Model\Account;
use Model\AmReasonTypeQuery;
use Model\Area;
use Model\BanqueQuery;
use Model\BidJobItemQuery;
use Model\BidJobQuery;
use Model\CategoriePrestation;
use Model\ContactQuery;
use Model\DernierAccesQuery;
use Model\DocumentQuery;
use Model\Etape;
use Model\Etude;
use Model\EtudeCheckListValidation;
use Model\EtudeCheckListValidationQuery;
use Model\EtudeFichier;
use Model\EtudeMethodology;
use Model\EtudeQuery;
use Model\EtudeSampleSource;
use Model\Event;
use Model\EventQuery;
use Model\FactureQuery;
use Model\Fichier;
use Model\FichierQuery;
use Model\Groupe;
use Model\Job;
use Model\JobCostQuery;
use Model\JobItem;
use Model\JobItemQuery;
use Model\JobQuery;
use Model\Location;
use Model\LogProjectStatus;
use Model\LogProjectStatusQuery;
use Model\Map\FichierTableMap;
use Model\Map\JobCostTableMap;
use Model\Map\RefSalesForceTableMap;
use Model\Methodology;
use Model\ModuleQuery;
use Model\Opportunity;
use Model\PaysQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefSalesForce;
use Model\RefSalesForceEtudeSector;
use Model\RefSalesForceQuery;
use Model\SampleSourceQuery;
use Model\User;
use Model\UserQuery;
use PDO;
use PhpOffice\PhpSpreadsheet\Exception;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpWord;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Propel;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Html2Pdf;
use SplFileInfo;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\HttpFoundation\File\Exception\PartialFileException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\UrlHelper;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Util\HtmlPurifier;

class EtudeController extends BaseController
{
    /**
     * @Route(name="etude_new_kohana", path="/project-new/{opportunity_id}", defaults={"opportunity_id": ""})
     * @Route(name="etude_new", path="/project/new/{opportunity_id}/{bid_id}", defaults={"opportunity_id": "", "bid_id": ""})
     */
    public function newAction(Request $request, MailManager $mailerManager, SalesforceManager $sfManager, string $uploadDir): Response
    {
        ini_set('memory_limit', '512M');

        $logProjectStatus = null;
        $user = $this->getUser();
        $sfId = $user->getSfIdOrDefault();
        $etude = new Etude();
        $etude->setIdEtape(Etape::STUDY_CREATION);
        $etude->setBookedBySfId($sfId);
        $etude->setCreatedBySfId($sfId);
        $etude->setAccountManagerSfId($sfId);
        $etude->setCreatedBy($user);
        $etude->setCreatedByComment('Created by: '.$user->getId());
        $tbdUser = UserQuery::create()
                ->filterByNom('TBD')
                ->select('id')
                ->findOne();
        $jobCallCenterStatus = RefSalesForceQuery::create()
            ->filterByActif(true)
            ->filterByField('call_center')
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB)
            ->filterByValue('Not Applicable')
             ->select('id')
            ->findOne();

        if ('fr' === $this->instance) {
            $etude->setSmsRelance(true);
        }

        $uploadedFile = $request->files->get('file');

        $currenciesGQS = $request->get('currencieGQS');

        $stageWonId = RefSalesForce::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'Closed Won');
        $methodologies = new ObjectCollection();

        $opportunityEventsDetailsOnHover = '';
        // ticket #20764 user "0_Not Applicable"
        $etude->setAccountPM(UserQuery::create()->findOneBySfId('0054Q00000EVkTbQAL'));
        if ($opportunity = Opportunity::getById($request->get('opportunity_id'))) {
            foreach ($opportunity->getRefMethodologies() as $refMethodology) {
                if ($methodology = $refMethodology->getSalesForceOpportunityMethodology()) {
                    $methodologies->append($methodology);
                }
            }

            $sectors = new ObjectCollection();
            foreach ($opportunity->getRefSalesForceOpportunityRefSectors() as $type) {
                $sectors->append($type);
            }

            $services = new ObjectCollection();
            foreach ($opportunity->getRefSalesForceOpportunityRefServicess() as $type) {
                $services->append($type);
            }
            $opportunityEvents = $opportunity->getEventsNotDeleted();
            foreach ($opportunityEvents as $event) {
                $opportunityEventsDetailsOnHover .= $event->getLocation() ? 'Location : '.$event->getLocation()->getLibelle().' ' : ' ';
                $opportunityEventsDetailsOnHover .= 'Date : '.$event->getDate('Y-m-d').' ';
                $opportunityEventsDetailsOnHover .= 'Status : '.$event->getRefEventStatus()."\n";
            }
            $studySpec = 'on' == $opportunity->getisStudySpecification();
            $etudeLocation = $this->getEtudeDataRegardingOpportunityIsRoomRental($opportunity, 'etude_location', null);
            $etudeSampleSource = $this->getEtudeDataRegardingOpportunityIsRoomRental($opportunity, 'sample_source', null);
            $etudeStartDate = $this->getEtudeDataRegardingOpportunityIsRoomRental($opportunity, 'date_debut', $opportunityEvents);
            $etudeEndDate = $this->getEtudeDataRegardingOpportunityIsRoomRental($opportunity, 'date_fin', $opportunityEvents);
            if ($etudeSampleSource) {
                $etude->setSampleSources($etudeSampleSource);
            }
            if ($etudeLocation) {
                $etude->setEtudeLocation($etudeLocation);
            }
            if ($etudeStartDate && $etudeEndDate) {
                $etude->setDateDebut($etudeStartDate);
                $etude->setDateFin($etudeEndDate);
            }
            $etude->setRefSalesForceEtudeRefSectors($sectors);
            $etude->setOpportunity($opportunity);
            $etude->setAccount($opportunity->getAccount());
            $etude->setContact($opportunity->getContact());
            $etude->setContactClientPm($opportunity->getContact());
            $etude->setReferenceClient($opportunity->getProjectNumber());
            $etude->setJobQualification($opportunity->getJobQualification());
            $etude->setMethodologies($methodologies);
            $etude->setProposedN($opportunity->getLoiOption1());
            $etude->setTheme($opportunity->getOpportunitySubject());
            $etude->setThemeBr($opportunity->getOpportunitySubject());
            $etude->setIndustry($opportunity->getIndustry());
            $etude->setCreatedByComment('Created From Opportunity '.$opportunity->getId().' by: '.$this->getUser()->getId());
            $etude->setRecruitsOffsite($opportunity->getRecruitsOffsite());
            $etude->setRoomRental($opportunity->getRoomRental());
            $etude->setCurrencies($opportunity->getCurrencies());
            $etude->setUsGlobalQualGms($opportunity->getUsGlobalQualGms());
            $etude->setCurrencyIsoCode($opportunity->getCurrencyIsoCode());
            $etude->setisStudySpecification($studySpec);
            $etude->setStudySpecification($opportunity->getStudySpecification());
            $etude->setFilePath($opportunity->getFilePath());
            $etude->setProjectAccountManager($opportunity->getOpportunityAccountManager());
            $etude->setProjectSpecialtySponsor($opportunity->getOpportunitySpecialtySponsor());
            $etude->setClientDiscountPercentage($opportunity->getClientDiscountPercentage());
            $etude->setEndClientDiscountPercentage($opportunity->getEndClientDiscountPercentage());
            $etude->setClientQuantDiscountPercentage($opportunity->getClientQuantDiscountPercentage());
            $etude->setEndClientQuantDiscountPercentage($opportunity->getEndClientQuantDiscountPercentage());
            $etude->setSamplePlan($opportunity->getSamplePlan());
            $etude->setSharepointFolder($opportunity->getSharepointFolder());

            $etude->setEndClient($opportunity->getEndClient() ?: Account::getNotApplicable());
            $etude->setEndClientContact($opportunity->getEndClientContact());
            $etude->setIntermediateClient($opportunity->getIntermediateClient() ?: Account::getNotApplicable());
            $etude->setIdPm($tbdUser);
            $etude->setFaciltyNote($opportunity->getFaciltyNote());
            $etude->setSampleSources($opportunity->getSampleSources());
            $logProjectStatus = (new LogProjectStatus())
                ->setEtude($etude)
                ->setStatus('PM is set to TBD')
                ->setDate(new DateTime())
                ->setUser($this->getUser());
            $opptBidJobs = BidJobQuery::create()->findByBidId($request->get('bid_id'));
            // add jobs
            foreach ($opptBidJobs as $opptBidJob) {
                $isMultiMarket = 'on' == $opptBidJob->getIsMultimarket();

                $job = new Job();
                $location = $opptBidJob->getLocation();
                $job->setJobLocation($location);
                $job->setBidJobId($opptBidJob->getId());
                $job->setPerDay($opptBidJob->getPerDay());
                $job->setPerHour($opptBidJob->getPerHour());
                $job->setPerGroup($opptBidJob->getPerGroup());
                $job->setMultimarketInCalculation($opptBidJob->getMultimarketInCalculation());
                $job->setIsMultimarket($isMultiMarket);
                $job->setName($opptBidJob->getName());
                $job->setPlatformId($opptBidJob->getProductId());
                $job->setJobAccountManager($opportunity->getOpportunityAccountManager());
                $job->setClientProjectNumber($opportunity->getProjectNumber());
                $job->originalId = $opptBidJob->getId();
                $job->setCallCenterId($jobCallCenterStatus);
                $job->setPmId($tbdUser);
                $etude->addJobEtude($job);
            }
        } else {
            $job = new Job();
            $job->setMethodologies($methodologies);
            $job->setPmId($tbdUser);
            $etude->addJobEtude($job);
            $etude->setIdPm($tbdUser);
        }
        $form = $this->createForm(EtudeType::class, $etude, ['user' => $this->getUser(), 'opportunity' => $opportunity ?? null]);
        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                if ($uploadedFile) {
                    $fileName = 'study_specification_'.date('y_m_dh_i_s').'.'.(new \SplFileInfo($uploadedFile->getClientOriginalName()))->getExtension();
                    $uploadedFile->move($uploadDir, $fileName);
                    $etude->setFilePath($fileName);
                }
                $etude = $form->getData();
                if ($opportunity && '' == $currenciesGQS) {
                    $etude->setCurrencies($opportunity->getCurrencies());
                } else {
                    $etude->setCurrencies($currenciesGQS);
                }
                $clientDiscountPercentageFormValue = $form->get('client_discount_percentage')->getData();
                $endClientDiscountPercentageFormValue = $form->get('end_client_discount_percentage')->getData();
                if ($etude->getAccount() && $client = $etude->getAccount()) {
                    $etude->setClientDiscountPercentage(null === $clientDiscountPercentageFormValue ? $client->getClientDiscountPercentageByInstance($this->instance) : $clientDiscountPercentageFormValue);
                }
                if ($etude->getEndClient() && $endClient = $etude->getEndClient()) {
                    $etude->setEndClientDiscountPercentage(null === $endClientDiscountPercentageFormValue ? $endClient->getClientDiscountPercentageByInstance($this->instance) : $endClientDiscountPercentageFormValue);
                }
                $etude->setIsSendCsatQuestMail(true);
                $etude->generateStudyNumber($this->instance);
                if ('fr' === $this->instance) {
                    $jobQual = $etude->getJobQualification();
                    if ('V' === $etude->getNumeroEtude()[0] || in_array($jobQual->getValue(), ['Quant - Online', 'Quant - Traditional - Field'])) {
                        $etude->setSmsRelance(false);
                    }
                }

                $etude->save();
                if ($logProjectStatus) {
                    $logProjectStatus->save();
                }

                //set etude_fichier for etudes that were copied from opportunities
                if ($opportunity) {
                    $opp_fichiers = $opportunity->getOpportunityFichiers();

                    foreach ($opp_fichiers as $fichier) {
                        $etude_fichier = new EtudeFichier();
                        $etude_fichier->setFichierId($fichier->getFichierId());
                        $etude_fichier->setEtude($etude);
                        $etude_fichier->save();
                    }
                }

                //create etude_fichier for new etudes
                if (isset($_SESSION['new_etude_id'])) {
                    $unique_etude_temp_id = isset($_SESSION['new_etude_id']) ? $_SESSION['new_etude_id'] : '';

                    // FIXME rewrite entirely
                    $files = scandir($uploadDir);
                    foreach ($files as $file) {
                        if (false !== strpos($file, ''.$unique_etude_temp_id)) {
                            $con = Propel::getConnection();
                            $sql = 'SELECT * FROM fichier WHERE fichier_original = ?';
                            $stm = $con->prepare($sql);
                            $stm->bindValue(1, $file, PDO::PARAM_STR);
                            $stm->execute();
                            $results = $stm->fetchAll();
                            $etude_fichier = new EtudeFichier();
                            $etude_fichier->setFichierId($results[0][0]);
                            $etude_fichier->setEtude($etude);
                            $etude_fichier->save();
                        }
                    }

                    //delete temp etude placeholder cookie
                    unset($_SESSION['new_etude_id']);
                }

                $study_spec_images = HtmlPurifier::getContents($etude->getStudySpecification(), 'file-name=', '"');
                $additional_notes_images = HtmlPurifier::getContents($etude->getAdditionalNotes(), 'file-name=', '"');
                $sample_plan_images = HtmlPurifier::getContents($etude->getSamplePlan(), 'file-name=', '"');
                $project_comment_images = HtmlPurifier::getContents($etude->getProjectComment(), 'file-name=', '"');

                //delete unused images
                $this->deleteUnusedImages($etude->getId(), array_merge($study_spec_images, $additional_notes_images, $sample_plan_images, $project_comment_images), $uploadDir);

                if ($etude->haveBadPayer()) {
                    $this->mailBadPayer($etude, $mailerManager);
                }

                foreach ($etude->getJobEtudes() as $job) {
                    /** @var Job $job */
                    //check if bid job items exist and add them to job(s)
                    if (isset($job->originalId)) {
                        $OpptBidJobItems = BidJobItemQuery::create()->findByBidJobId($job->originalId);
                        $this->convertJobItems($job->getId(), $OpptBidJobItems);
                        $job->setInitialCostRegardingJobItems();
                        $job->setInitialRevenueRegardingJobItems();
                    }

                    if (RefSalesForce::JOB_STATUS_ACTIVE == $job->getStatus() && !$job->getActiveDate()) {
                        $job->setActiveDate(new DateTime());
                    }

                    $logValues = null;
                    if ($job->getEndDateReason()) {
                        $logValues .= ' - Reason: '.($job->getEndDateReason() ? $job->getEndDateReason() : '');
                    }
                    if ($logValues) {
                        $initValue = $job->getIdSamsJob() ?: $job->getJobLocation().'  '.$job->getName();
                        $job->addCheckBoxHistory($user, $initValue.$logValues);
                    }
                }
                $etude->save();
                if ($opportunity) {
                    // Attach all Events to corresponding Jobs
                    foreach ($opportunity->getBids() as $bid) {
                        foreach ($bid->getJobs() as $bidJob) {
                            foreach ($bidJob->getEvents() as $event) {
                                if (!$event->getJobId()) {
                                    foreach ($etude->getJobEtudes() as $job) {
                                        if ($bidJob->getLocationId() == $job->getLocationId()) {
                                            $event->setJobId($job->getId());
                                        }
                                    }
                                    $event->save();
                                }
                            }
                        }
                    }

                    $opportunity->setPmtoolUpdated(true);
                    $opportunity->setStageNameId($stageWonId);
                    $opportunity->save();
                    $sfManager->setOpportunityClosedWon($opportunity);
                }

                $this->addFlash('success', 'Master Project created.');

                $user = $this->getUser();

                //log project status
                $etude->addProjectStatusLog($user);

                foreach ($sfManager->pushJobs($etude) as $error) {
                    $error ? $this->addFlash('warning', $error) : null;
                }

                // This method is used to fix Master location prefix
                $this->updateMasterLocationPrefix($etude);

                // update fields into salesforce via API call
                if ($response = $sfManager->updateMasterProjectFields($etude)) {
                    $this->addFlash('warning', 'Salesforce answered for project fields: '.$response);
                } elseif ($etude->getMasterProjectSfId()) {
                    $this->addFlash('success', 'Project fields successfully updated in Salesforce.');
                }

                $this->updateIdSamsJobForNonActiveJob($etude);
                foreach ($etude->getJobEtudes() as $job) {
                    if (in_array($job->getStatus(), ['Active', 'Confirmed']) && in_array($job->getPlatform()->getName(), ['Moderate Anywhere', 'QualBoard Rental Only'])) {
                        $mailerManager->sendToJobSectionMail($job);
                    }
                }

                return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
            } else {
                $this->addFlash('danger', 'Master Project validation errors.');
            }
        }

        return $this->render('pmtool/project/new.html.twig', [
            'form' => $form->createView(),
            'opportunity' => $opportunity,
            'etude' => $etude,
            'choiceAreas' => Area::getForJson(),
            'choiceMethodologies' => Methodology::getForJson(),
            'quantOnlineId' => Etude::getQualificationQuantOnLineType(),
            'qualificationQuantType' => array_values(Etude::getQualificationQuantType()),
            'currencies' => Location::getCurrencies($this->instance),
            'isAdmin' => in_array($user->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'isAdminOrDirector' => in_array($user->getIdGroupe(), [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'defaultAcctMngrId' => 0,
            'toInvoice' => Etape::TO_INVOICE,
            'opportunityEventsDetailsOnHover' => $opportunityEventsDetailsOnHover,
            'can_update_ins_gqs_rst_cli_checkboxes' => in_array($user->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
        ]);
    }

    /**
     * @Route(name="etude_upload_images", path="/etude/{id}/etude_upload_images", defaults={"id": ""})
     */
    public function uploadImages(Request $request, string $uploadDir): Response
    {
        if (isset($_FILES['upload']['name'])) {
            ini_set('memory_limit', '512M');
            $isNew = boolval((int) $request->get('isnew'));
            $etude = $isNew ? new Etude() : Etude::getById($request->get('id'));

            $file = $_FILES['upload']['tmp_name'];
            $file_name = $_FILES['upload']['name'];
            $file_name_array = explode('.', $file_name);
            $extension = strtolower(end($file_name_array));
            $timestamp = hrtime(true);
            $new_image_name = '';
            $new_etude_temp_id = '';
            $response = new Response();
            $final_width = 0;
            $final_height = 0;
            if ($isNew) {
                $new_etude_temp_id = isset($_SESSION['new_etude_id']) ? $_SESSION['new_etude_id'] : rand(10000, 99999);
                $_SESSION['new_etude_id'] = $new_etude_temp_id;
            }

            $new_image_name = $isNew ? 'new_etude_'.$new_etude_temp_id.'_'.$timestamp.'.'.$extension : 'etude_'.$request->get('id').'_img_'.$timestamp.'.'.$extension;
            $allowed_extension = ['jpeg', 'jpg', 'png'];
            if (in_array($extension, $allowed_extension)) {
                $maxDim = 800;
                list($width, $height, $type, $attr) = getimagesize($file);
                $final_width = $width;
                $final_height = $height;
                if ($width > $maxDim || $height > $maxDim) {
                    $target_filename = $file;
                    $ratio = $width / $height;
                    if ($ratio > 1) {
                        $new_width = $maxDim;
                        $new_height = $maxDim / $ratio;
                    } else {
                        $new_width = $maxDim * $ratio;
                        $new_height = $maxDim;
                    }
                    $src = imagecreatefromstring(file_get_contents($file));
                    $dst = imagecreatetruecolor($new_width, $new_height);
                    imagealphablending($dst, false);
                    imagesavealpha($dst, true);
                    imagecopyresampled($dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                    imagedestroy($src);
                    if ('jpeg' == $extension || 'jpg' == $extension) {
                        imagejpeg($dst, $target_filename, 0); // adjust format as needed
                    } else {
                        imagepng($dst, $target_filename, 0); // adjust format as needed
                    }
                    $final_width = $new_width;
                    $final_height = $new_height;
                }

                move_uploaded_file($file, $uploadDir.$new_image_name);

                $function_number = $_GET['CKEditorFuncNum'];
                $url = $this->generateUrl('etude_image_file', ['file-name' => $new_image_name]);
                $message = '';

                //upload to db
                $fichier = new Fichier();
                $fichier->setFichier(explode('.', $new_image_name)[0]);
                $fichier->setExtension((new SplFileInfo($new_image_name))->getExtension());
                $mimeType = $request->files->get('upload')->getClientMimeType() ?: 'application/octet-stream';
                $fichier->setMimeType($mimeType);
                $fichier->setFichierOriginal($new_image_name);
                $fichier->setType(FichierTableMap::COL_TYPE_GDPR);
                $fichier->setDateCreation(new \DateTime());
                $fichier->setFichier($fichier->getFichier().'.'.$fichier->getExtension());
                $fichier->save();

                if (!$isNew) {
                    $etudeFichier = new EtudeFichier();
                    $etudeFichier->setEtude($etude);
                    $etudeFichier->setFichier($fichier);
                    $etudeFichier->save();
                }

                $content = '';
                if ('true' == $request->get('isDragDrop')) {
                    return $this->json([
                        'uploaded' => 1,
                        'fileName' => $new_image_name,
                        'url' => $url,
                        'width' => $final_width,
                        'height' => $final_height,
                    ]);
                } else {
                    $content = "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($function_number, '$url', '$message');</script>\n";
                }
                $response->setContent($content);

                return $response;
            }

            $response->headers->set('Content-Type', 'text/html');
            $response->sendHeaders();
            $content = '<p>File type not supported.</p>';
            $response->setContent($content);

            return $response;
        }
        throw $this->createNotFoundException('File Not Found');
    }

    /**
     * @Route(name="etude_image_file", path="/etude/etude_image_file")
     */
    public function getImageAction(Request $request, string $uploadDir): Response
    {
        $fileName = $request->get('file-name', '');
        if (!$fileName) {
            return new Response(null); // FIXME rewrite entirely
        }
        try {
            $response = new BinaryFileResponse($uploadDir.$fileName);
            $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $fileName);

            return $response;
        } catch (FileNotFoundException $e) {
            throw $this->createNotFoundException();
        }
    }

    private function deleteUnusedImages(int $study_id, array $etude_files, string $uploadDir)
    {
        $server_files = $this->query('SELECT fichier.id, fichier FROM fichier WHERE fichier LIKE ? AND is_visible = 1', ['%etude_'.$study_id.'%']);
        $files_to_update = [];
        $study_files_to_delete = [];
        foreach ($server_files as $server_file) {
            $exists = false;
            foreach ($etude_files as $etude_file) {
                if ($etude_file == $server_file->fichier) {
                    $exists = true;
                    break;
                }
            }

            if (!$exists) {
                //delete etude_fichier record
                array_push($study_files_to_delete, $server_file->id);

                //check if file exists anywhere else
                $all_file_instances = $this->query('SELECT etude_fichier.etude_id etude_id,
                    opportunity_fichier.opportunity_id opportunity_id
                    FROM etude_fichier
                    LEFT OUTER JOIN opportunity_fichier
                    ON etude_fichier.fichier_id = opportunity_fichier.fichier_id
                    WHERE etude_fichier.fichier_id = ?', [$server_file->id]);

                $contains_other_instances = false;
                foreach ($all_file_instances as $file_instance) {
                    if ($file_instance->etude_id != $study_id) {
                        $contains_other_instances = true;
                    }
                }

                if (!$contains_other_instances) {
                    array_push($files_to_update, $server_file->id);
                    @unlink($uploadDir.$server_file->fichier);
                }
            }
        }

        if (!empty($files_to_update)) {
            $this->query('UPDATE fichier SET is_visible = 0 WHERE id IN ('.implode(',', $files_to_update).')');
        }
        if (!empty($study_files_to_delete)) {
            $this->query('DELETE FROM etude_fichier WHERE etude_id = ? AND fichier_id IN ('.implode(',', $study_files_to_delete).')', [$study_id]);
        }
    }

    private function getEtudeDataRegardingOpportunityIsRoomRental($opportunity, $etudeDataField, $opportunityEvents)
    {
        $data = '';
        if ($opportunity->isRoomRental()) {
            if ('sample_source' == $etudeDataField) {
                $sampleSourceCollection = new ObjectCollection();
                $notApplicableSampleSource = SampleSourceQuery::create()->filterByActif(true)->filterBySfLabel('Not Applicable')->findOne();
                $sampleSourceCollection->append($notApplicableSampleSource);
                $data = $sampleSourceCollection;
            } elseif ('etude_location' == $etudeDataField) {
                $firstBid = $opportunity->getBids()->getFirst();
                if (!is_null($firstBid)) {
                    $bidJobs = $firstBid->getJobs();
                    $firstBidJob = $bidJobs[0];
                    $data = $firstBidJob->getLocation() ? $firstBidJob->getLocation() : null;
                }
            } elseif ('date_debut' == $etudeDataField) {
                if (!is_null($opportunityEvents)) {
                    $events = Event::orderByDateAndStartDate($opportunityEvents);
                    $firstEventOrderByDateAndStartDate = reset($events);
                    if (is_object($firstEventOrderByDateAndStartDate)) {
                        $data = $firstEventOrderByDateAndStartDate->getDate();
                    }
                }
            } elseif ('date_fin' == $etudeDataField) {
                if (!is_null($opportunityEvents)) {
                    $events = Event::orderByDateAndStartDate($opportunityEvents);
                    $lastEventOrderByDateAndStartDate = end($events);
                    if (is_object($lastEventOrderByDateAndStartDate)) {
                        $data = $lastEventOrderByDateAndStartDate->getDate();
                    }
                }
            }
        }

        return $data;
    }

    private function convertJobItems($jobId, $opptBidJobItems)
    {
        foreach ($opptBidJobItems as $opptBidJobItem) {
            $bidJobItem = new JobItem();
            $bidJobItem->setDate($opptBidJobItem->getDate());
            $bidJobItem->setCategoriePrestation($opptBidJobItem->getSection());
            $bidJobItem->setSousTypePrestation($opptBidJobItem->getTitle());
            $bidJobItem->setQuantitePr($opptBidJobItem->getCostQty());
            $bidJobItem->setCoefficiantPr($opptBidJobItem->getCostRate());
            $bidJobItem->setPrixRevient($opptBidJobItem->getCostPrice());
            $bidJobItem->setQuantitePv($opptBidJobItem->getSellingQty());
            $bidJobItem->setPrixVenteUnitaire($opptBidJobItem->getSellingUnitPrice());
            $bidJobItem->setPrixRevientUnitaire($opptBidJobItem->getCostLocationUnitPrice());
            $bidJobItem->setPrixVente($opptBidJobItem->getSellingPrice());
            $bidJobItem->setMethodologyId($opptBidJobItem->getMethodologyId());
            $bidJobItem->setRespLocationId($opptBidJobItem->getRespLocationId());
            $bidJobItem->setVendorId($opptBidJobItem->getVendorId());
            $bidJobItem->setRespondentTypeId($opptBidJobItem->getRespondentTypeId());
            $bidJobItem->setCommentPm($opptBidJobItem->getPMComment());
            $bidJobItem->setDiscountComment($opptBidJobItem->getDiscountComment());
            $bidJobItem->setDiscountPercent($opptBidJobItem->getDiscountPercent());
            $bidJobItem->setDiscountExclude($opptBidJobItem->getDiscountExclude());
            $bidJobItem->setDiscountAuto($opptBidJobItem->getDiscountAuto());
            $bidJobItem->setOrder($opptBidJobItem->getOrder());
            $bidJobItem->setGroup($opptBidJobItem->getGroup());
            $bidJobItem->setSuperGroup($opptBidJobItem->getSuperGroup());
            $bidJobItem->setSuperGroupTitle($opptBidJobItem->getSuperGroupTitle());
            $bidJobItem->setGroupTitle($opptBidJobItem->getGroupTitle());
            $bidJobItem->setPrixVenteUnitaireLocation($opptBidJobItem->getCostUnitPrice());
            $bidJobItem->setJobId($jobId);
            $bidJobItem->save();
        }

        return true;
    }

    /**
     * @Route(name="validate_time", path="/project/{id}/validate-time/")
     */
    public function validateTime(Request $request, Etude $etude): Response
    {
        $last_updated = $etude->getUpdatedAt('U');
        $pageload_timestamp = $request->get('pageload_timestamp');

        return $this->json([
            'valid' => $pageload_timestamp < $last_updated ? 'false' : 'true',
            'db_timestamp' => $last_updated,
            'pageload_timestamp' => $pageload_timestamp,
        ]);
    }

    /**
     * @Route(name="etude_update", path="/project/update/{id}/{copyJobId}/{noOfCopy}", defaults={"id": "", "copyJobId": "", "noOfCopy": ""})
     */
    public function editAction(Request $request, MailManager $mailManager, SalesforceManager $sfManager, string $uploadDir): Response
    {
        // As per project loading issue on server
        ini_set('memory_limit', '2G');
        ini_set('max_execution_time', '120');

        $etude = Etude::getById($request->get('id'));
        $copyJobId = $request->get('copyJobId');
        $noOfCopy = $request->get('noOfCopy');
        $currenciesGQS = $request->get('currencieGQS');
        $respLocationCurrency = Location::RES_LOCATION_CURRENCY;
        $uploadedFile = $request->files->get('file');
        $isDeletedFile = $request->get('isDeleted');
        $oldAccountId = $etude->getAccountId();
        if (!$etude) {
            $this->addFlash('warning', 'This Master Project not exist.');

            return $this->redirectToRoute('etude_recherche_index');
        }

        $this->memoriserEtude($etude);
        $accountId = $etude->getAccountId();
        $user = $this->getUser();
        $form = $this->createForm(EtudeType::class, $etude, ['user' => $this->getUser()]);
        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $checkPriceValue = $etude->checkPriceValue();
                if ($checkPriceValue) {
                    $this->addFlash('danger', 'You have budget lines with 0 revenue - please check and in case it is ok validate them by proving those lines over the comment box.');
                } else {
                    $etude->setUpdatedBy($user);
                    if ($copyJobId = $request->get('copy_job_id')) {
                        $copyJobIndex = $request->get('copy_job_index');
                        $_i = 0;
                        foreach ($etude->getJobEtudes() as $job) {
                            if ($copyJobId && is_array($copyJobIndex)) {
                                if (in_array($_i, $copyJobIndex)) {
                                    $this->copyJobItems($copyJobId, $job, $etude);
                                }
                            } elseif ($copyJobId && !$job->getId()) {
                                $this->copyJobItems($copyJobId, $job, $etude);
                            }
                            ++$_i;
                        }
                    }

                    $consolidatedInvoiceLogValue = '';
                    $pmLogValue = '';
                    foreach ($etude->getModifiedColumns() as $modifiedColumn) {
                        if ('etude.consolidated_invoice' == $modifiedColumn) {
                            $consolidatedInvoiceLogValue .= 'Consolidated Invoice '.($etude->getConsolidatedInvoice() ? 'Checked ' : 'Unchecked ');
                            $etude->addConsolidatedInvoiceLogHistory($user, $consolidatedInvoiceLogValue);
                        }
                        if ('etude.id_pm' == $modifiedColumn) {
                            $masterPm = $etude->getEtudeProjectManager();
                            $changedPmName = $masterPm->getPrenom().' '.$masterPm->getNom();
                            $pmLogValue .= 'Master Pm changed to - '.$changedPmName;
                            $etude->addConsolidatedInvoiceLogHistory($user, $pmLogValue);
                        }
                    }

                    $amAutoLogValue = '';
                    $checkSendCsatQuest = null;
                    foreach ($etude->getModifiedColumns() as $modifiedColumn) {
                        if ('etude.dont_set_am_auto' == $modifiedColumn) {
                            $amAutoLogValue .= 'AM Auto '.($etude->getDontSetAmAuto() ? 'Checked' : 'Unchecked');
                            $etude->addStopAMCheckedAutomaticallyHistory($user, $amAutoLogValue);
                        }
                        if ('etude.am_reason_type_id' == $modifiedColumn && $etude->getDontSetAmAuto()) {
                            $amOtherReasonType = AmReasonTypeQuery::create()->filterByLabel('Others')->findOne();
                            $logValue = null !== $etude->getAmReasonType() && $etude->getAmReasonType() === $amOtherReasonType
                                ? 'AM Stop Reason: '.$etude->getSetAmReason()
                                : 'AM Stop Reason: '.$etude->getAmReasonType()->getLabel();
                            $etude->addStopAMCheckedAutomaticallyHistory($user, $logValue);
                        }
                        if ('etude.send_csat_quest' == $modifiedColumn && $etude->getSendCsatQuest() && Etape::TO_INVOICE == $etude->getIdEtape()) {
                            $checkSendCsatQuest = true;
                        }
                    }
                    $notModifiedArray = [];
                    foreach ($etude->getJobEtudes() as $job) {
                        $logValues = null;
                        $rejecedLogValues = null;
                        $unlockLogValues = null;
                        $rushLogValues = null;
                        $notModifiedColumn = true;
                        $initValue = $job->getIdSamsJob() ?: $job->getJobLocation().'  '.$job->getName();
                        $checkedBySystem = false;
                        $logFdAmPmAcct = null;

                        foreach ($job->getModifiedColumns() as $p) {
                            switch ($p) {
                                case 'job.pm_checked':
                                    $logFdAmPmAcct = ' - PM '.($job->getPmChecked() ? 'Checked ' : 'Unchecked ');
                                    $checkedBySystem = in_array($job->getId(), explode(',', $form->get('jobs_pm_checked_by_system')->getData()));
                                    $job->addCheckBoxHistory($user, $initValue.$logFdAmPmAcct, $checkedBySystem);

                                    break;
                                case 'job.am_checked':
                                    $logFdAmPmAcct = ' - AM '.($job->getAmChecked() ? 'Checked ' : 'Unchecked ');
                                    $checkedBySystem = in_array($job->getId(), explode(',', $form->get('jobs_am_checked_by_system')->getData()));
                                    $job->addCheckBoxHistory($user, $initValue.$logFdAmPmAcct, $checkedBySystem);
                                    break;
                                case 'job.acct_invoiced':
                                    $logValues .= ' - Acct Invoiced '.($job->getAcctInvoiced() ? 'Checked ' : 'Unchecked ');
                                    break;
                                case 'job.acct_checked':
                                    $logFdAmPmAcct = ' - Acct '.($job->getAcctChecked() ? 'Checked ' : 'Unchecked ');
                                    $checkedBySystem = in_array($job->getId(), explode(',', $form->get('jobs_acct_checked_by_system')->getData()));
                                    $job->addCheckBoxHistory($user, $initValue.$logFdAmPmAcct, $checkedBySystem);
                                    break;
                                case 'job.fd_checked':
                                    $logFdAmPmAcct = ' - FD '.($job->getFdChecked() ? 'Checked ' : 'Unchecked ');
                                    $checkedBySystem = in_array($job->getId(), explode(',', $form->get('jobs_fd_checked_by_system')->getData()));
                                    $job->addCheckBoxHistory($user, $initValue.$logFdAmPmAcct, $checkedBySystem);
                                    break;
                                case 'job.start_date':
                                    $logValues .= ' - Job start date: '.($job->getStartDate('d/m/Y'));
                                    break;
                                case 'job.end_date':
                                    $logValues .= ' - Job end date: '.($job->getEndDate('d/m/Y'));
                                    break;
                                case 'job.pm_id':
                                    $logValues .= ' - Job Project Manager: '.($job->getJobProjectManager());
                                    break;
                                case 'job.end_date_reason_id':
                                    $logValues .= ' - Reason: '.($job->getEndDateReason() ? $job->getEndDateReason() : '');
                                    break;
                                case 'job.status_id':
                                    $value = ($job->getIdSamsJob() ?: $job->getJobLocation().'  '.$job->getName()).' - '.$job->getStatus()->getValue();
                                    $job->addCheckBoxHistory($user, $value);
                                    break;
                                 case 'job.rejected_checked':
                                    (!$job->getAmChecked()) ? $mailManager->sendRejectedMail($etude, $job) : '';
                                    $rejecedLogValues .= ' - Rejected: '.($job->getRejectedChecked() ? 'Checked ' : 'Unchecked ');
                                    break;
                                 case 'job.rejected_reason':
                                    $rejecedLogValues .= ' - Rejected Reason: '.($job->getRejectedReason() ? $job->getRejectedReason() : '');
                                    break;
                                case 'job.unlock_request_checked':
                                    ($job->getAmChecked()) ? $mailManager->sendUnlockMail($etude, $job) : '';
                                    $unlockLogValues .= ' - Unlock: '.($job->getUnlockRequestChecked() ? 'Checked ' : 'Unchecked ');
                                    break;
                                case 'job.unlock_reason':
                                    $unlockLogValues .= ' - Unlock Reason: '.($job->getUnlockReason() ? $job->getUnlockReason() : '');
                                    break;
                                case 'job.rush_request_checked':
                                     ($job->getAmChecked()) ? $mailManager->sendRushMail($etude, $job) : '';
                                    $rushLogValues = ' - Rush Request: '.($job->getRushRequestChecked() ? 'Checked ' : 'Unchecked ');
                                    break;
                                case 'job.call_center_id':
                                    $value = ($job->getIdSamsJob() ?: $job->getJobLocation().'  '.$job->getName()).' - call center changed';
                                    $job->addCheckBoxHistory($user, $value);
                                    break;
                                case 'job.audit_complete':
                                    $jobNoOrLocation = $job->getIdSamsJob() ?: $job->getJobLocation();
                                    $value = $job->getAuditComplete() ? $jobNoOrLocation.' - Audit Complete Checked' : $jobNoOrLocation.' - Audit Complete Unchecked';
                                    $job->addCheckBoxHistory($user, $value);
                                    break;
                                default:
                                    break;
                            }
                            if (in_array($p, ['job.status_id', 'job.platform_id'])) {
                                $notModifiedColumn = null;
                            }
                        }
                        if ($notModifiedColumn) {
                            $notModifiedArray[] = $job->getId();
                        }
                        if (false !== strpos($logValues, 'FD Checked')) {
                            $url = $this->generateUrl('etude_show', ['id' => $etude->getId()], UrlGeneratorInterface::ABSOLUTE_URL);
                            $mailManager->sendFdMail($job, $url, $user);
                        }
                        if ($logValues) {
                            $job->addCheckBoxHistory($user, $initValue.$logValues);
                        }
                        if ($rejecedLogValues) {
                            $job->addCheckBoxHistory($user, $initValue.$rejecedLogValues);
                        }
                        if ($unlockLogValues) {
                            $job->addCheckBoxHistory($user, $initValue.$unlockLogValues);
                        }
                        if ($rushLogValues) {
                            $job->addCheckBoxHistory($user, $initValue.$rushLogValues);
                        }
                    }

                    if ($currenciesGQS) {
                        $etude->setCurrencies($currenciesGQS);
                    }

                    if ($etude->getAccountId() != $accountId) {
                        $sfManager->updateProjectAccount($etude);
                    }
                    if ($checkSendCsatQuest && $etude->getIsSendCsatQuestMail() && !$etude->getIns()) {
                        $mailManager->sendCsatQuestMail($etude, $this->instance);
                        $etude->setIsSendCsatQuestMail(false)->save();
                    }
                    $this->addFlash('success', 'Master Project updated.');

                    if ($uploadedFile) {
                        $fileName = 'study_specification_'.date('y_m_dh_i_s').'.'.(new \SplFileInfo($uploadedFile->getClientOriginalName()))->getExtension();
                        $uploadedFile->move($uploadDir, $fileName);
                        $etude->setFilePath($fileName);
                    }
                    if (!$uploadedFile && '1' == $isDeletedFile) {
                        $etude->setFilePath(null);
                    }

                    //delete unused images
                    $study_spec_images = HtmlPurifier::getContents($etude->getStudySpecification(), 'file-name=', '"');
                    $additional_notes_images = HtmlPurifier::getContents($etude->getAdditionalNotes(), 'file-name=', '"');
                    $sample_plan_images = HtmlPurifier::getContents($etude->getSamplePlan(), 'file-name=', '"');
                    $project_comment_images = HtmlPurifier::getContents($etude->getProjectComment(), 'file-name=', '"');

                    $this->deleteUnusedImages($etude->getId(), array_merge($study_spec_images, $additional_notes_images, $sample_plan_images, $project_comment_images), $uploadDir);

                    // FIXME rewrite
                    $curr = [];
                    if ($currenciesGQS) {
                        $curr = explode('|', $currenciesGQS);
                    }
                    array_pop($curr);
                    foreach ($curr as $currency) {
                        $t = explode('=', $currency);
                        $curr[$t[0]] = $t[1];
                    }

                    //update local unit and price
                    $jobs = $etude->getJobEtudes();
                    foreach ($jobs as $job) {
                        if (RefSalesForce::JOB_STATUS_ACTIVE == $job->getStatus() && !$job->getActiveDate()) {
                            $job->setActiveDate(new DateTime());
                        }

                        if (!$job->getAmChecked() && $job->getRejectedChecked()) {
                            $job->setRejectedChecked(true);
                        } else {
                            $job->setRejectedChecked(false);
                        }

                        foreach ($job->getJobItems() as $jobItem) {
                            $default_exchange_rate = 1;
                            if ($jobItem->getRespLocation()) {
                                $location = $jobItem->getRespLocation()->getValue();
                                $selectedCurrency = $respLocationCurrency[$location];

                                if (array_key_exists($selectedCurrency, $curr)) {
                                    $default_exchange_rate = $curr[$selectedCurrency];
                                }
                                $coeff = $jobItem->getCoefficiantPr() ?: 1;

                                $jobItem->setPrixVenteUnitaireLocation($jobItem->getPrixRevientUnitaire() * floatval($default_exchange_rate));
                                $jobItem->setPrixRevient($jobItem->getPrixRevientUnitaire() * floatval($default_exchange_rate) * $jobItem->getQuantitePr() * floatval($coeff));
                                $jobItem->save();
                            }
                        }

                        foreach ($job->getJobCosts() as $jobCost) {
                            $default_exchange_rate = 1;
                            if ($jobCost->getRespLocation()) {
                                $location = $jobCost->getRespLocation()->getValue();
                                $selectedCurr = $respLocationCurrency[$location];

                                if (array_key_exists($selectedCurr, $curr)) {
                                    $default_exchange_rate = $curr[$selectedCurr];
                                }
                                $coeff = $jobCost->getCoefficiant() ?: 1;

                                $jobCost->setPrixVenteUnitaireLocation($jobCost->getUnitPrice() * floatval($default_exchange_rate));
                                $jobCost->setPrixRevient($jobCost->getUnitPrice() * floatval($default_exchange_rate) * $jobCost->getQuantitePr() * floatval($coeff));
                                $jobCost->save();
                            }
                        }
                    }

                    if (count($jobs)) {
                        $isAllJobCancellNonBilled = true;
                        foreach ($jobs as $job) {
                            if (null !== $job->getStatus() && RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED !== $job->getStatus()->getValue()) {
                                $isAllJobCancellNonBilled = false;
                            }
                        }
                        if ($isAllJobCancellNonBilled) {
                            $etude->setIdEtape(Etape::CANCELLED);
                        }

                        $amChecked = $pmCheked = true;
                        $isAtleastOneJobCancellNonBilled = false;
                        $jobsNotCancelledNonBilledData = [];
                        $job_datas_toDetermine_project_status = [];
                        foreach ($jobs as $job) {
                            $job_datas_toDetermine_project_status[] = [ // FIXME don't do that, use $job directly!
                                'am_checked' => $job->getAmChecked(),
                                'pm_checked' => $job->getPmChecked(),
                                'status' => $job->getStatus() ? $job->getStatus()->getValue() : '',
                                'acctChecked' => $job->getAcctChecked(),
                            ];
                            if ($job->getAmChecked()) {
                                $job->setAmWasChecked(true);
                            } else {
                                $amChecked = false;
                                if (true === $job->getAmWasChecked()) {
                                    $job->setAmWasChecked(false);
                                }
                            }
                            if (!$job->getPmChecked()) {
                                $pmCheked = false;
                            }

                            if (in_array($job->getStatus() ? $job->getStatus()->getValue() : '', [RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED])) {
                                $isAtleastOneJobCancellNonBilled = true;
                            } else {
                                $jobsNotCancelledNonBilledData[] = [
                                    'status' => $job->getStatus() ? $job->getStatus()->getValue() : '',
                                    'acctChecked' => $job->getAcctChecked(),
                                ];
                            }
                            $jobItems = $job->getJobItems();
                            if (count($jobItems)) {
                                foreach ($jobItems as $jobItem) {
                                    if (RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED == $job->getStatus()) {
                                        $jobItem->setQuantitePv(0);
                                        $jobItem->setPrixVente(0);
                                    }
                                }
                                $job->jobDiscount(); // don't save, it will be saved on $etude->save()
                            }
                        }
                        $etude->save();

                        $isAllOtherJobClosedOrCancelledNonBilled = true;
                        $allOtherJobData = [];
                        foreach ($jobsNotCancelledNonBilledData as $data) {
                            if ((RefSalesForce::JOB_STATUS_CANCELLED_BILLED == $data['status'] && $data['acctChecked']) || ('Closed' == $data['status'] && $data['acctChecked'])) {
                                // nothing
                            } else {
                                $allOtherJobData[] = $data;
                            }
                        }
                        if (count($allOtherJobData) > 0) {
                            $isAllOtherJobClosedOrCancelledNonBilled = false;
                        }

                        // FIXME rewrite this entirely
                        $allJobStatusCancelled_non_billed_for_amCheked = $allJobStatusCancelled_non_billed_for_pmCheked = [];
                        foreach ($job_datas_toDetermine_project_status as $job_amCheck_pmChecked_and_status) {
                            if (!$job_amCheck_pmChecked_and_status['am_checked']) {
                                $allJobStatusCancelled_non_billed_for_amCheked[] = $job_amCheck_pmChecked_and_status['status'];
                            }
                            if (!$job_amCheck_pmChecked_and_status['pm_checked']) {
                                $allJobStatusCancelled_non_billed_for_pmCheked[] = $job_amCheck_pmChecked_and_status['status'];
                            }
                        }
                        $isJobStatusCancelled_non_billed_for_amCheked = count(array_unique($allJobStatusCancelled_non_billed_for_amCheked));
                        $isJobStatusCancelled_non_billed_for_pmCheked = count(array_unique($allJobStatusCancelled_non_billed_for_pmCheked));
                        $user = $this->getUser();
                        $currentEtudeIdEtape = $etude->getIdEtape();
                        if (!$etude->getMultiPhase()) {
                            if ($amChecked && !in_array($currentEtudeIdEtape, [Etape::INVOICED, Etape::CANCELLED, Etape::PAID]) && $etude->canChangeEtape(Etape::TO_INVOICE)) {
                                $etude->setIdEtape(Etape::TO_INVOICE);
                                $etude->setIsToInvoice(true);
                                $etude->majNotation();
                                //$mailManager->sendToInvoiceMail($etude);
                                if ($etude->getSendCsatQuest() && $etude->getIsSendCsatQuestMail() && !$etude->getIns()) {
                                    $mailManager->sendCsatQuestMail($etude, $this->instance);
                                    $etude->setIsSendCsatQuestMail(false)->save();
                                }
                                //$this->addFlash('success', 'The survey email was sent to '.$etude->getLinkedUsersAsString());
                                if (Etape::TO_INVOICE != $currentEtudeIdEtape) {
                                    $etude->addProjectStatusLog(null);
                                }
                            } elseif (($amChecked && $etude->canChangeEtape(Etape::TO_INVOICE)) ||
                                ((!$amChecked && (1 === $isJobStatusCancelled_non_billed_for_amCheked && RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED == end($allJobStatusCancelled_non_billed_for_amCheked))) && ($etude->canChangeEtape(Etape::TO_INVOICE)))) {
                                $etude->setIdEtape(Etape::TO_INVOICE);
                                //$mailManager->sendToInvoiceMail($etude);
                                $etude->majNotation();
                                if ($etude->getSendCsatQuest() && $etude->getIsSendCsatQuestMail() && !$etude->getIns()) {
                                    $mailManager->sendCsatQuestMail($etude, $this->instance);
                                    $etude->setIsSendCsatQuestMail(false)->save();
                                }
                                //$this->addFlash('success', 'The survey email was sent to '.$etude->getLinkedUsersAsString());
                                if (Etape::TO_INVOICE != $currentEtudeIdEtape) {
                                    $etude->addProjectStatusLog(null);
                                }
                            } elseif (($pmCheked && $etude->canChangeEtape(Etape::STUDY_FINISHED)) ||
                                ((!$pmCheked && (1 === $isJobStatusCancelled_non_billed_for_pmCheked && RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED == end($allJobStatusCancelled_non_billed_for_pmCheked))) && ($etude->canChangeEtape(Etape::STUDY_FINISHED)))) {
                                $etude->setIdEtape(Etape::STUDY_FINISHED);
                                if (Etape::STUDY_FINISHED != $currentEtudeIdEtape) {
                                    $etude->addProjectStatusLog($user);
                                }
                            } elseif (($isAtleastOneJobCancellNonBilled && $isAllOtherJobClosedOrCancelledNonBilled && $etude->canChangeEtape(Etape::INVOICED)) ||
                                ($isAllOtherJobClosedOrCancelledNonBilled && $etude->canChangeEtape(Etape::INVOICED))) {
                                $etude->setIdEtape(Etape::INVOICED);
                                $etude->majNotation();
                                if (Etape::INVOICED != $currentEtudeIdEtape) {
                                    $etude->addProjectStatusLog($user);
                                }
                            }
                        }

                        $clientDiscountPercentageFormValue = $form->get('client_discount_percentage')->getData();
                        $endClientDiscountPercentageFormValue = $form->get('end_client_discount_percentage')->getData();
                        if ($etude->getAccount() && $client = $etude->getAccount()) {
                            $etude->setClientDiscountPercentage(null === $clientDiscountPercentageFormValue ? $client->getClientDiscountPercentageByInstance($this->instance) : $clientDiscountPercentageFormValue);
                        }
                        if ($etude->getEndClient() && $endClient = $etude->getEndClient()) {
                            $etude->setEndClientDiscountPercentage(null === $endClientDiscountPercentageFormValue ? $endClient->getClientDiscountPercentageByInstance($this->instance) : $endClientDiscountPercentageFormValue);
                        }

                        $etude->save();

                        // This method is used to fix Master location prefix
                        $this->updateMasterLocationPrefix($etude);

                        // update fields into salesforce via API call
                        if ($response = $sfManager->updateMasterProjectFields($etude)) {
                            $this->addFlash('warning', 'Salesforce answered for project fields: '.$response);
                        } elseif ($etude->getMasterProjectSfId()) {
                            $this->addFlash('success', 'Project fields successfully updated in Salesforce.');
                        }
                    }

                    if ($oldAccountId !== $form->getData()->getAccountId()) {
                        $mailManager->sendAccountChangeMail($etude);
                    }

                    foreach ($sfManager->pushJobs($etude) as $error) {
                        $error ? $this->addFlash('warning', $error) : null;
                    }

                    $this->updateIdSamsJobForNonActiveJob($etude);
                    $etude->setEventsClosedForFdOrPmCheckedJob();
                    foreach ($etude->getJobEtudes() as $job) {
                        if (!in_array($job->getId(), $notModifiedArray) && in_array($job->getStatus(), ['Active', 'Confirmed']) && in_array($job->getPlatform()->getName(), ['Moderate Anywhere', 'QualBoard Rental Only'])) {
                            $mailManager->sendToJobSectionMail($job);
                        }
                        $events = $job->getEvents();
                        if ($events) {
                            $statusEventCancelledNonBilled = RefEventStatusQuery::create()->select('id')->filterByName(RefEventStatus::CANCELLED_NON_BILLED)->findOne();

                            $statusEventOnHold = RefEventStatusQuery::create()->select('id')->filterByName(RefEventStatus::ON_HOLD)->findOne();
                            foreach ($events as $event) {
                                if (null !== $job->getStatus() && RefSalesForce::JOB_STATUS_POSTPONED == $job->getStatus()->getValue()) {
                                    $event->setEventStatusId($statusEventOnHold);
                                }
                                if (null !== $job->getStatus() && RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED == $job->getStatus()->getValue()) {
                                    $event->setEventStatusId($statusEventCancelledNonBilled);
                                }
                                $event->save();
                            }
                        }
                    }

                    return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
                }
            } else {
                $this->addFlash('danger', 'Master Project validation errors.');
            }
        }

        return $this->render('pmtool/project/edit.html.twig', [
            'form' => $form->createView(),
            'opportunity' => $etude->getOpportunity(),
            'etude' => $etude,
            'choiceAreas' => Area::getForJson(),
            'choiceMethodologies' => Methodology::getForJson(),
            'quantOnlineId' => Etude::getQualificationQuantOnLineType(),
            'qualificationQuantType' => array_values(Etude::getQualificationQuantType()),
            'currencies' => Location::getCurrencies($this->instance),
            'defaultAcctMngrId' => User::getDefaultAccountManagerId($etude, $this->instance) ?: 0,
            'isNewProject' => false,
            'isAdmin' => in_array($user->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'isAdminOrDirector' => in_array($user->getIdGroupe(), [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'toInvoice' => Etape::TO_INVOICE,
            'copyJobId' => $copyJobId,
            'noOfCopy' => $noOfCopy,
            'can_update_ins_gqs_rst_cli_checkboxes' => in_array($user->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
        ]);
    }

    private function updateMasterLocationPrefix($etude)
    {
        $sfJobStatus = ['Active', 'Confirmed'];
        if (null === $etude->getIdMasterProjectLocationPnl() && $etude->getMasterProjectSfId()) {
            foreach ($etude->getJobEtudes() as $job) {
                if (in_array($job->getStatus()->getValue(), $sfJobStatus) && $job->getIdSamsJob()) {
                    $etude->setIdMasterProjectLocationPnl($job->getJobLocation()->getProjectLocationPrefixId());
                    $etude->save();
                    break;
                }
            }
        }

        return true;
    }

    private function updateIdSamsJobForNonActiveJob($etude)
    {
        foreach ($etude->getJobEtudes() as $job) {
            if (!in_array($job->getStatus()->getValue(), ['Active', 'Confirmed']) && !$job->getJobSlug()) {
                $newIdSamsJob = $job->getEtude()->getNumeroEtude().'-'.$this->createSlug($job->getJobLocation()).'-'.$job->getId();
                $job->setJobSlug($newIdSamsJob)->save();

                return true;
            }
        }

        return false;
    }

    private function createSlug($str, $delimiter = '-')
    {
        return strtolower(trim(preg_replace('/[\s-]+/', $delimiter, preg_replace('/[^A-Za-z0-9-]+/', $delimiter, preg_replace('/[&]/', 'and', preg_replace('/[\']/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $str))))), $delimiter));
    }

    /**
     * @Route(name="etude_show", path="/project/show/{id}", defaults={"id": ""})
     */
    public function showAction(Request $request, Etude $etude, string $uploadDir, string $spApiUrl): Response
    {
        ini_set('memory_limit', '3G');

        CategoriePrestation::getAll(); // prefetch to avoid N queries

        $width = $height = 0;
        if ($etude->getFilePath()) {
            [$width, $height] = @getimagesize($uploadDir.$etude->getFilePath());
        }
        $user = $this->getUser();
        $groupId = $user->getIdGroupe();

        $groupJobCostsPrice = $groupJobItemsPrice = [];
        foreach ($etude->getJobEtudes() as $job) {
            $groupJobCostsPrice[$job->getId()] = $job->groupJobCostsPrice($this->currency);
            $groupJobItemsPrice[$job->getId()] = $job->groupJobItemsPrice($this->currency);
        }
        $discountProgramsAr = [];
        $discountProgramsAr['qualDiscountProgram'] = $etude->getAccount() ? CategoriePrestation::getDiscountFilter($etude->getAccount()->getDiscountProgram() ? $etude->getAccount()->getDiscountProgram()->getValue() : '') : '';
        $discountProgramsAr['quantDiscountProgram'] = $etude->getAccount() ? CategoriePrestation::getDiscountFilter($etude->getAccount()->getQuantDiscountProgram() ? $etude->getAccount()->getQuantDiscountProgram()->getValue() : '') : '';
        $discountProgramsAr['intermediateClientDiscountProgram'] = $etude->getIntermediateClient() ? CategoriePrestation::getDiscountFilter($etude->getIntermediateClient()->getDiscountProgram() ? $etude->getIntermediateClient()->getDiscountProgram()->getValue() : '') : '';
        $discountProgramsAr['intermediateClientQuantDiscountProgram'] = $etude->getIntermediateClient() ? CategoriePrestation::getDiscountFilter($etude->getIntermediateClient()->getQuantDiscountProgram() ? $etude->getIntermediateClient()->getQuantDiscountProgram()->getValue() : '') : '';
        $discountProgramsAr['endClientDiscountProgram'] = $etude->getEndClient() ? CategoriePrestation::getDiscountFilter($etude->getEndClient()->getDiscountProgram() ? $etude->getEndClient()->getDiscountProgram()->getValue() : '') : '';
        $discountProgramsAr['endClientQuantDiscountProgram'] = $etude->getEndClient() ? CategoriePrestation::getDiscountFilter($etude->getEndClient()->getQuantDiscountProgram() ? $etude->getEndClient()->getQuantDiscountProgram()->getValue() : '') : '';

        $users = UserQuery::create()
            ->filterById(null, Criteria::ISNOTNULL)
            ->find();
        $serverTimeZone = date_default_timezone_get();

        return $this->render('pmtool/project/show.html.twig', [
            'user' => $this->getUser(),
            'opportunity' => $etude->getOpportunity(),
            'etude' => $etude,
            'timezone' => $serverTimeZone,
            'projectStatusLogs' => LogProjectStatusQuery::create()->filterByEtude($etude)->orderByDate(Criteria::ASC)->find(),
            'discountProgramsAr' => $discountProgramsAr,
            'width' => $width.'px',
            'height' => $height.'px',
            'isAdvancedInvoice' => $request->get('isAdvancedInvoice'),
            'boutonActif' => Groupe::boutonActif($groupId, $etude->getIdEtape()),
            'displayLockedJob' => in_array($groupId, [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'displayPayment' => in_array($groupId, [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING, Groupe::MANAGEMENT, Groupe::FINANCE]),
            'displayInvoicing' => in_array($groupId, [
                Groupe::PROJECT_MANAGER,
                GROUPE::PROJECT_DIRECTOR,
                Groupe::MANAGING_DIRECTOR,
                Groupe::ACCOUNTING,
                Groupe::SYSTEM_ADMINISTRATOR,
                Groupe::MANAGEMENT,
                Groupe::SALES_MANAGER,
                Groupe::PHONE_ROOM_SUPERVISOR,
                Groupe::FACILITY_DIRECTOR,
                Groupe::KNOWLEDGE_TEAM,
                Groupe::OPERATION_MANAGER,
                Groupe::PROJECT_CORDINATOR,
                Groupe::BUSINESS_DEVELOPER,
                Groupe::FACILITY_MANAGER,
                Groupe::FINANCE,
            ]),
            'steps' => Etape::STEPS,
            'allowedSteps' => Etape::ALLOWED_STEPS,
            'ongoingOrdre' => Etude::ONGOING_ORDRE,
            'sharepointApiUrl' => $spApiUrl,
            'currencies' => Location::getCurrencies($this->instance),
            'groupJobCostsPrice' => $groupJobCostsPrice,
            'groupJobItemsPrice' => $groupJobItemsPrice,
            'invoiceTabColor' => $etude->getInvoiceTabColor(),
            'users' => $users,
        ]);
    }

    /**
     * @Route(name="image_study_spec", path="/project/{id}/study-spec")
     */
    public function showImageStudySpecAction(Request $request, string $uploadDir): Response
    {
        ini_set('memory_limit', '512M');
        $etude = Etude::getById($request->get('id'));
        $file = $uploadDir.$etude->getFilePath();
        if (!$file) {
            throw $this->createNotFoundException();
        }

        $response = new Response();
        $response->headers->set('Cache-Control', 'private');
        $response->headers->set('Content-type', mime_content_type($file));
        $response->sendHeaders();
        $response->setContent(readfile($file));

        return $response;
    }

    /**
     * @Route(name="etude_gdpr_export", path="/project/gdpr/{id}/export")
     */
    public function exportGDPRAction(Request $request, Etude $etude, FileManager $fileManager, SpreadsheetManager $spreadsheetManager): Response
    {
        $dataFile = FichierQuery::create()
            ->filterByEtude($etude)
            ->filterByExtension(Fichier::DATA_FILE_TYPES)
            ->filterById($request->query->get('data_file_id'))
            ->findOne()
        ;
        $xlsmFile = $dataFile ? $fileManager->getFullPath($dataFile) : null;

        if (!$xlsmFile || !file_exists($xlsmFile)) {
            $this->addFlash('warning', 'This XLSM file does not exist.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        $templateFile = FichierQuery::create()
            ->filterById($request->query->get('template_file_id'))
            ->filterByExtension(Fichier::TEMPLATE_FILE_TYPES)
            ->findOne()
        ;
        $docxFile = $templateFile ? $fileManager->getFullPath($templateFile) : null;

        if (!$docxFile || !file_exists($docxFile)) {
            $this->addFlash('warning', 'This DOCX file does not exist.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        try {
            $spreadsheet = $spreadsheetManager->importSingleSheet($xlsmFile, 'import');
        } catch (Exception $e) {
            $this->addFlash('warning', 'This file cannot be imported. Check that its formulas do not refer to other files.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        } catch (\InvalidArgumentException $e) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        $sheet = $spreadsheet->getActiveSheet();
        $continueReading = true;
        $row = 2;
        $maxRow = 1000;
        $values = [];
        $max = 0;
        while ($continueReading && $max < 10000) {
            ++$max;
            $XA = $sheet->getCellByColumnAndRow(1, $row)->getValue();
            if ($XA) {
                $value = null;
                $type = $sheet->getCellByColumnAndRow(3, $row)->getValue();
                $value = $sheet->getCellByColumnAndRow(2, $row)->getCalculatedValue();
                if ('single select' === $type) {
                    $ind = (int) $value;
                    if ((($row >= 32 && $row <= 127) || ($row >= 144 && $row <= 171)) && $value) {
                        $index = $row >= 32 && $row <= 127 ? 'categories_of_transferred_data' : $XA;
                        $value = isset($values[$index]) ? $values[$index]."\n".$XA : $XA;
                        $XA = $index;
                    } elseif ($value) {
                        $value = $sheet->getCellByColumnAndRow(3 + $ind, $row)->getCalculatedValue();
                    }
                }
                $values[$XA] = $value ?: '';
            } else {
                $continueReading = false;
            }
            ++$row;
            if ($row >= $maxRow) {
                break;
            }
        }

        $values['etude_numero_etude'] = $etude->getNumeroEtude();
        $values['etude_theme'] = $etude->getTheme();
        $values['etude_date_fin'] = $etude->getDateFin('Y-m-d');
        $values['etude_address'] = 'unknown';
        $account = $etude->getAccount();
        if ($account) {
            $address = '';
            foreach ([
                    $account->getName(),
                    $account->getBillingStreet(),
                    $account->getBillingZip(),
                    $account->getBillingCity(),
                    $account->getBillingCountry(),
                ] as $value) {
                if ($value) {
                    $address .= ' '.$value;
                }
            }
            $values['client_address'] = trim($address);
        }

        $template = new PhpWord\TemplateProcessor($docxFile);
        foreach ($template->getVariables() as $variable) {
            if (!isset($values[$variable])) {
                $variables = explode('.', $variable);
                $object = $etude;
                foreach ($variables as $var) {
                    if (!is_null($object)) {
                        $methodName = 'get'.str_replace('_', '', ucwords($var));
                        $object = method_exists($object, $methodName) ? $object->{$methodName}() : null;
                    }
                }
                if (!is_null($object)) {
                    if ($object instanceof \DateTime) {
                        $format = 'Y-m-d';
                        $seconds = (int) $object->format('s');
                        $minutes = (int) $object->format('i');
                        $hours = (int) $object->format('G');
                        if ($seconds || $minutes || $hours) {
                            $format .= ' H:i:s';
                        }
                        $object = $object->format($format);
                    }
                    $values[$variable] = $object;
                }
            }
        }
        foreach ($values as $key => $value) {
            $template->setValue($key, str_replace("\n", "<w:br/>\n", htmlspecialchars($value)));
        }
        $docxFileSave = $template->save();

        $filename = substr($templateFile->getFichierOriginal(), 0, strlen($templateFile->getFichierOriginal()) - 5).'_'.$etude->getId().'.docx';
        $response = new Response();
        $response->headers->set('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        $response->headers->set('Content-Disposition', 'attachment;filename="'.$filename.'"');
        $response->setContent(file_get_contents($docxFileSave));

        unlink($docxFileSave);

        return $response;
    }

    /**
     * @Route(name="etude_gdpr_upload", path="/project/gdpr/{id}/upload")
     */
    public function uploadGDPRAction(Request $request, Etude $etude, string $uploadDir): Response
    {
        ini_set('memory_limit', '512M');

        $uploadedFile = $request->files->get('fichier');
        $name = $uploadedFile ? $uploadedFile->getClientOriginalName() : '';

        $fichier = (new Fichier())
            ->setFichier(sha1(uniqid(null, true)))
            ->setExtension((new SplFileInfo($name))->getExtension())
            ->setMimeType($uploadedFile && $uploadedFile->getClientMimeType() ? $uploadedFile->getClientMimeType() : 'application/octet-stream')
            ->setFichierOriginal($name)
            ->setType(FichierTableMap::COL_TYPE_GDPR)
            ->setDateCreation(new \DateTime());

        if (!$fichier->getExtension()) {
            $this->addFlash('warning', 'This file type is not allowed.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }
        $fichier->setFichier($fichier->getFichier().'.'.$fichier->getExtension());

        // check allowed file types
        if (
            !in_array(strtolower($fichier->getExtension()), Fichier::DATA_FILE_TYPES)
            && !in_array(strtolower($fichier->getExtension()), Fichier::OTHER_FILE_TYPES)
        ) {
            $this->addFlash('warning', 'This file cannot be imported.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        try {
            $uploadedFile->move($uploadDir, $fichier->getFichier());
        } catch (PartialFileException $e) {
            $this->addFlash('warning', 'This file was imported incompletely.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        (new EtudeFichier())
            ->setEtude($etude)
            ->setFichier($fichier)
            ->save();

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * @Route(name="etude_gdpr_delete", path="/project/gdpr/{id}/delete/{file_id}")
     */
    public function deleteGDPRAction(Request $request, FileManager $fileManager): Response
    {
        $etude = Etude::getById($request->get('id'));
        if (!$etude) {
            $this->addFlash('warning', 'This Master Project not exist.');

            return $this->redirectToRoute('etude_recherche_index');
        }

        $fichier = FichierQuery::create()
            ->filterByEtude($etude)
            ->filterById($request->get('file_id'))
            ->filterByType(FichierTableMap::COL_TYPE_GDPR)
            ->filterByExtension(Fichier::TEMPLATE_FILE_TYPES)
            ->findOne()
        ;
        if (!$fichier) {
            $this->addFlash('warning', 'This file not exists');
        } else {
            $fileManager->unlink($fichier);
            $fichier->getEtudeFichiers()->delete();
            $fichier->delete();
        }

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * @Route(name="etude_gdpr_list", path="/project/gdpr/{id}")
     */
    public function listGDPRAction(Request $request, Etude $etude): Response
    {
        $types = $etude->getAccount() ? $etude->getAccount()->getAgreementTypes() : [];
        $agreementTypes = [];
        foreach ($types as $agreementType) {
            $agreementTypes[] = $agreementType->getRefSalesForceAccountRefAgreementType()->getValue();
        }

        return $this->render('pmtool/project/_gdpr_list.html.twig', [
            'agreementTypes' => $agreementTypes,
            'etude' => $etude,
            'data_files' => Fichier::getGDPRDataFiles($etude),
            'template_files' => Fichier::getGDPRTemplateFiles(),
            'other_files' => Fichier::getGDPROtherFiles($etude),
        ]);
    }

    /**
     * Toggle via un boolean la vasibilité des fichiers en base de données via ajax depuis le front - end.
     *
     * @Route(name="etude_toggle_gdpr_file_visibility", path="/project/gdpr/toggle_visibility/{id}")
     */
    public function toggleFileVisibilityAction(Request $request, Fichier $fichier): JsonResponse
    {
        $fichier->setIsVisible(!$fichier->getIsVisible())->save();

        return $this->json([
            'ok' => 'true',
            'toggleValue' => (int) $fichier->getIsVisible(),
        ]);
    }

    /**
     * @Route(name="etude_gdpr_read_file", path="/project/gdpr/read_file/{data_file_id}")
     */
    public function readGDPRFileAction(Request $request, FileManager $fileManager, SpreadsheetManager $spreadsheetManager): Response
    {
        $clientRespondent = [
            'client' => [
                'client_mini_obligation' => ['type' => '0', 'files' => []],
                'client_formal_obligation_client_CC' => ['type' => '0', 'files' => []],
                'client_formal_obligation_client_AV' => ['type' => '0', 'files' => []],
                'client_formal_obligation_client_selfrecordingAV' => ['type' => '0', 'files' => []],
                'client_Order Processing Agreement - Client (C) and Schlesinger (P) unbranded' => ['type' => '1', 'files' => []],
                'client_Checklist_RoomRental' => ['type' => '0', 'files' => []],
                'client_ObserverAgreement' => ['type' => '0', 'files' => []],
                'client_ObserverAgreement_unbranded' => ['type' => '1', 'files' => []],
                'client_NDA information and End Client declaration' => ['type' => '0', 'files' => []],
                'client_instruction_for_client list_usage' => ['type' => '0', 'files' => []],
            ],
            'respondent' => [
                'respondent_respondent_consent_only_AV_recording_secure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_HCP_secure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_full_data_secure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_full_data_HCP_secure' => ['type' => '0', 'files' => []],
                'respondent_NDA_respondent' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_unbranded_secure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_HCP_unbranded_secure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_full_data_unbranded_secure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_full_data_HCP_unbranded_secure' => ['type' => '1', 'files' => []],
                'respondent_NDA_respondent_unbranded' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_unsecure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_HCP_unsecure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_full_data_unsecure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_full_data_HCP_unsecure' => ['type' => '0', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_unbranded_unsecure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_only_AV_recording_HCP_unbranded_unsecure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_full_data_unbranded_unsecure' => ['type' => '1', 'files' => []],
                'respondent_respondent_consent_full_data_HCP_unbranded_unsecure' => ['type' => '1', 'files' => []],
            ],
        ];

        $dataFile = FichierQuery::create()->findPk($request->get('data_file_id'));
        if (!$dataFile) {
            throw $this->createNotFoundException('The file does not exist!');
        }

        $xlsmFile = $fileManager->getFullPath($dataFile);

        try {
            $spreadsheet = $spreadsheetManager->importSingleSheet($xlsmFile, 'import');
        } catch (Exception $e) {
            $this->addFlash('warning', 'This file cannot be imported. Check that its formulas do not refer to other files.');

            return $this->redirectToRoute('etude_recherche_index');
        } catch (\InvalidArgumentException $e) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_recherche_index');
        }

        $sheet = $spreadsheet->getActiveSheet();
        $continueReading = true;
        $row = 2;
        $maxRow = 1000;
        $values = [];
        $max = 0;
        while ($continueReading && $max < 10000) {
            ++$max;
            $XA = $sheet->getCellByColumnAndRow(1, $row)->getValue();
            if ($XA && (isset($clientRespondent['client'][$XA]) || isset($clientRespondent['respondent'][$XA]))) {
                $value = null;
                $type = $sheet->getCellByColumnAndRow(3, $row)->getValue();
                $value = $sheet->getCellByColumnAndRow(2, $row)->getCalculatedValue();
                if ('single select' === $type) {
                    $values[$XA] = (bool) $value;
                }
            } elseif (!$XA) {
                $continueReading = false;
            }
            ++$row;
            if ($row >= $maxRow) {
                break;
            }
        }

        $templateFiles = Fichier::getGDPRTemplateFiles();
        foreach ($templateFiles as $templateFile) {
            $name = substr($templateFile->getFichierOriginal(), 0, strlen($templateFile->getFichierOriginal()) - 5);
            foreach (array_keys($clientRespondent) as $key) {
                if (isset($clientRespondent[$key][$name])) {
                    $clientRespondent[$key][$name]['files'][$templateFile->getLang()] = $templateFile->getId();
                }
            }
        }

        return $this->render('pmtool/project/_gdpr_read_file.html.twig', [
            'clientRespondent' => $clientRespondent,
            'values' => $values,
        ]);
    }

    /**
     * @Route(name="etude_download_file", path="/project/{id}/file/{file_id}/download")
     */
    public function downloadEtudeFileAction(Request $request, FileManager $fileManager): Response
    {
        $etude = Etude::getById($request->get('id'));
        if (!$etude) {
            $this->addFlash('warning', 'This Master Project not exist.');

            return $this->redirectToRoute('etude_recherche_index');
        }

        $fichier = FichierQuery::create()
            ->filterByEtude($etude)
            ->filterById($request->get('file_id'))
            ->findOne()
        ;

        if (!$fichier) {
            $this->addFlash('warning', 'This file not exist.');

            return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
        }

        return $fileManager->getDownloadResponse($fichier);
    }

    /**
     * Save new invoice.
     *
     * @Route(name="etude_save_facture", path="/project/save-facture/{id}", defaults={"id": ""})
     */
    public function saveFactureAction(Request $request, Etude $etude, UrlHelper $urlHelper): Response
    {
        $message = [
            'type' => 'success',
            'text' => 'Invoice updated.',
        ];

        $contactQuery = ContactQuery::create()->filterByAccountId($etude->getAccountId());
        if ('us' == $this->instance) {
            $documentQuery = DocumentQuery::create()->filterByDocumentBr(['ADVANCED INVOICE', 'ASPEN FINN'], Criteria::IN);
        } else {
            $documentQuery = DocumentQuery::create()->filterByDocumentBr(['ADVANCED INVOICE', 'ASPEN FINN', 'ADDISON'], Criteria::NOT_IN);
        }

        $symbolesMonnaie = PaysQuery::create()
            ->filterByCodeMonnaie('', Criteria::NOT_EQUAL)->filterByGeneric(true)
            ->orderByCodeMonnaie()->find()
            ->toKeyValue('Id', 'SymboleMonnaie');

        $symboleM = ['$' => 'USD', '€' => 'EUR', '£' => 'GBP', '¥' => 'CNY'];
        $curr = [$this->currency => '1,'.$this->currency];
        if ($currencies = $etude->getCurrencies()) {
            $currenciesArray = explode('|', $currencies);
            foreach ($currenciesArray as $c) {
                $exchangeRate = explode('=', $c);
                if (in_array($exchangeRate[0], $symboleM)) {
                    $key = array_search($exchangeRate[0], $symboleM);
                    $curr[$key] = $exchangeRate[1].','.$key;
                } elseif (isset($exchangeRate[1])) {
                    $curr[$exchangeRate[0]] = $exchangeRate[1].','.$exchangeRate[0];
                }
            }
        }
        $creditCardLogo = $urlHelper->getAbsoluteUrl('/htdocs/images/NewLogo/visa-mastercard-amex.png');
        $form = $this->createForm(EtudeFacturesType::class, $etude, [
            'contact_query' => $contactQuery,
            'document_query' => $documentQuery,
            'choice_monnaie' => $curr,
        ]);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $document = null;
                foreach ($etude->getFactures() as $facture) {
                    if ($facture->isNew()) {
                        $facture->generateNumeroFacture($this->instance);
                        $etude = $facture->getEtude();
                        if ($facture->getDocument()) {
                            $document = $facture->getDocument()->getDocumentBr();
                        }
                        $account = $etude->getAccount();
                        $summary = $etude->getSummary();
                        $specialClienInformation = null;
                        if ($account && $accountDetail = $account->getAccountDetail()) {
                            $specialClienInformation = $accountDetail->getId();
                        }

                        $clientPoNumber = null;
                        if (in_array($document, ['ADVANCED INVOICE', 'ASPEN FINN'])) {
                            $template = 'ASPEN FINN' == $document ? 'pmtool/facture/advanced_inv_aspen_finn.html.twig' : 'pmtool/facture/advanced_inv.html.twig';
                            $logoFile = 'ASPEN FINN' == $document ? '/htdocs/images/NewLogo/Aspen_Finn_Logo.png' : '/htdocs/images/NewLogo/QUAL.png';
                            $logo = $urlHelper->getAbsoluteUrl($logoFile);
                            $isProjectInvoiceType = null === $facture->getJobId();

                            $jobs = [];
                            if ($job = $facture->getJob()) {
                                foreach ($job->getJobItems() as $jobItem) {
                                    if ($jobItem->getDownPayment()) {
                                        $clientPoNumber = $job->getPoJobNumber();
                                        $jobs[] = $job;
                                        break;
                                    }
                                }
                            }
                            $textFacture = $this->renderTemplate($template, [
                                'etude' => $etude,
                                'isProjectInvoiceType' => $isProjectInvoiceType,
                                'projectInvoiceType' => $facture->getProjectInvoiceType(),
                                'factureMontantProject' => $facture->getMontant(),
                                'factureNumero' => $facture->getNumeroFacture(),
                                'tauxChangeNew' => $facture->getTauxChange(),
                                'symboleMonnaieNew' => $facture->getSymboleMonnaie(),
                                'special_client_information' => $specialClienInformation,
                                'externalReference' => $facture->getExternalReference(),
                                'account' => $account,
                                'jobs' => $jobs,
                                'date' => $facture->getDate(),
                                'contact' => $facture->getContact(),
                                'summary' => $summary,
                                'clientPoNumber' => $clientPoNumber,
                                'logo' => $logo,
                                'creditCardLogo' => $creditCardLogo,
                            ]);
                        } else {
                            $textFacture = $this->renderTemplate('pmtool/facture/facture_'.$facture->getLanguage().'.html.twig', [
                                'etude' => $etude,
                                'factureNumero' => $facture->getNumeroFacture(),
                                'tauxChangeNew' => $facture->getTauxChange(),
                                'symboleMonnaieNew' => $facture->getSymboleMonnaie(),
                                'special_client_information' => $specialClienInformation,
                                'externalReference' => $facture->getExternalReference(),
                                'account' => $account,
                                'contact' => $facture->getContact(),
                                'summary' => $summary,
                            ]);
                        }
                        $facture->setTexteFacture($textFacture);
                    }
                }

                $etude->save();
                $etude->reload();
                $message = [
                    'type' => 'success',
                    'text' => 'Invoice saved.',
                ];
            } else {
                $message = [
                    'type' => 'danger',
                    'text' => 'Invoice validation errors.',
                ];
            }
        }

        $user = $this->getUser();
        $etapeId = $etude->getIdEtape();
        $groupId = $user->getIdGroupe();
        $activeBtn = Groupe::boutonActif($groupId, $etapeId);

        $tpl = [
            'form' => $form->createView(),
            'etude' => $etude,
            'job' => $etude->getJobEtudes(),
            'symbolesMonnaie' => $symbolesMonnaie,
            'activeBtn' => $activeBtn,
        ];

        if ($request->isXmlHttpRequest()) {
            return $this->json([
                'html' => $this->renderTemplate('pmtool/project/_invoice.html.twig', $tpl),
                'message' => $message,
                'invoiceTabColor' => $etude->getInvoiceTabColor(),
            ]);
        }

        return $this->render('pmtool/project/_invoice.html.twig', $tpl);
    }

    /**
     * Fetches Project list for imputation.
     *
     * @Route(name="etude_retrieve", path="/project/retrieve/")
     */
    public function retrieveAction(Request $request): JsonResponse
    {
        $term = $request->get('term');
        $response = [];
        $etudes = EtudeQuery::create()
            ->filterByIdEtape([Etape::STUDY_CREATION, Etape::BUDGET_CREATION, Etape::TO_CONFIRM, Etape::ONGOING, Etape::STUDY_FINISHED], Criteria::IN)
            ->filterByNumeroEtude('%'.$term.'%', Criteria::LIKE)
            ->orderByNumeroEtude()
            ->find();

        foreach ($etudes as $etude) {
            $jobsArray = [];
            $locations = [];
            foreach ($etude->getJobEtudes() as $job) {
                $location = $job->getJobLocation();
                $jobsArray[$job->getId()] = $location->getLibelle();
                $locations[$location->getId()] = $location->getLibelle();
            }

            $response[] = [
                'id' => $etude->getId(),
                'idEtape' => $etude->getIdEtape(),
                'label' => $etude->getNumeroEtude().' - '.$etude->getTheme(),
                'jobs' => $jobsArray,
                'locations' => $locations,
            ];
        }

        return $this->json($response);
    }

    /**
     * @Route(name="etude_valider", path="/project/valider/{id}")
     */
    public function validerAction(Request $request, Etude $etude, SalesforceManager $sfManager, MailManager $mailManager): Response
    {
        $user = $this->getUser();
        $etape = $etude->getEtape();

        if (Etape::STUDY_FINISHED == $etape->getId()) {
            $statusClosed = RefSalesForceQuery::create()->filterByLabel('Status')->findOneByValue('Closed');
            foreach ($etude->getJobEtudes() as $job) {
                if (!in_array($job->getStatus()->getValue(), [RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED, RefSalesForce::JOB_STATUS_CANCELLED_BILLED])) {
                    $job->setStatus($statusClosed)->save();
                }
            }
        }

        if (Etape::TO_INVOICE == $etape->getId()) {
            foreach ($etude->getJobEtudes() as $job) {
                if ((!$job->getStatus() || 'Closed' != $job->getStatus()->getValue()) || ('Closed' == $job->getStatus()->getValue() && !$job->getAcctChecked())) {
                    $this->addFlash('warning', 'Some job(s) are not closed and Acct checked yet');

                    return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
                }
            }
        }
        if (Etape::STUDY_FINISHED == $etape->getId()) {
            foreach ($etude->getJobEtudes() as $job) {
                if (!$job->getAmChecked()) {
                    $job->setAmChecked(true);
                    $job->setAmWasChecked(true);
                    $job->addCheckBoxHistory($user, $job->getIdSamsJob().' - AM Checked');
                    $job->save();
                }
            }
        }
        $newStepId = Etape::STANDBY == $etape->getId() ? Etape::ONGOING : $etape->getIdNexEtapeByIdOfCurrentEtape();
        $etude->setIdEtape($newStepId);

        if (Etape::TO_INVOICE == $newStepId) {
            $etude->majNotation();
            //$mailManager->sendToInvoiceMail($etude);
            if ($etude->getSendCsatQuest() && $etude->getIsSendCsatQuestMail() && !$etude->getIns()) {
                $mailManager->sendCsatQuestMail($etude, $this->instance);
                $etude->setIsSendCsatQuestMail(false)->save();
            }
            //$this->addFlash('success', 'The survey email was sent to '.$etude->getLinkedUsersAsString());
        }
        if (Etape::INVOICED == $newStepId) {
            if (!$etude->getDateEnvoiFacture()) {
                $etude->setDateEnvoiFacture(new DateTime());
            }
            $etude->setDateReglement(new DateTime());
        }

        if (Etape::ONGOING == $newStepId) {
            foreach ($etude->getJobEtudes() as $job) {
                $job->copyBudgets();
            }
        }

        foreach ($etude->getJobEtudes() as $job) {
            $job->setPmtoolUpdated(true)->save();
        }

        $etude->save();

        if ($response = $sfManager->updateProjectStatus($etude)) {
            $this->addFlash('warning', 'Salesforce answered for project status: '.$response);
        } elseif ($etude->getMasterProjectSfId()) {
            $this->addFlash('success', 'Project status updated in Salesforce');
        }

        (new LogProjectStatus())
            ->setEtude($etude)
            ->setStatus($etude->getEtape() ? $etude->getEtape()->getEtape() : '-')
            ->setDate(new DateTime())
            ->setUser($this->getUser())
            ->save();

        $this->addFlash('success', 'Master Project saved!');

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * @Route(name="etude_summary", path="/project/summary/{id}", defaults={"id": ""})
     */
    public function summaryAction(Request $request, Etude $etude): Response
    {
        $user = $this->getUser();
        $tpl = [
            'etude' => $etude,
            'show_exports_1_2' => in_array($user->getIdGroupe(), [Groupe::SALES_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::MANAGEMENT, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
            'show_export_sum' => in_array($user->getIdGroupe(), [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING]),
        ];

        if ($request->isXmlHttpRequest()) {
            return $this->json([
                'html' => $this->renderTemplate('pmtool/project/_summary.html.twig', $tpl),
            ]);
        }

        return $this->render('pmtool/project/_summary.html.twig', $tpl);
    }

    private function memoriserEtude(Etude $etude)
    {
        $user = $this->getUser();

        $con = Propel::getConnection();
        $sql = 'INSERT INTO dernier_acces SET id_user=?, id_etude=?, date_heure=? ON DUPLICATE KEY UPDATE date_heure = ?;';

        $stm = $con->prepare($sql);
        $stm->bindValue(1, $user->getId(), PDO::PARAM_INT);
        $stm->bindValue(2, $etude->getId(), PDO::PARAM_INT);
        $stm->bindValue(3, date('Y-m-d H:i:s'), PDO::PARAM_STR);
        $stm->bindValue(4, date('Y-m-d H:i:s'), PDO::PARAM_STR);
        $stm->execute();

        $sql = 'SELECT count(id_etude) nbId FROM dernier_acces WHERE id_user = ?';
        $stm = $con->prepare($sql);
        $stm->bindValue(1, $user->getId(), PDO::PARAM_INT);
        $stm->execute();

        $row = $stm->fetch();

        if ($row && isset($row['nbId']) && ((int) $row['nbId'] > 10)) {
            DernierAccesQuery::create()
                ->filterByUser($user)
                ->orderByDateHeure()
                ->limit(1)
                ->delete();
        }
    }

    /**
     * @Route(name="etude_load_template_cs", path="/project/load-template-cs/{id}/{template}", defaults={"id": "", "template": ""})
     */
    public function loadTemplateCSAction(Request $request, Etude $etude): RedirectResponse
    {
        $numeroEtude = str_replace('_', '/', $etude->getNumeroEtude());
        $template = $request->get('template');

        $con = Propel::getConnection();
        $sql = 'SELECT * FROM dhtmlx_header WHERE sheetid = ? AND columnid = 1';
        $stm = $con->prepare($sql);
        $stm->bindValue(1, $numeroEtude, PDO::PARAM_STR);
        $stm->execute();
        $results = $stm->fetchAll();
        // Si on trouve des données pour l'étude on ne recharge pas le tableaau avec le template
        if (0 == count($results)) {
            //On met à jour la configuration de la coversheet avec celle du template choisi
            $sql = 'SELECT * FROM dhtmlx_sheet WHERE sheetid= ? LIMIT 1';
            $stm = $con->prepare($sql);
            $stm->bindValue(1, $template, PDO::PARAM_STR);
            $stm->execute();
            $sheet = $stm->fetch();

            if ($sheet) {
                $sql = 'UPDATE dhtmlx_sheet SET cfg = ? WHERE sheetid = ?';
                $stm = $con->prepare($sql);
                $stm->bindValue(1, $sheet['cfg'], PDO::PARAM_STR);
                $stm->bindValue(2, $numeroEtude, PDO::PARAM_STR);
                $stm->execute();
            }

            $tables = ['dhtmlx_data', 'dhtmlx_header'];

            // bouclage sur les 2 tables
            foreach ($tables as $table) {
                $sql = "DELETE FROM $table WHERE sheetid = ?";
                $stm = $con->prepare($sql);
                $stm->bindValue(1, $numeroEtude, PDO::PARAM_STR);
                $stm->execute();

                $sql = "SELECT * FROM $table WHERE sheetid = ?";
                $stm = $con->prepare($sql);
                $stm->bindValue(1, $template, PDO::PARAM_STR);
                $stm->execute();
                $results = $stm->fetchAll(PDO::FETCH_ASSOC);
                foreach ($results as $result) {
                    unset($result['sheetid']);
                    $sql_fields = 'sheetid,'.implode(',', array_keys($result));
                    $sql_values = "'$numeroEtude','".implode("','", array_values($result))."'";
                    $sql = "INSERT INTO $table ({$sql_fields}) VALUES ({$sql_values})";
                    $stm = $con->prepare($sql);
                    $stm->execute();
                }
            }
        }

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * To add New Payment.
     *
     * @Route(name="etude_save_payment", path="/project/save-payment/{id}", defaults={"id": ""})
     */
    public function saveReglementAction(Request $request, Etude $etude): Response
    {
        $message = [
            'type' => 'success',
            'text' => 'Payment updated.',
        ];

        // FIXME getListeBanqueFacturationClient for new and getListeBanque In form event
        $bankQuery = BanqueQuery::create()
            ->_if('de' == $this->instance)
                ->filterById([110, 349], Criteria::IN)
            ->_endif();
        $documentQuery = DocumentQuery::create()->filterByType('R');

        $form = $this->createForm(EtudeReglementsType::class, $etude, [
            'bank_query' => $bankQuery,
            'document_query' => $documentQuery,
        ]);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $etude->save();
                $message = [
                    'type' => 'success',
                    'text' => 'Payment saved.',
                ];
            } else {
                $message = [
                    'type' => 'danger',
                    'text' => 'Payment validation errors.',
                ];
            }
        }

        $etapeId = $etude->getIdEtape();
        $groupId = $this->getUser()->getIdGroupe();

        $tpl = [
            'activeButton' => Groupe::boutonActif($groupId, $etapeId),
            'form' => $form->createView(),
            'etude' => $etude,
        ];

        if ($request->isXmlHttpRequest()) {
            return $this->json([
                'html' => $this->renderTemplate('pmtool/project/_payment.html.twig', $tpl),
                'message' => $message,
            ]);
        }

        return $this->render('pmtool/project/_payment.html.twig', $tpl);
    }

    /**
     * @Route(name="etude_checklist", path="/project/checklist/{id}")
     */
    public function checklistAction(Request $request, Etude $etude): Response
    {
        foreach ($etude->getMissingEtudeCheckList() as $etudeCheckList) {
            $etudeChecklistValidation = new EtudeCheckListValidation();
            $etudeChecklistValidation->setEtudeCheckList($etudeCheckList);
            $etude->addEtudeCheckListValidation($etudeChecklistValidation);
        }

        $etudeChecklistValidationQuery = EtudeCheckListValidationQuery::create()
            ->useEtudeCheckListQuery()
                ->useEtudeCheckListTypeQuery()
                    ->orderBySort()
                ->endUse()
                ->orderBySort()
            ->endUse();

        return $this->render('pmtool/project/_checklist.html.twig', [
            'etude' => $etude,
            'etudeChecklistValidations' => $etude->getEtudeCheckListValidations($etudeChecklistValidationQuery),
        ]);
    }

    /**
     * @Route(name="etude_checklist_save", path="/project/checklist-save/{id}", defaults={"id": ""})
     */
    public function saveChecklistValidationAction(Request $request, Etude $etude): Response
    {
        $message = [
            'type' => 'success',
            'text' => 'Checklist updated.',
        ];

        $checkListValidations = $request->get('check_list_validation', []);

        $existingcheckListValidations = [];
        if (isset($checkListValidations)) {
            $existingcheckListValidations = $etude->getEtudeCheckListValidations()->toKeyIndex('Id');

            foreach ($checkListValidations as $checkListValidation) {
                $id = $checkListValidation['id'];
                $check = isset($checkListValidation['check']);
                $etudeCheckListId = $checkListValidation['checklist_id'];
                $checkListValidation = isset($existingcheckListValidations[$id]) ? $existingcheckListValidations[$id] : null;

                if (!$checkListValidation) {
                    $checkListValidation = new EtudeCheckListValidation();
                    $checkListValidation->setEtudeChecklistId($etudeCheckListId);
                    $checkListValidation->setEtudeId($etude->getId());
                    $existingcheckListValidations[$id] = $checkListValidation;
                }

                $checkListValidation->setIsCheck($check);
                $checkListValidation->save();
            }
        }

        return $this->render('pmtool/project/_checklist.html.twig', [
            'etude' => $etude,
            'etudeChecklistValidations' => $existingcheckListValidations,
            'message' => $message,
        ]);
    }

    // FIXME why do we need an Ajax call for that???

    /**
     * @Route(name="etude_currency", path="/project/project-currency/{id}")
     */
    public function getEtudeCurrencyAction(Request $request, Etude $etude): JsonResponse
    {
        return $this->json($etude->getCurrencies());
    }

    /**
     * @Route(name="etude_set_currency_rate", path="/project/set-currency-rate/{id}")
     */
    public function setCurrencyRateAction(Request $request, Etude $etude): Response
    {
        $currencies = array_filter($request->request->all());
        $default_exchange_rate = 1;

        $result = array_map(function ($k, $v) {
            $k = substr($k, 0, 3);

            return "$k=$v";
        }, array_keys($currencies), array_values($currencies));

        $result = implode('|', $result);

        $respLocationCurrency = Location::RES_LOCATION_CURRENCY;

        $etude->setCurrencies($result ?: '')->save();

        $bidJobItems = JobItemQuery::create()->filterByEtude($etude)->find();
        $JobCosts = JobCostQuery::create()->filterByEtude($etude)->find();

        //update local unit and price
        foreach ($bidJobItems as $bidJobItem) {
            $default_exchange_rate = 1;
            if ($bidJobItem->getRespLocation()) {
                $location = $bidJobItem->getRespLocation()->getValue();
                $selectedCurrency = $respLocationCurrency[$location];

                if (array_key_exists($selectedCurrency, $currencies)) {
                    $default_exchange_rate = $currencies[$selectedCurrency];
                }
                $coeff = $bidJobItem->getCoefficiantPr() ? $bidJobItem->getCoefficiantPr() : 1;
                $bidJobItem->setPrixVenteUnitaireLocation($bidJobItem->getPrixRevientUnitaire() * floatval($default_exchange_rate));
                $bidJobItem->setPrixRevient($bidJobItem->getPrixRevientUnitaire() * floatval($default_exchange_rate) * $bidJobItem->getQuantitePr() * floatval($coeff));
                $bidJobItem->save();
            }
        }

        foreach ($JobCosts as $JobCost) {
            $default_exchange_rate = 1;
            if ($JobCost->getRespLocation()) {
                $location = $JobCost->getRespLocation()->getValue();
                $selectedCurr = $respLocationCurrency[$location];

                if (array_key_exists($selectedCurr, $currencies)) {
                    $default_exchange_rate = $currencies[$selectedCurr];
                }
                $coeff = $JobCost->getCoefficiant() ? $JobCost->getCoefficiant() : 1;

                $JobCost->setPrixVenteUnitaireLocation($JobCost->getUnitPrice() * floatval($default_exchange_rate));
                $JobCost->setPrixRevient($JobCost->getUnitPrice() * floatval($default_exchange_rate) * $JobCost->getQuantitePr() * floatval($coeff));
                $JobCost->save();
            }
        }

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * @Route(name="etude_bid_job_location", path="/project/bid-job-location/{id}/{choice}")
     */
    public function bidJobLocationAction(Request $request, Job $job): JsonResponse
    {
        $choice = $request->get('choice');

        $cost = 0;
        switch ($choice) {
            case 1:
                $cost = $job->getPerHour() ?: 0;
                break;
            case 2:
                $cost = $job->getPerDay() ?: 0;
                break;
            case 3:
                $cost = $job->getPerGroup() ?: 0;
                break;
            default:
                $cost = 0;
        }

        return $this->json($cost);
    }

    /**
     * @Route(name="check_if_multimarket", path="/project/check-if-multimarket")
     */
    public function checkIfMultimarketAction(Request $request): JsonResponse
    {
        $clientId = $request->get('clientId');
        $endClientId = $request->get('endClientId');
        $clientDiscountProgram = $endClientDiscountProgram = null;

        if ($client = Account::getById($clientId)) {
            $clientDiscountProgram = $client->getDiscountProgramId();
        }

        if ($endClient = Account::getById($endClientId)) {
            $endClientDiscountProgram = $endClient->getDiscountProgramId();
        }

        $result = (int) ($clientDiscountProgram || $endClientDiscountProgram);

        return $this->json($result);
    }

    /**
     * @Route(name="etude_generate_invoice", path="/project/generate-invoice")
     */
    public function generateInvoiceAction(Request $request, UrlHelper $urlHelper): Response
    {
        $invoiceIds = $request->get('invoices');

        if (!empty($invoiceIds)) {
            $jobs = [];
            $clientsPo = [];
            $invoices = FactureQuery::create()->filterById($invoiceIds, Criteria::IN)->find();
            $ExchangeRateSym = [];
            $tauxChangeNew = 1;
            $invoiceType = $invoices->getFirst() && $invoices->getFirst()->getDocument() ? $invoices->getFirst()->getDocument()->getDocumentBr() : null;
            foreach ($invoices as $invoice) {
                $ExchangeRateSym[] = $invoice->getSymboleMonnaie();
                $job = $invoice->getJob();
                $tauxChangeNew = $invoice->getTauxChange();
                if ($job) {
                    foreach ($job->getJobItems() as $jobItem) {
                        if ($jobItem->getDownPayment()) {
                            $jobs[$job->getId()] = $job;
                            $clientsPo[] = $job->getPoJobNumber();
                        }
                    }
                }
            }
            $creditCardLogo = $urlHelper->getAbsoluteUrl('/htdocs/images/NewLogo/visa-mastercard-amex.png');
            $format = 'USLETTER';
            $html2pdf = new Html2Pdf('P', $format, 'fr', 'true', 'UTF-8', [0, 10, 0, 5]);
            $html2pdf->setDefaultFont('arial');
            $html2pdf->addFont('zapfdingbats', '', 14);

            $ExchangeRateSym = array_unique($ExchangeRateSym);
            $clientPoNumber = implode(' - ', array_unique($clientsPo));
            $template = null;
            $invoicesDatas = null;
            if (!empty($jobs)) {
                $etude = (current($jobs))->getEtude();

                if (in_array($invoiceType, ['ADVANCED INVOICE', 'ASPEN FINN'])) {
                    $template = 'ASPEN FINN' == $invoiceType ? 'pmtool/facture/advanced_inv_aspen_finn.html.twig' : 'pmtool/facture/advanced_inv.html.twig';
                    $logoFile = 'ASPEN FINN' == $invoiceType ? '/htdocs/images/NewLogo/Aspen_Finn_Logo.png' : '/htdocs/images/NewLogo/QUAL.png';
                    $logo = $urlHelper->getAbsoluteUrl($logoFile);
                    $invoicesDatas = [
                        'isProjectInvoiceType' => false,
                        'etude' => $etude,
                        'tauxChangeNew' => $tauxChangeNew,
                        'symboleMonnaieNew' => $ExchangeRateSym[0],
                        'jobs' => $jobs,
                        'factureNumero' => '',
                        'externalReference' => '',
                        'date' => new DateTime(),
                        'clientPoNumber' => $clientPoNumber,
                        'logo' => $logo,
                        'creditCardLogo' => $creditCardLogo,
                    ];

                    try {
                        $html2pdf->writeHTML($this->renderTemplate($template, $invoicesDatas));
                        $jobCollection = new Collection();
                        foreach ($jobs as $job) {
                            $jobCollection->append($job);
                        }
                        $pdfName = $etude->getNameForPDF('job_advanced_invoice', $jobCollection);
                        $content = $html2pdf->output($this->clean($pdfName).'.pdf', 'I');
                        $response = new Response($content, 200, [
                            'Content-Description' => 'PDF projet',
                            'Content-Type' => 'application/pdf',
                            'Content-Transfer-Encoding' => 'binary',
                            'Expires' => '0',
                            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
                            'Pragma' => 'public',
                            'Content-Length' => strlen($content),
                        ]);

                        return $response->setCharset('UTF-8');
                    } catch (Html2PdfException $e) {
                        $html2pdf->clean();
                        $formatter = new ExceptionFormatter($e);

                        return new Response($formatter->getHtmlMessage());
                    }
                }
            }
        }

        return $this->redirectToRoute('etude_recherche_index');
    }

    /**
     * @Route(name="etude_get_invoice_amount", path="/project/get-invoice-amount")
     */
    public function getInvoiceAmountAction(Request $request): JsonResponse
    {
        $job = Job::getById($request->get('jobId'));
        $amount = 0;
        if ($job) {
            foreach ($job->getJobItems() as $jobItem) {
                if ($jobItem->getDownPayment()) {
                    $amount += $jobItem->getPrixVente();
                }
            }
        }

        return $this->json($amount);
    }

    /**
     * @Route(name="get_discount_percentage", path="/project/get-discount-percentage")
     */
    public function getDiscountPercentageAction(Request $request): JsonResponse
    {
        $clientId = $request->get('clientId');
        $client = Account::getById($clientId);
        $clientDiscountPercentage = 0;
        $clientQuantDiscountPercentage = 0;
        $discountProgramClient = $client && $client->getDiscountProgram() ? $client->getDiscountProgram()->getValue() : '';

        if ($client && $client->getQuantDiscountPercentage()) {
            $clientQuantDiscountPercentage = $client->getQuantDiscountPercentage()->getValue();
        }

        if ('us' == $this->instance || !in_array($discountProgramClient, Job::QUAL_EU_PROGRAMS)) {
            if ($client && $client->getDiscountPercentage()) {
                $clientDiscountPercentage = $client->getDiscountPercentage()->getValue();
            }
        } else {
            if ($client && $client->getEuDiscountPercentage()) {
                $clientDiscountPercentage = $client->getEuDiscountPercentage()->getValue();
            }
        }

        return $this->json([
            'clientDiscountPercentage' => $clientDiscountPercentage,
            'clientQuantDiscountPercentage' => $clientQuantDiscountPercentage,
        ]);
    }

    private function pointToServerPathImage(string $img_string, string $uploadDir)
    {
        preg_match_all('@src="([^"]+)"@', $img_string, $match); //search all image src

        $images = array_pop($match);

        foreach ($images as $image) {
            $substring = '?file-name=';
            $start = stripos($image, $substring);
            $imageName = substr($image, $start + strlen($substring));

            if (file_exists($uploadDir.$imageName)) {
                $img_string = str_replace($image, $uploadDir.$imageName, $img_string);
            } else {
                $img_string = preg_replace("/<img[^>]+\>/i", ' ', $img_string);
            }
        }

        return $img_string;
    }

    /**
     * @Route(name="confirmation_document", path="/project/{id}/confirmation-document")
     */
    public function confirmationDocumentAction(Request $request, Etude $etude, string $uploadDir): Response
    {
        ini_set('max_execution_time', '240');

        foreach ($etude->getJobEtudes() as $job) {
            foreach ($job->getEvents() as $event) {
                if (!$event->getSite() && !$event->getIsDeletedC()) {
                    $this->addFlash('danger', 'You need to define a site before creating job alert / job confirmation!!');

                    return $this->redirect('/project/show/'.$etude->getId());
                }
            }
        }

        $format = 'us' == $this->instance ? 'USLETTER' : 'A4';
        $html2pdf = new Html2Pdf('P', $format, 'fr', 'true', 'UTF-8', [0, 10, 0, 5]);
        $html2pdf->setDefaultFont('arial');
        $html2pdf->addFont('zapfdingbats', '', 14);

        $study_specs = $etude->getStudySpecification() ?: '';
        $study_specs = $this->pointToServerPathImage($study_specs, $uploadDir);

        $additional_notes = $etude->getAdditionalNotes() ?: '';
        $additional_notes = $this->pointToServerPathImage($additional_notes, $uploadDir);

        try {
            $html2pdf->writeHTML($this->renderTemplate('pmtool/project/confirmationDocument.pdf.twig', [
                'etude' => $etude,
                'accountManager' => $etude->getProjectAccountManager(),
                'incentiveJobItems' => $etude->getIncentivesForDocuments(),
                'source' => array_map('strtolower', $etude->getSampleSources()->toKeyValue('Id', 'Libelle')),
                'siteEvents' => $etude->getEventsForDocuments(),
                'study_specification' => $etude->getStudySpecification() ? HTMLPurifier::cleanForPdf($study_specs) : '',
                'additional_notes' => $etude->getAdditionalNotes() ? HtmlPurifier::cleanForPdf($additional_notes) : '',
                'finalClientNumber' => $this->addSpacesInLongWords($etude->getReferenceClientWithNotLimitSize()),
                'finalTopic' => $this->addSpacesInLongWords($etude->getTheme()),
            ]));

            $content = $html2pdf->output('export.pdf', 'S');

            $response = new Response($content, 200, [
                'Content-Description' => 'PDF projet',
                'Content-Type' => 'application/pdf',
                'Content-Transfer-Encoding' => 'binary',
                'Expires' => '0',
                'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
                'Pragma' => 'public',
                'Content-Length' => strlen($content),
            ]);

            return $response->setCharset('UTF-8');
        } catch (Html2PdfException $e) {
            $html2pdf->clean();
            $formatter = new ExceptionFormatter($e);

            return new Response($formatter->getHtmlMessage());
        }
    }

    /**
     * @Route(name="new_confirmation_document", path="/project/{id}/new-confirmation-document")
     */
    public function newConfirmationDocumentAction(Request $request, Etude $etude): Response
    {
        ini_set('max_execution_time', '240');
        $basic_specification_flag = $request->get('basic_specification_flag', null);

        return $this->render('pmtool/project/newconfirmationDocument.html.twig', [
            'etude' => $etude,
            'accountManager' => $etude->getProjectAccountManager(),
            'incentiveJobItems' => $etude->getIncentivesForDocuments(),
            'source' => array_map('strtolower', $etude->getSampleSources()->toKeyValue('Id', 'Libelle')),
            'siteEvents' => $etude->getEventsForDocuments(),
            'study_specification' => $etude->getStudySpecification() ?: '',
            'additional_notes' => $etude->getAdditionalNotes() ?: '',
            'finalClientNumber' => $this->addSpacesInLongWords($etude->getReferenceClientWithNotLimitSize()),
            'finalTopic' => $this->addSpacesInLongWords($etude->getTheme()),
            'header' => '',
            'basic_specification_flag' => $basic_specification_flag,
        ]);
    }

    /**
     * @Route(name="group_etude_price", path="/project/{id}/group-price")
     */
    public function groupPriceAction(Job $job): JsonResponse
    {
        $bidJobItemGroups = array_unique(JobItemQuery::create()->select('group')->filterByJob($job)->find()->getData());
        $bidJobItemSubGroups = array_unique(JobItemQuery::create()->select('super_group')->filterByJob($job)->find()->getData());
        $groupTotal = [];
        $jobItems = $job->getJobItems();

        foreach ($bidJobItemGroups as $bidJobItemGroup) {
            $jobItemsPerGroups = [];
            foreach ($jobItems as $jobItem) {
                if ($jobItem->getGroup() == $bidJobItemGroup) {
                    $jobItemsPerGroups[] = $jobItem;
                }
            }
            $total = 0;
            $qty = 0;
            $totalCost = 0;
            $costQty = 0;

            foreach ($jobItemsPerGroups as $jobItemsPerGroup) {
                $total += (float) $jobItemsPerGroup->getPrixVente();
                if (!$jobItemsPerGroup->getCategoriePrestation() || 'Discounts' !== $jobItemsPerGroup->getCategoriePrestation()->getConsolidation()) {
                    $qty += (float) $jobItemsPerGroup->getQuantitePv();
                    $costQty += (float) $jobItemsPerGroup->getQuantitePr();
                }
                $totalCost += (float) $jobItemsPerGroup->getPrixRevient();
            }

            $total = $this->currency.$total;
            $totalCost = $this->currency.$totalCost;

            $groupTotal[] = [
                'group' => $bidJobItemGroup,
                'total' => $total,
                'qty' => (int) $qty,
                'costTotal' => $totalCost,
                'costQty' => (int) $costQty,
            ];
        }
        $subGroupTotal = [];
        foreach ($bidJobItemSubGroups as $bidJobItemSubGroup) {
            $jobItemsPerSubGroups = [];
            foreach ($jobItems as $jobItem) {
                if ($jobItem->getSuperGroup() == $bidJobItemSubGroup) {
                    $jobItemsPerSubGroups[] = $jobItem;
                }
            }
            $subTotal = 0;
            $subQty = 0;
            $costSubTotal = 0;
            $costSubQty = 0;
            $initGroupJobItem = $jobItemsPerSubGroups[0] ?? null;
            foreach ($jobItemsPerSubGroups as $jobItemsPerSubGroup) {
                if ($initGroupJobItem->getGroup() == $jobItemsPerSubGroup->getGroup()) {
                    $subTotal += (float) $jobItemsPerSubGroup->getPrixVente();
                    if (!$jobItemsPerSubGroup->getCategoriePrestation() || 'Discounts' !== $jobItemsPerSubGroup->getCategoriePrestation()->getConsolidation()) {
                        $subQty += (float) $jobItemsPerSubGroup->getQuantitePv();
                        $costSubQty += (float) $jobItemsPerSubGroup->getQuantitePr();
                    }
                    $costSubTotal += (float) $jobItemsPerSubGroup->getPrixRevient();
                }
            }
            $subTotal = $this->currency.$subTotal;
            $costSubTotal = $this->currency.$costSubTotal;
            $subGroupTotal[] = [
                'subGroup' => $bidJobItemSubGroup,
                'total' => $subTotal,
                'qty' => (int) $subQty,
                'costTotal' => $costSubTotal,
                'costQty' => (int) $costSubQty,
            ];
        }

        return $this->json([
            'group_total' => json_encode($groupTotal),
            'sub_group_total' => json_encode($subGroupTotal),
        ]);
    }

    /**
     * US only.
     */
    private function mailBadPayer(Etude $etude, MailManager $mailerManager): void
    {
        $pmRef = $etude->getNumeroEtude();
        $badPayers = [];
        $salesManager = $etude->getBM()->getMail();
        $createdBy = $this->getUser()->getMail();
        $mailTo = implode(';', User::getUserEmailBadPayerReceiver()).';'.$salesManager.';'.$createdBy;
        $accountBp = $etude->getAccount() ? $etude->getAccount()->getBadPayer() : '';
        $intermediateClientBp = $etude->getIntermediateClient() ? $etude->getIntermediateClient()->getBadPayer() : '';
        $endClientBp = $etude->getEndClient() ? $etude->getEndClient()->getBadPayer() : '';

        if ('Y' === $accountBp) {
            $badPayers['Account'] = $etude->getAccount()->getName();
        }

        if ('Y' === $intermediateClientBp) {
            $badPayers['Intermediate Client'] = $etude->getIntermediateClient()->getName();
        }

        if ('Y' === $endClientBp) {
            $badPayers['End Client'] = $etude->getEndClient()->getName();
        }
        $subject = 'The following Bad Payer has a new Project ('.implode(', ', $badPayers).')';
        $content = $this->renderTemplate('pmtool/email/mailBadPayer.html.twig', [
            'badPayers' => $badPayers,
            'pmRef' => $pmRef,
            'projectSubject' => $etude->getTheme(),
        ]);
        if ($mailTo) {
            $mailerManager->send($mailTo, [], [], $subject, $content);
        }
    }

    /**
     * @Route(name="summary_sheet", path="/project/{id}/summary-sheet")
     */
    public function summarySheetAction(Request $request, Etude $etude): Response
    {
        $rebateSection = CategoriePrestation::findByCategoryName('Rebate Amount');
        $currency = $this->currency;
        $defaultDateFmt = $this->getDefaultDateFmt();
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $this->setColumnWidth($sheet, ['A', 'B'], 23);
        $this->setColumnWidth($sheet, ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'], 17);

        $sheet->setCellValue('A1', 'Invoice Summary');
        $sheet->getStyle('A1')->getFont()->setBold(true);
        $sheet->getStyle('A1')->getFont()->setSize(15);

        $this->setTitleSheet($sheet, 'A2', 'Master Project');
        $this->setTitleSheet($sheet, 'A3', 'Help Search Subject');
        $this->setTitleSheet($sheet, 'A4', 'Job Type');
        $this->setTitleSheet($sheet, 'A5', 'Client');
        $this->setTitleSheet($sheet, 'A6', 'Client ID:');
        $this->setTitleSheet($sheet, 'A7', 'End Client:');
        $this->setTitleSheet($sheet, 'A8', 'Account Manager:');

        $projectMethodologies = null;
        foreach ($etude->getMethodologies() as $projectMethodology) {
            $projectMethodologies = $projectMethodologies ? $projectMethodologies.' - '.$projectMethodology->getSfLabel() : $projectMethodology->getSfLabel();
        }

        $massCode = $etude->getAccount() ? $etude->getAccount()->getMas500Id() : '-';
        $sheet->setCellValue('B2', $etude->getMasterProjectNumber());
        $sheet->setCellValue('B3', $etude->getTheme());
        $sheet->setCellValue('B4', $projectMethodologies);
        $sheet->setCellValue('B5', $etude->getAccount());
        $sheet->setCellValue('B6', $massCode);
        $sheet->setCellValue('B7', $etude->getEndClient());
        $sheet->setCellValue('B8', $etude->getProjectAccountManager());

        $this->setTitleSheet($sheet, 'E2', 'Project Total:');
        $this->setTitleSheet($sheet, 'E3', 'PM Contact:');
        $this->setTitleSheet($sheet, 'E6', 'Location:');
        $this->setTitleSheet($sheet, 'E7', 'Address:');

        $sheet->setCellValue('F2', $currency.' '.$etude->getPrixVenteActualise());
        $sheet->setCellValue('F3', $etude->getContactClientPm() ?: '');
        $sheet->setCellValue('F4', $etude->getContactClientPm() ? $etude->getContactClientPm()->getEmail() : '');
        $sheet->setCellValue('F5', $etude->getContactClientPm() ? $etude->getContactClientPm()->getPhone() : '');
        $billingAddress = $etude->getContactClientPm() ? ($etude->getContactClientPm()->getOtherStreet().' '.$etude->getContactClientPm()->getOtherCity().' '.$etude->getContactClientPm()->getOtherState().''.$etude->getContactClientPm()->getOtherPostalCode().' '.$etude->getContactClientPm()->getOtherCountry()) : '';
        $sheet->setCellValue('F6', $etude->getEtudeLocation());
        $sheet->setCellValue('F7', $billingAddress);
        $cellLine = 11;
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C']);
        $this->setTitleSheet($sheet, "B$cellLine", 'Initial');
        $this->setTitleSheet($sheet, "C$cellLine", 'Actual');
        $sheet->getStyle("C$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

        ++$cellLine;
        $this->setRevenueTab($sheet, $cellLine, 'Revenue', $etude->getPrixVenteInitial(), $etude->getPrixVenteActualise(), $currency);
        ++$cellLine;
        $this->setRevenueTab($sheet, $cellLine, 'Cost', $etude->getPrixRevientInitial(), $etude->getPrixRevientActualise(), $currency);
        ++$cellLine;
        $this->setRevenueTab($sheet, $cellLine, 'Margin %', $etude->getInitialMarginPercentage(), $etude->getActualMarginPercentage(), $currency);
        ++$cellLine;
        $this->setRevenueTab($sheet, $cellLine, 'Margin', $etude->getInitialMarginAmount(), $etude->getActualMarginAmount(), $currency);
        ++$cellLine;
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C']);

        ++$cellLine;
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D']);
        $this->setTitleSheet($sheet, "B$cellLine", 'Client ');
        $this->setTitleSheet($sheet, "C$cellLine", 'Intermediate Client ');
        $this->setTitleSheet($sheet, "D$cellLine", 'End Client ');
        $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

        ++$cellLine;
        $discountProgramClient = $etude->getAccount() && $etude->getAccount()->getDiscountProgram() ? $etude->getAccount()->getDiscountProgram()->getValue() : '';
        $discountProgramIntermediateClient = $etude->getIntermediateClient() && $etude->getIntermediateClient()->getDiscountProgram() ? $etude->getIntermediateClient()->getDiscountProgram()->getValue() : '';
        $discountProgramEndClient = $etude->getEndClient() && $etude->getEndClient()->getDiscountProgram() ? $etude->getEndClient()->getDiscountProgram()->getValue() : '';
        $this->setDiscountTab($sheet, $cellLine, 'Discount Program ', $discountProgramClient, $discountProgramIntermediateClient, $discountProgramEndClient);

        ++$cellLine;
        $rebateClient = $etude->getAccount() && 1 == $etude->getAccount()->getRebate() ? 'Yes' : '';
        $rebateInterClient = $etude->getIntermediateClient() && 1 == $etude->getIntermediateClient()->getRebate() ? 'Yes' : '';
        $rebateEndClient = $etude->getEndClient() && 1 == $etude->getEndClient()->getRebate() ? 'Yes' : '';

        $this->setDiscountTab($sheet, $cellLine, 'Rebate', $rebateClient, $rebateInterClient, $rebateEndClient);

        ++$cellLine;
        $qualDiscountInter = $etude->getIntermediateClient() && $etude->getIntermediateClient()->getDiscountPercentage() ? $etude->getIntermediateClient()->getDiscountPercentage()->getValue() : '';
        $this->setDiscountTab($sheet, $cellLine, 'Qual Discount in US', $etude->getClientDiscountPercentage(), $qualDiscountInter, $etude->getEndClientDiscountPercentage());

        ++$cellLine;
        $qualDiscountEu = $etude->getAccount() && $etude->getAccount()->getEuDiscountPercentage() ? $etude->getAccount()->getEuDiscountPercentage()->getValue() : '';
        $qualDiscountEuInter = $etude->getIntermediateClient() && $etude->getIntermediateClient()->getEuDiscountPercentage() ? $etude->getIntermediateClient()->getEuDiscountPercentage()->getValue() : '';
        $qualDiscountEuEnd = $etude->getEndClient() && $etude->getEndClient()->getEuDiscountPercentage() ? $etude->getEndClient()->getEuDiscountPercentage()->getValue() : '';
        $this->setDiscountTab($sheet, $cellLine, 'Qual Discount in EU', $qualDiscountEu, $qualDiscountEuInter, $qualDiscountEuEnd);

        ++$cellLine;
        $quantDiscountClient = $etude->getAccount() && $etude->getAccount()->getQuantDiscountPercentage() ? $etude->getAccount()->getQuantDiscountPercentage()->getValue() : '';
        $quantDiscountInterClient = $etude->getIntermediateClient() && $etude->getIntermediateClient()->getQuantDiscountPercentage() ? $etude->getIntermediateClient()->getQuantDiscountPercentage()->getValue() : '';
        $quantDiscountEndClient = $etude->getEndClient() && $etude->getEndClient()->getQuantDiscountPercentage() ? $etude->getEndClient()->getQuantDiscountPercentage()->getValue() : '';

        $this->setDiscountTab($sheet, $cellLine, 'Quant Discount everywhere', $quantDiscountClient, $quantDiscountInterClient, $quantDiscountEndClient);

        ++$cellLine;
        $commentClient = $etude->getAccount() && $etude->getAccount()->getQuantDiscountPercentage() ? $etude->getAccount()->getDiscountNotes() : '';
        $commentInterClient = $etude->getIntermediateClient() && $etude->getIntermediateClient()->getQuantDiscountPercentage() ? $etude->getIntermediateClient()->getDiscountNotes() : '';
        $commentEndClient = $etude->getEndClient() && $etude->getEndClient()->getQuantDiscountPercentage() ? $etude->getEndClient()->getDiscountNotes() : '';
        $this->setDiscountTab($sheet, $cellLine, 'Comments', $commentClient, $commentInterClient, $commentEndClient);

        ++$cellLine;
        $account = $etude->getAccount();
        $badPayerClient = $account ? $account->getBadPayer() : '';
        $badPayerInterClient = $etude->getIntermediateClient() ? $etude->getIntermediateClient()->getBadPayer() : '';
        $badPayerEndClient = $etude->getEndClient() ? $etude->getEndClient()->getBadPayer() : '';
        $this->setTitleSheet($sheet, "A$cellLine", 'Bad Payer');
        $sheet->setCellValue("B$cellLine", $badPayerClient);
        $sheet->setCellValue("C$cellLine", $badPayerInterClient);
        $sheet->setCellValue("D$cellLine", $badPayerEndClient);
        $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
        ++$cellLine;
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D']);
        ++$cellLine;

        $this->setTitleSheet($sheet, "A$cellLine", 'Facility Details');
        ++$cellLine;
        $this->setTitleSheet($sheet, "A$cellLine", 'Research Date USQ');
        ++$cellLine;
        $jobs = $etude->getJobEtudes();

        $events = EventQuery::create()->filterByJob($jobs)->find();
        $this->setTitleSheet($sheet, "A$cellLine", 'Date');
        $sheet->getStyle("A$cellLine:E$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
        $this->setTitleSheet($sheet, "B$cellLine", 'Start Time');
        $this->setTitleSheet($sheet, "C$cellLine", 'End Time');
        $this->setTitleSheet($sheet, "D$cellLine", 'Location');
        $this->setTitleSheet($sheet, "E$cellLine", 'Schedule Types');
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E']);
        $sheet->getStyle("E$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
        ++$cellLine;

        foreach ($events as $event) {
            $date = $event->getDate() ? $event->getDate($defaultDateFmt) : '-';
            $startTime = $event->getStartDateTime() ? $event->getStartDateTime('h:i a') : '-';
            $endTime = $event->getEndDateTime() ? $event->getEndDateTime('h:i a') : '-';
            $location = $event->getJob() ? $event->getJob()->getJobLocation() : '-';
            $scheduleTypes = $event->getEventMethodology();
            $sheet->setCellValue('A'.$cellLine, $date);
            $sheet->setCellValue('B'.$cellLine, $startTime);
            $sheet->setCellValue('C'.$cellLine, $endTime);
            $sheet->setCellValue('D'.$cellLine, $location);
            $sheet->setCellValue('E'.$cellLine, $scheduleTypes);
            $sheet->getStyle("E$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
            ++$cellLine;
        }
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E']);

        $jobs = JobQuery::create()->filterByEtudeId($etude->getId())->find();
        $jobItems = JobItemQuery::create()->filterByJob($jobs)->orderByCategoriePrestationId()->find();
        $costItems = JobCostQuery::create()->filterByJob($jobs)->find();
        $respType = null;

        foreach ($etude->getSectors() as $respTypes) {
            if ($respTypes->getRefSalesForceEtudeRefSector()) {
                if ($respType) {
                    $respType = $respType.' - '.$respTypes->getRefSalesForceEtudeRefSector()->getValue();
                } else {
                    $respType = $respTypes->getRefSalesForceEtudeRefSector()->getValue();
                }
            }
        }
        foreach ($jobs as $job) {
            $facilityRentalJobItems = $recruitingJobItems = $incentivesJobItems = $staffingJobItems = $equipmentJobItems = $clientFoodJobItems = $respondentFoodJobItems = $MiscJobItems = $discountJobItems = $ShippingJobItems = [];
            $facilityInternal = $recruitingInternal = $incentiveInternal = $staffingInternal = $internalClientFood = $internalRespondentFood = $miscInternal = $shippingInternal = 0;
            $facilityExternal = $recruitingExternal = $incentiveExternal = $staffingExternal = $externalClientFood = $externalRespondentFood = $miscExternal = $shippingExternal = $discountClient = 0;
            $jobItemsRebate = [];
            foreach ($jobItems as $jobItem) {
                if ($jobItem->getCategoriePrestation() && $jobItem->getJobId() == $job->getId()) {
                    if ($jobItem->getCategoriePrestation() == $rebateSection) {
                        $jobItemsRebate[] = $jobItem;
                    }
                    switch ($jobItem->getCategoriePrestation()->getConsolidation()) {
                        case 'Facility':
                            $facilityRentalJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $facilityInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $facilityExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Misc':
                            $MiscJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $miscInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $miscExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Recruitment':
                            $recruitingJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $recruitingInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $recruitingExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Staffing':
                            $staffingJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $staffingInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $staffingExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Equipment':
                            $equipmentJobItems[] = $jobItem;
                            break;
                        case 'Food':
                            if ($this->startsWith($jobItem->getCategoriePrestation()->getCategory(), 'Client')) {
                                if (!$jobItem->getVendor()) {
                                    $internalClientFood += floatval($jobItem->getPrixVente());
                                } else {
                                    $externalClientFood += floatval($jobItem->getPrixVente());
                                }
                                $clientFoodJobItems[] = $jobItem;
                            } elseif ($this->startsWith($jobItem->getCategoriePrestation()->getCategory(), 'Respondent')) {
                                $respondentFoodJobItems[] = $jobItem;
                                if (!$jobItem->getVendor()) {
                                    $internalRespondentFood += floatval($jobItem->getPrixVente());
                                } else {
                                    $externalRespondentFood += floatval($jobItem->getPrixVente());
                                }
                            }
                            break;
                        case 'Incentives':
                            $incentivesJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $incentiveInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $incentiveExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Shipping':
                            $ShippingJobItems[] = $jobItem;
                            if (!$jobItem->getVendor()) {
                                $shippingInternal += floatval($jobItem->getPrixVente());
                            } else {
                                $shippingExternal += floatval($jobItem->getPrixVente());
                            }
                            break;
                        case 'Discounts':
                            $discountJobItems[] = $jobItem;
                            if (Job::END_CLIENT_PREFERRED == $jobItem->getCategoriePrestation()->getCategory() || Job::PREFERRED == $jobItem->getCategoriePrestation()->getCategory()) {
                                $discountClient += $jobItem->getPrixVente();
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            $methodologies = $job->getMethodologies();
            $methlgy = null;
            foreach ($methodologies as $methodology) {
                $methlgy = $methlgy ? $methlgy.' - '.$methodology->getSfLabel() : $methlgy = $methodology->getSfLabel();
            }
            ++$cellLine;
            $sheet->setCellValue("A$cellLine", $job->getIdSamsJob());
            $sheet->getStyle("A$cellLine")->getFont()->setBold(true);
            $sheet->getStyle("A$cellLine")->getFont()->setSize(14);
            ++$cellLine;

            $this->setTitleSheet($sheet, "A$cellLine", 'Status:');
            $sheet->setCellValue("B$cellLine", $job->getStatus());
            $this->setTitleSheet($sheet, "C$cellLine", 'AM Review:');
            $sheet->setCellValue("D$cellLine", $job->getAmChecked() ? 'Yes' : 'No');
            $this->setTitleSheet($sheet, "E$cellLine", 'Final Review:');
            $sheet->setCellValue("F$cellLine", $job->getFdChecked() ? 'Yes' : 'No');
            ++$cellLine;
            $sumRebate = 0;
            foreach ($jobItemsRebate as $jobItemRebate) {
                $sumRebate += $jobItemRebate->getPrixVente();
            }
            $jobTotal = $job->getBudgetRevenue() - $sumRebate;
            $this->setTitleSheet($sheet, "A$cellLine", 'Job Total:');
            $sheet->setCellValue("B$cellLine", $jobTotal);
            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Job Comments:');
            $sheet->setCellValue("B$cellLine", $job->getJobComments());
            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Respondent Type:');
            $sheet->setCellValue("B$cellLine", $respType);
            $this->setTitleSheet($sheet, "E$cellLine", 'Job Type:');
            $sheet->setCellValue("F$cellLine", $methlgy);
            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Start Date:');
            $sheet->setCellValue("B$cellLine", $job->getStartDate() ? $job->getStartDate($defaultDateFmt) : '-');
            $this->setTitleSheet($sheet, "C$cellLine", 'End Date:');
            $sheet->setCellValue("D$cellLine", $job->getEndDate() ? $job->getEndDate($defaultDateFmt) : '-');
            $this->setTitleSheet($sheet, "E$cellLine", 'Invoice Date:');
            $sheet->setCellValue("F$cellLine", $job->getInvoiceDate() ? $job->getInvoiceDate($defaultDateFmt) : '-');
            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Client Project Number:');
            $sheet->setCellValue("B$cellLine", $etude->getReferenceClient());
            $this->setTitleSheet($sheet, "C$cellLine", 'PO Number:');
            $sheet->setCellValue("D$cellLine", $job->getPoJobNumber());
            $this->setTitleSheet($sheet, "E$cellLine", 'Invoice #:');
            $sheet->setCellValue("F$cellLine", $job->getInvoiceNumber());
            $cellLine += 2;

            if (0 != count($facilityRentalJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Facility Rental ');
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                $this->setTitleSheet($sheet, "B$cellLine", 'Date');
                $this->setTitleSheet($sheet, "C$cellLine", 'Qty');
                $this->setTitleSheet($sheet, "D$cellLine", 'Day');
                $this->setTitleSheet($sheet, "E$cellLine", 'Group');
                $this->setTitleSheet($sheet, "F$cellLine", 'Hour');
                $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
                $this->setTitleSheet($sheet, "H$cellLine", 'Discount %');
                $this->setTitleSheet($sheet, "I$cellLine", 'Exclude');
                $this->setTitleSheet($sheet, "J$cellLine", 'Price');
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
                ++$cellLine;
                foreach ($facilityRentalJobItems as $facilityRentalJobItem) {
                    $perGroup = $perDay = $perHour = '-';
                    if ($facilityRentalJobItem->getCategoriePrestation() && 'per hour' == $facilityRentalJobItem->getCategoriePrestation()->getCategory()) {
                        $perHour = $currency.' '.$facilityRentalJobItem->getPrixVenteUnitaire();
                    } elseif ($facilityRentalJobItem->getCategoriePrestation() && 'per day' == $facilityRentalJobItem->getCategoriePrestation()->getCategory()) {
                        $perDay = $currency.' '.$facilityRentalJobItem->getPrixVenteUnitaire();
                    } elseif ($facilityRentalJobItem->getCategoriePrestation() && 'per group' == $facilityRentalJobItem->getCategoriePrestation()->getCategory()) {
                        $perGroup = $currency.' '.$facilityRentalJobItem->getPrixVenteUnitaire();
                    }
                    $sheet->setCellValue("A$cellLine", $facilityRentalJobItem->getMethodology());
                    $sheet->setCellValue("B$cellLine", $facilityRentalJobItem->getDate() ? $facilityRentalJobItem->getDate($defaultDateFmt) : '-');
                    $sheet->setCellValue("C$cellLine", $facilityRentalJobItem->getQuantitePv());
                    $sheet->setCellValue("D$cellLine", $perDay);
                    $sheet->setCellValue("E$cellLine", $perGroup);
                    $sheet->setCellValue("F$cellLine", $perHour);
                    $sheet->setCellValue("G$cellLine", $facilityRentalJobItem->getVendor() ? $facilityRentalJobItem->getVendor()->getSociete() : '');
                    $sheet->setCellValue("H$cellLine", $facilityRentalJobItem->getDiscountPercent());
                    $sheet->setCellValue("I$cellLine", $facilityRentalJobItem->getDiscountExclude() ? 'Yes' : 'No');
                    $sheet->setCellValue("J$cellLine", $currency.' '.$facilityRentalJobItem->getPrixVente());
                    $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                    ++$cellLine;
                }
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
            }
            if (0 != count($recruitingJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Recruiting');
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                $this->setTitleSheet($sheet, "B$cellLine", 'Category');
                $this->setTitleSheet($sheet, "C$cellLine", 'Section');
                $this->setTitleSheet($sheet, "D$cellLine", 'Qty');
                $this->setTitleSheet($sheet, "E$cellLine", 'Unit');
                $this->setTitleSheet($sheet, "F$cellLine", 'Title');
                $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
                $this->setTitleSheet($sheet, "H$cellLine", 'Discount %');
                $this->setTitleSheet($sheet, "I$cellLine", 'Exclude');
                $this->setTitleSheet($sheet, "J$cellLine", 'Price');
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
                ++$cellLine;
                foreach ($recruitingJobItems as $recruitingJobItem) {
                    $category = $recruitingJobItem->getCategoriePrestation() ? $recruitingJobItem->getCategoriePrestation()->getCategory() : '-';
                    $section = $recruitingJobItem->getCategoriePrestation() ? $recruitingJobItem->getCategoriePrestation()->getConsolidation() : '-';
                    $sheet->setCellValue("A$cellLine", $recruitingJobItem->getMethodology());
                    $sheet->setCellValue("B$cellLine", $section);
                    $sheet->setCellValue("C$cellLine", $category);
                    $sheet->setCellValue("D$cellLine", $recruitingJobItem->getQuantitePv());
                    $sheet->setCellValue("E$cellLine", $currency.' '.$recruitingJobItem->getPrixVenteUnitaire());
                    $sheet->setCellValue("F$cellLine", $recruitingJobItem->getSousTypePrestation());
                    $sheet->setCellValue("G$cellLine", $recruitingJobItem->getVendor() ? $recruitingJobItem->getVendor()->getSociete() : '');
                    $sheet->setCellValue("H$cellLine", $recruitingJobItem->getDiscountPercent());
                    $sheet->setCellValue("I$cellLine", $recruitingJobItem->getDiscountExclude() ? 'Yes' : 'No');
                    $sheet->setCellValue("J$cellLine", $currency.' '.$recruitingJobItem->getPrixVente());
                    $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                    ++$cellLine;
                }
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
            }

            if (0 != count($incentivesJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Incentives');
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                $this->setTitleSheet($sheet, "B$cellLine", 'Category');
                $this->setTitleSheet($sheet, "C$cellLine", 'Section');
                $this->setTitleSheet($sheet, "D$cellLine", 'Qty');
                $this->setTitleSheet($sheet, "E$cellLine", 'Unit');
                $this->setTitleSheet($sheet, "F$cellLine", 'Title');
                $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
                $this->setTitleSheet($sheet, "J$cellLine", 'Price');
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
                ++$cellLine;
                foreach ($incentivesJobItems as $incentivesJobItem) {
                    $category = $incentivesJobItem->getCategoriePrestation() ? $incentivesJobItem->getCategoriePrestation()->getCategory() : '-';
                    $section = $incentivesJobItem->getCategoriePrestation() ? $incentivesJobItem->getCategoriePrestation()->getConsolidation() : '-';
                    $sheet->setCellValue("A$cellLine", $incentivesJobItem->getMethodology());
                    $sheet->setCellValue("B$cellLine", $section);
                    $sheet->setCellValue("C$cellLine", $category);
                    $sheet->setCellValue("D$cellLine", $incentivesJobItem->getQuantitePv());
                    $sheet->setCellValue("E$cellLine", $currency.' '.$incentivesJobItem->getPrixVenteUnitaire());
                    $sheet->setCellValue("F$cellLine", $incentivesJobItem->getSousTypePrestation());
                    $sheet->setCellValue("G$cellLine", $incentivesJobItem->getVendor() ? $incentivesJobItem->getVendor()->getSociete() : '');
                    $sheet->setCellValue("J$cellLine", $currency.' '.$incentivesJobItem->getPrixVente());
                    $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                    ++$cellLine;
                }
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
            }

            if (0 != count($staffingJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Staffing');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $staffingJobItems, $cellLine, false, true, $currency);
            }

            if (0 != count($equipmentJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Equipment');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $equipmentJobItems, $cellLine, false, false, $currency);
            }

            if (0 != count($clientFoodJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Client Food');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $clientFoodJobItems, $cellLine, true, false, $currency);
            }

            if (0 != count($respondentFoodJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Respondent Food');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $respondentFoodJobItems, $cellLine, true, false, $currency);
            }
            if (0 != count($MiscJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Misc');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $MiscJobItems, $cellLine, false, false, $currency);
            }
            if (0 != count($ShippingJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Shipping');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $ShippingJobItems, $cellLine, true, false, $currency);
            }
            if (0 != count($discountJobItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Discounts');
                ++$cellLine;
                $cellLine = $this->addJobItemsToSheet($sheet, $discountJobItems, $cellLine, false, false, $currency);
            }
            $cellLine += 2;
            $this->setTitleSheet($sheet, "B$cellLine", 'Internal');
            $this->setTitleSheet($sheet, "C$cellLine", 'External');
            $this->setTitleSheet($sheet, "D$cellLine", 'Total');
            $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D']);
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
            $sheet->getStyle("A$cellLine:D$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
            ++$cellLine;

            $this->setTitleSheet($sheet, "A$cellLine", 'Facility Rental');
            $sheet->setCellValue("B$cellLine", $currency.' '.$facilityInternal);
            $sheet->setCellValue("C$cellLine", $currency.' '.$facilityExternal);
            $sheet->setCellValue("D$cellLine", $currency.' '.($facilityInternal + $facilityExternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Recruiting');
            $sheet->setCellValue("B$cellLine", $currency.' '.$recruitingInternal);
            $sheet->setCellValue("C$cellLine", $currency.' '.$recruitingExternal);
            $sheet->setCellValue("D$cellLine", $currency.' '.($recruitingInternal + $recruitingExternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'F/R');
            $sheet->setCellValue("B$cellLine", $currency.' '.($facilityInternal + $recruitingInternal));
            $sheet->setCellValue("C$cellLine", $currency.' '.($facilityExternal + $recruitingExternal));
            $sheet->setCellValue("D$cellLine", $currency.' '.($recruitingExternal + $facilityExternal + $facilityInternal + $recruitingInternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Discount');
            $sheet->setCellValue("B$cellLine", $currency.' '.($facilityInternal + $recruitingInternal - $discountClient));
            $sheet->setCellValue("C$cellLine", '$ 0');
            $sheet->setCellValue("D$cellLine", $currency.' '.($facilityInternal + $recruitingInternal - $discountClient));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Incentives');
            $sheet->setCellValue("B$cellLine", $currency.' '.$incentiveInternal);
            $sheet->setCellValue("C$cellLine", $currency.' '.$incentiveExternal);
            $sheet->setCellValue("D$cellLine", $currency.' '.($incentiveInternal + $incentiveExternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Staffing');
            $sheet->setCellValue("B$cellLine", $currency.' '.$staffingInternal);
            $sheet->setCellValue("C$cellLine", $currency.' '.$staffingExternal);
            $sheet->setCellValue("D$cellLine", $currency.' '.($staffingExternal + $staffingInternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Client Food');
            $sheet->setCellValue("B$cellLine", $currency.' '.$internalClientFood);
            $sheet->setCellValue("C$cellLine", $currency.' '.$externalClientFood);
            $sheet->setCellValue("D$cellLine", $currency.' '.($internalClientFood + $externalClientFood));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Respondent Food');
            $sheet->setCellValue("B$cellLine", $currency.' '.$internalRespondentFood);
            $sheet->setCellValue("C$cellLine", $currency.' '.$externalRespondentFood);
            $sheet->setCellValue("D$cellLine", $currency.' '.($internalRespondentFood + $externalRespondentFood));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Misc');
            $sheet->setCellValue("B$cellLine", $currency.' '.$miscInternal);
            $sheet->setCellValue("C$cellLine", $currency.' '.$miscExternal);
            $sheet->setCellValue("D$cellLine", $currency.' '.($miscInternal + $miscExternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
            $this->setTitleSheet($sheet, "A$cellLine", 'Shipping');
            $sheet->setCellValue("B$cellLine", $currency.' '.($shippingInternal));
            $sheet->setCellValue("C$cellLine", $currency.' '.($shippingExternal));
            $sheet->setCellValue("D$cellLine", $currency.' '.($shippingInternal + $shippingExternal));
            $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
            ++$cellLine;
            $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D']);
            ++$cellLine;

            if (0 != count($costItems)) {
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Internal Cost - Not shared with client');
                ++$cellLine;
                $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                $this->setTitleSheet($sheet, "B$cellLine", 'Category');
                $this->setTitleSheet($sheet, "C$cellLine", 'Section');
                $this->setTitleSheet($sheet, "D$cellLine", 'Qty');
                $this->setTitleSheet($sheet, "E$cellLine", 'Unit');
                $this->setTitleSheet($sheet, "F$cellLine", 'Title');
                $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
                $this->setTitleSheet($sheet, "J$cellLine", 'Price');
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('EC1010');
                ++$cellLine;
                foreach ($costItems as $costItem) {
                    if ($costItem->getJobId() == $job->getId()) {
                        $sheet->setCellValue("A$cellLine", $costItem->getMethodology());
                        $sheet->setCellValue("B$cellLine", $costItem->getCategoriePrestation() ? $costItem->getCategoriePrestation()->getConsolidation() : '');
                        $sheet->setCellValue("C$cellLine", $costItem->getCategoriePrestation() ? $costItem->getCategoriePrestation()->getCategory() : '');
                        $sheet->setCellValue("D$cellLine", $costItem->getQuantitePr());
                        $sheet->setCellValue("E$cellLine", $currency.' '.$costItem->getPrixVenteUnitaireLocation());
                        $sheet->setCellValue("F$cellLine", $costItem->getSousTypePrestation());
                        $sheet->setCellValue("G$cellLine", $costItem->getFournisseur() ? $costItem->getFournisseur()->getSociete() : '');
                        $sheet->setCellValue("J$cellLine", $currency.' '.$costItem->getPrixRevient());
                        $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                        ++$cellLine;
                    }
                }
                $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
            }
        }

        $writer = new Xlsx($spreadsheet);
        $response = new StreamedResponse(
            function () use ($writer) {
                $writer->save('php://output');
            }
        );
        $response->headers->set('Content-Type', 'application/vnd.ms-excel');
        $response->headers->set('Content-Disposition', 'attachment;filename="summary-'.$etude->getId().'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');

        return $response;
    }

    /**
     * @Route(name="cost_and_budget_export", path="/project/{id}/budget-and-cost-export")
     */
    public function costAndBudgetExportAction(Request $request, Etude $etude): Response
    {
        $jobs = $etude->getJobEtudes();

        $costItems = [];
        // $costItems and $jobItems order defined in JobItemsType & JobCostsType order by deviseOk and by categoryPrestation
        // Also order by js script in etude/show.js window.orderJobItems()
        $normalCostsItems = JobCostQuery::create()
            ->filterByJob($jobs, Criteria::IN)
            ->filterBySource(JobCostTableMap::COL_SOURCE_AUTO, Criteria::NOT_EQUAL)
            ->orderByOrder()
            ->orderByGroup()
            ->find();
        $autoCostsItems = JobCostQuery::create()
            ->filterByJob($jobs, Criteria::IN)
            ->filterBySource(JobCostTableMap::COL_SOURCE_AUTO, Criteria::EQUAL)
            ->orderByDevisOk()
            ->useCategoriePrestationQuery()
                ->orderByCategorie()
            ->endUse()
            ->find();

        foreach ($normalCostsItems as $normalItem) {
            $costItems[] = $normalItem;
        }
        foreach ($autoCostsItems as $autoItem) {
            $costItems[] = $autoItem;
        }

        $jobItems = JobItemQuery::create()
            ->filterByJob($jobs, Criteria::IN)
            ->orderByOrder()
            ->orderByGroup()
            ->orderByGroupTitle()
            ->orderBySuperGroup()
            ->orderBySuperGroupTitle()
            ->orderByDevisOk()
            ->useCategoriePrestationQuery()
                ->orderByCategorie()
            ->endUse()
            ->find();

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet()->setTitle('Budget Export');
        $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $this->setColumnWidth($sheet, ['A', 'B'], 23);
        $this->setColumnWidth($sheet, ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'], 17);
        $sheet->setCellValue('A1', 'Budget Export');
        $sheet->getStyle('A1')->getFont()->setBold(true);
        $sheet->getStyle('A1')->getFont()->setSize(15);

        $this->setCostAndBudgetDataCells($jobs, $jobItems, $sheet, 'budget export', $this->currency);

        $spreadsheet->createSheet(2)->setTitle('Cost export');
        $sheet = $spreadsheet->getSheetByName('Cost export');
        $sheet->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $this->setColumnWidth($sheet, ['A', 'B'], 23);
        $this->setColumnWidth($sheet, ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M'], 17);
        $sheet->setCellValue('A1', 'Cost Export');
        $sheet->getStyle('A1')->getFont()->setBold(true);
        $sheet->getStyle('A1')->getFont()->setSize(15);

        $this->setCostAndBudgetDataCells($jobs, $costItems, $sheet, 'cost export', $this->currency);

        $writer = new Xlsx($spreadsheet);
        $response = new StreamedResponse(
            function () use ($writer) {
                $writer->save('php://output');
            }
        );
        $response->headers->set('Content-Type', 'application/vnd.ms-excel');
        $response->headers->set('Content-Disposition', 'attachment;filename="cost-'.$etude->getId().'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');

        return $response;
    }

    private function setCostAndBudgetDataCells($jobs, $jobCostOrJobItem, $sheet, $exportType, $currency)
    {
        $cellLine = 2;

        foreach ($jobs as $job) {
            ++$cellLine;
            $sheet->setCellValue("A$cellLine", $job->getIdSamsJob());
            $sheet->getStyle("A$cellLine")->getFont()->setBold(true);
            $sheet->getStyle("A$cellLine")->getFont()->setSize(14);
            ++$cellLine;

            if ('cost export' == $exportType) {
                if (0 != count($jobCostOrJobItem)) {
                    ++$cellLine;
                    $this->setTitleSheet($sheet, "A$cellLine", 'Internal Cost - Not shared with client');
                    ++$cellLine;
                    $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                    $this->setTitleSheet($sheet, "B$cellLine", 'Category');
                    $this->setTitleSheet($sheet, "C$cellLine", 'Section');
                    $this->setTitleSheet($sheet, "D$cellLine", 'Qty');
                    $this->setTitleSheet($sheet, "E$cellLine", 'Unit');
                    $this->setTitleSheet($sheet, "F$cellLine", 'Title');
                    $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
                    $this->setTitleSheet($sheet, "J$cellLine", 'Price');
                    $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                    $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                    $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('EC1010');
                    ++$cellLine;
                    foreach ($jobCostOrJobItem as $costItem) {
                        if ($costItem->getJobId() == $job->getId()) {
                            $sheet->setCellValue("A$cellLine", $costItem->getMethodology());
                            $sheet->setCellValue("B$cellLine", $costItem->getCategoriePrestation() ? $costItem->getCategoriePrestation()->getConsolidation() : '');
                            $sheet->setCellValue("C$cellLine", $costItem->getCategoriePrestation() ? $costItem->getCategoriePrestation()->getCategory() : '');
                            $sheet->setCellValue("D$cellLine", $costItem->getQuantitePr());
                            $sheet->setCellValue("E$cellLine", $currency.' '.$costItem->getPrixVenteUnitaireLocation());
                            $sheet->setCellValue("F$cellLine", $costItem->getSousTypePrestation());
                            $sheet->setCellValue("G$cellLine", $costItem->getFournisseur() ? $costItem->getFournisseur()->getSociete() : '');
                            $sheet->setCellValue("J$cellLine", $currency.' '.$costItem->getPrixRevient());
                            $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                            ++$cellLine;
                        }
                    }
                    $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
                }
            } elseif ('budget export' == $exportType) {
                if (0 != count($jobCostOrJobItem)) {
                    ++$cellLine;
                    $this->setTitleSheet($sheet, "A$cellLine", 'Job Items Budget');
                    ++$cellLine;
                    $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
                    $this->setTitleSheet($sheet, "B$cellLine", 'Category');
                    $this->setTitleSheet($sheet, "C$cellLine", 'Section');
                    $this->setTitleSheet($sheet, "D$cellLine", 'Vendor');
                    $this->setTitleSheet($sheet, "E$cellLine", 'Resp. Location');
                    $this->setTitleSheet($sheet, "F$cellLine", 'Resp. Type');
                    $this->setTitleSheet($sheet, "G$cellLine", 'Title');
                    $this->setTitleSheet($sheet, "H$cellLine", 'Date');
                    $this->setTitleSheet($sheet, "I$cellLine", 'Selling Qty');
                    $this->setTitleSheet($sheet, "J$cellLine", 'Selling Unit');
                    $this->setTitleSheet($sheet, "K$cellLine", 'Selling MarkeUp');
                    $this->setTitleSheet($sheet, "L$cellLine", 'Selling Price');
                    $this->setTitleSheet($sheet, "M$cellLine", 'Cost Qty');
                    $this->setTitleSheet($sheet, "N$cellLine", 'Cost Unit');
                    $this->setTitleSheet($sheet, "O$cellLine", 'Social Rate');
                    $this->setTitleSheet($sheet, "P$cellLine", 'Cost Price');
                    $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P']);
                    $sheet->getStyle("P$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                    $sheet->getStyle("A$cellLine:H$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('EC1010');
                    $sheet->getStyle("I$cellLine:L$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('CFFED3');
                    $sheet->getStyle("M$cellLine:P$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFECA6');
                    ++$cellLine;
                    $defaultDateFmt = $this->getDefaultDateFmt();
                    foreach ($jobCostOrJobItem as $jobItem) {
                        if ($jobItem->getJobId() == $job->getId()) {
                            $sheet->setCellValue("A$cellLine", $jobItem->getMethodology());
                            $sheet->setCellValue("B$cellLine", $jobItem->getCategoriePrestation() ? $jobItem->getCategoriePrestation()->getConsolidation() : '');
                            $sheet->setCellValue("C$cellLine", $jobItem->getCategoriePrestation() ? $jobItem->getCategoriePrestation()->getCategory() : '');
                            $sheet->setCellValue("D$cellLine", $jobItem->getVendor() ? $jobItem->getVendor()->getFullnameOrCompany() : '');
                            $sheet->setCellValue("E$cellLine", $jobItem->getRespLocation() ? $jobItem->getRespLocation()->getValue() : '');
                            $sheet->setCellValue("F$cellLine", $jobItem->getRespondentType() ? $jobItem->getRespondentType()->getValue() : '');
                            $sheet->setCellValue("G$cellLine", $jobItem->getSousTypePrestation());
                            $sheet->setCellValue("H$cellLine", $jobItem->getDate($defaultDateFmt));
                            $sheet->setCellValue("I$cellLine", $jobItem->getQuantitePv());
                            $sheet->setCellValue("J$cellLine", $jobItem->getPrixVenteUnitaire());
                            $sheet->setCellValue("K$cellLine", $jobItem->getMarkup());
                            $sheet->setCellValue("L$cellLine", $currency.' '.$jobItem->getPrixVente());
                            $sheet->setCellValue("M$cellLine", $jobItem->getQuantitePr() ? $jobItem->getQuantitePr() : '');
                            $sheet->setCellValue("N$cellLine", $jobItem->getPrixRevientUnitaire() ? $jobItem->getPrixRevientUnitaire() : '');
                            $sheet->setCellValue("O$cellLine", $jobItem->getCoefficiantPr() ? $jobItem->getCoefficiantPr() : '');
                            $sheet->setCellValue("P$cellLine", $currency.' '.$jobItem->getPrixRevient());

                            $sheet->getStyle("P$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
                            ++$cellLine;
                        }
                    }
                    $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P']);
                }
            }
        }
    }

    private function setTitleSheet($sheet, $cell, $title)
    {
        $sheet->setCellValue($cell, $title);
        $sheet->getStyle($cell)->getFont()->setBold(true);

        return $sheet;
    }

    private function addJobItemsToSheet($sheet, $JobItems, $cellLine, $isMarkUp = false, $isStafing = false, $currency)
    {
        if ($isMarkUp) {
            $colH = 'Actual';
            $colI = 'Mark Up';
        } elseif ($isStafing) {
            $colH = 'Discount %';
            $colI = 'Exclude';
        } else {
            $colH = $colI = '';
        }
        $this->setTitleSheet($sheet, "A$cellLine", 'Methodology');
        $this->setTitleSheet($sheet, "B$cellLine", 'Category');
        $this->setTitleSheet($sheet, "C$cellLine", 'Section');
        $this->setTitleSheet($sheet, "D$cellLine", 'Qty');
        $this->setTitleSheet($sheet, "E$cellLine", 'Unit');
        $this->setTitleSheet($sheet, "F$cellLine", 'Title');
        $this->setTitleSheet($sheet, "G$cellLine", 'Vendor');
        $this->setTitleSheet($sheet, "H$cellLine", $colH);
        $this->setTitleSheet($sheet, "I$cellLine", $colI);
        $this->setTitleSheet($sheet, "J$cellLine", 'Price');
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);
        $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
        $sheet->getStyle("A$cellLine:J$cellLine")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('9BCC59');
        ++$cellLine;
        foreach ($JobItems as $JobItem) {
            $section = $JobItem->getCategoriePrestation() ? $JobItem->getCategoriePrestation()->getCategory() : '-';
            $category = $JobItem->getCategoriePrestation() ? $JobItem->getCategoriePrestation()->getConsolidation() : '-';

            $discountSign = 'Discounts' == $category ? '-' : '';
            $sheet->setCellValue("A$cellLine", $JobItem->getMethodology());
            $sheet->setCellValue("B$cellLine", $category);
            $sheet->setCellValue("C$cellLine", $section);
            $sheet->setCellValue("D$cellLine", $discountSign.$JobItem->getQuantitePv());
            $sheet->setCellValue("E$cellLine", $currency.' '.$JobItem->getPrixVenteUnitaire());
            $sheet->setCellValue("F$cellLine", $JobItem->getSousTypePrestation());
            $sheet->setCellValue("G$cellLine", $JobItem->getVendor() ? $JobItem->getVendor()->getSociete() : '');
            if ($isMarkUp) {
                $this->setTitleSheet($sheet, "H$cellLine", $currency.' '.($JobItem->getQuantitePv() * $JobItem->getPrixVenteUnitaire()));
                $this->setTitleSheet($sheet, "I$cellLine", ($JobItem->getMarkUp() ?: 1));
            } elseif ($isStafing) {
                $sheet->setCellValue("H$cellLine", $JobItem->getDiscountPercent());
                $sheet->setCellValue("I$cellLine", $JobItem->getDiscountExclude() ? 'Yes' : 'No');
            }
            $sheet->setCellValue("J$cellLine", $currency.' '.$JobItem->getPrixVente());
            $sheet->getStyle("J$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);

            ++$cellLine;
        }
        $this->addBorder($sheet, $cellLine, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']);

        return $cellLine;
    }

    private function startsWith($haystack, $needle)
    {
        $length = strlen($needle);

        return substr($haystack, 0, $length) === $needle;
    }

    private function addBorder($sheet, $cellLine, $rows)
    {
        foreach ($rows as $row) {
            $sheet->getStyle("$row$cellLine")->getBorders()->getTop()->setBorderStyle(Border::BORDER_THIN);
        }
    }

    private function setColumnWidth($sheet, $rows, $size)
    {
        foreach ($rows as $row) {
            $sheet->getColumnDimension($row)->setWidth($size);
        }
    }

    private function setRevenueTab($sheet, $cellLine, $title, $val1, $val2, $currency)
    {
        $this->setTitleSheet($sheet, "A$cellLine", $title);
        $sheet->setCellValue("B$cellLine", $currency.' '.number_format($val1, '2', '.', ''));
        $sheet->setCellValue("C$cellLine", $currency.' '.number_format($val2, '2', '.', ''));
        $sheet->getStyle("C$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    }

    private function setDiscountTab($sheet, $cellLine, $title, $val1, $val2, $val3)
    {
        $this->setTitleSheet($sheet, "A$cellLine", $title);
        $sheet->setCellValue("B$cellLine", $val1);
        $sheet->setCellValue("C$cellLine", $val2);
        $sheet->setCellValue("D$cellLine", $val3);
        $sheet->getStyle("D$cellLine")->getBorders()->getRight()->setBorderStyle(Border::BORDER_THIN);
    }

    /**
     * @Route(name="job_alert", path="/project/{sf_id}/job-alert")
     */
    public function jobAlertAction(Request $request, string $uploadDir, $getUploadDir): Response
    {
        ini_set('max_execution_time', '240');

        $etude = EtudeQuery::create()->filterByMasterProjectSfId($request->get('sf_id'))->findOne();
        if (!$etude) {
            $this->addFlash('warning', 'This Master Project not exist.');

            return $this->redirectToRoute('etude_recherche_index');
        }

        foreach ($etude->getJobEtudes() as $job) {
            foreach ($job->getEvents() as $event) {
                if (!$event->getSite() && !$event->getIsDeletedC() && 'Released' != $event->getRefEventStatus()->getName() && 'Cancelled non-Billed' != $event->getRefEventStatus()->getName()) {
                    $this->addFlash('danger', 'You need to define a site before creating job alert / job confirmation!!');

                    return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
                }
            }
        }
        $jobAlertType = false !== strpos($etude->getJobQualification()->getValue(), 'Quant') ? 'Quant' : 'Qual';

        $jobItems = JobItemQuery::create()
            ->filterByEtude($etude)
            ->filterByJobStatus(RefSalesForce::JOB_STATUSES_DOCUMENTS, Criteria::IN)
            ->useCategoriePrestationQuery()
                ->filterByConsolidation('Incentives', Criteria::NOT_EQUAL)
            ->endUse()
            ->orderByCategoriePrestationId()
            ->find();

        $jobServices = [];
        $servicesNames = [];
        $jobsComments = [];
        $jobs = [];

        // Active, Cancelled-billed, Confirmed and Closed
        foreach ($etude->getJobEtudes() as $job) {
            if (in_array($job->getStatus()->getValue(), RefSalesForce::JOB_STATUSES_DOCUMENTS)) {
                $jobs[] = $job;
                $comment = $job->getJobComments() ?? '';
                foreach ($job->getRefSalesForceJobRefServicess() as $ref) {
                    if ($ref->isActif()) {
                        $servicesNames[] = $ref->getValue();
                    }
                }
                $jobServices[] = ['job' => $job->getIdSamsJob(), 'services' => implode(', ', array_unique($servicesNames))];
                $jobsComments[] = ['job' => $job->getIdSamsJob(), 'comments' => $comment];
            }
        }

        $format = 'us' == $this->instance ? 'USLETTER' : 'A4';
        $html2pdf = new Html2Pdf('P', $format, 'fr', 'true', 'UTF-8', [0, 10, 0, 5]);
        $html2pdf->setDefaultFont('arial');
        $html2pdf->addFont('zapfdingbats', '', 14);
        $html2pdf->setTestTdInOnePage(false);

        //point to server path
        //sample plan
        $sample_plan = $etude->getSamplePlan() ?: '';
        $sample_plan = $this->pointToServerPathImage($sample_plan, $getUploadDir);

        //study specs
        $study_specs = $etude->getStudySpecification() ?: '';
        $study_specs = $this->pointToServerPathImage($study_specs, $getUploadDir);

        //additional notes
        $additional_notes = $etude->getAdditionalNotes() ?: '';
        $additional_notes = $this->pointToServerPathImage($additional_notes, $getUploadDir);

        //project comment
        $project_comment = $etude->getProjectComment() ?: '';
        $project_comment = $this->pointToServerPathImage($project_comment, $getUploadDir);

        $tpl = [
            'etude' => $etude,
            'accountManager' => $etude->getProjectAccountManager(),
            'incentiveJobItems' => $etude->getIncentivesForDocuments(),
            'source' => array_map('strtolower', $etude->getSampleSources()->toKeyValue('Id', 'Libelle')),
            'siteEvents' => $etude->getEventsForDocuments(),
            'JobItems' => $jobItems,
            'study_specification' => HTMLPurifier::cleanForPdf($study_specs),
            'additional_notes' => HtmlPurifier::cleanForPdf($additional_notes),
            'sample_plan' => HtmlPurifier::cleanForPdf($sample_plan),
            'project_comment' => HtmlPurifier::cleanForPdf($project_comment),
            'finalClientNumber' => $this->addSpacesInLongWords($etude->getReferenceClientWithNotLimitSize()),
            'finalTopic' => $this->addSpacesInLongWords($etude->getTheme()),
            'instance' => $this->instance,
        ];

        try {
            if ('Qual' == $jobAlertType) {
                return $this->render('pmtool/project/jobAlert.pdf.twig', $tpl);
            } elseif ('Quant' == $jobAlertType) {
                $tpl['jobs'] = $jobs;
                $tpl['jobServices'] = $jobServices;
                $tpl['jobsComments'] = $jobsComments;
                $html2pdf->writeHTML($this->renderTemplate('pmtool/project/quantJobAlert.pdf.twig', $tpl));
            }

            $pdfName = $etude->getNameForPDF('job-alert');
            $content = $html2pdf->output($this->clean($pdfName, '_').'.pdf', 'I');

            $response = new Response($content, 200, [
                'Content-Description' => 'PDF projet',
                'Content-Type' => 'application/pdf',
                'Content-Transfer-Encoding' => 'binary',
                'Expires' => '0',
                'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
                'Pragma' => 'public',
                'Content-Length' => strlen($content),
            ]);

            return $response->setCharset('UTF-8');
        } catch (Html2PdfException $e) {
            $html2pdf->clean();
            $formatter = new ExceptionFormatter($e);

            return new Response($formatter->getHtmlMessage());
        }
    }

    /**
     * Deletes Module lines according to selection.
     *
     * @Route(name="etude_delete_module_line", path="/etude/deleteModuleLine/{jobId}/{etudeid}")
     */
    public function deleteModuleLineAction(Request $request): Response
    {
        $jobId = $request->get('jobId');
        $etudeid = $request->get('etudeid');
        $mod = $request->get('moduleTraite'.$jobId);
        if (!$mod) {
            throw $this->createNotFoundException();
        }
        ModuleQuery::create()->filterBySamsModuleId('')->filterById($mod)->delete();

        return $this->redirect("/project/show/$etudeid#module");
    }

    /**
     * Fonction for autocomplete.
     *
     * @Route(name="etude_search_study_by_period", path="/etude/searchEtudeByPeriod")
     */
    public function searchEtudeByPeriodAction(Request $request): JsonResponse
    {
        $term = $request->get('term', '').'%';
        $response = [];
        $periodes = $this->query('SELECT distinct periode_cutoff FROM etude WHERE periode_cutoff LIKE ? GROUP BY periode_cutoff ORDER BY periode_cutoff DESC', [$term]);
        foreach ($periodes as $periode) {
            $id_etudes = [];
            // recherche des types de fournisseur associés aux fournisseurs
            $etudes = $this->query('SELECT id,numero_etude,theme FROM etude WHERE periode_cutoff = ? ORDER BY numero_etude', [$periode->periode_cutoff]);
            foreach ($etudes as $etude) {
                $id_etudes[$etude->id] = $etude->numero_etude.' - '.mb_substr($etude->theme, 0, 30);
            }
            $response[] = ['label' => $periode->periode_cutoff, 'etudes' => $id_etudes];
        }

        return $this->json($response);
    }

    /**
     * Function créant un master project consolidation
     * Function ajoutant des master project au master project consolidation existant.
     *
     * Si l'étude courante a un numero_etude de 6 caractères à l'appel de la fonction elle devient maître et se persiste dans la table etude_master
     * Une etude fille est créee en remplacement de l'étude courante avec les mêmes informations et un numéro d'étude incrémenté : -01, -02 ...
     * D'autres études filles peuvent êtes créees à partir des études filles déjà existantes.
     *
     * @Route(name="etude_make_study_slave", path="/etude/makeStudySlaved/{idEtude}/{numeroEtude}")
     */
    public function makeStudySlavedAction(Request $request): Response
    {
        $idEtude = $request->get('idEtude');
        $numeroEtude = $request->get('numeroEtude');

        // If numero_etude contain '-' the master project already contains slave master project(s)
        if (false === strpos($numeroEtude, '-')) {
            $this->query('INSERT INTO etude_master(
                          numero_etude,
                          reference_client,
                          theme,
                          date_debut,
                          date_fin,
                          annee,
                          account_id,
                          id_pm,
                          id_etape,
                          prix_revient_initial,
                          prix_revient_actualise,
                          prix_vente_initial,
                          prix_vente_actualise,
                          numero_facture,
                          date_envoi_facture,
                          date_reglement,
                          commentaire,
                          industry_id,
                          remise_taux,
                          periode_cutoff,
                          theme_br,
                          area_id,
                          id_qq,
                          id_sams_study,
                          language,
                          recrutement_objectif,
                          id_location_pnl,
                          recrutement_objectif_pr,
                          id_bm)
                        SELECT numero_etude,
                        reference_client,
                        theme,
                        date_debut,
                        date_fin,
                        annee,
                        account_id,
                        id_pm,
                        id_etape,
                        prix_revient_initial,
                        prix_revient_actualise,
                        prix_vente_initial,
                        prix_vente_actualise,
                        numero_facture,
                        date_envoi_facture,
                        date_reglement,
                        commentaire,
                        industry_id,
                        remise_taux,
                        periode_cutoff,
                        theme_br,
                        area_id,
                        job_qualification_id,
                        id_sams_study,
                        language,
                        recrutement_objectif,
                        id_location_pnl,
                        recrutement_objectif_pr,
                        id_bm
                        FROM etude
                        WHERE id = ?', [$idEtude]);
            $this->query('UPDATE etude SET numero_etude = ? WHERE id = ?', [$numeroEtude.'-01', $idEtude]);

            return $this->redirect("/project/show/$idEtude");
        }

        /* Logic to increment on numero_etude */
        $numero_etude_max = $this->query('SELECT MAX(numero_etude)AS dernier_numero FROM etude WHERE numero_etude
            LIKE ?', [$numeroEtude.'%']);
        $numeroEtudeLength = strlen($numero_etude_max[0]->dernier_numero);
        $numeroEtudeLengthMinus2Char = $numeroEtudeLength - 1;
        $dernier_indice = substr($numero_etude_max[0]->dernier_numero, $numeroEtudeLengthMinus2Char, 2);
        $prochain_indice = sprintf('%02d', $dernier_indice + 1);
        $prochain_numero_etude = substr($numeroEtude, 0, strpos($numeroEtude, '-')).'-'.$prochain_indice;

        $etudeData = $this->query('SELECT * FROM etude WHERE id = ?', [$idEtude]);
        $etude_a_copier = $etudeData[0];
        $etude = (new Etude())
            ->setNumeroEtude($prochain_numero_etude)
            ->setReferenceClient($etude_a_copier->reference_client)
            ->setTheme($etude_a_copier->theme)
            ->setDateDebut(date('Y-m-d'))
            ->setAnnee($etude_a_copier->annee)
            ->setIdPm($etude_a_copier->id_pm)
            ->setIdEtape(Etape::STUDY_CREATION)
            ->setCommentaire($etude_a_copier->commentaire)
            ->setIndustryId($etude_a_copier->industry_id)
            ->setRemiseTaux($etude_a_copier->remise_taux)
            ->setThemeBr($etude_a_copier->theme_br)
            ->setAreaId($etude_a_copier->area_id)
            ->setIdSamsStudy($etude_a_copier->id_sams_study)
            ->setLanguage($etude_a_copier->language)
            ->setKol($etude_a_copier->kol)
            ->setRoomRental($etude_a_copier->room_rental)
            ->setRecruitsOffsite($etude_a_copier->recruits_offsite)
            ->setEndClientId($etude_a_copier->end_client_id)
            ->setEndClientContactId($etude_a_copier->end_client_contact_id)
            ->setContactId($etude_a_copier->contact_id)
            ->setContactClientPmId($etude_a_copier->contact_client_pm_id)
            ->setRecrutementObjectif($etude_a_copier->recrutement_objectif)
            ->setIdLocationPnl($etude_a_copier->id_location_pnl)
            ->setRecrutementObjectifPr($etude_a_copier->recrutement_objectif_pr)
            ->setIdBm($etude_a_copier->id_bm)
            ->setExtraInfo($etude_a_copier->extra_info)
            ->setAccountId($etude_a_copier->account_id)
            ->setSmsRelance($etude_a_copier->sms_relance)
            ->setIdEtudeGroup($etude_a_copier->id_etude_group ?: null)
            ->setProposedLoi($etude_a_copier->proposed_loi)
            ->setOpportunityId(null)
            ->setSiJobTypeId($etude_a_copier->si_job_type_id)
            ->setBestEffort($etude_a_copier->best_effort)
            ->setJobStatusSfId($etude_a_copier->job_status_sf_id)
            ->setBookedBySfId($etude_a_copier->booked_by_sf_id)
            ->setCreatedBySfId($etude_a_copier->created_by_sf_id)
            ->setAccountManagerSfId($etude_a_copier->account_manager_sf_id)
            ->setCreatedDate($etude_a_copier->created_date)
            ->setJobQualificationId($etude_a_copier->job_qualification_id)
            ->setProposedN($etude_a_copier->proposed_n)
            ->setGermanJobTypeId($etude_a_copier->german_job_type_id);
        $etude->save();

        $newEtudeId = $etude->getId();

        $parentEtude = Etude::getById($idEtude);

        // Persist the mother sample source in daughter
        foreach ($parentEtude->getEtudeSampleSources() as $etudeSampleSource) {
            (new EtudeSampleSource())
                ->setEtudeId($newEtudeId)
                ->setSampleSourceId($etudeSampleSource->getSampleSourceId())
                ->save();
        }

        // Persist the mother methodologies in daughter
        foreach ($parentEtude->getEtudeMethodologies() as $etudeMethodologie) {
            (new EtudeMethodology())
                ->setEtudeId($newEtudeId)
                ->setMethodologyId($etudeMethodologie->getMethodologyId())
                ->save();
        }

        // Persist the mother sectors in daughter (respondent type category)
        foreach ($parentEtude->getSectors() as $etudeSector) {
            (new RefSalesForceEtudeSector())
                ->setEtudeId($newEtudeId)
                ->setRefSalesforceId($etudeSector->getRefSalesforceId())
                ->save();
        }

        $parentAccountDetail = ($parentEtude->getAccount() && $parentEtude->getAccount()->getAccountDetail()) ? $parentEtude->getAccount()->getAccountDetail() : null;

        $etude->setBm($parentEtude->getBm());
        $etude->setEndClient($parentEtude->getEndClient());
        $etude->setExtraInfo($parentEtude->getExtraInfo());
        $etude->setAccountPM($parentEtude->getAccountPM());
        $etude->setSamplePlan($parentEtude->getSamplePlan());
        $etude->setRoomRental($parentEtude->getRoomRental());
        $etude->setSunshineAct($parentEtude->getSunshineAct());
        $etude->setFocusVision($parentEtude->getFocusVision());
        $etude->setAccountLeader($parentEtude->getAccountLeader());
        $etude->setProjectComment($parentEtude->getProjectComment());
        $etude->setUsGlobalQualGms($parentEtude->getUsGlobalQualGms());
        $etude->setAdditionalNotes($parentEtude->getAdditionalNotes());
        $etude->setLengthOfInterview($parentEtude->getLengthOfInterview());
        $etude->setClientListDeletion($parentEtude->getClientListDeletion());
        $etude->setIntermediateClient($parentEtude->getIntermediateClient());
        $etude->setStudySpecification($parentEtude->getStudySpecification());
        $etude->setProjectAccountManager($parentEtude->getProjectAccountManager());
        $etude->setClientDiscountPercentage($parentEtude->getClientDiscountPercentage());
        $etude->setIntermediateClientContact($parentEtude->getIntermediateClientContact());
        $etude->setEndClientDiscountPercentage($parentEtude->getEndClientDiscountPercentage());
        $etude->save();

        $accountDetails = $etude->getAccount() ? $etude->getAccount()->getAccountDetail() : null;
        if ($accountDetails) {
            $accountDetails->setSpecialClientBillingInformation($parentAccountDetail ? $parentAccountDetail->getSpecialClientBillingInformation() : null);
            $accountDetails->setMostImportantCriteria($parentAccountDetail ? $parentAccountDetail->getMostImportantCriteria() : null);
            $accountDetails->save();
        }

        return $this->redirect("/project/show/$newEtudeId");
    }

    /**
     * @Route(name="upload_job_items", path="/project/{id}/upload-job-items")
     */
    public function uploadJobItemsAction(Request $request, Job $job, SpreadsheetManager $spreadsheetManager, JobImporter $jobImporter): Response
    {
        ini_set('memory_limit', '2G');
        ini_set('max_execution_time', '60');
        $uploadedFile = $request->files->get('fichier');
        $type = $request->get('act');

        if (!$uploadedFile) {
            $this->addFlash('warning', 'You have to upload a file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }
        $extension = (new SplFileInfo($uploadedFile->getClientOriginalName()))->getExtension();
        if ('xlsx' !== strtolower($extension)) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }

        try {
            $jobImporter->upload($job, true, $type, $uploadedFile, $spreadsheetManager);
        } catch (\InvalidArgumentException $e) {
            $this->addFlash('warning', 'This file cannot be imported. Check that its formulas do not refer to other files.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        } catch (Exception $e) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }

        return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
    }

    /**
     * @Route(name="upload_job_costs", path="/project/{id}/upload-job-costs")
     */
    public function uploadJobCostsAction(Request $request, Job $job, SpreadsheetManager $spreadsheetManager, JobImporter $jobImporter): Response
    {
        ini_set('memory_limit', '2G');
        ini_set('max_execution_time', '60');
        $uploadedFile = $request->files->get('fichier');
        $type = $request->get('act-costs');

        if (!$uploadedFile) {
            $this->addFlash('warning', 'You have to upload a file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }
        $extension = (new SplFileInfo($uploadedFile->getClientOriginalName()))->getExtension();
        if ('xlsx' !== strtolower($extension)) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }

        try {
            $jobImporter->upload($job, false, $type, $uploadedFile, $spreadsheetManager);
        } catch (\InvalidArgumentException $e) {
            $this->addFlash('warning', 'This file cannot be imported. Check that its formulas do not refer to other files.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        } catch (Exception $e) {
            $this->addFlash('warning', 'This file cannot be imported. Please upload an xlsx file.');

            return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
        }

        return $this->redirectToRoute('etude_show', ['id' => $job->getEtudeId()]);
    }

    /**
     * Returns Projects for imputation.
     *
     * @Route(name="etude_retrieve_study_for_ge", path="/etude/retrieveEtudeForGE")
     */
    public function retrieveEtudeForGEAction(Request $request): JsonResponse
    {
        $term = '%'.$request->get('term', '').'%';
        $response = [];
        $results = $this->query('SELECT id,numero_etude,theme FROM etude WHERE numero_etude LIKE ? OR theme LIKE ? ORDER BY numero_etude', [$term, $term]);
        foreach ($results as $result) {
            $response[] = ['id' => $result->id, 'label' => $result->numero_etude.' - '.$result->theme];
        }

        return $this->json($response);
    }

    /**
     * @Route(name="cancel_project", path="/project/{id}/cancel-project")
     */
    public function cancelProjectAction(Request $request, Etude $etude, SalesforceManager $sfManager): Response
    {
        $stepCancelled = Etape::get(Etape::CANCELLED);
        $etude->setEtape($stepCancelled);
        $etude->save();

        if ($response = $sfManager->updateProjectStatus($etude)) {
            $this->addFlash('warning', 'Salesforce answered for project status: '.$response);
        } elseif ($etude->getMasterProjectSfId()) {
            $this->addFlash('success', 'Project status updated in Salesforce');
        }

        $jobs = $etude->getJobEtudes();
        if (count($jobs)) {
            $statusCancelledNonBilled = RefSalesForceQuery::create()->filterByField('status_id')->filterByValue(RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED)->findOne();

            $statusEventCancelledNonBilled = RefEventStatusQuery::create()
                  ->select('id')->filterByName(RefEventStatus::CANCELLED_NON_BILLED)->findOne();
            foreach ($jobs as $job) {
                $job->setStatus($statusCancelledNonBilled)->save();
                $jobItems = $job->getJobItems();
                foreach ($jobItems as $jobItem) {
                    $jobItem->setQuantitePv(0);
                    $jobItem->setPrixVente(0);
                    $jobItem->save();
                }
                foreach ($job->getEvents() as $event) {
                    $event->setEventStatusId($statusEventCancelledNonBilled);
                    $event->save();
                }
            }
        }

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    /**
     * @Route(name="standby_project", path="/project/{id}/standby-project")
     */
    public function standbyProjectAction(Request $request, Etude $etude, SalesforceManager $sfManager): Response
    {
        $stepStandby = Etape::get(Etape::STANDBY);
        $etude->setEtape($stepStandby);
        $etude->save();

        $jobs = $etude->getJobEtudes();

        $statusEventOnHold = RefEventStatusQuery::create()
                ->select('id')
                 ->filterByName(RefEventStatus::ON_HOLD)->findOne();
        foreach ($jobs as $job) {
            foreach ($job->getEvents() as $event) {
                $event->setEventStatusId($statusEventOnHold);
                $event->save();
            }
        }

        if ($response = $sfManager->updateProjectStatus($etude)) {
            $this->addFlash('warning', 'Salesforce answered for project status: '.$response);
        } elseif ($etude->getMasterProjectSfId()) {
            $this->addFlash('success', 'Project status updated in Salesforce');
        }

        return $this->redirectToRoute('etude_show', ['id' => $etude->getId()]);
    }

    private function addSpacesInLongWords(string $sentence, int $length = 37): string
    {
        $sentenceWordsExploded = explode(' ', $sentence);
        $finalSentence = [];
        foreach ($sentenceWordsExploded as $word) {
            if (strlen($word) > 37) {
                $wordPart1 = substr($word, 0, $length);
                $wordPart2 = substr($word, $length);
                $finalSentence[] = $wordPart1;
                $finalSentence[] = $wordPart2;
            } else {
                $finalSentence[] = $word;
            }
        }

        return implode(' ', $finalSentence);
    }

    private function copyJobItems(int $fromJobId, Job $toJob, Etude $etude)
    {
        $fromCopyJob = null;
        foreach ($etude->getJobEtudes() as $job) {
            if ($job->getId() === $fromJobId) {
                $fromCopyJob = $job;
                break;
            }
        }
        if ($fromCopyJob) {
            foreach ($fromCopyJob->getJobItems() as $jobitem) {
                $newJobItem = new JobItem();
                $newJobItem->setJob($toJob);
                $newJobItem->setSfId($jobitem->getSfId());
                $newJobItem->setSfIgnore($jobitem->getSfIgnore());
                $newJobItem->setDevisOk($jobitem->getDevisOk());
                $newJobItem->setCategoriePrestationId($jobitem->getCategoriePrestationId());
                $newJobItem->setSousTypePrestation($jobitem->getSousTypePrestation());
                $newJobItem->setQuantitePr($jobitem->getQuantitePr());
                $newJobItem->setCoefficiantPr($jobitem->getCoefficiantPr());
                $newJobItem->setPrixRevientUnitaire($jobitem->getPrixRevientUnitaire());
                $newJobItem->setPrixRevient($jobitem->getPrixRevient());
                $newJobItem->setQuantitePv($jobitem->getQuantitePv());
                $newJobItem->setPrixVenteUnitaireLocation($jobitem->getPrixVenteUnitaireLocation());
                $newJobItem->setPrixVenteUnitaire($jobitem->getPrixVenteUnitaire());
                $newJobItem->setPrixVente($jobitem->getPrixVente());
                $newJobItem->setFournisseur($jobitem->getFournisseur());
                $newJobItem->setPaye($jobitem->getPaye());
                $newJobItem->setCommentPm($jobitem->getCommentPm());
                $newJobItem->setDateCreation($jobitem->getDateCreation());
                $newJobItem->setHeureCreation($jobitem->getHeureCreation());
                $newJobItem->setDateLog($jobitem->getDateLog());
                $newJobItem->setUserLogId($jobitem->getUserLogId());
                $newJobItem->setEtapeLogId($jobitem->getEtapeLogId());
                $newJobItem->setDiscountComment($jobitem->getDiscountComment());
                $newJobItem->setDiscountPercent($jobitem->getDiscountPercent());
                $newJobItem->setDiscountExclude($jobitem->getDiscountExclude());
                $newJobItem->setDiscountAuto($jobitem->getDiscountAuto());
                $newJobItem->setDate($jobitem->getDate());
                $newJobItem->setOrder($jobitem->getOrder());
                $newJobItem->setGroup($jobitem->getGroup());
                $newJobItem->setGroupTitle($jobitem->getGroupTitle());
                $newJobItem->setSuperGroup($jobitem->getSuperGroup());
                $newJobItem->setSuperGroupTitle($jobitem->getSuperGroupTitle());
                $newJobItem->setApiExposedAt($jobitem->getApiExposedAt());
                $newJobItem->setDownPayment($jobitem->getDownPayment());
                $newJobItem->setUnit($jobitem->getUnit());
                $newJobItem->setDateFactureFnr($jobitem->getDateFactureFnr());
                $newJobItem->setRefFactureFnr($jobitem->getRefFactureFnr());
                $newJobItem->setRefFactureInt($jobitem->getRefFactureInt());
                $newJobItem->setCommentFnr($jobitem->getCommentFnr());
                $newJobItem->setIdFichiers($jobitem->getIdFichiers());
                $newJobItem->setMarkup($jobitem->getMarkup());
                $newJobItem->setSamsId(null);
                $newJobItem->setPmtoolUpdated($jobitem->getPmtoolUpdated());
                $newJobItem->setVendorId($jobitem->getVendorId());
                $newJobItem->setRespLocationId($jobitem->getRespLocationId());
                $newJobItem->setRespondentTypeId($jobitem->getRespondentTypeId());
                $newJobItem->setMethodologyId($jobitem->getMethodologyId());
                $newJobItem->setCreatedAt($jobitem->getCreatedAt());
                $newJobItem->setUpdatedAt($jobitem->getUpdatedAt());
                $newJobItem->save();
            }
        }
    }

    private function clean($name, $spaceSeparatorHyphenOrUnderscore = '-'): string
    {
        setlocale(LC_CTYPE, 'C.UTF-8');
        $name = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name);
        $name = str_replace(' ', $spaceSeparatorHyphenOrUnderscore, $name); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-_]/', '', $name); // Removes special chars.
    }

    /**
     * @Route(name="pm_email_defintion", path="/project/{id}/pm/email", defaults={"id": ""})
     */
    public function pmEmailDefintion(Etude $etude, MailManager $mailManager, Request $request, string $mailAttachmentDir)
    {
        $pmUsers = $request->get('pm_users');
        $additionalComment = $request->get('additional_comment');
        $attachments = $request->files->get('attachment');
        $etudeId = $etude->getid();
        $attachmentPathName = null;
        $subject = $etude->getTheme();
        $client = $etude->getAccount()->getName();
        $sfMasterProjectNumber = $etude->getMasterProjectNumber();
        $url = $this->generateUrl('etude_show', ['id' => $etude->getId()], UrlGeneratorInterface::ABSOLUTE_URL);

        $masterPmUser = $etude->getEtudeProjectManager();
        $masterPmUserName = $masterPmUser->getPrenom().' '.$masterPmUser->getNom();

        $senderEmail = $this->getUser()->getMail();

        if (empty($pmUsers)) {
            $this->addFlash('danger', 'Please select a User!');

            return $this->redirectToRoute('etude_show', ['id' => $etudeId]);
        }

        $users = UserQuery::create()
             ->filterById($pmUsers)
             ->find();

        if (empty($additionalComment)) {
            $this->addFlash('danger', 'Please Enter Additional Comment!');

            return $this->redirectToRoute('etude_show', ['id' => $etudeId]);
        }

        $attachmentPathName = [];

        if ($attachments) {
            foreach ($attachments as $attachment) {
                $orginalName = $attachment->getClientOriginalName();
                $attachmentPathName[] = $mailAttachmentDir.$orginalName;
                try {
                    $attachment->move($mailAttachmentDir, $orginalName);
                } catch (\Exception $e) {
                    $this->addFlash('danger', $e->getMessage());

                    return $this->redirectToRoute('etude_show', ['id' => $etudeId]);
                }
            }
        }

        $mailManager->sendPmDefinitionMail($etude, $users, $client, $sfMasterProjectNumber, $url, $additionalComment, $attachmentPathName, $subject, $senderEmail);

        foreach ($users as $user) {
            (new LogProjectStatus())
            ->setEtude($etude)
            ->setStatus('PM Definition Mail Sent to '.$user->getPrenom().''.$user->getNom())
            ->setDate(new DateTime())
            ->setUser($this->getUser())
            ->save();
        }

        $this->addFlash('success', 'PM definition Mail sent Successfully!');

        return $this->redirectToRoute('etude_show', ['id' => $etudeId]);
    }

    /**
     * @Route(name="job_items_copy", path="/project/{id}/copy/job/items")
     */
    public function jobItemsCopy(Request $request, Job $toJob, Etude $etude)
    {
        $jobItemIds = $request->get('job_item');
        $copyJobId = $request->get('location_id');
        $currentJobId = $request->get('current_location_id');

        if (!empty($jobItemIds) && !empty($copyJobId)) {
            try {
                $fromCopyJob = null;
                $toCopyJob = null;
                foreach ($etude->getJobEtudes() as $job) {
                    if ($job->getId() == $currentJobId) {
                        $fromCopyJob = $job;
                        break;
                    }
                }

                foreach ($etude->getJobEtudes() as $job) {
                    if ($job->getId() == $copyJobId) {
                        $toCopyJob = $job;
                        break;
                    }
                }

                if ($fromCopyJob) {
                    foreach ($fromCopyJob->getJobItems() as $jobitem) {
                        if (in_array($jobitem->getId(), $jobItemIds)) {
                            $newJobItem = new JobItem();
                            $newJobItem->setJob($toCopyJob);
                            $newJobItem->setSfId($jobitem->getSfId());
                            $newJobItem->setSfIgnore($jobitem->getSfIgnore());
                            $newJobItem->setDevisOk($jobitem->getDevisOk());
                            $newJobItem->setCategoriePrestationId($jobitem->getCategoriePrestationId());
                            $newJobItem->setSousTypePrestation($jobitem->getSousTypePrestation());
                            $newJobItem->setQuantitePr($jobitem->getQuantitePr());
                            $newJobItem->setCoefficiantPr($jobitem->getCoefficiantPr());
                            $newJobItem->setPrixRevientUnitaire($jobitem->getPrixRevientUnitaire());
                            $newJobItem->setPrixRevient($jobitem->getPrixRevient());
                            $newJobItem->setQuantitePv($jobitem->getQuantitePv());
                            $newJobItem->setPrixVenteUnitaireLocation($jobitem->getPrixVenteUnitaireLocation());
                            $newJobItem->setPrixVenteUnitaire($jobitem->getPrixVenteUnitaire());
                            $newJobItem->setPrixVente($jobitem->getPrixVente());
                            $newJobItem->setFournisseur($jobitem->getFournisseur());
                            $newJobItem->setPaye($jobitem->getPaye());
                            $newJobItem->setCommentPm($jobitem->getCommentPm());
                            $newJobItem->setDateCreation($jobitem->getDateCreation());
                            $newJobItem->setHeureCreation($jobitem->getHeureCreation());
                            $newJobItem->setDateLog($jobitem->getDateLog());
                            $newJobItem->setUserLogId($jobitem->getUserLogId());
                            $newJobItem->setEtapeLogId($jobitem->getEtapeLogId());
                            $newJobItem->setDiscountComment($jobitem->getDiscountComment());
                            $newJobItem->setDiscountPercent($jobitem->getDiscountPercent());
                            $newJobItem->setDiscountExclude($jobitem->getDiscountExclude());
                            $newJobItem->setDiscountAuto($jobitem->getDiscountAuto());
                            $newJobItem->setDate($jobitem->getDate());
                            $newJobItem->setOrder($jobitem->getOrder());
                            $newJobItem->setGroup($jobitem->getGroup());
                            $newJobItem->setGroupTitle($jobitem->getGroupTitle());
                            $newJobItem->setSuperGroup($jobitem->getSuperGroup());
                            $newJobItem->setSuperGroupTitle($jobitem->getSuperGroupTitle());
                            $newJobItem->setApiExposedAt($jobitem->getApiExposedAt());
                            $newJobItem->setDownPayment($jobitem->getDownPayment());
                            $newJobItem->setUnit($jobitem->getUnit());
                            $newJobItem->setDateFactureFnr($jobitem->getDateFactureFnr());
                            $newJobItem->setRefFactureFnr($jobitem->getRefFactureFnr());
                            $newJobItem->setRefFactureInt($jobitem->getRefFactureInt());
                            $newJobItem->setCommentFnr($jobitem->getCommentFnr());
                            $newJobItem->setIdFichiers($jobitem->getIdFichiers());
                            $newJobItem->setMarkup($jobitem->getMarkup());
                            $newJobItem->setSamsId(null);
                            $newJobItem->setPmtoolUpdated($jobitem->getPmtoolUpdated());
                            $newJobItem->setVendorId($jobitem->getVendorId());
                            $newJobItem->setRespLocationId($jobitem->getRespLocationId());
                            $newJobItem->setRespondentTypeId($jobitem->getRespondentTypeId());
                            $newJobItem->setMethodologyId($jobitem->getMethodologyId());
                            $newJobItem->setCreatedAt($jobitem->getCreatedAt());
                            $newJobItem->setUpdatedAt($jobitem->getUpdatedAt());
                            $newJobItem->save();
                        }
                    }
                }

                return new JsonResponse([
                'success' => true,
                'data' => 'copy job items successfully',
            ]);
            } catch (\Exception $exception) {
                return new JsonResponse([
                'success' => false,
                'code' => $exception->getCode(),
                'message' => $exception->getMessage(),
            ]);
            }
        }
    }
}
