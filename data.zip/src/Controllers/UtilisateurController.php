<?php

namespace Controllers;

use Model\Fournisseur;
use Model\Groupe;
use Model\Location;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UtilisateurController extends BaseController
{
    /**
     * @Route(name="user", path="/utilisateur")
     */
    public function indexAction(Request $request): Response
    {
        $rechercheUtilisateurs = '';

        return $this->render('pmtool/pages/utilisateur.html.twig', [
            'rechercheUtilisateurs' => $rechercheUtilisateurs,
            'param' => '',
        ]);
    }

    /**
     * @Route(name="user_results", path="/utilisateur/results")
     */
    public function resultsAction(Request $request): JsonResponse
    {
        $sortHeader = ['statut', 'nom', 'prenom', 'mail', 'id_groupe', 'is_seller'];

        $datagridIndex = '0';
        $sortColumnParameter = $request->get('iSortCol_'.$datagridIndex);
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[1];
        $sortDirection = $request->get('sSortDir_'.$datagridIndex, 'desc');
        $displayPerPage = $request->get('iDisplayLength', 50);
        $start = $request->get('iDisplayStart', 0);
        $currentPage = $request->get('sEcho', 1);
        $searchTerm = $request->get('sSearch', null);

        // FIXME SQL injections

        $queryConditions = 'FROM user ';

        if ($searchTerm) {
            $con = Propel::getConnection();
            $searchTerm = $con->quote('%'.$searchTerm.'%');
            $searchCriteria = [
                ' nom LIKE '.$searchTerm,
                ' prenom LIKE '.$searchTerm,
                ' mail LIKE '.$searchTerm,
                ' id_groupe LIKE '.$searchTerm,
            ];
            $queryConditions = $queryConditions.' WHERE '.implode(' OR ', $searchCriteria);
        }

        $nbResults = $this->query('SELECT count(*) as nbResults '.$queryConditions);
        $rechercheUtilisateurs = $this->query('
            SELECT user.id AS id_user,
            id_groupe,
            id_coordinateur,
            id_location_pr,
            fournisseur_id,
            employe,
            nom,
            prenom,
            statut,
            mail,
            is_seller '.$queryConditions.' ORDER BY '.$sortColumn.' '.$sortDirection.' LIMIT '.$start.','.$displayPerPage);
        $totalRecords = isset($nbResults[0]) ? (int) $nbResults[0]->nbResults : 0;

        $results = [];
        $results['sEcho'] = $currentPage;

        $results['iTotalRecords'] = $totalRecords;
        $results['iTotalDisplayRecords'] = $totalRecords;

        // Recherche de définitions
        $statuts = ['A' => 'Active', 'E' => 'Out', 'V' => 'Violation'];
        $employes = ['Y' => 'Yes', 'N' => 'No'];

        foreach ($rechercheUtilisateurs as $rechercheUtilisateur) {
            $fournisseur = Fournisseur::getById($rechercheUtilisateur->fournisseur_id);
            $tmpRow = [];
            $tmpRow[] = '<span data-id="'.$rechercheUtilisateur->id_user.'">'.$statuts[$rechercheUtilisateur->statut].'</span>';
            $tmpRow[] = mb_convert_case($rechercheUtilisateur->nom, MB_CASE_TITLE, 'UTF-8');
            $tmpRow[] = $rechercheUtilisateur->prenom;
            $tmpRow[] = $rechercheUtilisateur->mail;
            $tmpRow[] = Groupe::getById($rechercheUtilisateur->id_groupe) ? Groupe::getById($rechercheUtilisateur->id_groupe)->getGroupe() : '';
            $tmpRow[] = $rechercheUtilisateur->is_seller ? 'Yes' : 'No';
            $tmpRow[] = Location::getNomLocation($rechercheUtilisateur->id_location_pr);
            $tmpRow[] = $fournisseur ? $fournisseur->getNomComplet() : '';
            $tmpRow[] = isset($employes[$rechercheUtilisateur->employe]) ? $employes[$rechercheUtilisateur->employe] : '';
            $results['aaData'][] = $tmpRow;
        }

        return $this->json($results);
    }
}
