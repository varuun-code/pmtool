<?php

namespace Controllers;

use Exception;
use Manager\MailManager;
use Model\CategoriePrestation;
use Model\DureeQuery;
use Model\EtudeQuery;
use Model\Event;
use Model\EventMethodologyQuery;
use Model\EventQuery;
use Model\FournisseurQuery;
use Model\JobQuery;
use Model\Module;
use Model\ModuleFournisseur;
use Model\ModuleFournisseurQuery;
use Model\ModuleQuery;
use Model\QuotaQuery;
use Model\RefRoomQuery;
use Model\Repondant;
use Model\RepondantQuery;
use Model\Site;
use Model\SiteQuery;
use Model\Ville;
use Model\VilleQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ApiController extends BaseController
{
    /**
     * @Route(name="module_sams_api", path="/api/process/{user}/{password}")
     */
    public function processAction(Request $request, MailManager $mailManager, string $samsManager): Response
    {
        $separator = true;
        try {
            if ('PUT' == $request->getMethod()) {
                $content = $request->getContent();
                $data = json_decode($content, true) ?: [];
                $this->logUpdate($content);
                $separator = false;
                if ($data) {
                    $this->insertOrUpdateEvenement($data, $mailManager, $samsManager);

                    return $this->json(['status' => 'ok']);
                } else {
                    return $this->json(['status' => 'ko', 'reason' => 'Invalid JSON'], 400);
                }
            }
            $this->logUpdate('Exception Rest Is Not PUT');

            return $this->json(['status' => 'ko'], 405);
        } catch (Exception $e) {
            $this->logUpdate($e->getMessage(), $separator);

            return $this->json(['status' => 'ko', 'error' => $e->getMessage()], 500);
        }
    }

    private function sendEmail($message, MailManager $mailManager, string $samsManager): void
    {
        $objet = 'Schmiedl - Interface error SAMS';

        $mailManager->send($samsManager, [], [], $objet, $message);
    }

    private function insertOrUpdateEvenement(array $data, MailManager $mailManager, string $samsManager)
    {
        $dateCreation = date('Y-m-d');
        $heureCreation = date('H:i:s');
        $samsDate = isset($data['sams_date']) ? str_replace(['/', '.'], '-', $data['sams_date']) : null;         // Traitement de la date de l'évènement
        $samsStartTime = $data['sams_start_time'];                                                               // Traitement de l'heure de début
        $samsIncentive = (float) $data['sams_incentive'];                                                        // Traitement de l'incentive
        $samsRepondentAppointmentConfirmation = $data['sams_repondent_appointment_confirmation'];                // Traitement de la confirmation
        $samsRepondentConfirmationDate = str_replace(['/', '.'], '-', $data['sams_repondent_confirmation_date']); // Date de confirmation du RDV
        $samsEventId = $data['sams_event_id'];                                                                   // Id de l'évènement - information Sams
        $samsModuleId = $data['sams_module_id'];                                                                 // Id du module - information Sams
        $roomName = $data['sams_room'];                                                                          // Traitement de la room
        $samsJobNumber = $data['sams_study_number'];                                                             // Traitement des sams job number ex : 'MUC17800259'
        $repondantId = $this->insertOrUpdateRepondant($data);                                                    // Traitement du répondant
        $annule = $data['sams_event_cancelled'] ? 'O' : 'N';                                                     // Traitement de l'annulation
        $samsParticipationStatus = $data['sams_participation_status'];                                           // Statut SAMS de la participation - information Sams
        $duree = DureeQuery::create()->findOneByDureenum($data['sams_duration']) ?: null;                        // Traitement de l'heure de la durée
        $confirmationId = $samsRepondentAppointmentConfirmation ? 3 : null;                                      // Traitement de l'appointmentConfirmation
        $quota = QuotaQuery::create()->findOneByQuota($data['sams_repondent_quota']) ?: null;                    // Traitement de l'id quota
        $samsLocation = $data['sams_location'] ? $data['sams_location'] : '';                                    // Traitement des locations
        $samsMethodology = $data['sams_study_type'] ? $data['sams_study_type'] : '';                             // Traitement des méthodologies
        $methodology = EventMethodologyQuery::create()->findOneBySamsLabel($samsMethodology);
        $samsRecruiterId = $data['sams_recruiter_id'] ?? null;
        $samsConsumedStudyNumber = $data['sams_consumed_study_number'];
        $samsDateConsent = $data['sams_date_consent'] ?? null;
        $samsHomeworkReceived = (bool) ($data['sams_homework_received'] ?? false);
        $samsNDAReceived = (bool) ($data['sams_NDA_received'] ?? false);
        $samsConfirmerId = $data['sams_confirmer_id'] ?? null;

        $site = SiteQuery::create()->findOneBySamsLocation($samsLocation);
        if (!$site) {
            $site = new Site();
            $site->setSamsLocation($samsLocation);
            $site->save();
        }

        $job = JobQuery::create()->findOneByIdSamsJob($samsJobNumber);
        if (!$job) {
            $texte = "Could not find job $samsJobNumber";
            $this->logUpdate($texte, false);
            $this->sendEmail($texte, $mailManager, $samsManager);

            return;
        }

        // Recherche si l'étude existe // ils souhaitent ce log là mais aucun sens étant donné qu'aucun test ne se fait en fonction de l'étude.
        $etude = EtudeQuery::create()->findOneByNumeroEtude($samsConsumedStudyNumber);
        if (!$etude) {
            $texte = "Could not find master project {$samsConsumedStudyNumber}";
            $this->logUpdate($texte, false);

            return;
        }

        // Recherche si l'évènement existe
        $event = EventQuery::create()->findOneBySamsEventId($samsEventId);
        if (!$event) {
            $event = EventQuery::create()->filterByJob($job)->filterByEventMethodologyId(null, Criteria::ISNULL)->findOne();
            if ($event) {
                $event->setSamsEventId($samsEventId);
            }
        }
        if (!$event) {
            $event = (new Event())
                ->setJob($job)
                ->setSamsEventId($samsEventId)
                ->setComments('Created by SAMS API on '.date('Y-m-d'));
        }
        $room = RefRoomQuery::create()->filterByLocation($job->getJobLocation())->filterByName($roomName)->findOne();
        $event->setDate($samsDate)
            ->setEventMethodology($methodology)
            ->setRefRoom($room);
        $event->save();

        $module = ModuleQuery::create()->findOneBySamsModuleId($samsModuleId);

        $log = 'Updated ';
        if (!$module) {
            // per #12337 we do not import new modules that are canceled in SAMS (but we update the existing ones)
            if ('O' == $annule) {
                return;
            }

            $module = (new Module())
                ->setEventId($event->getId())
                ->setSamsCreatedAt(new \DateTime())
                ->setSamsModuleId($samsModuleId)
                ->setPaiement($etude->getModulePaymentDefaultValue($this->instance))
                ->setDateCreation($dateCreation)
                ->setHeureCreation($heureCreation);
            $log = 'Created ';
        }

        $module->setDate($samsDate);
        $module->setEventId($event->getId());
        // NB: SAMS should NOT overwrite existing values with empty values!
        if ($duree) {
            $module->setDuree($duree);
        }
        if ($samsStartTime) {
            $module->setDebut($samsStartTime);
        }
        if ($samsIncentive) {
            $module->setIncentive($samsIncentive);
        }
        if ($confirmationId) {
            $module->setConfirmationId($confirmationId);
        }
        if ($samsRepondentConfirmationDate) {
            $module->setDateConfirmation($samsRepondentConfirmationDate);
        }
        if ($annule) {
            $module->setAnnule($annule);
        }
        if ($quota) {
            $module->setQuota($quota);
        }
        if ($site) {
            $module->setSite($site);
        }
        // if check was emitted, we cannot change respondent
        if ($repondantId && !$module->getNoCheque()) {
            $module->setRepondantId($repondantId);
        }
        if ($samsParticipationStatus) {
            $samsStatus = null;
            if (in_array($samsParticipationStatus, Module::OK)) {
                $samsStatus = 'OK';
            } elseif (in_array($samsParticipationStatus, Module::OTHER)) {
                $samsStatus = 'Other';
            } elseif (in_array($samsParticipationStatus, Module::MISRECRUITMENT)) {
                $samsStatus = 'Misrecruitment';
            } elseif (in_array($samsParticipationStatus, Module::NO_SHOW)) {
                $samsStatus = 'No Show';
            }
            $module->setSamsParticipationStatus($samsParticipationStatus);
            $module->setStatus($samsStatus);
        }
        if ($samsDateConsent) {
            $module->setDateGdprConsent($samsDateConsent);
        }
        if ($samsHomeworkReceived) {
            $module->setHomeworkReceived($samsHomeworkReceived);
        }
        if ($samsNDAReceived) {
            $module->setNDAReceived($samsNDAReceived);
        }

        $module->save();
        $job->synchroModuleCosts();

        // Création d'un module Fournisseur sans coût afin de lier un module et son recruiter
        $moduleFournisseur = ModuleFournisseurQuery::create()->findOneByModuleId($module->getId());
        $fournisseur = FournisseurQuery::create()->findOneByIdSams($samsRecruiterId);
        if ('fr' == $this->instance) {
            $fournisseurId = $fournisseur ? $fournisseur->getId() : 377; // FIXME Si le fournisseur a un id_sams, sinon on met l'id 377 Thierry RAZZA - Phone Room
        } elseif ('de' == $this->instance) {
            $fournisseurId = $fournisseur ? $fournisseur->getId() : 2814; // FIXME
        } else { // es/uk/us
            $fournisseurId = $fournisseur ? $fournisseur->getId() : 5;
        }

        $fournisseurConfirmer = $samsConfirmerId ? FournisseurQuery::create()->findOneByIdSams($samsConfirmerId) : null;
        if ('fr' == $this->instance) {
            $fournisseurConfirmerId = $fournisseurConfirmer ? $fournisseurConfirmer->getId() : 377; // FIXME Si le fournisseur a un id_sams, sinon on met l'id 377 Thierry RAZZA - Phone Room
        } elseif ('de' == $this->instance) {
            $fournisseurConfirmerId = $fournisseurConfirmer ? $fournisseurConfirmer->getId() : 2814; // FIXME
        } else { // es/uk/us
            $fournisseurConfirmerId = $fournisseurConfirmer ? $fournisseurConfirmer->getId() : 5;
        }

        if (!$moduleFournisseur) {
            $recruitment = CategoriePrestation::getRecruitment();
            $moduleFournisseur = new ModuleFournisseur();
            $moduleFournisseur->setModuleId($module->getId());
            $moduleFournisseur->setCategoriePrestation($recruitment);
            $moduleFournisseur->setFournisseurId($fournisseurId);
            $moduleFournisseur->setFournisseurConfirmerId($fournisseurConfirmerId);
            $moduleFournisseur->save();
        } else {
            $moduleFournisseur->setFournisseurId($fournisseurId);
            $moduleFournisseur->setFournisseurConfirmerId($fournisseurConfirmerId);
            $moduleFournisseur->save();
        }

        $log .= 'module '.$module->getId();
        $this->logUpdate($log, false);
    }

    /**
     * @return mixed
     */
    private function insertOrUpdateRepondant(array $data)
    {
        $log = '';
        // récupération des données répondant
        $nom = addslashes(strtoupper(trim($data['sams_repondent_last_name'])));
        $prenom = addslashes(mb_convert_case(trim($data['sams_repondent_first_name']), MB_CASE_TITLE, 'UTF-8'));
        $telephone = trim($data['sams_repondent_fixed_line_number']);
        $portable = trim($data['sams_repondent_mobile_phone']);
        $sams_respondent_id = trim($data['sams_respondent_id']);
        $practiceType = $data['practice_type'] ?? null;

        if (10 == strlen($telephone)) {
            $telephone = chunk_split($telephone, 2, ' ');
        }
        if (10 == strlen($portable)) {
            $portable = chunk_split($portable, 2, ' ');
        }

        $adresse = addslashes(mb_strtoupper(trim($data['sams_repondent_adress']), 'UTF-8'));
        $email = strtolower(trim($data['sams_repondent_email']));
        $code_postal = trim($data['sams_repondent_city_code']);
        $ville_name = trim($data['sams_repondent_city_name']);
        $sams_bic = isset($data['sams_DE_BIC']) ? trim($data['sams_DE_BIC']) : null;
        $sams_iban = isset($data['sams_DE_IBAN']) ? trim($data['sams_DE_IBAN']) : null;
        $sams_kontoinhaber = isset($data['sams_DE_Kontoinhaber']) ? trim($data['sams_DE_Kontoinhaber']) : null;
        $sams_hcp_id = isset($data['sams_HCP_ID']) ? trim($data['sams_HCP_ID']) : null;
        $id_ville = $code_postal ? $this->getIdVille($code_postal, $ville_name) : null;

        if ($sams_respondent_id) {
            $respondent = RepondantQuery::create()->findOneBySamsRepondantId($sams_respondent_id);
        } else {
            $respondent = repondant::findOneOrCreate($prenom, $nom, $email, '', $telephone, $portable);
            if (!$respondent->getId()) {
                $respondent = null;
            }
        }

        if (!$respondent) {
            if (!$id_ville) {
                $log .= "Error - No city found with the city code $code_postal";
                $this->logUpdate($log, false);
            }
            $respondent = (new Repondant());
        }
        $respondent->setNom($nom)
            ->setPrenom($prenom)
            ->setTel($telephone)
            ->setPortable($portable)
            ->setAdresse($adresse)
            ->setIdVille($id_ville)
            ->setEmail($email)
            ->setActive('Y')
            ->setNotes($log)
            ->setSamsRepondantId($sams_respondent_id);

        if ('de' == $this->instance) {
            if ($sams_bic) {
                $respondent->setBic($sams_bic);
            }
            if ($sams_iban) {
                $respondent->setIban($sams_iban);
            }
            if ($sams_kontoinhaber) {
                $respondent->setKontoinhaber($sams_kontoinhaber);
            }
        }
        if ($sams_hcp_id) {
            $respondent->setNoRpps($sams_hcp_id);
        }
        if ($practiceType && in_array($practiceType, array_keys(Repondant::PRACTICE_TYPES))) {
            $respondent->setPracticeType($practiceType);
        }
        $respondent->save();

        return $respondent->getId();
    }

    /**
     * Renvoie l'id et le nombre de ville à partir du CP.
     */
    private function getIdVille(string $cp, string $ville_name): int
    {
        $ville = VilleQuery::create()->filterByCp($cp)->filterByVille($ville_name)->findOne();

        if ($ville) {
            return $ville->getId();
        }

        $ville = (new Ville())
            ->setCp($cp)
            ->setVille($ville_name);
        $ville->save();

        return $ville->getId();
    }

    /**
     * Write logs.
     */
    private function logUpdate(string $texte, $writeSeparator = true)
    {
        $filename = '../var/logs/api-'.date('Ymd').'.log';
        $maj = $writeSeparator ? ("\n\n".'// ====== Mise à jour du '.date('d/m/Y H:i:s')) : '';
        $maj .= "\n".$texte;
        file_put_contents($filename, $maj, FILE_APPEND | LOCK_EX);
    }
}
