<?php

namespace Controllers;

use Model\Etape;
use Model\Job;
use Model\Location;
use Model\RefSalesForceQuery;
use PDO;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;

class AccountingController extends BaseController
{
    /**
     * @Route(name="etude_recherche_acct", path="/accountingReport/index/{param}", defaults={"param": ""})
     */
    public function indexAction(Request $request): Response
    {
        return $this->render('pmtool/pages/accounting.html.twig', [
            'filter' => $request->get('param'),
            'group' => 0,
        ]);
    }

    /**
     * @Route(name="etude_resultats_acct", path="/accountingReport/{group}/results/{year}", defaults={"year": ""})
     * @Route(name="etude_resultats_acct_group", path="/accountingReport/{id}/results/")
     */
    public function resultsAction(Request $request): JsonResponse
    {
        $sortHeader = [
            'am',
            'acct',
            'master_project_number',
            'local_job_number',
            'local_job_end_date',
            'invoice_number',
            'budget_amount',
            'am_review_track_date',
            'checked_by',
            'pm_review_track_date',
            'pm_checked_by',
            'acct_review_track_date',
            'acct_checked_by',
            'acct_inv_review_track_date',
            'acct_inv_checked_by',
            'project_owner',
            'account_manager',
            'client',
            'client_id',
            'pod',
            'end_client',
            'local_project_manager',
            'local_job_status',
            'fd',
            'pm',
            'acct_invoiced',
            'consolidated_invoice',
            'invoice_date',
            'am_stop',
            'job_location_prefix',
            'project_location_prefix',
        ];

        $defaultSort = in_array($this->instance, ['de', 'es']) ? 0 : 9;
        $datagridIndex = '0';
        $sortColumnParameter = $request->get('iSortCol_'.$datagridIndex);
        $sortColumn = isset($sortHeader[$sortColumnParameter]) ? $sortHeader[$sortColumnParameter] : $sortHeader[$defaultSort];
        $sortDirection = $request->get('sSortDir_'.$datagridIndex) ?: 'desc';
        $displayPerPage = $request->get('iDisplayLength') ? (int) $request->get('iDisplayLength') : 25;
        $start = (int) $request->get('iDisplayStart');
        $currentPage = $request->get('sEcho') ? (int) $request->get('sEcho') : 1;
        $searchTerm = $request->get('sSearch') ? urldecode($request->get('sSearch')) : null;
        $searchAMChecked = $request->get('sSearch_0');
        $searchACCTChecked = $request->get('sSearch_1');
        $searchMasterProjectNumber = $request->get('sSearch_2');
        $searchJobNumber = $request->get('sSearch_3');
        $searchCJobEndDate = $request->get('sSearch_4');
        $searchInvoiceNumber = $request->get('sSearch_5');
        $searchBudgetAmount = $request->get('sSearch_6');
        $searchAMReviewDate = $request->get('sSearch_7');
        $searchAMCheckedBy = $request->get('sSearch_8');
        $searchPMReviewDate = $request->get('sSearch_9');
        $searchPMCheckedBy = $request->get('sSearch_10');
        $searchAcctReviewDate = $request->get('sSearch_11');
        $searchAcctCheckedBy = $request->get('sSearch_12');
        $searchAcctInvReviewDate = $request->get('sSearch_13');
        $searchAcctInvCheckedBy = $request->get('sSearch_14');
        $searchProjectOwner = $request->get('sSearch_15');
        $searchAccountManager = $request->get('sSearch_16');
        $searchClient = $request->get('sSearch_17');
        $searchClientId = $request->get('sSearch_18');
        $searchPOD = $request->get('sSearch_19');
        $searchEndClient = $request->get('sSearch_20');
        $searchProjectManager = $request->get('sSearch_21');
        $searchJobStatus = $request->get('sSearch_22');
        $searchFDChecked = $request->get('sSearch_23');
        $searchPMChecked = $request->get('sSearch_24');
        $searchACCTInvoiced = $request->get('sSearch_25');
        $searchConsolidatedInvoice = $request->get('sSearch_26');
        $searchInvoicedDate = $request->get('sSearch_27');
        $searchAMStop = $request->get('sSearch_28');
        $searchJobLocationPrefix = $request->get('sSearch_29');
        $searchProjectLocationPrefix = $request->get('sSearch_30');

        $con = Propel::getConnection();

        $year = $request->get('year') ?: date('Y');
        $group = $request->get('group');
        if ('1' == $group) {
            $locs = Location::GROUP1;
        } elseif ('2' == $group) {
            $locs = Location::GROUP2;
        } elseif ('3' == $group) {
            $locs = Location::GROUP3;
        } elseif ('4' == $group) {
            $locs = Location::GROUP4;
        } else {
            $locs = [];
        }
        $locationsRequest = count($locs) > 0 ? 'AND' : null;
        foreach ($locs as $loc) {
            $req = 'AND' == $locationsRequest ? 'AND ( ' : $locationsRequest.' OR ';
            $locationsRequest = $req.'ref_location.libelle = '.$con->quote($loc);
        }
        $locationsRequest ? $locationsRequest .= ' )' : null;
        $queryConditions = " FROM user
        LEFT JOIN etude ON user.id = etude.id_bm
        LEFT JOIN job ON etude.id = job.etude_id
        LEFT JOIN ref_location ON job.location_prefix_id = ref_location.id
        LEFT JOIN job_item ON job_item.job_id = job.id
        WHERE (job_item.devis_ok < 5 OR job_item.devis_ok IS NULL)
        AND (job.api_created_date BETWEEN '$year-01-01 00:00:00' AND '$year-12-31 23:59:59')
        $locationsRequest ";

        $querySearchTerms = '';
        $querySearchUsingHaving = '';
        if ($searchTerm) {
            $searchTerm = $con->quote('%'.$searchTerm.'%');
            $searchCriteria = [
                ' etude.master_project_number LIKE '.$searchTerm,
                ' CONCAT(user.nom,\' \', user.prenom) LIKE '.$searchTerm,
                ' CONCAT(user2.nom,\' \', user2.prenom) LIKE '.$searchTerm,
                ' id_sams_job LIKE '.$searchTerm,
                ' prix_vente LIKE '.$searchTerm,
                ' end_date LIKE '.$searchTerm,
                ' sf_account.name LIKE '.$searchTerm,
                ' sf_account.mas_500_id LIKE '.$searchTerm,
                ' acc2.name LIKE '.$searchTerm,
                ' user3.nom LIKE '.$searchTerm,
                ' user3.prenom LIKE '.$searchTerm,
                ' sf_ref_salesforce.value LIKE '.$searchTerm,
            ];
            $querySearchTerms = ' AND ('.implode(' OR ', $searchCriteria).') ';
        }

        //search AMaster Checked column

        if ($searchAMChecked) {
            if ('no' === strtolower($searchAMChecked)) {
                $querySearchTerms .= ' AND (job.am_checked = 0 OR job.am_checked IS NULL) ';
            } elseif ('yes' === strtolower($searchAMChecked)) {
                $querySearchTerms .= ' AND (job.am_checked = 1) ';
            }
        }

        //search ACCT Checked column
        if ($searchACCTChecked) {
            if ('no' === strtolower($searchACCTChecked)) {
                $querySearchTerms .= ' AND (acct_checked = 0 OR acct_checked IS NULL) ';
            } elseif ('yes' === strtolower($searchACCTChecked)) {
                $querySearchTerms .= ' AND (acct_checked = 1) ';
            }
        }

        if ($searchMasterProjectNumber) {
            $allMasterPNumber = explode(',', $searchMasterProjectNumber);
            $parts = [];
            foreach ($allMasterPNumber as $otherPNumber) {
                $parts[] = ' etude.master_project_number LIKE '.$con->quote('%'.$otherPNumber.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Master Project Number column
        if ($searchInvoiceNumber) {
            $allInvoiceNumber = explode(',', $searchInvoiceNumber);
            $parts = [];
            foreach ($allInvoiceNumber as $otherInvoiceNumber) {
                $parts[] = ' job.invoice_number LIKE '.$con->quote('%'.$otherInvoiceNumber.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Local Job Number column
        if ($searchJobNumber) {
            $allJobNumbers = explode(',', $searchJobNumber);
            $parts = [];
            foreach ($allJobNumbers as $otherJobNumber) {
                $parts[] = ' id_sams_job LIKE '.$con->quote('%'.$otherJobNumber.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Local Job End Date column
        if ($searchCJobEndDate) {
            $dateTocompare = explode(',', $searchCJobEndDate);
            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (end_date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (end_date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (end_date LIKE '.$con->quote('%'.$searchCJobEndDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        if ($searchAMReviewDate) {
            $dateTocompare = explode(',', $searchAMReviewDate);
            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (lps.date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (lps.date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (lps.date LIKE '.$con->quote('%'.$searchAMReviewDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        if ($searchPMReviewDate) {
            $dateTocompare = explode(',', $searchPMReviewDate);
            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (lps_0.date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (lps_0.date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (lps_0.date LIKE '.$con->quote('%'.$searchPMReviewDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        if ($searchAcctInvReviewDate) {
            $dateTocompare = explode(',', $searchAcctInvReviewDate);
            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (lps_2.date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (lps_2.date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (lps_2.date LIKE '.$con->quote('%'.$searchAcctInvReviewDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        if ($searchAcctReviewDate) {
            $dateTocompare = explode(',', $searchAcctReviewDate);
            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (lps_1.date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (lps_1.date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (lps_1.date LIKE '.$con->quote('%'.$searchAcctReviewDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        //search AM checked by
        if ($searchAMCheckedBy) {
            $allUsers = explode(',', $searchAMCheckedBy);
            $parts = [];
            foreach ($allUsers as $user) {
                $parts[] = " CONCAT(lps.nom, ' ', lps.prenom) LIKE ".$con->quote('%'.$user.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search PM checked by
        if ($searchPMCheckedBy) {
            $allUsers = explode(',', $searchPMCheckedBy);
            $parts = [];
            foreach ($allUsers as $user) {
                $parts[] = " CONCAT(lps_0.nom,' ', lps_0.prenom) LIKE ".$con->quote('%'.$user.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        if ($searchAcctCheckedBy) {
            $allUsers = explode(',', $searchAcctCheckedBy);
            $parts = [];
            foreach ($allUsers as $user) {
                $parts[] = " CONCAT(lps_1.nom,' ', lps_1.prenom) LIKE ".$con->quote('%'.$user.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        if ($searchAcctInvCheckedBy) {
            $allUsers = explode(',', $searchAcctInvCheckedBy);
            $parts = [];
            foreach ($allUsers as $user) {
                $parts[] = " CONCAT(lps_2.nom,' ', lps_2.prenom) LIKE ".$con->quote('%'.$user.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Budget Amount column
        if ($searchBudgetAmount) {
            $allBudgetAmount = explode(',', $searchBudgetAmount);
            $parts = [];
            foreach ($allBudgetAmount as $budgetAmount) {
                if (in_array(substr($budgetAmount, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (SUM(job_item.prix_vente) '.substr($budgetAmount, 0, 2).' '.(float) substr($budgetAmount, 2).') ';
                } elseif (in_array(substr($budgetAmount, 0, 1), ['<', '>'])) {
                    $parts[] = ' (SUM(job_item.prix_vente) '.substr($budgetAmount, 0, 1).' '.(float) substr($budgetAmount, 1).') ';
                } else {
                    $parts[] = ' (SUM(job_item.prix_vente) LIKE '.$con->quote('%'.$searchBudgetAmount.'%').') ';
                }
            }
            $querySearchUsingHaving .= ' Having ('.implode(' AND ', $parts).') ';
        }

        //search Project Owner column
        if ($searchProjectOwner) {
            $allProjectOwner = explode(',', $searchProjectOwner);
            $parts = [];
            foreach ($allProjectOwner as $otherProjectOwner) {
                $parts[] = ' CONCAT(user.nom,\' \', user.prenom) LIKE '.$con->quote('%'.$otherProjectOwner.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Account Manager column
        if ($searchAccountManager) {
            $allAccountManager = explode(',', $searchAccountManager);
            $parts = [];
            foreach ($allAccountManager as $otherAccountManager) {
                $parts[] = ' CONCAT(user2.nom,\' \', user2.prenom) LIKE '.$con->quote('%'.$otherAccountManager.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Client column
        if ($searchClient) {
            $allSearchClient = explode(',', $searchClient);
            $parts = [];
            foreach ($allSearchClient as $otherClient) {
                $parts[] = ' sf_account.name LIKE '.$con->quote('%'.$otherClient.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Client Id column
        if ($searchClientId) {
            $allClientId = explode(',', $searchClientId);
            $parts = [];
            foreach ($allClientId as $otherClientId) {
                $parts[] = ' sf_account.mas_500_id LIKE '.$con->quote('%'.$otherClientId.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        if ($searchPOD) {
            $allsearchPOD = explode(',', $searchPOD);
            $parts = [];
            foreach ($allsearchPOD as $otherPOD) {
                $parts[] = ' sf_ref_salesforce1.value LIKE '.$con->quote('%'.$otherPOD.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search End Client column
        if ($searchEndClient) {
            $allEndClient = explode(',', $searchEndClient);
            $parts = [];
            foreach ($allEndClient as $otherClient) {
                $parts[] = ' acc2.name LIKE '.$con->quote('%'.$otherClient.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Local Project Manager column
        if ($searchProjectManager) {
            $allProjectManager = explode(',', $searchProjectManager);
            $parts = [];
            foreach ($allProjectManager as $projectManager) {
                $parts[] = ' CONCAT(user3.nom,\' \', user3.prenom) LIKE '.$con->quote('%'.$projectManager.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Local Job Statut column
        if ($searchJobStatus) {
            $allJobStatus = explode(',', $searchJobStatus);
            $parts = [];
            foreach ($allJobStatus as $jobStatut) {
                $parts[] = ' sf_ref_salesforce.value LIKE '.$con->quote('%'.$jobStatut.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search FD Checked column
        if ($searchFDChecked) {
            if ('no' === strtolower($searchFDChecked)) {
                $querySearchTerms .= ' AND (fd_checked = 0 OR fd_checked IS NULL) ';
            } elseif ('yes' === strtolower($searchFDChecked)) {
                $querySearchTerms .= ' AND (fd_checked = 1) ';
            }
        }

        //search PM Checked column
        if ($searchPMChecked) {
            if ('no' === strtolower($searchPMChecked)) {
                $querySearchTerms .= ' AND (pm_checked = 0 OR pm_checked IS NULL) ';
            } elseif ('yes' === strtolower($searchPMChecked)) {
                $querySearchTerms .= ' AND (pm_checked = 1) ';
            }
        }

        //search ACCT Invoiced column
        if ($searchACCTInvoiced) {
            if ('no' === strtolower($searchACCTInvoiced)) {
                $querySearchTerms .= ' AND (acct_invoiced = 0 OR acct_invoiced IS NULL) ';
            } elseif ('yes' === strtolower($searchACCTInvoiced)) {
                $querySearchTerms .= ' AND (acct_invoiced = 1) ';
            }
        }

        //search Consolidated Invoice column
        if ($searchConsolidatedInvoice) {
            if ('no' === strtolower($searchConsolidatedInvoice)) {
                $querySearchTerms .= ' AND (etude.consolidated_invoice = 0) ';
            } elseif ('yes' === strtolower($searchConsolidatedInvoice)) {
                $querySearchTerms .= ' AND (etude.consolidated_invoice = 1) ';
            }
        }

        //search Job Location Prefix
        if ($searchJobLocationPrefix) {
            $allJobLocPrefix = explode(',', $searchJobLocationPrefix);
            $parts = [];
            foreach ($allJobLocPrefix as $jobLocPrefix) {
                $parts[] = ' ref_location.prefix LIKE '.$con->quote('%'.$jobLocPrefix.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Project Location Prefix
        if ($searchProjectLocationPrefix) {
            $allProjectLocPrefix = explode(',', $searchProjectLocationPrefix);
            $parts = [];
            foreach ($allProjectLocPrefix as $projectLocPrefix) {
                $parts[] = ' project_location_prefix.prefix LIKE '.$con->quote('%'.$projectLocPrefix.'%').' ';
            }
            $querySearchTerms .= ' AND ( '.implode(' OR ', $parts).' ) ';
        }

        //search Invoice Date column

        if ($searchInvoicedDate) {
            $dateTocompare = explode(',', $searchInvoicedDate);

            $parts = [];
            foreach ($dateTocompare as $dateValue) {
                if (in_array(substr($dateValue, 0, 2), ['<=', '>='])) {
                    $parts[] = ' (invoice_date '.substr($dateValue, 0, 2).' '.$con->quote(substr($dateValue, 2)).') ';
                } elseif (in_array(substr($dateValue, 0, 1), ['<', '>'])) {
                    $parts[] = ' (invoice_date '.substr($dateValue, 0, 1).' '.$con->quote(substr($dateValue, 1)).') ';
                } else {
                    $parts[] = ' (invoice_date LIKE '.$con->quote('%'.$searchInvoicedDate.'%').') ';
                }
            }
            $querySearchTerms .= ' AND ('.implode(' AND ', $parts).') ';
        }

        //search AM Stop column
        if ($searchAMStop) {
            if ('no' === strtolower($searchAMStop)) {
                $querySearchTerms .= ' AND (etude.dont_set_am_auto = 0) ';
            } elseif ('yes' === strtolower($searchAMStop)) {
                $querySearchTerms .= ' AND (etude.dont_set_am_auto = 1) ';
            }
        }

        'am' == $sortColumn ? $sortColumn = 'job.am_checked' : '';

        $allReportDatas = $this->getJobDetailsQuery($year, $locationsRequest, $querySearchTerms, $querySearchUsingHaving, $sortColumn, $sortDirection, $start, $displayPerPage);
        if ($querySearchUsingHaving || $querySearchTerms) {
            $totalRecords = isset($allReportDatas['count']) ? $allReportDatas['count'] : 0;
        } else {
            $nbResults = $this->query("SELECT COUNT(DISTINCT job.id) AS cnt $queryConditions ");
            $totalRecords = isset($nbResults[0]) ? ($nbResults[0])->cnt : 0;
        }

        $results = [];
        $results['sEcho'] = $currentPage;
        $results['iTotalRecords'] = $totalRecords;
        $results['iTotalDisplayRecords'] = $totalRecords;
        $results['aaData'] = [];

        foreach ($allReportDatas['data'] as $reportDatas) {
            if ($reportDatas) {
                $defaultDateFmt = $this->getDefaultDateFmt();
                $results['aaData'][] = [
                    'am' => $reportDatas->am ? 'Yes' : 'No',
                    'acct' => $reportDatas->acct ? 'Yes' : 'No',
                    'master_project_number' => '<span class="etude-id" data-id="'.$reportDatas->etude_id.'">'.$reportDatas->master_project_number.'</span>',
                    'local_job_number' => $reportDatas->local_job_number,
                    'local_job_end_date' => $reportDatas->local_job_end_date ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->local_job_end_date), 0, 10))) : null,
                    'invoice_number' => $reportDatas->invoice_number,
                    'budget_amount' => $this->currency.$reportDatas->budget_amount,
                    'am_review_track_date' => $reportDatas->am_review_track_date ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->am_review_track_date), 0, 10))) : null,
                    'checked_by' => null !== $reportDatas->am_review_track_date && null === $reportDatas->checked_by ? 'Integration' : $reportDatas->checked_by,
                    'pm_review_track_date' => $reportDatas->pm_review_track_date ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->pm_review_track_date), 0, 10))) : null,
                    'pm_checked_by' => $reportDatas->pm_checked_by,
                    'acct_review_track_date' => $reportDatas->acct_review_track_date ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->acct_review_track_date), 0, 10))) : null,
                    'acct_checked_by' => $reportDatas->acct_checked_by,
                    'acct_inv_review_track_date' => $reportDatas->acct_inv_review_track_date ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->acct_inv_review_track_date), 0, 10))) : null,
                    'acct_inv_checked_by' => $reportDatas->acct_inv_checked_by,
                    'project_owner' => $reportDatas->project_owner,
                    'account_manager' => $reportDatas->account_manager,
                    'client' => $reportDatas->client,
                    'end_client' => $reportDatas->account_name,
                    'client_id' => $reportDatas->client_id,
                    'pod' => $reportDatas->pod,
                    'local_project_manager' => $reportDatas->local_project_manager,
                    'local_job_status' => $reportDatas->local_job_status ? $reportDatas->local_job_status : null,
                    'fd' => $reportDatas->fd ? 'Yes' : 'No',
                    'pm' => $reportDatas->pm ? 'Yes' : 'No',
                    'acct_invoiced' => $reportDatas->acct_invoiced ? 'Yes' : 'No',
                    'consolidated_invoice' => $reportDatas->consolidated_invoice ? 'Yes' : 'No',
                    'invoice_date' => ($reportDatas->invoice_date) ? date($defaultDateFmt, strtotime(substr(trim($reportDatas->invoice_date), 0, 10))) : null,
                    'am_stop' => $reportDatas->am_stop ? 'Yes' : 'No',
                    'job_location_prefix' => $reportDatas->job_location_prefix,
                    'project_location_prefix' => $reportDatas->project_location_prefix,
                ];
            }
        }

        return $this->json($results);
    }

    private function getJobDetailsQuery($year, $locationsRequest = '', $querySearchTerms = '', $querySearchUsingHaving = '', $sortColumn = '', $sortDirection = '', $start = '', $displayPerPage = '')
    {
        $query = "SELECT DISTINCT
        job.id,
        CONCAT(user.nom,' ', user.prenom) as project_owner,
        CONCAT(user2.nom,' ', user2.prenom) as account_manager,
        CONCAT(lps.nom,' ', lps.prenom) as checked_by,
        CONCAT(lps_0.nom,' ', lps_0.prenom) as pm_checked_by,
        CONCAT(lps_1.nom,' ', lps_1.prenom) as acct_checked_by,
        CONCAT(lps_2.nom,' ', lps_2.prenom) as acct_inv_checked_by,
        SUM(job_item.prix_vente) as budget_amount,
        CONCAT(user3.nom,' ', user3.prenom) as local_project_manager,
        etude.numero_etude,
        etude.dont_set_am_auto as am_stop,
        sf_account.name as client,
        sf_account.mas_500_id as client_id,
        sf_account.need_for_po_numbers_to_start_recruiting as need_for_po_numbers_to_start_recruiting,
        acc2.name as account_name,
        etude.end_client_id as end_client,
        sf_ref_salesforce1.value as pod,
        etude.id as etudeId,
        etude.consolidated_invoice as consolidated_invoice,
        etude.master_project_number,
        etude.opportunity_id,
        job.am_checked as am,
        job.po_job_number as po_job_number,
        job.client_project_number as client_project_number,
        job.acct_checked as acct,
        job.acct_invoiced,
        job.fd_checked as fd,
        job.pm_checked as pm,
        job.acct_invoiced,
        job.invoice_date,
        job.id_sams_job as local_job_number,
        job.end_date as local_job_end_date,
        job.invoice_number,
        job.etude_id,
        sf_ref_salesforce.value as local_job_status,
        lps.date as am_review_track_date,
        lps_0.date as pm_review_track_date,
        lps_1.date as acct_review_track_date,
        lps_2.date as acct_inv_review_track_date,
        project_location_prefix.prefix as project_location_prefix,
        ref_location.prefix as job_location_prefix
        FROM user
        LEFT JOIN etude ON user.id = etude.id_bm
        LEFT JOIN sf_account ON etude.account_id = sf_account.id
        LEFT JOIN project_location_prefix ON etude.id_master_project_location_pnl = project_location_prefix.id
        LEFT JOIN job ON etude.id = job.etude_id
        LEFT JOIN ref_location ON job.location_prefix_id = ref_location.id
        LEFT JOIN sf_ref_salesforce ON job.status_id = sf_ref_salesforce.id
        LEFT JOIN sf_ref_salesforce sf_ref_salesforce1 ON sf_account.pod_qual_id = sf_ref_salesforce1.id
        LEFT JOIN sf_account acc2 ON etude.end_client_id = acc2.id
        LEFT JOIN user user2 ON etude.account_manager_id = user2.id
        LEFT JOIN user user3 ON job.pm_id = user3.id
        LEFT JOIN job_item ON job_item.job_id = job.id
        LEFT JOIN (
            SELECT l.date, u.nom, u.prenom, l.job_id
            FROM log_project_status as l
            LEFT JOIN user as u ON u.id = l.user_id
            WHERE l.id = (SELECT max(id) from log_project_status  WHERE log_project_status.am_checked = 1 AND job_id = l.job_id)
        ) AS lps ON (lps.job_id = job.id)
        LEFT JOIN (
            SELECT l.date, u.nom, u.prenom, l.job_id
            FROM log_project_status as l
            LEFT JOIN user as u ON u.id = l.user_id
            WHERE l.id =  (SELECT max(id) from log_project_status  WHERE log_project_status.pm_checked = 1 AND job_id = l.job_id)
        ) lps_0 ON (lps_0.job_id = job.id)
        LEFT JOIN (
            SELECT l.date, u.nom, u.prenom, l.job_id
            FROM log_project_status l
            LEFT JOIN user as u ON u.id = l.user_id
            WHERE l.id =  (SELECT max(id) from log_project_status  WHERE log_project_status.acct = 1 AND job_id = l.job_id)
        ) lps_1 ON (lps_1.job_id = job.id)
        LEFT JOIN (
            SELECT l.date, u.nom, u.prenom, l.job_id
            FROM log_project_status l
            LEFT JOIN user as u ON u.id = l.user_id
            WHERE l.id =  (SELECT max(id) from log_project_status  WHERE log_project_status.acct_inv_checked = 1 AND job_id = l.job_id)
        ) lps_2 ON (lps_2.job_id = job.id)
        WHERE (job_item.devis_ok < 5 OR job_item.devis_ok IS NULL)
        AND (job.api_created_date BETWEEN ? AND ?)
        $locationsRequest $querySearchTerms
        GROUP BY job.id $querySearchUsingHaving";

        if ($sortColumn || $sortDirection || $start || $displayPerPage) {
            $query .= " ORDER BY $sortColumn $sortDirection LIMIT $start,$displayPerPage";
        }

        $con = Propel::getConnection();
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $year.'-01-01 00:00:00', PDO::PARAM_STR);
        $stmt->bindValue(2, $year.'-12-31 23:59:59', PDO::PARAM_STR);
        $stmt->execute();

        return ['data' => $stmt->fetchAll(PDO::FETCH_OBJ), 'count' => $stmt->rowCount()];
    }

    /**
     * @Route(name="accounting_report_jobs_details_excel", path="/accountingReport/jobsDetails/excel")
     */
    public function accountingReportJobsDetailsExcelAction(Request $request): Response
    {
        $year = $request->get('year') ?: date('Y');
        $datas = $this->getJobDetailsQuery($year);
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $this->setColumnWidth($sheet, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA'], 17);
        $this->setTitleSheet($sheet, '1', ['AM Checked', 'ACCT Checked', 'Master Project Number', 'Local Job Number', 'Local Job End Date', 'Invoice Number', 'Budget amount', 'AM Review Track Date',
            'AM checked by', 'PM Review Track Date', 'PM checked by', 'Acct Review Track Date', 'Acct checked by', 'Acct Inv Review Track Date', 'Acct Inv checked by',
            'Project Owner', 'Sales Rep', 'Client', 'Client Id', 'POD', 'End Client', 'Local Project Manager', 'Local Job Status', 'FD Checked', 'PM Checked', 'Acct Invoiced',
            'Invoice Date', 'AM Stop', 'Consolidated Invoice', 'Project Location Prefix', 'Job Location Prefix', 'PO needed', 'PO number', 'Client project Number', ]);

        $i = 2;
        $defaultDateFmt = $this->getDefaultDateFmt();
        foreach ($datas['data'] as $data) {
            $checked_by = null !== $data->am_review_track_date && null === $data->checked_by ? 'Integration' : $data->checked_by;
            $pm_checked_by = $data->pm_checked_by;
            $acct_checked_by = $data->acct_checked_by;
            $acct_inv_checked_by = $data->acct_inv_checked_by;
            $job = Job::getById($data->id);
            $projectLocationPrefix = null !== $job->getEtude() && $job->getEtude()->getProjectLocationPrefix() ? $job->getEtude()->getProjectLocationPrefix()->getPrefix() : '';
            $jobLocationPrefix = $job->getLocationPrefix() ? $job->getLocationPrefix()->getPrefix() : '';

            $sheet->setCellValue("A$i", ($data->am ? 'Yes' : 'No'));
            $sheet->setCellValue("B$i", ($data->acct ? 'Yes' : 'No'));
            $sheet->setCellValue("C$i", $data->master_project_number);
            $sheet->setCellValue("D$i", $data->local_job_number);
            $sheet->setCellValue("E$i", ($data->local_job_end_date ? date($defaultDateFmt, strtotime(substr(trim($data->local_job_end_date), 0, 10))) : null));
            $sheet->setCellValue("F$i", $data->invoice_number);
            $sheet->setCellValue("G$i", "$ $data->budget_amount");
            $sheet->setCellValue("H$i", ($data->am_review_track_date ? date($defaultDateFmt, strtotime($data->am_review_track_date)) : null));
            $sheet->setCellValue("I$i", $checked_by);
            $sheet->setCellValue("J$i", ($data->pm_review_track_date ? date($defaultDateFmt, strtotime($data->pm_review_track_date)) : null));
            $sheet->setCellValue("K$i", $pm_checked_by);
            $sheet->setCellValue("L$i", ($data->acct_review_track_date ? date($defaultDateFmt, strtotime($data->acct_review_track_date)) : null));
            $sheet->setCellValue("M$i", $acct_checked_by);
            $sheet->setCellValue("N$i", ($data->acct_inv_review_track_date ? date($defaultDateFmt, strtotime($data->acct_inv_review_track_date)) : null));
            $sheet->setCellValue("O$i", $acct_inv_checked_by);
            $sheet->setCellValue("P$i", $data->project_owner);
            $sheet->setCellValue("Q$i", $data->account_manager);
            $sheet->setCellValue("R$i", $data->client);
            $sheet->setCellValue("S$i", $data->client_id);
            $sheet->setCellValue("T$i", $data->pod);
            $sheet->setCellValue("U$i", $data->account_name);
            $sheet->setCellValue("V$i", $data->local_project_manager);
            $sheet->setCellValue("W$i", $data->local_job_status);
            $sheet->setCellValue("X$i", ($data->fd ? 'Yes' : 'No'));
            $sheet->setCellValue("Y$i", ($data->pm ? 'Yes' : 'No'));
            $sheet->setCellValue("Z$i", ($data->acct_invoiced ? 'Yes' : 'No'));
            $sheet->setCellValue("AA$i", ($data->invoice_date ? date($defaultDateFmt, strtotime(substr(trim($data->invoice_date), 0, 10))) : null));
            $sheet->setCellValue("AB$i", ($data->am_stop ? 'Yes' : 'No'));
            $sheet->setCellValue("AC$i", ($data->consolidated_invoice ? 'Yes' : 'No'));
            $sheet->setCellValue("AD$i", $projectLocationPrefix);
            $sheet->setCellValue("AE$i", $jobLocationPrefix);
            $sheet->setCellValue("AF$i", ($data->need_for_po_numbers_to_start_recruiting ? 'Yes' : 'No'));
            $sheet->setCellValue("AG$i", $data->po_job_number);
            $sheet->setCellValue("AH$i", $data->client_project_number);
            ++$i;
            $checked_by = null;
        }
        $writer = new Xlsx($spreadsheet);
        $response = new StreamedResponse(
            function () use ($writer) {
                $writer->save('php://output');
            }
        );
        $response->headers->set('Content-Type', 'application/vnd.ms-excel');
        $response->headers->set('Content-Disposition', 'attachment;filename="accounting_report_'.date('Y-m-d').'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');

        return $response;
    }

    /**
     * @Route(name="etude_recherche_acct_g1", path="/accountingReport/index1/{param}", defaults={"param": ""})
     */
    public function indexGroup1Action(Request $request): Response
    {
        return $this->render('pmtool/pages/accounting.html.twig', [
            'filter' => $request->get('param'),
            'group' => 1,
        ]);
    }

    /**
     * @Route(name="etude_recherche_acct_g2", path="/accountingReport/index2/{param}", defaults={"param": ""})
     */
    public function indexGroup2Action(Request $request): Response
    {
        return $this->render('pmtool/pages/accounting.html.twig', [
            'filter' => $request->get('param'),
            'group' => 2,
        ]);
    }

    /**
     * @Route(name="etude_recherche_acct_g3", path="/accountingReport/index3/{param}", defaults={"param": ""})
     */
    public function indexGroup3Action(Request $request): Response
    {
        return $this->render('pmtool/pages/accounting.html.twig', [
            'filter' => $request->get('param'),
            'group' => 3,
        ]);
    }

    /**
     * @Route(name="etude_recherche_acct_g4", path="/accountingReport/index4/{param}", defaults={"param": ""})
     */
    public function indexGroup4Action(Request $request): Response
    {
        return $this->render('pmtool/pages/accounting.html.twig', [
            'filter' => $request->get('param'),
            'group' => 4,
        ]);
    }

    /**
     * @Route(name="accounting_report_excel", path="/accountingReport/excel")
     */
    public function accountingReportExcelAction(Request $request): Response
    {
        $statusCancelledNonBilled = RefSalesForceQuery::create()->select('id')->filterByField('status_id')->filterByValue('Cancelled-Non-Billed')->findOne() ?: 0;
        $year = $request->get('year') ?: date('Y');
        $query = "SELECT DISTINCT
        job.id,
        CONCAT(user.nom,' ', user.prenom) as project_owner,
        CONCAT(user2.nom,' ', user2.prenom) as account_manager,
        SUM(job_item.prix_vente) as budget_amount,
        user3.nom as local_project_manager ,
        user3.prenom,
        user4.nom as opportunity_owner_first_name ,
        user4.prenom as opp_owner_last_name,
        user5.nom as created_by_last_name,
        user5.prenom as created_by_first_name,
        ref_methodology.typeEtudeBr as job_methodology,
        etude.numero_etude,
        etude.dont_set_am_auto as am_stop,
        etude.set_am_reason as am_reason_other_text,
        am_reason_type.label as am_reason_type,
        etude.consolidated_invoice as consolidated_invoice,
        sf_account.name as client,
        sf_account.mas_500_id as client_id,
        acc2.name as account_name,
        etude.end_client_id as end_client,
        etude.id as etudeId,
        etude.master_project_number,
        etude.opportunity_id,
        job.am_checked as am,
        job.acct_checked as acct,
        job.acct_invoiced,
        job.invoice_date,
        job.fd_checked as fd,
        job.pm_checked as pm,
        job.id_sams_job as local_job_number,
        job.end_date as local_job_end_date,
        job.invoice_number,
        job.etude_id,
        job.id as pmtool_id,
        ref_site.lieu as site,
        ref_site.adresse as address,
        sf_ref_salesforce.value as local_job_status
        FROM user
        LEFT JOIN etude ON user.id = etude.id_bm
        LEFT JOIN am_reason_type ON etude.am_reason_type_id = am_reason_type.id
        LEFT JOIN sf_account ON etude.account_id = sf_account.id
        LEFT JOIN job ON etude.id = job.etude_id
        LEFT JOIN sf_ref_salesforce ON job.status_id = sf_ref_salesforce.id
        LEFT JOIN sf_account acc2 ON etude.end_client_id = acc2.id
        LEFT JOIN user user2 ON etude.account_manager_id = user2.id
        LEFT JOIN user user3 ON job.pm_id = user3.id
        LEFT JOIN job_item ON job_item.job_id = job.id
        LEFT JOIN ref_location ON job.location_id = ref_location.id
        LEFT JOIN ref_site ON job.offsite_location_id = ref_site.id
        LEFT JOIN sf_opportunity ON etude.opportunity_id = sf_opportunity.id
        LEFT JOIN user user4 ON sf_opportunity.pmtool_created_by_id = user4.id
        LEFT JOIN user user5 ON SUBSTRING_INDEX(etude.created_by_comment,'by: ',-1) = user5.id
        LEFT JOIN job_methodology ON job.id = job_methodology.job_id
        LEFT JOIN ref_methodology ON job_methodology.methodology_id = ref_methodology.id
        LEFT JOIN sf_ref_salesforce as job_qualification ON etude.job_qualification_id = job_qualification.id
        WHERE (job_item.devis_ok < 5 OR job_item.devis_ok IS NULL)
            AND (job_qualification.value = 'Qual' OR job_qualification.value = 'KOL (MedQuery/Advisors)' ) -- FIXME
            AND job.am_checked = 0
            AND job.status_id <> {$statusCancelledNonBilled}
            AND (job.api_created_date BETWEEN ? AND ?)
            AND (etude.id_etape != ?)
       GROUP BY job.id DESC ";
        $con = Propel::getConnection();
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $year.'-01-01 00:00:00', PDO::PARAM_STR);
        $stmt->bindValue(2, $year.'-12-31 23:59:59', PDO::PARAM_STR);
        $stmt->bindValue(3, Etape::CANCELLED, PDO::PARAM_INT);
        $stmt->execute();
        $datas = $stmt->fetchAll(PDO::FETCH_OBJ);

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
        $this->setColumnWidth($sheet, ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'], 17);
        $this->setTitleSheet($sheet, '1', ['Master Project Number', 'Local Job Number', 'Client', 'Job type', 'Offsite Location', 'Opportunity Owner', 'Created By', 'Project Owner',
            'Sales Rep', 'Local Project Manager', 'Local Job End Date', 'PM-Tool ID of the job', 'AM Checked', 'PM Checked', 'FD Checked',
            'Consolidated Invoice', 'Project Location Prefix', 'Job Location Prefix', 'AM Stop', 'AM Stop Reason', 'Other Reason', ]);

        $i = 2;
        $defaultDateFmt = $this->getDefaultDateFmt();
        foreach ($datas as $data) {
            $name = ($data->local_project_manager && $data->prenom) ? $data->local_project_manager.' '.$data->prenom : '';
            $oppOwnerName = ($data->opportunity_owner_first_name && $data->opp_owner_last_name) ? $data->opportunity_owner_first_name.' '.$data->opp_owner_last_name : '';
            $createdBy = ($data->created_by_first_name && $data->created_by_last_name) ? $data->created_by_first_name.' '.$data->created_by_last_name : '';

            $job = Job::getById($data->id);
            $projectLocationPrefix = null !== $job->getEtude() && $job->getEtude()->getProjectLocationPrefix() ? $job->getEtude()->getProjectLocationPrefix()->getPrefix() : '';
            $jobLocationPrefix = $job->getLocationPrefix() ? $job->getLocationPrefix()->getPrefix() : '';
            $offsiteLocation = $data->site.'-'.$data->address;
            // D F K
            $sheet->setCellValue("A$i", $data->master_project_number);
            $sheet->setCellValue("B$i", $data->local_job_number);
            $sheet->setCellValue("C$i", $data->client);
            $sheet->setCellValue("D$i", $data->job_methodology);
            $sheet->setCellValue("E$i", $offsiteLocation);
            $sheet->setCellValue("F$i", $oppOwnerName);
            $sheet->setCellValue("G$i", $createdBy);
            $sheet->setCellValue("H$i", $data->project_owner);
            $sheet->setCellValue("I$i", $data->account_manager);
            $sheet->setCellValue("J$i", $name);
            $sheet->setCellValue("K$i", ($data->local_job_end_date ? date($defaultDateFmt, strtotime(substr(trim($data->local_job_end_date), 0, 10))) : null));
            $sheet->setCellValue("L$i", $data->pmtool_id);
            $sheet->setCellValue("M$i", ($data->am ? 'Yes' : 'No'));
            $sheet->setCellValue("N$i", ($data->pm ? 'Yes' : 'No'));
            $sheet->setCellValue("O$i", ($data->fd ? 'Yes' : 'No'));
            $sheet->setCellValue("P$i", ($data->consolidated_invoice ? 'Yes' : 'No'));
            $sheet->setCellValue("Q$i", $projectLocationPrefix);
            $sheet->setCellValue("R$i", $jobLocationPrefix);
            $sheet->setCellValue("S$i", ($data->am_stop ? 'Yes' : 'No'));
            $sheet->setCellValue("T$i", (null !== $data->am_reason_type ? $data->am_reason_type : ''));
            $sheet->setCellValue("U$i", ('Others' == $data->am_reason_type ? $data->am_reason_other_text : ''));
            ++$i;
        }
        $writer = new Xlsx($spreadsheet);
        $response = new StreamedResponse(
            function () use ($writer) {
                $writer->save('php://output');
            }
        );
        $response->headers->set('Content-Type', 'application/vnd.ms-excel');
        $response->headers->set('Content-Disposition', 'attachment;filename="accounting_report_'.date('Y-m-d').'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');

        return $response;
    }

    private function increment($val, $increment)
    {
        for ($i = 1; $i <= $increment; ++$i) {
            ++$val;
        }

        return $val;
    }

    private function setTitleSheet($sheet, $cell, $title)
    {
        $i = 'A';
        foreach ($title as $t) {
            $sheet->setCellValue($i.$cell, $t);
            $sheet->getStyle($i.$cell)->getFont()->setBold(true);
            $i = $this->increment($i, 1);
        }

        return $sheet;
    }

    private function setColumnWidth($sheet, $rows, $size)
    {
        foreach ($rows as $row) {
            $sheet->getColumnDimension($row)->setWidth($size);
        }
    }
}
