<?php

namespace Controllers;

use DateTime;
use Model\CategoriePrestation;
use Model\Etape;
use Model\Etude;
use Model\Fournisseur;
use Model\Groupe;
use Model\ImputationType;
use Model\Location;
use Model\LocationQuery;
use Model\Map\TempsPresenceTableMap;
use Model\TempsPresence;
use Model\TempsPresenceQuery;
use Model\TimeSheet;
use Model\TimeSheetQuery;
use Model\User;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Util\DateFormat;

class TimeSheetController extends BaseController
{
    /**
     * @Route(name="time_sheet", path="/timeSheet/editer/{idUser}/{periode}")
     */
    public function editerAction(Request $request): Response
    {
        $idUser = $request->get('idUser');
        $user = User::getById($idUser);
        $fournisseur = Fournisseur::getById($user->getFournisseurId());
        $periode = $request->get('periode');

        $canAddExtraHours = (Groupe::SYSTEM_ADMINISTRATOR === $this->getUser()->getIdGroupe() || Groupe::ACCOUNTING == $this->getUser()->getIdGroupe());

        // FIXME use Propel (easy)
        // Liste des types d'activités
        $results = $this->query("SELECT id,categorie FROM categorie_prestation  WHERE timesheet_ok = 'Y'  ORDER BY categorie");
        $categories = ['0' => ''];
        foreach ($results as $result) {
            $categories[$result->id] = $result->categorie;
        }

        // only those used in TimeSheets.
        $locations = LocationQuery::create()->useTimeSheetQuery()->endUse()->find()->toKeyValue('Id', 'Libelle');

        // Liste des types d'imputations
        $results = $this->query('SELECT id,imputation FROM imputation_type ORDER BY imputation');
        $imputation_types = ['0' => ''];
        foreach ($results as $result) {
            $imputation_types[$result->id] = $result->imputation;
        }

        // Liste des durées de pauses
        $durees_pause = [];
        $j = 0;
        for ($i = 0; $i <= 15; $i = $i + 0.25) {
            $durees_pause["$j"] = "$i";
            $j = $j + 15;
        }

        // Liste des types d'erreurs
        $erreurs = [];
        $erreurs[2] = 'Supplier information Failed : No hourly rate entered in supplier data base';
        $erreurs[3] = 'User information Failed : User not located on a site';
        $erreurs[4] = 'User information Failed : No correspondence with people in the supplier data base';
        $erreurs[5] = 'User information Failed : Too many Supplier related to User';
        $erreurs[6] = 'Imputation selection Failed : No data, you must select an Activity & Master Project or Other';
        $erreurs[7] = 'Imputation selection Failed : Master Project imputation required Activity';
        $erreurs[8] = 'Imputation selection Failed : Master Project imputation required Activity, not Other';
        $erreurs[9] = 'Imputation selection Failed : You must select an Activity an specify a Master Project';
        $erreurs[10] = 'Imputation selection Failed : You must select an Activity & Master Project or Other';
        $erreurs[11] = 'Imputation selection Failed : Too many data, you must select an Activity & Master Project or Other';
        $erreurs[12] = 'Imputation Master Project Failed : The Master Project is no longer being';

        // Période d'imputation et Message associé
        $periodeDuJour = $this->calculePeriodeImputation();

        if ($request->isMethod('POST')) {
            //  Traitement des relevés d'heure
            // Logique : Si l'enregistrement n'existe pas pour le USER /DATE on le crée
            if ($request->get('date_arrivee')) {
                for ($z = 0; $z < sizeof($request->get('date_arrivee')); ++$z) {
                    $date_arrivee = DateFormat::getDateSql($request->get('date_arrivee')[$z]);
                    $heure_arrivee = $request->get('heure_arrivee')[$z];
                    $heure_depart = $request->get('heure_depart')[$z];
                    $duree_pause = $request->get('duree_pause')[$z];
                    $day_type = $request->get('day_type')[$z];
                    $day_type_extra = ($request->get('day_type_extra') && isset($request->get('day_type_extra')[$z])) ? $request->get('day_type_extra')[$z] : '';
                    $extraHours_extra = ($request->get('extra_hours_extra') && isset($request->get('extra_hours_extra')[$z])) ? $request->get('extra_hours_extra')[$z] : 0;

                    $dayOfWeek = date('l', strtotime($date_arrivee));
                    if (('W' == $day_type || 'N' == $day_type) && '' != $heure_arrivee && '' != $heure_depart && '' != $duree_pause) {
                        $nb_heure = DateFormat::NbHeures($heure_arrivee, $heure_depart, $duree_pause);
                        $debitHour = $fournisseur ? $fournisseur->getDayDebitHour($dayOfWeek) : null;
                    } else {
                        $nb_heure = '';
                        $heure_arrivee = '';
                        $heure_depart = '';
                        $duree_pause = '';
                        $debitHour = '';
                    }
                    if ('P' == $day_type) {
                        $debitHour = $fournisseur ? $fournisseur->getDayDebitHour($dayOfWeek) : null;
                    }
                    $tempPresence = TempsPresenceQuery::create()
                        ->filterByIsFor('timesheet')
                        ->filterByIdUser($idUser)
                        ->filterByDate($date_arrivee)
                        ->filterByDayType(['C', 'T'], Criteria::NOT_IN)
                        ->findOne();
                    if (!$tempPresence) {
                        $tempPresence = new TempsPresence();
                        $tempPresence->setIdUser($idUser);
                        $tempPresence->setIsFor(TempsPresenceTableMap::COL_IS_FOR_TIMESHEET);
                        $tempPresence->setDate(date('Y-m-d', strtotime($date_arrivee)));
                        if ($fournisseur) {
                            $tempPresence->setMaxHourMonth($fournisseur->getMaxHoursPerMonth());
                            $tempPresence->setMaxHourWeek($fournisseur->getMaxHoursPerWeek());
                        }
                    }
                    $tempPresence->setHeureArrivee($heure_arrivee)
                        ->setHeureDepart($heure_depart)
                        ->setDureePause($duree_pause)
                        ->setNbHeure(floatval($nb_heure))
                        ->setDayType($day_type)
                        ->setDebitHours(floatval($debitHour))
                        ->setExtraHours(floatval($nb_heure) - floatval($debitHour));
                    $tempPresence->save();

                    if ($day_type_extra && $extraHours_extra) {
                        $tempPresenceExtra = TempsPresenceQuery::create()
                            ->filterByIsFor('timesheet')
                            ->filterByIdUser($idUser)
                            ->filterByDate($date_arrivee)
                            ->filterByDayType(['C', 'T'], Criteria::IN)
                            ->findOne();
                        if (!$tempPresenceExtra) {
                            $tempPresenceExtra = new TempsPresence();
                            $tempPresenceExtra->setIdUser($idUser);
                            $tempPresenceExtra->setIsFor(TempsPresenceTableMap::COL_IS_FOR_TIMESHEET);
                            $tempPresenceExtra->setDate(date('Y-m-d', strtotime($date_arrivee)));
                            if ($fournisseur) {
                                $tempPresenceExtra->setMaxHourMonth($fournisseur->getMaxHoursPerMonth());
                                $tempPresenceExtra->setMaxHourWeek($fournisseur->getMaxHoursPerWeek());
                            }
                        }
                        $tempPresenceExtra->setHeureArrivee('')
                            ->setHeureDepart('')
                            ->setDureePause('')
                            ->setNbHeure(floatval($extraHours_extra))
                            ->setDayType($day_type_extra)
                            ->setDebitHours('')
                            ->setExtraHours(floatval($extraHours_extra));
                        $tempPresenceExtra->save();
                    }
                }
            }

            // traitement des imputations
            // Si id_timesheet = '' création d'une ligne
            // Sinon on update de ligne
            if ($request->get('id_timesheet')) {
                for ($z = 0; $z < sizeof($request->get('id_timesheet')); ++$z) {
                    $id_timesheet = $request->get('id_timesheet')[$z];
                    $periodelongue = $request->get('periodelongue')[$z];
                    $date = DateFormat::getDateSQLvide($request->get('date')[$z]);
                    $id_categorie = $request->get('id_categorie')[$z];
                    $category = CategoriePrestation::getById($id_categorie);
                    $id_imputation = $request->get('id_imputation_type')[$z] ?? 0;
                    $imputation = ImputationType::getById($id_imputation);

                    if (($category && ('Recontact/Callback' === $category->getCategory() || 'Recruitment' === $category->getCategory()))
                    || ($imputation && ('Phoneroom Administration' === $imputation->getImputation() || 'Data Base / Panel' === $imputation->getImputation()))) {
                        $taux_horaire = $fournisseur->getPhoneRoomHourlyRate();
                    } else {
                        $taux_horaire = (float) $request->get('taux_horaire')[$z];
                    }
                    $id_location = $request->get('id_location')[$z];
                    $id_etude = $request->get('id_etude')[$z];
                    $nb_heure = (float) $request->get('nbHeure')[$z];
                    $cout = $nb_heure * $taux_horaire;
                    $avalider = $request->get('valide')[$z];
                    $timesheet = TimeSheetQuery::create()->findOneById($id_timesheet);
                    $id_error = 0;
                    $validation = 'N';
                    if ('0' != $id_timesheet) { // traitement des anciennes lignes
                        if ('Y' == $avalider) { // l'utilsateur veut la valider => on fait les vérification si ok on valide
                            $donnees_user = $this->verifySupplierData($idUser); // Etape 1
                            $id_error = $donnees_user['erreur'];
                            if (0 == $id_error) {
                                $id_error = $this->verifyImputationSources($id_categorie, $id_etude, $id_imputation);
                                if (0 == $id_error) { // Si pas d'erreur
                                    if (0 != $id_etude) {  // Si une étude est définie et que sa mise à jour est permise
                                        $donnees_etude = $this->verifyEtude($id_etude);
                                        $id_error = $donnees_etude['erreur'];
                                        $validation = 0 == $id_error ? 'Y' : 'N'; // si étude OK
                                    } else { // validation si pas erreur et pas d'étude définie
                                        $validation = 'Y';
                                    }
                                }
                            }
                        }
                        $timesheet->setIdCategorie($id_categorie)
                            ->setNbHeure($nb_heure)
                            ->setIdEtude($id_etude)
                            ->setIdImputation($id_imputation)
                            ->setValide($validation)
                            ->setIdError($id_error)
                            ->setCout($cout)
                            ->setTauxHoraire($taux_horaire)
                            ->setIdLocation($id_location);
                        $timesheet->save();
                    } elseif ($date <= date('Y-m-d') && 0 != $cout && 0 != $id_location) { // new lines; forbid dates in the future (#12458)
                        $timesheet = new TimeSheet();
                        $timesheet->setIdUser($idUser)
                            ->setCutoffPeriode($periodelongue)
                            ->setDate($date)
                            ->setIdCategorie($id_categorie)
                            ->setNbHeure($nb_heure)
                            ->setIdEtude($id_etude)
                            ->setIdImputation($id_imputation)
                            ->setValide($validation)
                            ->setIdError($id_error)
                            ->setCout($cout)
                            ->setTauxHoraire($taux_horaire)
                            ->setIdLocation($id_location);
                        $timesheet->save();
                    }
                    if ('Y' == $validation && $id_etude) {
                        $etude = Etude::getById($id_etude);
                        if ($etude) {
                            $etude->resetConsolidationTs();
                            $etude->recalculCostsEtude();
                        }
                    }
                }
            }
            $this->addFlash('success', 'Time sheet updated!');
        }

        $periodeAn = substr($periode, 0, 4);
        $donnees_user = $this->verifySupplierData($idUser); // Etape 1
        $totalExtraHoursYear = $this->getTotalExtraHours($idUser, $periodeAn);

        // Calcul des périodes inférieure et supérieure
        $periodeMois = substr($periode, 5, 2);
        $periodeplus = '12' != $periodeMois ? $periodeAn.'-'.sprintf('%02d', $periodeMois + 1) : ($periodeAn + 1).'-'.('01');
        if ('01' != $periodeMois) {
            $periodemoins = $periodeAn.'-'.sprintf('%02d', $periodeMois - 1);
        } else {
            $periodemoins = ($periodeAn - 1).'-'.('12');
        }

        $imputations = $this->query('SELECT time_sheet.id,
              id_user,
              periode_cutoff,
              cutoff_periode,
              date,
              id_categorie,
              nb_heure,
              taux_horaire,
              cout,
              id_etude,
              id_imputation,
              time_sheet.a_supprimer,
              valide,
              id_error,
              id_etape,
              id_location
              FROM time_sheet
              LEFT JOIN etude ON time_sheet.id_etude = etude.id
              WHERE id_user = ?
              AND LEFT(date,7) = ?
              ORDER BY date DESC,valide', [$idUser, $periode]);

        $fournisseur = $user ? $user->getFournisseur() : null;
        $maxHourPerWeek = $fournisseur ? $fournisseur->getMaxHoursPerWeek() : null;
        $maxHourPerMonth = $fournisseur ? $fournisseur->getMaxHoursPerMonth() : null;

        $presences = TempsPresenceQuery::create()
            ->filterByIdUser($idUser)
            ->filterByDayType(TempsPresence::DAY_TYPE_EXTRA, Criteria::NOT_IN)
            ->filterByIsFor(0)->add('LEFT(date,7)', $periode, Criteria::EQUAL)->find();

        $temps_presences = [];
        $date_liste_select = [];
        $date_liste_finale = [];
        $existExtraHours = false;
        foreach ($presences as $result) {
            $date = DateFormat::getDateFrancaise($result->getDate()->format('Y-m-d'));
            $temps_presences[$date] = [
                'date_arrivee' => $date,
                'heure_arrivee' => $result->getHeureArrivee() ? $result->getHeureArrivee()->format('H:i') : '',
                'heure_depart' => $result->getHeureDepart() ? $result->getHeureDepart()->format('H:i') : '',
                'duree_pause' => $result->getDureePause(),
                'nb_heure' => $result->getNbHeure(),
                'extra_hours' => $result->getExtraHours(),
                'max_hours_week' => $result->getMaxHourWeek(),
                'max_hours_month' => $result->getMaxHourMonth(),
                'day_type' => $result->getDayType(),
                'extra_hours_type' => '',
                'extra_hours_nb_heure' => 0,
                ];
            $date_liste_select[$result->getDate()->format('Y-m-d')] = $date;
        }

        $presencesExtra = TempsPresenceQuery::create()
            ->filterByIdUser($idUser)
            ->filterByDayType(TempsPresence::DAY_TYPE_EXTRA, Criteria::IN)
            ->filterByIsFor(0)->add('LEFT(date,7)', $periode, Criteria::EQUAL)->find();
        foreach ($presencesExtra as $result) {
            $date = DateFormat::getDateFrancaise($result->getDate()->format('Y-m-d'));
            if (!isset($temps_presences[$date])) {
                $temps_presences[$date] = [
                    'date_arrivee' => $date,
                    'heure_arrivee' => $result->getHeureArrivee() ? $result->getHeureArrivee()->format('H:i') : '',
                    'heure_depart' => $result->getHeureDepart() ? $result->getHeureDepart()->format('H:i') : '',
                    'duree_pause' => $result->getDureePause(),
                    'nb_heure' => $result->getNbHeure(),
                    'extra_hours' => $result->getExtraHours(),
                    'max_hours_week' => $result->getMaxHourWeek(),
                    'max_hours_month' => $result->getMaxHourMonth(),
                    'day_type' => $result->getDayType(),
                    'extra_hours_type' => $result->getDayType(),
                    'extra_hours_nb_heure' => $result->getExtraHours(),
                ];
            } else {
                $temps_presences[$date]['extra_hours_type'] = $result->getDayType();
                $temps_presences[$date]['extra_hours_nb_heure'] = $result->getExtraHours();
            }
        }
        ksort($temps_presences);
        $temps_presences = array_reverse($temps_presences, true);

        // Calcule la liste des jours valides
        $jours_mois = [];
        if (!($periode > date('Y-m'))) {
            if ($periode == date('Y-m')) {
                $nbJours = date('d');
            } else {
                $nbJours = cal_days_in_month(CAL_GREGORIAN, substr($periode, 5, 2), substr($periode, 0, 4));
            }
            for ($i = 1; $i <= $nbJours; ++$i) {
                $jours_mois[substr($periode, 0, 4).'-'.substr($periode, 5, 2).'-'.sprintf('%02d', $i)] = sprintf('%02d', $i).'/'.substr($periode, 5, 2).'/'.substr($periode, 0, 4);
            }
            $date_liste_finale = array_diff($jours_mois, $date_liste_select);
        }
        $debitHours = $fournisseur ? [$fournisseur->getDebitHoursSunday(), $fournisseur->getDebitHoursMonday(), $fournisseur->getDebitHoursTuesday(), $fournisseur->getDebitHoursWednesday(), $fournisseur->getDebitHoursThursday(), $fournisseur->getDebitHoursFriday(), $fournisseur->getDebitHoursSaturday()] : [];
        $id_groupe = $this->getUser()->getIdGroupe();
        /*
         Per #7570:
         - the Managing Director and the Administrative Officer can enter the imputations for any date
         - other users can enter imputations only for the last 6 days (including today)
         */
        $canAddImputation = in_array($id_groupe, [Groupe::MANAGING_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::PROJECT_DIRECTOR, Groupe::KNOWLEDGE_TEAM,
            Groupe::OPERATION_MANAGER, Groupe::PROJECT_CORDINATOR, Groupe::HR, ]);
        $date_arrivee_ens = [];
        $days = [];
        $datetimes = [];
        if ($temps_presences) {
            foreach ($temps_presences as $temps_presence) {
                $date_arrivee_ens[$temps_presence['date_arrivee']] = DateFormat::getDateSql($temps_presence['date_arrivee']);
                $timestamp = strtotime($date_arrivee_ens[$temps_presence['date_arrivee']]);
                $days[$temps_presence['date_arrivee']] = date('l', $timestamp);
                $datetimes[$temps_presence['date_arrivee']] = new DateTime($date_arrivee_ens[$temps_presence['date_arrivee']]);
            }
        }
        $etudes = [];
        $infoCategories = [];
        $locats = [];
        foreach ($imputations as $imputation) {
            $etudes[$imputation->id_etude] = Etude::getById($imputation->id_etude);
            $infoCategories[$imputation->id_categorie] = CategoriePrestation::getByIdAsArray($imputation->id_categorie);
            $locats[$imputation->id_location] = Location::getNomLocation($imputation->id_location);
        }
        $day_types = array_flip(TempsPresence::DAY_TYPE);

        return $this->render('pmtool/pages/timeSheet.html.twig', [
            'header' => '',
            'etudes' => [],
            'erreurs' => $erreurs,
            'categories' => $categories,
            'categories_json' => json_encode(array_flip($categories)),
            'imputation_types' => $imputation_types,
            'imputation_types_json' => json_encode(array_flip($imputation_types)),
            'durees_pause' => $durees_pause,
            'locations' => $locations,
            'locations_json' => json_encode(array_flip($locations)),
            'periodeDuJour' => $periodeDuJour->periodeDuJour,
            'messages' => $periodeDuJour->messageLastDateToDeclare,
            'day_types' => $day_types,
            'idUser' => $idUser,
            'periode' => $periode,
            'taux_horaire' => $donnees_user['taux_horaire'],
            'avg_hours_per_day' => $donnees_user['avg_hours_per_day'],
            'total_extra_hours' => $donnees_user['start_extra_hours'] + $totalExtraHoursYear - $donnees_user['correction_extra_hours'],
            'id_user_location' => $donnees_user['id_location'],
            'location' => Location::getNomLocation($donnees_user['id_location']),
            'periodeplus' => $periodeplus,
            'periodemoins' => $periodemoins,
            'nomPrenom' => $user ? $user->getFullname() : '',
            'employe' => $user ? $user->getEmploye() : '',
            'imputations' => $imputations,
            'maxHourPerWeek' => $maxHourPerWeek,
            'maxHourPerMonth' => $maxHourPerMonth,
            'temps_presences' => $temps_presences,
            'date_liste' => ['' => 'Select date'] + $date_liste_finale,
            'debitHours' => $debitHours,
            'validation_types' => ['N' => 'No', 'Y' => 'Yes'],
            'validation_types2' => ['N' => 'No', 'Y' => 'Yes'],
            'validation_types_json' => json_encode(['No' => 'N', 'Yes' => 'Y']),
            'id_groupe' => $id_groupe,
            'today' => new DateTime('today'),
            'canAddImputation' => $canAddImputation,
            'dateDuJour' => date('d/m/Y'),
            'date_arrivee_ens' => $date_arrivee_ens,
            'days' => $days,
            'datetimes' => $datetimes,
            'etudess' => $etudes,
            'infoCategories' => $infoCategories,
            'locats' => $locats,
            'canAddExtraHours' => $canAddExtraHours,
            'existExtraHours' => $existExtraHours,
            'firstDayMonth' => count($jours_mois) ? $jours_mois[array_key_first($jours_mois)] : '',
            'lastDayMonth' => count($jours_mois) ? end($jours_mois) : '',
        ]);
    }

    /**
     * Si l'étude n'est pas on-going on renvoie l'erreur  :
     * $erreurs[12] = 'Imputation Master Project Failed : The Master Project is no longer being';.
     */
    private function verifyEtude($id_etude)
    {
        $donnees_etude = [];
        $erreur = 0;
        $results = $this->query('SELECT id FROM etude WHERE etude.id = ? AND id_etape IN ('.Etape::STUDY_CREATION.','.Etape::BUDGET_CREATION.','.Etape::TO_CONFIRM.','.Etape::ONGOING.')', [$id_etude]);
        if (0 == count($results)) {
            $erreur = 12; // l'étude n'est pas Ingoing
        }
        $donnees_etude['erreur'] = $erreur;

        return $donnees_etude;
    }

    /**
     * Sums the extra_hours column for the given user and year.
     */
    private function getTotalExtraHours($id_user, $year)
    {
        $result = TempsPresenceQuery::create()
            ->withColumn('SUM(extra_hours)', 'total')
            ->filterByIsFor(TempsPresenceTableMap::COL_IS_FOR_TIMESHEET)
            ->filterByIdUser($id_user)
            ->filterByDate(['min' => $year.'-01-01', 'max' => $year.'-12-31'])
            ->findOne();

        return $result ? $result->getVirtualColumn('total') : 0;
    }

    /**
     * Vérification des données fournisseur
     * A partir de l'id_user on va chercher les paramètres
     * Dans User        : employe (Y/N)
     * Dans User        : id_location
     * Dans Fournisseur : taux_horaire
     * ------------------------------------------------------
     * Erreurs 2 et 3 plus utilisées depuis que l'on peut forcer les 2 valeurs
     * $erreurs[2] = 'Supplier information Failed : No hourly rate entered in supplier data base';
     * $erreurs[3] = 'User information Failed : User not located on a site' ;
     * Erreurs rencontrées =>
     * $erreurs[4] = 'User information Failed : No correspondence with people in the supplier data base';
     * $erreurs[5] = 'User information Failed : Too many Supplier related to User' ;.
     */
    private function verifySupplierData($id_user)
    {
        $donnees_user = [];
        $erreur = 0;
        $employe = '';
        $id_location = 0;
        $taux_horaire = 0;
        $avg_hours_per_day = 0;
        $start_extra_hours = 0;
        $correction_extra_hours = 0;
        $results = $this->query('SELECT fournisseur_id,taux_horaire,avg_hours_per_day,start_extra_hours,correction_extra_hours,id_location,user.employe,user.nom,user.prenom
            FROM user
            LEFT JOIN fournisseur ON fournisseur.id = user.fournisseur_id
            WHERE user.id = ?', [$id_user]);
        if (count($results) > 1) {
            $erreur = 5;
        } else {
            $employe = $results[0]->employe;
            $id_location = $results[0]->id_location;
            $avg_hours_per_day = $results[0]->avg_hours_per_day;
            $start_extra_hours = $results[0]->start_extra_hours;
            $correction_extra_hours = $results[0]->correction_extra_hours;
            $taux_horaire = $results[0]->taux_horaire;
            if (!$taux_horaire || !$id_location) {
                $erreur = 4;
            }
        }
        $donnees_user['erreur'] = $erreur;
        $donnees_user['employe'] = $employe;
        $donnees_user['id_location'] = $id_location;
        $donnees_user['taux_horaire'] = $taux_horaire;
        $donnees_user['avg_hours_per_day'] = $avg_hours_per_day;
        $donnees_user['start_extra_hours'] = $start_extra_hours;
        $donnees_user['correction_extra_hours'] = $correction_extra_hours;
        $donnees_user['nomPrenomId'] = $results[0]->nom.' '.$results[0]->prenom.', id: '.$id_user;

        return $donnees_user;
    }

    /**
     * Vérification des combinaisons Activity / Master Project / Other
     * ------------------------------------------------------
     * Categorie $C IdEtude $B  ImputType A$    Erreur      IdErreur    Message
     *  0           0           0               NO          6           You must select an Activity & Master Project or Other
     *  0           0           1               OK
     *  0           1           0               KO          7           Master Project imputation required Activity
     *  0           1           1               KO          8           Master Project imputation required Activity, not Other
     *  1           0           0               KO          9           You must select an Activity an specify a Master Project
     *  1           0           1               KO          10          You must select an Activity & Master Project or Other
     *  1           1           0               OK
     *  1           1           1               KO          11          Too many selection, you must select an Activity & Master Project or Other.
     */
    private function verifyImputationSources($id_categorie, $id_etude, $id_imputation)
    {
        $tableErreur = [0 => 6, 1 => 0, 2 => 7, 3 => 8, 4 => 9, 5 => 10, 6 => 0, 7 => 11];
        $A = '0' == $id_imputation ? 0 : 1;
        $B = '0' == $id_etude ? 0 : 1;
        $C = '0' == $id_categorie ? 0 : 1;
        $acStOt_data = $A + 2 * $B + 4 * $C;

        return $tableErreur[$acStOt_data] ?? 0;
    }

    /**
     * Calcul de la période d'imputation en fonction du jour actuel.
     */
    private function calculePeriodeImputation()
    {
        $result = new \stdClass();
        $dernierJourDeLaPeriode = DateFormat::lastdaymonth(date('m'), date('Y'));
        $periodeDuJour = date('d') < 16 ? date('Y-m').'-01' : date('Y-m').'-02';
        $message = "To be paid at the end of month please declare and valid your imputation to $dernierJourDeLaPeriode";
        $result->periodeDuJour = $periodeDuJour;
        $result->messageLastDateToDeclare = $message;

        return $result;
    }
}
