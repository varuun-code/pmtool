<?php

namespace Controllers;

use Datagrid\AccountDatagrid;
use DateTime;
use Form\Type\AccountType;
use Model\Account;
use Model\AccountQuery;
use Model\Groupe;
use Model\Repondant;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AccountController extends BaseController
{
    /**
     * @Route(name="account_list", path="/client-list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "datagrid": "", "param1": "", "param2": ""})
     */
    public function listAction(Request $request): Response
    {
        $accountDatagrid = new AccountDatagrid($this->container);
        $accountDatagrid->setQuery(AccountQuery::create());
        $accountDatagrid->execute();

        return $this->render('pmtool/account/index.html.twig', [
            'datagrid' => $accountDatagrid,
        ]);
    }

    /**
     * @Route(name="account_update", path="/client/{id}/update")
     */
    public function editAction(Request $request, Account $account): Response
    {
        $form = $this->createForm(AccountType::class, $account, [
            'with_status' => Groupe::SYSTEM_ADMINISTRATOR == $this->getUser()->getIdGroupe(),
        ]);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $account->keepUpdateDateUnchanged();
                if (!empty(array_intersect($account->getModifiedColumns(), Account::EDITABLE_FIELDS))) {
                    $account->setPmtoolUpdated(true);
                }
                $account->setPmtoolUpdatedDate(new DateTime());
                $account->save();
                $this->addFlash('success', 'Account updated.');

                return $this->redirectToRoute('account_list');
            } else {
                $this->addFlash('success', 'Account validation errors.');
            }
        }

        return $this->render('pmtool/account/edit.html.twig', [
            'form' => $form->createView(),
            'account' => $account,
        ]);
    }

    /**
     * @Route(name="account_show", path="/client/{id}/show")
     */
    public function showAction(Request $request, Account $account): Response
    {
        return $this->render('pmtool/account/show.html.twig', ['account' => $account]);
    }

    /**
     * @Route(name="account_name_autocompletion_", path="/client/search")
     */
    public function autocompletionAction(Request $request): JsonResponse
    {
        $data = [];
        $accounts = AccountQuery::create()
            ->_if($request->get('name'))
                ->filterByName('%'.$request->get('name').'%', Criteria::LIKE)
            ->_endif()
            ->_if($request->get('id'))
                ->filterById($request->get('id'))
            ->_endif()
            ->setLimit(100)
            ->find();

        foreach ($accounts as $account) {
            $data[] = [
                'value' => $account->getId(),
                'label' => $account->getName(),
            ];
        }

        return $this->json($data);
    }

    /**
     * @Route(name="account_search_by_name", path="/client/search-by-name")
     */
    public function searchByNameAction(Request $request): Response
    {
        $limit = $request->get('max_per_page', 10);
        $result = [];

        $query = AccountQuery::create()->filterByActiveProspectStatus()->orderByName(Criteria::ASC);

        if ($term = $request->get('term')) {
            $query
                ->filterByName('%'.$term.'%', Criteria::LIKE)
                ->_or()
                ->filterByBillingState('%'.$term.'%', Criteria::LIKE)
                 ->_or()
                ->useAccountDetailQuery(null, Criteria::LEFT_JOIN)
                    ->filterByDebtorNumber('%'.$term.'%', Criteria::LIKE)
                ->endUse();
        }
        if ($id = $request->get('id')) {
            $query->filterById($id);
        }

        $offset = ($request->get('page', 0) - 1) * $limit;

        $total = (clone $query)->count();

        $tags = $query
            ->limit($limit)
            ->offset($offset)
            ->find();

        foreach ($tags as $tag) {
            $result[] = [
                'id' => $tag->getId(),
                'text' => $tag->getNameforPicklist(),
                'name' => $tag->getNameforPicklist(),
                'alert' => $tag->getAlert(),
            ];
        }

        return $this->json([
            'maxPerPage' => $limit,
            'results' => $result,
            'total' => $total,
        ]);
    }

    /**
     * @Route(name="account_search_by_name_init", path="/client/search-by-name-init")
     */
    public function searchByLabelInitAction(Request $request): Response
    {
        $result = [];
        $ids = [];
        if ($request->get('multiple', null)) {
            $ids = explode(',', $request->get('id', []));
        } else {
            $ids[] = $request->get('id', null);
        }

        // 1 query to find & count ; if performance issue, split them and paginate the find.
        $accounts = AccountQuery::create()->filterByActiveProspectStatus()->orderByName(Criteria::ASC)->filterById($ids, Criteria::IN)->find();
        $total = count($accounts);

        if ($total > 1) {
            foreach ($accounts as $account) {
                $result[] = [
                    'id' => $account->getId(),
                    'text' => $account->getNameforPicklist(),
                    'name' => $account->getNameforPicklist(),
                ];
            }
        } else {
            foreach ($accounts as $account) {
                $result = [
                    'id' => $account->getId(),
                    'text' => $account->getNameforPicklist(),
                    'name' => $account->getNameforPicklist(),
                ];
            }
        }

        return $this->json([
            'results' => $result,
            'total' => $total,
        ]);
    }

    /**
     * @Route(name="account_search_by_id_init", path="/client/search-by-id-init")
     */
    public function searchByIdInitAction(Request $request): JsonResponse
    {
        $result = [];
        $total = 0;

        $repondantId = $request->get('id');
        $repondant = Repondant::getById($repondantId);
        if ($repondant) {
            $blacklistedRespondants = $repondant->getRepondantBlacklistAccounts();

            // 1 query to find & count ; if performance issue, split them and paginate the find.
            $total = count($blacklistedRespondants);

            foreach ($blacklistedRespondants as $account) {
                $result[] = [
                   'id' => $account->getId(),
                   'text' => $account->getNameforPicklist(),
                   'name' => $account->getNameforPicklist(),
               ];
            }
        }

        return $this->json([
            'results' => $result,
            'total' => $total,
        ]);
    }
}
