<?php

namespace Manager;

use Model\Opportunity;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\Exception\HttpExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

class SharepointManager
{
    protected $client;
    protected $spAccessUrl;
    protected $spClientId;
    protected $spClientSecret;
    protected $spPrefix;
    protected $spResource;
    protected $spApiUrl;
    protected $requestDigest;
    protected $token;

    public function __construct(string $spAccessUrl, string $spClientId, string $spClientSecret, string $spPrefix, string $spResource, string $spApiUrl)
    {
        $this->spAccessUrl = $spAccessUrl;
        $this->spClientId = $spClientId;
        $this->spClientSecret = $spClientSecret;
        $this->spPrefix = $spPrefix;
        $this->spResource = $spResource;
        $this->spApiUrl = $spApiUrl;
    }

    public function createFolder(Opportunity $opportunity): string
    {
        $response = [];
        if ($this->spAccessUrl && $id = $opportunity->getId()) {
            $request = $this->getClient()->request('POST', $this->spApiUrl.'/_api/web/folders', [
                'headers' => [
                    'Accept' => 'application/json;odata=verbose',
                    'Authorization' => 'Bearer '.$this->getToken(),
                    'Content-Type' => 'application/json;odata=verbose',
                    'X-RequestDigest' => $this->getRequestDigest(),
                ],
                'json' => [
                        '__metadata' => [
                        'type' => 'SP.Folder',
                    ],
                    'ServerRelativeUrl' => $this->spPrefix.'-'.$id,
                ],
            ]);

            try {
                $response = $request->getContent() ? $request->toArray() : '';
            } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
                $response['message'] = $e->getMessage();
            }
        }

        return $response['d']['Name'] ?? '';
    }

    protected function getRequestDigest()
    {
        if ($this->requestDigest) {
            return $this->requestDigest;
        }

        $response = $this->getClient()->request('POST', $this->spApiUrl.'/_api/contextinfo', [
            'headers' => [
                'Accept' => 'application/json;odata=verbose',
                'Authorization' => 'Bearer '.$this->getToken(),
            ],
            'body' => 'non empty body',
        ]);

        $content = [];
        try {
            $content = $response->toArray();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            // continue
        }

        return $this->requestDigest = $content['d']['GetContextWebInformation']['FormDigestValue'] ?? null;
    }

    protected function getToken()
    {
        if ($this->token) {
            return $this->token;
        }

        $response = $this->getClient()->request('POST', $this->spAccessUrl, [
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'body' => [
                'grant_type' => 'client_credentials',
                'client_id' => $this->spClientId,
                'client_secret' => $this->spClientSecret,
                'resource' => $this->spResource,
            ],
        ]);

        $content = [];
        try {
            $content = $response->toArray();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            // continue
        }

        return $this->token = $content['access_token'] ?? null;
    }

    protected function getClient()
    {
        return $this->client ?? $this->client = HttpClient::create(['http_version' => '2.0', 'timeout' => 2.5]);
    }
}
