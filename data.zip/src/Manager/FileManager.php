<?php

namespace Manager;

use Model\Fichier;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class FileManager
{
    protected $uploadDir;

    public function __construct(string $uploadDir)
    {
        $this->uploadDir = $uploadDir;
    }

    public function getFullPath(Fichier $fichier): string
    {
        return $this->uploadDir.$fichier->getFichier();
    }

    public function getDownloadResponse(Fichier $fichier): Response
    {
        $path = $this->getFullPath($fichier);
        if (!file_exists($path)) {
            throw new NotFoundHttpException();
        }

        $response = new Response();
        $response->headers->set('Cache-Control', 'private');
        $response->headers->set('Content-type', $fichier->getMimeType());
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$fichier->getFichierOriginal().'";');
        $response->headers->set('Content-length', filesize($path));
        $response->sendHeaders();
        $response->setContent(readfile($path));

        return $response;
    }

    public function unlink($fichier): void
    {
        $path = $this->getFullPath($fichier);

        @unlink($path);
    }
}
