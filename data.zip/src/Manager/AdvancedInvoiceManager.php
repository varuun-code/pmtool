<?php

namespace Manager;

use PDO;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\Response;

class AdvancedInvoiceManager
{
    private $spreadSheetManager;

    public function __construct(SpreadsheetManager $spreadsheetManager)
    {
        $this->spreadSheetManager = $spreadsheetManager;
    }

    public function getInvoices(?string $account_ids, ?string $date_debut, ?string $date_fin, ?string $isSend, ?string $sendFilter, ?string $selection_suplementaire)
    {
        if (isset($account_ids) || isset($date_debut) || isset($date_fin) || isset($isSend) || $sendFilter) {
            $query = (
                'SELECT etude.id AS id_etude, numero_etude, is_send, sf_account.name,
                    facture.date as date_reglement, document, paid_amount, payment_date, facture.montant, external_reference, job.id_sams_job
                    FROM facture
                    LEFT JOIN etude ON facture.id_etude = etude.id
                    LEFT JOIN sf_account ON sf_account.id = etude.account_id
                    LEFT JOIN document ON document.id = facture.id_document
                    LEFT JOIN job ON job.id = facture.job_id
                    WHERE facture.is_deleted != 1 AND
                    facture.date IS NOT NULL '.$selection_suplementaire.'
                    ORDER BY facture.date DESC'
            );
            $con = Propel::getConnection();
            $stmt = $con->prepare($query);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_OBJ) ?: [];
        } else {
            return [];
        }
    }

    public function exportInvoices(array $datas): Response
    {
        $workbook = new Spreadsheet();
        $sheet = $workbook->getActiveSheet();
        $sheet->setTitle('Advanced Invoice Report');
        $header = [
            'Invoice Date',
            'Master Project',
            'Job Number',
            'Client',
            'Send',
            'Document',
            'Check Number/Specific Reference',
            'Amount',
            'Paid Amount',
            'Payment Date',
        ];

        $this->spreadSheetManager->setHeader($sheet, $header);
        $ligneEnCours = 2;
        if ($datas) {
            foreach ($datas as $data) {
                $sheet->setCellValue('A'.$ligneEnCours, '0000-00-00' != $data->date_reglement ? $data->date_reglement : '');
                $sheet->setCellValue('B'.$ligneEnCours, $data->numero_etude);
                $sheet->setCellValue('C'.$ligneEnCours, $data->id_sams_job);
                $sheet->setCellValue('D'.$ligneEnCours, $data->name);
                $sheet->setCellValue('E'.$ligneEnCours, 1 == $data->is_send ? 'Yes' : 'No');
                $sheet->setCellValue('F'.$ligneEnCours, $data->document);
                $sheet->setCellValue('G'.$ligneEnCours, $data->external_reference);
                $sheet->setCellValue('H'.$ligneEnCours, $data->montant);
                $sheet->setCellValue('I'.$ligneEnCours, $data->paid_amount);
                $sheet->setCellValue('J'.$ligneEnCours, '0000-00-00' != $data->payment_date ? $data->payment_date : '');

                ++$ligneEnCours;
            }
        }

        return $this->spreadSheetManager->createResponse($workbook, 'Advanced_invoice');
    }
}
