<?php

namespace Manager;

use Model\Etude;
use Model\Job;
use Model\UserQuery;
use Swift_Attachment;
use Swift_Mailer;
use Swift_Message;
use Twig\Environment;

class MailManager
{
    protected $mailer;
    protected $templating;
    protected $mailFrom;
    protected $mailFromNom;
    protected $managersEmails;
    protected $surveyBaseLink;
    protected $supportEmail;
    protected $customerExperienceEmail;
    protected $customerExperienceLink;
    protected $unlockMailSendTo;
    protected $rushMailSendTo;
    protected $customerExperienceEmailBcc;

    const INSTANCE_NAMES = [
        'de' => 'SCHMIEDL',
        'es' => 'SPAIN',
        'fr' => 'FRANCE',
        'uk' => 'UK',
        'us' => 'US',
    ];

    public function __construct(Swift_Mailer $mailer, Environment $templating, $mailFrom, $mailFromNom, $managersEmails, $surveyBaseLink, $supportEmail, $customerExperienceEmail, $customerExperienceLink, $unlockMailSendTo, $rushMailSendTo, $customerExperienceEmailBcc)
    {
        $this->mailer = $mailer;
        $this->templating = $templating;
        $this->mailFrom = $mailFrom;
        $this->mailFromNom = $mailFromNom;
        $this->managersEmails = $managersEmails;
        $this->surveyBaseLink = $surveyBaseLink;
        $this->supportEmail = $supportEmail;
        $this->customerExperienceEmail = $customerExperienceEmail;
        $this->customerExperienceLink = $customerExperienceLink;
        $this->unlockMailSendTo = $unlockMailSendTo;
        $this->rushMailSendTo = $rushMailSendTo;
        $this->customerExperienceEmailBcc = $customerExperienceEmailBcc;
    }

    public function sendSmsCreditWarning($remaining)
    {
        $body = "Only $remaining SMS of type [LONG] remain.
            Please order some more on http://www.smsenvoi.com";
        $message = (new Swift_Message('SMS credit is low', $body, 'text/plain'))
            ->setFrom($this->mailFrom, $this->mailFromNom);
        foreach ($this->managersEmails as $email) {
            $message->setTo($email);
        }
        $this->mailer->send($message);
    }

    public function sendSmsSentToAdmin($message_total)
    {
        $message = (new Swift_Message('SMS Alert', $message_total, 'text/plain'))
            ->setFrom($this->mailFrom, $this->mailFromNom);
        foreach ($this->managersEmails as $email) {
            $message->setTo($email);
        }
        $this->mailer->send($message);
    }

    public function sendSmsSentToProjectManagers($mailForManagers)
    {
        foreach ($mailForManagers as $mailForManager) {
            $message = (new Swift_Message('SMS Alert', $mailForManager['message'], 'text/plain'))
                ->setFrom($this->mailFrom, $this->mailFromNom)
                ->setTo($mailForManager['manager_mail']);
            $this->mailer->send($message);
        }
    }

    public function sendAccountChangeMail(Etude $etude): void
    {
        $recipients = UserQuery::create()->filterByIsAccountChangeMailReceiver(true)->find();
        if (!count($recipients)) {
            return;
        }
        $masterProjectNumber = $etude->getMasterProjectNumber();
        $jobsNumberStatus = [];

        foreach ($etude->getJobEtudes() as $job) {
            $jobsNumberStatus[$job->getIdSamsJob()] = $job->getStatus()->getValue();
        }

        $object = 'Account changed for '.$masterProjectNumber;
        $content = $this->templating->render('pmtool/email/mailAccountChanged.html.twig', [
            'pmtoolNumber' => $etude->getNumeroEtude(),
            'masterProjectNumber' => $masterProjectNumber,
            'projectStatus' => $etude->getEtape()->getEtape(),
            'jobsNumberStatus' => $jobsNumberStatus,
            'newAccountName' => $etude->getAccount()->getName(),
        ]);
        foreach ($recipients as $recipient) {
            $this->send($recipient->getMail(), [], [], $object, $content);
        }
    }

    public function sendToInvoiceMail(Etude $etude)
    {
        $users = $etude->getLinkedUsers();

        foreach ($users as $email => $roles) {
            $role = implode('', $roles);
            $url = $this->surveyBaseLink.'Project='.$etude->getMasterProjectNumber().'&FieldRole='.$role.'&Email='.$email;
            $content = $this->templating->render('pmtool/email/mailToInvoice.html.twig', [
                'etude' => $etude,
                'url' => $url,
            ]);
            $this->send($email, [], [], '360 view of project '.$etude->getMasterProjectNumber(), $content);
        }
    }

    public function sendToJobSectionMail(Job $job)
    {
        $content = $this->templating->render('pmtool/email/mailJobSection.html.twig', [
            'job' => $job,
        ]);
        $this->send($this->supportEmail, [], [], 'new job '.$job->getPlatform()->getName().' '.$job->getIdSamsJob() ?? $job->getIdSamsJob(), $content);
    }

    public function sendCsatQuestMail(Etude $etude, $instance)
    {
        $users = [
            ['email' => $etude->getContactClientPm() ? $etude->getContactClientPm()->getEmail() : '',
            'first_name' => $etude->getContactClientPm() ? $etude->getContactClientPm()->getFirstName() : '',
            'language' => $etude->getContactClientPm() ? ($etude->getContactClientPm()->getLanguagePreference() ? $etude->getContactClientPm()->getLanguagePreference()->getValue() : '') : '',
            'contact_id' => $etude->getContactClientPmId() ? $etude->getContactClientPmId() : '',
            ], ['email' => $etude->getContact() ? $etude->getContact()->getEmail() : '',
            'first_name' => $etude->getContact() ? $etude->getContact()->getFirstName() : '',
            'language' => $etude->getContact() ? ($etude->getContact()->getLanguagePreference() ? $etude->getContact()->getLanguagePreference()->getValue() : '') : '',
            'contact_id' => $etude->getContactId() ? $etude->getContactId() : '',
            ],
        ];
        $existingEmail = '';
        foreach ($users as $user) {
            if ($existingEmail != $user['email']) {
                $pid = $etude->getId().''.self::INSTANCE_NAMES[$instance].''.$user['contact_id'];
                $url = $this->customerExperienceLink.'Project='.$etude->getMasterProjectNumber().'&Email='.$user['email'].'&BDEmail='.($etude->getProjectAccountManager() ? $etude->getProjectAccountManager()->getMail() : '').'&PMEmail='.($etude->getEtudeProjectManager() ? $etude->getEtudeProjectManager()->getMail() : '').'&ClientCompany='.($etude->getAccount() ? $etude->getAccount()->getName() : '').'&AMEmail='.($etude->getBM() ? $etude->getBM()->getMail() : '').'&PodName='.($etude->getAccount() ? ($etude->getAccount()->getPodQual() ? $etude->getAccount()->getPodQual()->getValue() : '') : '').'&ClientName='.$user['first_name'].'&decLang='.lcfirst($user['language']).'&pid='.$pid;
                $content = $this->templating->render('pmtool/email/mailSendQuest.html.twig', [
                    'etude' => $etude,
                    'url' => $url,
                    'sender_email' => $this->customerExperienceEmail,
                    'language' => $user['language'],
                ]);
                if ('French' == $user['language']) {
                    $subject = 'Schlesinger Group : Dites-nous ce que vous pensez réellement !';
                } elseif ('Spanish' == $user['language']) {
                    $subject = 'Schlesinger Group: ¡Adelante, háblenos con sinceridad!';
                } elseif ('German' == $user['language']) {
                    $subject = 'Schlesinger Group: Sagen Sie uns, was Sie wirklich denken!';
                } else {
                    $subject = 'Schlesinger Group: Go On, Tell Us What You Really Think!';
                }
                $this->send($user['email'], [], [], $subject, $content, '', $this->customerExperienceEmail, explode(',', $this->customerExperienceEmailBcc), 'CustomerExperienceTeam');
                $existingEmail = $user['email'];
            }
        }
    }

    public function sendFdMail(Job $job, $url, $user)
    {
        $jobNumber = $job->getIdSamsJob();
        $receiverMail = $job->getJobProjectManager()->getMail();
        $content = $this->templating->render('pmtool/email/mailSendFd.html.twig', [
            'jobNumber' => $jobNumber,
            'url' => $url,
        ]);
        $this->send($receiverMail, [], [], "FD checked for [$jobNumber]", $content, '', $user->getMail());
    }

    public function sendRejectedMail(Etude $etude, $job)
    {
        $users = $etude->getLinkedUsers();
        $rejectedSenderMail = $etude->getUpdatedBy()->getMail();
        $rejectedSenderMail = $etude->getUpdatedBy()->getMail();
        $rejectedSenderName = $etude->getUpdatedBy()->getNom().' '.$etude->getUpdatedBy()->getPrenom();
        $client = $etude->getAccount();
        $reason = $job->getRejectedReason();
        $masterJob = $etude->getMasterProjectNumber();
        $localJob = $job->getIdSamsJob();

        foreach ($users as $email => $value) {
            $content = $this->templating->render('pmtool/email/mailRejected.html.twig', [
                'client' => $client,
                'rejectedUserName' => $rejectedSenderName,
                'rejectedUserMail' => $rejectedSenderMail,
                'masterJob' => $masterJob,
                'localJob' => $localJob,
                 'reason' => $reason,
            ]);

            $this->send($email, [], [], 'SUMMARY REJECTED:'.$masterJob.','.$localJob.','.$client, $content, '', $rejectedSenderMail);
        }
    }

    public function sendUnlockMail(Etude $etude, $job)
    {
        $unlockSenderMail = $etude->getUpdatedBy()->getMail();
        $unlockSenderName = $etude->getUpdatedBy()->getNom().' '.$etude->getUpdatedBy()->getPrenom();
        $client = $etude->getAccount();
        $reason = $job->getUnlockReason();
        $masterJob = $etude->getMasterProjectNumber();
        $localJob = $job->getIdSamsJob();

        $content = $this->templating->render('pmtool/email/mailUnlock.html.twig', [
                'client' => $client,
                'unlockUserName' => $unlockSenderName,
                'unlockUserMail' => $unlockSenderMail,
                'masterJob' => $masterJob,
                'localJob' => $localJob,
                 'reason' => $reason,
            ]);
        $this->send($this->unlockMailSendTo, [], [], 'UNLOCK REQUEST:'.$masterJob.','.$localJob.','.$client, $content, '', $unlockSenderMail);
    }

    public function sendRushMail(Etude $etude, $job)
    {
        $rushSenderMail = $etude->getUpdatedBy()->getMail();
        $rushSenderName = $etude->getUpdatedBy()->getNom().' '.$etude->getUpdatedBy()->getPrenom();
        $client = $etude->getAccount();
        $masterJob = $etude->getMasterProjectNumber();
        $localJob = $job->getIdSamsJob();

        $content = $this->templating->render('pmtool/email/mailRush.html.twig', [
                 'client' => $client,
                'rushUserName' => $rushSenderName,
                'rushUserMail' => $rushSenderMail,
                'masterJob' => $masterJob,
                'localJob' => $localJob,
            ]);
        $this->send($this->rushMailSendTo, [], [], 'RUSH REQUEST:'.$masterJob.','.$localJob.','.$client, $content, '', $rushSenderMail);
    }

    public function sendPmDefinitionMail(Etude $etude, $users, $client, $sfMasterProjectNumber, $url, $comment, $path = null, $subject = null, $senderEmail = null)
    {
        $sendUserEmail = '';
        $jobData = [];
        $copyUsersEmail = [];
        $sampleSource = $etude->getSampleSources() ? implode(',', $etude->getSampleSources()->toKeyValue('Id', 'Libelle')) : '';

        foreach ($users as $key => $user) {
            if (0 == $key) {
                $sendUserEmail = $user->getMail();
            } else {
                $copyUsersEmail[] = $user->getMail();
            }
        }

        foreach ($etude->getJobEtudes() as $key => $job) {
            $jobData[$key]['job_number'] = $job->getIdSamsJob();
            $jobData[$key]['location'] = $job->getJobLocation()->getLibelle();
            $jobData[$key]['sample_source'] = $sampleSource;
            $jobData[$key]['job_start_date'] = $job->getStartDate('d.m.Y');
            $jobData[$key]['job_on_site_requirement'] = (int) $job->getOnSiteRecruits();
            $jobData[$key]['job_off_site_requirement'] = (int) $job->getOffSiteRecruits();
        }

        $content = $this->templating->render('pmtool/email/pmDefinition.html.twig', [
                'numeroEtude' => $etude->getNumeroEtude(),
                'projectNumber' => $sfMasterProjectNumber,
                'client' => $client,
                'subject' => $subject,
                'jobDatas' => $jobData,
                'url' => $url,
                'comment' => $comment,
            ]);

        $this->send($sendUserEmail, [], $copyUsersEmail, 'Request PM/Call Center '.$sfMasterProjectNumber.' - '.$etude->getTheme().' - '.$client.'. ('.$etude->getNumeroEtude().')', $content, $path, '', [], $senderEmail);
    }

    public function send(string $mailTo, array $replyTo, array $mailCopy, string $objet, string $texte, $fileNamePJ = null, $customMailFromNom = null, array $mailBcc = [], $customMailFrom = null): void
    {
        foreach (explode(';', $mailTo) as $recipient) {
            if ($recipient) {
                $setReplyTo = null;
                if ($replyTo) {
                    $setReplyTo = $replyTo;
                } else {
                    if ('CustomerExperienceTeam' != $customMailFrom) {
                        $setReplyTo = $customMailFrom;
                    }
                }
                $message = (new Swift_Message($objet))
                    ->setTo(trim($recipient))
                    ->setReplyTo($setReplyTo)
                    ->setBody($texte, 'text/html');

                if ($customMailFrom && 'CustomerExperienceTeam' == $customMailFrom) {
                    $message->setFrom([$customMailFromNom => $customMailFrom]);
                } else {
                    empty($customMailFrom) ? $message->setFrom([$this->mailFrom => $customMailFromNom ?: $this->mailFromNom]) : $message->setFrom($customMailFrom);
                }

                foreach ($mailCopy as $cc) {
                    if (trim($cc)) {
                        $message->addCc(trim($cc));
                    }
                }

                foreach ($mailBcc as $bcc) {
                    if (trim($bcc)) {
                        $message->addBcc(trim($bcc));
                    }
                }

                if ($fileNamePJ) {
                    if (is_array($fileNamePJ)) {
                        foreach ($fileNamePJ as $path) {
                            $attachment = Swift_Attachment::fromPath($path);
                            $message->attach($attachment);
                        }
                    } else {
                        $attachment = Swift_Attachment::fromPath($fileNamePJ);
                        $message->attach($attachment);
                    }
                }

                $this->mailer->send($message);
            }
        }
    }
}
