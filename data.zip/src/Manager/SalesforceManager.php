<?php

namespace Manager;

use Model\Contact;
use Model\Etude;
use Model\Event;
use Model\Job;
use Model\Opportunity;
use Model\RefSalesForce;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\Exception\HttpExceptionInterface;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;

class SalesforceManager
{
    const SALESFORCE_REQUEST = 'Salesforce request';
    const SALESFORCE_RESPONSE = 'Salesforce response';

    const CONTACT_ID_FIELD = [
        'de' => 'Schmiedl_PM_TOOL_id__c',
        'es' => 'Spain_PM_TOOL_id__c',
        'fr' => 'Contact_PM_TOOL_id__c',
        'uk' => 'UK_PM_Tool_ID__c',
        'us' => 'US_PM_Tool_ID__c',
    ];

    private $client;
    private $logger;
    private $instance;
    private $sfUrl;
    private $clientId;
    private $clientSecret;
    private $sfUser;
    private $sfPassword;
    private $token;

    public function __construct(string $apiUrl, string $clientId, string $clientSecret, string $sfUser, string $sfPassword, string $instance, LoggerInterface $logger)
    {
        $this->logger = $logger;
        $this->sfUrl = $apiUrl;
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->sfUser = $sfUser;
        $this->sfPassword = $sfPassword;
        $this->instance = $instance;
    }

    public function pushJobs(Etude $etude): array
    {
        $results = [];
        foreach ($etude->getJobEtudes() as $job) {
            /** @var Job $job */
            if (!$job->getJobSfId() && in_array($job->getStatus()->getValue(), RefSalesForce::JOB_STATUSES_SALESFORCE)) {
                $results[] = $this->createJob($job);
            } elseif ($job->getJobSfId()) {
                $results[] = $this->updateJob($job);
            }
        }

        return $results;
    }

    private function updateJob(Job $job): string
    {
        $serializedJob = $job->serializeForSalesforce($this->instance);
        //Remove Name property in the case of the update
        unset($serializedJob['Name']);
        $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v52.0/sobjects/job__c/'.$job->getJobSfId(), [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'json' => $serializedJob,
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    private function createJob(Job $job): string
    {
        $request = $this->getClient()->request('POST', $this->sfUrl.'/services/data/v49.0/composite/', [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'allOrNone' => true,
                'collateSubrequests' => true,
                'compositeRequest' => [
                    [
                        'method' => 'POST',
                        'url' => '/services/data/v38.0/sobjects/Job__c',
                        'referenceId' => 'refJob',
                        'body' => $job->serializeForSalesforce($this->instance),
                    ],
                    [
                        'method' => 'GET',
                        'referenceId' => 'newJobInfo',
                        'url' => '/services/data/v49.0/sobjects/job__c/@{refJob.id}?fields=id,Name,Master_Project_Number__c,Master_Project_Num__c',
                    ],
                ],
            ],
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $compResponse = $response['compositeResponse'] ?? [];
            $data = $compResponse[1] ?? [];
            $body = $data['body'] ?? [];
            $message = isset($compResponse[0]) && isset($compResponse[0]['body']) && isset($compResponse[0]['body'][0])
                && isset($compResponse[0]['body'][0]['message']) ? $compResponse[0]['body'][0]['message'] : '';
            $jobSfId = $body['Id'] ?? null;
            $jobName = $body['Name'] ?? '';
            $job->setJobSfId($jobSfId)->setIdSamsJob($jobName)->save();

            $etude = $job->getEtude();
            if (isset($body['Master_Project_Num__c']) && !$etude->getMasterProjectNumber()) {
                $etude->setMasterProjectNumber($body['Master_Project_Num__c']);
            }
            if (isset($body['Master_Project_Number__c']) && !$etude->getMasterProjectSfId()) {
                $etude->setMasterProjectSfId($body['Master_Project_Number__c']);
            }
            $etude->save();
            if ($message) {
                $response = ['message' => $message];
            }
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $response = ['message' => $e->getMessage()];
        }

        return $response['message'] ?? '';
    }

    public function pushEvent(Event $event): ?string
    {
        $refEventStatus = $event->getRefEventStatus();
        $isOnlyAttachedToBidJob = $event->getBidJobId() && !$event->getJobId();
        if (!$isOnlyAttachedToBidJob && !$event->getSamsEventId() && $refEventStatus && !in_array($refEventStatus->getName(), Event::NOT_NEW_STATUS_EVENT)) {
            return $this->createEvent($event);
        } elseif (!$isOnlyAttachedToBidJob && $event->getSamsEventId() && !$event->getBidJobId()) {
            return $this->updateEvent($event);
        }

        return '';
    }

    private function createEvent(Event $event)
    {
        $request = $this->getClient()->request('POST', $this->sfUrl.'/services/data/v52.0/sobjects/Event/', [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($event->serializeForSalesforce($this->instance)),
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
            $response = $request->getContent() ? $request->toArray() : [];
            $eventSfId = $response['id'] ?? null;
            $event->setSamsEventId($eventSfId)->save();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    private function updateEvent(Event $event)
    {
        $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v52.0/sobjects/Event/'.$event->getSamsEventId(), [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($event->serializeForSalesforce($this->instance)),
        ]);

        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    public function updateProjectAccount(Etude $etude): string
    {
        $accountSfId = $etude->getAccount() ? $etude->getAccount()->getSfId() : '';

        $message = '';
        if ($accountSfId && $sfId = $etude->getMasterProjectSfId()) {
            $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v20.0/sobjects/GMS__c/'.$sfId, [
                'headers' => [
                    'Authorization' => 'Bearer '.$this->getToken(),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'Account__c' => $accountSfId,
                ],
            ]);
            $message = $this->getResponseMessage($request);
        }

        return $message;
    }

    public function updateProjectStatus(Etude $etude): string
    {
        $status = $etude->getEtape() ? $etude->getEtape()->getSfLabel() : '';

        $message = '';
        if ($status && $sfId = $etude->getMasterProjectSfId()) {
            $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v20.0/sobjects/GMS__c/'.$sfId, [
                'headers' => [
                    'Authorization' => 'Bearer '.$this->getToken(),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'Job_Status__c' => $status,
                    'Field_Start_Date__c' => $etude->getDateDebut('Y-m-d'),
                ],
            ]);
            $message = $this->getResponseMessage($request);
        }

        return $message;
    }

    public function updateMasterProjectFields(Etude $etude): string
    {
        $message = '';
        if ($sfId = $etude->getMasterProjectSfId()) {
            $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v20.0/sobjects/GMS__c/'.$sfId, [
                'headers' => [
                    'Authorization' => 'Bearer '.$this->getToken(),
                    'Content-Type' => 'application/json',
                ],
                'json' => $etude->serializeForSalesforce(),
            ]);
            $message = $this->getResponseMessage($request);
        }

        return $message;
    }

    public function setOpportunityClosedWon(Opportunity $opportunity): string
    {
        $message = '';
        if ($sfId = $opportunity->getSfId()) {
            $request = $this->getClient()->request('PATCH', $this->sfUrl.'/services/data/v20.0/sobjects/Opportunity/'.$sfId, [
                'headers' => [
                    'Authorization' => 'Bearer '.$this->getToken(),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'StageName' => 'Closed Won',
                    'Coronavirus_Effected__c' => $opportunity->getCoronavirusEffected() ? 'Yes' : 'No',
                    'Financial_implication_of_COVID__c' => $opportunity->getLostRevenue(),
                ],
            ]);
            $message = $this->getResponseMessage($request);
        }

        return $message;
    }

    public function getJobs(string $sfId)
    {
        $query = "SELECT id,name,other_location__c,job_status__c FROM job__c WHERE Opportunity__c = '".$sfId."'";
        $response = $this->getClient()->request('GET', $this->sfUrl.'/services/data/v20.0/query/?q='.str_replace(' ', '+', $query), [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
        ]);

        return $response->toArray();
    }

    public function pushOpportunity(Opportunity $opportunity): ?string
    {
        $opportunity->reload(true); // fixes #21217
        if (!$opportunity->getSfId()) {
            return $this->createOpportunity($opportunity);
        }

        return $this->updateOpportunity($opportunity);
    }

    private function createOpportunity(Opportunity $opportunity): ?string
    {
        $request = $this->getClient()->request('POST', $this->sfUrl.'/services/data/v52.0/sobjects/Opportunity/', [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($opportunity->serializeForSalesforce($this->instance)),
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
            $response = $request->getContent() ? $request->toArray() : [];
            $sfId = $response['id'] ?? null;
            $opportunity->setSfId($sfId)->save();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    private function updateOpportunity(Opportunity $opportunity): ?string
    {
        $instance = strtolower($this->instance);
        $field = Opportunity::INSTANCE_NAMES[$instance] ?? '';
        $url = $this->sfUrl.'/services/data/v52.0/sobjects/Opportunity/ExternalID__c/'.$opportunity->getId().'-'.$field;
        $body = json_encode($opportunity->serializeForSalesforce($this->instance));
        $this->logger->debug(self::SALESFORCE_REQUEST, [$url, $body]);
        $request = $this->getClient()->request('PATCH', $url, [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => $body,
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    public function getToken()
    {
        if ($this->token) {
            return $this->token;
        }

        $body = [
            'grant_type' => 'password',
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'username' => $this->sfUser,
            'password' => $this->sfPassword,
        ];

        $response = $this->getClient()->request('POST', $this->sfUrl.'/services/oauth2/token', [
            'body' => $body,
        ]);

        $content = [];
        try {
            $content = $response->toArray();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            // continue
        }

        return $this->token = $content['access_token'] ?? null;
    }

    private function getClient()
    {
        return $this->client ?? $this->client = HttpClient::create(['timeout' => 7]);
    }

    private function getResponseMessage($request): string
    {
        $message = '';
        try {
            $content = $request->getContent() ? $request->toArray() : [];
            $message = $content['message'] ?? '';
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $content = [];
            try {
                $content = $request->toArray(false);
            } catch (\Exception $e) {
                // ignore
            }
            $this->logger->debug(self::SALESFORCE_RESPONSE, $content);
            $message = $content[0]['message'] ?? $content['message'] ?? $e->getMessage();
        }

        return $message;
    }

    public function pushContact(Contact $contact): string
    {
        if ($contact->getSfId()) {
            return $this->updateContact($contact);
        }

        return $this->createContact($contact);
    }

    private function createContact(Contact $contact): string
    {
        $request = $this->getClient()->request('POST', $this->sfUrl.'/services/data/v52.0/sobjects/Contact/', [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($contact->serializeForSalesforce()),
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
            $response = $request->getContent() ? $request->toArray() : [];
            $sfId = $response['id'] ?? null;
            $contact->setSfId($sfId)->save();
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }

    private function updateContact(Contact $contact): string
    {
        $instance = strtolower($this->instance);
        $field = self::CONTACT_ID_FIELD[$instance] ?? 'Contact_PM_TOOL_id__c';
        $url = $this->sfUrl.'/services/data/v52.0/sobjects/Contact/'.$field.'/'.$contact->getId();
        $request = $this->getClient()->request('PATCH', $url, [
            'headers' => [
                'Authorization' => 'Bearer '.$this->getToken(),
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($contact->serializeForSalesforce()),
        ]);
        try {
            $response = $request->getContent() ? $request->toArray() : [];
            $this->logger->debug(self::SALESFORCE_RESPONSE, $response);
            $message = $this->getResponseMessage($request);
            $response = $request->getContent() ? $request->toArray() : [];
        } catch (HttpExceptionInterface | TransportExceptionInterface $e) {
            $message = $e->getMessage();
            $message .= $this->getResponseMessage($request);
        }

        return $message;
    }
}
