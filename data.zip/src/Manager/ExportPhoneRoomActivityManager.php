<?php

namespace Manager;

use Model\CategoriePrestationQuery;
use Model\ImputationTypeQuery;
use Model\Location;
use Model\PhoneroomTarget;
use Model\User;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Propel\Runtime\Propel;
use Symfony\Component\HttpFoundation\Response;
use Util\DateFormat;

class ExportPhoneRoomActivityManager
{
    public function exportAction(string $myTime, ?string $periode, ?int $location, ?string $date, User $user, ?string $year): Response
    {
        ini_set('memory_limit', '512M');

        $fournisseurId = $user->getFournisseurId() ?? '';

        $targets = PhoneroomTarget::getAll()->toKeyValue('Id', 'Target');
        $chosenLocation = $location ? 'AND location_id = '.$location : '';
        $chosenDate = ($date && !$periode) ? 'AND phoneroom_activity.date = "'.DateFormat::getDateSQL($date).'" ' : '';
        $chosenPeriode = $periode ? "AND SUBSTRING(phoneroom_activity.date,1,7) = '$periode' " : '';
        $chosenUser = ('me' === $myTime && $fournisseurId) ? ' AND phoneroom_activity.fournisseur_id = '.$fournisseurId : '';
        $phoneroomDate = ('me' === $myTime) ? 'AND YEAR(date) = '.$year : '';

        $query = "SELECT DISTINCT phoneroom_activity.id, phoneroom_activity.id_location_pr,job.location_id ,
                fournisseur.nom,fournisseur.prenom,id_section,id_target,
                phoneroom_activity.date,phoneroom_activity.start_time,phoneroom_activity.end_time,break_time,nb_heure,
                unit_rate,bonus,cout, nb_recruitment,phone_station,numero_etude,theme,
                CONCAT(P.nom, ' ', P.prenom) AS project_manager, F.id_location_pr AS user_location
                FROM phoneroom_activity
                LEFT JOIN job on job.id = phoneroom_activity.job_id
                LEFT JOIN etude ON etude.id = job.etude_id
                LEFT JOIN user P ON etude.id_pm = P.id
                LEFT JOIN ref_industry on ref_industry.id = etude.industry_id
                JOIN fournisseur on fournisseur.id = phoneroom_activity.fournisseur_id
                LEFT JOIN user F ON fournisseur.id = F.fournisseur_id
                LEFT JOIN categorie_prestation cp ON phoneroom_activity.id_section = cp.id
                WHERE phoneroom_activity.valide = 'Y'
                $chosenPeriode $chosenLocation $chosenDate $chosenUser $phoneroomDate
                ORDER BY phoneroom_activity.date DESC,fournisseur.nom,fournisseur.prenom,start_time";

        $chosenPeriode = $periode ? "AND SUBSTRING(time_sheet.date,1,7) = '$periode' " : '';
        $chosenLocation = $location ? 'AND time_sheet.id_location = '.$location : '';
        $chosenDate = ($date && !$periode) ? 'AND time_sheet.date = "'.DateFormat::getDateSQL($date).'" ' : '';

        $projectManagerQuery = "SELECT DISTINCT time_sheet.id, time_sheet.id_categorie, time_sheet.id_location,etude.numero_etude,etude.theme, id_imputation,
                time_sheet.date,time_sheet.nb_heure,
                time_sheet.cout, time_sheet.taux_horaire, F.prenom, F.nom,
                CONCAT(P.nom, ' ', P.prenom) AS project_manager
                FROM time_sheet
                LEFT JOIN etude on etude.id = time_sheet.id_etude
                LEFT JOIN user P ON etude.id_pm = P.id
                LEFT JOIN categorie_prestation cp ON time_sheet.id_categorie = cp.id
                LEFT JOIN user ON time_sheet.id_user = user.id
                LEFT join fournisseur F on user.fournisseur_id = F.id
                LEFT JOIN imputation_type imputation on time_sheet.id_imputation = imputation.id
                WHERE time_sheet.valide = 'Y'
                AND (cp.category = 'Recruitment' OR cp.category = 'Recontact/Callback' OR imputation.imputation = 'Phoneroom Administration' OR imputation.imputation = 'Data Base / Panel')
                $chosenPeriode $chosenLocation $chosenDate
                ORDER BY time_sheet.date DESC,time_sheet.cutoff_periode";

        $con = Propel::getConnection();
        $stmt = $con->prepare($query);
        $stmt->execute();
        $donnees = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];
        $stmt = $con->prepare($projectManagerQuery);
        $stmt->execute();
        $donneesPm = $stmt->fetchAll(\PDO::FETCH_OBJ) ?: [];

        $workbook = new Spreadsheet();
        $sheet = $workbook->getActiveSheet();
        $sheet->setTitle('Phone Room Activity');
        $sheet->setCellValue('A1', 'Project number');
        $sheet->setCellValue('B1', 'Phone Room Location');
        $sheet->setCellValue('C1', 'Job Location');
        $sheet->setCellValue('D1', 'Recruiter');
        $sheet->setCellValue('E1', 'Task');
        $sheet->setCellValue('F1', 'Date');
        $sheet->setCellValue('G1', 'Master Project');
        $sheet->setCellValue('H1', 'Target');
        $sheet->setCellValue('I1', 'Phone Station');
        $sheet->setCellValue('J1', 'Start');
        $sheet->setCellValue('K1', 'End');
        $sheet->setCellValue('L1', 'Break');
        $sheet->setCellValue('M1', 'Work Time');
        $sheet->setCellValue('N1', 'Hourly Rate');
        $sheet->setCellValue('O1', 'Recruit Qty');
        $sheet->setCellValue('P1', 'Unit Bonus');
        $sheet->setCellValue('Q1', 'Total Cost');
        $sheet->setCellValue('R1', 'Project Manager');

        $categories = CategoriePrestationQuery::create()->find()->toKeyValue('Id', 'Categorie');
        $imputations = ImputationTypeQuery::create()->find()->toKeyValue('Id', 'Imputation');

        $ligneEnCours = 2;
        // edition des donneée des paies
        if ($donnees) {
            foreach ($donnees as $donnee) {
                $categorie = $categories[$donnee->id_section] ?? '';
                $sheet->setCellValue('A'.$ligneEnCours, $donnee->numero_etude);
                $sheet->setCellValue('B'.$ligneEnCours, Location::getNomLocation($donnee->user_location));
                $sheet->setCellValue('C'.$ligneEnCours, Location::getNomLocation($donnee->location_id));
                $sheet->setCellValue('D'.$ligneEnCours, $donnee->nom.' '.$donnee->prenom);
                $sheet->setCellValue('E'.$ligneEnCours, $categorie);
                $sheet->setCellValue('F'.$ligneEnCours, DateFormat::getDateFrancaise($donnee->date));
                $sheet->setCellValue('G'.$ligneEnCours, $donnee->numero_etude.' - '.$donnee->theme);
                $sheet->setCellValue('H'.$ligneEnCours, $targets[$donnee->id_target] ?? '');
                $sheet->setCellValue('I'.$ligneEnCours, $donnee->phone_station);
                $sheet->setCellValue('J'.$ligneEnCours, $donnee->start_time);
                $sheet->setCellValue('K'.$ligneEnCours, $donnee->end_time);
                $sheet->setCellValue('L'.$ligneEnCours, $donnee->break_time);
                $sheet->setCellValue('M'.$ligneEnCours, $donnee->nb_heure);
                $sheet->setCellValue('N'.$ligneEnCours, $user->isPhoneroomUser() ? '-' : $donnee->unit_rate);
                $sheet->setCellValue('O'.$ligneEnCours, $donnee->nb_recruitment);
                $sheet->setCellValue('P'.$ligneEnCours, $donnee->bonus);
                $sheet->setCellValue('Q'.$ligneEnCours, $user->isPhoneroomUser() ? '-' : $donnee->cout);
                $sheet->setCellValue('R'.$ligneEnCours, $donnee->project_manager);
                ++$ligneEnCours;
            }
        }

        if ($donneesPm) {
            foreach ($donneesPm as $donnee) {
                $imputation = '';
                if (null !== $donnee->id_imputation && in_array($donnee->id_imputation, [4, 8])) {
                    $imputation = $imputations[$donnee->id_imputation];
                } elseif (null !== $donnee->id_categorie) {
                    $imputation = $categories[$donnee->id_categorie];
                }
                $sheet->setCellValue('A'.$ligneEnCours, $donnee->numero_etude);
                $sheet->setCellValue('B'.$ligneEnCours, Location::getNomLocation($donnee->id_location));
                $sheet->setCellValue('D'.$ligneEnCours, $donnee->nom.' '.$donnee->prenom);
                $sheet->setCellValue('E'.$ligneEnCours, $imputation);
                $sheet->setCellValue('F'.$ligneEnCours, DateFormat::getDateFrancaise($donnee->date));
                $sheet->setCellValue('G'.$ligneEnCours, $donnee->numero_etude.' - '.$donnee->theme);
                $sheet->setCellValue('M'.$ligneEnCours, $donnee->nb_heure);
                $sheet->setCellValue('N'.$ligneEnCours, $donnee->taux_horaire);
                $sheet->setCellValue('Q'.$ligneEnCours, $donnee->cout);
                $sheet->setCellValue('R'.$ligneEnCours, $donnee->project_manager);
                ++$ligneEnCours;
            }
        }
        $writer = new Xlsx($workbook);
        $filename = $periode ?: ($date ?: 'timesheet_'.$year);

        $response = new Response();
        $response->headers->set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $response->headers->set('Content-Disposition', 'attachment;filename="'.$filename.'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');
        $response->sendHeaders();
        $writer->save('php://output');

        return $response;
    }
}
