<?php

namespace Manager;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Symfony\Component\HttpFoundation\Response;

class SpreadsheetManager
{
    public function importSingleSheet(string $filename, string $sheetName): Spreadsheet
    {
        // Ignores a bug in PHPSpreadSheet. see #16760
        $errorReporting = error_reporting();
        error_reporting($errorReporting & ~E_NOTICE & ~E_WARNING);
        $reader = IOFactory::createReaderForFile($filename);
        $reader->setLoadSheetsOnly($sheetName);
        $spreadsheet = $reader->load($filename);
        error_reporting($errorReporting);

        return $spreadsheet;
    }

    public function importFile(string $filename): Spreadsheet
    {
        // Ignores a bug in PHPSpreadSheet. see #16760
        $errorReporting = error_reporting();
        error_reporting($errorReporting & ~E_NOTICE & ~E_WARNING);
        $spreadsheet = IOFactory::load($filename);
        error_reporting($errorReporting);

        return $spreadsheet;
    }

    public function setHeader(Worksheet $sheet, array $header): void
    {
        foreach ($header as $id => $name) {
            $columnIndex = $id + 1;
            $sheet->setCellValueByColumnAndRow($columnIndex, 1, $name);
            $sheet->getStyleByColumnAndRow($columnIndex, 1)->getFont()->setBold(true);
            $sheet->getColumnDimensionByColumn($columnIndex)->setAutoSize(true);
        }
    }

    public function setRowData(Worksheet $sheet, int $rowIndex, array $data): void
    {
        foreach ($data as $id => $item) {
            $sheet->setCellValueByColumnAndRow($id + 1, $rowIndex, $item);
        }
    }

    public function createResponse(Spreadsheet $spreadsheet, string $title): Response
    {
        $response = new Response();
        $response->headers->set('Content-Type', 'application/vnd.ms-excel');
        $response->headers->set('Content-Disposition', 'attachment;filename="'.$title.'.xlsx"');
        $response->headers->set('Cache-Control', 'max-age=0');
        $response->sendHeaders();

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');

        return $response;
    }

    public function setColumnWidth($sheet, $rows, $size)
    {
        foreach ($rows as $row) {
            $sheet->getColumnDimension($row)->setWidth($size);
        }
    }

    public function setAutoColumnWidth($sheet, string $lower, string $upper): void
    {
        foreach ($this->columnRange($lower, $upper) as $columnID) {
            $sheet->getColumnDimension($columnID)->setAutoSize(true);
        }
    }

    public function columnRange(string $lower, string $upper)
    {
        ++$upper;
        for ($i = $lower; $i !== $upper; ++$i) {
            yield $i;
        }
    }

    public function setTitleSheet($sheet, $cell, $title, $fontsize = 12)
    {
        $sheet->setCellValue($cell, $title);
        $sheet->getStyle($cell)->getFont()->setBold(true);
        $sheet->getStyle($cell)->getFont()->setSize($fontsize);
    }
}
