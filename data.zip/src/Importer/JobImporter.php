<?php

namespace Importer;

use Manager\SpreadsheetManager;
use Model\BidJobItemQuery;
use Model\CategoriePrestationQuery;
use Model\FournisseurQuery;
use Model\Job;
use Model\JobCost;
use Model\JobCostQuery;
use Model\JobItem;
use Model\JobItemQuery;
use Model\Map\JobCostTableMap;
use Model\RefSalesForceQuery;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class JobImporter
{
    public function upload(Job $job, bool $isJobItemsImport, string $type, UploadedFile $uploadedFile, SpreadsheetManager $spreadsheetManager)
    {
        $spreadsheet = $spreadsheetManager->importFile($uploadedFile);
        $firstWorksheet = $spreadsheet->getSheet(0);
        $rows = [];
        foreach ($firstWorksheet->getRowIterator() as $row) {
            $cellIterator = $row->getCellIterator();
            $cells = [];
            foreach ($cellIterator as $cell) {
                $cells[] = $cell->getValue();
            }
            $rows[] = $cells;
        }

        if (count($rows) > 1) {
            array_shift($rows);

            if ($isJobItemsImport) {
                if ('create' == $type) {
                    JobItemQuery::create()->filterByJobId($job->getId())->delete();
                } else {
                    $bidJobItemDiscountAuto = BidJobItemQuery::create()->filterByBidJobId($job->getId())->filterByDiscountAuto(true);
                    foreach ($bidJobItemDiscountAuto as $bidJobItemDA) {
                        $bidJobItemDA->delete();
                    }
                    foreach ($job->getJobItems() as $jobItem) {
                        $jobItem->setPmtoolUpdated(true);
                    }
                }
                $this->importJobItemsLines($rows, $job);
            } else {
                JobCostQuery::create()
                    ->filterByJobId($job->getId())
                    ->filterBySource(JobCostTableMap::COL_SOURCE_AUTO, Criteria::EQUAL)
                    ->update(['Group' => -100]);
                if ('create' == $type) {
                    JobCostQuery::create()
                        ->filterByJobId($job->getId())
                        ->filterBySource(JobCostTableMap::COL_SOURCE_AUTO, Criteria::NOT_EQUAL)
                        ->delete();
                }

                $this->importJobCostsLines($rows, $job);
            }
            $job->jobDiscount()->save();
        }
    }

    private function importJobItemsLines(array $rows, Job $job)
    {
        $groupOrder = $subGroupOrder = -1;
        $groupTitle = $subGroupTitle = null;
        foreach ($rows as $row) {
            if (null == $row[0] && null == $row[1] && null == $row[2] && null == $row[3] && null == $row[5] && null == $row[6]) {
                break;
            }
            if (count($row) < 18) {
                continue;
            }
            $date = is_numeric($row[7]) ? Date::excelToTimestamp($row[7]) : null;
            $groupTitleSheet = $row[16];
            $subGroupTitleSheet = $row[17];
            if ($groupTitle != $groupTitleSheet) {
                $groupTitle = $groupTitleSheet;
                ++$groupOrder;
            }
            if ($subGroupTitle != $subGroupTitleSheet && '' != $subGroupTitleSheet) {
                $subGroupTitle = $subGroupTitleSheet;
                ++$subGroupOrder;
            }

            $section = CategoriePrestationQuery::create()->filterByConsolidation($row[0])->filterByCategory($row[1])->findOne();
            $respType = RefSalesForceQuery::create()->filterByField('respondent_type')->findOneByValue($row[3]);
            $vendor = FournisseurQuery::create()->findOneBySociete($row[4]);
            $respLocation = RefSalesForceQuery::create()->filterByField('respondent_location_id')->findOneByValue($row[5]);
            $methodology = RefSalesForceQuery::create()->filterByField('methodology')->findOneByValue($row[6]);
            $jobItem = (new JobItem())
                ->setCategory($row[0])
                ->setCategoriePrestation($section)
                ->setSousTypePrestation($row[2])
                ->setRespondentType($respType)
                ->setVendor($vendor)
                ->setRespLocation($respLocation)
                ->setMethodology($methodology)
                ->setDate($date)
                ->setQuantitePv($row[8])
                ->setPrixVenteUnitaire($row[9])
                ->setPrixVente($row[10])
                ->setQuantitePr($row[11])
                ->setPrixRevientUnitaire('' != $row[13] ?: $row[12])
                ->setPrixVenteUnitaireLocation($row[12])
                ->setCoefficiantPr($row[14])
                ->setPrixRevient($row[15])
                ->setGroup($groupOrder)
                ->setGroupTitle($groupTitle)
                ->setSuperGroup($subGroupOrder)
                ->setSuperGroupTitle($subGroupTitle)
                ->setJob($job);
        }
    }

    private function importJobCostsLines(array $rows, Job $job)
    {
        $groupOrder = 0;
        $groupTitle = null;
        foreach ($rows as $row) {
            if (null == $row[0] && null == $row[1] && null == $row[2] && null == $row[3] && null == $row[5] && null == $row[6]) {
                break;
            }
            if (count($row) < 17) {
                continue;
            }
            $groupTitleSheet = $row[16];
            if ($groupTitle != $groupTitleSheet) {
                $groupTitle = $groupTitleSheet;
                ++$groupOrder;
            }

            $date = is_numeric($row[7]) ? Date::excelToTimestamp($row[7]) : null;
            $section = CategoriePrestationQuery::create()->filterByConsolidation($row[0])->filterByCategory($row[1])->findOne();
            $respType = RefSalesForceQuery::create()->filterByField('respondent_type')->findOneByValue($row[3]);
            $vendor = FournisseurQuery::create()->findOneBySociete($row[4]);
            $respLocation = RefSalesForceQuery::create()->filterByField('respondent_location_id')->findOneByValue($row[5]);
            $methodology = RefSalesForceQuery::create()->filterByField('methodology')->findOneByValue($row[6]);
            $jobCost = (new JobCost())
                ->setCategory($row[0])
                ->setCategoriePrestation($section)
                ->setSousTypePrestation($row[2])
                ->setRespondentType($respType)
                ->setFournisseur($vendor)
                ->setRespLocation($respLocation)
                ->setMethodology($methodology)
                ->setDate($date)
                ->setQuantitePr($row[11])
                ->setPrixVenteUnitaireLocation($row[12])
                ->setUnitPrice($row[13])
                ->setCoefficiant($row[14])
                ->setPrixRevient($row[15])
                ->setGroup($groupOrder)
                ->setGroupTitle($groupTitle)
                ->setJob($job);
        }
    }
}
