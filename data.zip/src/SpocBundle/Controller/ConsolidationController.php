<?php

namespace SpocBundle\Controller;

use Model\ConsolidatedProject;
use Model\EtudeQuery;
use SpocBundle\Form\ConsolidatedType;
use SpocBundle\Manager\DatabaseManager;
use SpocBundle\Service\EtudeService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/spoc")
 */
class ConsolidationController extends AbstractController
{
    /**
     * @Route("/project_consolidation", name="consolidation")
     */
    public function create(Request $request): Response
    {
        $consolidatedProject = new ConsolidatedProject();
        $form = $this->createForm(ConsolidatedType::class, $consolidatedProject, ['edit' => false]);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $consolidatedProject = $form->getData();
                if ($consolidatedProject->getFrProjectId()) {
                    $etudeFr = (new EtudeQuery(DatabaseManager::PMTOOL_FR))->findOneById($consolidatedProject->getFrProjectId());
                    $etudeFr->setIsConsolidated(true);
                    $etudeFr->save();
                }
                if ($consolidatedProject->getUkProjectId()) {
                    $etudeUk = (new EtudeQuery(DatabaseManager::PMTOOL_UK))->findOneById($consolidatedProject->getUkProjectId());
                    $etudeUk->setIsConsolidated(true);
                    $etudeUk->save();
                }
                if ($consolidatedProject->getUsProjectId()) {
                    $etudeUs = (new EtudeQuery(DatabaseManager::PMTOOL_US))->findOneById($consolidatedProject->getUsProjectId());
                    $etudeUs->setIsConsolidated(true);
                    $etudeUs->save();
                }
                if ($consolidatedProject->getEsProjectId()) {
                    $etudeEs = (new EtudeQuery(DatabaseManager::PMTOOL_ES))->findOneById($consolidatedProject->getEsProjectId());
                    $etudeEs->setIsConsolidated(true);
                    $etudeEs->save();
                }
                if ($consolidatedProject->getDeProjectId()) {
                    $etudeDe = (new EtudeQuery(DatabaseManager::PMTOOL_DE))->findOneById($consolidatedProject->getDeProjectId());
                    $etudeDe->setIsConsolidated(true);
                    $etudeDe->save();
                }
                $consolidatedProject->save();
                $this->addFlash('success', 'Consolidated Project created');

                return $this->redirectToRoute('project_show', ['id' => $consolidatedProject->getId()]);
            } else {
                $this->addFlash('warning', 'Consolidated Project has not been created');
            }
        }

        return $this->render('spoc/consolidated/consolidated.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/project/show/{id}", name="project_show")
     */
    public function showAction(ConsolidatedProject $consolidatedProject, Request $request, EtudeService $etudeService): Response
    {
        ini_set('memory_limit', '512M');
        $form = $this->createForm(ConsolidatedType::class, $consolidatedProject, ['edit' => true]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $consolidatedProject = $form->getData();
            $consolidatedProject->save();
            $this->addFlash('success', 'Consolidated Project updated');

            return $this->redirectToRoute('project_show', ['id' => $consolidatedProject->getId()]);
        }

        $etudes = $etudeService->getProjectsByConsolidation($consolidatedProject);
        $etudeJobs = $etudeService->getJobsByConsolidateProject($consolidatedProject);
        $clients = $etudeService->consolidationEtudeClient($consolidatedProject);
        $summaries = [];
        foreach ($etudes as $key => $etude) {
            $summaries[$key] = $etudeService->getSummaryTbody($etude, $key);
        }

        return $this->render('spoc/etude/show.html.twig', [
            'consolidatedProject' => $consolidatedProject,
            'etudes' => $etudes,
            'form' => $form->createView(),
            'etudeJobs' => $etudeJobs,
            'clients' => $clients,
            'summaries' => $summaries,
            'countries' => DatabaseManager::COUNTRIES,
        ]);
    }
}
