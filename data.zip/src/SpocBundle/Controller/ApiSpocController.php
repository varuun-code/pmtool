<?php

namespace SpocBundle\Controller;

use SpocBundle\Service\EtudeService;
use SpocBundle\Service\PmCapacityService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/spoc/api/")
 */
class ApiSpocController extends AbstractController
{
    /**
     * @Route("pmcapacity", name="api_pmcapacity_list")
     */
    public function getPmCapacity(PmCapacityService $pmCapacityService): JsonResponse
    {
        return $this->json($pmCapacityService->getPmCapacityDatas());
    }

    /**
     * @Route("teamnotes", name="api_teamnotes_list")
     */
    public function getTeamNotes(PmCapacityService $pmCapacityService): JsonResponse
    {
        return $this->json($pmCapacityService->getTeamNotes());
    }

    /**
     * @Route("etudes/global_details/{id}", name="api_get_etudes_globalDetails")
     */
    public function getEtudeGlobalDetails(Request $request, EtudeService $etudeService, int $id): JsonResponse
    {
        return $this->json($etudeService->getEtudeGlobalDetails($id));
    }

    /**
     * @Route("etudes_jobitems/{jobId}/{database_instance}", name="api_get_consolidation_jobitems")
     */
    public function getConsolidationJobItems(Request $request, EtudeService $etudeService, int $jobId, string $database_instance): JsonResponse
    {
        return $this->json($etudeService->getConsolidationJobItems($jobId, $database_instance));
    }

    /**
     * @Route("etudes_jobcosts/{jobId}/{database_instance}", name="api_get_consolidation_jobcosts")
     */
    public function getConsolidationJobCosts(Request $request, EtudeService $etudeService, int $jobId, string $database_instance): JsonResponse
    {
        return $this->json($etudeService->getConsolidationJobCosts($jobId, $database_instance));
    }

    /**
     * @Route("etudes_event_modules/{jobId}/{database_instance}", name="api_get_consolidation_event_module")
     */
    public function getConsolidationEventModules(Request $request, EtudeService $etudeService, int $jobId, string $database_instance): JsonResponse
    {
        return $this->json($etudeService->getConsolidationEventModules($jobId, $database_instance));
    }
}
