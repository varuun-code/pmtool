<?php

namespace SpocBundle\Controller;

use Model\ConsolidatedProjectQuery;
use Model\EtudeQuery;
use Model\Location;
use Model\LocationQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use SpocBundle\Manager\DatabaseManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/spoc")
 */
class RechercheController extends AbstractController
{
    /**
     * @Route("/project/recherche/", name="recherche_project")
     */
    public function indexAction(): Response
    {
        ini_set('memory_limit', '512M');
        $consolidatedProjects = ConsolidatedProjectQuery::create()->find();
        if (!$consolidatedProjects) {
            $this->addFlash('warning', 'There is no consolidation project yet.');

            return $this->redirectToRoute('pm_capacity');
        }

        return $this->render('spoc/etude/recherche.html.twig', [
            'consolidatedProjects' => $consolidatedProjects,
        ]);
    }

    /**
     * @Route("search/consolidate/project/list", name="search_consolidate_project_list")
     */
    public function getSearchConsolidateTable(Request $request, DatabaseManager $manager): JsonResponse
    {
        $data = [];
        $accountName = $ref = $mPnumber = $step = $refClient = $masterPM = $salesManager = $startedDate = $startedDate = $endedDate = $invoiceDate = '';
        $prixVenteActualise = $prixRevientActualise = $actualMarginPercentage = $recrutObjectif = 0;

        $consolidations = ConsolidatedProjectQuery::create()->find();
        foreach ($consolidations as $key => $consolidation) {
            $consolidation_ids_instances = [
                DatabaseManager::DATABASES['FR'] => $consolidation->getFrProjectId(),
                DatabaseManager::DATABASES['US'] => $consolidation->getUsProjectId(),
                DatabaseManager::DATABASES['ES'] => $consolidation->getEsProjectId(),
                DatabaseManager::DATABASES['DE'] => $consolidation->getDeProjectId(),
                DatabaseManager::DATABASES['UK'] => $consolidation->getUkProjectId(),
            ];
            foreach ($consolidation_ids_instances as $instance => $id) {
                if (is_int($id)) {
                    $conn = $manager->getReadConnection($instance);
                    $location = (new LocationQuery($instance))->filterByLibelle(Location::GQS_SPOC, Criteria::IN)->find();
                    $etude = EtudeQuery::create()->filterByEtudeLocation($location, Criteria::NOT_IN)->findPk($id, $conn);
                    if ($etude) {
                        $ref .= $etude->getNumeroEtude() ? $etude->getNumeroEtude().'</br> ' : ' ';
                        $accountName .= $etude->getAccount($conn) ? $etude->getAccount($conn)->getName().'</br> ' : ' ';
                        $mPnumber .= $etude->getMasterProjectNumber().'</br> ';
                        $step .= $etude->getEtape($conn) ? $etude->getEtape($conn).'</br> ' : ' ';
                        $refClient .= $etude->getReferenceClient() ? $etude->getReferenceClient().'</br> ' : ' ';
                        $masterPM .= $etude->getEtudeProjectManager($conn) ? $etude->getEtudeProjectManager($conn).'</br> ' : ' ';
                        $salesManager .= $etude->getBM($conn) ? $etude->getBM($conn).'</br> ' : ' ';
                        $recrutObjectif += $etude->getRecrutementObjectif();
                        $invoiceDate .= $etude->getDateEnvoiFacture() ? $etude->getDateEnvoiFacture()->format('Y-m-d').'</br> ' : ' ';
                        $startedDate .= $etude->getDateDebut() ? $etude->getDateDebut()->format('Y-m-d').'</br> ' : ' ';
                        $endedDate .= $etude->getDateFin() ? $etude->getDateFin()->format('Y-m-d').'</br> ' : ' ';
                        $prixVenteActualise += $etude->getPrixVenteActualise();
                        $prixRevientActualise += $etude->getPrixRevientActualise();
                        $actualMarginPercentage += $etude->getActualMarginPercentage();
                    }
                }
            }

            // Manage started & ended date by chosen the smallest and bigest of the etudes array in each consolidation
            $startedDateArr = explode(',', $startedDate);
            $endedDateArr = explode(',', $endedDate);

            $startdatetoCompare = [];
            $endDatetoCompare = [];
            foreach ($startedDateArr as $dateKey => $date) {
                if ('' != $date) {
                    $startdatetoCompare[$dateKey] = strtotime($date);
                }
            }
            foreach ($endedDateArr as $dateKey => $date) {
                if ('' != $date) {
                    $endDatetoCompare[$dateKey] = strtotime($date);
                }
            }

            $data[$key] = [
                'Project Id' => $consolidation->getId(),
                'PM TOOL Ref' => $ref,
                'Salesforce project Number' => $mPnumber,
                'Cut-Off' => '',
                'Step' => $step,
                'Client' => $accountName,
                'Client ref' => $refClient,
                'Project Manager' => $masterPM,
                'Sales Manager' => $salesManager,
                'Subject' => $consolidation->getProjectName(),
                'Started date' => $startedDate,
                'Ended date' => $endedDate,
                'Invoice date' => $invoiceDate,
                'Recruit Objectif' => $recrutObjectif,
                'Revenue' => $prixVenteActualise,
                'Costs' => $prixRevientActualise,
                'Margin' => number_format($actualMarginPercentage, '1', '.', ''),
            ];

            $prixVenteActualise = $prixRevientActualise = $actualMarginPercentage = $recrutObjectif = 0;
            $accountName = $ref = $masterPM = $mPnumber = $step = $refClient = $salesManager = $startedDate = $endedDate = $invoiceDate = '';
        }

        return $this->json(['data' => $data]);
    }
}
