<?php

namespace SpocBundle\Controller;

use Model\SpocDatas;
use Model\SpocDatasQuery;
use Model\UserQuery;
use SpocBundle\Form\TeamNotesType;
use SpocBundle\Form\UserType;
use SpocBundle\Manager\DatabaseManager;
use SpocBundle\Service\PmCapacityService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/spoc")
 */
class DefaultController extends AbstractController
{
    /**
     * @Route("/", name="spoc_index")
     */
    public function index(DatabaseManager $manager): Response
    {
        return $this->redirectToRoute('pm_capacity');
    }

    /**
     * Display data from route: api_pmcapacity_list.
     *
     * @Route("/pmcapacity", name="pm_capacity")
     */
    public function pmCapacity(): Response
    {
        return $this->render('spoc/pmcapacity.html.twig');
    }

    /**
     * @Route("/edit/notes/{team}/{id}", name="api_edit_note")
     */
    public function postEditNotes(Request $request, DatabaseManager $manager, string $team, int $id): Response
    {
        if (!isset(DatabaseManager::DATABASES[$team])) {
            throw $this->createNotFoundException();
        }

        $conn = $manager->getReadConnection(DatabaseManager::DATABASES[$team]);
        $user = UserQuery::create()->findPk($id, $conn);
        $form = $this->createForm(UserType::class, $user);
        $form->add('submit', SubmitType::class, [
            'label' => 'Update',
            'attr' => ['onclick' => 'closeMyIframe()'],
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $form->getData()->save($conn);
        }

        return $this->render('spoc/formNotes.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/edit/teamnotes", name="edit_teamnotes")
     */
    public function postEditTeamNotes(Request $request, PmCapacityService $manager): Response
    {
        $spocDatas = SpocDatasQuery::create()->filterBySlug('team-notes')->findOne() ?? new SpocDatas();
        $form = $this->createForm(TeamNotesType::class, $spocDatas);
        $form->add('submit', SubmitType::class, [
            'label' => 'Save Notes',
        ]);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $form->getData()
                ->setSlug('team-notes')
                ->save();

            return $this->redirectToRoute('pm_capacity');
        }

        return $this->render('spoc/editTeamNotes.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
