<?php

namespace SpocBundle\Controller;

use Model\AccountQuery;
use Model\SpocProjectManager;
use Model\SpocProjectManagerQuery;
use Model\UserQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use SpocBundle\Form\ClientTeamType;
use SpocBundle\Form\ManageClientType;
use SpocBundle\Manager\DatabaseManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/spoc")
 */
class AccountController extends AbstractController
{
    /**
     * @Route("/client/team", name="client_team")
     */
    public function selectClient(Request $request): Response
    {
        $accounts = [];
        $form = $this->createForm(ClientTeamType::class);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $accounts = $form->getData();
            }
        }

        return $this->render('spoc/client/client_team.html.twig', [
            'form' => $form->createView(),
            'accounts' => $accounts,
        ]);
    }

    /**
     * Generic function to register clients data sended via ajax in database.
     */
    private function registerClientsDatas(array $clientsDatas, DatabaseManager $manager)
    {
        foreach ($clientsDatas as $oneClientData) {
            if ('' !== $oneClientData['pmTeamLeaderInstance'] || is_int($oneClientData['pmTeamLeaderId']) || strlen($oneClientData['allPmData']) >= 0 || '' !== $oneClientData['notes']) {
                $pmDataFromJS = explode(',', $oneClientData['allPmData']);
                $allPm = [];
                foreach ($pmDataFromJS as $k => $item) {
                    $pos = strpos($item, '|');
                    $id = substr($item, 0, -1);
                    $instance = substr($item, $pos + 2, strlen($item));
                    $allPm[$k]['user_id'] = (int) $id;
                    $allPm[$k]['instance'] = $instance;
                }

                // Manage Notes and eu-sponsor
                $clientId = (int) $oneClientData['client_id'];
                $clientActualInstance = AccountQuery::create()->filterBySfId($oneClientData['sf_id'])->findOneById($clientId);
                if (strlen($oneClientData['eu_sponsor']) > 0) {
                    $clientActualInstance->setEuSponsor($oneClientData['eu_sponsor']);
                    $clientActualInstance->save();
                }
                $clientActualInstance->setSpocNotes($oneClientData['notes'] ?: null)->save();

                // Manage PM Team Leader
                $existPmTeamLeader = SpocProjectManagerQuery::create()->filterBySfId($oneClientData['sf_id'])->findOneByType('pm_team_leader');
                if (is_int($oneClientData['pmTeamLeaderId'])) {
                    if (!$existPmTeamLeader) {
                        $existPmTeamLeader = new SpocProjectManager();
                        $existPmTeamLeader->setSfId($oneClientData['sf_id']);
                        $existPmTeamLeader->setType('pm_team_leader');
                    }
                    $existPmTeamLeader->setUserId($oneClientData['pmTeamLeaderId']);
                    $existPmTeamLeader->setInstance($oneClientData['pmTeamLeaderInstance']);
                    $existPmTeamLeader->save();
                } else {
                    if ($existPmTeamLeader) {
                        $existPmTeamLeader->delete();
                    }
                }

                // Manage ALL PM
                $pmUserId_instance_Collection_exist = SpocProjectManagerQuery::create()->filterBySfId(($oneClientData['sf_id']))->filterByType('pm')->find();
                foreach ($allPm as $pm) {
                    $isOk = false;
                    foreach ($pmUserId_instance_Collection_exist as $pmExist) {
                        $pmExist_datas = ['user_id' => $pmExist->getUserId(), 'instance' => $pmExist->getInstance(), 'sf_id' => $pmExist->getSfId()];
                        $pmData = ['user_id' => $pm['user_id'], 'instance' => $pm['instance'], 'sf_id' => $oneClientData['sf_id']];

                        if ($pmData == $pmExist_datas) {
                            $isOk = true;
                        }
                    }
                    if (!$isOk && $pm['instance']) {
                        $newPm = new SpocProjectManager();
                        $newPm->setSfId($oneClientData['sf_id']);
                        $newPm->setType('pm');
                        $newPm->setUserId($pm['user_id']);
                        $newPm->setInstance($pm['instance']);
                        $newPm->save();
                    }
                }

                foreach ($pmUserId_instance_Collection_exist as $pmExist) {
                    $toDelete = true;
                    foreach ($allPm as $pm) {
                        $pmExist_datas = ['user_id' => $pmExist->getUserId(), 'instance' => $pmExist->getInstance()];
                        $pmData = ['user_id' => $pm['user_id'], 'instance' => $pm['instance']];
                        if ($pmData == $pmExist_datas) {
                            $toDelete = false;
                        }
                    }
                    if ($toDelete) {
                        $pmExist->delete();
                    }
                }
            }
        }
    }

    /**
     * @Route("/client/manage/team", name="manage_client_team", methods={"GET","POST"})
     */
    public function clientProjectManager(Request $request, DatabaseManager $manager, $accounts = null): Response
    {
        $form2 = $this->createForm(ManageClientType::class, null, ['accounts_data' => []]);
        $clients = null;

        if ($request->isXmlHttpRequest() && $request->isMethod('post')) {
            $clientsDatas = json_decode($request->request->get('data'), true);
            $this->registerClientsDatas($clientsDatas, $manager);

            return $this->json([
                'status' => 'OK',
                'message' => 'Saved',
            ]);
        }

        // $account get from 'spoc/client/client_team.html.twig' render to this controller by {{ render(controller() }} on the template
        if (!is_null($accounts)) {
            $clients = array_filter($accounts);
            $form2 = $this->createForm(ManageClientType::class, null, ['accounts_data' => $clients]);

            return $this->render('spoc/client/manage_client_team.html.twig', [
                'form2' => $form2->createView(),
                'clients' => $clients,
            ]);
        }

        return $this->render('spoc/client/manage_client_team.html.twig', [
            'form2' => $form2 ? $form2->createView() : null,
            'clients' => $clients ? $clients : null,
        ]);
    }

    private function getInitialPMTeamLeaderOrPMArrayForClientTeam($params, bool $isPmLeader)
    {
        $initUserInstance = strtoupper($params->getInstance());
        $location = strtolower('pmtool_'.$initUserInstance);
        $user = (new UserQuery($location))->filterByisPmTeamLeader($isPmLeader)->findOneById($params->getUserId());
        $text = $user ? $user->getNomCompletforPicklist().' ('.strtoupper($initUserInstance).')' : '';

        return $user ? [
            'id' => $user->getId().' | '.strtolower($initUserInstance),
            'text' => $text,
            'name' => $text,
            'sfid' => $params->getSfId(),
        ] : [];
    }

    /**
     * @Route("/pm-team-leader/search-by-name-init", name="client_team_all_data_init")
     */
    public function searchClientTeamInitDatas(Request $request): JsonResponse
    {
        $clientsDatas = json_decode($request->request->get('data'), true);
        $pmTeamleaders = [];
        $existPms = [];
        $result = [];
        $sfIds = [];

        foreach ($clientsDatas as $clientSfid) {
            $sfIds[] = $clientSfid['sfid'];
        }

        foreach ($sfIds as $sfid) {
            $pmTeamleaders[] = SpocProjectManagerQuery::create()->filterBySfId($sfid)->findOneByType('pm_team_leader');
            $existPms[$sfid] = SpocProjectManagerQuery::create()->filterBySfId($sfid)->findByType('pm')->getData();
            $existPms[$sfid] = array_filter($existPms[$sfid]);

            foreach ($existPms[$sfid] as $pm) {
                if ($pmResult = $this->getInitialPMTeamLeaderOrPMArrayForClientTeam($pm, false)) {
                    $result['pm'][] = $pmResult;
                }
            }
        }

        $pmTeamleaders = array_filter($pmTeamleaders);
        foreach ($pmTeamleaders as $pmTeamLeader) {
            if ($pmTeamleaderResult = $this->getInitialPMTeamLeaderOrPMArrayForClientTeam($pmTeamLeader, true)) {
                $result['pmTeamLeader'][] = $pmTeamleaderResult;
            }
        }

        return $this->json([
            'results' => $result,
        ]);
    }

    /**
     * @Route("/pm-team-leader/all-instances/search-by-name", name="all_pm_team_leader_instances_search_by_name")
     */
    public function getAllPmTeamLeadersAndInstances(Request $request): JsonResponse
    {
        $term = $request->get('term');
        $limit = $request->get('max_per_page', 10);
        $result = [];
        $total = 0;
        $offset = ($request->get('page', 0) - 1) * $limit;

        foreach (DatabaseManager::DATABASES as $instance) {
            $results[$instance] = (new UserQuery($instance))->filterByisPmTeamLeader(true)
                ->_if($term)
                ->filterByNom('%'.$term.'%', Criteria::LIKE)
                ->_or()
                ->filterByPrenom('%'.$term.'%', Criteria::LIKE)
                ->_or()
                ->filterByMail('%'.$term.'%', Criteria::LIKE)
                ->_endif()
                ->_if($id = $request->get('id'))
                ->filterById($id)
                ->_endif()
                ->limit($limit)
                ->offset($offset)
                ->find();
        }

        foreach ($results as $instance => $collection) {
            foreach ($collection as $user) {
                $text = $user->getNomCompletforPicklist().' ('.strtoupper(str_replace('pmtool_', '', $instance)).')';
                $location = str_replace('pmtool_', '', $instance);
                $result[] = [
                    'id' => $user->getId().' | '.$location,
                    'text' => $text,
                    'name' => $text,
                ];
            }
        }

        return $this->json([
            'maxPerPage' => $limit,
            'results' => $result,
            'total' => $total,
        ]);
    }

    /**
     * @Route("/pm/all-instances/search-by-name", name="all_pm_instances_search_by_name")
     */
    public function getAllPMandInstances(Request $request): JsonResponse
    {
        $term = $request->get('term');
        $limit = $request->get('max_per_page', 10);
        $result = [];
        $total = 0;
        $offset = ($request->get('page', 0) - 1) * $limit;

        foreach (DatabaseManager::DATABASES as $instance) {
            $results[$instance] = (new UserQuery($instance))->filterByIdGroupe(2)
                ->_if($term)
                ->filterByNom('%'.$term.'%', Criteria::LIKE)
                ->_or()
                ->filterByPrenom('%'.$term.'%', Criteria::LIKE)
                ->_or()
                ->filterByMail('%'.$term.'%', Criteria::LIKE)
                ->_endif()
                ->_if($id = $request->get('id'))
                ->filterById($id)
                ->_endif()
                ->limit($limit)
                ->offset($offset)
                ->find();
        }

        foreach ($results as $instance => $collection) {
            foreach ($collection as $user) {
                $text = $user->getNomCompletforPicklist().' ('.strtoupper(str_replace('pmtool_', '', $instance)).')';
                $location = str_replace('pmtool_', '', $instance);
                $result[] = [
                    'id' => $user->getId().' | '.$location,
                    'text' => $text,
                    'name' => $text,
                ];
            }
        }

        return $this->json([
            'maxPerPage' => $limit,
            'results' => $result,
            'total' => $total,
        ]);
    }

    /**
     * @Route("/client/search-by-name", name="spoc_account_search_by_name")
     */
    public function searchByName(Request $request): JsonResponse
    {
        $term = $request->get('term');
        $limit = $request->get('max_per_page', 10);
        $result = [];
        $total = 0;
        $offset = ($request->get('page', 0) - 1) * $limit;

        $results = AccountQuery::create()->filterByActiveStatusId()
            ->_if($term)
            ->filterByName('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByBillingState('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->useAccountDetailQuery(null, Criteria::LEFT_JOIN)
            ->filterByDebtorNumber('%'.$term.'%', Criteria::LIKE)
            ->endUse()
            ->_endif()
            ->_if($id = $request->get('id'))
            ->filterById($id)
            ->_endif()
            ->limit($limit)
            ->offset($offset)
            ->find();

        foreach ($results as $account) {
            $text = $account->getNameforPicklist();
            $result[] = [
                'id' => $account->getId(),
                'text' => $text,
                'name' => $text,
                'alert' => $account->getAlert(),
            ];
        }

        return $this->json([
            'maxPerPage' => $limit,
            'results' => $result,
            'total' => $total,
        ]);
    }

    /**
     * @Route("/client/search-by-name-init", name="spoc_account_search_by_name_init")
     */
    public function searchByLabelInit(Request $request): JsonResponse
    {
        $result = [];
        $ids = explode(',', $request->get('id', ''));

        // 1 query to find & count ; if performance issue, split them and paginate the find.
        $accounts = AccountQuery::create()->filterByActiveStatusId()->filterById($ids, Criteria::IN)->find();
        $total = count($accounts);

        if ($total > 1) {
            foreach ($accounts as $account) {
                $result[] = [
                    'id' => $account->getId(),
                    'text' => $account->getNameforPicklist(),
                    'name' => $account->getNameforPicklist(),
                ];
            }
        } else {
            foreach ($accounts as $account) {
                $result = [
                    'id' => $account->getId(),
                    'text' => $account->getNameforPicklist(),
                    'name' => $account->getNameforPicklist(),
                ];
            }
        }

        return $this->json([
            'results' => $result,
            'total' => $total,
        ]);
    }
}
