<?php

namespace SpocBundle\Form;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ClientTeamType extends AbstractType
{
    const INPUTS = [
        'account_1',
        'account_2',
        'account_3',
        'account_4',
    ];

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        foreach (self::INPUTS as $input) {
            $builder->add($input, Select2HiddenPropelType::class, [
                'label' => '',
                'multiple' => false,
                'required' => false,
                'empty_value' => 'Select a client',
                'query' => AccountQuery::create(),
                'choices' => 'spoc_account_search_by_name',
                'init_choices' => 'spoc_account_search_by_name_init',
                'class' => Account::class,
            ]);
        }

        $builder->add('show', SubmitType::class, [
            'label' => 'Show',
            'attr' => [
                'id' => 'client_team_show',
                'class' => 'client_team_show',
            ],
        ]);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'allow_extra_fields' => true,
        ]);
    }
}
