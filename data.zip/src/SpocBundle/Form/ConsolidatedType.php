<?php

namespace SpocBundle\Form;

use Model\ConsolidatedProject;
use Model\Etude;
use Model\EtudeQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use SpocBundle\Manager\DatabaseManager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ConsolidatedType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => ConsolidatedProject::class,
            'name' => 'job_item',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'edit' => false,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $data = $builder->getData();
        $builder
            ->add('project_name', TextType::class, [
                'label' => 'Project name:',
                'attr' => [
                    'class' => 'form-control',
                ],
            ])
            ->add('fr_project', ModelType::class, [
                'label' => 'France',
                'required' => false,
                'class' => Etude::class,
                'query' => $this->getSelectQuery(DatabaseManager::PMTOOL_FR, $data->getFrProjectId() ?: 0),
                'choice_label' => 'getDisplayName',
            ])
            ->add('de_project', ModelType::class, [
                'label' => 'Germany',
                'required' => false,
                'class' => Etude::class,
                'query' => $this->getSelectQuery(DatabaseManager::PMTOOL_DE, $data->getDeProjectId() ?: 0),
                'choice_label' => 'getDisplayName',
            ])
            ->add('es_project', ModelType::class, [
                'label' => 'Spain',
                'required' => false,
                'class' => Etude::class,
                'query' => $this->getSelectQuery(DatabaseManager::PMTOOL_ES, $data->getEsProjectId() ?: 0),
                'choice_label' => 'getDisplayName',
            ])
            ->add('uk_project', ModelType::class, [
                'label' => 'United-Kingdom',
                'required' => false,
                'class' => Etude::class,
                'query' => $this->getSelectQuery(DatabaseManager::PMTOOL_UK, $data->getUkProjectId() ?: 0),
                'choice_label' => 'getDisplayName',
            ])
            ->add('us_project', ModelType::class, [
                'label' => 'United-States',
                'required' => false,
                'class' => Etude::class,
                'query' => $this->getSelectQuery(DatabaseManager::PMTOOL_US, $data->getUsProjectId() ?: 0),
                'choice_label' => 'getDisplayName',
            ]);
        if (!$options['edit']) {
            $builder
                ->add('euro', TextType::class, [
                    'label' => 'Euro:',
                    'required' => false,
                    'attr' => [
                        'class' => 'form-control',
                    ],
                ])
                ->add('dollar', TextType::class, [
                    'label' => 'Dollar:',
                    'required' => false,
                    'attr' => [
                        'class' => 'form-control',
                    ],
                ])
                ->add('pound', TextType::class, [
                    'label' => 'Pound:',
                    'required' => false,
                    'attr' => [
                        'class' => 'form-control',
                    ],
                ])
            ;
        }
    }

    protected function getSelectQuery(string $db, int $id = 0)
    {
        return (new EtudeQuery($db))
            ->filterByDateFin(Criteria::CURRENT_DATE, Criteria::GREATER_EQUAL)
            ->filterByIsConsolidated(false)
            ->_or()
            ->filterById($id);
    }
}
