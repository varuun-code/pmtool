<?php

namespace SpocBundle\Form;

use Form\Propel\Select2HiddenPropelType;
use Model\AccountQuery;
use Model\User;
use Model\UserQuery;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ManageClientType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $accountsClient = $options['accounts_data'];
        foreach ($accountsClient as $key => $input) {
            $builder->addEventListener(
                FormEvents::PRE_SET_DATA,
                function (FormEvent $event) use ($key, $input) {
                    $data = $event->getData();
                    $form = $event->getForm();
                    $qualSponsor = $quantSponsor = $euSponsor = '';

                    if (!$data) {
                        if ($input->getSponsor()) {
                            $account = AccountQuery::create()->filterBySfId($input->getSfId())->findOne();
                            $qualSponsor = $account ? $account->getSponsor() : '';
                        }
                        if ($input->getQuantSponsor()) {
                            $account = AccountQuery::create()->filterBySfId($input->getSfId())->findOne();
                            $quantSponsor = $account ? $account->getQuantSponsor() : '';
                        }
                        if ($input->getEuSponsor()) {
                            $account = AccountQuery::create()->filterBySfId($input->getSfId())->findOne();
                            $euSponsor = $account ? $account->getEuSponsor() : '';
                        }
                    }

                    $form->add('quant_sponsor_'.$input->getSfId(), TextType::class, [
                        'data' => $quantSponsor,
                        'disabled' => true,
                        'label' => false,
                        'required' => false,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'form-control input-sm',
                            'placeholder' => '',
                            'style' => 'font-size: 15px',
                        ],
                    ])
                    ->add('qual_sponsor_'.$input->getSfId(), TextType::class, [
                        'data' => $qualSponsor,
                        'disabled' => true,
                        'label' => false,
                        'required' => false,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'form-control input-sm',
                            'placeholder' => '',
                            'style' => 'font-size: 15px',
                        ],
                    ])
                    ->add('eu_sponsor_'.$input->getSfId(), TextType::class, [
                        'data' => $euSponsor,
                        'disabled' => false,
                        'label' => false,
                        'required' => false,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'form-control input-sm eu-sponsor',
                            'placeholder' => '',
                            'style' => 'font-size: 15px',
                        ],
                    ])
                    ->add('pm_team_leader_'.$input->getSfId(), Select2HiddenPropelType::class, [
                        'label' => false,
                        'multiple' => false,
                        'required' => false,
                        'empty_value' => 'Select a PM Team Leader',
                        'query' => UserQuery::create(),
                        'choices' => 'all_pm_team_leader_instances_search_by_name',
                        'class' => User::class,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'pm_team_leader_'.$key,
                            'style' => [
                                'padding' => '6px 12px',
                                'line-height' => '1.42857143',
                            ],
                        ],
                    ])
                    ->add('pm_'.$input->getSfId(), Select2HiddenPropelType::class, [
                        'label' => false,
                        'multiple' => true,
                        'required' => false,
                        'empty_value' => 'Select a PM',
                        'query' => UserQuery::create(),
                        'choices' => 'all_pm_instances_search_by_name',
                        'class' => User::class,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'pm_'.$key,
                            'style' => [
                                'padding' => '6px 12px',
                                'line-height' => '1.42857143',
                            ],
                        ],
                    ])
                    ->add('notes_'.$input->getSfId(), TextareaType::class, [
                        'label' => false,
                        'required' => false,
                        'mapped' => false,
                        'attr' => [
                            'class' => 'notes_'.$key,
                            'placeholder' => 'Specific Client Notes',
                            'style' => 'font-size: 15px',
                            'height' => '250px',
                            'rows' => '10',
                        ],
                    ])
                    ;
                }
            );
        }
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'accounts_data' => [],
            'allow_extra_fields' => true,
        ]);
    }
}
