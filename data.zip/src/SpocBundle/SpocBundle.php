<?php

namespace SpocBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SpocBundle extends Bundle
{
}
