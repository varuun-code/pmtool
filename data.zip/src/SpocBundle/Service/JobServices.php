<?php

namespace SpocBundle\Service;

use Model\ConsolidatedProject;
use Model\JobQuery;
use SpocBundle\Manager\DatabaseManager;

class JobServices
{
    /**
     * Get all Projects linked to the current consolidation project by each databases instance.
     */
    public function getProjectsByConsolidation(ConsolidatedProject $consolidatedProject): array
    {
        $projects_Ids = [
            DatabaseManager::PMTOOL_FR => $consolidatedProject->getFrProjectId(),
            DatabaseManager::PMTOOL_UK => $consolidatedProject->getUkProjectId(),
            DatabaseManager::PMTOOL_ES => $consolidatedProject->getEsProjectId(),
            DatabaseManager::PMTOOL_DE => $consolidatedProject->getDeProjectId(),
            DatabaseManager::PMTOOL_US => $consolidatedProject->getUsProjectId(),
        ];

        $parts = [];
        foreach ($projects_Ids as $key => $projectId) {
            if (in_array($key, DatabaseManager::DATABASES)) {
                $projects = (new JobQuery($key))->findById($projectId);
                if (count($projects)) {
                    $parts[$key] = $projects->getFirst();
                }
            }
        }

        return $parts;
    }
}
