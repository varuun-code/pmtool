<?php

namespace SpocBundle\Service;

use Model\AccountQuery;
use Model\ConsolidatedProject;
use Model\ConsolidatedProjectQuery;
use Model\Etude;
use Model\EtudeQuery;
use Model\EventQuery;
use Model\JobCostQuery;
use Model\JobItemQuery;
use Model\Location;
use Model\ModuleQuery;
use Propel\Runtime\Propel;
use SpocBundle\Manager\DatabaseManager;

class EtudeService
{
    private $manager;

    public function __construct(DatabaseManager $databaseManager)
    {
        $this->manager = $databaseManager;
    }

    /**
     * Get all Projects linked to the current consolidation project by each databases instance.
     */
    public function getProjectsByConsolidation(ConsolidatedProject $consolidatedProject): array
    {
        $projects_Ids = [
            DatabaseManager::PMTOOL_FR => $consolidatedProject->getFrProjectId(),
            DatabaseManager::PMTOOL_UK => $consolidatedProject->getUkProjectId(),
            DatabaseManager::PMTOOL_ES => $consolidatedProject->getEsProjectId(),
            DatabaseManager::PMTOOL_DE => $consolidatedProject->getDeProjectId(),
            DatabaseManager::PMTOOL_US => $consolidatedProject->getUsProjectId(),
        ];

        $parts = [];
        foreach ($projects_Ids as $key => $projectId) {
            $project = (new EtudeQuery($key))->findOneById($projectId);
            if ($project) {
                $parts[$key] = $project;
            }
        }

        return $parts;
    }

    public function consolidationEtudeClient(ConsolidatedProject $consolidatedProject): array
    {
        $etudes = $this->getProjectsByConsolidation($consolidatedProject);

        $clients = [];
        foreach ($etudes as $instance => $etude) {
            $clients[$instance] = (new AccountQuery($instance))->findOneById($etude->getAccountId());
        }

        return $clients;
    }

    /**
     * Get all Jobs Linked to each Projects inside consolidation project | Jobs < Projects < Consolidation Project.
     */
    public function getJobsByConsolidateProject(ConsolidatedProject $consolidatedProject): array
    {
        $etudes = $this->getProjectsByConsolidation($consolidatedProject);
        $jobsModel = [];
        foreach ($etudes as $key => $etude) {
            $etudeJobs = $etude->getJobEtudes(null, Propel::getConnection($key));
            foreach ($etudeJobs as $job) {
                $location = $job->getJobLocation(Propel::getConnection($key));
                if (!in_array($location->getLibelle(), Location::GQS_SPOC)) {
                    $jobsModel[$key] = $job;
                }
            }
        }

        return ['etude_jobs' => $jobsModel];
    }

    public function getConsolidationJobItems(int $jobId, string $database_instance): array
    {
        $data = [];
        $con = Propel::getServiceContainer()->getConnection($database_instance);
        $jobItems = (new JobItemQuery($database_instance))->filterByJobId($jobId)->orderByGroup()->find($con);
        foreach ($jobItems as $jobItem) {
            $quantitePr = $jobItem->getQuantitePr() ? $jobItem->getQuantitePr() : '-';
            $unitCost = $jobItem->getPrixRevientUnitaire() ? $jobItem->getPrixRevientUnitaire() : '-';
            $costRate = $jobItem->getCoefficiantPr() ? $jobItem->getCoefficiantPr() : '-';
            $costPrice = $jobItem->getPrixRevient() ? $jobItem->getPrixRevient() : '-';
            $section = $jobItem->getCategoriePrestation($con) ? $jobItem->getCategoriePrestation($con)->getCategory() : '-';
            $category = $jobItem->getCategoriePrestation($con) ? $jobItem->getCategoriePrestation($con)->getConsolidation() : '-';
            $methodology = $jobItem->getMethodology($con) ? $jobItem->getMethodology($con)->getValue() : '-';
            $vendor = $jobItem->getVendor($con) ? $jobItem->getVendor($con)->getFullname() : '-';
            $respLocation = $jobItem->getRespLocation($con) ? $jobItem->getRespLocation($con)->getValue() : '-';
            $respType = $jobItem->getRespondentType($con) ? $jobItem->getRespondentType($con)->getValue() : '-';
            $data[] = [
                'Group order' => $jobItem->getGroup(),
                'Group' => $jobItem->getGroupTitle(),
                'Sub group' => $jobItem->getSuperGroupTitle(),
                'Category' => $category,
                'Section' => $section,
                'Methodology' => $methodology,
                'Vendor' => $vendor,
                'Resp. Location' => $respLocation,
                'Resp. Type' => $respType,
                'Title' => $jobItem->getSousTypePrestation(),
                'date' => $jobItem->getDate('Y-m-j'),
                'Selling Qty' => $jobItem->getQuantitePv(),
                'Selling Unit' => $jobItem->getPrixVenteUnitaire(),
                'Local Unit' => $jobItem->getPrixVenteUnitaire(),
                'Selling Price' => $jobItem->getPrixVente(),
                'Cost Qty' => $quantitePr,
                'Unit cost' => $unitCost,
                'Cost Rate' => $costRate,
                'Cost Price' => $costPrice,
            ];
        }
        Propel::getServiceContainer()->closeConnections();

        return ['data' => $data];
    }

    public function getConsolidationJobCosts(int $jobId, string $database_instance): array
    {
        $data = [];
        $con = Propel::getServiceContainer()->getConnection($database_instance);
        $jobCosts = (new JobCostQuery($database_instance))->filterByJobId($jobId)->find($con);
        foreach ($jobCosts as $jobCost) {
            $category = $jobCost->getCategoriePrestation($con) ? $jobCost->getCategoriePrestation($con)->getConsolidation() : '-';
            $section = $jobCost->getCategoriePrestation($con) ? $jobCost->getCategoriePrestation($con)->getCategory() : '-';
            $fournisseur = $jobCost->getFournisseur();
            $fournisseurName = $jobCost && $fournisseur ? $fournisseur->getFullnameOrCompany() : $jobCost->getFournisseurNom();
            $respLocation = $jobCost->getRespLocation($con) ? $jobCost->getRespLocation($con)->getValue() : '-';
            $respType = $jobCost->getRespLocation($con) ? $jobCost->getRespLocation($con)->getField() : '-';

            $data[] = [
                'Category' => $category,
                'Section' => $section,
                'Methodology' => $jobCost->getMethodology(),
                'Provider' => $fournisseurName,
                'Resp. Location' => $respLocation,
                'Resp. Type' => $respType,
                'date' => $jobCost->getDate(),
                'Title' => $jobCost->getSousTypePrestation(),
                'Qty' => $jobCost->getQuantitePr(),
                'Resp.Location Unit' => $jobCost->getUnitPrice(),
                'Unit Price' => $jobCost->getPrixVenteUnitaireLocation(),
                'Social Rate' => $jobCost->getCoefficiant(),
                'Price' => $jobCost->getPrixRevient(),
                'Paid' => $jobCost->getPaid(),
            ];
        }
        Propel::getServiceContainer()->closeConnections();

        return ['data' => $data];
    }

    public function getConsolidationEventModules(int $jobId, string $database_instance): array
    {
        $events = (new EventQuery($database_instance))->findByJobId($jobId);
        $data = [];

        foreach ($events as $event) {
            if (!$event) {
                continue;
            }

            $modules = (new ModuleQuery($database_instance))->findByEventId($event->getId());

            foreach ($modules as $module) {
                if (!$module) {
                    continue;
                }
                $methodology = $event && $event->getEventMethodology() ? $event->getEventMethodology()->getLabel() : '-';
                $respondant = $module->getRepondantId() ? $module->getRepondantId() : '-';
                $duree = $module->getDuree() ? $module->getDuree()->getDureetext() : '-';
                $confirmation = $module->getConfirmation() ? $module->getConfirmation()->getConfirmation() : '-';
                $data[] = [
                    'Cancel.' => $module->getAnnule(),
                    'Cust Id' => $module->getIdClient(),
                    'Status' => $module->getStatus(),
                    'Meth.' => $methodology,
                    'Duration' => $duree,
                    'Date' => $module->getDate('Y-m-j'),
                    'Start' => $module->getDebut(),
                    'Site' => $module->getSite(),
                    'Respondent' => $respondant,
                    'Amount' => $module->getIncentive(),
                    'Check number' => '-',
                    'Payment' => $module->getPaiement(),
                    'Respondent Confirmation' => $confirmation,
                    'Confir. Date' => $module->getDateConfirmation('Y-m-j'),
                    'Rescr. Date' => $module->getDateRescreening('Y-m-j'),
                    'Synthec' => $module->getDateScintex('Y-m-j'),
                    'Quality Check' => $module->getQualityCheck(),
                ];
            }
        }

        return ['data' => $data];
    }

    public function getEtudeGlobalDetails($id)
    {
        $consolidatedProject = ConsolidatedProjectQuery::create()->findOneById($id);
        $projects = $this->getProjectsByConsolidation($consolidatedProject);

        $prixVenteInitial = $prixVenteActualise = 0;
        $prixRevientInitial = $prixRevientActualise = 0;
        $initialMarginPercentage = $actualMarginPercentage = 0;
        $initialMarginAmount = $actualMarginAmount = 0;
        $globalEtudeDetails = [];
        foreach ($projects as $etude) {
            $prixVenteInitial += $etude->getPrixVenteInitial();
            $prixVenteActualise += $etude->getPrixVenteActualise();
            $prixRevientInitial += $etude->getPrixRevientInitial();
            $prixRevientActualise += $etude->getPrixRevientActualise();
            $initialMarginPercentage += $etude->getInitialMarginPercentage();
            $actualMarginPercentage += $etude->getActualMarginPercentage();
            $initialMarginAmount += $etude->getInitialMarginAmount();
            $actualMarginAmount += $etude->getActualMarginAmount();
        }

        $globalEtudeDetails[0] = [
            '' => 'Revenue',
            'initial' => $prixVenteInitial,
            'actual' => $prixVenteActualise,
        ];
        $globalEtudeDetails[1] = [
            '' => 'Cost',
            'initial' => $prixRevientInitial,
            'actual' => $prixRevientActualise,
        ];
        $globalEtudeDetails[2] = [
            '' => 'Margin %',
            'initial' => number_format($initialMarginPercentage, '1', '.', ''),
            'actual' => number_format($actualMarginPercentage, '1', '.', ''),
        ];
        $globalEtudeDetails[3] = [
            '' => 'Margin',
            'initial' => $initialMarginAmount,
            'actual' => $actualMarginAmount,
        ];

        return ['data' => $globalEtudeDetails];
    }

    /**
     * Calculate datas for Summary tab on project.
     */
    public function getSummaryTbody(Etude $etude, string $instance): array
    {
        $result = [];
        $totalPrixVente = 0;
        $totalPrixRevient = 0;
        $sousTotalPrixVente = 0;
        $sousTotalPrixRevient = 0;
        $summary = $etude->getSummary(Propel::getConnection($instance));
        if (count($summary) > 0) {
            foreach ($summary as $location => $sections) {
                $marge = 0;
                foreach ($sections as $section => $data) {
                    $prixVente = isset($data['prixVente']) ? $data['prixVente'] : null;
                    $prixRevient = isset($data['prixRevient']) ? $data['prixRevient'] : null;
                    $qtePv = isset($data['qtePv']) ? $data['qtePv'] : null;
                    $qtePr = isset($data['qtePr']) ? $data['qtePr'] : null;

                    if (null === $prixVente || null === $prixRevient) {
                        $marge = null;
                    } else {
                        $marge = ($prixVente > 0) ? ($prixVente - $prixRevient) / $prixVente * 100 : 0;
                    }

                    $sousTotalPrixRevient += isset($data['prixRevient']) ? $data['prixRevient'] : 0;
                    $sousTotalPrixVente += isset($data['prixVente']) ? $data['prixVente'] : 0;

                    $totalPrixRevient += isset($data['prixRevient']) ? $data['prixRevient'] : 0;
                    $totalPrixVente += isset($data['prixVente']) ? $data['prixVente'] : 0;

                    $result[$location][$section]['location'] = $location;
                    $result[$location][$section]['section'] = $section;
                    $result[$location][$section]['qtePv'] = $qtePv;
                    $result[$location][$section]['prixVente'] = $prixVente;
                    $result[$location][$section]['qtePr'] = $qtePr;

                    $result[$location][$section]['prixRevient'] = $prixRevient;
                    $result[$location][$section]['marge'] = $marge;
                }

                $sousTotalMarge = ($sousTotalPrixVente > 0) ? ($sousTotalPrixVente - $sousTotalPrixRevient) / $sousTotalPrixVente * 100 : 0;

//                $result[$location]['prixRevient'] = $prixRevient;
                $result[$location]['sousTotalPrixRevient'] = $sousTotalPrixRevient;
                $result[$location]['sousTotalPrixVente'] = $sousTotalPrixVente;
                $result[$location]['totalPrixRevient'] = $totalPrixRevient;
                $result[$location]['totalPrixVente'] = $totalPrixVente;
                $result[$location]['marge'] = $marge;

                $result[$location]['sousTotalMarge'] = $sousTotalMarge;

                $sousTotalPrixVente = 0;
                $sousTotalPrixRevient = 0;
            }
            $totalMarge = ($totalPrixVente > 0) ? ($totalPrixVente - $totalPrixRevient) / $totalPrixVente * 100 : 0;
//            $result['margeTotale'] = $totalMarge;
        }

        return $result;
    }
}
