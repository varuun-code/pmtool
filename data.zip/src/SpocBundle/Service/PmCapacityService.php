<?php

namespace SpocBundle\Service;

use Model\SpocDatasQuery;
use SpocBundle\Manager\DatabaseManager;

class PmCapacityService
{
    private $manager;

    public function __construct(DatabaseManager $databaseManager)
    {
        $this->manager = $databaseManager;
    }

    public function getPmCapacityDatas(): array
    {
        $sql = "
                SELECT
                    user.id,
                    CONCAT(nom, ' ', prenom) AS pm,
                    CASE
                        WHEN COUNT(DISTINCT(CASE WHEN etude.date_debut BETWEEN (CURDATE() - INTERVAL 6 DAY) AND CURDATE() THEN '1' END )) >= 1 THEN 'New'
                        WHEN COUNT(DISTINCT(CASE WHEN etude.date_debut BETWEEN (CURDATE() - INTERVAL 6 DAY) AND CURDATE() THEN '1' END )) < 1 THEN ''
                    END as status,
                    IF(notes IS NULL or notes = '', '', notes) as notes,
                    pm_notes as pm_notes,
                    COUNT( (CASE
                        WHEN job.pm_id != etude.id_pm
                        THEN '1' END )) as lpm,
                    COUNT( (CASE
                        WHEN job.pm_id = etude.id_pm
                        THEN '1' END )) as cpm,
                    COUNT(job.pm_id) as total,
                    SUM(etude.prix_vente_actualise) as ca,
                    SUM(etude.recrutement_objectif) + SUM(etude.recrutement_objectif_pr) as recruits,
                    COUNT(DISTINCT (CASE
                        WHEN etude.date_fin = CURDATE()
                        THEN '1' END )) as drop_today,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Monday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as M,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Tuesday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as T,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Wednesday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as W,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Thursday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as Th,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Friday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as F,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Saturday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as Sa,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_debut) = 'Sunday'
                        AND YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as Su,
                    COUNT(DISTINCT (CASE
                        WHEN YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE())
                        THEN '1' END )) as assignedThisWeek,
                    COUNT(DISTINCT (CASE
                        WHEN YEARWEEK(etude.date_debut) = YEARWEEK(CURDATE()) - 1
                        THEN '1' END )) as assignedLastWeek,
                    COUNT(DISTINCT (CASE
                        WHEN YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) - 1
                        THEN '1' END )) as ThisWeek,
                       COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Monday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as 'dM',
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Tuesday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dT,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Wednesday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dW,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Thursday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dTh,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Friday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dF,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Saturday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dSa,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Sunday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as dSu,
                    COUNT(DISTINCT (CASE
                        WHEN YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE())
                        THEN '1' END )) as NextWeek,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Monday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nM,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Tuesday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nT,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Wednesday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nW,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Thursday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nTh,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Friday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nF,
                    COUNT(DISTINCT (CASE
                        WHEN DAYNAME(etude.date_fin) = 'Saturday'
                        AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                        THEN '1' END )) as nSa,
                    COUNT(DISTINCT (CASE
                            WHEN DAYNAME(etude.date_fin) = 'Sunday'
                           AND YEARWEEK(etude.date_fin) = YEARWEEK(CURDATE()) + 1
                            THEN '1' END )) as nSu
                    FROM
                        etude
                    LEFT JOIN job on
                        job.etude_id = etude.id
                    LEFT JOIN user on
                        job.pm_id = user.id
                    WHERE
                        etude.date_fin >= CURDATE()
                    GROUP BY
                        user.id";

        $datas = $this->manager->queryAllDb($sql);
        $json = [];
        $i = 0;

        foreach ($datas as $location => $pm) {
            $team = strtoupper(str_replace('pmtool_', '', $location));
            $currency = 'US' === $team ? '$' : '€';
            foreach (array_keys($pm) as $key) {
                $json[$i] = $datas[$location][$key];
                $json[$i]['team'] = $team;
                $json[$i]['ca'] = number_format($json[$i]['ca'])."$currency";
                ++$i;
            }
        }

        return ['data' => $json];
    }

    public function getTeamNotes(): array
    {
        $datas = SpocDatasQuery::create()->filterBySlug('team-notes')->findOne();

        return [
            'team_notes' => $datas ? $datas->getTeamNotes() : '',
        ];
    }
}
