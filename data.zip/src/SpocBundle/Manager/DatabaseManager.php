<?php

namespace SpocBundle\Manager;

use Propel\Runtime\Propel;
use Propel\Runtime\ServiceContainer\ServiceContainerInterface;

class DatabaseManager
{
    const PMTOOL_DE = 'pmtool_de';
    const PMTOOL_ES = 'pmtool_es';
    const PMTOOL_FR = 'pmtool_fr';
    const PMTOOL_UK = 'pmtool_uk';
    const PMTOOL_US = 'pmtool_us';

    const COUNTRIES = [
        self::PMTOOL_DE => 'Germany',
        self::PMTOOL_ES => 'Spain',
        self::PMTOOL_FR => 'France',
        self::PMTOOL_UK => 'United Kingdom',
        self::PMTOOL_US => 'United States',
    ];

    const DATABASES = [
        'DE' => self::PMTOOL_DE,
        'ES' => self::PMTOOL_ES,
        'FR' => self::PMTOOL_FR,
        'US' => self::PMTOOL_US,
        'UK' => self::PMTOOL_UK,
    ];

    private $readConnections = [];
    private $writeConnections = [];

    public function __construct()
    {
        Propel::disableInstancePooling(); // Disable Propel Cache to avoid PK collisions.
    }

    public function getReadConnection(string $database)
    {
        if (!in_array($database, self::DATABASES)) {
            throw new \LogicException('Requested access to unknown database '.$database);
        }

        return $this->readConnections[$database] ?? $this->readConnections[$database] = Propel::getConnection($database, ServiceContainerInterface::CONNECTION_READ);
    }

    public function getWriteConnection(string $database)
    {
        if (!in_array($database, self::DATABASES)) {
            throw new \LogicException('Requested access to unknown database '.$database);
        }

        return $this->writeConnections[$database] ?? $this->writeConnections[$database] = Propel::getConnection($database, ServiceContainerInterface::CONNECTION_WRITE);
    }

    /**
     * Query on every databases.
     */
    public function queryAllDb(string $sql, array $databases = self::DATABASES): array
    {
        $result = [];

        foreach ($databases as $database) {
            $con = $this->getReadConnection($database);
            $stmt = $con->prepare($sql);
            $stmt->execute();
            $result[$database] = $stmt->fetchAll(\PDO::FETCH_ASSOC) ?? null;
        }

        return $result;
    }
}
