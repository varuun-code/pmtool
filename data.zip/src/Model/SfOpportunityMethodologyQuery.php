<?php

namespace Model;

use Model\Base\SfOpportunityMethodologyQuery as BaseSfOpportunityMethodologyQuery;

class SfOpportunityMethodologyQuery extends BaseSfOpportunityMethodologyQuery
{
}
