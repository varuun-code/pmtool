<?php

namespace Model;

use Model\Base\ReglementQuery as BaseReglementQuery;

class ReglementQuery extends BaseReglementQuery
{
}
