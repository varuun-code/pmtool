<?php

namespace Model;

use Model\Base\EventMethodology as BaseEventMethodology;

class EventMethodology extends BaseEventMethodology
{
    const FG = 'fg';
    const CL_IDI = 'cl idi';
    const CLIENT_BRIEFING = 'client briefing';

    public function __toString(): string
    {
        return $this->label;
    }
}
