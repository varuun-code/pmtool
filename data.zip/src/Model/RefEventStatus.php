<?php

namespace Model;

use Model\Base\RefEventStatus as BaseRefEventStatus;

class RefEventStatus extends BaseRefEventStatus
{
    const ACTIVE = 'Active';
    const CONFIRMED = 'Confirmed';
    const CANCELLED_BILLED = 'Cancelled Billed';
    const CANCELLED_NON_BILLED = 'Cancelled non-Billed';
    const CLOSED = 'Closed';
    const ON_HOLD = 'On Hold';
    const RELEASED = 'Released';
    const TENTATIVE = 'Tentative';
    const NO_ROOM_COUNT = 'no-room-count';

    public function __toString(): string
    {
        return $this->getName();
    }

    public static function getEventsStatusNamesIdsAndColor()
    {
        return RefEventStatusQuery::create()
            ->select(['id', 'name', 'color'])
            ->find()
            ->toArray();
    }

    public static function getDefaultEventsStatusNamesIdsAndColor()
    {
        return RefEventStatusQuery::create()
            ->select(['id', 'name', 'color'])
            ->filterByName([strtolower(self::CONFIRMED), strtolower(self::ACTIVE), strtolower(self::TENTATIVE), strtolower(self::ON_HOLD), self::NO_ROOM_COUNT])
            ->filterByName([ucwords(self::CONFIRMED), ucwords(self::ACTIVE), ucwords(self::TENTATIVE), ucwords(self::ON_HOLD), ucwords(self::NO_ROOM_COUNT)])
            ->find()
            ->toArray();
    }

    public static function getDefaultCheckedEventsStatusIds()
    {
        return RefEventStatusQuery::create()
            ->select(['id'])
            ->filterByName([strtolower(self::CONFIRMED), strtolower(self::ACTIVE), strtolower(self::TENTATIVE), strtolower(self::ON_HOLD), self::NO_ROOM_COUNT])
            ->filterByName([ucwords(self::CONFIRMED), ucwords(self::ACTIVE), ucwords(self::TENTATIVE), ucwords(self::ON_HOLD), ucwords(self::NO_ROOM_COUNT)])
            ->find()
            ->toArray();
    }
}
