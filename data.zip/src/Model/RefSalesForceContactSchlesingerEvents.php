<?php

namespace Model;

use Model\Base\RefSalesForceContactSchlesingerEvents as BaseRefSalesForceContactSchlesingerEvents;

class RefSalesForceContactSchlesingerEvents extends BaseRefSalesForceContactSchlesingerEvents
{
}
