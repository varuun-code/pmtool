<?php

namespace Model;

use Model\Base\SampleSource as BaseSampleSource;

class SampleSource extends BaseSampleSource
{
    private static $sampleSources;

    public function __toString(): string
    {
        return $this->libelle;
    }

    public static function getAll()
    {
        return self::$sampleSources ?? self::$sampleSources = SampleSourceQuery::create()
            ->orderByRank()
            ->find();
    }

    public function isDeletable(): bool
    {
        return !count($this->getEtudes());
    }
}
