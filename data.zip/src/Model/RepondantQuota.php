<?php

namespace Model;

use Model\Base\RepondantQuota as BaseRepondantQuota;

class RepondantQuota extends BaseRepondantQuota
{
}
