<?php

namespace Model;

use Model\Base\RefSalesForceAccountRegularlyUsesSaFor as BaseRefSalesForceAccountRegularlyUsesSaFor;

class RefSalesForceAccountRegularlyUsesSaFor extends BaseRefSalesForceAccountRegularlyUsesSaFor
{
}
