<?php

namespace Model;

use Model\Base\SpocProjectManagerQuery as BaseSpocProjectManagerQuery;

class SpocProjectManagerQuery extends BaseSpocProjectManagerQuery
{
}
