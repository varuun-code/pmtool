<?php

namespace Model;

use Model\Base\SfOpportunityMethodology as BaseSfOpportunityMethodology;

class SfOpportunityMethodology extends BaseSfOpportunityMethodology
{
}
