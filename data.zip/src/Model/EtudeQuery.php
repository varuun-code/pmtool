<?php

namespace Model;

use Model\Base\EtudeQuery as BaseEtudeQuery;

class EtudeQuery extends BaseEtudeQuery
{
}
