<?php

namespace Model;

use Model\Base\EtudeGroup as BaseEtudeGroup;

class EtudeGroup extends BaseEtudeGroup
{
}
