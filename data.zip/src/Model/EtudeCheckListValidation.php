<?php

namespace Model;

use Model\Base\EtudeCheckListValidation as BaseEtudeCheckListValidation;

class EtudeCheckListValidation extends BaseEtudeCheckListValidation
{
}
