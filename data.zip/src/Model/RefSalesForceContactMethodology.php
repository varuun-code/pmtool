<?php

namespace Model;

use Model\Base\RefSalesForceContactMethodology as BaseRefSalesForceContactMethodology;

class RefSalesForceContactMethodology extends BaseRefSalesForceContactMethodology
{
}
