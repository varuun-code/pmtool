<?php

namespace Model;

use Model\Base\RefTimeSlot as BaseRefTimeSlot;

class RefTimeSlot extends BaseRefTimeSlot
{
    public function __toString(): string
    {
        return $this->getName();
    }
}
