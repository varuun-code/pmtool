<?php

namespace Model;

use Model\Base\SfOpportunityLocationQuery as BaseSfOpportunityLocationQuery;

class SfOpportunityLocationQuery extends BaseSfOpportunityLocationQuery
{
}
