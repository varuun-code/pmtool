<?php

namespace Model;

use Model\Base\EtudeMethodologyQuery as BaseEtudeMethodologyQuery;

class EtudeMethodologyQuery extends BaseEtudeMethodologyQuery
{
}
