<?php

namespace Model;

use Model\Base\SpocDatasQuery as BaseSpocDatasQuery;

class SpocDatasQuery extends BaseSpocDatasQuery
{
}
