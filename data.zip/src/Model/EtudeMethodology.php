<?php

namespace Model;

use Model\Base\EtudeMethodology as BaseEtudeMethodology;

class EtudeMethodology extends BaseEtudeMethodology
{
}
