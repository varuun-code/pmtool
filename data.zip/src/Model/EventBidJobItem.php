<?php

namespace Model;

use Model\Base\EventBidJobItem as BaseEventBidJobItem;

class EventBidJobItem extends BaseEventBidJobItem
{
}
