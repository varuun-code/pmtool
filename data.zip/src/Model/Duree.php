<?php

namespace Model;

use Model\Base\Duree as BaseDuree;

class Duree extends BaseDuree
{
    private static $instances;
    private static $durees;

    public function __toString(): string
    {
        return $this->dureetext;
    }

    public static function getAll()
    {
        return self::$durees ?? self::$durees = DureeQuery::create()
            ->orderByDureenum()
            ->find();
    }

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = DureeQuery::create()->findOneById($id);
    }
}
