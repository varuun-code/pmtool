<?php

namespace Model;

use Model\Base\Site as BaseSite;

class Site extends BaseSite
{
    private static $instances;
    private static $sites;

    public function __toString(): string
    {
        return $this->getLieu();
    }

    public static function getAll()
    {
        return self::$sites ?? self::$sites = SiteQuery::create()->orderByLieu()->find();
    }

    public static function getById($id)
    {
        return self::$instances[$id] ?? SiteQuery::create()->leftJoinWithVille()->findOneById($id);
    }

    public function getFullAddress()
    {
        $ville = $this->getVille();

        return $this->getLieu().'<br>'.$this->getAdresse().($ville ? '<br>'.$ville->getCpAndVille() : '');
    }
}
