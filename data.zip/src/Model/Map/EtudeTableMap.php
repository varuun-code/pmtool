<?php

namespace Model\Map;

use Model\Etude;
use Model\EtudeQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'etude' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 */
class EtudeTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'src.Model.Map.EtudeTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'default';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'etude';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\Model\\Etude';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'src.Model.Etude';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 104;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 104;

    /**
     * the column name for the id field
     */
    const COL_ID = 'etude.id';

    /**
     * the column name for the numero_etude field
     */
    const COL_NUMERO_ETUDE = 'etude.numero_etude';

    /**
     * the column name for the reference_client field
     */
    const COL_REFERENCE_CLIENT = 'etude.reference_client';

    /**
     * the column name for the master_project_sf_id field
     */
    const COL_MASTER_PROJECT_SF_ID = 'etude.master_project_sf_id';

    /**
     * the column name for the theme field
     */
    const COL_THEME = 'etude.theme';

    /**
     * the column name for the date_debut field
     */
    const COL_DATE_DEBUT = 'etude.date_debut';

    /**
     * the column name for the date_fin field
     */
    const COL_DATE_FIN = 'etude.date_fin';

    /**
     * the column name for the annee field
     */
    const COL_ANNEE = 'etude.annee';

    /**
     * the column name for the rst field
     */
    const COL_RST = 'etude.rst';

    /**
     * the column name for the cli field
     */
    const COL_CLI = 'etude.cli';

    /**
     * the column name for the gqs field
     */
    const COL_GQS = 'etude.gqs';

    /**
     * the column name for the ins field
     */
    const COL_INS = 'etude.ins';

    /**
     * the column name for the hut field
     */
    const COL_HUT = 'etude.hut';

    /**
     * the column name for the display_total_only field
     */
    const COL_DISPLAY_TOTAL_ONLY = 'etude.display_total_only';

    /**
     * the column name for the id_pm field
     */
    const COL_ID_PM = 'etude.id_pm';

    /**
     * the column name for the id_etape field
     */
    const COL_ID_ETAPE = 'etude.id_etape';

    /**
     * the column name for the prix_revient_initial field
     */
    const COL_PRIX_REVIENT_INITIAL = 'etude.prix_revient_initial';

    /**
     * the column name for the prix_revient_actualise field
     */
    const COL_PRIX_REVIENT_ACTUALISE = 'etude.prix_revient_actualise';

    /**
     * the column name for the prix_vente_initial field
     */
    const COL_PRIX_VENTE_INITIAL = 'etude.prix_vente_initial';

    /**
     * the column name for the prix_vente_actualise field
     */
    const COL_PRIX_VENTE_ACTUALISE = 'etude.prix_vente_actualise';

    /**
     * the column name for the consolidated_invoice field
     */
    const COL_CONSOLIDATED_INVOICE = 'etude.consolidated_invoice';

    /**
     * the column name for the send_csat_quest field
     */
    const COL_SEND_CSAT_QUEST = 'etude.send_csat_quest';

    /**
     * the column name for the is_send_csat_quest_mail field
     */
    const COL_IS_SEND_CSAT_QUEST_MAIL = 'etude.is_send_csat_quest_mail';

    /**
     * the column name for the numero_facture field
     */
    const COL_NUMERO_FACTURE = 'etude.numero_facture';

    /**
     * the column name for the dont_set_am_auto field
     */
    const COL_DONT_SET_AM_AUTO = 'etude.dont_set_am_auto';

    /**
     * the column name for the set_am_reason field
     */
    const COL_SET_AM_REASON = 'etude.set_am_reason';

    /**
     * the column name for the am_reason_type_id field
     */
    const COL_AM_REASON_TYPE_ID = 'etude.am_reason_type_id';

    /**
     * the column name for the date_envoi_facture field
     */
    const COL_DATE_ENVOI_FACTURE = 'etude.date_envoi_facture';

    /**
     * the column name for the date_reglement field
     */
    const COL_DATE_REGLEMENT = 'etude.date_reglement';

    /**
     * the column name for the commentaire field
     */
    const COL_COMMENTAIRE = 'etude.commentaire';

    /**
     * the column name for the industry_id field
     */
    const COL_INDUSTRY_ID = 'etude.industry_id';

    /**
     * the column name for the periode_cutoff field
     */
    const COL_PERIODE_CUTOFF = 'etude.periode_cutoff';

    /**
     * the column name for the theme_br field
     */
    const COL_THEME_BR = 'etude.theme_br';

    /**
     * the column name for the area_id field
     */
    const COL_AREA_ID = 'etude.area_id';

    /**
     * the column name for the id_sams_study field
     */
    const COL_ID_SAMS_STUDY = 'etude.id_sams_study';

    /**
     * the column name for the recrutement_objectif field
     */
    const COL_RECRUTEMENT_OBJECTIF = 'etude.recrutement_objectif';

    /**
     * the column name for the id_location_pnl field
     */
    const COL_ID_LOCATION_PNL = 'etude.id_location_pnl';

    /**
     * the column name for the id_master_project_location_pnl field
     */
    const COL_ID_MASTER_PROJECT_LOCATION_PNL = 'etude.id_master_project_location_pnl';

    /**
     * the column name for the recrutement_objectif_pr field
     */
    const COL_RECRUTEMENT_OBJECTIF_PR = 'etude.recrutement_objectif_pr';

    /**
     * the column name for the id_bm field
     */
    const COL_ID_BM = 'etude.id_bm';

    /**
     * the column name for the extra_info field
     */
    const COL_EXTRA_INFO = 'etude.extra_info';

    /**
     * the column name for the account_id field
     */
    const COL_ACCOUNT_ID = 'etude.account_id';

    /**
     * the column name for the account_manager_id field
     */
    const COL_ACCOUNT_MANAGER_ID = 'etude.account_manager_id';

    /**
     * the column name for the project_specialty_sponsor_id field
     */
    const COL_PROJECT_SPECIALTY_SPONSOR_ID = 'etude.project_specialty_sponsor_id';

    /**
     * the column name for the language field
     */
    const COL_LANGUAGE = 'etude.language';

    /**
     * the column name for the remise_taux field
     */
    const COL_REMISE_TAUX = 'etude.remise_taux';

    /**
     * the column name for the client_discount_percentage field
     */
    const COL_CLIENT_DISCOUNT_PERCENTAGE = 'etude.client_discount_percentage';

    /**
     * the column name for the end_client_discount_percentage field
     */
    const COL_END_CLIENT_DISCOUNT_PERCENTAGE = 'etude.end_client_discount_percentage';

    /**
     * the column name for the client_quant_discount_percentage field
     */
    const COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE = 'etude.client_quant_discount_percentage';

    /**
     * the column name for the end_client_quant_discount_percentage field
     */
    const COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE = 'etude.end_client_quant_discount_percentage';

    /**
     * the column name for the sample_plan field
     */
    const COL_SAMPLE_PLAN = 'etude.sample_plan';

    /**
     * the column name for the isToInvoice field
     */
    const COL_ISTOINVOICE = 'etude.isToInvoice';

    /**
     * the column name for the file_path field
     */
    const COL_FILE_PATH = 'etude.file_path';

    /**
     * the column name for the account_leader_id field
     */
    const COL_ACCOUNT_LEADER_ID = 'etude.account_leader_id';

    /**
     * the column name for the account_pm_id field
     */
    const COL_ACCOUNT_PM_ID = 'etude.account_pm_id';

    /**
     * the column name for the am_email field
     */
    const COL_AM_EMAIL = 'etude.am_email';

    /**
     * the column name for the client_portal_ready field
     */
    const COL_CLIENT_PORTAL_READY = 'etude.client_portal_ready';

    /**
     * the column name for the length_of_interview field
     */
    const COL_LENGTH_OF_INTERVIEW = 'etude.length_of_interview';

    /**
     * the column name for the sunshine_act field
     */
    const COL_SUNSHINE_ACT = 'etude.sunshine_act';

    /**
     * the column name for the is_consolidated field
     */
    const COL_IS_CONSOLIDATED = 'etude.is_consolidated';

    /**
     * the column name for the sharepoint_folder field
     */
    const COL_SHAREPOINT_FOLDER = 'etude.sharepoint_folder';

    /**
     * the column name for the multi_phase field
     */
    const COL_MULTI_PHASE = 'etude.multi_phase';

    /**
     * the column name for the po_number field
     */
    const COL_PO_NUMBER = 'etude.po_number';

    /**
     * the column name for the currencies field
     */
    const COL_CURRENCIES = 'etude.currencies';

    /**
     * the column name for the sms_relance field
     */
    const COL_SMS_RELANCE = 'etude.sms_relance';

    /**
     * the column name for the id_etude_group field
     */
    const COL_ID_ETUDE_GROUP = 'etude.id_etude_group';

    /**
     * the column name for the gms field
     */
    const COL_GMS = 'etude.gms';

    /**
     * the column name for the kol field
     */
    const COL_KOL = 'etude.kol';

    /**
     * the column name for the room_rental field
     */
    const COL_ROOM_RENTAL = 'etude.room_rental';

    /**
     * the column name for the recruits_offsite field
     */
    const COL_RECRUITS_OFFSITE = 'etude.recruits_offsite';

    /**
     * the column name for the study_specification field
     */
    const COL_STUDY_SPECIFICATION = 'etude.study_specification';

    /**
     * the column name for the is_study_specification field
     */
    const COL_IS_STUDY_SPECIFICATION = 'etude.is_study_specification';

    /**
     * the column name for the additional_notes field
     */
    const COL_ADDITIONAL_NOTES = 'etude.additional_notes';

    /**
     * the column name for the project_comment field
     */
    const COL_PROJECT_COMMENT = 'etude.project_comment';

    /**
     * the column name for the end_client_id field
     */
    const COL_END_CLIENT_ID = 'etude.end_client_id';

    /**
     * the column name for the end_client_contact_id field
     */
    const COL_END_CLIENT_CONTACT_ID = 'etude.end_client_contact_id';

    /**
     * the column name for the contact_id field
     */
    const COL_CONTACT_ID = 'etude.contact_id';

    /**
     * the column name for the contact_client_pm_id field
     */
    const COL_CONTACT_CLIENT_PM_ID = 'etude.contact_client_pm_id';

    /**
     * the column name for the master_project_number field
     */
    const COL_MASTER_PROJECT_NUMBER = 'etude.master_project_number';

    /**
     * the column name for the proposed_loi field
     */
    const COL_PROPOSED_LOI = 'etude.proposed_loi';

    /**
     * the column name for the opportunity_id field
     */
    const COL_OPPORTUNITY_ID = 'etude.opportunity_id';

    /**
     * the column name for the si_job_type_id field
     */
    const COL_SI_JOB_TYPE_ID = 'etude.si_job_type_id';

    /**
     * the column name for the best_effort field
     */
    const COL_BEST_EFFORT = 'etude.best_effort';

    /**
     * the column name for the job_status_sf_id field
     */
    const COL_JOB_STATUS_SF_ID = 'etude.job_status_sf_id';

    /**
     * the column name for the booked_by_sf_id field
     */
    const COL_BOOKED_BY_SF_ID = 'etude.booked_by_sf_id';

    /**
     * the column name for the created_by_sf_id field
     */
    const COL_CREATED_BY_SF_ID = 'etude.created_by_sf_id';

    /**
     * the column name for the account_manager_sf_id field
     */
    const COL_ACCOUNT_MANAGER_SF_ID = 'etude.account_manager_sf_id';

    /**
     * the column name for the created_date field
     */
    const COL_CREATED_DATE = 'etude.created_date';

    /**
     * the column name for the job_qualification_id field
     */
    const COL_JOB_QUALIFICATION_ID = 'etude.job_qualification_id';

    /**
     * the column name for the proposed_n field
     */
    const COL_PROPOSED_N = 'etude.proposed_n';

    /**
     * the column name for the german_job_type_id field
     */
    const COL_GERMAN_JOB_TYPE_ID = 'etude.german_job_type_id';

    /**
     * the column name for the created_by_comment field
     */
    const COL_CREATED_BY_COMMENT = 'etude.created_by_comment';

    /**
     * the column name for the focus_vision field
     */
    const COL_FOCUS_VISION = 'etude.focus_vision';

    /**
     * the column name for the si_eu_job_type field
     */
    const COL_SI_EU_JOB_TYPE = 'etude.si_eu_job_type';

    /**
     * the column name for the intermediate_client_id field
     */
    const COL_INTERMEDIATE_CLIENT_ID = 'etude.intermediate_client_id';

    /**
     * the column name for the intermediate_client_contact_id field
     */
    const COL_INTERMEDIATE_CLIENT_CONTACT_ID = 'etude.intermediate_client_contact_id';

    /**
     * the column name for the us_global_qual_gms_id field
     */
    const COL_US_GLOBAL_QUAL_GMS_ID = 'etude.us_global_qual_gms_id';

    /**
     * the column name for the facilty_note field
     */
    const COL_FACILTY_NOTE = 'etude.facilty_note';

    /**
     * the column name for the currency_iso_code_id field
     */
    const COL_CURRENCY_ISO_CODE_ID = 'etude.currency_iso_code_id';

    /**
     * the column name for the client_list_deletion_id field
     */
    const COL_CLIENT_LIST_DELETION_ID = 'etude.client_list_deletion_id';

    /**
     * the column name for the created_by_id field
     */
    const COL_CREATED_BY_ID = 'etude.created_by_id';

    /**
     * the column name for the updated_by_id field
     */
    const COL_UPDATED_BY_ID = 'etude.updated_by_id';

    /**
     * the column name for the created_at field
     */
    const COL_CREATED_AT = 'etude.created_at';

    /**
     * the column name for the updated_at field
     */
    const COL_UPDATED_AT = 'etude.updated_at';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /** The enumerated values for the si_eu_job_type field */
    const COL_SI_EU_JOB_TYPE_SAMPLE_ONLY = 'Sample only';
    const COL_SI_EU_JOB_TYPE_INCL__DATA_PROCESSING = 'Incl. Data Processing';
    const COL_SI_EU_JOB_TYPE_FULL_SERVICE = 'Full Service';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Id', 'NumeroEtude', 'ReferenceClient', 'MasterProjectSfId', 'Theme', 'DateDebut', 'DateFin', 'Annee', 'Rst', 'Cli', 'Gqs', 'Ins', 'Hut', 'DisplayTotalOnly', 'IdPm', 'IdEtape', 'PrixRevientInitial', 'PrixRevientActualise', 'PrixVenteInitial', 'PrixVenteActualise', 'ConsolidatedInvoice', 'SendCsatQuest', 'IsSendCsatQuestMail', 'NumeroFacture', 'DontSetAmAuto', 'SetAmReason', 'AmReasonTypeId', 'DateEnvoiFacture', 'DateReglement', 'Commentaire', 'IndustryId', 'PeriodeCutoff', 'ThemeBr', 'AreaId', 'IdSamsStudy', 'RecrutementObjectif', 'IdLocationPnl', 'IdMasterProjectLocationPnl', 'RecrutementObjectifPr', 'IdBm', 'ExtraInfo', 'AccountId', 'AccountManagerId', 'ProjectSpecialtySponsorId', 'Language', 'RemiseTaux', 'ClientDiscountPercentage', 'EndClientDiscountPercentage', 'ClientQuantDiscountPercentage', 'EndClientQuantDiscountPercentage', 'SamplePlan', 'IsToInvoice', 'FilePath', 'AccountLeaderId', 'AccountPMId', 'AmEmail', 'ClientPortalReady', 'LengthOfInterview', 'sunshineAct', 'IsConsolidated', 'SharepointFolder', 'MultiPhase', 'PoNumber', 'Currencies', 'SmsRelance', 'IdEtudeGroup', 'Gms', 'Kol', 'RoomRental', 'RecruitsOffsite', 'StudySpecification', 'isStudySpecification', 'AdditionalNotes', 'ProjectComment', 'EndClientId', 'EndClientContactId', 'ContactId', 'ContactClientPmId', 'MasterProjectNumber', 'ProposedLoi', 'OpportunityId', 'SiJobTypeId', 'BestEffort', 'JobStatusSfId', 'BookedBySfId', 'CreatedBySfId', 'AccountManagerSfId', 'CreatedDate', 'JobQualificationId', 'ProposedN', 'GermanJobTypeId', 'CreatedByComment', 'FocusVision', 'SiEuJobType', 'IntermediateClientId', 'IntermediateClientContactId', 'UsGlobalQualGmsId', 'FaciltyNote', 'CurrencyIsoCodeId', 'ClientListDeletionId', 'CreatedById', 'UpdatedById', 'CreatedAt', 'UpdatedAt', ),
        self::TYPE_CAMELNAME     => array('id', 'numeroEtude', 'referenceClient', 'masterProjectSfId', 'theme', 'dateDebut', 'dateFin', 'annee', 'rst', 'cli', 'gqs', 'ins', 'hut', 'displayTotalOnly', 'idPm', 'idEtape', 'prixRevientInitial', 'prixRevientActualise', 'prixVenteInitial', 'prixVenteActualise', 'consolidatedInvoice', 'sendCsatQuest', 'isSendCsatQuestMail', 'numeroFacture', 'dontSetAmAuto', 'setAmReason', 'amReasonTypeId', 'dateEnvoiFacture', 'dateReglement', 'commentaire', 'industryId', 'periodeCutoff', 'themeBr', 'areaId', 'idSamsStudy', 'recrutementObjectif', 'idLocationPnl', 'idMasterProjectLocationPnl', 'recrutementObjectifPr', 'idBm', 'extraInfo', 'accountId', 'accountManagerId', 'projectSpecialtySponsorId', 'language', 'remiseTaux', 'clientDiscountPercentage', 'endClientDiscountPercentage', 'clientQuantDiscountPercentage', 'endClientQuantDiscountPercentage', 'samplePlan', 'isToInvoice', 'filePath', 'accountLeaderId', 'accountPMId', 'amEmail', 'clientPortalReady', 'lengthOfInterview', 'sunshineAct', 'isConsolidated', 'sharepointFolder', 'multiPhase', 'poNumber', 'currencies', 'smsRelance', 'idEtudeGroup', 'gms', 'kol', 'roomRental', 'recruitsOffsite', 'studySpecification', 'isStudySpecification', 'additionalNotes', 'projectComment', 'endClientId', 'endClientContactId', 'contactId', 'contactClientPmId', 'masterProjectNumber', 'proposedLoi', 'opportunityId', 'siJobTypeId', 'bestEffort', 'jobStatusSfId', 'bookedBySfId', 'createdBySfId', 'accountManagerSfId', 'createdDate', 'jobQualificationId', 'proposedN', 'germanJobTypeId', 'createdByComment', 'focusVision', 'siEuJobType', 'intermediateClientId', 'intermediateClientContactId', 'usGlobalQualGmsId', 'faciltyNote', 'currencyIsoCodeId', 'clientListDeletionId', 'createdById', 'updatedById', 'createdAt', 'updatedAt', ),
        self::TYPE_COLNAME       => array(EtudeTableMap::COL_ID, EtudeTableMap::COL_NUMERO_ETUDE, EtudeTableMap::COL_REFERENCE_CLIENT, EtudeTableMap::COL_MASTER_PROJECT_SF_ID, EtudeTableMap::COL_THEME, EtudeTableMap::COL_DATE_DEBUT, EtudeTableMap::COL_DATE_FIN, EtudeTableMap::COL_ANNEE, EtudeTableMap::COL_RST, EtudeTableMap::COL_CLI, EtudeTableMap::COL_GQS, EtudeTableMap::COL_INS, EtudeTableMap::COL_HUT, EtudeTableMap::COL_DISPLAY_TOTAL_ONLY, EtudeTableMap::COL_ID_PM, EtudeTableMap::COL_ID_ETAPE, EtudeTableMap::COL_PRIX_REVIENT_INITIAL, EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE, EtudeTableMap::COL_PRIX_VENTE_INITIAL, EtudeTableMap::COL_PRIX_VENTE_ACTUALISE, EtudeTableMap::COL_CONSOLIDATED_INVOICE, EtudeTableMap::COL_SEND_CSAT_QUEST, EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL, EtudeTableMap::COL_NUMERO_FACTURE, EtudeTableMap::COL_DONT_SET_AM_AUTO, EtudeTableMap::COL_SET_AM_REASON, EtudeTableMap::COL_AM_REASON_TYPE_ID, EtudeTableMap::COL_DATE_ENVOI_FACTURE, EtudeTableMap::COL_DATE_REGLEMENT, EtudeTableMap::COL_COMMENTAIRE, EtudeTableMap::COL_INDUSTRY_ID, EtudeTableMap::COL_PERIODE_CUTOFF, EtudeTableMap::COL_THEME_BR, EtudeTableMap::COL_AREA_ID, EtudeTableMap::COL_ID_SAMS_STUDY, EtudeTableMap::COL_RECRUTEMENT_OBJECTIF, EtudeTableMap::COL_ID_LOCATION_PNL, EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR, EtudeTableMap::COL_ID_BM, EtudeTableMap::COL_EXTRA_INFO, EtudeTableMap::COL_ACCOUNT_ID, EtudeTableMap::COL_ACCOUNT_MANAGER_ID, EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, EtudeTableMap::COL_LANGUAGE, EtudeTableMap::COL_REMISE_TAUX, EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE, EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE, EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE, EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE, EtudeTableMap::COL_SAMPLE_PLAN, EtudeTableMap::COL_ISTOINVOICE, EtudeTableMap::COL_FILE_PATH, EtudeTableMap::COL_ACCOUNT_LEADER_ID, EtudeTableMap::COL_ACCOUNT_PM_ID, EtudeTableMap::COL_AM_EMAIL, EtudeTableMap::COL_CLIENT_PORTAL_READY, EtudeTableMap::COL_LENGTH_OF_INTERVIEW, EtudeTableMap::COL_SUNSHINE_ACT, EtudeTableMap::COL_IS_CONSOLIDATED, EtudeTableMap::COL_SHAREPOINT_FOLDER, EtudeTableMap::COL_MULTI_PHASE, EtudeTableMap::COL_PO_NUMBER, EtudeTableMap::COL_CURRENCIES, EtudeTableMap::COL_SMS_RELANCE, EtudeTableMap::COL_ID_ETUDE_GROUP, EtudeTableMap::COL_GMS, EtudeTableMap::COL_KOL, EtudeTableMap::COL_ROOM_RENTAL, EtudeTableMap::COL_RECRUITS_OFFSITE, EtudeTableMap::COL_STUDY_SPECIFICATION, EtudeTableMap::COL_IS_STUDY_SPECIFICATION, EtudeTableMap::COL_ADDITIONAL_NOTES, EtudeTableMap::COL_PROJECT_COMMENT, EtudeTableMap::COL_END_CLIENT_ID, EtudeTableMap::COL_END_CLIENT_CONTACT_ID, EtudeTableMap::COL_CONTACT_ID, EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, EtudeTableMap::COL_MASTER_PROJECT_NUMBER, EtudeTableMap::COL_PROPOSED_LOI, EtudeTableMap::COL_OPPORTUNITY_ID, EtudeTableMap::COL_SI_JOB_TYPE_ID, EtudeTableMap::COL_BEST_EFFORT, EtudeTableMap::COL_JOB_STATUS_SF_ID, EtudeTableMap::COL_BOOKED_BY_SF_ID, EtudeTableMap::COL_CREATED_BY_SF_ID, EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID, EtudeTableMap::COL_CREATED_DATE, EtudeTableMap::COL_JOB_QUALIFICATION_ID, EtudeTableMap::COL_PROPOSED_N, EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, EtudeTableMap::COL_CREATED_BY_COMMENT, EtudeTableMap::COL_FOCUS_VISION, EtudeTableMap::COL_SI_EU_JOB_TYPE, EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, EtudeTableMap::COL_FACILTY_NOTE, EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, EtudeTableMap::COL_CREATED_BY_ID, EtudeTableMap::COL_UPDATED_BY_ID, EtudeTableMap::COL_CREATED_AT, EtudeTableMap::COL_UPDATED_AT, ),
        self::TYPE_FIELDNAME     => array('id', 'numero_etude', 'reference_client', 'master_project_sf_id', 'theme', 'date_debut', 'date_fin', 'annee', 'rst', 'cli', 'gqs', 'ins', 'hut', 'display_total_only', 'id_pm', 'id_etape', 'prix_revient_initial', 'prix_revient_actualise', 'prix_vente_initial', 'prix_vente_actualise', 'consolidated_invoice', 'send_csat_quest', 'is_send_csat_quest_mail', 'numero_facture', 'dont_set_am_auto', 'set_am_reason', 'am_reason_type_id', 'date_envoi_facture', 'date_reglement', 'commentaire', 'industry_id', 'periode_cutoff', 'theme_br', 'area_id', 'id_sams_study', 'recrutement_objectif', 'id_location_pnl', 'id_master_project_location_pnl', 'recrutement_objectif_pr', 'id_bm', 'extra_info', 'account_id', 'account_manager_id', 'project_specialty_sponsor_id', 'language', 'remise_taux', 'client_discount_percentage', 'end_client_discount_percentage', 'client_quant_discount_percentage', 'end_client_quant_discount_percentage', 'sample_plan', 'isToInvoice', 'file_path', 'account_leader_id', 'account_pm_id', 'am_email', 'client_portal_ready', 'length_of_interview', 'sunshine_act', 'is_consolidated', 'sharepoint_folder', 'multi_phase', 'po_number', 'currencies', 'sms_relance', 'id_etude_group', 'gms', 'kol', 'room_rental', 'recruits_offsite', 'study_specification', 'is_study_specification', 'additional_notes', 'project_comment', 'end_client_id', 'end_client_contact_id', 'contact_id', 'contact_client_pm_id', 'master_project_number', 'proposed_loi', 'opportunity_id', 'si_job_type_id', 'best_effort', 'job_status_sf_id', 'booked_by_sf_id', 'created_by_sf_id', 'account_manager_sf_id', 'created_date', 'job_qualification_id', 'proposed_n', 'german_job_type_id', 'created_by_comment', 'focus_vision', 'si_eu_job_type', 'intermediate_client_id', 'intermediate_client_contact_id', 'us_global_qual_gms_id', 'facilty_note', 'currency_iso_code_id', 'client_list_deletion_id', 'created_by_id', 'updated_by_id', 'created_at', 'updated_at', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Id' => 0, 'NumeroEtude' => 1, 'ReferenceClient' => 2, 'MasterProjectSfId' => 3, 'Theme' => 4, 'DateDebut' => 5, 'DateFin' => 6, 'Annee' => 7, 'Rst' => 8, 'Cli' => 9, 'Gqs' => 10, 'Ins' => 11, 'Hut' => 12, 'DisplayTotalOnly' => 13, 'IdPm' => 14, 'IdEtape' => 15, 'PrixRevientInitial' => 16, 'PrixRevientActualise' => 17, 'PrixVenteInitial' => 18, 'PrixVenteActualise' => 19, 'ConsolidatedInvoice' => 20, 'SendCsatQuest' => 21, 'IsSendCsatQuestMail' => 22, 'NumeroFacture' => 23, 'DontSetAmAuto' => 24, 'SetAmReason' => 25, 'AmReasonTypeId' => 26, 'DateEnvoiFacture' => 27, 'DateReglement' => 28, 'Commentaire' => 29, 'IndustryId' => 30, 'PeriodeCutoff' => 31, 'ThemeBr' => 32, 'AreaId' => 33, 'IdSamsStudy' => 34, 'RecrutementObjectif' => 35, 'IdLocationPnl' => 36, 'IdMasterProjectLocationPnl' => 37, 'RecrutementObjectifPr' => 38, 'IdBm' => 39, 'ExtraInfo' => 40, 'AccountId' => 41, 'AccountManagerId' => 42, 'ProjectSpecialtySponsorId' => 43, 'Language' => 44, 'RemiseTaux' => 45, 'ClientDiscountPercentage' => 46, 'EndClientDiscountPercentage' => 47, 'ClientQuantDiscountPercentage' => 48, 'EndClientQuantDiscountPercentage' => 49, 'SamplePlan' => 50, 'IsToInvoice' => 51, 'FilePath' => 52, 'AccountLeaderId' => 53, 'AccountPMId' => 54, 'AmEmail' => 55, 'ClientPortalReady' => 56, 'LengthOfInterview' => 57, 'sunshineAct' => 58, 'IsConsolidated' => 59, 'SharepointFolder' => 60, 'MultiPhase' => 61, 'PoNumber' => 62, 'Currencies' => 63, 'SmsRelance' => 64, 'IdEtudeGroup' => 65, 'Gms' => 66, 'Kol' => 67, 'RoomRental' => 68, 'RecruitsOffsite' => 69, 'StudySpecification' => 70, 'isStudySpecification' => 71, 'AdditionalNotes' => 72, 'ProjectComment' => 73, 'EndClientId' => 74, 'EndClientContactId' => 75, 'ContactId' => 76, 'ContactClientPmId' => 77, 'MasterProjectNumber' => 78, 'ProposedLoi' => 79, 'OpportunityId' => 80, 'SiJobTypeId' => 81, 'BestEffort' => 82, 'JobStatusSfId' => 83, 'BookedBySfId' => 84, 'CreatedBySfId' => 85, 'AccountManagerSfId' => 86, 'CreatedDate' => 87, 'JobQualificationId' => 88, 'ProposedN' => 89, 'GermanJobTypeId' => 90, 'CreatedByComment' => 91, 'FocusVision' => 92, 'SiEuJobType' => 93, 'IntermediateClientId' => 94, 'IntermediateClientContactId' => 95, 'UsGlobalQualGmsId' => 96, 'FaciltyNote' => 97, 'CurrencyIsoCodeId' => 98, 'ClientListDeletionId' => 99, 'CreatedById' => 100, 'UpdatedById' => 101, 'CreatedAt' => 102, 'UpdatedAt' => 103, ),
        self::TYPE_CAMELNAME     => array('id' => 0, 'numeroEtude' => 1, 'referenceClient' => 2, 'masterProjectSfId' => 3, 'theme' => 4, 'dateDebut' => 5, 'dateFin' => 6, 'annee' => 7, 'rst' => 8, 'cli' => 9, 'gqs' => 10, 'ins' => 11, 'hut' => 12, 'displayTotalOnly' => 13, 'idPm' => 14, 'idEtape' => 15, 'prixRevientInitial' => 16, 'prixRevientActualise' => 17, 'prixVenteInitial' => 18, 'prixVenteActualise' => 19, 'consolidatedInvoice' => 20, 'sendCsatQuest' => 21, 'isSendCsatQuestMail' => 22, 'numeroFacture' => 23, 'dontSetAmAuto' => 24, 'setAmReason' => 25, 'amReasonTypeId' => 26, 'dateEnvoiFacture' => 27, 'dateReglement' => 28, 'commentaire' => 29, 'industryId' => 30, 'periodeCutoff' => 31, 'themeBr' => 32, 'areaId' => 33, 'idSamsStudy' => 34, 'recrutementObjectif' => 35, 'idLocationPnl' => 36, 'idMasterProjectLocationPnl' => 37, 'recrutementObjectifPr' => 38, 'idBm' => 39, 'extraInfo' => 40, 'accountId' => 41, 'accountManagerId' => 42, 'projectSpecialtySponsorId' => 43, 'language' => 44, 'remiseTaux' => 45, 'clientDiscountPercentage' => 46, 'endClientDiscountPercentage' => 47, 'clientQuantDiscountPercentage' => 48, 'endClientQuantDiscountPercentage' => 49, 'samplePlan' => 50, 'isToInvoice' => 51, 'filePath' => 52, 'accountLeaderId' => 53, 'accountPMId' => 54, 'amEmail' => 55, 'clientPortalReady' => 56, 'lengthOfInterview' => 57, 'sunshineAct' => 58, 'isConsolidated' => 59, 'sharepointFolder' => 60, 'multiPhase' => 61, 'poNumber' => 62, 'currencies' => 63, 'smsRelance' => 64, 'idEtudeGroup' => 65, 'gms' => 66, 'kol' => 67, 'roomRental' => 68, 'recruitsOffsite' => 69, 'studySpecification' => 70, 'isStudySpecification' => 71, 'additionalNotes' => 72, 'projectComment' => 73, 'endClientId' => 74, 'endClientContactId' => 75, 'contactId' => 76, 'contactClientPmId' => 77, 'masterProjectNumber' => 78, 'proposedLoi' => 79, 'opportunityId' => 80, 'siJobTypeId' => 81, 'bestEffort' => 82, 'jobStatusSfId' => 83, 'bookedBySfId' => 84, 'createdBySfId' => 85, 'accountManagerSfId' => 86, 'createdDate' => 87, 'jobQualificationId' => 88, 'proposedN' => 89, 'germanJobTypeId' => 90, 'createdByComment' => 91, 'focusVision' => 92, 'siEuJobType' => 93, 'intermediateClientId' => 94, 'intermediateClientContactId' => 95, 'usGlobalQualGmsId' => 96, 'faciltyNote' => 97, 'currencyIsoCodeId' => 98, 'clientListDeletionId' => 99, 'createdById' => 100, 'updatedById' => 101, 'createdAt' => 102, 'updatedAt' => 103, ),
        self::TYPE_COLNAME       => array(EtudeTableMap::COL_ID => 0, EtudeTableMap::COL_NUMERO_ETUDE => 1, EtudeTableMap::COL_REFERENCE_CLIENT => 2, EtudeTableMap::COL_MASTER_PROJECT_SF_ID => 3, EtudeTableMap::COL_THEME => 4, EtudeTableMap::COL_DATE_DEBUT => 5, EtudeTableMap::COL_DATE_FIN => 6, EtudeTableMap::COL_ANNEE => 7, EtudeTableMap::COL_RST => 8, EtudeTableMap::COL_CLI => 9, EtudeTableMap::COL_GQS => 10, EtudeTableMap::COL_INS => 11, EtudeTableMap::COL_HUT => 12, EtudeTableMap::COL_DISPLAY_TOTAL_ONLY => 13, EtudeTableMap::COL_ID_PM => 14, EtudeTableMap::COL_ID_ETAPE => 15, EtudeTableMap::COL_PRIX_REVIENT_INITIAL => 16, EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE => 17, EtudeTableMap::COL_PRIX_VENTE_INITIAL => 18, EtudeTableMap::COL_PRIX_VENTE_ACTUALISE => 19, EtudeTableMap::COL_CONSOLIDATED_INVOICE => 20, EtudeTableMap::COL_SEND_CSAT_QUEST => 21, EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL => 22, EtudeTableMap::COL_NUMERO_FACTURE => 23, EtudeTableMap::COL_DONT_SET_AM_AUTO => 24, EtudeTableMap::COL_SET_AM_REASON => 25, EtudeTableMap::COL_AM_REASON_TYPE_ID => 26, EtudeTableMap::COL_DATE_ENVOI_FACTURE => 27, EtudeTableMap::COL_DATE_REGLEMENT => 28, EtudeTableMap::COL_COMMENTAIRE => 29, EtudeTableMap::COL_INDUSTRY_ID => 30, EtudeTableMap::COL_PERIODE_CUTOFF => 31, EtudeTableMap::COL_THEME_BR => 32, EtudeTableMap::COL_AREA_ID => 33, EtudeTableMap::COL_ID_SAMS_STUDY => 34, EtudeTableMap::COL_RECRUTEMENT_OBJECTIF => 35, EtudeTableMap::COL_ID_LOCATION_PNL => 36, EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL => 37, EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR => 38, EtudeTableMap::COL_ID_BM => 39, EtudeTableMap::COL_EXTRA_INFO => 40, EtudeTableMap::COL_ACCOUNT_ID => 41, EtudeTableMap::COL_ACCOUNT_MANAGER_ID => 42, EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID => 43, EtudeTableMap::COL_LANGUAGE => 44, EtudeTableMap::COL_REMISE_TAUX => 45, EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE => 46, EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE => 47, EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE => 48, EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE => 49, EtudeTableMap::COL_SAMPLE_PLAN => 50, EtudeTableMap::COL_ISTOINVOICE => 51, EtudeTableMap::COL_FILE_PATH => 52, EtudeTableMap::COL_ACCOUNT_LEADER_ID => 53, EtudeTableMap::COL_ACCOUNT_PM_ID => 54, EtudeTableMap::COL_AM_EMAIL => 55, EtudeTableMap::COL_CLIENT_PORTAL_READY => 56, EtudeTableMap::COL_LENGTH_OF_INTERVIEW => 57, EtudeTableMap::COL_SUNSHINE_ACT => 58, EtudeTableMap::COL_IS_CONSOLIDATED => 59, EtudeTableMap::COL_SHAREPOINT_FOLDER => 60, EtudeTableMap::COL_MULTI_PHASE => 61, EtudeTableMap::COL_PO_NUMBER => 62, EtudeTableMap::COL_CURRENCIES => 63, EtudeTableMap::COL_SMS_RELANCE => 64, EtudeTableMap::COL_ID_ETUDE_GROUP => 65, EtudeTableMap::COL_GMS => 66, EtudeTableMap::COL_KOL => 67, EtudeTableMap::COL_ROOM_RENTAL => 68, EtudeTableMap::COL_RECRUITS_OFFSITE => 69, EtudeTableMap::COL_STUDY_SPECIFICATION => 70, EtudeTableMap::COL_IS_STUDY_SPECIFICATION => 71, EtudeTableMap::COL_ADDITIONAL_NOTES => 72, EtudeTableMap::COL_PROJECT_COMMENT => 73, EtudeTableMap::COL_END_CLIENT_ID => 74, EtudeTableMap::COL_END_CLIENT_CONTACT_ID => 75, EtudeTableMap::COL_CONTACT_ID => 76, EtudeTableMap::COL_CONTACT_CLIENT_PM_ID => 77, EtudeTableMap::COL_MASTER_PROJECT_NUMBER => 78, EtudeTableMap::COL_PROPOSED_LOI => 79, EtudeTableMap::COL_OPPORTUNITY_ID => 80, EtudeTableMap::COL_SI_JOB_TYPE_ID => 81, EtudeTableMap::COL_BEST_EFFORT => 82, EtudeTableMap::COL_JOB_STATUS_SF_ID => 83, EtudeTableMap::COL_BOOKED_BY_SF_ID => 84, EtudeTableMap::COL_CREATED_BY_SF_ID => 85, EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID => 86, EtudeTableMap::COL_CREATED_DATE => 87, EtudeTableMap::COL_JOB_QUALIFICATION_ID => 88, EtudeTableMap::COL_PROPOSED_N => 89, EtudeTableMap::COL_GERMAN_JOB_TYPE_ID => 90, EtudeTableMap::COL_CREATED_BY_COMMENT => 91, EtudeTableMap::COL_FOCUS_VISION => 92, EtudeTableMap::COL_SI_EU_JOB_TYPE => 93, EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID => 94, EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID => 95, EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID => 96, EtudeTableMap::COL_FACILTY_NOTE => 97, EtudeTableMap::COL_CURRENCY_ISO_CODE_ID => 98, EtudeTableMap::COL_CLIENT_LIST_DELETION_ID => 99, EtudeTableMap::COL_CREATED_BY_ID => 100, EtudeTableMap::COL_UPDATED_BY_ID => 101, EtudeTableMap::COL_CREATED_AT => 102, EtudeTableMap::COL_UPDATED_AT => 103, ),
        self::TYPE_FIELDNAME     => array('id' => 0, 'numero_etude' => 1, 'reference_client' => 2, 'master_project_sf_id' => 3, 'theme' => 4, 'date_debut' => 5, 'date_fin' => 6, 'annee' => 7, 'rst' => 8, 'cli' => 9, 'gqs' => 10, 'ins' => 11, 'hut' => 12, 'display_total_only' => 13, 'id_pm' => 14, 'id_etape' => 15, 'prix_revient_initial' => 16, 'prix_revient_actualise' => 17, 'prix_vente_initial' => 18, 'prix_vente_actualise' => 19, 'consolidated_invoice' => 20, 'send_csat_quest' => 21, 'is_send_csat_quest_mail' => 22, 'numero_facture' => 23, 'dont_set_am_auto' => 24, 'set_am_reason' => 25, 'am_reason_type_id' => 26, 'date_envoi_facture' => 27, 'date_reglement' => 28, 'commentaire' => 29, 'industry_id' => 30, 'periode_cutoff' => 31, 'theme_br' => 32, 'area_id' => 33, 'id_sams_study' => 34, 'recrutement_objectif' => 35, 'id_location_pnl' => 36, 'id_master_project_location_pnl' => 37, 'recrutement_objectif_pr' => 38, 'id_bm' => 39, 'extra_info' => 40, 'account_id' => 41, 'account_manager_id' => 42, 'project_specialty_sponsor_id' => 43, 'language' => 44, 'remise_taux' => 45, 'client_discount_percentage' => 46, 'end_client_discount_percentage' => 47, 'client_quant_discount_percentage' => 48, 'end_client_quant_discount_percentage' => 49, 'sample_plan' => 50, 'isToInvoice' => 51, 'file_path' => 52, 'account_leader_id' => 53, 'account_pm_id' => 54, 'am_email' => 55, 'client_portal_ready' => 56, 'length_of_interview' => 57, 'sunshine_act' => 58, 'is_consolidated' => 59, 'sharepoint_folder' => 60, 'multi_phase' => 61, 'po_number' => 62, 'currencies' => 63, 'sms_relance' => 64, 'id_etude_group' => 65, 'gms' => 66, 'kol' => 67, 'room_rental' => 68, 'recruits_offsite' => 69, 'study_specification' => 70, 'is_study_specification' => 71, 'additional_notes' => 72, 'project_comment' => 73, 'end_client_id' => 74, 'end_client_contact_id' => 75, 'contact_id' => 76, 'contact_client_pm_id' => 77, 'master_project_number' => 78, 'proposed_loi' => 79, 'opportunity_id' => 80, 'si_job_type_id' => 81, 'best_effort' => 82, 'job_status_sf_id' => 83, 'booked_by_sf_id' => 84, 'created_by_sf_id' => 85, 'account_manager_sf_id' => 86, 'created_date' => 87, 'job_qualification_id' => 88, 'proposed_n' => 89, 'german_job_type_id' => 90, 'created_by_comment' => 91, 'focus_vision' => 92, 'si_eu_job_type' => 93, 'intermediate_client_id' => 94, 'intermediate_client_contact_id' => 95, 'us_global_qual_gms_id' => 96, 'facilty_note' => 97, 'currency_iso_code_id' => 98, 'client_list_deletion_id' => 99, 'created_by_id' => 100, 'updated_by_id' => 101, 'created_at' => 102, 'updated_at' => 103, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, )
    );

    /**
     * Holds a list of column names and their normalized version.
     *
     * @var string[]
     */
    protected $normalizedColumnNameMap = [
        'Id' => 'ID',
        'Etude.Id' => 'ID',
        'id' => 'ID',
        'etude.id' => 'ID',
        'EtudeTableMap::COL_ID' => 'ID',
        'COL_ID' => 'ID',
        'NumeroEtude' => 'NUMERO_ETUDE',
        'Etude.NumeroEtude' => 'NUMERO_ETUDE',
        'numeroEtude' => 'NUMERO_ETUDE',
        'etude.numeroEtude' => 'NUMERO_ETUDE',
        'EtudeTableMap::COL_NUMERO_ETUDE' => 'NUMERO_ETUDE',
        'COL_NUMERO_ETUDE' => 'NUMERO_ETUDE',
        'numero_etude' => 'NUMERO_ETUDE',
        'etude.numero_etude' => 'NUMERO_ETUDE',
        'ReferenceClient' => 'REFERENCE_CLIENT',
        'Etude.ReferenceClient' => 'REFERENCE_CLIENT',
        'referenceClient' => 'REFERENCE_CLIENT',
        'etude.referenceClient' => 'REFERENCE_CLIENT',
        'EtudeTableMap::COL_REFERENCE_CLIENT' => 'REFERENCE_CLIENT',
        'COL_REFERENCE_CLIENT' => 'REFERENCE_CLIENT',
        'reference_client' => 'REFERENCE_CLIENT',
        'etude.reference_client' => 'REFERENCE_CLIENT',
        'MasterProjectSfId' => 'MASTER_PROJECT_SF_ID',
        'Etude.MasterProjectSfId' => 'MASTER_PROJECT_SF_ID',
        'masterProjectSfId' => 'MASTER_PROJECT_SF_ID',
        'etude.masterProjectSfId' => 'MASTER_PROJECT_SF_ID',
        'EtudeTableMap::COL_MASTER_PROJECT_SF_ID' => 'MASTER_PROJECT_SF_ID',
        'COL_MASTER_PROJECT_SF_ID' => 'MASTER_PROJECT_SF_ID',
        'master_project_sf_id' => 'MASTER_PROJECT_SF_ID',
        'etude.master_project_sf_id' => 'MASTER_PROJECT_SF_ID',
        'Theme' => 'THEME',
        'Etude.Theme' => 'THEME',
        'theme' => 'THEME',
        'etude.theme' => 'THEME',
        'EtudeTableMap::COL_THEME' => 'THEME',
        'COL_THEME' => 'THEME',
        'DateDebut' => 'DATE_DEBUT',
        'Etude.DateDebut' => 'DATE_DEBUT',
        'dateDebut' => 'DATE_DEBUT',
        'etude.dateDebut' => 'DATE_DEBUT',
        'EtudeTableMap::COL_DATE_DEBUT' => 'DATE_DEBUT',
        'COL_DATE_DEBUT' => 'DATE_DEBUT',
        'date_debut' => 'DATE_DEBUT',
        'etude.date_debut' => 'DATE_DEBUT',
        'DateFin' => 'DATE_FIN',
        'Etude.DateFin' => 'DATE_FIN',
        'dateFin' => 'DATE_FIN',
        'etude.dateFin' => 'DATE_FIN',
        'EtudeTableMap::COL_DATE_FIN' => 'DATE_FIN',
        'COL_DATE_FIN' => 'DATE_FIN',
        'date_fin' => 'DATE_FIN',
        'etude.date_fin' => 'DATE_FIN',
        'Annee' => 'ANNEE',
        'Etude.Annee' => 'ANNEE',
        'annee' => 'ANNEE',
        'etude.annee' => 'ANNEE',
        'EtudeTableMap::COL_ANNEE' => 'ANNEE',
        'COL_ANNEE' => 'ANNEE',
        'Rst' => 'RST',
        'Etude.Rst' => 'RST',
        'rst' => 'RST',
        'etude.rst' => 'RST',
        'EtudeTableMap::COL_RST' => 'RST',
        'COL_RST' => 'RST',
        'Cli' => 'CLI',
        'Etude.Cli' => 'CLI',
        'cli' => 'CLI',
        'etude.cli' => 'CLI',
        'EtudeTableMap::COL_CLI' => 'CLI',
        'COL_CLI' => 'CLI',
        'Gqs' => 'GQS',
        'Etude.Gqs' => 'GQS',
        'gqs' => 'GQS',
        'etude.gqs' => 'GQS',
        'EtudeTableMap::COL_GQS' => 'GQS',
        'COL_GQS' => 'GQS',
        'Ins' => 'INS',
        'Etude.Ins' => 'INS',
        'ins' => 'INS',
        'etude.ins' => 'INS',
        'EtudeTableMap::COL_INS' => 'INS',
        'COL_INS' => 'INS',
        'Hut' => 'HUT',
        'Etude.Hut' => 'HUT',
        'hut' => 'HUT',
        'etude.hut' => 'HUT',
        'EtudeTableMap::COL_HUT' => 'HUT',
        'COL_HUT' => 'HUT',
        'DisplayTotalOnly' => 'DISPLAY_TOTAL_ONLY',
        'Etude.DisplayTotalOnly' => 'DISPLAY_TOTAL_ONLY',
        'displayTotalOnly' => 'DISPLAY_TOTAL_ONLY',
        'etude.displayTotalOnly' => 'DISPLAY_TOTAL_ONLY',
        'EtudeTableMap::COL_DISPLAY_TOTAL_ONLY' => 'DISPLAY_TOTAL_ONLY',
        'COL_DISPLAY_TOTAL_ONLY' => 'DISPLAY_TOTAL_ONLY',
        'display_total_only' => 'DISPLAY_TOTAL_ONLY',
        'etude.display_total_only' => 'DISPLAY_TOTAL_ONLY',
        'IdPm' => 'ID_PM',
        'Etude.IdPm' => 'ID_PM',
        'idPm' => 'ID_PM',
        'etude.idPm' => 'ID_PM',
        'EtudeTableMap::COL_ID_PM' => 'ID_PM',
        'COL_ID_PM' => 'ID_PM',
        'id_pm' => 'ID_PM',
        'etude.id_pm' => 'ID_PM',
        'IdEtape' => 'ID_ETAPE',
        'Etude.IdEtape' => 'ID_ETAPE',
        'idEtape' => 'ID_ETAPE',
        'etude.idEtape' => 'ID_ETAPE',
        'EtudeTableMap::COL_ID_ETAPE' => 'ID_ETAPE',
        'COL_ID_ETAPE' => 'ID_ETAPE',
        'id_etape' => 'ID_ETAPE',
        'etude.id_etape' => 'ID_ETAPE',
        'PrixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'Etude.PrixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'prixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'etude.prixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'EtudeTableMap::COL_PRIX_REVIENT_INITIAL' => 'PRIX_REVIENT_INITIAL',
        'COL_PRIX_REVIENT_INITIAL' => 'PRIX_REVIENT_INITIAL',
        'prix_revient_initial' => 'PRIX_REVIENT_INITIAL',
        'etude.prix_revient_initial' => 'PRIX_REVIENT_INITIAL',
        'PrixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'Etude.PrixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'prixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'etude.prixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE' => 'PRIX_REVIENT_ACTUALISE',
        'COL_PRIX_REVIENT_ACTUALISE' => 'PRIX_REVIENT_ACTUALISE',
        'prix_revient_actualise' => 'PRIX_REVIENT_ACTUALISE',
        'etude.prix_revient_actualise' => 'PRIX_REVIENT_ACTUALISE',
        'PrixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'Etude.PrixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'prixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'etude.prixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'EtudeTableMap::COL_PRIX_VENTE_INITIAL' => 'PRIX_VENTE_INITIAL',
        'COL_PRIX_VENTE_INITIAL' => 'PRIX_VENTE_INITIAL',
        'prix_vente_initial' => 'PRIX_VENTE_INITIAL',
        'etude.prix_vente_initial' => 'PRIX_VENTE_INITIAL',
        'PrixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'Etude.PrixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'prixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'etude.prixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'EtudeTableMap::COL_PRIX_VENTE_ACTUALISE' => 'PRIX_VENTE_ACTUALISE',
        'COL_PRIX_VENTE_ACTUALISE' => 'PRIX_VENTE_ACTUALISE',
        'prix_vente_actualise' => 'PRIX_VENTE_ACTUALISE',
        'etude.prix_vente_actualise' => 'PRIX_VENTE_ACTUALISE',
        'ConsolidatedInvoice' => 'CONSOLIDATED_INVOICE',
        'Etude.ConsolidatedInvoice' => 'CONSOLIDATED_INVOICE',
        'consolidatedInvoice' => 'CONSOLIDATED_INVOICE',
        'etude.consolidatedInvoice' => 'CONSOLIDATED_INVOICE',
        'EtudeTableMap::COL_CONSOLIDATED_INVOICE' => 'CONSOLIDATED_INVOICE',
        'COL_CONSOLIDATED_INVOICE' => 'CONSOLIDATED_INVOICE',
        'consolidated_invoice' => 'CONSOLIDATED_INVOICE',
        'etude.consolidated_invoice' => 'CONSOLIDATED_INVOICE',
        'SendCsatQuest' => 'SEND_CSAT_QUEST',
        'Etude.SendCsatQuest' => 'SEND_CSAT_QUEST',
        'sendCsatQuest' => 'SEND_CSAT_QUEST',
        'etude.sendCsatQuest' => 'SEND_CSAT_QUEST',
        'EtudeTableMap::COL_SEND_CSAT_QUEST' => 'SEND_CSAT_QUEST',
        'COL_SEND_CSAT_QUEST' => 'SEND_CSAT_QUEST',
        'send_csat_quest' => 'SEND_CSAT_QUEST',
        'etude.send_csat_quest' => 'SEND_CSAT_QUEST',
        'IsSendCsatQuestMail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'Etude.IsSendCsatQuestMail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'isSendCsatQuestMail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'etude.isSendCsatQuestMail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL' => 'IS_SEND_CSAT_QUEST_MAIL',
        'COL_IS_SEND_CSAT_QUEST_MAIL' => 'IS_SEND_CSAT_QUEST_MAIL',
        'is_send_csat_quest_mail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'etude.is_send_csat_quest_mail' => 'IS_SEND_CSAT_QUEST_MAIL',
        'NumeroFacture' => 'NUMERO_FACTURE',
        'Etude.NumeroFacture' => 'NUMERO_FACTURE',
        'numeroFacture' => 'NUMERO_FACTURE',
        'etude.numeroFacture' => 'NUMERO_FACTURE',
        'EtudeTableMap::COL_NUMERO_FACTURE' => 'NUMERO_FACTURE',
        'COL_NUMERO_FACTURE' => 'NUMERO_FACTURE',
        'numero_facture' => 'NUMERO_FACTURE',
        'etude.numero_facture' => 'NUMERO_FACTURE',
        'DontSetAmAuto' => 'DONT_SET_AM_AUTO',
        'Etude.DontSetAmAuto' => 'DONT_SET_AM_AUTO',
        'dontSetAmAuto' => 'DONT_SET_AM_AUTO',
        'etude.dontSetAmAuto' => 'DONT_SET_AM_AUTO',
        'EtudeTableMap::COL_DONT_SET_AM_AUTO' => 'DONT_SET_AM_AUTO',
        'COL_DONT_SET_AM_AUTO' => 'DONT_SET_AM_AUTO',
        'dont_set_am_auto' => 'DONT_SET_AM_AUTO',
        'etude.dont_set_am_auto' => 'DONT_SET_AM_AUTO',
        'SetAmReason' => 'SET_AM_REASON',
        'Etude.SetAmReason' => 'SET_AM_REASON',
        'setAmReason' => 'SET_AM_REASON',
        'etude.setAmReason' => 'SET_AM_REASON',
        'EtudeTableMap::COL_SET_AM_REASON' => 'SET_AM_REASON',
        'COL_SET_AM_REASON' => 'SET_AM_REASON',
        'set_am_reason' => 'SET_AM_REASON',
        'etude.set_am_reason' => 'SET_AM_REASON',
        'AmReasonTypeId' => 'AM_REASON_TYPE_ID',
        'Etude.AmReasonTypeId' => 'AM_REASON_TYPE_ID',
        'amReasonTypeId' => 'AM_REASON_TYPE_ID',
        'etude.amReasonTypeId' => 'AM_REASON_TYPE_ID',
        'EtudeTableMap::COL_AM_REASON_TYPE_ID' => 'AM_REASON_TYPE_ID',
        'COL_AM_REASON_TYPE_ID' => 'AM_REASON_TYPE_ID',
        'am_reason_type_id' => 'AM_REASON_TYPE_ID',
        'etude.am_reason_type_id' => 'AM_REASON_TYPE_ID',
        'DateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'Etude.DateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'dateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'etude.dateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'EtudeTableMap::COL_DATE_ENVOI_FACTURE' => 'DATE_ENVOI_FACTURE',
        'COL_DATE_ENVOI_FACTURE' => 'DATE_ENVOI_FACTURE',
        'date_envoi_facture' => 'DATE_ENVOI_FACTURE',
        'etude.date_envoi_facture' => 'DATE_ENVOI_FACTURE',
        'DateReglement' => 'DATE_REGLEMENT',
        'Etude.DateReglement' => 'DATE_REGLEMENT',
        'dateReglement' => 'DATE_REGLEMENT',
        'etude.dateReglement' => 'DATE_REGLEMENT',
        'EtudeTableMap::COL_DATE_REGLEMENT' => 'DATE_REGLEMENT',
        'COL_DATE_REGLEMENT' => 'DATE_REGLEMENT',
        'date_reglement' => 'DATE_REGLEMENT',
        'etude.date_reglement' => 'DATE_REGLEMENT',
        'Commentaire' => 'COMMENTAIRE',
        'Etude.Commentaire' => 'COMMENTAIRE',
        'commentaire' => 'COMMENTAIRE',
        'etude.commentaire' => 'COMMENTAIRE',
        'EtudeTableMap::COL_COMMENTAIRE' => 'COMMENTAIRE',
        'COL_COMMENTAIRE' => 'COMMENTAIRE',
        'IndustryId' => 'INDUSTRY_ID',
        'Etude.IndustryId' => 'INDUSTRY_ID',
        'industryId' => 'INDUSTRY_ID',
        'etude.industryId' => 'INDUSTRY_ID',
        'EtudeTableMap::COL_INDUSTRY_ID' => 'INDUSTRY_ID',
        'COL_INDUSTRY_ID' => 'INDUSTRY_ID',
        'industry_id' => 'INDUSTRY_ID',
        'etude.industry_id' => 'INDUSTRY_ID',
        'PeriodeCutoff' => 'PERIODE_CUTOFF',
        'Etude.PeriodeCutoff' => 'PERIODE_CUTOFF',
        'periodeCutoff' => 'PERIODE_CUTOFF',
        'etude.periodeCutoff' => 'PERIODE_CUTOFF',
        'EtudeTableMap::COL_PERIODE_CUTOFF' => 'PERIODE_CUTOFF',
        'COL_PERIODE_CUTOFF' => 'PERIODE_CUTOFF',
        'periode_cutoff' => 'PERIODE_CUTOFF',
        'etude.periode_cutoff' => 'PERIODE_CUTOFF',
        'ThemeBr' => 'THEME_BR',
        'Etude.ThemeBr' => 'THEME_BR',
        'themeBr' => 'THEME_BR',
        'etude.themeBr' => 'THEME_BR',
        'EtudeTableMap::COL_THEME_BR' => 'THEME_BR',
        'COL_THEME_BR' => 'THEME_BR',
        'theme_br' => 'THEME_BR',
        'etude.theme_br' => 'THEME_BR',
        'AreaId' => 'AREA_ID',
        'Etude.AreaId' => 'AREA_ID',
        'areaId' => 'AREA_ID',
        'etude.areaId' => 'AREA_ID',
        'EtudeTableMap::COL_AREA_ID' => 'AREA_ID',
        'COL_AREA_ID' => 'AREA_ID',
        'area_id' => 'AREA_ID',
        'etude.area_id' => 'AREA_ID',
        'IdSamsStudy' => 'ID_SAMS_STUDY',
        'Etude.IdSamsStudy' => 'ID_SAMS_STUDY',
        'idSamsStudy' => 'ID_SAMS_STUDY',
        'etude.idSamsStudy' => 'ID_SAMS_STUDY',
        'EtudeTableMap::COL_ID_SAMS_STUDY' => 'ID_SAMS_STUDY',
        'COL_ID_SAMS_STUDY' => 'ID_SAMS_STUDY',
        'id_sams_study' => 'ID_SAMS_STUDY',
        'etude.id_sams_study' => 'ID_SAMS_STUDY',
        'RecrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'Etude.RecrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'recrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'etude.recrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'EtudeTableMap::COL_RECRUTEMENT_OBJECTIF' => 'RECRUTEMENT_OBJECTIF',
        'COL_RECRUTEMENT_OBJECTIF' => 'RECRUTEMENT_OBJECTIF',
        'recrutement_objectif' => 'RECRUTEMENT_OBJECTIF',
        'etude.recrutement_objectif' => 'RECRUTEMENT_OBJECTIF',
        'IdLocationPnl' => 'ID_LOCATION_PNL',
        'Etude.IdLocationPnl' => 'ID_LOCATION_PNL',
        'idLocationPnl' => 'ID_LOCATION_PNL',
        'etude.idLocationPnl' => 'ID_LOCATION_PNL',
        'EtudeTableMap::COL_ID_LOCATION_PNL' => 'ID_LOCATION_PNL',
        'COL_ID_LOCATION_PNL' => 'ID_LOCATION_PNL',
        'id_location_pnl' => 'ID_LOCATION_PNL',
        'etude.id_location_pnl' => 'ID_LOCATION_PNL',
        'IdMasterProjectLocationPnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'Etude.IdMasterProjectLocationPnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'idMasterProjectLocationPnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'etude.idMasterProjectLocationPnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'COL_ID_MASTER_PROJECT_LOCATION_PNL' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'id_master_project_location_pnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'etude.id_master_project_location_pnl' => 'ID_MASTER_PROJECT_LOCATION_PNL',
        'RecrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'Etude.RecrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'recrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'etude.recrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR' => 'RECRUTEMENT_OBJECTIF_PR',
        'COL_RECRUTEMENT_OBJECTIF_PR' => 'RECRUTEMENT_OBJECTIF_PR',
        'recrutement_objectif_pr' => 'RECRUTEMENT_OBJECTIF_PR',
        'etude.recrutement_objectif_pr' => 'RECRUTEMENT_OBJECTIF_PR',
        'IdBm' => 'ID_BM',
        'Etude.IdBm' => 'ID_BM',
        'idBm' => 'ID_BM',
        'etude.idBm' => 'ID_BM',
        'EtudeTableMap::COL_ID_BM' => 'ID_BM',
        'COL_ID_BM' => 'ID_BM',
        'id_bm' => 'ID_BM',
        'etude.id_bm' => 'ID_BM',
        'ExtraInfo' => 'EXTRA_INFO',
        'Etude.ExtraInfo' => 'EXTRA_INFO',
        'extraInfo' => 'EXTRA_INFO',
        'etude.extraInfo' => 'EXTRA_INFO',
        'EtudeTableMap::COL_EXTRA_INFO' => 'EXTRA_INFO',
        'COL_EXTRA_INFO' => 'EXTRA_INFO',
        'extra_info' => 'EXTRA_INFO',
        'etude.extra_info' => 'EXTRA_INFO',
        'AccountId' => 'ACCOUNT_ID',
        'Etude.AccountId' => 'ACCOUNT_ID',
        'accountId' => 'ACCOUNT_ID',
        'etude.accountId' => 'ACCOUNT_ID',
        'EtudeTableMap::COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'account_id' => 'ACCOUNT_ID',
        'etude.account_id' => 'ACCOUNT_ID',
        'AccountManagerId' => 'ACCOUNT_MANAGER_ID',
        'Etude.AccountManagerId' => 'ACCOUNT_MANAGER_ID',
        'accountManagerId' => 'ACCOUNT_MANAGER_ID',
        'etude.accountManagerId' => 'ACCOUNT_MANAGER_ID',
        'EtudeTableMap::COL_ACCOUNT_MANAGER_ID' => 'ACCOUNT_MANAGER_ID',
        'COL_ACCOUNT_MANAGER_ID' => 'ACCOUNT_MANAGER_ID',
        'account_manager_id' => 'ACCOUNT_MANAGER_ID',
        'etude.account_manager_id' => 'ACCOUNT_MANAGER_ID',
        'ProjectSpecialtySponsorId' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'Etude.ProjectSpecialtySponsorId' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'projectSpecialtySponsorId' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'etude.projectSpecialtySponsorId' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'COL_PROJECT_SPECIALTY_SPONSOR_ID' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'project_specialty_sponsor_id' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'etude.project_specialty_sponsor_id' => 'PROJECT_SPECIALTY_SPONSOR_ID',
        'Language' => 'LANGUAGE',
        'Etude.Language' => 'LANGUAGE',
        'language' => 'LANGUAGE',
        'etude.language' => 'LANGUAGE',
        'EtudeTableMap::COL_LANGUAGE' => 'LANGUAGE',
        'COL_LANGUAGE' => 'LANGUAGE',
        'RemiseTaux' => 'REMISE_TAUX',
        'Etude.RemiseTaux' => 'REMISE_TAUX',
        'remiseTaux' => 'REMISE_TAUX',
        'etude.remiseTaux' => 'REMISE_TAUX',
        'EtudeTableMap::COL_REMISE_TAUX' => 'REMISE_TAUX',
        'COL_REMISE_TAUX' => 'REMISE_TAUX',
        'remise_taux' => 'REMISE_TAUX',
        'etude.remise_taux' => 'REMISE_TAUX',
        'ClientDiscountPercentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'Etude.ClientDiscountPercentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'clientDiscountPercentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'etude.clientDiscountPercentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'COL_CLIENT_DISCOUNT_PERCENTAGE' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'client_discount_percentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'etude.client_discount_percentage' => 'CLIENT_DISCOUNT_PERCENTAGE',
        'EndClientDiscountPercentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'Etude.EndClientDiscountPercentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'endClientDiscountPercentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'etude.endClientDiscountPercentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'COL_END_CLIENT_DISCOUNT_PERCENTAGE' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'end_client_discount_percentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'etude.end_client_discount_percentage' => 'END_CLIENT_DISCOUNT_PERCENTAGE',
        'ClientQuantDiscountPercentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'Etude.ClientQuantDiscountPercentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'clientQuantDiscountPercentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'etude.clientQuantDiscountPercentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'client_quant_discount_percentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'etude.client_quant_discount_percentage' => 'CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'EndClientQuantDiscountPercentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'Etude.EndClientQuantDiscountPercentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'endClientQuantDiscountPercentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'etude.endClientQuantDiscountPercentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'end_client_quant_discount_percentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'etude.end_client_quant_discount_percentage' => 'END_CLIENT_QUANT_DISCOUNT_PERCENTAGE',
        'SamplePlan' => 'SAMPLE_PLAN',
        'Etude.SamplePlan' => 'SAMPLE_PLAN',
        'samplePlan' => 'SAMPLE_PLAN',
        'etude.samplePlan' => 'SAMPLE_PLAN',
        'EtudeTableMap::COL_SAMPLE_PLAN' => 'SAMPLE_PLAN',
        'COL_SAMPLE_PLAN' => 'SAMPLE_PLAN',
        'sample_plan' => 'SAMPLE_PLAN',
        'etude.sample_plan' => 'SAMPLE_PLAN',
        'IsToInvoice' => 'ISTOINVOICE',
        'Etude.IsToInvoice' => 'ISTOINVOICE',
        'isToInvoice' => 'ISTOINVOICE',
        'etude.isToInvoice' => 'ISTOINVOICE',
        'EtudeTableMap::COL_ISTOINVOICE' => 'ISTOINVOICE',
        'COL_ISTOINVOICE' => 'ISTOINVOICE',
        'FilePath' => 'FILE_PATH',
        'Etude.FilePath' => 'FILE_PATH',
        'filePath' => 'FILE_PATH',
        'etude.filePath' => 'FILE_PATH',
        'EtudeTableMap::COL_FILE_PATH' => 'FILE_PATH',
        'COL_FILE_PATH' => 'FILE_PATH',
        'file_path' => 'FILE_PATH',
        'etude.file_path' => 'FILE_PATH',
        'AccountLeaderId' => 'ACCOUNT_LEADER_ID',
        'Etude.AccountLeaderId' => 'ACCOUNT_LEADER_ID',
        'accountLeaderId' => 'ACCOUNT_LEADER_ID',
        'etude.accountLeaderId' => 'ACCOUNT_LEADER_ID',
        'EtudeTableMap::COL_ACCOUNT_LEADER_ID' => 'ACCOUNT_LEADER_ID',
        'COL_ACCOUNT_LEADER_ID' => 'ACCOUNT_LEADER_ID',
        'account_leader_id' => 'ACCOUNT_LEADER_ID',
        'etude.account_leader_id' => 'ACCOUNT_LEADER_ID',
        'AccountPMId' => 'ACCOUNT_PM_ID',
        'Etude.AccountPMId' => 'ACCOUNT_PM_ID',
        'accountPMId' => 'ACCOUNT_PM_ID',
        'etude.accountPMId' => 'ACCOUNT_PM_ID',
        'EtudeTableMap::COL_ACCOUNT_PM_ID' => 'ACCOUNT_PM_ID',
        'COL_ACCOUNT_PM_ID' => 'ACCOUNT_PM_ID',
        'account_pm_id' => 'ACCOUNT_PM_ID',
        'etude.account_pm_id' => 'ACCOUNT_PM_ID',
        'AmEmail' => 'AM_EMAIL',
        'Etude.AmEmail' => 'AM_EMAIL',
        'amEmail' => 'AM_EMAIL',
        'etude.amEmail' => 'AM_EMAIL',
        'EtudeTableMap::COL_AM_EMAIL' => 'AM_EMAIL',
        'COL_AM_EMAIL' => 'AM_EMAIL',
        'am_email' => 'AM_EMAIL',
        'etude.am_email' => 'AM_EMAIL',
        'ClientPortalReady' => 'CLIENT_PORTAL_READY',
        'Etude.ClientPortalReady' => 'CLIENT_PORTAL_READY',
        'clientPortalReady' => 'CLIENT_PORTAL_READY',
        'etude.clientPortalReady' => 'CLIENT_PORTAL_READY',
        'EtudeTableMap::COL_CLIENT_PORTAL_READY' => 'CLIENT_PORTAL_READY',
        'COL_CLIENT_PORTAL_READY' => 'CLIENT_PORTAL_READY',
        'client_portal_ready' => 'CLIENT_PORTAL_READY',
        'etude.client_portal_ready' => 'CLIENT_PORTAL_READY',
        'LengthOfInterview' => 'LENGTH_OF_INTERVIEW',
        'Etude.LengthOfInterview' => 'LENGTH_OF_INTERVIEW',
        'lengthOfInterview' => 'LENGTH_OF_INTERVIEW',
        'etude.lengthOfInterview' => 'LENGTH_OF_INTERVIEW',
        'EtudeTableMap::COL_LENGTH_OF_INTERVIEW' => 'LENGTH_OF_INTERVIEW',
        'COL_LENGTH_OF_INTERVIEW' => 'LENGTH_OF_INTERVIEW',
        'length_of_interview' => 'LENGTH_OF_INTERVIEW',
        'etude.length_of_interview' => 'LENGTH_OF_INTERVIEW',
        'sunshineAct' => 'SUNSHINE_ACT',
        'Etude.sunshineAct' => 'SUNSHINE_ACT',
        'etude.sunshineAct' => 'SUNSHINE_ACT',
        'EtudeTableMap::COL_SUNSHINE_ACT' => 'SUNSHINE_ACT',
        'COL_SUNSHINE_ACT' => 'SUNSHINE_ACT',
        'sunshine_act' => 'SUNSHINE_ACT',
        'etude.sunshine_act' => 'SUNSHINE_ACT',
        'IsConsolidated' => 'IS_CONSOLIDATED',
        'Etude.IsConsolidated' => 'IS_CONSOLIDATED',
        'isConsolidated' => 'IS_CONSOLIDATED',
        'etude.isConsolidated' => 'IS_CONSOLIDATED',
        'EtudeTableMap::COL_IS_CONSOLIDATED' => 'IS_CONSOLIDATED',
        'COL_IS_CONSOLIDATED' => 'IS_CONSOLIDATED',
        'is_consolidated' => 'IS_CONSOLIDATED',
        'etude.is_consolidated' => 'IS_CONSOLIDATED',
        'SharepointFolder' => 'SHAREPOINT_FOLDER',
        'Etude.SharepointFolder' => 'SHAREPOINT_FOLDER',
        'sharepointFolder' => 'SHAREPOINT_FOLDER',
        'etude.sharepointFolder' => 'SHAREPOINT_FOLDER',
        'EtudeTableMap::COL_SHAREPOINT_FOLDER' => 'SHAREPOINT_FOLDER',
        'COL_SHAREPOINT_FOLDER' => 'SHAREPOINT_FOLDER',
        'sharepoint_folder' => 'SHAREPOINT_FOLDER',
        'etude.sharepoint_folder' => 'SHAREPOINT_FOLDER',
        'MultiPhase' => 'MULTI_PHASE',
        'Etude.MultiPhase' => 'MULTI_PHASE',
        'multiPhase' => 'MULTI_PHASE',
        'etude.multiPhase' => 'MULTI_PHASE',
        'EtudeTableMap::COL_MULTI_PHASE' => 'MULTI_PHASE',
        'COL_MULTI_PHASE' => 'MULTI_PHASE',
        'multi_phase' => 'MULTI_PHASE',
        'etude.multi_phase' => 'MULTI_PHASE',
        'PoNumber' => 'PO_NUMBER',
        'Etude.PoNumber' => 'PO_NUMBER',
        'poNumber' => 'PO_NUMBER',
        'etude.poNumber' => 'PO_NUMBER',
        'EtudeTableMap::COL_PO_NUMBER' => 'PO_NUMBER',
        'COL_PO_NUMBER' => 'PO_NUMBER',
        'po_number' => 'PO_NUMBER',
        'etude.po_number' => 'PO_NUMBER',
        'Currencies' => 'CURRENCIES',
        'Etude.Currencies' => 'CURRENCIES',
        'currencies' => 'CURRENCIES',
        'etude.currencies' => 'CURRENCIES',
        'EtudeTableMap::COL_CURRENCIES' => 'CURRENCIES',
        'COL_CURRENCIES' => 'CURRENCIES',
        'SmsRelance' => 'SMS_RELANCE',
        'Etude.SmsRelance' => 'SMS_RELANCE',
        'smsRelance' => 'SMS_RELANCE',
        'etude.smsRelance' => 'SMS_RELANCE',
        'EtudeTableMap::COL_SMS_RELANCE' => 'SMS_RELANCE',
        'COL_SMS_RELANCE' => 'SMS_RELANCE',
        'sms_relance' => 'SMS_RELANCE',
        'etude.sms_relance' => 'SMS_RELANCE',
        'IdEtudeGroup' => 'ID_ETUDE_GROUP',
        'Etude.IdEtudeGroup' => 'ID_ETUDE_GROUP',
        'idEtudeGroup' => 'ID_ETUDE_GROUP',
        'etude.idEtudeGroup' => 'ID_ETUDE_GROUP',
        'EtudeTableMap::COL_ID_ETUDE_GROUP' => 'ID_ETUDE_GROUP',
        'COL_ID_ETUDE_GROUP' => 'ID_ETUDE_GROUP',
        'id_etude_group' => 'ID_ETUDE_GROUP',
        'etude.id_etude_group' => 'ID_ETUDE_GROUP',
        'Gms' => 'GMS',
        'Etude.Gms' => 'GMS',
        'gms' => 'GMS',
        'etude.gms' => 'GMS',
        'EtudeTableMap::COL_GMS' => 'GMS',
        'COL_GMS' => 'GMS',
        'Kol' => 'KOL',
        'Etude.Kol' => 'KOL',
        'kol' => 'KOL',
        'etude.kol' => 'KOL',
        'EtudeTableMap::COL_KOL' => 'KOL',
        'COL_KOL' => 'KOL',
        'RoomRental' => 'ROOM_RENTAL',
        'Etude.RoomRental' => 'ROOM_RENTAL',
        'roomRental' => 'ROOM_RENTAL',
        'etude.roomRental' => 'ROOM_RENTAL',
        'EtudeTableMap::COL_ROOM_RENTAL' => 'ROOM_RENTAL',
        'COL_ROOM_RENTAL' => 'ROOM_RENTAL',
        'room_rental' => 'ROOM_RENTAL',
        'etude.room_rental' => 'ROOM_RENTAL',
        'RecruitsOffsite' => 'RECRUITS_OFFSITE',
        'Etude.RecruitsOffsite' => 'RECRUITS_OFFSITE',
        'recruitsOffsite' => 'RECRUITS_OFFSITE',
        'etude.recruitsOffsite' => 'RECRUITS_OFFSITE',
        'EtudeTableMap::COL_RECRUITS_OFFSITE' => 'RECRUITS_OFFSITE',
        'COL_RECRUITS_OFFSITE' => 'RECRUITS_OFFSITE',
        'recruits_offsite' => 'RECRUITS_OFFSITE',
        'etude.recruits_offsite' => 'RECRUITS_OFFSITE',
        'StudySpecification' => 'STUDY_SPECIFICATION',
        'Etude.StudySpecification' => 'STUDY_SPECIFICATION',
        'studySpecification' => 'STUDY_SPECIFICATION',
        'etude.studySpecification' => 'STUDY_SPECIFICATION',
        'EtudeTableMap::COL_STUDY_SPECIFICATION' => 'STUDY_SPECIFICATION',
        'COL_STUDY_SPECIFICATION' => 'STUDY_SPECIFICATION',
        'study_specification' => 'STUDY_SPECIFICATION',
        'etude.study_specification' => 'STUDY_SPECIFICATION',
        'isStudySpecification' => 'IS_STUDY_SPECIFICATION',
        'Etude.isStudySpecification' => 'IS_STUDY_SPECIFICATION',
        'etude.isStudySpecification' => 'IS_STUDY_SPECIFICATION',
        'EtudeTableMap::COL_IS_STUDY_SPECIFICATION' => 'IS_STUDY_SPECIFICATION',
        'COL_IS_STUDY_SPECIFICATION' => 'IS_STUDY_SPECIFICATION',
        'is_study_specification' => 'IS_STUDY_SPECIFICATION',
        'etude.is_study_specification' => 'IS_STUDY_SPECIFICATION',
        'AdditionalNotes' => 'ADDITIONAL_NOTES',
        'Etude.AdditionalNotes' => 'ADDITIONAL_NOTES',
        'additionalNotes' => 'ADDITIONAL_NOTES',
        'etude.additionalNotes' => 'ADDITIONAL_NOTES',
        'EtudeTableMap::COL_ADDITIONAL_NOTES' => 'ADDITIONAL_NOTES',
        'COL_ADDITIONAL_NOTES' => 'ADDITIONAL_NOTES',
        'additional_notes' => 'ADDITIONAL_NOTES',
        'etude.additional_notes' => 'ADDITIONAL_NOTES',
        'ProjectComment' => 'PROJECT_COMMENT',
        'Etude.ProjectComment' => 'PROJECT_COMMENT',
        'projectComment' => 'PROJECT_COMMENT',
        'etude.projectComment' => 'PROJECT_COMMENT',
        'EtudeTableMap::COL_PROJECT_COMMENT' => 'PROJECT_COMMENT',
        'COL_PROJECT_COMMENT' => 'PROJECT_COMMENT',
        'project_comment' => 'PROJECT_COMMENT',
        'etude.project_comment' => 'PROJECT_COMMENT',
        'EndClientId' => 'END_CLIENT_ID',
        'Etude.EndClientId' => 'END_CLIENT_ID',
        'endClientId' => 'END_CLIENT_ID',
        'etude.endClientId' => 'END_CLIENT_ID',
        'EtudeTableMap::COL_END_CLIENT_ID' => 'END_CLIENT_ID',
        'COL_END_CLIENT_ID' => 'END_CLIENT_ID',
        'end_client_id' => 'END_CLIENT_ID',
        'etude.end_client_id' => 'END_CLIENT_ID',
        'EndClientContactId' => 'END_CLIENT_CONTACT_ID',
        'Etude.EndClientContactId' => 'END_CLIENT_CONTACT_ID',
        'endClientContactId' => 'END_CLIENT_CONTACT_ID',
        'etude.endClientContactId' => 'END_CLIENT_CONTACT_ID',
        'EtudeTableMap::COL_END_CLIENT_CONTACT_ID' => 'END_CLIENT_CONTACT_ID',
        'COL_END_CLIENT_CONTACT_ID' => 'END_CLIENT_CONTACT_ID',
        'end_client_contact_id' => 'END_CLIENT_CONTACT_ID',
        'etude.end_client_contact_id' => 'END_CLIENT_CONTACT_ID',
        'ContactId' => 'CONTACT_ID',
        'Etude.ContactId' => 'CONTACT_ID',
        'contactId' => 'CONTACT_ID',
        'etude.contactId' => 'CONTACT_ID',
        'EtudeTableMap::COL_CONTACT_ID' => 'CONTACT_ID',
        'COL_CONTACT_ID' => 'CONTACT_ID',
        'contact_id' => 'CONTACT_ID',
        'etude.contact_id' => 'CONTACT_ID',
        'ContactClientPmId' => 'CONTACT_CLIENT_PM_ID',
        'Etude.ContactClientPmId' => 'CONTACT_CLIENT_PM_ID',
        'contactClientPmId' => 'CONTACT_CLIENT_PM_ID',
        'etude.contactClientPmId' => 'CONTACT_CLIENT_PM_ID',
        'EtudeTableMap::COL_CONTACT_CLIENT_PM_ID' => 'CONTACT_CLIENT_PM_ID',
        'COL_CONTACT_CLIENT_PM_ID' => 'CONTACT_CLIENT_PM_ID',
        'contact_client_pm_id' => 'CONTACT_CLIENT_PM_ID',
        'etude.contact_client_pm_id' => 'CONTACT_CLIENT_PM_ID',
        'MasterProjectNumber' => 'MASTER_PROJECT_NUMBER',
        'Etude.MasterProjectNumber' => 'MASTER_PROJECT_NUMBER',
        'masterProjectNumber' => 'MASTER_PROJECT_NUMBER',
        'etude.masterProjectNumber' => 'MASTER_PROJECT_NUMBER',
        'EtudeTableMap::COL_MASTER_PROJECT_NUMBER' => 'MASTER_PROJECT_NUMBER',
        'COL_MASTER_PROJECT_NUMBER' => 'MASTER_PROJECT_NUMBER',
        'master_project_number' => 'MASTER_PROJECT_NUMBER',
        'etude.master_project_number' => 'MASTER_PROJECT_NUMBER',
        'ProposedLoi' => 'PROPOSED_LOI',
        'Etude.ProposedLoi' => 'PROPOSED_LOI',
        'proposedLoi' => 'PROPOSED_LOI',
        'etude.proposedLoi' => 'PROPOSED_LOI',
        'EtudeTableMap::COL_PROPOSED_LOI' => 'PROPOSED_LOI',
        'COL_PROPOSED_LOI' => 'PROPOSED_LOI',
        'proposed_loi' => 'PROPOSED_LOI',
        'etude.proposed_loi' => 'PROPOSED_LOI',
        'OpportunityId' => 'OPPORTUNITY_ID',
        'Etude.OpportunityId' => 'OPPORTUNITY_ID',
        'opportunityId' => 'OPPORTUNITY_ID',
        'etude.opportunityId' => 'OPPORTUNITY_ID',
        'EtudeTableMap::COL_OPPORTUNITY_ID' => 'OPPORTUNITY_ID',
        'COL_OPPORTUNITY_ID' => 'OPPORTUNITY_ID',
        'opportunity_id' => 'OPPORTUNITY_ID',
        'etude.opportunity_id' => 'OPPORTUNITY_ID',
        'SiJobTypeId' => 'SI_JOB_TYPE_ID',
        'Etude.SiJobTypeId' => 'SI_JOB_TYPE_ID',
        'siJobTypeId' => 'SI_JOB_TYPE_ID',
        'etude.siJobTypeId' => 'SI_JOB_TYPE_ID',
        'EtudeTableMap::COL_SI_JOB_TYPE_ID' => 'SI_JOB_TYPE_ID',
        'COL_SI_JOB_TYPE_ID' => 'SI_JOB_TYPE_ID',
        'si_job_type_id' => 'SI_JOB_TYPE_ID',
        'etude.si_job_type_id' => 'SI_JOB_TYPE_ID',
        'BestEffort' => 'BEST_EFFORT',
        'Etude.BestEffort' => 'BEST_EFFORT',
        'bestEffort' => 'BEST_EFFORT',
        'etude.bestEffort' => 'BEST_EFFORT',
        'EtudeTableMap::COL_BEST_EFFORT' => 'BEST_EFFORT',
        'COL_BEST_EFFORT' => 'BEST_EFFORT',
        'best_effort' => 'BEST_EFFORT',
        'etude.best_effort' => 'BEST_EFFORT',
        'JobStatusSfId' => 'JOB_STATUS_SF_ID',
        'Etude.JobStatusSfId' => 'JOB_STATUS_SF_ID',
        'jobStatusSfId' => 'JOB_STATUS_SF_ID',
        'etude.jobStatusSfId' => 'JOB_STATUS_SF_ID',
        'EtudeTableMap::COL_JOB_STATUS_SF_ID' => 'JOB_STATUS_SF_ID',
        'COL_JOB_STATUS_SF_ID' => 'JOB_STATUS_SF_ID',
        'job_status_sf_id' => 'JOB_STATUS_SF_ID',
        'etude.job_status_sf_id' => 'JOB_STATUS_SF_ID',
        'BookedBySfId' => 'BOOKED_BY_SF_ID',
        'Etude.BookedBySfId' => 'BOOKED_BY_SF_ID',
        'bookedBySfId' => 'BOOKED_BY_SF_ID',
        'etude.bookedBySfId' => 'BOOKED_BY_SF_ID',
        'EtudeTableMap::COL_BOOKED_BY_SF_ID' => 'BOOKED_BY_SF_ID',
        'COL_BOOKED_BY_SF_ID' => 'BOOKED_BY_SF_ID',
        'booked_by_sf_id' => 'BOOKED_BY_SF_ID',
        'etude.booked_by_sf_id' => 'BOOKED_BY_SF_ID',
        'CreatedBySfId' => 'CREATED_BY_SF_ID',
        'Etude.CreatedBySfId' => 'CREATED_BY_SF_ID',
        'createdBySfId' => 'CREATED_BY_SF_ID',
        'etude.createdBySfId' => 'CREATED_BY_SF_ID',
        'EtudeTableMap::COL_CREATED_BY_SF_ID' => 'CREATED_BY_SF_ID',
        'COL_CREATED_BY_SF_ID' => 'CREATED_BY_SF_ID',
        'created_by_sf_id' => 'CREATED_BY_SF_ID',
        'etude.created_by_sf_id' => 'CREATED_BY_SF_ID',
        'AccountManagerSfId' => 'ACCOUNT_MANAGER_SF_ID',
        'Etude.AccountManagerSfId' => 'ACCOUNT_MANAGER_SF_ID',
        'accountManagerSfId' => 'ACCOUNT_MANAGER_SF_ID',
        'etude.accountManagerSfId' => 'ACCOUNT_MANAGER_SF_ID',
        'EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID' => 'ACCOUNT_MANAGER_SF_ID',
        'COL_ACCOUNT_MANAGER_SF_ID' => 'ACCOUNT_MANAGER_SF_ID',
        'account_manager_sf_id' => 'ACCOUNT_MANAGER_SF_ID',
        'etude.account_manager_sf_id' => 'ACCOUNT_MANAGER_SF_ID',
        'CreatedDate' => 'CREATED_DATE',
        'Etude.CreatedDate' => 'CREATED_DATE',
        'createdDate' => 'CREATED_DATE',
        'etude.createdDate' => 'CREATED_DATE',
        'EtudeTableMap::COL_CREATED_DATE' => 'CREATED_DATE',
        'COL_CREATED_DATE' => 'CREATED_DATE',
        'created_date' => 'CREATED_DATE',
        'etude.created_date' => 'CREATED_DATE',
        'JobQualificationId' => 'JOB_QUALIFICATION_ID',
        'Etude.JobQualificationId' => 'JOB_QUALIFICATION_ID',
        'jobQualificationId' => 'JOB_QUALIFICATION_ID',
        'etude.jobQualificationId' => 'JOB_QUALIFICATION_ID',
        'EtudeTableMap::COL_JOB_QUALIFICATION_ID' => 'JOB_QUALIFICATION_ID',
        'COL_JOB_QUALIFICATION_ID' => 'JOB_QUALIFICATION_ID',
        'job_qualification_id' => 'JOB_QUALIFICATION_ID',
        'etude.job_qualification_id' => 'JOB_QUALIFICATION_ID',
        'ProposedN' => 'PROPOSED_N',
        'Etude.ProposedN' => 'PROPOSED_N',
        'proposedN' => 'PROPOSED_N',
        'etude.proposedN' => 'PROPOSED_N',
        'EtudeTableMap::COL_PROPOSED_N' => 'PROPOSED_N',
        'COL_PROPOSED_N' => 'PROPOSED_N',
        'proposed_n' => 'PROPOSED_N',
        'etude.proposed_n' => 'PROPOSED_N',
        'GermanJobTypeId' => 'GERMAN_JOB_TYPE_ID',
        'Etude.GermanJobTypeId' => 'GERMAN_JOB_TYPE_ID',
        'germanJobTypeId' => 'GERMAN_JOB_TYPE_ID',
        'etude.germanJobTypeId' => 'GERMAN_JOB_TYPE_ID',
        'EtudeTableMap::COL_GERMAN_JOB_TYPE_ID' => 'GERMAN_JOB_TYPE_ID',
        'COL_GERMAN_JOB_TYPE_ID' => 'GERMAN_JOB_TYPE_ID',
        'german_job_type_id' => 'GERMAN_JOB_TYPE_ID',
        'etude.german_job_type_id' => 'GERMAN_JOB_TYPE_ID',
        'CreatedByComment' => 'CREATED_BY_COMMENT',
        'Etude.CreatedByComment' => 'CREATED_BY_COMMENT',
        'createdByComment' => 'CREATED_BY_COMMENT',
        'etude.createdByComment' => 'CREATED_BY_COMMENT',
        'EtudeTableMap::COL_CREATED_BY_COMMENT' => 'CREATED_BY_COMMENT',
        'COL_CREATED_BY_COMMENT' => 'CREATED_BY_COMMENT',
        'created_by_comment' => 'CREATED_BY_COMMENT',
        'etude.created_by_comment' => 'CREATED_BY_COMMENT',
        'FocusVision' => 'FOCUS_VISION',
        'Etude.FocusVision' => 'FOCUS_VISION',
        'focusVision' => 'FOCUS_VISION',
        'etude.focusVision' => 'FOCUS_VISION',
        'EtudeTableMap::COL_FOCUS_VISION' => 'FOCUS_VISION',
        'COL_FOCUS_VISION' => 'FOCUS_VISION',
        'focus_vision' => 'FOCUS_VISION',
        'etude.focus_vision' => 'FOCUS_VISION',
        'SiEuJobType' => 'SI_EU_JOB_TYPE',
        'Etude.SiEuJobType' => 'SI_EU_JOB_TYPE',
        'siEuJobType' => 'SI_EU_JOB_TYPE',
        'etude.siEuJobType' => 'SI_EU_JOB_TYPE',
        'EtudeTableMap::COL_SI_EU_JOB_TYPE' => 'SI_EU_JOB_TYPE',
        'COL_SI_EU_JOB_TYPE' => 'SI_EU_JOB_TYPE',
        'si_eu_job_type' => 'SI_EU_JOB_TYPE',
        'etude.si_eu_job_type' => 'SI_EU_JOB_TYPE',
        'IntermediateClientId' => 'INTERMEDIATE_CLIENT_ID',
        'Etude.IntermediateClientId' => 'INTERMEDIATE_CLIENT_ID',
        'intermediateClientId' => 'INTERMEDIATE_CLIENT_ID',
        'etude.intermediateClientId' => 'INTERMEDIATE_CLIENT_ID',
        'EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID' => 'INTERMEDIATE_CLIENT_ID',
        'COL_INTERMEDIATE_CLIENT_ID' => 'INTERMEDIATE_CLIENT_ID',
        'intermediate_client_id' => 'INTERMEDIATE_CLIENT_ID',
        'etude.intermediate_client_id' => 'INTERMEDIATE_CLIENT_ID',
        'IntermediateClientContactId' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'Etude.IntermediateClientContactId' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'intermediateClientContactId' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'etude.intermediateClientContactId' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'COL_INTERMEDIATE_CLIENT_CONTACT_ID' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'intermediate_client_contact_id' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'etude.intermediate_client_contact_id' => 'INTERMEDIATE_CLIENT_CONTACT_ID',
        'UsGlobalQualGmsId' => 'US_GLOBAL_QUAL_GMS_ID',
        'Etude.UsGlobalQualGmsId' => 'US_GLOBAL_QUAL_GMS_ID',
        'usGlobalQualGmsId' => 'US_GLOBAL_QUAL_GMS_ID',
        'etude.usGlobalQualGmsId' => 'US_GLOBAL_QUAL_GMS_ID',
        'EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID' => 'US_GLOBAL_QUAL_GMS_ID',
        'COL_US_GLOBAL_QUAL_GMS_ID' => 'US_GLOBAL_QUAL_GMS_ID',
        'us_global_qual_gms_id' => 'US_GLOBAL_QUAL_GMS_ID',
        'etude.us_global_qual_gms_id' => 'US_GLOBAL_QUAL_GMS_ID',
        'FaciltyNote' => 'FACILTY_NOTE',
        'Etude.FaciltyNote' => 'FACILTY_NOTE',
        'faciltyNote' => 'FACILTY_NOTE',
        'etude.faciltyNote' => 'FACILTY_NOTE',
        'EtudeTableMap::COL_FACILTY_NOTE' => 'FACILTY_NOTE',
        'COL_FACILTY_NOTE' => 'FACILTY_NOTE',
        'facilty_note' => 'FACILTY_NOTE',
        'etude.facilty_note' => 'FACILTY_NOTE',
        'CurrencyIsoCodeId' => 'CURRENCY_ISO_CODE_ID',
        'Etude.CurrencyIsoCodeId' => 'CURRENCY_ISO_CODE_ID',
        'currencyIsoCodeId' => 'CURRENCY_ISO_CODE_ID',
        'etude.currencyIsoCodeId' => 'CURRENCY_ISO_CODE_ID',
        'EtudeTableMap::COL_CURRENCY_ISO_CODE_ID' => 'CURRENCY_ISO_CODE_ID',
        'COL_CURRENCY_ISO_CODE_ID' => 'CURRENCY_ISO_CODE_ID',
        'currency_iso_code_id' => 'CURRENCY_ISO_CODE_ID',
        'etude.currency_iso_code_id' => 'CURRENCY_ISO_CODE_ID',
        'ClientListDeletionId' => 'CLIENT_LIST_DELETION_ID',
        'Etude.ClientListDeletionId' => 'CLIENT_LIST_DELETION_ID',
        'clientListDeletionId' => 'CLIENT_LIST_DELETION_ID',
        'etude.clientListDeletionId' => 'CLIENT_LIST_DELETION_ID',
        'EtudeTableMap::COL_CLIENT_LIST_DELETION_ID' => 'CLIENT_LIST_DELETION_ID',
        'COL_CLIENT_LIST_DELETION_ID' => 'CLIENT_LIST_DELETION_ID',
        'client_list_deletion_id' => 'CLIENT_LIST_DELETION_ID',
        'etude.client_list_deletion_id' => 'CLIENT_LIST_DELETION_ID',
        'CreatedById' => 'CREATED_BY_ID',
        'Etude.CreatedById' => 'CREATED_BY_ID',
        'createdById' => 'CREATED_BY_ID',
        'etude.createdById' => 'CREATED_BY_ID',
        'EtudeTableMap::COL_CREATED_BY_ID' => 'CREATED_BY_ID',
        'COL_CREATED_BY_ID' => 'CREATED_BY_ID',
        'created_by_id' => 'CREATED_BY_ID',
        'etude.created_by_id' => 'CREATED_BY_ID',
        'UpdatedById' => 'UPDATED_BY_ID',
        'Etude.UpdatedById' => 'UPDATED_BY_ID',
        'updatedById' => 'UPDATED_BY_ID',
        'etude.updatedById' => 'UPDATED_BY_ID',
        'EtudeTableMap::COL_UPDATED_BY_ID' => 'UPDATED_BY_ID',
        'COL_UPDATED_BY_ID' => 'UPDATED_BY_ID',
        'updated_by_id' => 'UPDATED_BY_ID',
        'etude.updated_by_id' => 'UPDATED_BY_ID',
        'CreatedAt' => 'CREATED_AT',
        'Etude.CreatedAt' => 'CREATED_AT',
        'createdAt' => 'CREATED_AT',
        'etude.createdAt' => 'CREATED_AT',
        'EtudeTableMap::COL_CREATED_AT' => 'CREATED_AT',
        'COL_CREATED_AT' => 'CREATED_AT',
        'created_at' => 'CREATED_AT',
        'etude.created_at' => 'CREATED_AT',
        'UpdatedAt' => 'UPDATED_AT',
        'Etude.UpdatedAt' => 'UPDATED_AT',
        'updatedAt' => 'UPDATED_AT',
        'etude.updatedAt' => 'UPDATED_AT',
        'EtudeTableMap::COL_UPDATED_AT' => 'UPDATED_AT',
        'COL_UPDATED_AT' => 'UPDATED_AT',
        'updated_at' => 'UPDATED_AT',
        'etude.updated_at' => 'UPDATED_AT',
    ];

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
                EtudeTableMap::COL_SI_EU_JOB_TYPE => array(
                            self::COL_SI_EU_JOB_TYPE_SAMPLE_ONLY,
            self::COL_SI_EU_JOB_TYPE_INCL__DATA_PROCESSING,
            self::COL_SI_EU_JOB_TYPE_FULL_SERVICE,
        ),
    );

    /**
     * Gets the list of values for all ENUM and SET columns
     * @return array
     */
    public static function getValueSets()
    {
      return static::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM or SET column
     * @param string $colname
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = self::getValueSets();

        return $valueSets[$colname];
    }

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('etude');
        $this->setPhpName('Etude');
        $this->setIdentifierQuoting(true);
        $this->setClassName('\\Model\\Etude');
        $this->setPackage('src.Model');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('id', 'Id', 'INTEGER', true, 8, null);
        $this->addColumn('numero_etude', 'NumeroEtude', 'CHAR', true, 32, null);
        $this->addColumn('reference_client', 'ReferenceClient', 'VARCHAR', true, 30, null);
        $this->addColumn('master_project_sf_id', 'MasterProjectSfId', 'VARCHAR', false, 255, null);
        $this->addColumn('theme', 'Theme', 'VARCHAR', false, 255, null);
        $this->addColumn('date_debut', 'DateDebut', 'DATE', true, null, null);
        $this->addColumn('date_fin', 'DateFin', 'DATE', true, null, null);
        $this->addColumn('annee', 'Annee', 'VARCHAR', true, 4, null);
        $this->addColumn('rst', 'Rst', 'BOOLEAN', true, 1, false);
        $this->addColumn('cli', 'Cli', 'BOOLEAN', true, 1, false);
        $this->addColumn('gqs', 'Gqs', 'BOOLEAN', true, 1, false);
        $this->addColumn('ins', 'Ins', 'BOOLEAN', true, 1, false);
        $this->addColumn('hut', 'Hut', 'BOOLEAN', true, 1, false);
        $this->addColumn('display_total_only', 'DisplayTotalOnly', 'BOOLEAN', true, 1, false);
        $this->addForeignKey('id_pm', 'IdPm', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addForeignKey('id_etape', 'IdEtape', 'INTEGER', 'ref_etape', 'id', false, 8, null);
        $this->addColumn('prix_revient_initial', 'PrixRevientInitial', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_revient_actualise', 'PrixRevientActualise', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_vente_initial', 'PrixVenteInitial', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_vente_actualise', 'PrixVenteActualise', 'DECIMAL', true, 15, null);
        $this->addColumn('consolidated_invoice', 'ConsolidatedInvoice', 'BOOLEAN', true, 1, false);
        $this->addColumn('send_csat_quest', 'SendCsatQuest', 'BOOLEAN', false, 1, false);
        $this->addColumn('is_send_csat_quest_mail', 'IsSendCsatQuestMail', 'BOOLEAN', true, 1, true);
        $this->addColumn('numero_facture', 'NumeroFacture', 'VARCHAR', false, 50, null);
        $this->addColumn('dont_set_am_auto', 'DontSetAmAuto', 'BOOLEAN', true, 1, false);
        $this->addColumn('set_am_reason', 'SetAmReason', 'VARCHAR', false, 255, null);
        $this->addForeignKey('am_reason_type_id', 'AmReasonTypeId', 'INTEGER', 'am_reason_type', 'id', false, 8, null);
        $this->addColumn('date_envoi_facture', 'DateEnvoiFacture', 'DATE', false, null, null);
        $this->addColumn('date_reglement', 'DateReglement', 'DATE', false, null, null);
        $this->addColumn('commentaire', 'Commentaire', 'CLOB', false, null, null);
        $this->addForeignKey('industry_id', 'IndustryId', 'INTEGER', 'ref_industry', 'id', true, 8, null);
        $this->addColumn('periode_cutoff', 'PeriodeCutoff', 'VARCHAR', true, 7, null);
        $this->addColumn('theme_br', 'ThemeBr', 'VARCHAR', true, 255, null);
        $this->addForeignKey('area_id', 'AreaId', 'INTEGER', 'ref_area', 'id', false, 8, null);
        $this->addColumn('id_sams_study', 'IdSamsStudy', 'VARCHAR', true, 50, null);
        $this->addColumn('recrutement_objectif', 'RecrutementObjectif', 'INTEGER', true, 4, 0);
        $this->addForeignKey('id_location_pnl', 'IdLocationPnl', 'INTEGER', 'ref_location', 'id', false, 3, null);
        $this->addForeignKey('id_master_project_location_pnl', 'IdMasterProjectLocationPnl', 'INTEGER', 'project_location_prefix', 'id', false, 3, null);
        $this->addColumn('recrutement_objectif_pr', 'RecrutementObjectifPr', 'INTEGER', true, 4, null);
        $this->addForeignKey('id_bm', 'IdBm', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addColumn('extra_info', 'ExtraInfo', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('account_id', 'AccountId', 'INTEGER', 'sf_account', 'id', false, null, null);
        $this->addForeignKey('account_manager_id', 'AccountManagerId', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addForeignKey('project_specialty_sponsor_id', 'ProjectSpecialtySponsorId', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addColumn('language', 'Language', 'VARCHAR', false, 3, null);
        $this->addColumn('remise_taux', 'RemiseTaux', 'DECIMAL', false, 4, null);
        $this->addColumn('client_discount_percentage', 'ClientDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('end_client_discount_percentage', 'EndClientDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('client_quant_discount_percentage', 'ClientQuantDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('end_client_quant_discount_percentage', 'EndClientQuantDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('sample_plan', 'SamplePlan', 'CLOB', false, null, null);
        $this->addColumn('isToInvoice', 'IsToInvoice', 'BOOLEAN', false, 1, false);
        $this->addColumn('file_path', 'FilePath', 'VARCHAR', false, 255, null);
        $this->addForeignKey('account_leader_id', 'AccountLeaderId', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addForeignKey('account_pm_id', 'AccountPMId', 'INTEGER', 'user', 'id', false, 8, null);
        $this->addColumn('am_email', 'AmEmail', 'VARCHAR', false, 50, null);
        $this->addColumn('client_portal_ready', 'ClientPortalReady', 'BOOLEAN', false, 1, true);
        $this->addColumn('length_of_interview', 'LengthOfInterview', 'VARCHAR', false, 255, null);
        $this->addColumn('sunshine_act', 'sunshineAct', 'VARCHAR', false, 250, null);
        $this->addColumn('is_consolidated', 'IsConsolidated', 'BOOLEAN', false, 1, false);
        $this->addColumn('sharepoint_folder', 'SharepointFolder', 'VARCHAR', false, 255, null);
        $this->addColumn('multi_phase', 'MultiPhase', 'BOOLEAN', true, 1, false);
        $this->addColumn('po_number', 'PoNumber', 'VARCHAR', true, 255, null);
        $this->addColumn('currencies', 'Currencies', 'VARCHAR', false, 255, null);
        $this->addColumn('sms_relance', 'SmsRelance', 'BOOLEAN', true, 1, false);
        $this->addForeignKey('id_etude_group', 'IdEtudeGroup', 'INTEGER', 'etude_group', 'id', false, 8, null);
        $this->addColumn('gms', 'Gms', 'VARCHAR', true, 1, null);
        $this->addColumn('kol', 'Kol', 'VARCHAR', true, 1, null);
        $this->addColumn('room_rental', 'RoomRental', 'BOOLEAN', false, 1, false);
        $this->addColumn('recruits_offsite', 'RecruitsOffsite', 'BOOLEAN', false, 1, false);
        $this->addColumn('study_specification', 'StudySpecification', 'CLOB', false, null, null);
        $this->addColumn('is_study_specification', 'isStudySpecification', 'BOOLEAN', false, 1, false);
        $this->addColumn('additional_notes', 'AdditionalNotes', 'CLOB', false, null, null);
        $this->addColumn('project_comment', 'ProjectComment', 'CLOB', false, null, null);
        $this->addForeignKey('end_client_id', 'EndClientId', 'INTEGER', 'sf_account', 'id', false, null, null);
        $this->addForeignKey('end_client_contact_id', 'EndClientContactId', 'INTEGER', 'sf_contact', 'id', false, null, null);
        $this->addForeignKey('contact_id', 'ContactId', 'INTEGER', 'sf_contact', 'id', false, null, null);
        $this->addForeignKey('contact_client_pm_id', 'ContactClientPmId', 'INTEGER', 'sf_contact', 'id', false, null, null);
        $this->addColumn('master_project_number', 'MasterProjectNumber', 'VARCHAR', false, 255, null);
        $this->addColumn('proposed_loi', 'ProposedLoi', 'DOUBLE', false, null, 0);
        $this->addForeignKey('opportunity_id', 'OpportunityId', 'INTEGER', 'sf_opportunity', 'id', false, null, null);
        $this->addForeignKey('si_job_type_id', 'SiJobTypeId', 'INTEGER', 'ref_si_job_type', 'id', false, null, null);
        $this->addColumn('best_effort', 'BestEffort', 'BOOLEAN', false, 1, false);
        $this->addForeignKey('job_status_sf_id', 'JobStatusSfId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addColumn('booked_by_sf_id', 'BookedBySfId', 'VARCHAR', false, 255, null);
        $this->addColumn('created_by_sf_id', 'CreatedBySfId', 'VARCHAR', false, 255, null);
        $this->addColumn('account_manager_sf_id', 'AccountManagerSfId', 'VARCHAR', false, 255, null);
        $this->addColumn('created_date', 'CreatedDate', 'TIMESTAMP', false, null, null);
        $this->addForeignKey('job_qualification_id', 'JobQualificationId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addColumn('proposed_n', 'ProposedN', 'DOUBLE', false, null, 0);
        $this->addForeignKey('german_job_type_id', 'GermanJobTypeId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addColumn('created_by_comment', 'CreatedByComment', 'VARCHAR', false, 255, null);
        $this->addColumn('focus_vision', 'FocusVision', 'BOOLEAN', false, 1, null);
        $this->addColumn('si_eu_job_type', 'SiEuJobType', 'ENUM', false, null, null);
        $this->getColumn('si_eu_job_type')->setValueSet(array (
  0 => 'Sample only',
  1 => 'Incl. Data Processing',
  2 => 'Full Service',
));
        $this->addForeignKey('intermediate_client_id', 'IntermediateClientId', 'INTEGER', 'sf_account', 'id', false, null, null);
        $this->addForeignKey('intermediate_client_contact_id', 'IntermediateClientContactId', 'INTEGER', 'sf_contact', 'id', false, null, null);
        $this->addForeignKey('us_global_qual_gms_id', 'UsGlobalQualGmsId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addColumn('facilty_note', 'FaciltyNote', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('currency_iso_code_id', 'CurrencyIsoCodeId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addForeignKey('client_list_deletion_id', 'ClientListDeletionId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addForeignKey('created_by_id', 'CreatedById', 'INTEGER', 'user', 'id', false, null, null);
        $this->addForeignKey('updated_by_id', 'UpdatedById', 'INTEGER', 'user', 'id', false, null, null);
        $this->addColumn('created_at', 'CreatedAt', 'TIMESTAMP', false, null, null);
        $this->addColumn('updated_at', 'UpdatedAt', 'TIMESTAMP', false, null, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('UsGlobalQualGms', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':us_global_qual_gms_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('AccountLeader', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_leader_id',
    1 => ':id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('AccountPM', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_pm_id',
    1 => ':id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('IntermediateClient', '\\Model\\Account', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':intermediate_client_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Etape', '\\Model\\Etape', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_etape',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('Contact', '\\Model\\Contact', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':contact_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Opportunity', '\\Model\\Opportunity', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':opportunity_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('JobStatusSf', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':job_status_sf_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('JobQualification', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':job_qualification_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('SiJobType', '\\Model\\SiJobType', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':si_job_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('EndClientContact', '\\Model\\Contact', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':end_client_contact_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('GermanJobType', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':german_job_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('EndClient', '\\Model\\Account', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':end_client_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Account', '\\Model\\Account', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Industry', '\\Model\\Industry', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':industry_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('EtudeLocation', '\\Model\\Location', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_location_pnl',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('ProjectLocationPrefix', '\\Model\\ProjectLocationPrefix', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_master_project_location_pnl',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('ContactClientPm', '\\Model\\Contact', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':contact_client_pm_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('BM', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_bm',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('EtudeProjectManager', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_pm',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('EtudeGroup', '\\Model\\EtudeGroup', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_etude_group',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('EtudeArea', '\\Model\\Area', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':area_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('CurrencyIsoCode', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':currency_iso_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('ClientListDeletion', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':client_list_deletion_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('CreatedBy', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':created_by_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('UpdatedBy', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':updated_by_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('IntermediateClientContact', '\\Model\\Contact', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':intermediate_client_contact_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('ProjectAccountManager', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_manager_id',
    1 => ':id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('ProjectSpecialtySponsor', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':project_specialty_sponsor_id',
    1 => ':id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('AmReasonType', '\\Model\\AmReasonType', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':am_reason_type_id',
    1 => ':id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('DernierAcces', '\\Model\\DernierAcces', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':id_etude',
    1 => ':id',
  ),
), null, null, 'DernierAccess', false);
        $this->addRelation('EtudeSampleSource', '\\Model\\EtudeSampleSource', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'EtudeSampleSources', false);
        $this->addRelation('EtudeMethodology', '\\Model\\EtudeMethodology', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'EtudeMethodologies', false);
        $this->addRelation('Facture', '\\Model\\Facture', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':id_etude',
    1 => ':id',
  ),
), 'CASCADE', null, 'Factures', false);
        $this->addRelation('JobEtude', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'JobEtudes', false);
        $this->addRelation('Reglement', '\\Model\\Reglement', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':id_etude',
    1 => ':id',
  ),
), 'CASCADE', null, 'Reglements', false);
        $this->addRelation('Sector', '\\Model\\RefSalesForceEtudeSector', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'Sectors', false);
        $this->addRelation('EtudeCheckListValidation', '\\Model\\EtudeCheckListValidation', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), null, null, 'EtudeCheckListValidations', false);
        $this->addRelation('EtudeFichier', '\\Model\\EtudeFichier', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), null, null, 'EtudeFichiers', false);
        $this->addRelation('LogProjectStatus', '\\Model\\LogProjectStatus', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':etude_id',
    1 => ':id',
  ),
), null, null, 'LogProjectStatuses', false);
        $this->addRelation('SampleSource', '\\Model\\SampleSource', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'SampleSources');
        $this->addRelation('Methodology', '\\Model\\Methodology', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'Methodologies');
        $this->addRelation('RefSalesForceEtudeRefSector', '\\Model\\RefSalesForce', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'RefSalesForceEtudeRefSectors');
    } // buildRelations()

    /**
     *
     * Gets the list of behaviors registered for this table
     *
     * @return array Associative array (name => parameters) of behaviors
     */
    public function getBehaviors()
    {
        return array(
            'timestampable' => ['create_column' => 'created_at', 'update_column' => 'updated_at', 'disable_created_at' => 'false', 'disable_updated_at' => 'false'],
        );
    } // getBehaviors()

    /**
     * Method to invalidate the instance pool of all tables related to etude     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
        // Invalidate objects in related instance pools,
        // since one or more of them may be deleted by ON DELETE CASCADE/SETNULL rule.
        EtudeSampleSourceTableMap::clearInstancePool();
        EtudeMethodologyTableMap::clearInstancePool();
        FactureTableMap::clearInstancePool();
        JobTableMap::clearInstancePool();
        ReglementTableMap::clearInstancePool();
        RefSalesForceEtudeSectorTableMap::clearInstancePool();
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return null === $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] || is_scalar($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)]) || is_callable([$row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)], '__toString']) ? (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] : $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }

    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? EtudeTableMap::CLASS_DEFAULT : EtudeTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (Etude object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = EtudeTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = EtudeTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + EtudeTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = EtudeTableMap::OM_CLASS;
            /** @var Etude $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            EtudeTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = EtudeTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = EtudeTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var Etude $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                EtudeTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(EtudeTableMap::COL_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_NUMERO_ETUDE);
            $criteria->addSelectColumn(EtudeTableMap::COL_REFERENCE_CLIENT);
            $criteria->addSelectColumn(EtudeTableMap::COL_MASTER_PROJECT_SF_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_THEME);
            $criteria->addSelectColumn(EtudeTableMap::COL_DATE_DEBUT);
            $criteria->addSelectColumn(EtudeTableMap::COL_DATE_FIN);
            $criteria->addSelectColumn(EtudeTableMap::COL_ANNEE);
            $criteria->addSelectColumn(EtudeTableMap::COL_RST);
            $criteria->addSelectColumn(EtudeTableMap::COL_CLI);
            $criteria->addSelectColumn(EtudeTableMap::COL_GQS);
            $criteria->addSelectColumn(EtudeTableMap::COL_INS);
            $criteria->addSelectColumn(EtudeTableMap::COL_HUT);
            $criteria->addSelectColumn(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_PM);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_ETAPE);
            $criteria->addSelectColumn(EtudeTableMap::COL_PRIX_REVIENT_INITIAL);
            $criteria->addSelectColumn(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE);
            $criteria->addSelectColumn(EtudeTableMap::COL_PRIX_VENTE_INITIAL);
            $criteria->addSelectColumn(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE);
            $criteria->addSelectColumn(EtudeTableMap::COL_CONSOLIDATED_INVOICE);
            $criteria->addSelectColumn(EtudeTableMap::COL_SEND_CSAT_QUEST);
            $criteria->addSelectColumn(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL);
            $criteria->addSelectColumn(EtudeTableMap::COL_NUMERO_FACTURE);
            $criteria->addSelectColumn(EtudeTableMap::COL_DONT_SET_AM_AUTO);
            $criteria->addSelectColumn(EtudeTableMap::COL_SET_AM_REASON);
            $criteria->addSelectColumn(EtudeTableMap::COL_AM_REASON_TYPE_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_DATE_ENVOI_FACTURE);
            $criteria->addSelectColumn(EtudeTableMap::COL_DATE_REGLEMENT);
            $criteria->addSelectColumn(EtudeTableMap::COL_COMMENTAIRE);
            $criteria->addSelectColumn(EtudeTableMap::COL_INDUSTRY_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_PERIODE_CUTOFF);
            $criteria->addSelectColumn(EtudeTableMap::COL_THEME_BR);
            $criteria->addSelectColumn(EtudeTableMap::COL_AREA_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_SAMS_STUDY);
            $criteria->addSelectColumn(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_LOCATION_PNL);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL);
            $criteria->addSelectColumn(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_BM);
            $criteria->addSelectColumn(EtudeTableMap::COL_EXTRA_INFO);
            $criteria->addSelectColumn(EtudeTableMap::COL_ACCOUNT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_ACCOUNT_MANAGER_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_LANGUAGE);
            $criteria->addSelectColumn(EtudeTableMap::COL_REMISE_TAUX);
            $criteria->addSelectColumn(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(EtudeTableMap::COL_SAMPLE_PLAN);
            $criteria->addSelectColumn(EtudeTableMap::COL_ISTOINVOICE);
            $criteria->addSelectColumn(EtudeTableMap::COL_FILE_PATH);
            $criteria->addSelectColumn(EtudeTableMap::COL_ACCOUNT_LEADER_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_ACCOUNT_PM_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_AM_EMAIL);
            $criteria->addSelectColumn(EtudeTableMap::COL_CLIENT_PORTAL_READY);
            $criteria->addSelectColumn(EtudeTableMap::COL_LENGTH_OF_INTERVIEW);
            $criteria->addSelectColumn(EtudeTableMap::COL_SUNSHINE_ACT);
            $criteria->addSelectColumn(EtudeTableMap::COL_IS_CONSOLIDATED);
            $criteria->addSelectColumn(EtudeTableMap::COL_SHAREPOINT_FOLDER);
            $criteria->addSelectColumn(EtudeTableMap::COL_MULTI_PHASE);
            $criteria->addSelectColumn(EtudeTableMap::COL_PO_NUMBER);
            $criteria->addSelectColumn(EtudeTableMap::COL_CURRENCIES);
            $criteria->addSelectColumn(EtudeTableMap::COL_SMS_RELANCE);
            $criteria->addSelectColumn(EtudeTableMap::COL_ID_ETUDE_GROUP);
            $criteria->addSelectColumn(EtudeTableMap::COL_GMS);
            $criteria->addSelectColumn(EtudeTableMap::COL_KOL);
            $criteria->addSelectColumn(EtudeTableMap::COL_ROOM_RENTAL);
            $criteria->addSelectColumn(EtudeTableMap::COL_RECRUITS_OFFSITE);
            $criteria->addSelectColumn(EtudeTableMap::COL_STUDY_SPECIFICATION);
            $criteria->addSelectColumn(EtudeTableMap::COL_IS_STUDY_SPECIFICATION);
            $criteria->addSelectColumn(EtudeTableMap::COL_ADDITIONAL_NOTES);
            $criteria->addSelectColumn(EtudeTableMap::COL_PROJECT_COMMENT);
            $criteria->addSelectColumn(EtudeTableMap::COL_END_CLIENT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_END_CLIENT_CONTACT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CONTACT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_MASTER_PROJECT_NUMBER);
            $criteria->addSelectColumn(EtudeTableMap::COL_PROPOSED_LOI);
            $criteria->addSelectColumn(EtudeTableMap::COL_OPPORTUNITY_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_SI_JOB_TYPE_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_BEST_EFFORT);
            $criteria->addSelectColumn(EtudeTableMap::COL_JOB_STATUS_SF_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_BOOKED_BY_SF_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CREATED_BY_SF_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CREATED_DATE);
            $criteria->addSelectColumn(EtudeTableMap::COL_JOB_QUALIFICATION_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_PROPOSED_N);
            $criteria->addSelectColumn(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CREATED_BY_COMMENT);
            $criteria->addSelectColumn(EtudeTableMap::COL_FOCUS_VISION);
            $criteria->addSelectColumn(EtudeTableMap::COL_SI_EU_JOB_TYPE);
            $criteria->addSelectColumn(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_FACILTY_NOTE);
            $criteria->addSelectColumn(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CREATED_BY_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_UPDATED_BY_ID);
            $criteria->addSelectColumn(EtudeTableMap::COL_CREATED_AT);
            $criteria->addSelectColumn(EtudeTableMap::COL_UPDATED_AT);
        } else {
            $criteria->addSelectColumn($alias . '.id');
            $criteria->addSelectColumn($alias . '.numero_etude');
            $criteria->addSelectColumn($alias . '.reference_client');
            $criteria->addSelectColumn($alias . '.master_project_sf_id');
            $criteria->addSelectColumn($alias . '.theme');
            $criteria->addSelectColumn($alias . '.date_debut');
            $criteria->addSelectColumn($alias . '.date_fin');
            $criteria->addSelectColumn($alias . '.annee');
            $criteria->addSelectColumn($alias . '.rst');
            $criteria->addSelectColumn($alias . '.cli');
            $criteria->addSelectColumn($alias . '.gqs');
            $criteria->addSelectColumn($alias . '.ins');
            $criteria->addSelectColumn($alias . '.hut');
            $criteria->addSelectColumn($alias . '.display_total_only');
            $criteria->addSelectColumn($alias . '.id_pm');
            $criteria->addSelectColumn($alias . '.id_etape');
            $criteria->addSelectColumn($alias . '.prix_revient_initial');
            $criteria->addSelectColumn($alias . '.prix_revient_actualise');
            $criteria->addSelectColumn($alias . '.prix_vente_initial');
            $criteria->addSelectColumn($alias . '.prix_vente_actualise');
            $criteria->addSelectColumn($alias . '.consolidated_invoice');
            $criteria->addSelectColumn($alias . '.send_csat_quest');
            $criteria->addSelectColumn($alias . '.is_send_csat_quest_mail');
            $criteria->addSelectColumn($alias . '.numero_facture');
            $criteria->addSelectColumn($alias . '.dont_set_am_auto');
            $criteria->addSelectColumn($alias . '.set_am_reason');
            $criteria->addSelectColumn($alias . '.am_reason_type_id');
            $criteria->addSelectColumn($alias . '.date_envoi_facture');
            $criteria->addSelectColumn($alias . '.date_reglement');
            $criteria->addSelectColumn($alias . '.commentaire');
            $criteria->addSelectColumn($alias . '.industry_id');
            $criteria->addSelectColumn($alias . '.periode_cutoff');
            $criteria->addSelectColumn($alias . '.theme_br');
            $criteria->addSelectColumn($alias . '.area_id');
            $criteria->addSelectColumn($alias . '.id_sams_study');
            $criteria->addSelectColumn($alias . '.recrutement_objectif');
            $criteria->addSelectColumn($alias . '.id_location_pnl');
            $criteria->addSelectColumn($alias . '.id_master_project_location_pnl');
            $criteria->addSelectColumn($alias . '.recrutement_objectif_pr');
            $criteria->addSelectColumn($alias . '.id_bm');
            $criteria->addSelectColumn($alias . '.extra_info');
            $criteria->addSelectColumn($alias . '.account_id');
            $criteria->addSelectColumn($alias . '.account_manager_id');
            $criteria->addSelectColumn($alias . '.project_specialty_sponsor_id');
            $criteria->addSelectColumn($alias . '.language');
            $criteria->addSelectColumn($alias . '.remise_taux');
            $criteria->addSelectColumn($alias . '.client_discount_percentage');
            $criteria->addSelectColumn($alias . '.end_client_discount_percentage');
            $criteria->addSelectColumn($alias . '.client_quant_discount_percentage');
            $criteria->addSelectColumn($alias . '.end_client_quant_discount_percentage');
            $criteria->addSelectColumn($alias . '.sample_plan');
            $criteria->addSelectColumn($alias . '.isToInvoice');
            $criteria->addSelectColumn($alias . '.file_path');
            $criteria->addSelectColumn($alias . '.account_leader_id');
            $criteria->addSelectColumn($alias . '.account_pm_id');
            $criteria->addSelectColumn($alias . '.am_email');
            $criteria->addSelectColumn($alias . '.client_portal_ready');
            $criteria->addSelectColumn($alias . '.length_of_interview');
            $criteria->addSelectColumn($alias . '.sunshine_act');
            $criteria->addSelectColumn($alias . '.is_consolidated');
            $criteria->addSelectColumn($alias . '.sharepoint_folder');
            $criteria->addSelectColumn($alias . '.multi_phase');
            $criteria->addSelectColumn($alias . '.po_number');
            $criteria->addSelectColumn($alias . '.currencies');
            $criteria->addSelectColumn($alias . '.sms_relance');
            $criteria->addSelectColumn($alias . '.id_etude_group');
            $criteria->addSelectColumn($alias . '.gms');
            $criteria->addSelectColumn($alias . '.kol');
            $criteria->addSelectColumn($alias . '.room_rental');
            $criteria->addSelectColumn($alias . '.recruits_offsite');
            $criteria->addSelectColumn($alias . '.study_specification');
            $criteria->addSelectColumn($alias . '.is_study_specification');
            $criteria->addSelectColumn($alias . '.additional_notes');
            $criteria->addSelectColumn($alias . '.project_comment');
            $criteria->addSelectColumn($alias . '.end_client_id');
            $criteria->addSelectColumn($alias . '.end_client_contact_id');
            $criteria->addSelectColumn($alias . '.contact_id');
            $criteria->addSelectColumn($alias . '.contact_client_pm_id');
            $criteria->addSelectColumn($alias . '.master_project_number');
            $criteria->addSelectColumn($alias . '.proposed_loi');
            $criteria->addSelectColumn($alias . '.opportunity_id');
            $criteria->addSelectColumn($alias . '.si_job_type_id');
            $criteria->addSelectColumn($alias . '.best_effort');
            $criteria->addSelectColumn($alias . '.job_status_sf_id');
            $criteria->addSelectColumn($alias . '.booked_by_sf_id');
            $criteria->addSelectColumn($alias . '.created_by_sf_id');
            $criteria->addSelectColumn($alias . '.account_manager_sf_id');
            $criteria->addSelectColumn($alias . '.created_date');
            $criteria->addSelectColumn($alias . '.job_qualification_id');
            $criteria->addSelectColumn($alias . '.proposed_n');
            $criteria->addSelectColumn($alias . '.german_job_type_id');
            $criteria->addSelectColumn($alias . '.created_by_comment');
            $criteria->addSelectColumn($alias . '.focus_vision');
            $criteria->addSelectColumn($alias . '.si_eu_job_type');
            $criteria->addSelectColumn($alias . '.intermediate_client_id');
            $criteria->addSelectColumn($alias . '.intermediate_client_contact_id');
            $criteria->addSelectColumn($alias . '.us_global_qual_gms_id');
            $criteria->addSelectColumn($alias . '.facilty_note');
            $criteria->addSelectColumn($alias . '.currency_iso_code_id');
            $criteria->addSelectColumn($alias . '.client_list_deletion_id');
            $criteria->addSelectColumn($alias . '.created_by_id');
            $criteria->addSelectColumn($alias . '.updated_by_id');
            $criteria->addSelectColumn($alias . '.created_at');
            $criteria->addSelectColumn($alias . '.updated_at');
        }
    }

    /**
     * Remove all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be removed as they are only loaded on demand.
     *
     * @param Criteria $criteria object containing the columns to remove.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function removeSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_NUMERO_ETUDE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_REFERENCE_CLIENT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_MASTER_PROJECT_SF_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_THEME);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DATE_DEBUT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DATE_FIN);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ANNEE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_RST);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CLI);
            $criteria->removeSelectColumn(EtudeTableMap::COL_GQS);
            $criteria->removeSelectColumn(EtudeTableMap::COL_INS);
            $criteria->removeSelectColumn(EtudeTableMap::COL_HUT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_PM);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_ETAPE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PRIX_REVIENT_INITIAL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PRIX_VENTE_INITIAL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CONSOLIDATED_INVOICE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SEND_CSAT_QUEST);
            $criteria->removeSelectColumn(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_NUMERO_FACTURE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DONT_SET_AM_AUTO);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SET_AM_REASON);
            $criteria->removeSelectColumn(EtudeTableMap::COL_AM_REASON_TYPE_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DATE_ENVOI_FACTURE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_DATE_REGLEMENT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_COMMENTAIRE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_INDUSTRY_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PERIODE_CUTOFF);
            $criteria->removeSelectColumn(EtudeTableMap::COL_THEME_BR);
            $criteria->removeSelectColumn(EtudeTableMap::COL_AREA_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_SAMS_STUDY);
            $criteria->removeSelectColumn(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_LOCATION_PNL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_BM);
            $criteria->removeSelectColumn(EtudeTableMap::COL_EXTRA_INFO);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ACCOUNT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ACCOUNT_MANAGER_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_LANGUAGE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_REMISE_TAUX);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SAMPLE_PLAN);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ISTOINVOICE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_FILE_PATH);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ACCOUNT_LEADER_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ACCOUNT_PM_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_AM_EMAIL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CLIENT_PORTAL_READY);
            $criteria->removeSelectColumn(EtudeTableMap::COL_LENGTH_OF_INTERVIEW);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SUNSHINE_ACT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_IS_CONSOLIDATED);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SHAREPOINT_FOLDER);
            $criteria->removeSelectColumn(EtudeTableMap::COL_MULTI_PHASE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PO_NUMBER);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CURRENCIES);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SMS_RELANCE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ID_ETUDE_GROUP);
            $criteria->removeSelectColumn(EtudeTableMap::COL_GMS);
            $criteria->removeSelectColumn(EtudeTableMap::COL_KOL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ROOM_RENTAL);
            $criteria->removeSelectColumn(EtudeTableMap::COL_RECRUITS_OFFSITE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_STUDY_SPECIFICATION);
            $criteria->removeSelectColumn(EtudeTableMap::COL_IS_STUDY_SPECIFICATION);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ADDITIONAL_NOTES);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PROJECT_COMMENT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_END_CLIENT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_END_CLIENT_CONTACT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CONTACT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_MASTER_PROJECT_NUMBER);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PROPOSED_LOI);
            $criteria->removeSelectColumn(EtudeTableMap::COL_OPPORTUNITY_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SI_JOB_TYPE_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_BEST_EFFORT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_JOB_STATUS_SF_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_BOOKED_BY_SF_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CREATED_BY_SF_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CREATED_DATE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_JOB_QUALIFICATION_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_PROPOSED_N);
            $criteria->removeSelectColumn(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CREATED_BY_COMMENT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_FOCUS_VISION);
            $criteria->removeSelectColumn(EtudeTableMap::COL_SI_EU_JOB_TYPE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_FACILTY_NOTE);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CREATED_BY_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_UPDATED_BY_ID);
            $criteria->removeSelectColumn(EtudeTableMap::COL_CREATED_AT);
            $criteria->removeSelectColumn(EtudeTableMap::COL_UPDATED_AT);
        } else {
            $criteria->removeSelectColumn($alias . '.id');
            $criteria->removeSelectColumn($alias . '.numero_etude');
            $criteria->removeSelectColumn($alias . '.reference_client');
            $criteria->removeSelectColumn($alias . '.master_project_sf_id');
            $criteria->removeSelectColumn($alias . '.theme');
            $criteria->removeSelectColumn($alias . '.date_debut');
            $criteria->removeSelectColumn($alias . '.date_fin');
            $criteria->removeSelectColumn($alias . '.annee');
            $criteria->removeSelectColumn($alias . '.rst');
            $criteria->removeSelectColumn($alias . '.cli');
            $criteria->removeSelectColumn($alias . '.gqs');
            $criteria->removeSelectColumn($alias . '.ins');
            $criteria->removeSelectColumn($alias . '.hut');
            $criteria->removeSelectColumn($alias . '.display_total_only');
            $criteria->removeSelectColumn($alias . '.id_pm');
            $criteria->removeSelectColumn($alias . '.id_etape');
            $criteria->removeSelectColumn($alias . '.prix_revient_initial');
            $criteria->removeSelectColumn($alias . '.prix_revient_actualise');
            $criteria->removeSelectColumn($alias . '.prix_vente_initial');
            $criteria->removeSelectColumn($alias . '.prix_vente_actualise');
            $criteria->removeSelectColumn($alias . '.consolidated_invoice');
            $criteria->removeSelectColumn($alias . '.send_csat_quest');
            $criteria->removeSelectColumn($alias . '.is_send_csat_quest_mail');
            $criteria->removeSelectColumn($alias . '.numero_facture');
            $criteria->removeSelectColumn($alias . '.dont_set_am_auto');
            $criteria->removeSelectColumn($alias . '.set_am_reason');
            $criteria->removeSelectColumn($alias . '.am_reason_type_id');
            $criteria->removeSelectColumn($alias . '.date_envoi_facture');
            $criteria->removeSelectColumn($alias . '.date_reglement');
            $criteria->removeSelectColumn($alias . '.commentaire');
            $criteria->removeSelectColumn($alias . '.industry_id');
            $criteria->removeSelectColumn($alias . '.periode_cutoff');
            $criteria->removeSelectColumn($alias . '.theme_br');
            $criteria->removeSelectColumn($alias . '.area_id');
            $criteria->removeSelectColumn($alias . '.id_sams_study');
            $criteria->removeSelectColumn($alias . '.recrutement_objectif');
            $criteria->removeSelectColumn($alias . '.id_location_pnl');
            $criteria->removeSelectColumn($alias . '.id_master_project_location_pnl');
            $criteria->removeSelectColumn($alias . '.recrutement_objectif_pr');
            $criteria->removeSelectColumn($alias . '.id_bm');
            $criteria->removeSelectColumn($alias . '.extra_info');
            $criteria->removeSelectColumn($alias . '.account_id');
            $criteria->removeSelectColumn($alias . '.account_manager_id');
            $criteria->removeSelectColumn($alias . '.project_specialty_sponsor_id');
            $criteria->removeSelectColumn($alias . '.language');
            $criteria->removeSelectColumn($alias . '.remise_taux');
            $criteria->removeSelectColumn($alias . '.client_discount_percentage');
            $criteria->removeSelectColumn($alias . '.end_client_discount_percentage');
            $criteria->removeSelectColumn($alias . '.client_quant_discount_percentage');
            $criteria->removeSelectColumn($alias . '.end_client_quant_discount_percentage');
            $criteria->removeSelectColumn($alias . '.sample_plan');
            $criteria->removeSelectColumn($alias . '.isToInvoice');
            $criteria->removeSelectColumn($alias . '.file_path');
            $criteria->removeSelectColumn($alias . '.account_leader_id');
            $criteria->removeSelectColumn($alias . '.account_pm_id');
            $criteria->removeSelectColumn($alias . '.am_email');
            $criteria->removeSelectColumn($alias . '.client_portal_ready');
            $criteria->removeSelectColumn($alias . '.length_of_interview');
            $criteria->removeSelectColumn($alias . '.sunshine_act');
            $criteria->removeSelectColumn($alias . '.is_consolidated');
            $criteria->removeSelectColumn($alias . '.sharepoint_folder');
            $criteria->removeSelectColumn($alias . '.multi_phase');
            $criteria->removeSelectColumn($alias . '.po_number');
            $criteria->removeSelectColumn($alias . '.currencies');
            $criteria->removeSelectColumn($alias . '.sms_relance');
            $criteria->removeSelectColumn($alias . '.id_etude_group');
            $criteria->removeSelectColumn($alias . '.gms');
            $criteria->removeSelectColumn($alias . '.kol');
            $criteria->removeSelectColumn($alias . '.room_rental');
            $criteria->removeSelectColumn($alias . '.recruits_offsite');
            $criteria->removeSelectColumn($alias . '.study_specification');
            $criteria->removeSelectColumn($alias . '.is_study_specification');
            $criteria->removeSelectColumn($alias . '.additional_notes');
            $criteria->removeSelectColumn($alias . '.project_comment');
            $criteria->removeSelectColumn($alias . '.end_client_id');
            $criteria->removeSelectColumn($alias . '.end_client_contact_id');
            $criteria->removeSelectColumn($alias . '.contact_id');
            $criteria->removeSelectColumn($alias . '.contact_client_pm_id');
            $criteria->removeSelectColumn($alias . '.master_project_number');
            $criteria->removeSelectColumn($alias . '.proposed_loi');
            $criteria->removeSelectColumn($alias . '.opportunity_id');
            $criteria->removeSelectColumn($alias . '.si_job_type_id');
            $criteria->removeSelectColumn($alias . '.best_effort');
            $criteria->removeSelectColumn($alias . '.job_status_sf_id');
            $criteria->removeSelectColumn($alias . '.booked_by_sf_id');
            $criteria->removeSelectColumn($alias . '.created_by_sf_id');
            $criteria->removeSelectColumn($alias . '.account_manager_sf_id');
            $criteria->removeSelectColumn($alias . '.created_date');
            $criteria->removeSelectColumn($alias . '.job_qualification_id');
            $criteria->removeSelectColumn($alias . '.proposed_n');
            $criteria->removeSelectColumn($alias . '.german_job_type_id');
            $criteria->removeSelectColumn($alias . '.created_by_comment');
            $criteria->removeSelectColumn($alias . '.focus_vision');
            $criteria->removeSelectColumn($alias . '.si_eu_job_type');
            $criteria->removeSelectColumn($alias . '.intermediate_client_id');
            $criteria->removeSelectColumn($alias . '.intermediate_client_contact_id');
            $criteria->removeSelectColumn($alias . '.us_global_qual_gms_id');
            $criteria->removeSelectColumn($alias . '.facilty_note');
            $criteria->removeSelectColumn($alias . '.currency_iso_code_id');
            $criteria->removeSelectColumn($alias . '.client_list_deletion_id');
            $criteria->removeSelectColumn($alias . '.created_by_id');
            $criteria->removeSelectColumn($alias . '.updated_by_id');
            $criteria->removeSelectColumn($alias . '.created_at');
            $criteria->removeSelectColumn($alias . '.updated_at');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(EtudeTableMap::DATABASE_NAME)->getTable(EtudeTableMap::TABLE_NAME);
    }

    /**
     * Performs a DELETE on the database, given a Etude or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or Etude object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \Model\Etude) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(EtudeTableMap::DATABASE_NAME);
            $criteria->add(EtudeTableMap::COL_ID, (array) $values, Criteria::IN);
        }

        $query = EtudeQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            EtudeTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                EtudeTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the etude table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return EtudeQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a Etude or Criteria object.
     *
     * @param mixed               $criteria Criteria or Etude object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from Etude object
        }

        if ($criteria->containsKey(EtudeTableMap::COL_ID) && $criteria->keyContainsValue(EtudeTableMap::COL_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.EtudeTableMap::COL_ID.')');
        }


        // Set the correct dbName
        $query = EtudeQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // EtudeTableMap
