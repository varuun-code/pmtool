<?php

namespace Model\Map;

use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'sf_ref_salesforce' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 */
class RefSalesForceTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'src.Model.Map.RefSalesForceTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'default';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'sf_ref_salesforce';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\Model\\RefSalesForce';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'src.Model.RefSalesForce';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 6;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 6;

    /**
     * the column name for the id field
     */
    const COL_ID = 'sf_ref_salesforce.id';

    /**
     * the column name for the table field
     */
    const COL_TABLE = 'sf_ref_salesforce.table';

    /**
     * the column name for the label field
     */
    const COL_LABEL = 'sf_ref_salesforce.label';

    /**
     * the column name for the field field
     */
    const COL_FIELD = 'sf_ref_salesforce.field';

    /**
     * the column name for the value field
     */
    const COL_VALUE = 'sf_ref_salesforce.value';

    /**
     * the column name for the actif field
     */
    const COL_ACTIF = 'sf_ref_salesforce.actif';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /** The enumerated values for the table field */
    const COL_TABLE_ACCOUNT = 'account';
    const COL_TABLE_CONTACT = 'contact';
    const COL_TABLE_OPPORTUNITY = 'opportunity';
    const COL_TABLE_ETUDE = 'etude';
    const COL_TABLE_JOB = 'job';
    const COL_TABLE_EVENT = 'event';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Id', 'Table', 'Label', 'Field', 'Value', 'Actif', ),
        self::TYPE_CAMELNAME     => array('id', 'table', 'label', 'field', 'value', 'actif', ),
        self::TYPE_COLNAME       => array(RefSalesForceTableMap::COL_ID, RefSalesForceTableMap::COL_TABLE, RefSalesForceTableMap::COL_LABEL, RefSalesForceTableMap::COL_FIELD, RefSalesForceTableMap::COL_VALUE, RefSalesForceTableMap::COL_ACTIF, ),
        self::TYPE_FIELDNAME     => array('id', 'table', 'label', 'field', 'value', 'actif', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Id' => 0, 'Table' => 1, 'Label' => 2, 'Field' => 3, 'Value' => 4, 'Actif' => 5, ),
        self::TYPE_CAMELNAME     => array('id' => 0, 'table' => 1, 'label' => 2, 'field' => 3, 'value' => 4, 'actif' => 5, ),
        self::TYPE_COLNAME       => array(RefSalesForceTableMap::COL_ID => 0, RefSalesForceTableMap::COL_TABLE => 1, RefSalesForceTableMap::COL_LABEL => 2, RefSalesForceTableMap::COL_FIELD => 3, RefSalesForceTableMap::COL_VALUE => 4, RefSalesForceTableMap::COL_ACTIF => 5, ),
        self::TYPE_FIELDNAME     => array('id' => 0, 'table' => 1, 'label' => 2, 'field' => 3, 'value' => 4, 'actif' => 5, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, )
    );

    /**
     * Holds a list of column names and their normalized version.
     *
     * @var string[]
     */
    protected $normalizedColumnNameMap = [
        'Id' => 'ID',
        'RefSalesForce.Id' => 'ID',
        'id' => 'ID',
        'refSalesForce.id' => 'ID',
        'RefSalesForceTableMap::COL_ID' => 'ID',
        'COL_ID' => 'ID',
        'sf_ref_salesforce.id' => 'ID',
        'Table' => 'TABLE',
        'RefSalesForce.Table' => 'TABLE',
        'table' => 'TABLE',
        'refSalesForce.table' => 'TABLE',
        'RefSalesForceTableMap::COL_TABLE' => 'TABLE',
        'COL_TABLE' => 'TABLE',
        'sf_ref_salesforce.table' => 'TABLE',
        'Label' => 'LABEL',
        'RefSalesForce.Label' => 'LABEL',
        'label' => 'LABEL',
        'refSalesForce.label' => 'LABEL',
        'RefSalesForceTableMap::COL_LABEL' => 'LABEL',
        'COL_LABEL' => 'LABEL',
        'sf_ref_salesforce.label' => 'LABEL',
        'Field' => 'FIELD',
        'RefSalesForce.Field' => 'FIELD',
        'field' => 'FIELD',
        'refSalesForce.field' => 'FIELD',
        'RefSalesForceTableMap::COL_FIELD' => 'FIELD',
        'COL_FIELD' => 'FIELD',
        'sf_ref_salesforce.field' => 'FIELD',
        'Value' => 'VALUE',
        'RefSalesForce.Value' => 'VALUE',
        'value' => 'VALUE',
        'refSalesForce.value' => 'VALUE',
        'RefSalesForceTableMap::COL_VALUE' => 'VALUE',
        'COL_VALUE' => 'VALUE',
        'sf_ref_salesforce.value' => 'VALUE',
        'Actif' => 'ACTIF',
        'RefSalesForce.Actif' => 'ACTIF',
        'actif' => 'ACTIF',
        'refSalesForce.actif' => 'ACTIF',
        'RefSalesForceTableMap::COL_ACTIF' => 'ACTIF',
        'COL_ACTIF' => 'ACTIF',
        'sf_ref_salesforce.actif' => 'ACTIF',
    ];

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
                RefSalesForceTableMap::COL_TABLE => array(
                            self::COL_TABLE_ACCOUNT,
            self::COL_TABLE_CONTACT,
            self::COL_TABLE_OPPORTUNITY,
            self::COL_TABLE_ETUDE,
            self::COL_TABLE_JOB,
            self::COL_TABLE_EVENT,
        ),
    );

    /**
     * Gets the list of values for all ENUM and SET columns
     * @return array
     */
    public static function getValueSets()
    {
      return static::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM or SET column
     * @param string $colname
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = self::getValueSets();

        return $valueSets[$colname];
    }

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('sf_ref_salesforce');
        $this->setPhpName('RefSalesForce');
        $this->setIdentifierQuoting(true);
        $this->setClassName('\\Model\\RefSalesForce');
        $this->setPackage('src.Model');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('id', 'Id', 'INTEGER', true, null, null);
        $this->addColumn('table', 'Table', 'ENUM', true, null, 'account');
        $this->getColumn('table')->setValueSet(array (
  0 => 'account',
  1 => 'contact',
  2 => 'opportunity',
  3 => 'etude',
  4 => 'job',
  5 => 'event',
));
        $this->addColumn('label', 'Label', 'VARCHAR', false, 255, null);
        $this->addColumn('field', 'Field', 'VARCHAR', true, 255, null);
        $this->addColumn('value', 'Value', 'VARCHAR', true, 255, null);
        $this->addColumn('actif', 'Actif', 'BOOLEAN', false, 1, true);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('EventRelatedByRecordTypeId', '\\Model\\Event', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':record_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EventsRelatedByRecordTypeId', false);
        $this->addRelation('EventRelatedByEventSubTypeId', '\\Model\\Event', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':event_sub_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EventsRelatedByEventSubTypeId', false);
        $this->addRelation('EtudeRelatedByUsGlobalQualGmsId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':us_global_qual_gms_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByUsGlobalQualGmsId', false);
        $this->addRelation('EtudeRelatedByJobStatusSfId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':job_status_sf_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByJobStatusSfId', false);
        $this->addRelation('EtudeRelatedByJobQualificationId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':job_qualification_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByJobQualificationId', false);
        $this->addRelation('EtudeRelatedByGermanJobTypeId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':german_job_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByGermanJobTypeId', false);
        $this->addRelation('EtudeRelatedByCurrencyIsoCodeId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':currency_iso_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByCurrencyIsoCodeId', false);
        $this->addRelation('EtudeRelatedByClientListDeletionId', '\\Model\\Etude', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':client_list_deletion_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'EtudesRelatedByClientListDeletionId', false);
        $this->addRelation('JobCostRelatedByRespLocationId', '\\Model\\JobCost', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':resp_location_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobCostsRelatedByRespLocationId', false);
        $this->addRelation('JobCostRelatedByRespondentTypeId', '\\Model\\JobCost', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':respondent_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobCostsRelatedByRespondentTypeId', false);
        $this->addRelation('JobCostRelatedByMethodologyId', '\\Model\\JobCost', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':methodology_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobCostsRelatedByMethodologyId', false);
        $this->addRelation('JobItemRelatedByRespLocationId', '\\Model\\JobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':resp_location_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobItemsRelatedByRespLocationId', false);
        $this->addRelation('JobItemRelatedByRespondentTypeId', '\\Model\\JobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':respondent_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobItemsRelatedByRespondentTypeId', false);
        $this->addRelation('JobItemRelatedByMethodologyId', '\\Model\\JobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':methodology_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobItemsRelatedByMethodologyId', false);
        $this->addRelation('JobRelatedByFacilityRatingId', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':facility_rating_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobsRelatedByFacilityRatingId', false);
        $this->addRelation('JobRelatedByFacilityStaffId', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':facility_staff_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobsRelatedByFacilityStaffId', false);
        $this->addRelation('JobRelatedByProjectManagementId', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':project_management_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobsRelatedByProjectManagementId', false);
        $this->addRelation('JobRelatedByRecruitmentRatingId', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':recruitment_rating_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobsRelatedByRecruitmentRatingId', false);
        $this->addRelation('JobStatus', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':status_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobStatuses', false);
        $this->addRelation('JobCountry', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':country_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobCountries', false);
        $this->addRelation('JobRelatedByEndDateReasonId', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':end_date_reason_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobsRelatedByEndDateReasonId', false);
        $this->addRelation('JobCallCenter', '\\Model\\Job', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':call_center_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'JobCallCenters', false);
        $this->addRelation('JobSampleSources', '\\Model\\JobSampleSources', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':sample_source_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'JobSampleSourcess', false);
        $this->addRelation('Methodology', '\\Model\\Methodology', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':job_qualification_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'Methodologies', false);
        $this->addRelation('OpportunityRelatedByClientTypeId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':client_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByClientTypeId', false);
        $this->addRelation('OpportunityRelatedByUsGlobalQualGmsId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':us_global_qual_gms_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByUsGlobalQualGmsId', false);
        $this->addRelation('OpportunityRelatedByJobQualificationId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':job_qualification_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByJobQualificationId', false);
        $this->addRelation('OpportunityRelatedByCurrencyIsoCodeId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':currency_iso_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByCurrencyIsoCodeId', false);
        $this->addRelation('OpportunityRelatedByStageNameId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':stage_name_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByStageNameId', false);
        $this->addRelation('OpportunityRelatedByPlatformId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':platform_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedByPlatformId', false);
        $this->addRelation('OpportunityRelatedBySpecificsId', '\\Model\\Opportunity', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':specifics_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'OpportunitiesRelatedBySpecificsId', false);
        $this->addRelation('BidJobItemRelatedByRespLocationId', '\\Model\\BidJobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':resp_location_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'BidJobItemsRelatedByRespLocationId', false);
        $this->addRelation('BidJobItemRelatedByMethodologyId', '\\Model\\BidJobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':methodology_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'BidJobItemsRelatedByMethodologyId', false);
        $this->addRelation('BidJobItemRelatedByRespondentTypeId', '\\Model\\BidJobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':respondent_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'BidJobItemsRelatedByRespondentTypeId', false);
        $this->addRelation('AccountRelatedByClientTypeId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':client_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByClientTypeId', false);
        $this->addRelation('AccountRelatedByClientSourceId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':client_source_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByClientSourceId', false);
        $this->addRelation('AccountRelatedByIndustryId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':industry_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByIndustryId', false);
        $this->addRelation('AccountRelatedByStatusId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':status_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByStatusId', false);
        $this->addRelation('AccountRelatedByRelationshipStatusId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':relationship_status_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByRelationshipStatusId', false);
        $this->addRelation('AccountRelatedByDiscountProgramId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':discount_program_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByDiscountProgramId', false);
        $this->addRelation('AccountRelatedByDiscountPercentageId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':discount_percentage_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByDiscountPercentageId', false);
        $this->addRelation('AccountRelatedByEuDiscountPercentageId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':eu_discount_percentage_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByEuDiscountPercentageId', false);
        $this->addRelation('AccountRelatedByQuantDiscountPercentageId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':quant_discount_percentage_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByQuantDiscountPercentageId', false);
        $this->addRelation('AccountRelatedByReceiveInvoiceViaId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':receive_invoice_via_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByReceiveInvoiceViaId', false);
        $this->addRelation('AccountRelatedByEndClientVerticalId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':end_client_vertical_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByEndClientVerticalId', false);
        $this->addRelation('AccountRelatedByCurrencyIsoCodeId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':currency_iso_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByCurrencyIsoCodeId', false);
        $this->addRelation('AccountRelatedByPodQualId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':pod_qual_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByPodQualId', false);
        $this->addRelation('AccountRelatedByPodQuantId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':pod_quant_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByPodQuantId', false);
        $this->addRelation('AccountRelatedByQuantDiscountProgramId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':quant_discount_program_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByQuantDiscountProgramId', false);
        $this->addRelation('AccountRelatedByArPaymentTermsId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ar_payment_terms_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByArPaymentTermsId', false);
        $this->addRelation('AccountRelatedByAiPaymentTermsId', '\\Model\\Account', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ai_payment_terms_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'AccountsRelatedByAiPaymentTermsId', false);
        $this->addRelation('ContactRelatedBySalutationId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':salutation_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedBySalutationId', false);
        $this->addRelation('ContactRelatedByContactStatusId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':contact_status_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByContactStatusId', false);
        $this->addRelation('ContactRelatedByLanguagePreferenceId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':language_preference_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByLanguagePreferenceId', false);
        $this->addRelation('ContactRelatedByTheWallId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':the_wall_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByTheWallId', false);
        $this->addRelation('ContactRelatedByGiftCodeId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':gift_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByGiftCodeId', false);
        $this->addRelation('ContactRelatedByLeadSourceId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':lead_source_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByLeadSourceId', false);
        $this->addRelation('ContactRelatedByCurrencyIsoCodeId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':currency_iso_code_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByCurrencyIsoCodeId', false);
        $this->addRelation('ContactRelatedByTwLeadSourceId', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':tw_lead_source_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByTwLeadSourceId', false);
        $this->addRelation('ContactRelatedByAddedById', '\\Model\\Contact', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':added_by_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', 'ContactsRelatedByAddedById', false);
        $this->addRelation('RefSalesForceOpportunityServices', '\\Model\\RefSalesForceOpportunityServices', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceOpportunityServicess', false);
        $this->addRelation('RefSalesForceOpportunitySector', '\\Model\\RefSalesForceOpportunitySector', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceOpportunitySectors', false);
        $this->addRelation('RefSalesForceOpportunityClosedLostReasonV2', '\\Model\\RefSalesForceOpportunityClosedLostReasonV2', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceOpportunityClosedLostReasonV2s', false);
        $this->addRelation('RefSalesForceContactSchlesingerEvents', '\\Model\\RefSalesForceContactSchlesingerEvents', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactSchlesingerEventss', false);
        $this->addRelation('RefSalesForceContactPossiblePrimaryJobLocation', '\\Model\\RefSalesForceContactPossiblePrimaryJobLocation', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactPossiblePrimaryJobLocations', false);
        $this->addRelation('RefSalesForceContactAreaOfInterest', '\\Model\\RefSalesForceContactAreaOfInterest', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactAreaOfInterests', false);
        $this->addRelation('RefSalesForceContactMarketingAudience', '\\Model\\RefSalesForceContactMarketingAudience', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactMarketingAudiences', false);
        $this->addRelation('RefSalesForceContactMethodology', '\\Model\\RefSalesForceContactMethodology', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactMethodologies', false);
        $this->addRelation('RefSalesForceContactContactSource', '\\Model\\RefSalesForceContactContactSource', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceContactContactSources', false);
        $this->addRelation('RefSalesForceAccountAreasOfResearch', '\\Model\\RefSalesForceAccountAreasOfResearch', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountAreasOfResearches', false);
        $this->addRelation('RefSalesForceAccountCountryOfUse', '\\Model\\RefSalesForceAccountCountryOfUse', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountCountryOfUses', false);
        $this->addRelation('RefSalesForceAccountRegularlyUsesAnotherVendorFor', '\\Model\\RefSalesForceAccountRegularlyUsesAnotherVendorFor', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountRegularlyUsesAnotherVendorFors', false);
        $this->addRelation('RefSalesForceAccountRegularlyUsesSaFor', '\\Model\\RefSalesForceAccountRegularlyUsesSaFor', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountRegularlyUsesSaFors', false);
        $this->addRelation('RefSalesForceAccountProductsAndServicesUsed', '\\Model\\RefSalesForceAccountProductsAndServicesUsed', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountProductsAndServicesUseds', false);
        $this->addRelation('RefSalesForceAccountAgreementType', '\\Model\\RefSalesForceAccountAgreementType', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountAgreementTypes', false);
        $this->addRelation('RefSalesForceAccountSubType', '\\Model\\RefSalesForceAccountSubType', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceAccountSubTypes', false);
        $this->addRelation('RefSalesForceJobServices', '\\Model\\RefSalesForceJobServices', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceJobServicess', false);
        $this->addRelation('RefSalesForceEtudeSector', '\\Model\\RefSalesForceEtudeSector', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':ref_salesforce_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'RefSalesForceEtudeSectors', false);
        $this->addRelation('Area', '\\Model\\Area', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':sector_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'Areas', false);
        $this->addRelation('Job', '\\Model\\Job', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'Jobs');
        $this->addRelation('OpportunityServices', '\\Model\\Opportunity', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'OpportunityServicess');
        $this->addRelation('OpportunitySector', '\\Model\\Opportunity', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'OpportunitySectors');
        $this->addRelation('OpportunityClosedLostReasonV2', '\\Model\\Opportunity', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'OpportunityClosedLostReasonV2s');
        $this->addRelation('ContactSchlesingerEvents', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactSchlesingerEventss');
        $this->addRelation('ContactPossiblePrimaryJobLocation', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactPossiblePrimaryJobLocations');
        $this->addRelation('ContactAreaOfInterest', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactAreaOfInterests');
        $this->addRelation('ContactMarketingAudience', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactMarketingAudiences');
        $this->addRelation('ContactMethodology', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactMethodologies');
        $this->addRelation('ContactContactSource', '\\Model\\Contact', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'ContactContactSources');
        $this->addRelation('AccountAreasOfResearch', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountAreasOfResearches');
        $this->addRelation('AccountCountryOfUse', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountCountryOfUses');
        $this->addRelation('AccountRegularlyUsesAnotherVendorFor', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountRegularlyUsesAnotherVendorFors');
        $this->addRelation('AccountRegularlyUsesSaFor', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountRegularlyUsesSaFors');
        $this->addRelation('AccountProductsAndServicesUsed', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountProductsAndServicesUseds');
        $this->addRelation('AccountAgreementType', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountAgreementTypes');
        $this->addRelation('AccountSubType', '\\Model\\Account', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'AccountSubTypes');
        $this->addRelation('JobServices', '\\Model\\Job', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'JobServicess');
        $this->addRelation('EtudeSector', '\\Model\\Etude', RelationMap::MANY_TO_MANY, array(), 'CASCADE', 'CASCADE', 'EtudeSectors');
    } // buildRelations()

    /**
     * Method to invalidate the instance pool of all tables related to sf_ref_salesforce     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
        // Invalidate objects in related instance pools,
        // since one or more of them may be deleted by ON DELETE CASCADE/SETNULL rule.
        EventTableMap::clearInstancePool();
        EtudeTableMap::clearInstancePool();
        JobCostTableMap::clearInstancePool();
        JobItemTableMap::clearInstancePool();
        JobTableMap::clearInstancePool();
        JobSampleSourcesTableMap::clearInstancePool();
        MethodologyTableMap::clearInstancePool();
        OpportunityTableMap::clearInstancePool();
        BidJobItemTableMap::clearInstancePool();
        AccountTableMap::clearInstancePool();
        ContactTableMap::clearInstancePool();
        RefSalesForceOpportunityServicesTableMap::clearInstancePool();
        RefSalesForceOpportunitySectorTableMap::clearInstancePool();
        RefSalesForceOpportunityClosedLostReasonV2TableMap::clearInstancePool();
        RefSalesForceContactSchlesingerEventsTableMap::clearInstancePool();
        RefSalesForceContactPossiblePrimaryJobLocationTableMap::clearInstancePool();
        RefSalesForceContactAreaOfInterestTableMap::clearInstancePool();
        RefSalesForceContactMarketingAudienceTableMap::clearInstancePool();
        RefSalesForceContactMethodologyTableMap::clearInstancePool();
        RefSalesForceContactContactSourceTableMap::clearInstancePool();
        RefSalesForceAccountAreasOfResearchTableMap::clearInstancePool();
        RefSalesForceAccountCountryOfUseTableMap::clearInstancePool();
        RefSalesForceAccountRegularlyUsesAnotherVendorForTableMap::clearInstancePool();
        RefSalesForceAccountRegularlyUsesSaForTableMap::clearInstancePool();
        RefSalesForceAccountProductsAndServicesUsedTableMap::clearInstancePool();
        RefSalesForceAccountAgreementTypeTableMap::clearInstancePool();
        RefSalesForceAccountSubTypeTableMap::clearInstancePool();
        RefSalesForceJobServicesTableMap::clearInstancePool();
        RefSalesForceEtudeSectorTableMap::clearInstancePool();
        AreaTableMap::clearInstancePool();
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return null === $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] || is_scalar($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)]) || is_callable([$row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)], '__toString']) ? (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] : $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }

    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? RefSalesForceTableMap::CLASS_DEFAULT : RefSalesForceTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (RefSalesForce object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = RefSalesForceTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = RefSalesForceTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + RefSalesForceTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = RefSalesForceTableMap::OM_CLASS;
            /** @var RefSalesForce $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            RefSalesForceTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = RefSalesForceTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = RefSalesForceTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var RefSalesForce $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                RefSalesForceTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_ID);
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_TABLE);
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_LABEL);
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_FIELD);
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_VALUE);
            $criteria->addSelectColumn(RefSalesForceTableMap::COL_ACTIF);
        } else {
            $criteria->addSelectColumn($alias . '.id');
            $criteria->addSelectColumn($alias . '.table');
            $criteria->addSelectColumn($alias . '.label');
            $criteria->addSelectColumn($alias . '.field');
            $criteria->addSelectColumn($alias . '.value');
            $criteria->addSelectColumn($alias . '.actif');
        }
    }

    /**
     * Remove all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be removed as they are only loaded on demand.
     *
     * @param Criteria $criteria object containing the columns to remove.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function removeSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_ID);
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_TABLE);
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_LABEL);
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_FIELD);
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_VALUE);
            $criteria->removeSelectColumn(RefSalesForceTableMap::COL_ACTIF);
        } else {
            $criteria->removeSelectColumn($alias . '.id');
            $criteria->removeSelectColumn($alias . '.table');
            $criteria->removeSelectColumn($alias . '.label');
            $criteria->removeSelectColumn($alias . '.field');
            $criteria->removeSelectColumn($alias . '.value');
            $criteria->removeSelectColumn($alias . '.actif');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(RefSalesForceTableMap::DATABASE_NAME)->getTable(RefSalesForceTableMap::TABLE_NAME);
    }

    /**
     * Performs a DELETE on the database, given a RefSalesForce or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or RefSalesForce object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RefSalesForceTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \Model\RefSalesForce) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(RefSalesForceTableMap::DATABASE_NAME);
            $criteria->add(RefSalesForceTableMap::COL_ID, (array) $values, Criteria::IN);
        }

        $query = RefSalesForceQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            RefSalesForceTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                RefSalesForceTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the sf_ref_salesforce table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return RefSalesForceQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a RefSalesForce or Criteria object.
     *
     * @param mixed               $criteria Criteria or RefSalesForce object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RefSalesForceTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from RefSalesForce object
        }


        // Set the correct dbName
        $query = RefSalesForceQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // RefSalesForceTableMap
