<?php

namespace Model\Map;

use Model\SfOpportunityBidJobItemArchive;
use Model\SfOpportunityBidJobItemArchiveQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'sf_opportunity_bid_job_item_archive' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 */
class SfOpportunityBidJobItemArchiveTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'src.Model.Map.SfOpportunityBidJobItemArchiveTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'default';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'sf_opportunity_bid_job_item_archive';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\Model\\SfOpportunityBidJobItemArchive';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'src.Model.SfOpportunityBidJobItemArchive';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 38;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 38;

    /**
     * the column name for the id field
     */
    const COL_ID = 'sf_opportunity_bid_job_item_archive.id';

    /**
     * the column name for the bid_job_id field
     */
    const COL_BID_JOB_ID = 'sf_opportunity_bid_job_item_archive.bid_job_id';

    /**
     * the column name for the event_id field
     */
    const COL_EVENT_ID = 'sf_opportunity_bid_job_item_archive.event_id';

    /**
     * the column name for the section_id field
     */
    const COL_SECTION_ID = 'sf_opportunity_bid_job_item_archive.section_id';

    /**
     * the column name for the title field
     */
    const COL_TITLE = 'sf_opportunity_bid_job_item_archive.title';

    /**
     * the column name for the vendor_id field
     */
    const COL_VENDOR_ID = 'sf_opportunity_bid_job_item_archive.vendor_id';

    /**
     * the column name for the resp_location_id field
     */
    const COL_RESP_LOCATION_ID = 'sf_opportunity_bid_job_item_archive.resp_location_id';

    /**
     * the column name for the methodology_id field
     */
    const COL_METHODOLOGY_ID = 'sf_opportunity_bid_job_item_archive.methodology_id';

    /**
     * the column name for the date field
     */
    const COL_DATE = 'sf_opportunity_bid_job_item_archive.date';

    /**
     * the column name for the selling_qty field
     */
    const COL_SELLING_QTY = 'sf_opportunity_bid_job_item_archive.selling_qty';

    /**
     * the column name for the selling_unit_price field
     */
    const COL_SELLING_UNIT_PRICE = 'sf_opportunity_bid_job_item_archive.selling_unit_price';

    /**
     * the column name for the unit field
     */
    const COL_UNIT = 'sf_opportunity_bid_job_item_archive.unit';

    /**
     * the column name for the selling_price field
     */
    const COL_SELLING_PRICE = 'sf_opportunity_bid_job_item_archive.selling_price';

    /**
     * the column name for the cost_qty field
     */
    const COL_COST_QTY = 'sf_opportunity_bid_job_item_archive.cost_qty';

    /**
     * the column name for the cost_unit_price field
     */
    const COL_COST_UNIT_PRICE = 'sf_opportunity_bid_job_item_archive.cost_unit_price';

    /**
     * the column name for the cost_location_unit_price field
     */
    const COL_COST_LOCATION_UNIT_PRICE = 'sf_opportunity_bid_job_item_archive.cost_location_unit_price';

    /**
     * the column name for the cost_rate field
     */
    const COL_COST_RATE = 'sf_opportunity_bid_job_item_archive.cost_rate';

    /**
     * the column name for the cost_price field
     */
    const COL_COST_PRICE = 'sf_opportunity_bid_job_item_archive.cost_price';

    /**
     * the column name for the discount_comment field
     */
    const COL_DISCOUNT_COMMENT = 'sf_opportunity_bid_job_item_archive.discount_comment';

    /**
     * the column name for the discount_percent field
     */
    const COL_DISCOUNT_PERCENT = 'sf_opportunity_bid_job_item_archive.discount_percent';

    /**
     * the column name for the discount_exclude field
     */
    const COL_DISCOUNT_EXCLUDE = 'sf_opportunity_bid_job_item_archive.discount_exclude';

    /**
     * the column name for the discount_auto field
     */
    const COL_DISCOUNT_AUTO = 'sf_opportunity_bid_job_item_archive.discount_auto';

    /**
     * the column name for the pm_comment field
     */
    const COL_PM_COMMENT = 'sf_opportunity_bid_job_item_archive.pm_comment';

    /**
     * the column name for the order field
     */
    const COL_ORDER = 'sf_opportunity_bid_job_item_archive.order';

    /**
     * the column name for the group field
     */
    const COL_GROUP = 'sf_opportunity_bid_job_item_archive.group';

    /**
     * the column name for the group_title field
     */
    const COL_GROUP_TITLE = 'sf_opportunity_bid_job_item_archive.group_title';

    /**
     * the column name for the super_group field
     */
    const COL_SUPER_GROUP = 'sf_opportunity_bid_job_item_archive.super_group';

    /**
     * the column name for the super_group_title field
     */
    const COL_SUPER_GROUP_TITLE = 'sf_opportunity_bid_job_item_archive.super_group_title';

    /**
     * the column name for the first_discount_percentage field
     */
    const COL_FIRST_DISCOUNT_PERCENTAGE = 'sf_opportunity_bid_job_item_archive.first_discount_percentage';

    /**
     * the column name for the second_discount_percentage field
     */
    const COL_SECOND_DISCOUNT_PERCENTAGE = 'sf_opportunity_bid_job_item_archive.second_discount_percentage';

    /**
     * the column name for the first_discount_section_id field
     */
    const COL_FIRST_DISCOUNT_SECTION_ID = 'sf_opportunity_bid_job_item_archive.first_discount_section_id';

    /**
     * the column name for the second_discount_section_id field
     */
    const COL_SECOND_DISCOUNT_SECTION_ID = 'sf_opportunity_bid_job_item_archive.second_discount_section_id';

    /**
     * the column name for the respondent_type_id field
     */
    const COL_RESPONDENT_TYPE_ID = 'sf_opportunity_bid_job_item_archive.respondent_type_id';

    /**
     * the column name for the created_by_id field
     */
    const COL_CREATED_BY_ID = 'sf_opportunity_bid_job_item_archive.created_by_id';

    /**
     * the column name for the updated_by_id field
     */
    const COL_UPDATED_BY_ID = 'sf_opportunity_bid_job_item_archive.updated_by_id';

    /**
     * the column name for the created_at field
     */
    const COL_CREATED_AT = 'sf_opportunity_bid_job_item_archive.created_at';

    /**
     * the column name for the updated_at field
     */
    const COL_UPDATED_AT = 'sf_opportunity_bid_job_item_archive.updated_at';

    /**
     * the column name for the archived_at field
     */
    const COL_ARCHIVED_AT = 'sf_opportunity_bid_job_item_archive.archived_at';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Id', 'BidJobId', 'EventId', 'SectionId', 'Title', 'VendorId', 'RespLocationId', 'MethodologyId', 'Date', 'SellingQty', 'SellingUnitPrice', 'Unit', 'SellingPrice', 'CostQty', 'CostUnitPrice', 'CostLocationUnitPrice', 'CostRate', 'CostPrice', 'DiscountComment', 'DiscountPercent', 'DiscountExclude', 'DiscountAuto', 'PMComment', 'Order', 'Group', 'GroupTitle', 'SuperGroup', 'SuperGroupTitle', 'FirstDiscountPercentage', 'SecondDiscountPercentage', 'FirstDiscountSectionId', 'SecondDiscountSectionId', 'RespondentTypeId', 'CreatedById', 'UpdatedById', 'CreatedAt', 'UpdatedAt', 'ArchivedAt', ),
        self::TYPE_CAMELNAME     => array('id', 'bidJobId', 'eventId', 'sectionId', 'title', 'vendorId', 'respLocationId', 'methodologyId', 'date', 'sellingQty', 'sellingUnitPrice', 'unit', 'sellingPrice', 'costQty', 'costUnitPrice', 'costLocationUnitPrice', 'costRate', 'costPrice', 'discountComment', 'discountPercent', 'discountExclude', 'discountAuto', 'pMComment', 'order', 'group', 'groupTitle', 'superGroup', 'superGroupTitle', 'firstDiscountPercentage', 'secondDiscountPercentage', 'firstDiscountSectionId', 'secondDiscountSectionId', 'respondentTypeId', 'createdById', 'updatedById', 'createdAt', 'updatedAt', 'archivedAt', ),
        self::TYPE_COLNAME       => array(SfOpportunityBidJobItemArchiveTableMap::COL_ID, SfOpportunityBidJobItemArchiveTableMap::COL_BID_JOB_ID, SfOpportunityBidJobItemArchiveTableMap::COL_EVENT_ID, SfOpportunityBidJobItemArchiveTableMap::COL_SECTION_ID, SfOpportunityBidJobItemArchiveTableMap::COL_TITLE, SfOpportunityBidJobItemArchiveTableMap::COL_VENDOR_ID, SfOpportunityBidJobItemArchiveTableMap::COL_RESP_LOCATION_ID, SfOpportunityBidJobItemArchiveTableMap::COL_METHODOLOGY_ID, SfOpportunityBidJobItemArchiveTableMap::COL_DATE, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_QTY, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_UNIT_PRICE, SfOpportunityBidJobItemArchiveTableMap::COL_UNIT, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_PRICE, SfOpportunityBidJobItemArchiveTableMap::COL_COST_QTY, SfOpportunityBidJobItemArchiveTableMap::COL_COST_UNIT_PRICE, SfOpportunityBidJobItemArchiveTableMap::COL_COST_LOCATION_UNIT_PRICE, SfOpportunityBidJobItemArchiveTableMap::COL_COST_RATE, SfOpportunityBidJobItemArchiveTableMap::COL_COST_PRICE, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_COMMENT, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_PERCENT, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_EXCLUDE, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_AUTO, SfOpportunityBidJobItemArchiveTableMap::COL_PM_COMMENT, SfOpportunityBidJobItemArchiveTableMap::COL_ORDER, SfOpportunityBidJobItemArchiveTableMap::COL_GROUP, SfOpportunityBidJobItemArchiveTableMap::COL_GROUP_TITLE, SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP, SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP_TITLE, SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_PERCENTAGE, SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_PERCENTAGE, SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_SECTION_ID, SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_SECTION_ID, SfOpportunityBidJobItemArchiveTableMap::COL_RESPONDENT_TYPE_ID, SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_BY_ID, SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_BY_ID, SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_AT, SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_AT, SfOpportunityBidJobItemArchiveTableMap::COL_ARCHIVED_AT, ),
        self::TYPE_FIELDNAME     => array('id', 'bid_job_id', 'event_id', 'section_id', 'title', 'vendor_id', 'resp_location_id', 'methodology_id', 'date', 'selling_qty', 'selling_unit_price', 'unit', 'selling_price', 'cost_qty', 'cost_unit_price', 'cost_location_unit_price', 'cost_rate', 'cost_price', 'discount_comment', 'discount_percent', 'discount_exclude', 'discount_auto', 'pm_comment', 'order', 'group', 'group_title', 'super_group', 'super_group_title', 'first_discount_percentage', 'second_discount_percentage', 'first_discount_section_id', 'second_discount_section_id', 'respondent_type_id', 'created_by_id', 'updated_by_id', 'created_at', 'updated_at', 'archived_at', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Id' => 0, 'BidJobId' => 1, 'EventId' => 2, 'SectionId' => 3, 'Title' => 4, 'VendorId' => 5, 'RespLocationId' => 6, 'MethodologyId' => 7, 'Date' => 8, 'SellingQty' => 9, 'SellingUnitPrice' => 10, 'Unit' => 11, 'SellingPrice' => 12, 'CostQty' => 13, 'CostUnitPrice' => 14, 'CostLocationUnitPrice' => 15, 'CostRate' => 16, 'CostPrice' => 17, 'DiscountComment' => 18, 'DiscountPercent' => 19, 'DiscountExclude' => 20, 'DiscountAuto' => 21, 'PMComment' => 22, 'Order' => 23, 'Group' => 24, 'GroupTitle' => 25, 'SuperGroup' => 26, 'SuperGroupTitle' => 27, 'FirstDiscountPercentage' => 28, 'SecondDiscountPercentage' => 29, 'FirstDiscountSectionId' => 30, 'SecondDiscountSectionId' => 31, 'RespondentTypeId' => 32, 'CreatedById' => 33, 'UpdatedById' => 34, 'CreatedAt' => 35, 'UpdatedAt' => 36, 'ArchivedAt' => 37, ),
        self::TYPE_CAMELNAME     => array('id' => 0, 'bidJobId' => 1, 'eventId' => 2, 'sectionId' => 3, 'title' => 4, 'vendorId' => 5, 'respLocationId' => 6, 'methodologyId' => 7, 'date' => 8, 'sellingQty' => 9, 'sellingUnitPrice' => 10, 'unit' => 11, 'sellingPrice' => 12, 'costQty' => 13, 'costUnitPrice' => 14, 'costLocationUnitPrice' => 15, 'costRate' => 16, 'costPrice' => 17, 'discountComment' => 18, 'discountPercent' => 19, 'discountExclude' => 20, 'discountAuto' => 21, 'pMComment' => 22, 'order' => 23, 'group' => 24, 'groupTitle' => 25, 'superGroup' => 26, 'superGroupTitle' => 27, 'firstDiscountPercentage' => 28, 'secondDiscountPercentage' => 29, 'firstDiscountSectionId' => 30, 'secondDiscountSectionId' => 31, 'respondentTypeId' => 32, 'createdById' => 33, 'updatedById' => 34, 'createdAt' => 35, 'updatedAt' => 36, 'archivedAt' => 37, ),
        self::TYPE_COLNAME       => array(SfOpportunityBidJobItemArchiveTableMap::COL_ID => 0, SfOpportunityBidJobItemArchiveTableMap::COL_BID_JOB_ID => 1, SfOpportunityBidJobItemArchiveTableMap::COL_EVENT_ID => 2, SfOpportunityBidJobItemArchiveTableMap::COL_SECTION_ID => 3, SfOpportunityBidJobItemArchiveTableMap::COL_TITLE => 4, SfOpportunityBidJobItemArchiveTableMap::COL_VENDOR_ID => 5, SfOpportunityBidJobItemArchiveTableMap::COL_RESP_LOCATION_ID => 6, SfOpportunityBidJobItemArchiveTableMap::COL_METHODOLOGY_ID => 7, SfOpportunityBidJobItemArchiveTableMap::COL_DATE => 8, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_QTY => 9, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_UNIT_PRICE => 10, SfOpportunityBidJobItemArchiveTableMap::COL_UNIT => 11, SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_PRICE => 12, SfOpportunityBidJobItemArchiveTableMap::COL_COST_QTY => 13, SfOpportunityBidJobItemArchiveTableMap::COL_COST_UNIT_PRICE => 14, SfOpportunityBidJobItemArchiveTableMap::COL_COST_LOCATION_UNIT_PRICE => 15, SfOpportunityBidJobItemArchiveTableMap::COL_COST_RATE => 16, SfOpportunityBidJobItemArchiveTableMap::COL_COST_PRICE => 17, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_COMMENT => 18, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_PERCENT => 19, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_EXCLUDE => 20, SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_AUTO => 21, SfOpportunityBidJobItemArchiveTableMap::COL_PM_COMMENT => 22, SfOpportunityBidJobItemArchiveTableMap::COL_ORDER => 23, SfOpportunityBidJobItemArchiveTableMap::COL_GROUP => 24, SfOpportunityBidJobItemArchiveTableMap::COL_GROUP_TITLE => 25, SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP => 26, SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP_TITLE => 27, SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_PERCENTAGE => 28, SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_PERCENTAGE => 29, SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_SECTION_ID => 30, SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_SECTION_ID => 31, SfOpportunityBidJobItemArchiveTableMap::COL_RESPONDENT_TYPE_ID => 32, SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_BY_ID => 33, SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_BY_ID => 34, SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_AT => 35, SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_AT => 36, SfOpportunityBidJobItemArchiveTableMap::COL_ARCHIVED_AT => 37, ),
        self::TYPE_FIELDNAME     => array('id' => 0, 'bid_job_id' => 1, 'event_id' => 2, 'section_id' => 3, 'title' => 4, 'vendor_id' => 5, 'resp_location_id' => 6, 'methodology_id' => 7, 'date' => 8, 'selling_qty' => 9, 'selling_unit_price' => 10, 'unit' => 11, 'selling_price' => 12, 'cost_qty' => 13, 'cost_unit_price' => 14, 'cost_location_unit_price' => 15, 'cost_rate' => 16, 'cost_price' => 17, 'discount_comment' => 18, 'discount_percent' => 19, 'discount_exclude' => 20, 'discount_auto' => 21, 'pm_comment' => 22, 'order' => 23, 'group' => 24, 'group_title' => 25, 'super_group' => 26, 'super_group_title' => 27, 'first_discount_percentage' => 28, 'second_discount_percentage' => 29, 'first_discount_section_id' => 30, 'second_discount_section_id' => 31, 'respondent_type_id' => 32, 'created_by_id' => 33, 'updated_by_id' => 34, 'created_at' => 35, 'updated_at' => 36, 'archived_at' => 37, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, )
    );

    /**
     * Holds a list of column names and their normalized version.
     *
     * @var string[]
     */
    protected $normalizedColumnNameMap = [
        'Id' => 'ID',
        'SfOpportunityBidJobItemArchive.Id' => 'ID',
        'id' => 'ID',
        'sfOpportunityBidJobItemArchive.id' => 'ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_ID' => 'ID',
        'COL_ID' => 'ID',
        'sf_opportunity_bid_job_item_archive.id' => 'ID',
        'BidJobId' => 'BID_JOB_ID',
        'SfOpportunityBidJobItemArchive.BidJobId' => 'BID_JOB_ID',
        'bidJobId' => 'BID_JOB_ID',
        'sfOpportunityBidJobItemArchive.bidJobId' => 'BID_JOB_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_BID_JOB_ID' => 'BID_JOB_ID',
        'COL_BID_JOB_ID' => 'BID_JOB_ID',
        'bid_job_id' => 'BID_JOB_ID',
        'sf_opportunity_bid_job_item_archive.bid_job_id' => 'BID_JOB_ID',
        'EventId' => 'EVENT_ID',
        'SfOpportunityBidJobItemArchive.EventId' => 'EVENT_ID',
        'eventId' => 'EVENT_ID',
        'sfOpportunityBidJobItemArchive.eventId' => 'EVENT_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_EVENT_ID' => 'EVENT_ID',
        'COL_EVENT_ID' => 'EVENT_ID',
        'event_id' => 'EVENT_ID',
        'sf_opportunity_bid_job_item_archive.event_id' => 'EVENT_ID',
        'SectionId' => 'SECTION_ID',
        'SfOpportunityBidJobItemArchive.SectionId' => 'SECTION_ID',
        'sectionId' => 'SECTION_ID',
        'sfOpportunityBidJobItemArchive.sectionId' => 'SECTION_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SECTION_ID' => 'SECTION_ID',
        'COL_SECTION_ID' => 'SECTION_ID',
        'section_id' => 'SECTION_ID',
        'sf_opportunity_bid_job_item_archive.section_id' => 'SECTION_ID',
        'Title' => 'TITLE',
        'SfOpportunityBidJobItemArchive.Title' => 'TITLE',
        'title' => 'TITLE',
        'sfOpportunityBidJobItemArchive.title' => 'TITLE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_TITLE' => 'TITLE',
        'COL_TITLE' => 'TITLE',
        'sf_opportunity_bid_job_item_archive.title' => 'TITLE',
        'VendorId' => 'VENDOR_ID',
        'SfOpportunityBidJobItemArchive.VendorId' => 'VENDOR_ID',
        'vendorId' => 'VENDOR_ID',
        'sfOpportunityBidJobItemArchive.vendorId' => 'VENDOR_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_VENDOR_ID' => 'VENDOR_ID',
        'COL_VENDOR_ID' => 'VENDOR_ID',
        'vendor_id' => 'VENDOR_ID',
        'sf_opportunity_bid_job_item_archive.vendor_id' => 'VENDOR_ID',
        'RespLocationId' => 'RESP_LOCATION_ID',
        'SfOpportunityBidJobItemArchive.RespLocationId' => 'RESP_LOCATION_ID',
        'respLocationId' => 'RESP_LOCATION_ID',
        'sfOpportunityBidJobItemArchive.respLocationId' => 'RESP_LOCATION_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_RESP_LOCATION_ID' => 'RESP_LOCATION_ID',
        'COL_RESP_LOCATION_ID' => 'RESP_LOCATION_ID',
        'resp_location_id' => 'RESP_LOCATION_ID',
        'sf_opportunity_bid_job_item_archive.resp_location_id' => 'RESP_LOCATION_ID',
        'MethodologyId' => 'METHODOLOGY_ID',
        'SfOpportunityBidJobItemArchive.MethodologyId' => 'METHODOLOGY_ID',
        'methodologyId' => 'METHODOLOGY_ID',
        'sfOpportunityBidJobItemArchive.methodologyId' => 'METHODOLOGY_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_METHODOLOGY_ID' => 'METHODOLOGY_ID',
        'COL_METHODOLOGY_ID' => 'METHODOLOGY_ID',
        'methodology_id' => 'METHODOLOGY_ID',
        'sf_opportunity_bid_job_item_archive.methodology_id' => 'METHODOLOGY_ID',
        'Date' => 'DATE',
        'SfOpportunityBidJobItemArchive.Date' => 'DATE',
        'date' => 'DATE',
        'sfOpportunityBidJobItemArchive.date' => 'DATE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_DATE' => 'DATE',
        'COL_DATE' => 'DATE',
        'sf_opportunity_bid_job_item_archive.date' => 'DATE',
        'SellingQty' => 'SELLING_QTY',
        'SfOpportunityBidJobItemArchive.SellingQty' => 'SELLING_QTY',
        'sellingQty' => 'SELLING_QTY',
        'sfOpportunityBidJobItemArchive.sellingQty' => 'SELLING_QTY',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_QTY' => 'SELLING_QTY',
        'COL_SELLING_QTY' => 'SELLING_QTY',
        'selling_qty' => 'SELLING_QTY',
        'sf_opportunity_bid_job_item_archive.selling_qty' => 'SELLING_QTY',
        'SellingUnitPrice' => 'SELLING_UNIT_PRICE',
        'SfOpportunityBidJobItemArchive.SellingUnitPrice' => 'SELLING_UNIT_PRICE',
        'sellingUnitPrice' => 'SELLING_UNIT_PRICE',
        'sfOpportunityBidJobItemArchive.sellingUnitPrice' => 'SELLING_UNIT_PRICE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_UNIT_PRICE' => 'SELLING_UNIT_PRICE',
        'COL_SELLING_UNIT_PRICE' => 'SELLING_UNIT_PRICE',
        'selling_unit_price' => 'SELLING_UNIT_PRICE',
        'sf_opportunity_bid_job_item_archive.selling_unit_price' => 'SELLING_UNIT_PRICE',
        'Unit' => 'UNIT',
        'SfOpportunityBidJobItemArchive.Unit' => 'UNIT',
        'unit' => 'UNIT',
        'sfOpportunityBidJobItemArchive.unit' => 'UNIT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_UNIT' => 'UNIT',
        'COL_UNIT' => 'UNIT',
        'sf_opportunity_bid_job_item_archive.unit' => 'UNIT',
        'SellingPrice' => 'SELLING_PRICE',
        'SfOpportunityBidJobItemArchive.SellingPrice' => 'SELLING_PRICE',
        'sellingPrice' => 'SELLING_PRICE',
        'sfOpportunityBidJobItemArchive.sellingPrice' => 'SELLING_PRICE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_PRICE' => 'SELLING_PRICE',
        'COL_SELLING_PRICE' => 'SELLING_PRICE',
        'selling_price' => 'SELLING_PRICE',
        'sf_opportunity_bid_job_item_archive.selling_price' => 'SELLING_PRICE',
        'CostQty' => 'COST_QTY',
        'SfOpportunityBidJobItemArchive.CostQty' => 'COST_QTY',
        'costQty' => 'COST_QTY',
        'sfOpportunityBidJobItemArchive.costQty' => 'COST_QTY',
        'SfOpportunityBidJobItemArchiveTableMap::COL_COST_QTY' => 'COST_QTY',
        'COL_COST_QTY' => 'COST_QTY',
        'cost_qty' => 'COST_QTY',
        'sf_opportunity_bid_job_item_archive.cost_qty' => 'COST_QTY',
        'CostUnitPrice' => 'COST_UNIT_PRICE',
        'SfOpportunityBidJobItemArchive.CostUnitPrice' => 'COST_UNIT_PRICE',
        'costUnitPrice' => 'COST_UNIT_PRICE',
        'sfOpportunityBidJobItemArchive.costUnitPrice' => 'COST_UNIT_PRICE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_COST_UNIT_PRICE' => 'COST_UNIT_PRICE',
        'COL_COST_UNIT_PRICE' => 'COST_UNIT_PRICE',
        'cost_unit_price' => 'COST_UNIT_PRICE',
        'sf_opportunity_bid_job_item_archive.cost_unit_price' => 'COST_UNIT_PRICE',
        'CostLocationUnitPrice' => 'COST_LOCATION_UNIT_PRICE',
        'SfOpportunityBidJobItemArchive.CostLocationUnitPrice' => 'COST_LOCATION_UNIT_PRICE',
        'costLocationUnitPrice' => 'COST_LOCATION_UNIT_PRICE',
        'sfOpportunityBidJobItemArchive.costLocationUnitPrice' => 'COST_LOCATION_UNIT_PRICE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_COST_LOCATION_UNIT_PRICE' => 'COST_LOCATION_UNIT_PRICE',
        'COL_COST_LOCATION_UNIT_PRICE' => 'COST_LOCATION_UNIT_PRICE',
        'cost_location_unit_price' => 'COST_LOCATION_UNIT_PRICE',
        'sf_opportunity_bid_job_item_archive.cost_location_unit_price' => 'COST_LOCATION_UNIT_PRICE',
        'CostRate' => 'COST_RATE',
        'SfOpportunityBidJobItemArchive.CostRate' => 'COST_RATE',
        'costRate' => 'COST_RATE',
        'sfOpportunityBidJobItemArchive.costRate' => 'COST_RATE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_COST_RATE' => 'COST_RATE',
        'COL_COST_RATE' => 'COST_RATE',
        'cost_rate' => 'COST_RATE',
        'sf_opportunity_bid_job_item_archive.cost_rate' => 'COST_RATE',
        'CostPrice' => 'COST_PRICE',
        'SfOpportunityBidJobItemArchive.CostPrice' => 'COST_PRICE',
        'costPrice' => 'COST_PRICE',
        'sfOpportunityBidJobItemArchive.costPrice' => 'COST_PRICE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_COST_PRICE' => 'COST_PRICE',
        'COL_COST_PRICE' => 'COST_PRICE',
        'cost_price' => 'COST_PRICE',
        'sf_opportunity_bid_job_item_archive.cost_price' => 'COST_PRICE',
        'DiscountComment' => 'DISCOUNT_COMMENT',
        'SfOpportunityBidJobItemArchive.DiscountComment' => 'DISCOUNT_COMMENT',
        'discountComment' => 'DISCOUNT_COMMENT',
        'sfOpportunityBidJobItemArchive.discountComment' => 'DISCOUNT_COMMENT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_COMMENT' => 'DISCOUNT_COMMENT',
        'COL_DISCOUNT_COMMENT' => 'DISCOUNT_COMMENT',
        'discount_comment' => 'DISCOUNT_COMMENT',
        'sf_opportunity_bid_job_item_archive.discount_comment' => 'DISCOUNT_COMMENT',
        'DiscountPercent' => 'DISCOUNT_PERCENT',
        'SfOpportunityBidJobItemArchive.DiscountPercent' => 'DISCOUNT_PERCENT',
        'discountPercent' => 'DISCOUNT_PERCENT',
        'sfOpportunityBidJobItemArchive.discountPercent' => 'DISCOUNT_PERCENT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_PERCENT' => 'DISCOUNT_PERCENT',
        'COL_DISCOUNT_PERCENT' => 'DISCOUNT_PERCENT',
        'discount_percent' => 'DISCOUNT_PERCENT',
        'sf_opportunity_bid_job_item_archive.discount_percent' => 'DISCOUNT_PERCENT',
        'DiscountExclude' => 'DISCOUNT_EXCLUDE',
        'SfOpportunityBidJobItemArchive.DiscountExclude' => 'DISCOUNT_EXCLUDE',
        'discountExclude' => 'DISCOUNT_EXCLUDE',
        'sfOpportunityBidJobItemArchive.discountExclude' => 'DISCOUNT_EXCLUDE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_EXCLUDE' => 'DISCOUNT_EXCLUDE',
        'COL_DISCOUNT_EXCLUDE' => 'DISCOUNT_EXCLUDE',
        'discount_exclude' => 'DISCOUNT_EXCLUDE',
        'sf_opportunity_bid_job_item_archive.discount_exclude' => 'DISCOUNT_EXCLUDE',
        'DiscountAuto' => 'DISCOUNT_AUTO',
        'SfOpportunityBidJobItemArchive.DiscountAuto' => 'DISCOUNT_AUTO',
        'discountAuto' => 'DISCOUNT_AUTO',
        'sfOpportunityBidJobItemArchive.discountAuto' => 'DISCOUNT_AUTO',
        'SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_AUTO' => 'DISCOUNT_AUTO',
        'COL_DISCOUNT_AUTO' => 'DISCOUNT_AUTO',
        'discount_auto' => 'DISCOUNT_AUTO',
        'sf_opportunity_bid_job_item_archive.discount_auto' => 'DISCOUNT_AUTO',
        'PMComment' => 'PM_COMMENT',
        'SfOpportunityBidJobItemArchive.PMComment' => 'PM_COMMENT',
        'pMComment' => 'PM_COMMENT',
        'sfOpportunityBidJobItemArchive.pMComment' => 'PM_COMMENT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_PM_COMMENT' => 'PM_COMMENT',
        'COL_PM_COMMENT' => 'PM_COMMENT',
        'pm_comment' => 'PM_COMMENT',
        'sf_opportunity_bid_job_item_archive.pm_comment' => 'PM_COMMENT',
        'Order' => 'ORDER',
        'SfOpportunityBidJobItemArchive.Order' => 'ORDER',
        'order' => 'ORDER',
        'sfOpportunityBidJobItemArchive.order' => 'ORDER',
        'SfOpportunityBidJobItemArchiveTableMap::COL_ORDER' => 'ORDER',
        'COL_ORDER' => 'ORDER',
        'sf_opportunity_bid_job_item_archive.order' => 'ORDER',
        'Group' => 'GROUP',
        'SfOpportunityBidJobItemArchive.Group' => 'GROUP',
        'group' => 'GROUP',
        'sfOpportunityBidJobItemArchive.group' => 'GROUP',
        'SfOpportunityBidJobItemArchiveTableMap::COL_GROUP' => 'GROUP',
        'COL_GROUP' => 'GROUP',
        'sf_opportunity_bid_job_item_archive.group' => 'GROUP',
        'GroupTitle' => 'GROUP_TITLE',
        'SfOpportunityBidJobItemArchive.GroupTitle' => 'GROUP_TITLE',
        'groupTitle' => 'GROUP_TITLE',
        'sfOpportunityBidJobItemArchive.groupTitle' => 'GROUP_TITLE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_GROUP_TITLE' => 'GROUP_TITLE',
        'COL_GROUP_TITLE' => 'GROUP_TITLE',
        'group_title' => 'GROUP_TITLE',
        'sf_opportunity_bid_job_item_archive.group_title' => 'GROUP_TITLE',
        'SuperGroup' => 'SUPER_GROUP',
        'SfOpportunityBidJobItemArchive.SuperGroup' => 'SUPER_GROUP',
        'superGroup' => 'SUPER_GROUP',
        'sfOpportunityBidJobItemArchive.superGroup' => 'SUPER_GROUP',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP' => 'SUPER_GROUP',
        'COL_SUPER_GROUP' => 'SUPER_GROUP',
        'super_group' => 'SUPER_GROUP',
        'sf_opportunity_bid_job_item_archive.super_group' => 'SUPER_GROUP',
        'SuperGroupTitle' => 'SUPER_GROUP_TITLE',
        'SfOpportunityBidJobItemArchive.SuperGroupTitle' => 'SUPER_GROUP_TITLE',
        'superGroupTitle' => 'SUPER_GROUP_TITLE',
        'sfOpportunityBidJobItemArchive.superGroupTitle' => 'SUPER_GROUP_TITLE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP_TITLE' => 'SUPER_GROUP_TITLE',
        'COL_SUPER_GROUP_TITLE' => 'SUPER_GROUP_TITLE',
        'super_group_title' => 'SUPER_GROUP_TITLE',
        'sf_opportunity_bid_job_item_archive.super_group_title' => 'SUPER_GROUP_TITLE',
        'FirstDiscountPercentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'SfOpportunityBidJobItemArchive.FirstDiscountPercentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'firstDiscountPercentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'sfOpportunityBidJobItemArchive.firstDiscountPercentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_PERCENTAGE' => 'FIRST_DISCOUNT_PERCENTAGE',
        'COL_FIRST_DISCOUNT_PERCENTAGE' => 'FIRST_DISCOUNT_PERCENTAGE',
        'first_discount_percentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'sf_opportunity_bid_job_item_archive.first_discount_percentage' => 'FIRST_DISCOUNT_PERCENTAGE',
        'SecondDiscountPercentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'SfOpportunityBidJobItemArchive.SecondDiscountPercentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'secondDiscountPercentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'sfOpportunityBidJobItemArchive.secondDiscountPercentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_PERCENTAGE' => 'SECOND_DISCOUNT_PERCENTAGE',
        'COL_SECOND_DISCOUNT_PERCENTAGE' => 'SECOND_DISCOUNT_PERCENTAGE',
        'second_discount_percentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'sf_opportunity_bid_job_item_archive.second_discount_percentage' => 'SECOND_DISCOUNT_PERCENTAGE',
        'FirstDiscountSectionId' => 'FIRST_DISCOUNT_SECTION_ID',
        'SfOpportunityBidJobItemArchive.FirstDiscountSectionId' => 'FIRST_DISCOUNT_SECTION_ID',
        'firstDiscountSectionId' => 'FIRST_DISCOUNT_SECTION_ID',
        'sfOpportunityBidJobItemArchive.firstDiscountSectionId' => 'FIRST_DISCOUNT_SECTION_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_SECTION_ID' => 'FIRST_DISCOUNT_SECTION_ID',
        'COL_FIRST_DISCOUNT_SECTION_ID' => 'FIRST_DISCOUNT_SECTION_ID',
        'first_discount_section_id' => 'FIRST_DISCOUNT_SECTION_ID',
        'sf_opportunity_bid_job_item_archive.first_discount_section_id' => 'FIRST_DISCOUNT_SECTION_ID',
        'SecondDiscountSectionId' => 'SECOND_DISCOUNT_SECTION_ID',
        'SfOpportunityBidJobItemArchive.SecondDiscountSectionId' => 'SECOND_DISCOUNT_SECTION_ID',
        'secondDiscountSectionId' => 'SECOND_DISCOUNT_SECTION_ID',
        'sfOpportunityBidJobItemArchive.secondDiscountSectionId' => 'SECOND_DISCOUNT_SECTION_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_SECTION_ID' => 'SECOND_DISCOUNT_SECTION_ID',
        'COL_SECOND_DISCOUNT_SECTION_ID' => 'SECOND_DISCOUNT_SECTION_ID',
        'second_discount_section_id' => 'SECOND_DISCOUNT_SECTION_ID',
        'sf_opportunity_bid_job_item_archive.second_discount_section_id' => 'SECOND_DISCOUNT_SECTION_ID',
        'RespondentTypeId' => 'RESPONDENT_TYPE_ID',
        'SfOpportunityBidJobItemArchive.RespondentTypeId' => 'RESPONDENT_TYPE_ID',
        'respondentTypeId' => 'RESPONDENT_TYPE_ID',
        'sfOpportunityBidJobItemArchive.respondentTypeId' => 'RESPONDENT_TYPE_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_RESPONDENT_TYPE_ID' => 'RESPONDENT_TYPE_ID',
        'COL_RESPONDENT_TYPE_ID' => 'RESPONDENT_TYPE_ID',
        'respondent_type_id' => 'RESPONDENT_TYPE_ID',
        'sf_opportunity_bid_job_item_archive.respondent_type_id' => 'RESPONDENT_TYPE_ID',
        'CreatedById' => 'CREATED_BY_ID',
        'SfOpportunityBidJobItemArchive.CreatedById' => 'CREATED_BY_ID',
        'createdById' => 'CREATED_BY_ID',
        'sfOpportunityBidJobItemArchive.createdById' => 'CREATED_BY_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_BY_ID' => 'CREATED_BY_ID',
        'COL_CREATED_BY_ID' => 'CREATED_BY_ID',
        'created_by_id' => 'CREATED_BY_ID',
        'sf_opportunity_bid_job_item_archive.created_by_id' => 'CREATED_BY_ID',
        'UpdatedById' => 'UPDATED_BY_ID',
        'SfOpportunityBidJobItemArchive.UpdatedById' => 'UPDATED_BY_ID',
        'updatedById' => 'UPDATED_BY_ID',
        'sfOpportunityBidJobItemArchive.updatedById' => 'UPDATED_BY_ID',
        'SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_BY_ID' => 'UPDATED_BY_ID',
        'COL_UPDATED_BY_ID' => 'UPDATED_BY_ID',
        'updated_by_id' => 'UPDATED_BY_ID',
        'sf_opportunity_bid_job_item_archive.updated_by_id' => 'UPDATED_BY_ID',
        'CreatedAt' => 'CREATED_AT',
        'SfOpportunityBidJobItemArchive.CreatedAt' => 'CREATED_AT',
        'createdAt' => 'CREATED_AT',
        'sfOpportunityBidJobItemArchive.createdAt' => 'CREATED_AT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_AT' => 'CREATED_AT',
        'COL_CREATED_AT' => 'CREATED_AT',
        'created_at' => 'CREATED_AT',
        'sf_opportunity_bid_job_item_archive.created_at' => 'CREATED_AT',
        'UpdatedAt' => 'UPDATED_AT',
        'SfOpportunityBidJobItemArchive.UpdatedAt' => 'UPDATED_AT',
        'updatedAt' => 'UPDATED_AT',
        'sfOpportunityBidJobItemArchive.updatedAt' => 'UPDATED_AT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_AT' => 'UPDATED_AT',
        'COL_UPDATED_AT' => 'UPDATED_AT',
        'updated_at' => 'UPDATED_AT',
        'sf_opportunity_bid_job_item_archive.updated_at' => 'UPDATED_AT',
        'ArchivedAt' => 'ARCHIVED_AT',
        'SfOpportunityBidJobItemArchive.ArchivedAt' => 'ARCHIVED_AT',
        'archivedAt' => 'ARCHIVED_AT',
        'sfOpportunityBidJobItemArchive.archivedAt' => 'ARCHIVED_AT',
        'SfOpportunityBidJobItemArchiveTableMap::COL_ARCHIVED_AT' => 'ARCHIVED_AT',
        'COL_ARCHIVED_AT' => 'ARCHIVED_AT',
        'archived_at' => 'ARCHIVED_AT',
        'sf_opportunity_bid_job_item_archive.archived_at' => 'ARCHIVED_AT',
    ];

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('sf_opportunity_bid_job_item_archive');
        $this->setPhpName('SfOpportunityBidJobItemArchive');
        $this->setIdentifierQuoting(true);
        $this->setClassName('\\Model\\SfOpportunityBidJobItemArchive');
        $this->setPackage('src.Model');
        $this->setUseIdGenerator(false);
        // columns
        $this->addPrimaryKey('id', 'Id', 'INTEGER', true, null, null);
        $this->addColumn('bid_job_id', 'BidJobId', 'INTEGER', true, null, null);
        $this->addColumn('event_id', 'EventId', 'INTEGER', false, null, null);
        $this->addColumn('section_id', 'SectionId', 'INTEGER', false, null, null);
        $this->addColumn('title', 'Title', 'VARCHAR', true, 255, null);
        $this->addColumn('vendor_id', 'VendorId', 'INTEGER', false, 10, null);
        $this->addColumn('resp_location_id', 'RespLocationId', 'INTEGER', false, null, null);
        $this->addColumn('methodology_id', 'MethodologyId', 'INTEGER', false, null, null);
        $this->addColumn('date', 'Date', 'DATE', false, null, null);
        $this->addColumn('selling_qty', 'SellingQty', 'DECIMAL', false, 8, null);
        $this->addColumn('selling_unit_price', 'SellingUnitPrice', 'DECIMAL', false, 15, null);
        $this->addColumn('unit', 'Unit', 'DECIMAL', false, 15, null);
        $this->addColumn('selling_price', 'SellingPrice', 'DECIMAL', false, 15, null);
        $this->addColumn('cost_qty', 'CostQty', 'INTEGER', false, null, null);
        $this->addColumn('cost_unit_price', 'CostUnitPrice', 'DECIMAL', false, 15, null);
        $this->addColumn('cost_location_unit_price', 'CostLocationUnitPrice', 'DECIMAL', false, 15, null);
        $this->addColumn('cost_rate', 'CostRate', 'DECIMAL', false, 8, null);
        $this->addColumn('cost_price', 'CostPrice', 'DECIMAL', false, 15, null);
        $this->addColumn('discount_comment', 'DiscountComment', 'LONGVARCHAR', false, null, null);
        $this->addColumn('discount_percent', 'DiscountPercent', 'DECIMAL', false, 8, null);
        $this->addColumn('discount_exclude', 'DiscountExclude', 'BOOLEAN', false, 1, false);
        $this->addColumn('discount_auto', 'DiscountAuto', 'BOOLEAN', false, 1, false);
        $this->addColumn('pm_comment', 'PMComment', 'LONGVARCHAR', false, null, null);
        $this->addColumn('order', 'Order', 'INTEGER', true, null, null);
        $this->addColumn('group', 'Group', 'INTEGER', false, null, 0);
        $this->addColumn('group_title', 'GroupTitle', 'VARCHAR', false, 50, null);
        $this->addColumn('super_group', 'SuperGroup', 'INTEGER', false, null, 0);
        $this->addColumn('super_group_title', 'SuperGroupTitle', 'VARCHAR', false, 50, null);
        $this->addColumn('first_discount_percentage', 'FirstDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('second_discount_percentage', 'SecondDiscountPercentage', 'DECIMAL', false, 4, null);
        $this->addColumn('first_discount_section_id', 'FirstDiscountSectionId', 'INTEGER', false, null, null);
        $this->addColumn('second_discount_section_id', 'SecondDiscountSectionId', 'INTEGER', false, null, null);
        $this->addColumn('respondent_type_id', 'RespondentTypeId', 'INTEGER', false, null, null);
        $this->addColumn('created_by_id', 'CreatedById', 'INTEGER', false, null, null);
        $this->addColumn('updated_by_id', 'UpdatedById', 'INTEGER', false, null, null);
        $this->addColumn('created_at', 'CreatedAt', 'TIMESTAMP', false, null, null);
        $this->addColumn('updated_at', 'UpdatedAt', 'TIMESTAMP', false, null, null);
        $this->addColumn('archived_at', 'ArchivedAt', 'TIMESTAMP', false, null, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
    } // buildRelations()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return null === $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] || is_scalar($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)]) || is_callable([$row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)], '__toString']) ? (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] : $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }

    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? SfOpportunityBidJobItemArchiveTableMap::CLASS_DEFAULT : SfOpportunityBidJobItemArchiveTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (SfOpportunityBidJobItemArchive object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = SfOpportunityBidJobItemArchiveTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = SfOpportunityBidJobItemArchiveTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + SfOpportunityBidJobItemArchiveTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = SfOpportunityBidJobItemArchiveTableMap::OM_CLASS;
            /** @var SfOpportunityBidJobItemArchive $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            SfOpportunityBidJobItemArchiveTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = SfOpportunityBidJobItemArchiveTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = SfOpportunityBidJobItemArchiveTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var SfOpportunityBidJobItemArchive $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                SfOpportunityBidJobItemArchiveTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_BID_JOB_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_EVENT_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECTION_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_TITLE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_VENDOR_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_RESP_LOCATION_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_METHODOLOGY_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DATE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_QTY);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_UNIT_PRICE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UNIT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_PRICE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_QTY);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_UNIT_PRICE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_LOCATION_UNIT_PRICE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_RATE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_PRICE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_COMMENT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_PERCENT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_EXCLUDE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_AUTO);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_PM_COMMENT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ORDER);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_GROUP);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_GROUP_TITLE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP_TITLE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_PERCENTAGE);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_SECTION_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_SECTION_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_RESPONDENT_TYPE_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_BY_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_BY_ID);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_AT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_AT);
            $criteria->addSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ARCHIVED_AT);
        } else {
            $criteria->addSelectColumn($alias . '.id');
            $criteria->addSelectColumn($alias . '.bid_job_id');
            $criteria->addSelectColumn($alias . '.event_id');
            $criteria->addSelectColumn($alias . '.section_id');
            $criteria->addSelectColumn($alias . '.title');
            $criteria->addSelectColumn($alias . '.vendor_id');
            $criteria->addSelectColumn($alias . '.resp_location_id');
            $criteria->addSelectColumn($alias . '.methodology_id');
            $criteria->addSelectColumn($alias . '.date');
            $criteria->addSelectColumn($alias . '.selling_qty');
            $criteria->addSelectColumn($alias . '.selling_unit_price');
            $criteria->addSelectColumn($alias . '.unit');
            $criteria->addSelectColumn($alias . '.selling_price');
            $criteria->addSelectColumn($alias . '.cost_qty');
            $criteria->addSelectColumn($alias . '.cost_unit_price');
            $criteria->addSelectColumn($alias . '.cost_location_unit_price');
            $criteria->addSelectColumn($alias . '.cost_rate');
            $criteria->addSelectColumn($alias . '.cost_price');
            $criteria->addSelectColumn($alias . '.discount_comment');
            $criteria->addSelectColumn($alias . '.discount_percent');
            $criteria->addSelectColumn($alias . '.discount_exclude');
            $criteria->addSelectColumn($alias . '.discount_auto');
            $criteria->addSelectColumn($alias . '.pm_comment');
            $criteria->addSelectColumn($alias . '.order');
            $criteria->addSelectColumn($alias . '.group');
            $criteria->addSelectColumn($alias . '.group_title');
            $criteria->addSelectColumn($alias . '.super_group');
            $criteria->addSelectColumn($alias . '.super_group_title');
            $criteria->addSelectColumn($alias . '.first_discount_percentage');
            $criteria->addSelectColumn($alias . '.second_discount_percentage');
            $criteria->addSelectColumn($alias . '.first_discount_section_id');
            $criteria->addSelectColumn($alias . '.second_discount_section_id');
            $criteria->addSelectColumn($alias . '.respondent_type_id');
            $criteria->addSelectColumn($alias . '.created_by_id');
            $criteria->addSelectColumn($alias . '.updated_by_id');
            $criteria->addSelectColumn($alias . '.created_at');
            $criteria->addSelectColumn($alias . '.updated_at');
            $criteria->addSelectColumn($alias . '.archived_at');
        }
    }

    /**
     * Remove all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be removed as they are only loaded on demand.
     *
     * @param Criteria $criteria object containing the columns to remove.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function removeSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_BID_JOB_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_EVENT_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECTION_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_TITLE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_VENDOR_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_RESP_LOCATION_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_METHODOLOGY_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DATE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_QTY);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_UNIT_PRICE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UNIT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SELLING_PRICE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_QTY);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_UNIT_PRICE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_LOCATION_UNIT_PRICE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_RATE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_COST_PRICE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_COMMENT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_PERCENT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_EXCLUDE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_DISCOUNT_AUTO);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_PM_COMMENT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ORDER);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_GROUP);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_GROUP_TITLE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SUPER_GROUP_TITLE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_PERCENTAGE);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_FIRST_DISCOUNT_SECTION_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_SECOND_DISCOUNT_SECTION_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_RESPONDENT_TYPE_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_BY_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_BY_ID);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_CREATED_AT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_UPDATED_AT);
            $criteria->removeSelectColumn(SfOpportunityBidJobItemArchiveTableMap::COL_ARCHIVED_AT);
        } else {
            $criteria->removeSelectColumn($alias . '.id');
            $criteria->removeSelectColumn($alias . '.bid_job_id');
            $criteria->removeSelectColumn($alias . '.event_id');
            $criteria->removeSelectColumn($alias . '.section_id');
            $criteria->removeSelectColumn($alias . '.title');
            $criteria->removeSelectColumn($alias . '.vendor_id');
            $criteria->removeSelectColumn($alias . '.resp_location_id');
            $criteria->removeSelectColumn($alias . '.methodology_id');
            $criteria->removeSelectColumn($alias . '.date');
            $criteria->removeSelectColumn($alias . '.selling_qty');
            $criteria->removeSelectColumn($alias . '.selling_unit_price');
            $criteria->removeSelectColumn($alias . '.unit');
            $criteria->removeSelectColumn($alias . '.selling_price');
            $criteria->removeSelectColumn($alias . '.cost_qty');
            $criteria->removeSelectColumn($alias . '.cost_unit_price');
            $criteria->removeSelectColumn($alias . '.cost_location_unit_price');
            $criteria->removeSelectColumn($alias . '.cost_rate');
            $criteria->removeSelectColumn($alias . '.cost_price');
            $criteria->removeSelectColumn($alias . '.discount_comment');
            $criteria->removeSelectColumn($alias . '.discount_percent');
            $criteria->removeSelectColumn($alias . '.discount_exclude');
            $criteria->removeSelectColumn($alias . '.discount_auto');
            $criteria->removeSelectColumn($alias . '.pm_comment');
            $criteria->removeSelectColumn($alias . '.order');
            $criteria->removeSelectColumn($alias . '.group');
            $criteria->removeSelectColumn($alias . '.group_title');
            $criteria->removeSelectColumn($alias . '.super_group');
            $criteria->removeSelectColumn($alias . '.super_group_title');
            $criteria->removeSelectColumn($alias . '.first_discount_percentage');
            $criteria->removeSelectColumn($alias . '.second_discount_percentage');
            $criteria->removeSelectColumn($alias . '.first_discount_section_id');
            $criteria->removeSelectColumn($alias . '.second_discount_section_id');
            $criteria->removeSelectColumn($alias . '.respondent_type_id');
            $criteria->removeSelectColumn($alias . '.created_by_id');
            $criteria->removeSelectColumn($alias . '.updated_by_id');
            $criteria->removeSelectColumn($alias . '.created_at');
            $criteria->removeSelectColumn($alias . '.updated_at');
            $criteria->removeSelectColumn($alias . '.archived_at');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(SfOpportunityBidJobItemArchiveTableMap::DATABASE_NAME)->getTable(SfOpportunityBidJobItemArchiveTableMap::TABLE_NAME);
    }

    /**
     * Performs a DELETE on the database, given a SfOpportunityBidJobItemArchive or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or SfOpportunityBidJobItemArchive object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(SfOpportunityBidJobItemArchiveTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \Model\SfOpportunityBidJobItemArchive) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(SfOpportunityBidJobItemArchiveTableMap::DATABASE_NAME);
            $criteria->add(SfOpportunityBidJobItemArchiveTableMap::COL_ID, (array) $values, Criteria::IN);
        }

        $query = SfOpportunityBidJobItemArchiveQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            SfOpportunityBidJobItemArchiveTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                SfOpportunityBidJobItemArchiveTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the sf_opportunity_bid_job_item_archive table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return SfOpportunityBidJobItemArchiveQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a SfOpportunityBidJobItemArchive or Criteria object.
     *
     * @param mixed               $criteria Criteria or SfOpportunityBidJobItemArchive object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(SfOpportunityBidJobItemArchiveTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from SfOpportunityBidJobItemArchive object
        }


        // Set the correct dbName
        $query = SfOpportunityBidJobItemArchiveQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // SfOpportunityBidJobItemArchiveTableMap
