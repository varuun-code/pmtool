<?php

namespace Model\Map;

use Model\Event;
use Model\EventQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'event' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 */
class EventTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'src.Model.Map.EventTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'default';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'event';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\Model\\Event';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'src.Model.Event';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 46;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 46;

    /**
     * the column name for the id field
     */
    const COL_ID = 'event.id';

    /**
     * the column name for the sams_event_id field
     */
    const COL_SAMS_EVENT_ID = 'event.sams_event_id';

    /**
     * the column name for the job_id field
     */
    const COL_JOB_ID = 'event.job_id';

    /**
     * the column name for the bid_job_id field
     */
    const COL_BID_JOB_ID = 'event.bid_job_id';

    /**
     * the column name for the bid_job_archive_id field
     */
    const COL_BID_JOB_ARCHIVE_ID = 'event.bid_job_archive_id';

    /**
     * the column name for the ref_room_id field
     */
    const COL_REF_ROOM_ID = 'event.ref_room_id';

    /**
     * the column name for the ref_time_slot_id field
     */
    const COL_REF_TIME_SLOT_ID = 'event.ref_time_slot_id';

    /**
     * the column name for the event_status_id field
     */
    const COL_EVENT_STATUS_ID = 'event.event_status_id';

    /**
     * the column name for the date field
     */
    const COL_DATE = 'event.date';

    /**
     * the column name for the confirmed_date field
     */
    const COL_CONFIRMED_DATE = 'event.confirmed_date';

    /**
     * the column name for the active_date field
     */
    const COL_ACTIVE_DATE = 'event.active_date';

    /**
     * the column name for the event_methodology_id field
     */
    const COL_EVENT_METHODOLOGY_ID = 'event.event_methodology_id';

    /**
     * the column name for the status field
     */
    const COL_STATUS = 'event.status';

    /**
     * the column name for the comments field
     */
    const COL_COMMENTS = 'event.comments';

    /**
     * the column name for the facility_note field
     */
    const COL_FACILITY_NOTE = 'event.facility_note';

    /**
     * the column name for the site_id field
     */
    const COL_SITE_ID = 'event.site_id';

    /**
     * the column name for the account_id field
     */
    const COL_ACCOUNT_ID = 'event.account_id';

    /**
     * the column name for the account_sf_id field
     */
    const COL_ACCOUNT_SF_ID = 'event.account_sf_id';

    /**
     * the column name for the activity_currency field
     */
    const COL_ACTIVITY_CURRENCY = 'event.activity_currency';

    /**
     * the column name for the all_day_event field
     */
    const COL_ALL_DAY_EVENT = 'event.all_day_event';

    /**
     * the column name for the archived field
     */
    const COL_ARCHIVED = 'event.archived';

    /**
     * the column name for the assigned_to_id field
     */
    const COL_ASSIGNED_TO_ID = 'event.assigned_to_id';

    /**
     * the column name for the cancelled field
     */
    const COL_CANCELLED = 'event.cancelled';

    /**
     * the column name for the recurring_event field
     */
    const COL_RECURRING_EVENT = 'event.recurring_event';

    /**
     * the column name for the is_deleted field
     */
    const COL_IS_DELETED = 'event.is_deleted';

    /**
     * the column name for the is_deleted_c field
     */
    const COL_IS_DELETED_C = 'event.is_deleted_c';

    /**
     * the column name for the description field
     */
    const COL_DESCRIPTION = 'event.description';

    /**
     * the column name for the duration_minutes field
     */
    const COL_DURATION_MINUTES = 'event.duration_minutes';

    /**
     * the column name for the end_date_time field
     */
    const COL_END_DATE_TIME = 'event.end_date_time';

    /**
     * the column name for the record_type_id field
     */
    const COL_RECORD_TYPE_ID = 'event.record_type_id';

    /**
     * the column name for the event_sub_type_id field
     */
    const COL_EVENT_SUB_TYPE_ID = 'event.event_sub_type_id';

    /**
     * the column name for the job_status field
     */
    const COL_JOB_STATUS = 'event.job_status';

    /**
     * the column name for the location_c field
     */
    const COL_LOCATION_C = 'event.location_c';

    /**
     * the column name for the reminder_date field
     */
    const COL_REMINDER_DATE = 'event.reminder_date';

    /**
     * the column name for the reminder_set field
     */
    const COL_REMINDER_SET = 'event.reminder_set';

    /**
     * the column name for the start_date_time field
     */
    const COL_START_DATE_TIME = 'event.start_date_time';

    /**
     * the column name for the subject field
     */
    const COL_SUBJECT = 'event.subject';

    /**
     * the column name for the recurrence_time_zone field
     */
    const COL_RECURRENCE_TIME_ZONE = 'event.recurrence_time_zone';

    /**
     * the column name for the created_by_sf_id field
     */
    const COL_CREATED_BY_SF_ID = 'event.created_by_sf_id';

    /**
     * the column name for the pmtool_updated field
     */
    const COL_PMTOOL_UPDATED = 'event.pmtool_updated';

    /**
     * the column name for the event_holder_id field
     */
    const COL_EVENT_HOLDER_ID = 'event.event_holder_id';

    /**
     * the column name for the api_created_date field
     */
    const COL_API_CREATED_DATE = 'event.api_created_date';

    /**
     * the column name for the api_updated_date field
     */
    const COL_API_UPDATED_DATE = 'event.api_updated_date';

    /**
     * the column name for the is_group field
     */
    const COL_IS_GROUP = 'event.is_group';

    /**
     * the column name for the created_date field
     */
    const COL_CREATED_DATE = 'event.created_date';

    /**
     * the column name for the updated_date field
     */
    const COL_UPDATED_DATE = 'event.updated_date';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /** The enumerated values for the status field */
    const COL_STATUS_ACTIVE = 'active';
    const COL_STATUS_CANCELLED = 'cancelled';
    const COL_STATUS_DELETED = 'deleted';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Id', 'SamsEventId', 'JobId', 'BidJobId', 'BidJobArchiveId', 'RefRoomId', 'RefTimeSlotId', 'EventStatusId', 'Date', 'ConfirmedDate', 'ActiveDate', 'EventMethodologyId', 'Status', 'Comments', 'FacilityNote', 'SiteId', 'AccountId', 'AccountSfId', 'ActivityCurrency', 'AllDayEvent', 'Archived', 'AssignedToId', 'Cancelled', 'RecurringEvent', 'IsDeleted', 'IsDeletedC', 'Description', 'DurationMinutes', 'EndDateTime', 'RecordTypeId', 'EventSubTypeId', 'JobStatus', 'LocationC', 'ReminderDate', 'ReminderSet', 'StartDateTime', 'Subject', 'RecurrenceTimeZone', 'CreatedBySfId', 'PmtoolUpdated', 'EventHolderId', 'ApiCreatedDate', 'ApiUpdatedDate', 'IsGroup', 'CreatedDate', 'UpdatedDate', ),
        self::TYPE_CAMELNAME     => array('id', 'samsEventId', 'jobId', 'bidJobId', 'bidJobArchiveId', 'refRoomId', 'refTimeSlotId', 'eventStatusId', 'date', 'confirmedDate', 'activeDate', 'eventMethodologyId', 'status', 'comments', 'facilityNote', 'siteId', 'accountId', 'accountSfId', 'activityCurrency', 'allDayEvent', 'archived', 'assignedToId', 'cancelled', 'recurringEvent', 'isDeleted', 'isDeletedC', 'description', 'durationMinutes', 'endDateTime', 'recordTypeId', 'eventSubTypeId', 'jobStatus', 'locationC', 'reminderDate', 'reminderSet', 'startDateTime', 'subject', 'recurrenceTimeZone', 'createdBySfId', 'pmtoolUpdated', 'eventHolderId', 'apiCreatedDate', 'apiUpdatedDate', 'isGroup', 'createdDate', 'updatedDate', ),
        self::TYPE_COLNAME       => array(EventTableMap::COL_ID, EventTableMap::COL_SAMS_EVENT_ID, EventTableMap::COL_JOB_ID, EventTableMap::COL_BID_JOB_ID, EventTableMap::COL_BID_JOB_ARCHIVE_ID, EventTableMap::COL_REF_ROOM_ID, EventTableMap::COL_REF_TIME_SLOT_ID, EventTableMap::COL_EVENT_STATUS_ID, EventTableMap::COL_DATE, EventTableMap::COL_CONFIRMED_DATE, EventTableMap::COL_ACTIVE_DATE, EventTableMap::COL_EVENT_METHODOLOGY_ID, EventTableMap::COL_STATUS, EventTableMap::COL_COMMENTS, EventTableMap::COL_FACILITY_NOTE, EventTableMap::COL_SITE_ID, EventTableMap::COL_ACCOUNT_ID, EventTableMap::COL_ACCOUNT_SF_ID, EventTableMap::COL_ACTIVITY_CURRENCY, EventTableMap::COL_ALL_DAY_EVENT, EventTableMap::COL_ARCHIVED, EventTableMap::COL_ASSIGNED_TO_ID, EventTableMap::COL_CANCELLED, EventTableMap::COL_RECURRING_EVENT, EventTableMap::COL_IS_DELETED, EventTableMap::COL_IS_DELETED_C, EventTableMap::COL_DESCRIPTION, EventTableMap::COL_DURATION_MINUTES, EventTableMap::COL_END_DATE_TIME, EventTableMap::COL_RECORD_TYPE_ID, EventTableMap::COL_EVENT_SUB_TYPE_ID, EventTableMap::COL_JOB_STATUS, EventTableMap::COL_LOCATION_C, EventTableMap::COL_REMINDER_DATE, EventTableMap::COL_REMINDER_SET, EventTableMap::COL_START_DATE_TIME, EventTableMap::COL_SUBJECT, EventTableMap::COL_RECURRENCE_TIME_ZONE, EventTableMap::COL_CREATED_BY_SF_ID, EventTableMap::COL_PMTOOL_UPDATED, EventTableMap::COL_EVENT_HOLDER_ID, EventTableMap::COL_API_CREATED_DATE, EventTableMap::COL_API_UPDATED_DATE, EventTableMap::COL_IS_GROUP, EventTableMap::COL_CREATED_DATE, EventTableMap::COL_UPDATED_DATE, ),
        self::TYPE_FIELDNAME     => array('id', 'sams_event_id', 'job_id', 'bid_job_id', 'bid_job_archive_id', 'ref_room_id', 'ref_time_slot_id', 'event_status_id', 'date', 'confirmed_date', 'active_date', 'event_methodology_id', 'status', 'comments', 'facility_note', 'site_id', 'account_id', 'account_sf_id', 'activity_currency', 'all_day_event', 'archived', 'assigned_to_id', 'cancelled', 'recurring_event', 'is_deleted', 'is_deleted_c', 'description', 'duration_minutes', 'end_date_time', 'record_type_id', 'event_sub_type_id', 'job_status', 'location_c', 'reminder_date', 'reminder_set', 'start_date_time', 'subject', 'recurrence_time_zone', 'created_by_sf_id', 'pmtool_updated', 'event_holder_id', 'api_created_date', 'api_updated_date', 'is_group', 'created_date', 'updated_date', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Id' => 0, 'SamsEventId' => 1, 'JobId' => 2, 'BidJobId' => 3, 'BidJobArchiveId' => 4, 'RefRoomId' => 5, 'RefTimeSlotId' => 6, 'EventStatusId' => 7, 'Date' => 8, 'ConfirmedDate' => 9, 'ActiveDate' => 10, 'EventMethodologyId' => 11, 'Status' => 12, 'Comments' => 13, 'FacilityNote' => 14, 'SiteId' => 15, 'AccountId' => 16, 'AccountSfId' => 17, 'ActivityCurrency' => 18, 'AllDayEvent' => 19, 'Archived' => 20, 'AssignedToId' => 21, 'Cancelled' => 22, 'RecurringEvent' => 23, 'IsDeleted' => 24, 'IsDeletedC' => 25, 'Description' => 26, 'DurationMinutes' => 27, 'EndDateTime' => 28, 'RecordTypeId' => 29, 'EventSubTypeId' => 30, 'JobStatus' => 31, 'LocationC' => 32, 'ReminderDate' => 33, 'ReminderSet' => 34, 'StartDateTime' => 35, 'Subject' => 36, 'RecurrenceTimeZone' => 37, 'CreatedBySfId' => 38, 'PmtoolUpdated' => 39, 'EventHolderId' => 40, 'ApiCreatedDate' => 41, 'ApiUpdatedDate' => 42, 'IsGroup' => 43, 'CreatedDate' => 44, 'UpdatedDate' => 45, ),
        self::TYPE_CAMELNAME     => array('id' => 0, 'samsEventId' => 1, 'jobId' => 2, 'bidJobId' => 3, 'bidJobArchiveId' => 4, 'refRoomId' => 5, 'refTimeSlotId' => 6, 'eventStatusId' => 7, 'date' => 8, 'confirmedDate' => 9, 'activeDate' => 10, 'eventMethodologyId' => 11, 'status' => 12, 'comments' => 13, 'facilityNote' => 14, 'siteId' => 15, 'accountId' => 16, 'accountSfId' => 17, 'activityCurrency' => 18, 'allDayEvent' => 19, 'archived' => 20, 'assignedToId' => 21, 'cancelled' => 22, 'recurringEvent' => 23, 'isDeleted' => 24, 'isDeletedC' => 25, 'description' => 26, 'durationMinutes' => 27, 'endDateTime' => 28, 'recordTypeId' => 29, 'eventSubTypeId' => 30, 'jobStatus' => 31, 'locationC' => 32, 'reminderDate' => 33, 'reminderSet' => 34, 'startDateTime' => 35, 'subject' => 36, 'recurrenceTimeZone' => 37, 'createdBySfId' => 38, 'pmtoolUpdated' => 39, 'eventHolderId' => 40, 'apiCreatedDate' => 41, 'apiUpdatedDate' => 42, 'isGroup' => 43, 'createdDate' => 44, 'updatedDate' => 45, ),
        self::TYPE_COLNAME       => array(EventTableMap::COL_ID => 0, EventTableMap::COL_SAMS_EVENT_ID => 1, EventTableMap::COL_JOB_ID => 2, EventTableMap::COL_BID_JOB_ID => 3, EventTableMap::COL_BID_JOB_ARCHIVE_ID => 4, EventTableMap::COL_REF_ROOM_ID => 5, EventTableMap::COL_REF_TIME_SLOT_ID => 6, EventTableMap::COL_EVENT_STATUS_ID => 7, EventTableMap::COL_DATE => 8, EventTableMap::COL_CONFIRMED_DATE => 9, EventTableMap::COL_ACTIVE_DATE => 10, EventTableMap::COL_EVENT_METHODOLOGY_ID => 11, EventTableMap::COL_STATUS => 12, EventTableMap::COL_COMMENTS => 13, EventTableMap::COL_FACILITY_NOTE => 14, EventTableMap::COL_SITE_ID => 15, EventTableMap::COL_ACCOUNT_ID => 16, EventTableMap::COL_ACCOUNT_SF_ID => 17, EventTableMap::COL_ACTIVITY_CURRENCY => 18, EventTableMap::COL_ALL_DAY_EVENT => 19, EventTableMap::COL_ARCHIVED => 20, EventTableMap::COL_ASSIGNED_TO_ID => 21, EventTableMap::COL_CANCELLED => 22, EventTableMap::COL_RECURRING_EVENT => 23, EventTableMap::COL_IS_DELETED => 24, EventTableMap::COL_IS_DELETED_C => 25, EventTableMap::COL_DESCRIPTION => 26, EventTableMap::COL_DURATION_MINUTES => 27, EventTableMap::COL_END_DATE_TIME => 28, EventTableMap::COL_RECORD_TYPE_ID => 29, EventTableMap::COL_EVENT_SUB_TYPE_ID => 30, EventTableMap::COL_JOB_STATUS => 31, EventTableMap::COL_LOCATION_C => 32, EventTableMap::COL_REMINDER_DATE => 33, EventTableMap::COL_REMINDER_SET => 34, EventTableMap::COL_START_DATE_TIME => 35, EventTableMap::COL_SUBJECT => 36, EventTableMap::COL_RECURRENCE_TIME_ZONE => 37, EventTableMap::COL_CREATED_BY_SF_ID => 38, EventTableMap::COL_PMTOOL_UPDATED => 39, EventTableMap::COL_EVENT_HOLDER_ID => 40, EventTableMap::COL_API_CREATED_DATE => 41, EventTableMap::COL_API_UPDATED_DATE => 42, EventTableMap::COL_IS_GROUP => 43, EventTableMap::COL_CREATED_DATE => 44, EventTableMap::COL_UPDATED_DATE => 45, ),
        self::TYPE_FIELDNAME     => array('id' => 0, 'sams_event_id' => 1, 'job_id' => 2, 'bid_job_id' => 3, 'bid_job_archive_id' => 4, 'ref_room_id' => 5, 'ref_time_slot_id' => 6, 'event_status_id' => 7, 'date' => 8, 'confirmed_date' => 9, 'active_date' => 10, 'event_methodology_id' => 11, 'status' => 12, 'comments' => 13, 'facility_note' => 14, 'site_id' => 15, 'account_id' => 16, 'account_sf_id' => 17, 'activity_currency' => 18, 'all_day_event' => 19, 'archived' => 20, 'assigned_to_id' => 21, 'cancelled' => 22, 'recurring_event' => 23, 'is_deleted' => 24, 'is_deleted_c' => 25, 'description' => 26, 'duration_minutes' => 27, 'end_date_time' => 28, 'record_type_id' => 29, 'event_sub_type_id' => 30, 'job_status' => 31, 'location_c' => 32, 'reminder_date' => 33, 'reminder_set' => 34, 'start_date_time' => 35, 'subject' => 36, 'recurrence_time_zone' => 37, 'created_by_sf_id' => 38, 'pmtool_updated' => 39, 'event_holder_id' => 40, 'api_created_date' => 41, 'api_updated_date' => 42, 'is_group' => 43, 'created_date' => 44, 'updated_date' => 45, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, )
    );

    /**
     * Holds a list of column names and their normalized version.
     *
     * @var string[]
     */
    protected $normalizedColumnNameMap = [
        'Id' => 'ID',
        'Event.Id' => 'ID',
        'id' => 'ID',
        'event.id' => 'ID',
        'EventTableMap::COL_ID' => 'ID',
        'COL_ID' => 'ID',
        'SamsEventId' => 'SAMS_EVENT_ID',
        'Event.SamsEventId' => 'SAMS_EVENT_ID',
        'samsEventId' => 'SAMS_EVENT_ID',
        'event.samsEventId' => 'SAMS_EVENT_ID',
        'EventTableMap::COL_SAMS_EVENT_ID' => 'SAMS_EVENT_ID',
        'COL_SAMS_EVENT_ID' => 'SAMS_EVENT_ID',
        'sams_event_id' => 'SAMS_EVENT_ID',
        'event.sams_event_id' => 'SAMS_EVENT_ID',
        'JobId' => 'JOB_ID',
        'Event.JobId' => 'JOB_ID',
        'jobId' => 'JOB_ID',
        'event.jobId' => 'JOB_ID',
        'EventTableMap::COL_JOB_ID' => 'JOB_ID',
        'COL_JOB_ID' => 'JOB_ID',
        'job_id' => 'JOB_ID',
        'event.job_id' => 'JOB_ID',
        'BidJobId' => 'BID_JOB_ID',
        'Event.BidJobId' => 'BID_JOB_ID',
        'bidJobId' => 'BID_JOB_ID',
        'event.bidJobId' => 'BID_JOB_ID',
        'EventTableMap::COL_BID_JOB_ID' => 'BID_JOB_ID',
        'COL_BID_JOB_ID' => 'BID_JOB_ID',
        'bid_job_id' => 'BID_JOB_ID',
        'event.bid_job_id' => 'BID_JOB_ID',
        'BidJobArchiveId' => 'BID_JOB_ARCHIVE_ID',
        'Event.BidJobArchiveId' => 'BID_JOB_ARCHIVE_ID',
        'bidJobArchiveId' => 'BID_JOB_ARCHIVE_ID',
        'event.bidJobArchiveId' => 'BID_JOB_ARCHIVE_ID',
        'EventTableMap::COL_BID_JOB_ARCHIVE_ID' => 'BID_JOB_ARCHIVE_ID',
        'COL_BID_JOB_ARCHIVE_ID' => 'BID_JOB_ARCHIVE_ID',
        'bid_job_archive_id' => 'BID_JOB_ARCHIVE_ID',
        'event.bid_job_archive_id' => 'BID_JOB_ARCHIVE_ID',
        'RefRoomId' => 'REF_ROOM_ID',
        'Event.RefRoomId' => 'REF_ROOM_ID',
        'refRoomId' => 'REF_ROOM_ID',
        'event.refRoomId' => 'REF_ROOM_ID',
        'EventTableMap::COL_REF_ROOM_ID' => 'REF_ROOM_ID',
        'COL_REF_ROOM_ID' => 'REF_ROOM_ID',
        'ref_room_id' => 'REF_ROOM_ID',
        'event.ref_room_id' => 'REF_ROOM_ID',
        'RefTimeSlotId' => 'REF_TIME_SLOT_ID',
        'Event.RefTimeSlotId' => 'REF_TIME_SLOT_ID',
        'refTimeSlotId' => 'REF_TIME_SLOT_ID',
        'event.refTimeSlotId' => 'REF_TIME_SLOT_ID',
        'EventTableMap::COL_REF_TIME_SLOT_ID' => 'REF_TIME_SLOT_ID',
        'COL_REF_TIME_SLOT_ID' => 'REF_TIME_SLOT_ID',
        'ref_time_slot_id' => 'REF_TIME_SLOT_ID',
        'event.ref_time_slot_id' => 'REF_TIME_SLOT_ID',
        'EventStatusId' => 'EVENT_STATUS_ID',
        'Event.EventStatusId' => 'EVENT_STATUS_ID',
        'eventStatusId' => 'EVENT_STATUS_ID',
        'event.eventStatusId' => 'EVENT_STATUS_ID',
        'EventTableMap::COL_EVENT_STATUS_ID' => 'EVENT_STATUS_ID',
        'COL_EVENT_STATUS_ID' => 'EVENT_STATUS_ID',
        'event_status_id' => 'EVENT_STATUS_ID',
        'event.event_status_id' => 'EVENT_STATUS_ID',
        'Date' => 'DATE',
        'Event.Date' => 'DATE',
        'date' => 'DATE',
        'event.date' => 'DATE',
        'EventTableMap::COL_DATE' => 'DATE',
        'COL_DATE' => 'DATE',
        'ConfirmedDate' => 'CONFIRMED_DATE',
        'Event.ConfirmedDate' => 'CONFIRMED_DATE',
        'confirmedDate' => 'CONFIRMED_DATE',
        'event.confirmedDate' => 'CONFIRMED_DATE',
        'EventTableMap::COL_CONFIRMED_DATE' => 'CONFIRMED_DATE',
        'COL_CONFIRMED_DATE' => 'CONFIRMED_DATE',
        'confirmed_date' => 'CONFIRMED_DATE',
        'event.confirmed_date' => 'CONFIRMED_DATE',
        'ActiveDate' => 'ACTIVE_DATE',
        'Event.ActiveDate' => 'ACTIVE_DATE',
        'activeDate' => 'ACTIVE_DATE',
        'event.activeDate' => 'ACTIVE_DATE',
        'EventTableMap::COL_ACTIVE_DATE' => 'ACTIVE_DATE',
        'COL_ACTIVE_DATE' => 'ACTIVE_DATE',
        'active_date' => 'ACTIVE_DATE',
        'event.active_date' => 'ACTIVE_DATE',
        'EventMethodologyId' => 'EVENT_METHODOLOGY_ID',
        'Event.EventMethodologyId' => 'EVENT_METHODOLOGY_ID',
        'eventMethodologyId' => 'EVENT_METHODOLOGY_ID',
        'event.eventMethodologyId' => 'EVENT_METHODOLOGY_ID',
        'EventTableMap::COL_EVENT_METHODOLOGY_ID' => 'EVENT_METHODOLOGY_ID',
        'COL_EVENT_METHODOLOGY_ID' => 'EVENT_METHODOLOGY_ID',
        'event_methodology_id' => 'EVENT_METHODOLOGY_ID',
        'event.event_methodology_id' => 'EVENT_METHODOLOGY_ID',
        'Status' => 'STATUS',
        'Event.Status' => 'STATUS',
        'status' => 'STATUS',
        'event.status' => 'STATUS',
        'EventTableMap::COL_STATUS' => 'STATUS',
        'COL_STATUS' => 'STATUS',
        'Comments' => 'COMMENTS',
        'Event.Comments' => 'COMMENTS',
        'comments' => 'COMMENTS',
        'event.comments' => 'COMMENTS',
        'EventTableMap::COL_COMMENTS' => 'COMMENTS',
        'COL_COMMENTS' => 'COMMENTS',
        'FacilityNote' => 'FACILITY_NOTE',
        'Event.FacilityNote' => 'FACILITY_NOTE',
        'facilityNote' => 'FACILITY_NOTE',
        'event.facilityNote' => 'FACILITY_NOTE',
        'EventTableMap::COL_FACILITY_NOTE' => 'FACILITY_NOTE',
        'COL_FACILITY_NOTE' => 'FACILITY_NOTE',
        'facility_note' => 'FACILITY_NOTE',
        'event.facility_note' => 'FACILITY_NOTE',
        'SiteId' => 'SITE_ID',
        'Event.SiteId' => 'SITE_ID',
        'siteId' => 'SITE_ID',
        'event.siteId' => 'SITE_ID',
        'EventTableMap::COL_SITE_ID' => 'SITE_ID',
        'COL_SITE_ID' => 'SITE_ID',
        'site_id' => 'SITE_ID',
        'event.site_id' => 'SITE_ID',
        'AccountId' => 'ACCOUNT_ID',
        'Event.AccountId' => 'ACCOUNT_ID',
        'accountId' => 'ACCOUNT_ID',
        'event.accountId' => 'ACCOUNT_ID',
        'EventTableMap::COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'account_id' => 'ACCOUNT_ID',
        'event.account_id' => 'ACCOUNT_ID',
        'AccountSfId' => 'ACCOUNT_SF_ID',
        'Event.AccountSfId' => 'ACCOUNT_SF_ID',
        'accountSfId' => 'ACCOUNT_SF_ID',
        'event.accountSfId' => 'ACCOUNT_SF_ID',
        'EventTableMap::COL_ACCOUNT_SF_ID' => 'ACCOUNT_SF_ID',
        'COL_ACCOUNT_SF_ID' => 'ACCOUNT_SF_ID',
        'account_sf_id' => 'ACCOUNT_SF_ID',
        'event.account_sf_id' => 'ACCOUNT_SF_ID',
        'ActivityCurrency' => 'ACTIVITY_CURRENCY',
        'Event.ActivityCurrency' => 'ACTIVITY_CURRENCY',
        'activityCurrency' => 'ACTIVITY_CURRENCY',
        'event.activityCurrency' => 'ACTIVITY_CURRENCY',
        'EventTableMap::COL_ACTIVITY_CURRENCY' => 'ACTIVITY_CURRENCY',
        'COL_ACTIVITY_CURRENCY' => 'ACTIVITY_CURRENCY',
        'activity_currency' => 'ACTIVITY_CURRENCY',
        'event.activity_currency' => 'ACTIVITY_CURRENCY',
        'AllDayEvent' => 'ALL_DAY_EVENT',
        'Event.AllDayEvent' => 'ALL_DAY_EVENT',
        'allDayEvent' => 'ALL_DAY_EVENT',
        'event.allDayEvent' => 'ALL_DAY_EVENT',
        'EventTableMap::COL_ALL_DAY_EVENT' => 'ALL_DAY_EVENT',
        'COL_ALL_DAY_EVENT' => 'ALL_DAY_EVENT',
        'all_day_event' => 'ALL_DAY_EVENT',
        'event.all_day_event' => 'ALL_DAY_EVENT',
        'Archived' => 'ARCHIVED',
        'Event.Archived' => 'ARCHIVED',
        'archived' => 'ARCHIVED',
        'event.archived' => 'ARCHIVED',
        'EventTableMap::COL_ARCHIVED' => 'ARCHIVED',
        'COL_ARCHIVED' => 'ARCHIVED',
        'AssignedToId' => 'ASSIGNED_TO_ID',
        'Event.AssignedToId' => 'ASSIGNED_TO_ID',
        'assignedToId' => 'ASSIGNED_TO_ID',
        'event.assignedToId' => 'ASSIGNED_TO_ID',
        'EventTableMap::COL_ASSIGNED_TO_ID' => 'ASSIGNED_TO_ID',
        'COL_ASSIGNED_TO_ID' => 'ASSIGNED_TO_ID',
        'assigned_to_id' => 'ASSIGNED_TO_ID',
        'event.assigned_to_id' => 'ASSIGNED_TO_ID',
        'Cancelled' => 'CANCELLED',
        'Event.Cancelled' => 'CANCELLED',
        'cancelled' => 'CANCELLED',
        'event.cancelled' => 'CANCELLED',
        'EventTableMap::COL_CANCELLED' => 'CANCELLED',
        'COL_CANCELLED' => 'CANCELLED',
        'RecurringEvent' => 'RECURRING_EVENT',
        'Event.RecurringEvent' => 'RECURRING_EVENT',
        'recurringEvent' => 'RECURRING_EVENT',
        'event.recurringEvent' => 'RECURRING_EVENT',
        'EventTableMap::COL_RECURRING_EVENT' => 'RECURRING_EVENT',
        'COL_RECURRING_EVENT' => 'RECURRING_EVENT',
        'recurring_event' => 'RECURRING_EVENT',
        'event.recurring_event' => 'RECURRING_EVENT',
        'IsDeleted' => 'IS_DELETED',
        'Event.IsDeleted' => 'IS_DELETED',
        'isDeleted' => 'IS_DELETED',
        'event.isDeleted' => 'IS_DELETED',
        'EventTableMap::COL_IS_DELETED' => 'IS_DELETED',
        'COL_IS_DELETED' => 'IS_DELETED',
        'is_deleted' => 'IS_DELETED',
        'event.is_deleted' => 'IS_DELETED',
        'IsDeletedC' => 'IS_DELETED_C',
        'Event.IsDeletedC' => 'IS_DELETED_C',
        'isDeletedC' => 'IS_DELETED_C',
        'event.isDeletedC' => 'IS_DELETED_C',
        'EventTableMap::COL_IS_DELETED_C' => 'IS_DELETED_C',
        'COL_IS_DELETED_C' => 'IS_DELETED_C',
        'is_deleted_c' => 'IS_DELETED_C',
        'event.is_deleted_c' => 'IS_DELETED_C',
        'Description' => 'DESCRIPTION',
        'Event.Description' => 'DESCRIPTION',
        'description' => 'DESCRIPTION',
        'event.description' => 'DESCRIPTION',
        'EventTableMap::COL_DESCRIPTION' => 'DESCRIPTION',
        'COL_DESCRIPTION' => 'DESCRIPTION',
        'DurationMinutes' => 'DURATION_MINUTES',
        'Event.DurationMinutes' => 'DURATION_MINUTES',
        'durationMinutes' => 'DURATION_MINUTES',
        'event.durationMinutes' => 'DURATION_MINUTES',
        'EventTableMap::COL_DURATION_MINUTES' => 'DURATION_MINUTES',
        'COL_DURATION_MINUTES' => 'DURATION_MINUTES',
        'duration_minutes' => 'DURATION_MINUTES',
        'event.duration_minutes' => 'DURATION_MINUTES',
        'EndDateTime' => 'END_DATE_TIME',
        'Event.EndDateTime' => 'END_DATE_TIME',
        'endDateTime' => 'END_DATE_TIME',
        'event.endDateTime' => 'END_DATE_TIME',
        'EventTableMap::COL_END_DATE_TIME' => 'END_DATE_TIME',
        'COL_END_DATE_TIME' => 'END_DATE_TIME',
        'end_date_time' => 'END_DATE_TIME',
        'event.end_date_time' => 'END_DATE_TIME',
        'RecordTypeId' => 'RECORD_TYPE_ID',
        'Event.RecordTypeId' => 'RECORD_TYPE_ID',
        'recordTypeId' => 'RECORD_TYPE_ID',
        'event.recordTypeId' => 'RECORD_TYPE_ID',
        'EventTableMap::COL_RECORD_TYPE_ID' => 'RECORD_TYPE_ID',
        'COL_RECORD_TYPE_ID' => 'RECORD_TYPE_ID',
        'record_type_id' => 'RECORD_TYPE_ID',
        'event.record_type_id' => 'RECORD_TYPE_ID',
        'EventSubTypeId' => 'EVENT_SUB_TYPE_ID',
        'Event.EventSubTypeId' => 'EVENT_SUB_TYPE_ID',
        'eventSubTypeId' => 'EVENT_SUB_TYPE_ID',
        'event.eventSubTypeId' => 'EVENT_SUB_TYPE_ID',
        'EventTableMap::COL_EVENT_SUB_TYPE_ID' => 'EVENT_SUB_TYPE_ID',
        'COL_EVENT_SUB_TYPE_ID' => 'EVENT_SUB_TYPE_ID',
        'event_sub_type_id' => 'EVENT_SUB_TYPE_ID',
        'event.event_sub_type_id' => 'EVENT_SUB_TYPE_ID',
        'JobStatus' => 'JOB_STATUS',
        'Event.JobStatus' => 'JOB_STATUS',
        'jobStatus' => 'JOB_STATUS',
        'event.jobStatus' => 'JOB_STATUS',
        'EventTableMap::COL_JOB_STATUS' => 'JOB_STATUS',
        'COL_JOB_STATUS' => 'JOB_STATUS',
        'job_status' => 'JOB_STATUS',
        'event.job_status' => 'JOB_STATUS',
        'LocationC' => 'LOCATION_C',
        'Event.LocationC' => 'LOCATION_C',
        'locationC' => 'LOCATION_C',
        'event.locationC' => 'LOCATION_C',
        'EventTableMap::COL_LOCATION_C' => 'LOCATION_C',
        'COL_LOCATION_C' => 'LOCATION_C',
        'location_c' => 'LOCATION_C',
        'event.location_c' => 'LOCATION_C',
        'ReminderDate' => 'REMINDER_DATE',
        'Event.ReminderDate' => 'REMINDER_DATE',
        'reminderDate' => 'REMINDER_DATE',
        'event.reminderDate' => 'REMINDER_DATE',
        'EventTableMap::COL_REMINDER_DATE' => 'REMINDER_DATE',
        'COL_REMINDER_DATE' => 'REMINDER_DATE',
        'reminder_date' => 'REMINDER_DATE',
        'event.reminder_date' => 'REMINDER_DATE',
        'ReminderSet' => 'REMINDER_SET',
        'Event.ReminderSet' => 'REMINDER_SET',
        'reminderSet' => 'REMINDER_SET',
        'event.reminderSet' => 'REMINDER_SET',
        'EventTableMap::COL_REMINDER_SET' => 'REMINDER_SET',
        'COL_REMINDER_SET' => 'REMINDER_SET',
        'reminder_set' => 'REMINDER_SET',
        'event.reminder_set' => 'REMINDER_SET',
        'StartDateTime' => 'START_DATE_TIME',
        'Event.StartDateTime' => 'START_DATE_TIME',
        'startDateTime' => 'START_DATE_TIME',
        'event.startDateTime' => 'START_DATE_TIME',
        'EventTableMap::COL_START_DATE_TIME' => 'START_DATE_TIME',
        'COL_START_DATE_TIME' => 'START_DATE_TIME',
        'start_date_time' => 'START_DATE_TIME',
        'event.start_date_time' => 'START_DATE_TIME',
        'Subject' => 'SUBJECT',
        'Event.Subject' => 'SUBJECT',
        'subject' => 'SUBJECT',
        'event.subject' => 'SUBJECT',
        'EventTableMap::COL_SUBJECT' => 'SUBJECT',
        'COL_SUBJECT' => 'SUBJECT',
        'RecurrenceTimeZone' => 'RECURRENCE_TIME_ZONE',
        'Event.RecurrenceTimeZone' => 'RECURRENCE_TIME_ZONE',
        'recurrenceTimeZone' => 'RECURRENCE_TIME_ZONE',
        'event.recurrenceTimeZone' => 'RECURRENCE_TIME_ZONE',
        'EventTableMap::COL_RECURRENCE_TIME_ZONE' => 'RECURRENCE_TIME_ZONE',
        'COL_RECURRENCE_TIME_ZONE' => 'RECURRENCE_TIME_ZONE',
        'recurrence_time_zone' => 'RECURRENCE_TIME_ZONE',
        'event.recurrence_time_zone' => 'RECURRENCE_TIME_ZONE',
        'CreatedBySfId' => 'CREATED_BY_SF_ID',
        'Event.CreatedBySfId' => 'CREATED_BY_SF_ID',
        'createdBySfId' => 'CREATED_BY_SF_ID',
        'event.createdBySfId' => 'CREATED_BY_SF_ID',
        'EventTableMap::COL_CREATED_BY_SF_ID' => 'CREATED_BY_SF_ID',
        'COL_CREATED_BY_SF_ID' => 'CREATED_BY_SF_ID',
        'created_by_sf_id' => 'CREATED_BY_SF_ID',
        'event.created_by_sf_id' => 'CREATED_BY_SF_ID',
        'PmtoolUpdated' => 'PMTOOL_UPDATED',
        'Event.PmtoolUpdated' => 'PMTOOL_UPDATED',
        'pmtoolUpdated' => 'PMTOOL_UPDATED',
        'event.pmtoolUpdated' => 'PMTOOL_UPDATED',
        'EventTableMap::COL_PMTOOL_UPDATED' => 'PMTOOL_UPDATED',
        'COL_PMTOOL_UPDATED' => 'PMTOOL_UPDATED',
        'pmtool_updated' => 'PMTOOL_UPDATED',
        'event.pmtool_updated' => 'PMTOOL_UPDATED',
        'EventHolderId' => 'EVENT_HOLDER_ID',
        'Event.EventHolderId' => 'EVENT_HOLDER_ID',
        'eventHolderId' => 'EVENT_HOLDER_ID',
        'event.eventHolderId' => 'EVENT_HOLDER_ID',
        'EventTableMap::COL_EVENT_HOLDER_ID' => 'EVENT_HOLDER_ID',
        'COL_EVENT_HOLDER_ID' => 'EVENT_HOLDER_ID',
        'event_holder_id' => 'EVENT_HOLDER_ID',
        'event.event_holder_id' => 'EVENT_HOLDER_ID',
        'ApiCreatedDate' => 'API_CREATED_DATE',
        'Event.ApiCreatedDate' => 'API_CREATED_DATE',
        'apiCreatedDate' => 'API_CREATED_DATE',
        'event.apiCreatedDate' => 'API_CREATED_DATE',
        'EventTableMap::COL_API_CREATED_DATE' => 'API_CREATED_DATE',
        'COL_API_CREATED_DATE' => 'API_CREATED_DATE',
        'api_created_date' => 'API_CREATED_DATE',
        'event.api_created_date' => 'API_CREATED_DATE',
        'ApiUpdatedDate' => 'API_UPDATED_DATE',
        'Event.ApiUpdatedDate' => 'API_UPDATED_DATE',
        'apiUpdatedDate' => 'API_UPDATED_DATE',
        'event.apiUpdatedDate' => 'API_UPDATED_DATE',
        'EventTableMap::COL_API_UPDATED_DATE' => 'API_UPDATED_DATE',
        'COL_API_UPDATED_DATE' => 'API_UPDATED_DATE',
        'api_updated_date' => 'API_UPDATED_DATE',
        'event.api_updated_date' => 'API_UPDATED_DATE',
        'IsGroup' => 'IS_GROUP',
        'Event.IsGroup' => 'IS_GROUP',
        'isGroup' => 'IS_GROUP',
        'event.isGroup' => 'IS_GROUP',
        'EventTableMap::COL_IS_GROUP' => 'IS_GROUP',
        'COL_IS_GROUP' => 'IS_GROUP',
        'is_group' => 'IS_GROUP',
        'event.is_group' => 'IS_GROUP',
        'CreatedDate' => 'CREATED_DATE',
        'Event.CreatedDate' => 'CREATED_DATE',
        'createdDate' => 'CREATED_DATE',
        'event.createdDate' => 'CREATED_DATE',
        'EventTableMap::COL_CREATED_DATE' => 'CREATED_DATE',
        'COL_CREATED_DATE' => 'CREATED_DATE',
        'created_date' => 'CREATED_DATE',
        'event.created_date' => 'CREATED_DATE',
        'UpdatedDate' => 'UPDATED_DATE',
        'Event.UpdatedDate' => 'UPDATED_DATE',
        'updatedDate' => 'UPDATED_DATE',
        'event.updatedDate' => 'UPDATED_DATE',
        'EventTableMap::COL_UPDATED_DATE' => 'UPDATED_DATE',
        'COL_UPDATED_DATE' => 'UPDATED_DATE',
        'updated_date' => 'UPDATED_DATE',
        'event.updated_date' => 'UPDATED_DATE',
    ];

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
                EventTableMap::COL_STATUS => array(
                            self::COL_STATUS_ACTIVE,
            self::COL_STATUS_CANCELLED,
            self::COL_STATUS_DELETED,
        ),
    );

    /**
     * Gets the list of values for all ENUM and SET columns
     * @return array
     */
    public static function getValueSets()
    {
      return static::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM or SET column
     * @param string $colname
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = self::getValueSets();

        return $valueSets[$colname];
    }

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('event');
        $this->setPhpName('Event');
        $this->setIdentifierQuoting(true);
        $this->setClassName('\\Model\\Event');
        $this->setPackage('src.Model');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('id', 'Id', 'INTEGER', true, null, null);
        $this->addColumn('sams_event_id', 'SamsEventId', 'VARCHAR', true, 50, null);
        $this->addForeignKey('job_id', 'JobId', 'INTEGER', 'job', 'id', false, null, null);
        $this->addForeignKey('bid_job_id', 'BidJobId', 'INTEGER', 'sf_opportunity_bid_job', 'id', false, null, null);
        $this->addColumn('bid_job_archive_id', 'BidJobArchiveId', 'INTEGER', false, null, null);
        $this->addForeignKey('ref_room_id', 'RefRoomId', 'INTEGER', 'ref_room', 'id', false, null, null);
        $this->addForeignKey('ref_time_slot_id', 'RefTimeSlotId', 'INTEGER', 'ref_time_slot', 'id', false, null, null);
        $this->addForeignKey('event_status_id', 'EventStatusId', 'INTEGER', 'ref_event_status', 'id', false, null, null);
        $this->addColumn('date', 'Date', 'DATE', false, null, null);
        $this->addColumn('confirmed_date', 'ConfirmedDate', 'DATE', false, null, null);
        $this->addColumn('active_date', 'ActiveDate', 'DATE', false, null, null);
        $this->addForeignKey('event_methodology_id', 'EventMethodologyId', 'INTEGER', 'ref_event_methodology', 'id', false, null, null);
        $this->addColumn('status', 'Status', 'ENUM', false, null, 'active');
        $this->getColumn('status')->setValueSet(array (
  0 => 'active',
  1 => 'cancelled',
  2 => 'deleted',
));
        $this->addColumn('comments', 'Comments', 'LONGVARCHAR', false, null, null);
        $this->addColumn('facility_note', 'FacilityNote', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('site_id', 'SiteId', 'INTEGER', 'ref_site', 'id', false, 8, null);
        $this->addForeignKey('account_id', 'AccountId', 'INTEGER', 'sf_account', 'id', false, null, null);
        $this->addColumn('account_sf_id', 'AccountSfId', 'VARCHAR', false, 255, null);
        $this->addColumn('activity_currency', 'ActivityCurrency', 'VARCHAR', false, 255, null);
        $this->addColumn('all_day_event', 'AllDayEvent', 'BOOLEAN', true, 1, false);
        $this->addColumn('archived', 'Archived', 'BOOLEAN', true, 1, false);
        $this->addForeignKey('assigned_to_id', 'AssignedToId', 'INTEGER', 'user', 'id', false, null, null);
        $this->addColumn('cancelled', 'Cancelled', 'BOOLEAN', true, 1, false);
        $this->addColumn('recurring_event', 'RecurringEvent', 'BOOLEAN', true, 1, false);
        $this->addColumn('is_deleted', 'IsDeleted', 'BOOLEAN', true, 1, false);
        $this->addColumn('is_deleted_c', 'IsDeletedC', 'BOOLEAN', true, 1, false);
        $this->addColumn('description', 'Description', 'LONGVARCHAR', false, null, null);
        $this->addColumn('duration_minutes', 'DurationMinutes', 'INTEGER', false, null, null);
        $this->addColumn('end_date_time', 'EndDateTime', 'TIMESTAMP', false, null, null);
        $this->addForeignKey('record_type_id', 'RecordTypeId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addForeignKey('event_sub_type_id', 'EventSubTypeId', 'INTEGER', 'sf_ref_salesforce', 'id', false, null, null);
        $this->addColumn('job_status', 'JobStatus', 'VARCHAR', false, 30, null);
        $this->addColumn('location_c', 'LocationC', 'VARCHAR', false, 50, null);
        $this->addColumn('reminder_date', 'ReminderDate', 'DATE', false, null, null);
        $this->addColumn('reminder_set', 'ReminderSet', 'BOOLEAN', true, 1, false);
        $this->addColumn('start_date_time', 'StartDateTime', 'TIMESTAMP', false, null, null);
        $this->addColumn('subject', 'Subject', 'VARCHAR', false, 255, null);
        $this->addColumn('recurrence_time_zone', 'RecurrenceTimeZone', 'VARCHAR', false, 255, null);
        $this->addColumn('created_by_sf_id', 'CreatedBySfId', 'VARCHAR', true, 255, null);
        $this->addColumn('pmtool_updated', 'PmtoolUpdated', 'BOOLEAN', true, 1, false);
        $this->addForeignKey('event_holder_id', 'EventHolderId', 'INTEGER', 'user', 'id', false, null, null);
        $this->addColumn('api_created_date', 'ApiCreatedDate', 'TIMESTAMP', false, null, null);
        $this->addColumn('api_updated_date', 'ApiUpdatedDate', 'TIMESTAMP', false, null, null);
        $this->addColumn('is_group', 'IsGroup', 'BOOLEAN', true, 1, false);
        $this->addColumn('created_date', 'CreatedDate', 'TIMESTAMP', false, null, null);
        $this->addColumn('updated_date', 'UpdatedDate', 'TIMESTAMP', false, null, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('EventHolderBy', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':event_holder_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Job', '\\Model\\Job', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':job_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('BidJob', '\\Model\\BidJob', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':bid_job_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', null, false);
        $this->addRelation('RefRoom', '\\Model\\RefRoom', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':ref_room_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('RefEventStatus', '\\Model\\RefEventStatus', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':event_status_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('RefTimeSlot', '\\Model\\RefTimeSlot', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':ref_time_slot_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('EventMethodology', '\\Model\\EventMethodology', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':event_methodology_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Account', '\\Model\\Account', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('AssignedTo', '\\Model\\User', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':assigned_to_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('RecordType', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':record_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('EventSubType', '\\Model\\RefSalesForce', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':event_sub_type_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Site', '\\Model\\Site', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':site_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Module', '\\Model\\Module', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':event_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'Modules', false);
        $this->addRelation('Event', '\\Model\\BidJobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':event_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'Events', false);
        $this->addRelation('EventBidJobItem', '\\Model\\EventBidJobItem', RelationMap::ONE_TO_MANY, array (
  0 =>
  array (
    0 => ':event_id',
    1 => ':id',
  ),
), 'CASCADE', 'CASCADE', 'EventBidJobItems', false);
    } // buildRelations()

    /**
     *
     * Gets the list of behaviors registered for this table
     *
     * @return array Associative array (name => parameters) of behaviors
     */
    public function getBehaviors()
    {
        return array(
            'timestampable' => ['create_column' => 'created_date', 'update_column' => 'updated_date', 'disable_created_at' => 'false', 'disable_updated_at' => 'false'],
        );
    } // getBehaviors()

    /**
     * Method to invalidate the instance pool of all tables related to event     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
        // Invalidate objects in related instance pools,
        // since one or more of them may be deleted by ON DELETE CASCADE/SETNULL rule.
        ModuleTableMap::clearInstancePool();
        BidJobItemTableMap::clearInstancePool();
        EventBidJobItemTableMap::clearInstancePool();
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return null === $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] || is_scalar($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)]) || is_callable([$row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)], '__toString']) ? (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] : $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }

    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? EventTableMap::CLASS_DEFAULT : EventTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (Event object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = EventTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = EventTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + EventTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = EventTableMap::OM_CLASS;
            /** @var Event $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            EventTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = EventTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = EventTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var Event $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                EventTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(EventTableMap::COL_ID);
            $criteria->addSelectColumn(EventTableMap::COL_SAMS_EVENT_ID);
            $criteria->addSelectColumn(EventTableMap::COL_JOB_ID);
            $criteria->addSelectColumn(EventTableMap::COL_BID_JOB_ID);
            $criteria->addSelectColumn(EventTableMap::COL_BID_JOB_ARCHIVE_ID);
            $criteria->addSelectColumn(EventTableMap::COL_REF_ROOM_ID);
            $criteria->addSelectColumn(EventTableMap::COL_REF_TIME_SLOT_ID);
            $criteria->addSelectColumn(EventTableMap::COL_EVENT_STATUS_ID);
            $criteria->addSelectColumn(EventTableMap::COL_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_CONFIRMED_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_ACTIVE_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_EVENT_METHODOLOGY_ID);
            $criteria->addSelectColumn(EventTableMap::COL_STATUS);
            $criteria->addSelectColumn(EventTableMap::COL_COMMENTS);
            $criteria->addSelectColumn(EventTableMap::COL_FACILITY_NOTE);
            $criteria->addSelectColumn(EventTableMap::COL_SITE_ID);
            $criteria->addSelectColumn(EventTableMap::COL_ACCOUNT_ID);
            $criteria->addSelectColumn(EventTableMap::COL_ACCOUNT_SF_ID);
            $criteria->addSelectColumn(EventTableMap::COL_ACTIVITY_CURRENCY);
            $criteria->addSelectColumn(EventTableMap::COL_ALL_DAY_EVENT);
            $criteria->addSelectColumn(EventTableMap::COL_ARCHIVED);
            $criteria->addSelectColumn(EventTableMap::COL_ASSIGNED_TO_ID);
            $criteria->addSelectColumn(EventTableMap::COL_CANCELLED);
            $criteria->addSelectColumn(EventTableMap::COL_RECURRING_EVENT);
            $criteria->addSelectColumn(EventTableMap::COL_IS_DELETED);
            $criteria->addSelectColumn(EventTableMap::COL_IS_DELETED_C);
            $criteria->addSelectColumn(EventTableMap::COL_DESCRIPTION);
            $criteria->addSelectColumn(EventTableMap::COL_DURATION_MINUTES);
            $criteria->addSelectColumn(EventTableMap::COL_END_DATE_TIME);
            $criteria->addSelectColumn(EventTableMap::COL_RECORD_TYPE_ID);
            $criteria->addSelectColumn(EventTableMap::COL_EVENT_SUB_TYPE_ID);
            $criteria->addSelectColumn(EventTableMap::COL_JOB_STATUS);
            $criteria->addSelectColumn(EventTableMap::COL_LOCATION_C);
            $criteria->addSelectColumn(EventTableMap::COL_REMINDER_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_REMINDER_SET);
            $criteria->addSelectColumn(EventTableMap::COL_START_DATE_TIME);
            $criteria->addSelectColumn(EventTableMap::COL_SUBJECT);
            $criteria->addSelectColumn(EventTableMap::COL_RECURRENCE_TIME_ZONE);
            $criteria->addSelectColumn(EventTableMap::COL_CREATED_BY_SF_ID);
            $criteria->addSelectColumn(EventTableMap::COL_PMTOOL_UPDATED);
            $criteria->addSelectColumn(EventTableMap::COL_EVENT_HOLDER_ID);
            $criteria->addSelectColumn(EventTableMap::COL_API_CREATED_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_API_UPDATED_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_IS_GROUP);
            $criteria->addSelectColumn(EventTableMap::COL_CREATED_DATE);
            $criteria->addSelectColumn(EventTableMap::COL_UPDATED_DATE);
        } else {
            $criteria->addSelectColumn($alias . '.id');
            $criteria->addSelectColumn($alias . '.sams_event_id');
            $criteria->addSelectColumn($alias . '.job_id');
            $criteria->addSelectColumn($alias . '.bid_job_id');
            $criteria->addSelectColumn($alias . '.bid_job_archive_id');
            $criteria->addSelectColumn($alias . '.ref_room_id');
            $criteria->addSelectColumn($alias . '.ref_time_slot_id');
            $criteria->addSelectColumn($alias . '.event_status_id');
            $criteria->addSelectColumn($alias . '.date');
            $criteria->addSelectColumn($alias . '.confirmed_date');
            $criteria->addSelectColumn($alias . '.active_date');
            $criteria->addSelectColumn($alias . '.event_methodology_id');
            $criteria->addSelectColumn($alias . '.status');
            $criteria->addSelectColumn($alias . '.comments');
            $criteria->addSelectColumn($alias . '.facility_note');
            $criteria->addSelectColumn($alias . '.site_id');
            $criteria->addSelectColumn($alias . '.account_id');
            $criteria->addSelectColumn($alias . '.account_sf_id');
            $criteria->addSelectColumn($alias . '.activity_currency');
            $criteria->addSelectColumn($alias . '.all_day_event');
            $criteria->addSelectColumn($alias . '.archived');
            $criteria->addSelectColumn($alias . '.assigned_to_id');
            $criteria->addSelectColumn($alias . '.cancelled');
            $criteria->addSelectColumn($alias . '.recurring_event');
            $criteria->addSelectColumn($alias . '.is_deleted');
            $criteria->addSelectColumn($alias . '.is_deleted_c');
            $criteria->addSelectColumn($alias . '.description');
            $criteria->addSelectColumn($alias . '.duration_minutes');
            $criteria->addSelectColumn($alias . '.end_date_time');
            $criteria->addSelectColumn($alias . '.record_type_id');
            $criteria->addSelectColumn($alias . '.event_sub_type_id');
            $criteria->addSelectColumn($alias . '.job_status');
            $criteria->addSelectColumn($alias . '.location_c');
            $criteria->addSelectColumn($alias . '.reminder_date');
            $criteria->addSelectColumn($alias . '.reminder_set');
            $criteria->addSelectColumn($alias . '.start_date_time');
            $criteria->addSelectColumn($alias . '.subject');
            $criteria->addSelectColumn($alias . '.recurrence_time_zone');
            $criteria->addSelectColumn($alias . '.created_by_sf_id');
            $criteria->addSelectColumn($alias . '.pmtool_updated');
            $criteria->addSelectColumn($alias . '.event_holder_id');
            $criteria->addSelectColumn($alias . '.api_created_date');
            $criteria->addSelectColumn($alias . '.api_updated_date');
            $criteria->addSelectColumn($alias . '.is_group');
            $criteria->addSelectColumn($alias . '.created_date');
            $criteria->addSelectColumn($alias . '.updated_date');
        }
    }

    /**
     * Remove all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be removed as they are only loaded on demand.
     *
     * @param Criteria $criteria object containing the columns to remove.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function removeSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->removeSelectColumn(EventTableMap::COL_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_SAMS_EVENT_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_JOB_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_BID_JOB_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_BID_JOB_ARCHIVE_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_REF_ROOM_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_REF_TIME_SLOT_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_EVENT_STATUS_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_CONFIRMED_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_ACTIVE_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_EVENT_METHODOLOGY_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_STATUS);
            $criteria->removeSelectColumn(EventTableMap::COL_COMMENTS);
            $criteria->removeSelectColumn(EventTableMap::COL_FACILITY_NOTE);
            $criteria->removeSelectColumn(EventTableMap::COL_SITE_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_ACCOUNT_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_ACCOUNT_SF_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_ACTIVITY_CURRENCY);
            $criteria->removeSelectColumn(EventTableMap::COL_ALL_DAY_EVENT);
            $criteria->removeSelectColumn(EventTableMap::COL_ARCHIVED);
            $criteria->removeSelectColumn(EventTableMap::COL_ASSIGNED_TO_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_CANCELLED);
            $criteria->removeSelectColumn(EventTableMap::COL_RECURRING_EVENT);
            $criteria->removeSelectColumn(EventTableMap::COL_IS_DELETED);
            $criteria->removeSelectColumn(EventTableMap::COL_IS_DELETED_C);
            $criteria->removeSelectColumn(EventTableMap::COL_DESCRIPTION);
            $criteria->removeSelectColumn(EventTableMap::COL_DURATION_MINUTES);
            $criteria->removeSelectColumn(EventTableMap::COL_END_DATE_TIME);
            $criteria->removeSelectColumn(EventTableMap::COL_RECORD_TYPE_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_EVENT_SUB_TYPE_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_JOB_STATUS);
            $criteria->removeSelectColumn(EventTableMap::COL_LOCATION_C);
            $criteria->removeSelectColumn(EventTableMap::COL_REMINDER_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_REMINDER_SET);
            $criteria->removeSelectColumn(EventTableMap::COL_START_DATE_TIME);
            $criteria->removeSelectColumn(EventTableMap::COL_SUBJECT);
            $criteria->removeSelectColumn(EventTableMap::COL_RECURRENCE_TIME_ZONE);
            $criteria->removeSelectColumn(EventTableMap::COL_CREATED_BY_SF_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_PMTOOL_UPDATED);
            $criteria->removeSelectColumn(EventTableMap::COL_EVENT_HOLDER_ID);
            $criteria->removeSelectColumn(EventTableMap::COL_API_CREATED_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_API_UPDATED_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_IS_GROUP);
            $criteria->removeSelectColumn(EventTableMap::COL_CREATED_DATE);
            $criteria->removeSelectColumn(EventTableMap::COL_UPDATED_DATE);
        } else {
            $criteria->removeSelectColumn($alias . '.id');
            $criteria->removeSelectColumn($alias . '.sams_event_id');
            $criteria->removeSelectColumn($alias . '.job_id');
            $criteria->removeSelectColumn($alias . '.bid_job_id');
            $criteria->removeSelectColumn($alias . '.bid_job_archive_id');
            $criteria->removeSelectColumn($alias . '.ref_room_id');
            $criteria->removeSelectColumn($alias . '.ref_time_slot_id');
            $criteria->removeSelectColumn($alias . '.event_status_id');
            $criteria->removeSelectColumn($alias . '.date');
            $criteria->removeSelectColumn($alias . '.confirmed_date');
            $criteria->removeSelectColumn($alias . '.active_date');
            $criteria->removeSelectColumn($alias . '.event_methodology_id');
            $criteria->removeSelectColumn($alias . '.status');
            $criteria->removeSelectColumn($alias . '.comments');
            $criteria->removeSelectColumn($alias . '.facility_note');
            $criteria->removeSelectColumn($alias . '.site_id');
            $criteria->removeSelectColumn($alias . '.account_id');
            $criteria->removeSelectColumn($alias . '.account_sf_id');
            $criteria->removeSelectColumn($alias . '.activity_currency');
            $criteria->removeSelectColumn($alias . '.all_day_event');
            $criteria->removeSelectColumn($alias . '.archived');
            $criteria->removeSelectColumn($alias . '.assigned_to_id');
            $criteria->removeSelectColumn($alias . '.cancelled');
            $criteria->removeSelectColumn($alias . '.recurring_event');
            $criteria->removeSelectColumn($alias . '.is_deleted');
            $criteria->removeSelectColumn($alias . '.is_deleted_c');
            $criteria->removeSelectColumn($alias . '.description');
            $criteria->removeSelectColumn($alias . '.duration_minutes');
            $criteria->removeSelectColumn($alias . '.end_date_time');
            $criteria->removeSelectColumn($alias . '.record_type_id');
            $criteria->removeSelectColumn($alias . '.event_sub_type_id');
            $criteria->removeSelectColumn($alias . '.job_status');
            $criteria->removeSelectColumn($alias . '.location_c');
            $criteria->removeSelectColumn($alias . '.reminder_date');
            $criteria->removeSelectColumn($alias . '.reminder_set');
            $criteria->removeSelectColumn($alias . '.start_date_time');
            $criteria->removeSelectColumn($alias . '.subject');
            $criteria->removeSelectColumn($alias . '.recurrence_time_zone');
            $criteria->removeSelectColumn($alias . '.created_by_sf_id');
            $criteria->removeSelectColumn($alias . '.pmtool_updated');
            $criteria->removeSelectColumn($alias . '.event_holder_id');
            $criteria->removeSelectColumn($alias . '.api_created_date');
            $criteria->removeSelectColumn($alias . '.api_updated_date');
            $criteria->removeSelectColumn($alias . '.is_group');
            $criteria->removeSelectColumn($alias . '.created_date');
            $criteria->removeSelectColumn($alias . '.updated_date');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(EventTableMap::DATABASE_NAME)->getTable(EventTableMap::TABLE_NAME);
    }

    /**
     * Performs a DELETE on the database, given a Event or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or Event object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \Model\Event) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(EventTableMap::DATABASE_NAME);
            $criteria->add(EventTableMap::COL_ID, (array) $values, Criteria::IN);
        }

        $query = EventQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            EventTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                EventTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the event table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return EventQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a Event or Criteria object.
     *
     * @param mixed               $criteria Criteria or Event object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from Event object
        }

        if ($criteria->containsKey(EventTableMap::COL_ID) && $criteria->keyContainsValue(EventTableMap::COL_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.EventTableMap::COL_ID.')');
        }


        // Set the correct dbName
        $query = EventQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // EventTableMap
