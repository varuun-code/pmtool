<?php

namespace Model\Map;

use Model\EtudeMaster;
use Model\EtudeMasterQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'etude_master' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 */
class EtudeMasterTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'src.Model.Map.EtudeMasterTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'default';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'etude_master';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\Model\\EtudeMaster';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'src.Model.EtudeMaster';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 34;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 34;

    /**
     * the column name for the id field
     */
    const COL_ID = 'etude_master.id';

    /**
     * the column name for the numero_etude field
     */
    const COL_NUMERO_ETUDE = 'etude_master.numero_etude';

    /**
     * the column name for the reference_client field
     */
    const COL_REFERENCE_CLIENT = 'etude_master.reference_client';

    /**
     * the column name for the theme field
     */
    const COL_THEME = 'etude_master.theme';

    /**
     * the column name for the date_debut field
     */
    const COL_DATE_DEBUT = 'etude_master.date_debut';

    /**
     * the column name for the date_fin field
     */
    const COL_DATE_FIN = 'etude_master.date_fin';

    /**
     * the column name for the annee field
     */
    const COL_ANNEE = 'etude_master.annee';

    /**
     * the column name for the id_pm field
     */
    const COL_ID_PM = 'etude_master.id_pm';

    /**
     * the column name for the id_etape field
     */
    const COL_ID_ETAPE = 'etude_master.id_etape';

    /**
     * the column name for the prix_revient_initial field
     */
    const COL_PRIX_REVIENT_INITIAL = 'etude_master.prix_revient_initial';

    /**
     * the column name for the prix_revient_actualise field
     */
    const COL_PRIX_REVIENT_ACTUALISE = 'etude_master.prix_revient_actualise';

    /**
     * the column name for the prix_vente_initial field
     */
    const COL_PRIX_VENTE_INITIAL = 'etude_master.prix_vente_initial';

    /**
     * the column name for the prix_vente_actualise field
     */
    const COL_PRIX_VENTE_ACTUALISE = 'etude_master.prix_vente_actualise';

    /**
     * the column name for the numero_facture field
     */
    const COL_NUMERO_FACTURE = 'etude_master.numero_facture';

    /**
     * the column name for the date_envoi_facture field
     */
    const COL_DATE_ENVOI_FACTURE = 'etude_master.date_envoi_facture';

    /**
     * the column name for the date_reglement field
     */
    const COL_DATE_REGLEMENT = 'etude_master.date_reglement';

    /**
     * the column name for the commentaire field
     */
    const COL_COMMENTAIRE = 'etude_master.commentaire';

    /**
     * the column name for the industry_id field
     */
    const COL_INDUSTRY_ID = 'etude_master.industry_id';

    /**
     * the column name for the periode_cutoff field
     */
    const COL_PERIODE_CUTOFF = 'etude_master.periode_cutoff';

    /**
     * the column name for the theme_br field
     */
    const COL_THEME_BR = 'etude_master.theme_br';

    /**
     * the column name for the area_id field
     */
    const COL_AREA_ID = 'etude_master.area_id';

    /**
     * the column name for the id_qq field
     */
    const COL_ID_QQ = 'etude_master.id_qq';

    /**
     * the column name for the id_sams_study field
     */
    const COL_ID_SAMS_STUDY = 'etude_master.id_sams_study';

    /**
     * the column name for the recrutement_objectif field
     */
    const COL_RECRUTEMENT_OBJECTIF = 'etude_master.recrutement_objectif';

    /**
     * the column name for the id_location_pnl field
     */
    const COL_ID_LOCATION_PNL = 'etude_master.id_location_pnl';

    /**
     * the column name for the durationStudy field
     */
    const COL_DURATIONSTUDY = 'etude_master.durationStudy';

    /**
     * the column name for the recrutement_objectif_pr field
     */
    const COL_RECRUTEMENT_OBJECTIF_PR = 'etude_master.recrutement_objectif_pr';

    /**
     * the column name for the id_bm field
     */
    const COL_ID_BM = 'etude_master.id_bm';

    /**
     * the column name for the account_id field
     */
    const COL_ACCOUNT_ID = 'etude_master.account_id';

    /**
     * the column name for the remise_taux field
     */
    const COL_REMISE_TAUX = 'etude_master.remise_taux';

    /**
     * the column name for the language field
     */
    const COL_LANGUAGE = 'etude_master.language';

    /**
     * the column name for the kol field
     */
    const COL_KOL = 'etude_master.kol';

    /**
     * the column name for the sms_relance field
     */
    const COL_SMS_RELANCE = 'etude_master.sms_relance';

    /**
     * the column name for the gms field
     */
    const COL_GMS = 'etude_master.gms';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Id', 'NumeroEtude', 'ReferenceClient', 'Theme', 'DateDebut', 'DateFin', 'Annee', 'IdPm', 'IdEtape', 'PrixRevientInitial', 'PrixRevientActualise', 'PrixVenteInitial', 'PrixVenteActualise', 'NumeroFacture', 'DateEnvoiFacture', 'DateReglement', 'Commentaire', 'IndustryId', 'PeriodeCutoff', 'ThemeBr', 'AreaId', 'IdQq', 'IdSamsStudy', 'RecrutementObjectif', 'IdLocationPnl', 'Durationstudy', 'RecrutementObjectifPr', 'IdBm', 'AccountId', 'RemiseTaux', 'Language', 'Kol', 'SmsRelance', 'Gms', ),
        self::TYPE_CAMELNAME     => array('id', 'numeroEtude', 'referenceClient', 'theme', 'dateDebut', 'dateFin', 'annee', 'idPm', 'idEtape', 'prixRevientInitial', 'prixRevientActualise', 'prixVenteInitial', 'prixVenteActualise', 'numeroFacture', 'dateEnvoiFacture', 'dateReglement', 'commentaire', 'industryId', 'periodeCutoff', 'themeBr', 'areaId', 'idQq', 'idSamsStudy', 'recrutementObjectif', 'idLocationPnl', 'durationstudy', 'recrutementObjectifPr', 'idBm', 'accountId', 'remiseTaux', 'language', 'kol', 'smsRelance', 'gms', ),
        self::TYPE_COLNAME       => array(EtudeMasterTableMap::COL_ID, EtudeMasterTableMap::COL_NUMERO_ETUDE, EtudeMasterTableMap::COL_REFERENCE_CLIENT, EtudeMasterTableMap::COL_THEME, EtudeMasterTableMap::COL_DATE_DEBUT, EtudeMasterTableMap::COL_DATE_FIN, EtudeMasterTableMap::COL_ANNEE, EtudeMasterTableMap::COL_ID_PM, EtudeMasterTableMap::COL_ID_ETAPE, EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL, EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE, EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL, EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE, EtudeMasterTableMap::COL_NUMERO_FACTURE, EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE, EtudeMasterTableMap::COL_DATE_REGLEMENT, EtudeMasterTableMap::COL_COMMENTAIRE, EtudeMasterTableMap::COL_INDUSTRY_ID, EtudeMasterTableMap::COL_PERIODE_CUTOFF, EtudeMasterTableMap::COL_THEME_BR, EtudeMasterTableMap::COL_AREA_ID, EtudeMasterTableMap::COL_ID_QQ, EtudeMasterTableMap::COL_ID_SAMS_STUDY, EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF, EtudeMasterTableMap::COL_ID_LOCATION_PNL, EtudeMasterTableMap::COL_DURATIONSTUDY, EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR, EtudeMasterTableMap::COL_ID_BM, EtudeMasterTableMap::COL_ACCOUNT_ID, EtudeMasterTableMap::COL_REMISE_TAUX, EtudeMasterTableMap::COL_LANGUAGE, EtudeMasterTableMap::COL_KOL, EtudeMasterTableMap::COL_SMS_RELANCE, EtudeMasterTableMap::COL_GMS, ),
        self::TYPE_FIELDNAME     => array('id', 'numero_etude', 'reference_client', 'theme', 'date_debut', 'date_fin', 'annee', 'id_pm', 'id_etape', 'prix_revient_initial', 'prix_revient_actualise', 'prix_vente_initial', 'prix_vente_actualise', 'numero_facture', 'date_envoi_facture', 'date_reglement', 'commentaire', 'industry_id', 'periode_cutoff', 'theme_br', 'area_id', 'id_qq', 'id_sams_study', 'recrutement_objectif', 'id_location_pnl', 'durationStudy', 'recrutement_objectif_pr', 'id_bm', 'account_id', 'remise_taux', 'language', 'kol', 'sms_relance', 'gms', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Id' => 0, 'NumeroEtude' => 1, 'ReferenceClient' => 2, 'Theme' => 3, 'DateDebut' => 4, 'DateFin' => 5, 'Annee' => 6, 'IdPm' => 7, 'IdEtape' => 8, 'PrixRevientInitial' => 9, 'PrixRevientActualise' => 10, 'PrixVenteInitial' => 11, 'PrixVenteActualise' => 12, 'NumeroFacture' => 13, 'DateEnvoiFacture' => 14, 'DateReglement' => 15, 'Commentaire' => 16, 'IndustryId' => 17, 'PeriodeCutoff' => 18, 'ThemeBr' => 19, 'AreaId' => 20, 'IdQq' => 21, 'IdSamsStudy' => 22, 'RecrutementObjectif' => 23, 'IdLocationPnl' => 24, 'Durationstudy' => 25, 'RecrutementObjectifPr' => 26, 'IdBm' => 27, 'AccountId' => 28, 'RemiseTaux' => 29, 'Language' => 30, 'Kol' => 31, 'SmsRelance' => 32, 'Gms' => 33, ),
        self::TYPE_CAMELNAME     => array('id' => 0, 'numeroEtude' => 1, 'referenceClient' => 2, 'theme' => 3, 'dateDebut' => 4, 'dateFin' => 5, 'annee' => 6, 'idPm' => 7, 'idEtape' => 8, 'prixRevientInitial' => 9, 'prixRevientActualise' => 10, 'prixVenteInitial' => 11, 'prixVenteActualise' => 12, 'numeroFacture' => 13, 'dateEnvoiFacture' => 14, 'dateReglement' => 15, 'commentaire' => 16, 'industryId' => 17, 'periodeCutoff' => 18, 'themeBr' => 19, 'areaId' => 20, 'idQq' => 21, 'idSamsStudy' => 22, 'recrutementObjectif' => 23, 'idLocationPnl' => 24, 'durationstudy' => 25, 'recrutementObjectifPr' => 26, 'idBm' => 27, 'accountId' => 28, 'remiseTaux' => 29, 'language' => 30, 'kol' => 31, 'smsRelance' => 32, 'gms' => 33, ),
        self::TYPE_COLNAME       => array(EtudeMasterTableMap::COL_ID => 0, EtudeMasterTableMap::COL_NUMERO_ETUDE => 1, EtudeMasterTableMap::COL_REFERENCE_CLIENT => 2, EtudeMasterTableMap::COL_THEME => 3, EtudeMasterTableMap::COL_DATE_DEBUT => 4, EtudeMasterTableMap::COL_DATE_FIN => 5, EtudeMasterTableMap::COL_ANNEE => 6, EtudeMasterTableMap::COL_ID_PM => 7, EtudeMasterTableMap::COL_ID_ETAPE => 8, EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL => 9, EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE => 10, EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL => 11, EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE => 12, EtudeMasterTableMap::COL_NUMERO_FACTURE => 13, EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE => 14, EtudeMasterTableMap::COL_DATE_REGLEMENT => 15, EtudeMasterTableMap::COL_COMMENTAIRE => 16, EtudeMasterTableMap::COL_INDUSTRY_ID => 17, EtudeMasterTableMap::COL_PERIODE_CUTOFF => 18, EtudeMasterTableMap::COL_THEME_BR => 19, EtudeMasterTableMap::COL_AREA_ID => 20, EtudeMasterTableMap::COL_ID_QQ => 21, EtudeMasterTableMap::COL_ID_SAMS_STUDY => 22, EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF => 23, EtudeMasterTableMap::COL_ID_LOCATION_PNL => 24, EtudeMasterTableMap::COL_DURATIONSTUDY => 25, EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR => 26, EtudeMasterTableMap::COL_ID_BM => 27, EtudeMasterTableMap::COL_ACCOUNT_ID => 28, EtudeMasterTableMap::COL_REMISE_TAUX => 29, EtudeMasterTableMap::COL_LANGUAGE => 30, EtudeMasterTableMap::COL_KOL => 31, EtudeMasterTableMap::COL_SMS_RELANCE => 32, EtudeMasterTableMap::COL_GMS => 33, ),
        self::TYPE_FIELDNAME     => array('id' => 0, 'numero_etude' => 1, 'reference_client' => 2, 'theme' => 3, 'date_debut' => 4, 'date_fin' => 5, 'annee' => 6, 'id_pm' => 7, 'id_etape' => 8, 'prix_revient_initial' => 9, 'prix_revient_actualise' => 10, 'prix_vente_initial' => 11, 'prix_vente_actualise' => 12, 'numero_facture' => 13, 'date_envoi_facture' => 14, 'date_reglement' => 15, 'commentaire' => 16, 'industry_id' => 17, 'periode_cutoff' => 18, 'theme_br' => 19, 'area_id' => 20, 'id_qq' => 21, 'id_sams_study' => 22, 'recrutement_objectif' => 23, 'id_location_pnl' => 24, 'durationStudy' => 25, 'recrutement_objectif_pr' => 26, 'id_bm' => 27, 'account_id' => 28, 'remise_taux' => 29, 'language' => 30, 'kol' => 31, 'sms_relance' => 32, 'gms' => 33, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, )
    );

    /**
     * Holds a list of column names and their normalized version.
     *
     * @var string[]
     */
    protected $normalizedColumnNameMap = [
        'Id' => 'ID',
        'EtudeMaster.Id' => 'ID',
        'id' => 'ID',
        'etudeMaster.id' => 'ID',
        'EtudeMasterTableMap::COL_ID' => 'ID',
        'COL_ID' => 'ID',
        'etude_master.id' => 'ID',
        'NumeroEtude' => 'NUMERO_ETUDE',
        'EtudeMaster.NumeroEtude' => 'NUMERO_ETUDE',
        'numeroEtude' => 'NUMERO_ETUDE',
        'etudeMaster.numeroEtude' => 'NUMERO_ETUDE',
        'EtudeMasterTableMap::COL_NUMERO_ETUDE' => 'NUMERO_ETUDE',
        'COL_NUMERO_ETUDE' => 'NUMERO_ETUDE',
        'numero_etude' => 'NUMERO_ETUDE',
        'etude_master.numero_etude' => 'NUMERO_ETUDE',
        'ReferenceClient' => 'REFERENCE_CLIENT',
        'EtudeMaster.ReferenceClient' => 'REFERENCE_CLIENT',
        'referenceClient' => 'REFERENCE_CLIENT',
        'etudeMaster.referenceClient' => 'REFERENCE_CLIENT',
        'EtudeMasterTableMap::COL_REFERENCE_CLIENT' => 'REFERENCE_CLIENT',
        'COL_REFERENCE_CLIENT' => 'REFERENCE_CLIENT',
        'reference_client' => 'REFERENCE_CLIENT',
        'etude_master.reference_client' => 'REFERENCE_CLIENT',
        'Theme' => 'THEME',
        'EtudeMaster.Theme' => 'THEME',
        'theme' => 'THEME',
        'etudeMaster.theme' => 'THEME',
        'EtudeMasterTableMap::COL_THEME' => 'THEME',
        'COL_THEME' => 'THEME',
        'etude_master.theme' => 'THEME',
        'DateDebut' => 'DATE_DEBUT',
        'EtudeMaster.DateDebut' => 'DATE_DEBUT',
        'dateDebut' => 'DATE_DEBUT',
        'etudeMaster.dateDebut' => 'DATE_DEBUT',
        'EtudeMasterTableMap::COL_DATE_DEBUT' => 'DATE_DEBUT',
        'COL_DATE_DEBUT' => 'DATE_DEBUT',
        'date_debut' => 'DATE_DEBUT',
        'etude_master.date_debut' => 'DATE_DEBUT',
        'DateFin' => 'DATE_FIN',
        'EtudeMaster.DateFin' => 'DATE_FIN',
        'dateFin' => 'DATE_FIN',
        'etudeMaster.dateFin' => 'DATE_FIN',
        'EtudeMasterTableMap::COL_DATE_FIN' => 'DATE_FIN',
        'COL_DATE_FIN' => 'DATE_FIN',
        'date_fin' => 'DATE_FIN',
        'etude_master.date_fin' => 'DATE_FIN',
        'Annee' => 'ANNEE',
        'EtudeMaster.Annee' => 'ANNEE',
        'annee' => 'ANNEE',
        'etudeMaster.annee' => 'ANNEE',
        'EtudeMasterTableMap::COL_ANNEE' => 'ANNEE',
        'COL_ANNEE' => 'ANNEE',
        'etude_master.annee' => 'ANNEE',
        'IdPm' => 'ID_PM',
        'EtudeMaster.IdPm' => 'ID_PM',
        'idPm' => 'ID_PM',
        'etudeMaster.idPm' => 'ID_PM',
        'EtudeMasterTableMap::COL_ID_PM' => 'ID_PM',
        'COL_ID_PM' => 'ID_PM',
        'id_pm' => 'ID_PM',
        'etude_master.id_pm' => 'ID_PM',
        'IdEtape' => 'ID_ETAPE',
        'EtudeMaster.IdEtape' => 'ID_ETAPE',
        'idEtape' => 'ID_ETAPE',
        'etudeMaster.idEtape' => 'ID_ETAPE',
        'EtudeMasterTableMap::COL_ID_ETAPE' => 'ID_ETAPE',
        'COL_ID_ETAPE' => 'ID_ETAPE',
        'id_etape' => 'ID_ETAPE',
        'etude_master.id_etape' => 'ID_ETAPE',
        'PrixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'EtudeMaster.PrixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'prixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'etudeMaster.prixRevientInitial' => 'PRIX_REVIENT_INITIAL',
        'EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL' => 'PRIX_REVIENT_INITIAL',
        'COL_PRIX_REVIENT_INITIAL' => 'PRIX_REVIENT_INITIAL',
        'prix_revient_initial' => 'PRIX_REVIENT_INITIAL',
        'etude_master.prix_revient_initial' => 'PRIX_REVIENT_INITIAL',
        'PrixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'EtudeMaster.PrixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'prixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'etudeMaster.prixRevientActualise' => 'PRIX_REVIENT_ACTUALISE',
        'EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE' => 'PRIX_REVIENT_ACTUALISE',
        'COL_PRIX_REVIENT_ACTUALISE' => 'PRIX_REVIENT_ACTUALISE',
        'prix_revient_actualise' => 'PRIX_REVIENT_ACTUALISE',
        'etude_master.prix_revient_actualise' => 'PRIX_REVIENT_ACTUALISE',
        'PrixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'EtudeMaster.PrixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'prixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'etudeMaster.prixVenteInitial' => 'PRIX_VENTE_INITIAL',
        'EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL' => 'PRIX_VENTE_INITIAL',
        'COL_PRIX_VENTE_INITIAL' => 'PRIX_VENTE_INITIAL',
        'prix_vente_initial' => 'PRIX_VENTE_INITIAL',
        'etude_master.prix_vente_initial' => 'PRIX_VENTE_INITIAL',
        'PrixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'EtudeMaster.PrixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'prixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'etudeMaster.prixVenteActualise' => 'PRIX_VENTE_ACTUALISE',
        'EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE' => 'PRIX_VENTE_ACTUALISE',
        'COL_PRIX_VENTE_ACTUALISE' => 'PRIX_VENTE_ACTUALISE',
        'prix_vente_actualise' => 'PRIX_VENTE_ACTUALISE',
        'etude_master.prix_vente_actualise' => 'PRIX_VENTE_ACTUALISE',
        'NumeroFacture' => 'NUMERO_FACTURE',
        'EtudeMaster.NumeroFacture' => 'NUMERO_FACTURE',
        'numeroFacture' => 'NUMERO_FACTURE',
        'etudeMaster.numeroFacture' => 'NUMERO_FACTURE',
        'EtudeMasterTableMap::COL_NUMERO_FACTURE' => 'NUMERO_FACTURE',
        'COL_NUMERO_FACTURE' => 'NUMERO_FACTURE',
        'numero_facture' => 'NUMERO_FACTURE',
        'etude_master.numero_facture' => 'NUMERO_FACTURE',
        'DateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'EtudeMaster.DateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'dateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'etudeMaster.dateEnvoiFacture' => 'DATE_ENVOI_FACTURE',
        'EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE' => 'DATE_ENVOI_FACTURE',
        'COL_DATE_ENVOI_FACTURE' => 'DATE_ENVOI_FACTURE',
        'date_envoi_facture' => 'DATE_ENVOI_FACTURE',
        'etude_master.date_envoi_facture' => 'DATE_ENVOI_FACTURE',
        'DateReglement' => 'DATE_REGLEMENT',
        'EtudeMaster.DateReglement' => 'DATE_REGLEMENT',
        'dateReglement' => 'DATE_REGLEMENT',
        'etudeMaster.dateReglement' => 'DATE_REGLEMENT',
        'EtudeMasterTableMap::COL_DATE_REGLEMENT' => 'DATE_REGLEMENT',
        'COL_DATE_REGLEMENT' => 'DATE_REGLEMENT',
        'date_reglement' => 'DATE_REGLEMENT',
        'etude_master.date_reglement' => 'DATE_REGLEMENT',
        'Commentaire' => 'COMMENTAIRE',
        'EtudeMaster.Commentaire' => 'COMMENTAIRE',
        'commentaire' => 'COMMENTAIRE',
        'etudeMaster.commentaire' => 'COMMENTAIRE',
        'EtudeMasterTableMap::COL_COMMENTAIRE' => 'COMMENTAIRE',
        'COL_COMMENTAIRE' => 'COMMENTAIRE',
        'etude_master.commentaire' => 'COMMENTAIRE',
        'IndustryId' => 'INDUSTRY_ID',
        'EtudeMaster.IndustryId' => 'INDUSTRY_ID',
        'industryId' => 'INDUSTRY_ID',
        'etudeMaster.industryId' => 'INDUSTRY_ID',
        'EtudeMasterTableMap::COL_INDUSTRY_ID' => 'INDUSTRY_ID',
        'COL_INDUSTRY_ID' => 'INDUSTRY_ID',
        'industry_id' => 'INDUSTRY_ID',
        'etude_master.industry_id' => 'INDUSTRY_ID',
        'PeriodeCutoff' => 'PERIODE_CUTOFF',
        'EtudeMaster.PeriodeCutoff' => 'PERIODE_CUTOFF',
        'periodeCutoff' => 'PERIODE_CUTOFF',
        'etudeMaster.periodeCutoff' => 'PERIODE_CUTOFF',
        'EtudeMasterTableMap::COL_PERIODE_CUTOFF' => 'PERIODE_CUTOFF',
        'COL_PERIODE_CUTOFF' => 'PERIODE_CUTOFF',
        'periode_cutoff' => 'PERIODE_CUTOFF',
        'etude_master.periode_cutoff' => 'PERIODE_CUTOFF',
        'ThemeBr' => 'THEME_BR',
        'EtudeMaster.ThemeBr' => 'THEME_BR',
        'themeBr' => 'THEME_BR',
        'etudeMaster.themeBr' => 'THEME_BR',
        'EtudeMasterTableMap::COL_THEME_BR' => 'THEME_BR',
        'COL_THEME_BR' => 'THEME_BR',
        'theme_br' => 'THEME_BR',
        'etude_master.theme_br' => 'THEME_BR',
        'AreaId' => 'AREA_ID',
        'EtudeMaster.AreaId' => 'AREA_ID',
        'areaId' => 'AREA_ID',
        'etudeMaster.areaId' => 'AREA_ID',
        'EtudeMasterTableMap::COL_AREA_ID' => 'AREA_ID',
        'COL_AREA_ID' => 'AREA_ID',
        'area_id' => 'AREA_ID',
        'etude_master.area_id' => 'AREA_ID',
        'IdQq' => 'ID_QQ',
        'EtudeMaster.IdQq' => 'ID_QQ',
        'idQq' => 'ID_QQ',
        'etudeMaster.idQq' => 'ID_QQ',
        'EtudeMasterTableMap::COL_ID_QQ' => 'ID_QQ',
        'COL_ID_QQ' => 'ID_QQ',
        'id_qq' => 'ID_QQ',
        'etude_master.id_qq' => 'ID_QQ',
        'IdSamsStudy' => 'ID_SAMS_STUDY',
        'EtudeMaster.IdSamsStudy' => 'ID_SAMS_STUDY',
        'idSamsStudy' => 'ID_SAMS_STUDY',
        'etudeMaster.idSamsStudy' => 'ID_SAMS_STUDY',
        'EtudeMasterTableMap::COL_ID_SAMS_STUDY' => 'ID_SAMS_STUDY',
        'COL_ID_SAMS_STUDY' => 'ID_SAMS_STUDY',
        'id_sams_study' => 'ID_SAMS_STUDY',
        'etude_master.id_sams_study' => 'ID_SAMS_STUDY',
        'RecrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'EtudeMaster.RecrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'recrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'etudeMaster.recrutementObjectif' => 'RECRUTEMENT_OBJECTIF',
        'EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF' => 'RECRUTEMENT_OBJECTIF',
        'COL_RECRUTEMENT_OBJECTIF' => 'RECRUTEMENT_OBJECTIF',
        'recrutement_objectif' => 'RECRUTEMENT_OBJECTIF',
        'etude_master.recrutement_objectif' => 'RECRUTEMENT_OBJECTIF',
        'IdLocationPnl' => 'ID_LOCATION_PNL',
        'EtudeMaster.IdLocationPnl' => 'ID_LOCATION_PNL',
        'idLocationPnl' => 'ID_LOCATION_PNL',
        'etudeMaster.idLocationPnl' => 'ID_LOCATION_PNL',
        'EtudeMasterTableMap::COL_ID_LOCATION_PNL' => 'ID_LOCATION_PNL',
        'COL_ID_LOCATION_PNL' => 'ID_LOCATION_PNL',
        'id_location_pnl' => 'ID_LOCATION_PNL',
        'etude_master.id_location_pnl' => 'ID_LOCATION_PNL',
        'Durationstudy' => 'DURATIONSTUDY',
        'EtudeMaster.Durationstudy' => 'DURATIONSTUDY',
        'durationstudy' => 'DURATIONSTUDY',
        'etudeMaster.durationstudy' => 'DURATIONSTUDY',
        'EtudeMasterTableMap::COL_DURATIONSTUDY' => 'DURATIONSTUDY',
        'COL_DURATIONSTUDY' => 'DURATIONSTUDY',
        'durationStudy' => 'DURATIONSTUDY',
        'etude_master.durationStudy' => 'DURATIONSTUDY',
        'RecrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'EtudeMaster.RecrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'recrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'etudeMaster.recrutementObjectifPr' => 'RECRUTEMENT_OBJECTIF_PR',
        'EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR' => 'RECRUTEMENT_OBJECTIF_PR',
        'COL_RECRUTEMENT_OBJECTIF_PR' => 'RECRUTEMENT_OBJECTIF_PR',
        'recrutement_objectif_pr' => 'RECRUTEMENT_OBJECTIF_PR',
        'etude_master.recrutement_objectif_pr' => 'RECRUTEMENT_OBJECTIF_PR',
        'IdBm' => 'ID_BM',
        'EtudeMaster.IdBm' => 'ID_BM',
        'idBm' => 'ID_BM',
        'etudeMaster.idBm' => 'ID_BM',
        'EtudeMasterTableMap::COL_ID_BM' => 'ID_BM',
        'COL_ID_BM' => 'ID_BM',
        'id_bm' => 'ID_BM',
        'etude_master.id_bm' => 'ID_BM',
        'AccountId' => 'ACCOUNT_ID',
        'EtudeMaster.AccountId' => 'ACCOUNT_ID',
        'accountId' => 'ACCOUNT_ID',
        'etudeMaster.accountId' => 'ACCOUNT_ID',
        'EtudeMasterTableMap::COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'COL_ACCOUNT_ID' => 'ACCOUNT_ID',
        'account_id' => 'ACCOUNT_ID',
        'etude_master.account_id' => 'ACCOUNT_ID',
        'RemiseTaux' => 'REMISE_TAUX',
        'EtudeMaster.RemiseTaux' => 'REMISE_TAUX',
        'remiseTaux' => 'REMISE_TAUX',
        'etudeMaster.remiseTaux' => 'REMISE_TAUX',
        'EtudeMasterTableMap::COL_REMISE_TAUX' => 'REMISE_TAUX',
        'COL_REMISE_TAUX' => 'REMISE_TAUX',
        'remise_taux' => 'REMISE_TAUX',
        'etude_master.remise_taux' => 'REMISE_TAUX',
        'Language' => 'LANGUAGE',
        'EtudeMaster.Language' => 'LANGUAGE',
        'language' => 'LANGUAGE',
        'etudeMaster.language' => 'LANGUAGE',
        'EtudeMasterTableMap::COL_LANGUAGE' => 'LANGUAGE',
        'COL_LANGUAGE' => 'LANGUAGE',
        'etude_master.language' => 'LANGUAGE',
        'Kol' => 'KOL',
        'EtudeMaster.Kol' => 'KOL',
        'kol' => 'KOL',
        'etudeMaster.kol' => 'KOL',
        'EtudeMasterTableMap::COL_KOL' => 'KOL',
        'COL_KOL' => 'KOL',
        'etude_master.kol' => 'KOL',
        'SmsRelance' => 'SMS_RELANCE',
        'EtudeMaster.SmsRelance' => 'SMS_RELANCE',
        'smsRelance' => 'SMS_RELANCE',
        'etudeMaster.smsRelance' => 'SMS_RELANCE',
        'EtudeMasterTableMap::COL_SMS_RELANCE' => 'SMS_RELANCE',
        'COL_SMS_RELANCE' => 'SMS_RELANCE',
        'sms_relance' => 'SMS_RELANCE',
        'etude_master.sms_relance' => 'SMS_RELANCE',
        'Gms' => 'GMS',
        'EtudeMaster.Gms' => 'GMS',
        'gms' => 'GMS',
        'etudeMaster.gms' => 'GMS',
        'EtudeMasterTableMap::COL_GMS' => 'GMS',
        'COL_GMS' => 'GMS',
        'etude_master.gms' => 'GMS',
    ];

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('etude_master');
        $this->setPhpName('EtudeMaster');
        $this->setIdentifierQuoting(true);
        $this->setClassName('\\Model\\EtudeMaster');
        $this->setPackage('src.Model');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('id', 'Id', 'INTEGER', true, 8, null);
        $this->addColumn('numero_etude', 'NumeroEtude', 'CHAR', true, 9, null);
        $this->addColumn('reference_client', 'ReferenceClient', 'LONGVARCHAR', true, null, null);
        $this->addColumn('theme', 'Theme', 'VARCHAR', false, 255, null);
        $this->addColumn('date_debut', 'DateDebut', 'DATE', true, null, null);
        $this->addColumn('date_fin', 'DateFin', 'DATE', true, null, null);
        $this->addColumn('annee', 'Annee', 'VARCHAR', true, 4, null);
        $this->addColumn('id_pm', 'IdPm', 'INTEGER', true, 8, null);
        $this->addForeignKey('id_etape', 'IdEtape', 'INTEGER', 'ref_etape', 'id', true, 8, null);
        $this->addColumn('prix_revient_initial', 'PrixRevientInitial', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_revient_actualise', 'PrixRevientActualise', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_vente_initial', 'PrixVenteInitial', 'DECIMAL', true, 15, null);
        $this->addColumn('prix_vente_actualise', 'PrixVenteActualise', 'DECIMAL', true, 15, null);
        $this->addColumn('numero_facture', 'NumeroFacture', 'VARCHAR', false, 50, null);
        $this->addColumn('date_envoi_facture', 'DateEnvoiFacture', 'DATE', false, null, null);
        $this->addColumn('date_reglement', 'DateReglement', 'DATE', false, null, null);
        $this->addColumn('commentaire', 'Commentaire', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('industry_id', 'IndustryId', 'INTEGER', 'ref_industry', 'id', true, 8, null);
        $this->addColumn('periode_cutoff', 'PeriodeCutoff', 'VARCHAR', true, 7, null);
        $this->addColumn('theme_br', 'ThemeBr', 'VARCHAR', true, 255, null);
        $this->addForeignKey('area_id', 'AreaId', 'INTEGER', 'ref_area', 'id', false, 4, null);
        $this->addColumn('id_qq', 'IdQq', 'INTEGER', true, 8, null);
        $this->addColumn('id_sams_study', 'IdSamsStudy', 'VARCHAR', true, 50, null);
        $this->addColumn('recrutement_objectif', 'RecrutementObjectif', 'INTEGER', true, 3, null);
        $this->addColumn('id_location_pnl', 'IdLocationPnl', 'INTEGER', true, 3, null);
        $this->addColumn('durationStudy', 'Durationstudy', 'VARCHAR', true, 10, null);
        $this->addColumn('recrutement_objectif_pr', 'RecrutementObjectifPr', 'INTEGER', true, 3, null);
        $this->addColumn('id_bm', 'IdBm', 'INTEGER', true, 8, null);
        $this->addForeignKey('account_id', 'AccountId', 'INTEGER', 'sf_account', 'id', false, null, null);
        $this->addColumn('remise_taux', 'RemiseTaux', 'DECIMAL', false, 4, null);
        $this->addColumn('language', 'Language', 'VARCHAR', false, 3, null);
        $this->addColumn('kol', 'Kol', 'VARCHAR', false, 1, null);
        $this->addColumn('sms_relance', 'SmsRelance', 'VARCHAR', false, 1, null);
        $this->addColumn('gms', 'Gms', 'VARCHAR', false, 1, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('EtudeMasterArea', '\\Model\\Area', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':area_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Account', '\\Model\\Account', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':account_id',
    1 => ':id',
  ),
), 'SET NULL', 'CASCADE', null, false);
        $this->addRelation('Industry', '\\Model\\Industry', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':industry_id',
    1 => ':id',
  ),
), null, null, null, false);
        $this->addRelation('Etape', '\\Model\\Etape', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':id_etape',
    1 => ':id',
  ),
), null, null, null, false);
    } // buildRelations()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return null === $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] || is_scalar($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)]) || is_callable([$row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)], '__toString']) ? (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)] : $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }

    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? EtudeMasterTableMap::CLASS_DEFAULT : EtudeMasterTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (EtudeMaster object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = EtudeMasterTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = EtudeMasterTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + EtudeMasterTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = EtudeMasterTableMap::OM_CLASS;
            /** @var EtudeMaster $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            EtudeMasterTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = EtudeMasterTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = EtudeMasterTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var EtudeMaster $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                EtudeMasterTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_NUMERO_ETUDE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_REFERENCE_CLIENT);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_THEME);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_DATE_DEBUT);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_DATE_FIN);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ANNEE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_PM);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_ETAPE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_NUMERO_FACTURE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_DATE_REGLEMENT);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_COMMENTAIRE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_INDUSTRY_ID);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_PERIODE_CUTOFF);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_THEME_BR);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_AREA_ID);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_QQ);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_SAMS_STUDY);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_LOCATION_PNL);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_DURATIONSTUDY);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ID_BM);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_ACCOUNT_ID);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_REMISE_TAUX);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_LANGUAGE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_KOL);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_SMS_RELANCE);
            $criteria->addSelectColumn(EtudeMasterTableMap::COL_GMS);
        } else {
            $criteria->addSelectColumn($alias . '.id');
            $criteria->addSelectColumn($alias . '.numero_etude');
            $criteria->addSelectColumn($alias . '.reference_client');
            $criteria->addSelectColumn($alias . '.theme');
            $criteria->addSelectColumn($alias . '.date_debut');
            $criteria->addSelectColumn($alias . '.date_fin');
            $criteria->addSelectColumn($alias . '.annee');
            $criteria->addSelectColumn($alias . '.id_pm');
            $criteria->addSelectColumn($alias . '.id_etape');
            $criteria->addSelectColumn($alias . '.prix_revient_initial');
            $criteria->addSelectColumn($alias . '.prix_revient_actualise');
            $criteria->addSelectColumn($alias . '.prix_vente_initial');
            $criteria->addSelectColumn($alias . '.prix_vente_actualise');
            $criteria->addSelectColumn($alias . '.numero_facture');
            $criteria->addSelectColumn($alias . '.date_envoi_facture');
            $criteria->addSelectColumn($alias . '.date_reglement');
            $criteria->addSelectColumn($alias . '.commentaire');
            $criteria->addSelectColumn($alias . '.industry_id');
            $criteria->addSelectColumn($alias . '.periode_cutoff');
            $criteria->addSelectColumn($alias . '.theme_br');
            $criteria->addSelectColumn($alias . '.area_id');
            $criteria->addSelectColumn($alias . '.id_qq');
            $criteria->addSelectColumn($alias . '.id_sams_study');
            $criteria->addSelectColumn($alias . '.recrutement_objectif');
            $criteria->addSelectColumn($alias . '.id_location_pnl');
            $criteria->addSelectColumn($alias . '.durationStudy');
            $criteria->addSelectColumn($alias . '.recrutement_objectif_pr');
            $criteria->addSelectColumn($alias . '.id_bm');
            $criteria->addSelectColumn($alias . '.account_id');
            $criteria->addSelectColumn($alias . '.remise_taux');
            $criteria->addSelectColumn($alias . '.language');
            $criteria->addSelectColumn($alias . '.kol');
            $criteria->addSelectColumn($alias . '.sms_relance');
            $criteria->addSelectColumn($alias . '.gms');
        }
    }

    /**
     * Remove all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be removed as they are only loaded on demand.
     *
     * @param Criteria $criteria object containing the columns to remove.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function removeSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_NUMERO_ETUDE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_REFERENCE_CLIENT);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_THEME);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_DATE_DEBUT);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_DATE_FIN);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ANNEE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_PM);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_ETAPE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_NUMERO_FACTURE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_DATE_REGLEMENT);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_COMMENTAIRE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_INDUSTRY_ID);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_PERIODE_CUTOFF);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_THEME_BR);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_AREA_ID);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_QQ);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_SAMS_STUDY);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_LOCATION_PNL);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_DURATIONSTUDY);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ID_BM);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_ACCOUNT_ID);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_REMISE_TAUX);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_LANGUAGE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_KOL);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_SMS_RELANCE);
            $criteria->removeSelectColumn(EtudeMasterTableMap::COL_GMS);
        } else {
            $criteria->removeSelectColumn($alias . '.id');
            $criteria->removeSelectColumn($alias . '.numero_etude');
            $criteria->removeSelectColumn($alias . '.reference_client');
            $criteria->removeSelectColumn($alias . '.theme');
            $criteria->removeSelectColumn($alias . '.date_debut');
            $criteria->removeSelectColumn($alias . '.date_fin');
            $criteria->removeSelectColumn($alias . '.annee');
            $criteria->removeSelectColumn($alias . '.id_pm');
            $criteria->removeSelectColumn($alias . '.id_etape');
            $criteria->removeSelectColumn($alias . '.prix_revient_initial');
            $criteria->removeSelectColumn($alias . '.prix_revient_actualise');
            $criteria->removeSelectColumn($alias . '.prix_vente_initial');
            $criteria->removeSelectColumn($alias . '.prix_vente_actualise');
            $criteria->removeSelectColumn($alias . '.numero_facture');
            $criteria->removeSelectColumn($alias . '.date_envoi_facture');
            $criteria->removeSelectColumn($alias . '.date_reglement');
            $criteria->removeSelectColumn($alias . '.commentaire');
            $criteria->removeSelectColumn($alias . '.industry_id');
            $criteria->removeSelectColumn($alias . '.periode_cutoff');
            $criteria->removeSelectColumn($alias . '.theme_br');
            $criteria->removeSelectColumn($alias . '.area_id');
            $criteria->removeSelectColumn($alias . '.id_qq');
            $criteria->removeSelectColumn($alias . '.id_sams_study');
            $criteria->removeSelectColumn($alias . '.recrutement_objectif');
            $criteria->removeSelectColumn($alias . '.id_location_pnl');
            $criteria->removeSelectColumn($alias . '.durationStudy');
            $criteria->removeSelectColumn($alias . '.recrutement_objectif_pr');
            $criteria->removeSelectColumn($alias . '.id_bm');
            $criteria->removeSelectColumn($alias . '.account_id');
            $criteria->removeSelectColumn($alias . '.remise_taux');
            $criteria->removeSelectColumn($alias . '.language');
            $criteria->removeSelectColumn($alias . '.kol');
            $criteria->removeSelectColumn($alias . '.sms_relance');
            $criteria->removeSelectColumn($alias . '.gms');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(EtudeMasterTableMap::DATABASE_NAME)->getTable(EtudeMasterTableMap::TABLE_NAME);
    }

    /**
     * Performs a DELETE on the database, given a EtudeMaster or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or EtudeMaster object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeMasterTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \Model\EtudeMaster) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(EtudeMasterTableMap::DATABASE_NAME);
            $criteria->add(EtudeMasterTableMap::COL_ID, (array) $values, Criteria::IN);
        }

        $query = EtudeMasterQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            EtudeMasterTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                EtudeMasterTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the etude_master table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return EtudeMasterQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a EtudeMaster or Criteria object.
     *
     * @param mixed               $criteria Criteria or EtudeMaster object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeMasterTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from EtudeMaster object
        }

        if ($criteria->containsKey(EtudeMasterTableMap::COL_ID) && $criteria->keyContainsValue(EtudeMasterTableMap::COL_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.EtudeMasterTableMap::COL_ID.')');
        }


        // Set the correct dbName
        $query = EtudeMasterQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // EtudeMasterTableMap
