<?php

namespace Model;

use Model\Base\Event as BaseEvent;
use Model\Map\EventTableMap;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Map\TableMap;

class Event extends BaseEvent
{
    const FIELDS_ISO_DATE = [
        'created_date',
    ];

    const FIELDS_SHORT_DATETIME = [
        'end_date_time',
        'start_date_time',
    ];

    const FIELDS_LOCATION = [
        'location_c',
    ];

    const FIELDS_PICKLIST = [
        'record_type',
        'event_sub_type',
    ];

    const FIELDS_USER = [
        'assigned_to',
    ];

    const DAY = 'day';
    const HALF_A_DAY = 'half a day';
    const EVENING = 'evening';
    const DAY_EVENING = 'day + evening';
    const AFTERNOON_EVENING = 'afternoon + evening';
    const EVENT_TYPE_VIEW_TASK = 'task';
    const EVENT_TYPE_VIEW_TIME = 'time';
    const OFFSITE_NAMES = ['20/20', 'offsite', 'off site', 'off-site'];

    const FIELD_PMTOOL_ID = [
        'de' => 'Schmiedl_PM_Tool_ID__c',
        'es' => 'Spain_PM_Tool_ID__c',
        'fr' => 'Consumed_PM_Tool_ID__c',
        'uk' => 'UK_PM_Tool_ID__c',
        'us' => 'PM_Tool_ID__c',
    ];

    const NOT_NEW_STATUS_EVENT = [
        RefEventStatus::TENTATIVE,
        RefEventStatus::RELEASED,
        RefEventStatus::CANCELLED_NON_BILLED,
    ];

    private static $events;

    public function calculeMaxId()
    {
        $maxId = 0;
        foreach ($this->getModules() as $module) {
            if ($module->getNumeroLigne() > $maxId) {
                $maxId = $module->getNumeroLigne();
            }
        }

        return $maxId;
    }

    public static function getPMToolFieldName($fieldName)
    {
        return EventTableMap::translateFieldName($fieldName, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME);
    }

    public function copyDateToStartEndTimes(): self
    {
        $dateMeeting = $this->getDate('Y-m-d');
        $startTime = $this->getStartDateTime('H:i:s');
        $endTime = $this->getEndDateTime('H:i:s');

        if ($dateMeeting && $startTime) {
            $this->setStartDateTime("$dateMeeting $startTime");
        }
        if ($dateMeeting && $endTime) {
            $this->setEndDateTime("$dateMeeting $endTime");
        }

        return $this;
    }

    public function toArrayWithCollection()
    {
        $job = $this->getJob();
        $result = [
            'pmtool_id' => $this->getId(),
            'account_id' => $this->getAccountId(),
            'activity_currency' => $this->getActivityCurrency(),
            'sams_event_id' => $this->getSamsEventId(),
            'all_day_event' => $this->getAllDayEvent(),
            'archived' => $this->getArchived(),
            'assigned_to' => $this->getAssignedTo() ? $this->getAssignedTo()->getSfId() : '',
            'cancelled' => $this->getCancelled(),
            'created_date' => $this->getCreatedDate(),
            'recurring_event' => $this->getRecurringEvent(),
            'is_deleted' => $this->getIsDeleted(),
            'is_deleted_c' => $this->getIsDeletedC(),
            'description' => $this->getDescription(),
            'event_date' => $this->getDate(),
            'duration_minutes' => $this->getDurationMinutes(),
            'end_date_time' => $this->getEndDateTime(),
            'record_type' => $this->getRecordType(),
            'event_sub_type' => $this->getEventSubType(),
            'job_status' => $job ? $job->getStatus() : '',
            'location_c' => $job ? $job->getJobLocation() : '',
            'job_sf_id' => $job ? $job->getJobSfId() : '',
            'reminder_date' => $this->getReminderDate(),
            'reminder_set' => $this->getReminderSet(),
            'room' => $this->getRefRoom() ? $this->getRefRoom()->getName() : '',
            'start_date_time' => $this->getStartDateTime(),
            'subject' => $job && $job->getEtude() ? $job->getEtude()->getTheme() : '',
            'recurrence_time_zone' => $this->getRecurrenceTimeZone(),
            'created_by_sf_id' => $this->getCreatedBySfId(),
            'event_methodology' => $this->getEventMethodology() ? $this->getEventMethodology()->getSamsLabel() : '',
        ];
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        return $result;
    }

    public function toXMLForSalesForce()
    {
        $array = [];
        foreach ($this->toArrayWithCollection() as $key => $value) {
            if (is_bool($value)) {
                $value = (int) $value;
            } elseif ($value instanceof \DateTime) {
                $value = in_array($key, self::FIELDS_ISO_DATE)
                    ? $value->format('Y-m-d\TH:i:s.uP')
                    : (in_array($key, self::FIELDS_SHORT_DATETIME) ? $value->format('Y-m-d h:i:s A') : $value->format('Y-m-d'));
            } elseif (in_array($key, self::FIELDS_PICKLIST) && $value) {
                if ($ref = RefSalesForceQuery::create()->filterById($value)->findOne()) {
                    $value = $ref->getValue();
                }
            } elseif (in_array($key, self::FIELDS_LOCATION) && $value) {
                if ($ref = LocationQuery::create()->filterById($value->getId())->filterByActive(1)->findOne()) {
                    $value = $ref->getSfLabel();
                }
            }

            if ([] === $value) {
                $value = '';
            }

            $array[$key] = $value;
        }

        $xml = PHP_EOL.'<Event>'.PHP_EOL;
        foreach ($array as $key => $value) {
            $xml .= (null === $value || '' === $value || 'pmtool_id' == $key) ? "<{$key}>{$value}</{$key}>".PHP_EOL : "<{$key}><![CDATA[{$value}]]></{$key}>".PHP_EOL;
        }

        return $xml.'</Event>';
    }

    public function setAccountsAndContactsFromSalesForce()
    {
        if ($this->getAccountSfId() && (in_array(EventTableMap::COL_ACCOUNT_SF_ID, $this->getModifiedColumns())) && ($account = AccountQuery::create()->findOneBySfId($this->getAccountSfId()))) {
            $this->setAccountId($account->getId());
        }

        return $this;
    }

    public function setSfAccountAndSfContactFromPmTool()
    {
        if ($account = $this->getAccount()) {
            $this->setAccountSfId($account->getSfId());
        }

        return $this;
    }

    public static function getById($id)
    {
        return self::$events[$id] ?? self::$events[$id] = EventQuery::create()->findOneById($id);
    }

    public function preSave(ConnectionInterface $con = null)
    {
        $job = $this->getJob();
        if ($job && !$job->getOffsiteLocationId()) {
            if ($this->isOffsite()) {
                $this->setSiteId(null);
            } else {
                $location = $job->getJobLocation() ? $job->getJobLocation()->getLibelle() : '-';

                if ($site = SiteQuery::create()->findOneBySamsLocation($location)) {
                    $this->setSiteId($site->getId());
                }
            }
        }

        if (count($this->getModifiedColumns()) && !$this->isColumnModified(EventTableMap::COL_PMTOOL_UPDATED)) {
            $this->setPmtoolUpdated(true);
        }

        if (!$this->getEventStatusId() && ($name = trim($this->getJobStatus()))
            && $status = RefEventStatusQuery::create()->filterByName($name)->findOne()) {
            $this->setRefEventStatus($status);
        }

        if ($this->getRefEventStatus() && in_array($this->getRefEventStatus()->getName(), [RefEventStatus::ACTIVE, RefEventStatus::CONFIRMED])) {
            if (null === $this->getActiveDate() && RefEventStatus::ACTIVE == $this->getRefEventStatus()->getName()) {
                $this->setActiveDate(new \DateTime());
            } elseif (null === $this->getConfirmedDate() && RefEventStatus::CONFIRMED == $this->getRefEventStatus()->getName()) {
                $this->setConfirmedDate(new \DateTime());
            }
        }

        return parent::preSave($con);
    }

    public function getEventContact(): ?Contact
    {
        $bidJob = $this->getBidJob();
        $job = $this->getJob();
        if ($bidJob && $this->getJob() && $etude = $job->getEtude()) {
            return $etude->getContact();
        } elseif ($bidJob && $bidJob->getBid() && $opportunity = $bidJob->getBid()->getOpportunity()) {
            return $opportunity->getContact();
        } elseif ($job && $etude = $job->getEtude()) {
            return $etude->getContact();
        }

        return null;
    }

    public function getEventAccount(): ?Account
    {
        $bidJob = $this->getBidJob();
        $job = $this->getJob();
        if ($bidJob && $this->getJob() && $etude = $job->getEtude()) {
            return $etude->getAccount();
        } elseif ($bidJob && $bidJob->getBid() && $opportunity = $bidJob->getBid()->getOpportunity()) {
            return $opportunity->getAccount();
        } elseif ($job && $etude = $job->getEtude()) {
            return $etude->getAccount();
        }

        return null;
    }

    public function getEventHolderName(): string
    {
        return $this->getEventHolderBy() ? $this->getEventHolderBy()->getNomComplet() : '';
    }

    public function getEventStudySpecification(): string
    {
        $bidJob = $this->getBidJob();
        $job = $this->getJob();
        if ($bidJob && $this->getJob() && $etude = $job->getEtude()) {
            return (string) $etude->getStudySpecification();
        } elseif ($bidJob && $bidJob->getBid() && $opportunity = $bidJob->getBid()->getOpportunity()) {
            return (string) $opportunity->getStudySpecification();
        } elseif ($job && $etude = $job->getEtude()) {
            return (string) $etude->getStudySpecification();
        }

        return '';
    }

    public function getEventProjectNumber(): string
    {
        if ($this->getBidJob() && $this->getJob() && $etude = $this->getJob()->getEtude()) {
            return $etude->getNumeroEtude();
        } elseif ($this->getBidJob()) {
            return '';
        } elseif ($this->getJob() && $etude = $this->getJob()->getEtude()) {
            return $etude->getNumeroEtude();
        }

        return '';
    }

    public function getEventSubjectOrLocalSubject(): string
    {
        $bidJob = $this->getBidJob();
        $job = $this->getJob();
        if ($bidJob && $this->getJob() && $etude = $job->getEtude()) {
            return $etude->getTheme();
        } elseif ($bidJob && $bidJob->getBid() && $opportunity = $bidJob->getBid()->getOpportunity()) {
            return $opportunity->getOpportunitySubject() ?? '';
        } elseif ($job && $etude = $job->getEtude()) {
            return $etude->getTheme();
        }

        return '';
    }

    public static function orderByDateAndStartDate($events)
    {
        if (!is_null($events)) {
            usort($events, function ($a, $b) {
                return strtotime($a->getDate('Y-m-d')) - strtotime($b->getDate('Y-m-d'));
            });
            usort($events, function ($a, $b) {
                return strtotime($a->getStartDateTime('Y-m-d H:i:s')) - strtotime($b->getStartDateTime('Y-m-d H:i:s'));
            });
        }

        return $events;
    }

    public function getTimeZone(): string
    {
        $location = $this->getJob() ? ($this->getJob()->getJobLocation() ? $this->getJob()->getJobLocation()->getLibelle() : '-') : '-';

        if (in_array($location, Location::EST)) {
            return 'EST';
        } elseif (in_array($location, Location::CST)) {
            return 'CST';
        } elseif (in_array($location, Location::PST)) {
            return 'PST';
        } elseif (in_array($location, Location::MST)) {
            return 'MST';
        }

        return '~';
    }

    /**
     * Event if offsite if it's room name contains 'offsite' or '20/20'.
     */
    public function isOffsite(): bool
    {
        $room = $this->getRefRoom() ? strtolower($this->getRefRoom()->getName()) : '';

        foreach (self::OFFSITE_NAMES as $offsite) {
            if (false !== strpos($room, $offsite)) {
                return true;
            }
        }

        return false;
    }

    public function isEventRoomSalleDinter($eventRoomName): bool
    {
        return in_array($eventRoomName, ['Madeleine', 'Bercy']);
    }

    public function postDelete(ConnectionInterface $con = null)
    {
        $id = $this->getId();

        (new LogEvent())
            ->setObjectId($id)
            ->setUserId(User::getIdFromSession())
            ->setDate(new \DateTime())
            ->setevent("Event $id deleted")
            ->save();
    }

    public function getLocation()
    {
        if ($this->getJob() && $this->getJob()->getJobLocation()) {
            return $this->getJob()->getJobLocation();
        } elseif ($this->getBidJob() && $this->getBidJob()->getLocation()) {
            return $this->getBidJob()->getLocation();
        }

        return null;
    }

    public function getCalendarSchedulesInfos(string $viewType = 'task', $opptId = null, $samsJobId = null)
    {
        $bidJob = $this->getBidJob();
        $job = $this->getJob();

        $bgColor = $this->getRefEventStatus() ? $this->getRefEventStatus()->getColor() : '#000';
        if ($opptId && !$samsJobId) {
            $opportunityId = $bidJob && $bidJob->getBid() ? $bidJob->getBid()->getOpportunityId() : '';
            if ($opptId == $opportunityId) {
                $bgColor = $this->hex2rgbaEventsBgColor($bgColor, 1);
            } else {
                $bgColor = $this->hex2rgbaEventsBgColor($bgColor, 0.3);
            }
        } elseif (!$opptId && $samsJobId) {
            if ($job && $job->getIdSamsJob()) {
                $idSamsJob = $job->getIdSamsJob();
            } elseif ($job && $job->getJobSlug()) {
                $idSamsJob = $job->getJobSlug();
            } else {
                $idSamsJob = null;
            }

            if ($samsJobId == $idSamsJob) {
                $bgColor = $this->hex2rgbaEventsBgColor($bgColor, 1);
            } else {
                $bgColor = $this->hex2rgbaEventsBgColor($bgColor, 0.3);
            }
        }

        $location = $this->getLocation();
        $account = $this->getEventAccount();
        $contact = $this->getEventContact();
        $eventDetailsOnHover = $this->getEventDetailsOnHover($account);
        $opportunity = ($bidJob && $bidJob->getBid()) ? $bidJob->getBid()->getOpportunity() : null;
        $masterProjectNumberLastFourDigit = null;
        $bidNumber = null;
        $zendeskId = null;

        $category = self::EVENT_TYPE_VIEW_TASK;
        if (self::EVENT_TYPE_VIEW_TIME == $viewType) {
            $category = $this->getStartDateTime('Y-m-d') !== $this->getEndDateTime('Y-m-d') ? self::EVENT_TYPE_VIEW_TASK : self::EVENT_TYPE_VIEW_TIME;
        }
        if ($job && $job->getEtude() && $job->getEtude()->getMasterProjectNumber()) {
            $masterProjectNumberLastFourDigit = substr($job->getEtude()->getMasterProjectNumber(), -4);
        }
        if ($bidJob && $bidJob->getBid() && $bidJob->getBid()->getOpportunity()) {
            $bidNumber = $bidJob->getBid()->getOpportunity()->getBidNumber2();
            $zendeskId = $bidJob->getBid()->getOpportunity()->getZendeskTicketId();
        }

        $opportunityOwnerName = '';
        if ($bidJob && $bidJob->getBid()) {
            $opportunityOwnerName = $bidJob->getBid()->getOpportunity()->getCreatorName();
        } elseif ($this->getJob() && $this->getJob()->getEtude()->getOpportunity()) {
            $opportunityOwnerName = $this->getJob()->getEtude()->getOpportunity()->getCreatorName();
        }

        return [
            'id' => $this->getId(),
            'title' => $eventDetailsOnHover,
            'isAllDay' => false,
            'start' => $this->getStartDateTime('Y-m-d\TH:i:s'),
            'end' => $this->getEndDateTime('Y-m-d\TH:i:s'),
            'isVisible' => true,
            'color' => '#ffffff',
            'bgColor' => $bgColor,
            'dragBgColor' => '#000',
            'borderColor' => $bgColor,
            'calendarId' => $this->getRefRoomId(),
            'category' => $category,
            'dueDateClass' => '',
            'customStyle' => '',
            'isPending' => false,
            'isFocused' => false,
            'isReadOnly' => false,
            'isPrivate' => false,
            'location' => $location ? $location->getLibelle() : '',
            'attendees' => '',
            'recurrenceRule' => '',
            'state' => $this->getRefEventStatus() ? $this->getRefEventStatus()->getName() : '',
            'raw' => [
                'isGrouped' => $this->getIsGroup(),
                'description' => $this->getDescription() ?: '',
                'roomId' => $this->getRefRoomId(),
                'room' => $this->getRefRoom() ? $this->getRefRoom()->getName() : '',
                'status' => $this->getEventStatusId(),
                'statusName' => $this->getRefEventStatus() ? $this->getRefEventStatus()->getName() : '',
                'methodology' => $this->getEventMethodologyId(),
                'facilityNote' => $this->getFacilityNote(),
                'job_sams_id' => $job ? $job->getIdSamsJob() : '',
                'bid_job_id' => $bidJob ? $this->getBidJobId() : '',
                'locationId' => $location ? $location->getId() : '',
                'account' => $account ? $account->getName() : '',
                'contact' => $contact ? $contact->getNomComplet() : '',
                'contactPhone' => $contact ? $contact->getPhone() : '',
                'contactMobile' => $contact ? $contact->getMobilePhone() : '',
                'clientEmail' => $contact ? $contact->getEmail() : '',
                'eventHolder' => $this->getEventHolderName() ?: '',
                'opportunityOwnerName' => $opportunityOwnerName,
                'opportunity_id' => $bidJob && $bidJob->getBid() ? $bidJob->getBid()->getOpportunityId() : null,
                'bid_number' => $bidNumber,
                'zendesk_ticket_id' => $zendeskId,
                'etude_id' => $job ? $job->getEtudeId() : null,
                'masterProjectNumberLastFourDigit' => $masterProjectNumberLastFourDigit,
                'masterProjectNumber' => $job ? $job->getEtude()->getMasterProjectNumber() : null,
                'study_specification' => $this->getEventStudySpecification() ?: '',
                'subject' => $this->getEventSubjectOrLocalSubject() ?: '',
                'project_number' => $this->getEventProjectNumber(),
                'allRooms_from_locations_linkedTo_etude_or_oppt' => $this->getRoomsFromLinkedLocations(),
                'isRepondent' => (bool) $this->countModules(),
                'generalFacilityNote' => ($job && $job->getEtude()) ? $job->getEtude()->getFaciltyNote() : ($opportunity ? $opportunity->getFaciltyNote() : ''),
                'createdDate' => $this->getCreatedDate('d/m/Y') ?? '',
            ],
        ];
    }

    public function getEventDetailsOnHover($account)
    {
        if ($job = $this->getJob()) {
            $etude = $job->getEtude() ? $job->getEtude() : null;
            $opportunity = $etude ? $etude->getOpportunity() : '';
            $masterProject = $etude ? $etude->getMasterProjectNumber().' ('.$etude->getNumeroEtude().')' : '';
            $accountManager = ($etude && $etude->getProjectAccountManager()) ? $etude->getProjectAccountManager()->getFullname() : '';
            $pm = $job->getJobProjectManager() ? $job->getJobProjectManager()->getFullname() : '';
            $subject = $etude ? $etude->getTheme() : '';
            $account = ($etude && $etude->getAccount()) ? $etude->getAccount()->getName() : '';
            $contacClientPm = $etude ? $etude->getContactClientPm() : null;
            $contactName = $contacClientPm ? $contacClientPm->getLastNameAndFirstName() : '';
            $contactPhone = $contacClientPm ? $contacClientPm->getPhone() : '';
            $contactEmail = $contacClientPm ? $contacClientPm->getEmail() : '';
            $contactPreference = $contacClientPm ? $contacClientPm->getContactPreferences() : '';
            $target = ($etude && $etude->getEtudeArea()) ? $etude->getEtudeArea()->getLibelle() : '';
            $generalFacilityNote = $etude ? $etude->getFaciltyNote() : '';

            $details = '';
            $details .= 'Job# : '.$job->getIdSamsJob()."\n";
            $details .= "Master Project #: $masterProject"."\n";
            $details .= 'Event Booked By : '.$this->getEventHolderName()."\n";
            $details .= 'Opportunity Owner Name : '.($opportunity ? $opportunity->getCreatorName() : '')."\n";
            $details .= "Sales Rep : $accountManager"."\n";
            $details .= "PM : $pm"."\n";
            $details .= "Subject : $subject"."\n";
            $details .= "Account : $account"."\n";
            $details .= "Contact Name : $contactName"."\n";
            $details .= "Contact Phone : $contactPhone"."\n";
            $details .= "Contact Email : $contactEmail"."\n";
            $details .= "Contact Preference : $contactPreference"."\n";
            $details .= "Target : $target"."\n";
            $details .= 'Facility Note : '.$this->getFacilityNote()."\n";
            $details .= 'General Facility Note : '.$generalFacilityNote."\n";

            return $details;
        } elseif ($bidJob = $this->getBidJob()) {
            $opportunity = $bidJob->getBid() ? $this->getBidJob()->getBid()->getOpportunity() : null;
            $bidNumber = $opportunity ? $opportunity->getBidNumber2() : '';
            $zendesk = $opportunity ? $opportunity->getZendeskTicketId() : '';
            $accountManager = ($opportunity && $opportunity->getOpportunityAccountManager()) ? $opportunity->getOpportunityAccountManager()->getFullname() : '';
            $subject = $opportunity ? $opportunity->getOpportunitySubject() : '';
            $account = ($opportunity && $opportunity->getAccount()) ? $opportunity->getAccount()->getName() : '';
            $accountName = ($opportunity && $opportunity->getContact()) ? $opportunity->getContact()->getLastNameAndFirstName() : '';
            $accountPhone = ($opportunity && $opportunity->getContact()) ? $opportunity->getContact()->getPhone() : '';
            $accountEmail = ($opportunity && $opportunity->getContact()) ? $opportunity->getContact()->getEmail() : '';
            $accountPreference = ($opportunity && $opportunity->getContact()) ? $opportunity->getContact()->getContactPreferences() : '';
            $generalFacilityNote = $opportunity ? $opportunity->getFaciltyNote() : '';

            $details = '';
            $details .= "Bid# : $bidNumber"."\n";
            $details .= "Zendesk# : $zendesk"."\n";
            $details .= 'Event Booked By : '.$this->getEventHolderName()."\n";
            $details .= 'Opportunity Owner Name : '.($opportunity ? $opportunity->getCreatorName() : '')."\n";
            $details .= "Sales Rep : $accountManager"."\n";
            $details .= "Subject : $subject"."\n";
            $details .= "Account : $account"."\n";
            $details .= "Contact Name : $accountName"."\n";
            $details .= "Contact Phone : $accountPhone"."\n";
            $details .= "Contact Email : $accountEmail"."\n";
            $details .= "Contact Preference : $accountPreference"."\n";
            $details .= 'Facility Note : '.$this->getFacilityNote()."\n";
            $details .= 'General Facility Note : '.$generalFacilityNote."\n";

            return $details;
        }

        return '#Job : '."\n".'Booked By : '."\n".'A/C Manager : '."\n".'PM : '."\n".'Subject : '."\n".'Phone : '."\n".'Contact Name : '."\n"
            .'Contact Email : '."\n".'Contact Preference : '."\n".'Target : '."\n".'Master Project : '."\n".'Moderator : '."\n".'Moderator Preferences: '."\n";
    }

    public function getRoomsFromLinkedLocations(): array
    {
        if ($job = $this->getJob()) {
            return RefRoom::findByLocations([$job->getLocationId()]);
        }

        return RefRoom::findByLocations([]);
    }

    protected function hex2rgbaEventsBgColor($color, $opacity = false): string
    {
        $default = 'rgb(0,0,0)';

        //Return default if no color provided
        if (empty($color)) {
            return $default;
        }

        //Sanitize $color if "#" is provided
        if ('#' == $color[0]) {
            $color = substr($color, 1);
        }

        //Check if color has 6 or 3 characters and get values
        if (6 == strlen($color)) {
            $hex = [$color[0].$color[1], $color[2].$color[3], $color[4].$color[5]];
        } elseif (3 == strlen($color)) {
            $hex = [$color[0].$color[0], $color[1].$color[1], $color[2].$color[2]];
        } else {
            return $default;
        }

        //Convert hexadec to rgb
        $rgb = array_map('hexdec', $hex);

        //Check if opacity is set(rgba or rgb)
        if ($opacity) {
            if (abs($opacity) > 1) {
                $opacity = 1.0;
            }
            $output = 'rgba('.implode(',', $rgb).','.$opacity.')';
        } else {
            $output = 'rgb('.implode(',', $rgb).')';
        }

        //Return rgb(a) color string
        return $output;
    }

    public function EventReleasedSetToDelete()
    {
        if ($this->getRefEventStatus() && in_array($this->getRefEventStatus()->getName(), [RefEventStatus::RELEASED, RefEventStatus::CANCELLED_BILLED, RefEventStatus::CANCELLED_NON_BILLED])) {
            $this->setCancelled(true)->save();
        } else {
            $this->setCancelled(false)->save();
        }
    }

    public function serializeForSalesforce(string $instance): array
    {
        $instance = strtolower($instance);
        $pmtoolIdField = self::FIELD_PMTOOL_ID[$instance] ?? 'PM_Tool_ID__c';
        $job = $this->getJob();
        $externalId = $this->getId().'-'.$job->getJobSfId().'-'.$pmtoolIdField;

        return [
            'ActivityDateTime' => $this->getStartDateTime('Y-m-d\TH:i:sO'),
            'Cancelled__c' => $this->getCancelled(),
            'CMSEndDate__c' => $this->getEndDateTime('Y-m-d h:i:s A'),
            'CMSStartDate__c' => $this->getStartDateTime('Y-m-d h:i:s A'),
            'CurrencyIsoCode' => $this->getActivityCurrency(),
            'Deleted__c' => $this->getIsDeletedC(),
            'Description' => $this->getComments(),
            'EndDateTime' => $this->getEndDateTime('Y-m-d\TH:i:sO'),
            'ExternalId__c' => $externalId, // = Event PMTooID-SFDC JobID-Schmeidl code
            'IsAllDayEvent' => $this->isAllDayEvent(),
            'IsReminderSet' => $this->isReminderSet(),
            'Job_Status__c' => $job->getStatus() ? $job->getStatus()->getLabel() : null,
            'Location__c' => $job->getJobLocation() ? $job->getJobLocation()->getSfLabel() : null,
            'PM_Tool_ID__c' => $this->getId(),
            'Qual_Schedule_Type__c' => $this->getEventMethodology() ? $this->getEventMethodology()->getSamsLabel() : null,
            'Room_ID__c' => $this->getRefRoom() ? $this->getRefRoom()->getName() : null,
            'Session_Comment__c' => $this->getDescription(),
            'StartDateTime' => $this->getStartDateTime('Y-m-d\TH:i:sO'),
            'Subject' => $job->getEtude()->getTheme(),
            'WhatId' => $job->getJobSfId(), // = SFDC JOB ID
        ];
    }

    public function manageGroupEvents(RefRoom $room = null, $statusId = null)
    {
        if ($this->isGroup()) {
            $eventGroupQuery = EventQuery::create()
            ->filterByStartDateTime($this->getStartDateTime('Y-m-d'), Criteria::GREATER_EQUAL)
            ->_if($this->getBidJobId())
            ->filterByBidJobId($this->getBidJobId())
            ->_elseif($this->getJobId())
            ->filterByJobId($this->getJobId())
            ->_endif()
            ->filterByIsGroup(true)
            ->filterByRefRoom($this->getRefRoom())
            ->find();
            if ($eventGroupQuery) {
                foreach ($eventGroupQuery as $groupEvent) {
                    $eventStartDate = new \DateTime($this->getStartDateTime('Y-m-d'));
                    $eventGroupStartDate = new \DateTime($groupEvent->getStartDateTime('Y-m-d'));
                    if ($eventStartDate == $eventGroupStartDate) {
                        if ($room) {
                            $groupEvent->setRefRoom($room)->save();
                        } elseif ($statusId) {
                            $groupEvent->setEventStatusId($statusId)->save();
                        }
                    }
                }
            }
        }
    }
}
