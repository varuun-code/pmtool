<?php

namespace Model;

use Model\Base\EtudeSampleSourceQuery as BaseEtudeSampleSourceQuery;

class EtudeSampleSourceQuery extends BaseEtudeSampleSourceQuery
{
}
