<?php

namespace Model;

use Model\Base\RefSalesForceAccountCountryOfUse as BaseRefSalesForceAccountCountryOfUse;

class RefSalesForceAccountCountryOfUse extends BaseRefSalesForceAccountCountryOfUse
{
}
