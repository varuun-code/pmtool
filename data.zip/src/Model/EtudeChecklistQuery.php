<?php

namespace Model;

use Model\Base\EtudeChecklistQuery as BaseEtudeChecklistQuery;

class EtudeChecklistQuery extends BaseEtudeChecklistQuery
{
}
