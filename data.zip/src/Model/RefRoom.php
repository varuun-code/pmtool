<?php

namespace Model;

use Model\Base\RefRoom as BaseRefRoom;
use Propel\Runtime\ActiveQuery\Criteria;

class RefRoom extends BaseRefRoom
{
    private static $allRooms;
    private static $instances;
    private static $byLocations = [];
    private static $rooms;

    public function __toString(): string
    {
        return $this->getName();
    }

    public static function getAll()
    {
        return self::$rooms ?? self::$rooms = RefRoomQuery::create()->find();
    }

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = RefRoomQuery::create()->findOneById($id);
    }

    public static function findByLocations(array $locationIds): array
    {
        if (count($locationIds) > 0) {
            $key = implode('#', $locationIds);

            return self::$byLocations[$key] ?? self::$byLocations[$key] = RefRoomQuery::create()
                ->select(['id', 'location_id', 'name'])
                ->useLocationQuery()
                    ->withColumn('libelle')
                    ->filterByActive(true)
                ->endUse()
                ->filterByIdLocation($locationIds, Criteria::IN)
                ->filterByActive(true)
                ->find()
                ->toArray();
        } else {
            return self::$allRooms ?? self::$allRooms = RefRoomQuery::create()
                ->select(['id', 'location_id', 'name'])
                ->useLocationQuery()
                    ->withColumn('libelle')
                    ->filterByLibelle(null, Criteria::NOT_EQUAL)
                    ->filterByActive(true)
                ->endUse()
                ->filterByActive(true)
                ->find()
                ->toArray();
        }
    }

    public static function getRoomsNamesAndLocationsForChoiceSelection(array $locationIds = []): array
    {
        $selections = self::findByLocations($locationIds);
        $choicesSelection = [];
        foreach ($selections as $selection) {
            $key = $selection['name'].' - '.$selection['libelle'];
            $choicesSelection[$key] = $selection['id'];
        }

        return $choicesSelection;
    }
}
