<?php

namespace Model;

use Model\Base\TempsPresence as BaseTempsPresence;
use Propel\Runtime\Connection\ConnectionInterface;

class TempsPresence extends BaseTempsPresence
{
    const DAY_TYPE = [
        'Working day' => 'W',
        'Holiday' => 'H',
        'Bank holiday' => 'B',
        'Special holiday' => 'P',
        'Sick day' => 'S',
        'Non-working day' => 'N',
        'Day off' => 'O',
    ];
    const DAY_TYPE_EXTRA = [
        'Correction extra hours' => 'C',
        'Transfer last year' => 'T',
    ];

    public function setCalculatedExtraHours($nbHours)
    {
        $dayType = $this->getDayType();
        $user = $this->getUser();
        $fournisseur = FournisseurQuery::create()->findPk($user->getFournisseurId());
        $avg_hours_per_day = ('W' == $dayType || 'P' == $dayType) ? $fournisseur->getAvgHoursPerDay() : 0;
        $extraHours = $nbHours - $avg_hours_per_day;
        parent::setExtraHours($extraHours);

        return $this;
    }

    public function preSave(ConnectionInterface $con = null)
    {
        $this->setPeriod($this->getDate('Y-m'));

        return parent::preSave();
    }
}
