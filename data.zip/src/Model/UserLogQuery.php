<?php

namespace Model;

use Model\Base\UserLogQuery as BaseUserLogQuery;

class UserLogQuery extends BaseUserLogQuery
{
}
