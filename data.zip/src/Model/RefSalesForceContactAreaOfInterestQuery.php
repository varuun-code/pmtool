<?php

namespace Model;

use Model\Base\RefSalesForceContactAreaOfInterestQuery as BaseRefSalesForceContactAreaOfInterestQuery;

class RefSalesForceContactAreaOfInterestQuery extends BaseRefSalesForceContactAreaOfInterestQuery
{
}
