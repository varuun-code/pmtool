<?php

namespace Model;

use Model\Base\EtudeFichierQuery as BaseEtudeFichierQuery;

class EtudeFichierQuery extends BaseEtudeFichierQuery
{
}
