<?php

namespace Model;

use Model\Base\RefSalesForceEtudeSectorQuery as BaseRefSalesForceEtudeSectorQuery;

class RefSalesForceEtudeSectorQuery extends BaseRefSalesForceEtudeSectorQuery
{
    public static function categoryToTarget($category, $targets)
    {
        switch ($category) {
            case 'Consumer':
            case 'patient':
                $match = 'Consumer';
                break;
            case 'Medical':
                $match = 'Healthcare';
                break;
            case 'B2B':
                $match = 'B2B';
                break;
            default:
                $match = null;
        }
        if (isset($targets[$match])) {
            return $targets[$match];
        }
        switch ($category) {
            case 'Consumer':
            case 'patient':
                $match = '1 B2C';
                break;
            case 'Medical':
                $match = '2 HC';
                break;
            case 'B2B':
                $match = '3 B2B';
                break;
            default:
                $match = null;
        }
        if (isset($targets[$match])) {
            return $targets[$match];
        }

        return null;
    }
}
