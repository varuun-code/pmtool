<?php

namespace Model;

use Model\Base\RefSalesForceOpportunitySectorQuery as BaseRefSalesForceOpportunitySectorQuery;

class RefSalesForceOpportunitySectorQuery extends BaseRefSalesForceOpportunitySectorQuery
{
}
