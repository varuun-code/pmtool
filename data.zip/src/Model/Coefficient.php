<?php

namespace Model;

use Model\Base\Coefficient as BaseCoefficient;

class Coefficient extends BaseCoefficient
{
    private static $coefficients;
    private static $instances;

    public function __toString(): string
    {
        return $this->getCoefficient();
    }

    public static function getCoefficients($asIds = false)
    {
        if (!self::$coefficients) {
            self::$coefficients = self::getAll()
                ->toKeyValue('Id', 'Coefficient');
        }
        if ($asIds) {
            return self::$coefficients;
        }

        return array_combine(array_values(self::$coefficients), array_values(self::$coefficients));
    }

    public static function getAll()
    {
        return self::$instances ?? self::$instances = CoefficientQuery::create()->find();
    }

    public static function getIdFromValue($value)
    {
        $coefs = self::getCoefficients(true);
        $key = array_search($value, $coefs);

        return false === $key ? null : $key;
    }
}
