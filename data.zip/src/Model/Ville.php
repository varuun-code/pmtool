<?php

namespace Model;

use Model\Base\Ville as BaseVille;

class Ville extends BaseVille
{
    private static $instances;

    public function __toString(): string
    {
        return $this->getCpAndVille();
    }

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = VilleQuery::create()->findOneById($id);
    }

    public function getCpAndVille()
    {
        return $this->getCp().' '.$this->getVille();
    }
}
