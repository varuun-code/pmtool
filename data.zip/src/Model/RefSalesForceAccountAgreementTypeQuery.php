<?php

namespace Model;

use Model\Base\RefSalesForceAccountAgreementTypeQuery as BaseRefSalesForceAccountAgreementTypeQuery;

class RefSalesForceAccountAgreementTypeQuery extends BaseRefSalesForceAccountAgreementTypeQuery
{
}
