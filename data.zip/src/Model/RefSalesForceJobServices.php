<?php

namespace Model;

use Model\Base\RefSalesForceJobServices as BaseRefSalesForceJobServices;

class RefSalesForceJobServices extends BaseRefSalesForceJobServices
{
}
