<?php

namespace Model;

use Model\Base\ChequesHistoriqueQuery as BaseChequesHistoriqueQuery;

class ChequesHistoriqueQuery extends BaseChequesHistoriqueQuery
{
}
