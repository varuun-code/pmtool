<?php

namespace Model;

use Model\Base\RefEventStatusQuery as BaseRefEventStatusQuery;

class RefEventStatusQuery extends BaseRefEventStatusQuery
{
}
