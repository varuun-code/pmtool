<?php

namespace Model;

use Model\Base\User as BaseUser;
use Symfony\Component\Security\Core\User\UserInterface;

class User extends BaseUser implements UserInterface
{
    const STATUS_ACTIVE = 'A'; // can log in
    const STATUS_EXPIRED = 'E'; // cannot log in (expired)
    const STATUS_LOCKED = 'V'; // cannot log in (locked)
    const HIGH_AUTHORITY = [
        Groupe::ACCOUNTING,  Groupe::MANAGEMENT, Groupe::SYSTEM_ADMINISTRATOR,
    ];
    const TO_INOICE_USERS = [Groupe::MANAGING_DIRECTOR, Groupe::ACCOUNTING, Groupe::MANAGEMENT,  Groupe::SYSTEM_ADMINISTRATOR, Groupe::FACILITY_DIRECTOR, Groupe::KNOWLEDGE_TEAM, Groupe::OPERATION_MANAGER, Groupe::PROJECT_CORDINATOR, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER, Groupe::FINANCE];
    const STUDY_FINISHED_USERS = [Groupe::MANAGING_DIRECTOR, Groupe::ACCOUNTING, Groupe::MANAGEMENT,  Groupe::SALES_MANAGER, Groupe::SYSTEM_ADMINISTRATOR, Groupe::PROJECT_DIRECTOR];
    const STANDBY_USERS = [Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_MANAGER, Groupe::ACCOUNTING, Groupe::MANAGEMENT,  Groupe::PROJECT_DIRECTOR, Groupe::SYSTEM_ADMINISTRATOR, Groupe::SALES_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR,
        Groupe::FACILITY_DIRECTOR, Groupe::KNOWLEDGE_TEAM, Groupe::OPERATION_MANAGER, Groupe::PROJECT_CORDINATOR, Groupe::BUSINESS_DEVELOPER,  Groupe::FACILITY_MANAGER, Groupe::QUALITY_ASSISTANT, Groupe::FINANCE, ];
    const MOST_USERS = [Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_MANAGER, Groupe::ACCOUNTING, Groupe::PROJECT_DIRECTOR,  Groupe::SALES_MANAGER, Groupe::MANAGEMENT, Groupe::SYSTEM_ADMINISTRATOR, Groupe::PHONE_ROOM_SUPERVISOR,
        Groupe::FACILITY_DIRECTOR, Groupe::KNOWLEDGE_TEAM, Groupe::OPERATION_MANAGER, Groupe::PROJECT_CORDINATOR, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER, Groupe::QUALITY_ASSISTANT, Groupe::FINANCE, ];

    private static $bm;
    private static $pm;
    private static $all;
    private static $default;
    private static $instancesPerGroup;
    private static $instances;
    private static $sellers;
    private static $phoneroomUsers;
    private static $userEmailBpReceiver;

    private $lastAccessedOpportunities;
    private $lastAccessedProjects;
    private $listProgramme;
    private $menu;

    public function __toString(): string
    {
        return $this->getNomComplet();
    }

    public static function getAllUserPR()
    {
        if (!isset(self::$phoneroomUsers)) {
            self::$phoneroomUsers = UserQuery::create()
                ->filterByIdGroupe([Groupe::PHONE_ROOM])
                ->find();
        }

        return self::$phoneroomUsers;
    }

    public static function getAllBM($etudeId = null)
    {
        self::$bm = self::$bm ?? UserQuery::create()
            ->filterByIdGroupe([Groupe::MANAGING_DIRECTOR, Groupe::SALES_MANAGER])
            ->filterByStatut('A')
            ->orderByNom()
            ->orderByPrenom()
            ->find();

        if ($etudeId && ($etude = Etude::getById($etudeId)) && ($bm = $etude->getBM())) {
            $result = clone self::$bm;

            return $result->append($bm);
        }

        return self::$bm;
    }

    public static function getAllPM($etudeId = null)
    {
        self::$pm = self::$pm ?? UserQuery::create()
            ->filterByIdGroupe([Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_MANAGER, Groupe::PROJECT_DIRECTOR, Groupe::SALES_MANAGER])
            ->filterByStatut('A')
            ->orderByNom()
            ->orderByPrenom()
            ->find();

        if ($etudeId && ($etude = Etude::getById($etudeId)) && ($pm = $etude->getEtudeProjectManager())) {
            $result = clone self::$pm;

            return $result->append($pm);
        }

        return self::$pm;
    }

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = UserQuery::create()->findOneById($id);
    }

    public static function getAll()
    {
        return self::$all ?? self::$all = UserQuery::create()->find();
    }

    public static function getPerGroup($groups)
    {
        $key = is_array($groups) ? implode('-', $groups) : $groups;

        return self::$instancesPerGroup[$key] ?? self::$instancesPerGroup[$key] = UserQuery::create()
            ->filterByIdGroupe($groups)
            ->orderByNom()
            ->find();
    }

    public static function getSellers()
    {
        return self::$sellers ?? self::$sellers = UserQuery::create()
            ->filterByisSeller(true)
            ->orderByNom()
            ->find();
    }

    public static function getIdFromSession() // FIXME remove
    {
        $id = $_SESSION['user'] ?? 0;

        return is_numeric($id) ? $id : 0;
    }

    public function canValidatePhoneRoom(): bool
    {
        return in_array($this->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::PHONE_ROOM_SUPERVISOR, Groupe::PROJECT_DIRECTOR, Groupe::ACCOUNTING]);
    }

    public function getFullname(): string
    {
        return $this->getNomComplet();
    }

    public function getNomComplet(): string
    {
        $fullName = [];

        if ($this->prenom) {
            $fullName[] = $this->prenom;
        }
        if ($this->nom) {
            $fullName[] = $this->nom;
        }

        return implode(' ', $fullName);
    }

    public function getNomCompletforPicklist()
    {
        $fullName = [];

        if ($this->nom) {
            $fullName[] = $this->nom;
        }
        if ($this->prenom) {
            $fullName[] = $this->prenom;
        }

        return implode(' | ', $fullName);
    }

    /**
     * List of civilities.
     */
    public static function getListeQualite(string $instance = '')
    {
        if ('de' == $instance) {
            return [
                '' => '',
                'Dr' => 'Doctor',
                'Fehl' => 'Fehl',
                'Frau' => 'Frau',
                'Frau Dr.' => 'Frau Dr.',
                'Frau Prof.' => 'Frau Prof.',
                'Firma' => 'Firma',
                'Herr' => 'Herr',
                'Herr Dr.' => 'Herr Dr.',
                'Herr Prof.' => 'Herr Prof.',
                'Herrn' => 'Herrn',
                'Pr' => 'Pr',
            ];
        } elseif ('fr' == $instance) {
            return [
                '' => '',
                'M.' => 'M.',
                'Mme' => 'Mme',
                'Dr' => 'Dr',
                'Pr' => 'Pr',
                'Mlle' => 'Mlle',
            ];
        }

        return [
            '' => '',
            'Mr' => 'Mr',
            'Mrs' => 'Mrs',
            'Ms' => 'Ms',
        ];
    }

    public static function getDefault()
    {
        return self::$default ?? self::$default = UserQuery::create()->findOneByDefaultSf(true);
    }

    public static function getDefaultSfId(): string
    {
        return self::getDefault() ? self::getDefault()->getSfId() : '';
    }

    public function getSfIdOrDefault(): string
    {
        return $this->getSfId() ?: self::getDefaultSfId();
    }

    public function getLastAccessedOpportunities()
    {
        return $this->lastAccessedOpportunities ?? $this->lastAccessedOpportunities = OpportunityQuery::create()
            ->select(['Id', 'OpportunitySubject'])
            ->useLastAccesOpportunityQuery()
                ->filterByUser($this)
            ->endUse()
            ->orderById()
            ->find();
    }

    public function haveAccessTo(string $url): bool
    {
        if (!$this->listProgramme) {
            $this->listProgramme = $this->getMenu();
            $this->listProgramme = $this->listProgramme ? $this->listProgramme->toArray() : [];
        }
        foreach ($this->listProgramme as $programme) {
            if (array_search($url, $programme)) {
                return true;
            }
        }

        return false;
    }

    public function isPhoneroomUser(): bool
    {
        return Groupe::PHONE_ROOM == $this->getIdGroupe();
    }

    public function getLastAccessedProjects()
    {
        return $this->lastAccessedProjects ?? $this->lastAccessedProjects = EtudeQuery::create()
            ->select(['Id', 'NumeroEtude'])
            ->useDernierAccesQuery()
                ->filterByUser($this)
            ->endUse()
            ->orderByNumeroEtude()
            ->find();
    }

    public static function getDefaultAccountManagerId($etudeOrOppty, $instance)
    {
        $defaultAcctMngrId = 0;
        if (!$etudeOrOppty->getAccountManagerId()) {
            switch ($instance) {
                case 'fr':
                    $nom = 'Nalpas';
                    $prenom = 'Eric';
                    break;
                case 'de':
                    $nom = 'Schmid';
                    $prenom = 'Stephan';
                    break;
                case 'es':
                    $nom = 'SPAIN';
                    $prenom = 'BDI';
                    break;
                case 'uk':
                    $nom = 'ASSOULINE';
                    $prenom = 'Hanna';
                    break;
                default:
                    $nom = $prenom = null;
                    break;
            }
            $defaultAcctMngrId = UserQuery::create()->select('id')->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT])
                ->filterByStatut('A')->filterByNom($nom)->filterByPrenom($prenom)->findOne();
        }

        return $defaultAcctMngrId;
    }

    public static function getUserEmailBadPayerReceiver()
    {
        return self::$userEmailBpReceiver ?? self::$userEmailBpReceiver = UserQuery::create()
            ->filterByIsBadPayerMailReceiver(true)
            ->select(['mail'])
            ->find()->getData();
    }

    public function getPassword()
    {
        return '';
    }

    public function eraseCredentials()
    {
    }

    public function getSalt()
    {
        return '';
    }

    public function getRoles()
    {
        return parent::getRawRoles();
    }

    public function getUsername()
    {
        return $this->getMail();
    }

    public function getMenu()
    {
        return $this->menu ?? $this->menu = ProgrammeQuery::create()
            ->useGroupeProgrammeQuery()
                ->filterByIdGroupe($this->getIdGroupe())
            ->endUse()
            ->orderByOrdre()
            ->find();
    }

    public function isReadOnly()
    {
        return Groupe::READ_ONLY === $this->getIdGroupe();
    }
}
