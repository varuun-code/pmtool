<?php

namespace Model;

use Model\Base\EtudeFichier as BaseEtudeFichier;

class EtudeFichier extends BaseEtudeFichier
{
}
