<?php

namespace Model;

use Model\Base\SfOpportunityBidJobArchive as BaseSfOpportunityBidJobArchive;

class SfOpportunityBidJobArchive extends BaseSfOpportunityBidJobArchive
{
}
