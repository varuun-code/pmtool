<?php

namespace Model;

use Model\Base\RefSalesForceAccountAgreementType as BaseRefSalesForceAccountAgreementType;

class RefSalesForceAccountAgreementType extends BaseRefSalesForceAccountAgreementType
{
}
