<?php

namespace Model;

use Model\Base\EtapeQuery as BaseEtapeQuery;

class EtapeQuery extends BaseEtapeQuery
{
}
