<?php

namespace Model;

use Model\Base\SuiviMajTable as BaseSuiviMajTable;

class SuiviMajTable extends BaseSuiviMajTable
{
    const INIT_TABLE = 'initTable';

    private static $instances;

    public static function getByOperation($operation)
    {
        return self::$instances[$operation] ?? self::$instances[$operation] = SuiviMajTableQuery::create()
            ->findOneByOperation($operation);
    }
}
