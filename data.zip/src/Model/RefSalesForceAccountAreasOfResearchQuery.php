<?php

namespace Model;

use Model\Base\RefSalesForceAccountAreasOfResearchQuery as BaseRefSalesForceAccountAreasOfResearchQuery;

class RefSalesForceAccountAreasOfResearchQuery extends BaseRefSalesForceAccountAreasOfResearchQuery
{
}
