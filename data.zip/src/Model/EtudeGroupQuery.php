<?php

namespace Model;

use Model\Base\EtudeGroupQuery as BaseEtudeGroupQuery;

class EtudeGroupQuery extends BaseEtudeGroupQuery
{
}
