<?php

namespace Model;

use Model\Base\Confirmation as BaseConfirmation;

class Confirmation extends BaseConfirmation
{
    private static $confirmations;

    public function __toString(): string
    {
        return $this->confirmation;
    }

    public static function getAll()
    {
        return self::$confirmations ?? self::$confirmations = ConfirmationQuery::create()
            ->orderByConfirmation()
            ->find();
    }
}
