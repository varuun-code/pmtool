<?php

namespace Model;

use Model\Base\RefSalesForceAccountAreasOfResearch as BaseRefSalesForceAccountAreasOfResearch;

class RefSalesForceAccountAreasOfResearch extends BaseRefSalesForceAccountAreasOfResearch
{
}
