<?php

namespace Model;

use Model\Base\DureeQuery as BaseDureeQuery;
use Util\PropelFullCacheTrait;

class DureeQuery extends BaseDureeQuery
{
    use PropelFullCacheTrait;
}
