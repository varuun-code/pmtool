<?php

namespace Model;

use Model\Base\UserQuery as BaseUserQuery;
use Util\PropelFullCacheTrait;

class UserQuery extends BaseUserQuery
{
    use PropelFullCacheTrait;
}
