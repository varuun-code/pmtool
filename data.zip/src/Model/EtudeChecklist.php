<?php

namespace Model;

use Model\Base\EtudeChecklist as BaseEtudeChecklist;

class EtudeChecklist extends BaseEtudeChecklist
{
}
