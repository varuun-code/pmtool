<?php

namespace Model;

use Model\Base\TempsPresenceQuery as BaseTempsPresenceQuery;

class TempsPresenceQuery extends BaseTempsPresenceQuery
{
}
