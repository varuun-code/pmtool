<?php

namespace Model;

use Model\Base\RefSalesForceOpportunityServicesQuery as BaseRefSalesForceOpportunityServicesQuery;

class RefSalesForceOpportunityServicesQuery extends BaseRefSalesForceOpportunityServicesQuery
{
}
