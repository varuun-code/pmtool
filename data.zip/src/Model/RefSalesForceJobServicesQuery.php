<?php

namespace Model;

use Model\Base\RefSalesForceJobServicesQuery as BaseRefSalesForceJobServicesQuery;

class RefSalesForceJobServicesQuery extends BaseRefSalesForceJobServicesQuery
{
}
