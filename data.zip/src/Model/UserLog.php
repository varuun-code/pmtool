<?php

namespace Model;

use Model\Base\UserLog as BaseUserLog;

class UserLog extends BaseUserLog
{
}
