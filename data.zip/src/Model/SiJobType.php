<?php

namespace Model;

use Model\Base\SiJobType as BaseSiJobType;

class SiJobType extends BaseSiJobType
{
    public function __toString(): string
    {
        return $this->label;
    }
}
