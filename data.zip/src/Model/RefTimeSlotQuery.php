<?php

namespace Model;

use Model\Base\RefTimeSlotQuery as BaseRefTimeSlotQuery;

class RefTimeSlotQuery extends BaseRefTimeSlotQuery
{
}
