<?php

namespace Model;

use Model\Base\SiteQuery as BaseSiteQuery;
use Util\PropelFullCacheTrait;

class SiteQuery extends BaseSiteQuery
{
    use PropelFullCacheTrait;
}
