<?php

namespace Model;

use Model\Base\SfOpportunityBidJobArchiveQuery as BaseSfOpportunityBidJobArchiveQuery;

class SfOpportunityBidJobArchiveQuery extends BaseSfOpportunityBidJobArchiveQuery
{
}
