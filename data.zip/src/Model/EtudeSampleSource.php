<?php

namespace Model;

use Model\Base\EtudeSampleSource as BaseEtudeSampleSource;

class EtudeSampleSource extends BaseEtudeSampleSource
{
}
