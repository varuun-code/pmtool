<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\DhtmlxSheet as ChildDhtmlxSheet;
use Model\DhtmlxSheetQuery as ChildDhtmlxSheetQuery;
use Model\Map\DhtmlxSheetTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'dhtmlx_sheet' table.
 *
 *
 *
 * @method     ChildDhtmlxSheetQuery orderBySheetid($order = Criteria::ASC) Order by the sheetid column
 * @method     ChildDhtmlxSheetQuery orderByUserid($order = Criteria::ASC) Order by the userid column
 * @method     ChildDhtmlxSheetQuery orderByName($order = Criteria::ASC) Order by the name column
 * @method     ChildDhtmlxSheetQuery orderByKey($order = Criteria::ASC) Order by the key column
 * @method     ChildDhtmlxSheetQuery orderByCfg($order = Criteria::ASC) Order by the cfg column
 *
 * @method     ChildDhtmlxSheetQuery groupBySheetid() Group by the sheetid column
 * @method     ChildDhtmlxSheetQuery groupByUserid() Group by the userid column
 * @method     ChildDhtmlxSheetQuery groupByName() Group by the name column
 * @method     ChildDhtmlxSheetQuery groupByKey() Group by the key column
 * @method     ChildDhtmlxSheetQuery groupByCfg() Group by the cfg column
 *
 * @method     ChildDhtmlxSheetQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildDhtmlxSheetQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildDhtmlxSheetQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildDhtmlxSheetQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildDhtmlxSheetQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildDhtmlxSheetQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildDhtmlxSheet|null findOne(ConnectionInterface $con = null) Return the first ChildDhtmlxSheet matching the query
 * @method     ChildDhtmlxSheet findOneOrCreate(ConnectionInterface $con = null) Return the first ChildDhtmlxSheet matching the query, or a new ChildDhtmlxSheet object populated from the query conditions when no match is found
 *
 * @method     ChildDhtmlxSheet|null findOneBySheetid(string $sheetid) Return the first ChildDhtmlxSheet filtered by the sheetid column
 * @method     ChildDhtmlxSheet|null findOneByUserid(int $userid) Return the first ChildDhtmlxSheet filtered by the userid column
 * @method     ChildDhtmlxSheet|null findOneByName(string $name) Return the first ChildDhtmlxSheet filtered by the name column
 * @method     ChildDhtmlxSheet|null findOneByKey(string $key) Return the first ChildDhtmlxSheet filtered by the key column
 * @method     ChildDhtmlxSheet|null findOneByCfg(string $cfg) Return the first ChildDhtmlxSheet filtered by the cfg column *

 * @method     ChildDhtmlxSheet requirePk($key, ConnectionInterface $con = null) Return the ChildDhtmlxSheet by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxSheet requireOne(ConnectionInterface $con = null) Return the first ChildDhtmlxSheet matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDhtmlxSheet requireOneBySheetid(string $sheetid) Return the first ChildDhtmlxSheet filtered by the sheetid column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxSheet requireOneByUserid(int $userid) Return the first ChildDhtmlxSheet filtered by the userid column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxSheet requireOneByName(string $name) Return the first ChildDhtmlxSheet filtered by the name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxSheet requireOneByKey(string $key) Return the first ChildDhtmlxSheet filtered by the key column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxSheet requireOneByCfg(string $cfg) Return the first ChildDhtmlxSheet filtered by the cfg column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDhtmlxSheet[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildDhtmlxSheet objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> find(ConnectionInterface $con = null) Return ChildDhtmlxSheet objects based on current ModelCriteria
 * @method     ChildDhtmlxSheet[]|ObjectCollection findBySheetid(string $sheetid) Return ChildDhtmlxSheet objects filtered by the sheetid column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> findBySheetid(string $sheetid) Return ChildDhtmlxSheet objects filtered by the sheetid column
 * @method     ChildDhtmlxSheet[]|ObjectCollection findByUserid(int $userid) Return ChildDhtmlxSheet objects filtered by the userid column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> findByUserid(int $userid) Return ChildDhtmlxSheet objects filtered by the userid column
 * @method     ChildDhtmlxSheet[]|ObjectCollection findByName(string $name) Return ChildDhtmlxSheet objects filtered by the name column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> findByName(string $name) Return ChildDhtmlxSheet objects filtered by the name column
 * @method     ChildDhtmlxSheet[]|ObjectCollection findByKey(string $key) Return ChildDhtmlxSheet objects filtered by the key column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> findByKey(string $key) Return ChildDhtmlxSheet objects filtered by the key column
 * @method     ChildDhtmlxSheet[]|ObjectCollection findByCfg(string $cfg) Return ChildDhtmlxSheet objects filtered by the cfg column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxSheet> findByCfg(string $cfg) Return ChildDhtmlxSheet objects filtered by the cfg column
 * @method     ChildDhtmlxSheet[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildDhtmlxSheet> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class DhtmlxSheetQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\DhtmlxSheetQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\DhtmlxSheet', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildDhtmlxSheetQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildDhtmlxSheetQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildDhtmlxSheetQuery) {
            return $criteria;
        }
        $query = new ChildDhtmlxSheetQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildDhtmlxSheet|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(DhtmlxSheetTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = DhtmlxSheetTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildDhtmlxSheet A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `sheetid`, `userid`, `name`, `key`, `cfg` FROM `dhtmlx_sheet` WHERE `sheetid` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildDhtmlxSheet $obj */
            $obj = new ChildDhtmlxSheet();
            $obj->hydrate($row);
            DhtmlxSheetTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildDhtmlxSheet|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_SHEETID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_SHEETID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the sheetid column
     *
     * Example usage:
     * <code>
     * $query->filterBySheetid('fooValue');   // WHERE sheetid = 'fooValue'
     * $query->filterBySheetid('%fooValue%', Criteria::LIKE); // WHERE sheetid LIKE '%fooValue%'
     * $query->filterBySheetid(['foo', 'bar']); // WHERE sheetid IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $sheetid The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterBySheetid($sheetid = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sheetid)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_SHEETID, $sheetid, $comparison);
    }

    /**
     * Filter the query on the userid column
     *
     * Example usage:
     * <code>
     * $query->filterByUserid(1234); // WHERE userid = 1234
     * $query->filterByUserid(array(12, 34)); // WHERE userid IN (12, 34)
     * $query->filterByUserid(array('min' => 12)); // WHERE userid > 12
     * </code>
     *
     * @param     mixed $userid The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByUserid($userid = null, $comparison = null)
    {
        if (is_array($userid)) {
            $useMinMax = false;
            if (isset($userid['min'])) {
                $this->addUsingAlias(DhtmlxSheetTableMap::COL_USERID, $userid['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($userid['max'])) {
                $this->addUsingAlias(DhtmlxSheetTableMap::COL_USERID, $userid['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_USERID, $userid, $comparison);
    }

    /**
     * Filter the query on the name column
     *
     * Example usage:
     * <code>
     * $query->filterByName('fooValue');   // WHERE name = 'fooValue'
     * $query->filterByName('%fooValue%', Criteria::LIKE); // WHERE name LIKE '%fooValue%'
     * $query->filterByName(['foo', 'bar']); // WHERE name IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $name The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByName($name = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($name)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_NAME, $name, $comparison);
    }

    /**
     * Filter the query on the key column
     *
     * Example usage:
     * <code>
     * $query->filterByKey('fooValue');   // WHERE key = 'fooValue'
     * $query->filterByKey('%fooValue%', Criteria::LIKE); // WHERE key LIKE '%fooValue%'
     * $query->filterByKey(['foo', 'bar']); // WHERE key IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $key The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByKey($key = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($key)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_KEY, $key, $comparison);
    }

    /**
     * Filter the query on the cfg column
     *
     * Example usage:
     * <code>
     * $query->filterByCfg('fooValue');   // WHERE cfg = 'fooValue'
     * $query->filterByCfg('%fooValue%', Criteria::LIKE); // WHERE cfg LIKE '%fooValue%'
     * $query->filterByCfg(['foo', 'bar']); // WHERE cfg IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $cfg The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function filterByCfg($cfg = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($cfg)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxSheetTableMap::COL_CFG, $cfg, $comparison);
    }

    /**
     * Exclude object from result
     *
     * @param   ChildDhtmlxSheet $dhtmlxSheet Object to remove from the list of results
     *
     * @return $this|ChildDhtmlxSheetQuery The current query, for fluid interface
     */
    public function prune($dhtmlxSheet = null)
    {
        if ($dhtmlxSheet) {
            $this->addUsingAlias(DhtmlxSheetTableMap::COL_SHEETID, $dhtmlxSheet->getSheetid(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the dhtmlx_sheet table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DhtmlxSheetTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            DhtmlxSheetTableMap::clearInstancePool();
            DhtmlxSheetTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DhtmlxSheetTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(DhtmlxSheetTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            DhtmlxSheetTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            DhtmlxSheetTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // DhtmlxSheetQuery
