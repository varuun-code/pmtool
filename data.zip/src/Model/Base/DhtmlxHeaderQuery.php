<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\DhtmlxHeader as ChildDhtmlxHeader;
use Model\DhtmlxHeaderQuery as ChildDhtmlxHeaderQuery;
use Model\Map\DhtmlxHeaderTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'dhtmlx_header' table.
 *
 *
 *
 * @method     ChildDhtmlxHeaderQuery orderBySheetid($order = Criteria::ASC) Order by the sheetid column
 * @method     ChildDhtmlxHeaderQuery orderByColumnid($order = Criteria::ASC) Order by the columnid column
 * @method     ChildDhtmlxHeaderQuery orderByLabel($order = Criteria::ASC) Order by the label column
 * @method     ChildDhtmlxHeaderQuery orderByWidth($order = Criteria::ASC) Order by the width column
 *
 * @method     ChildDhtmlxHeaderQuery groupBySheetid() Group by the sheetid column
 * @method     ChildDhtmlxHeaderQuery groupByColumnid() Group by the columnid column
 * @method     ChildDhtmlxHeaderQuery groupByLabel() Group by the label column
 * @method     ChildDhtmlxHeaderQuery groupByWidth() Group by the width column
 *
 * @method     ChildDhtmlxHeaderQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildDhtmlxHeaderQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildDhtmlxHeaderQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildDhtmlxHeaderQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildDhtmlxHeaderQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildDhtmlxHeaderQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildDhtmlxHeader|null findOne(ConnectionInterface $con = null) Return the first ChildDhtmlxHeader matching the query
 * @method     ChildDhtmlxHeader findOneOrCreate(ConnectionInterface $con = null) Return the first ChildDhtmlxHeader matching the query, or a new ChildDhtmlxHeader object populated from the query conditions when no match is found
 *
 * @method     ChildDhtmlxHeader|null findOneBySheetid(string $sheetid) Return the first ChildDhtmlxHeader filtered by the sheetid column
 * @method     ChildDhtmlxHeader|null findOneByColumnid(int $columnid) Return the first ChildDhtmlxHeader filtered by the columnid column
 * @method     ChildDhtmlxHeader|null findOneByLabel(string $label) Return the first ChildDhtmlxHeader filtered by the label column
 * @method     ChildDhtmlxHeader|null findOneByWidth(int $width) Return the first ChildDhtmlxHeader filtered by the width column *

 * @method     ChildDhtmlxHeader requirePk($key, ConnectionInterface $con = null) Return the ChildDhtmlxHeader by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxHeader requireOne(ConnectionInterface $con = null) Return the first ChildDhtmlxHeader matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDhtmlxHeader requireOneBySheetid(string $sheetid) Return the first ChildDhtmlxHeader filtered by the sheetid column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxHeader requireOneByColumnid(int $columnid) Return the first ChildDhtmlxHeader filtered by the columnid column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxHeader requireOneByLabel(string $label) Return the first ChildDhtmlxHeader filtered by the label column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDhtmlxHeader requireOneByWidth(int $width) Return the first ChildDhtmlxHeader filtered by the width column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDhtmlxHeader[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildDhtmlxHeader objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxHeader> find(ConnectionInterface $con = null) Return ChildDhtmlxHeader objects based on current ModelCriteria
 * @method     ChildDhtmlxHeader[]|ObjectCollection findBySheetid(string $sheetid) Return ChildDhtmlxHeader objects filtered by the sheetid column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxHeader> findBySheetid(string $sheetid) Return ChildDhtmlxHeader objects filtered by the sheetid column
 * @method     ChildDhtmlxHeader[]|ObjectCollection findByColumnid(int $columnid) Return ChildDhtmlxHeader objects filtered by the columnid column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxHeader> findByColumnid(int $columnid) Return ChildDhtmlxHeader objects filtered by the columnid column
 * @method     ChildDhtmlxHeader[]|ObjectCollection findByLabel(string $label) Return ChildDhtmlxHeader objects filtered by the label column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxHeader> findByLabel(string $label) Return ChildDhtmlxHeader objects filtered by the label column
 * @method     ChildDhtmlxHeader[]|ObjectCollection findByWidth(int $width) Return ChildDhtmlxHeader objects filtered by the width column
 * @psalm-method ObjectCollection&\Traversable<ChildDhtmlxHeader> findByWidth(int $width) Return ChildDhtmlxHeader objects filtered by the width column
 * @method     ChildDhtmlxHeader[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildDhtmlxHeader> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class DhtmlxHeaderQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\DhtmlxHeaderQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\DhtmlxHeader', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildDhtmlxHeaderQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildDhtmlxHeaderQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildDhtmlxHeaderQuery) {
            return $criteria;
        }
        $query = new ChildDhtmlxHeaderQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$sheetid, $columnid] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildDhtmlxHeader|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(DhtmlxHeaderTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = DhtmlxHeaderTableMap::getInstanceFromPool(serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]))))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildDhtmlxHeader A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `sheetid`, `columnid`, `label`, `width` FROM `dhtmlx_header` WHERE `sheetid` = :p0 AND `columnid` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildDhtmlxHeader $obj */
            $obj = new ChildDhtmlxHeader();
            $obj->hydrate($row);
            DhtmlxHeaderTableMap::addInstanceToPool($obj, serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildDhtmlxHeader|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(DhtmlxHeaderTableMap::COL_SHEETID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(DhtmlxHeaderTableMap::COL_COLUMNID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(DhtmlxHeaderTableMap::COL_SHEETID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(DhtmlxHeaderTableMap::COL_COLUMNID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the sheetid column
     *
     * Example usage:
     * <code>
     * $query->filterBySheetid('fooValue');   // WHERE sheetid = 'fooValue'
     * $query->filterBySheetid('%fooValue%', Criteria::LIKE); // WHERE sheetid LIKE '%fooValue%'
     * $query->filterBySheetid(['foo', 'bar']); // WHERE sheetid IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $sheetid The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterBySheetid($sheetid = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sheetid)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxHeaderTableMap::COL_SHEETID, $sheetid, $comparison);
    }

    /**
     * Filter the query on the columnid column
     *
     * Example usage:
     * <code>
     * $query->filterByColumnid(1234); // WHERE columnid = 1234
     * $query->filterByColumnid(array(12, 34)); // WHERE columnid IN (12, 34)
     * $query->filterByColumnid(array('min' => 12)); // WHERE columnid > 12
     * </code>
     *
     * @param     mixed $columnid The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterByColumnid($columnid = null, $comparison = null)
    {
        if (is_array($columnid)) {
            $useMinMax = false;
            if (isset($columnid['min'])) {
                $this->addUsingAlias(DhtmlxHeaderTableMap::COL_COLUMNID, $columnid['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($columnid['max'])) {
                $this->addUsingAlias(DhtmlxHeaderTableMap::COL_COLUMNID, $columnid['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxHeaderTableMap::COL_COLUMNID, $columnid, $comparison);
    }

    /**
     * Filter the query on the label column
     *
     * Example usage:
     * <code>
     * $query->filterByLabel('fooValue');   // WHERE label = 'fooValue'
     * $query->filterByLabel('%fooValue%', Criteria::LIKE); // WHERE label LIKE '%fooValue%'
     * $query->filterByLabel(['foo', 'bar']); // WHERE label IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $label The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterByLabel($label = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($label)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxHeaderTableMap::COL_LABEL, $label, $comparison);
    }

    /**
     * Filter the query on the width column
     *
     * Example usage:
     * <code>
     * $query->filterByWidth(1234); // WHERE width = 1234
     * $query->filterByWidth(array(12, 34)); // WHERE width IN (12, 34)
     * $query->filterByWidth(array('min' => 12)); // WHERE width > 12
     * </code>
     *
     * @param     mixed $width The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function filterByWidth($width = null, $comparison = null)
    {
        if (is_array($width)) {
            $useMinMax = false;
            if (isset($width['min'])) {
                $this->addUsingAlias(DhtmlxHeaderTableMap::COL_WIDTH, $width['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($width['max'])) {
                $this->addUsingAlias(DhtmlxHeaderTableMap::COL_WIDTH, $width['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DhtmlxHeaderTableMap::COL_WIDTH, $width, $comparison);
    }

    /**
     * Exclude object from result
     *
     * @param   ChildDhtmlxHeader $dhtmlxHeader Object to remove from the list of results
     *
     * @return $this|ChildDhtmlxHeaderQuery The current query, for fluid interface
     */
    public function prune($dhtmlxHeader = null)
    {
        if ($dhtmlxHeader) {
            $this->addCond('pruneCond0', $this->getAliasedColName(DhtmlxHeaderTableMap::COL_SHEETID), $dhtmlxHeader->getSheetid(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(DhtmlxHeaderTableMap::COL_COLUMNID), $dhtmlxHeader->getColumnid(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the dhtmlx_header table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DhtmlxHeaderTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            DhtmlxHeaderTableMap::clearInstancePool();
            DhtmlxHeaderTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DhtmlxHeaderTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(DhtmlxHeaderTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            DhtmlxHeaderTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            DhtmlxHeaderTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // DhtmlxHeaderQuery
