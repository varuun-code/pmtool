<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\Event as ChildEvent;
use Model\EventQuery as ChildEventQuery;
use Model\Map\EventTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'event' table.
 *
 *
 *
 * @method     ChildEventQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEventQuery orderBySamsEventId($order = Criteria::ASC) Order by the sams_event_id column
 * @method     ChildEventQuery orderByJobId($order = Criteria::ASC) Order by the job_id column
 * @method     ChildEventQuery orderByBidJobId($order = Criteria::ASC) Order by the bid_job_id column
 * @method     ChildEventQuery orderByBidJobArchiveId($order = Criteria::ASC) Order by the bid_job_archive_id column
 * @method     ChildEventQuery orderByRefRoomId($order = Criteria::ASC) Order by the ref_room_id column
 * @method     ChildEventQuery orderByRefTimeSlotId($order = Criteria::ASC) Order by the ref_time_slot_id column
 * @method     ChildEventQuery orderByEventStatusId($order = Criteria::ASC) Order by the event_status_id column
 * @method     ChildEventQuery orderByDate($order = Criteria::ASC) Order by the date column
 * @method     ChildEventQuery orderByConfirmedDate($order = Criteria::ASC) Order by the confirmed_date column
 * @method     ChildEventQuery orderByActiveDate($order = Criteria::ASC) Order by the active_date column
 * @method     ChildEventQuery orderByEventMethodologyId($order = Criteria::ASC) Order by the event_methodology_id column
 * @method     ChildEventQuery orderByStatus($order = Criteria::ASC) Order by the status column
 * @method     ChildEventQuery orderByComments($order = Criteria::ASC) Order by the comments column
 * @method     ChildEventQuery orderByFacilityNote($order = Criteria::ASC) Order by the facility_note column
 * @method     ChildEventQuery orderBySiteId($order = Criteria::ASC) Order by the site_id column
 * @method     ChildEventQuery orderByAccountId($order = Criteria::ASC) Order by the account_id column
 * @method     ChildEventQuery orderByAccountSfId($order = Criteria::ASC) Order by the account_sf_id column
 * @method     ChildEventQuery orderByActivityCurrency($order = Criteria::ASC) Order by the activity_currency column
 * @method     ChildEventQuery orderByAllDayEvent($order = Criteria::ASC) Order by the all_day_event column
 * @method     ChildEventQuery orderByArchived($order = Criteria::ASC) Order by the archived column
 * @method     ChildEventQuery orderByAssignedToId($order = Criteria::ASC) Order by the assigned_to_id column
 * @method     ChildEventQuery orderByCancelled($order = Criteria::ASC) Order by the cancelled column
 * @method     ChildEventQuery orderByRecurringEvent($order = Criteria::ASC) Order by the recurring_event column
 * @method     ChildEventQuery orderByIsDeleted($order = Criteria::ASC) Order by the is_deleted column
 * @method     ChildEventQuery orderByIsDeletedC($order = Criteria::ASC) Order by the is_deleted_c column
 * @method     ChildEventQuery orderByDescription($order = Criteria::ASC) Order by the description column
 * @method     ChildEventQuery orderByDurationMinutes($order = Criteria::ASC) Order by the duration_minutes column
 * @method     ChildEventQuery orderByEndDateTime($order = Criteria::ASC) Order by the end_date_time column
 * @method     ChildEventQuery orderByRecordTypeId($order = Criteria::ASC) Order by the record_type_id column
 * @method     ChildEventQuery orderByEventSubTypeId($order = Criteria::ASC) Order by the event_sub_type_id column
 * @method     ChildEventQuery orderByJobStatus($order = Criteria::ASC) Order by the job_status column
 * @method     ChildEventQuery orderByLocationC($order = Criteria::ASC) Order by the location_c column
 * @method     ChildEventQuery orderByReminderDate($order = Criteria::ASC) Order by the reminder_date column
 * @method     ChildEventQuery orderByReminderSet($order = Criteria::ASC) Order by the reminder_set column
 * @method     ChildEventQuery orderByStartDateTime($order = Criteria::ASC) Order by the start_date_time column
 * @method     ChildEventQuery orderBySubject($order = Criteria::ASC) Order by the subject column
 * @method     ChildEventQuery orderByRecurrenceTimeZone($order = Criteria::ASC) Order by the recurrence_time_zone column
 * @method     ChildEventQuery orderByCreatedBySfId($order = Criteria::ASC) Order by the created_by_sf_id column
 * @method     ChildEventQuery orderByPmtoolUpdated($order = Criteria::ASC) Order by the pmtool_updated column
 * @method     ChildEventQuery orderByEventHolderId($order = Criteria::ASC) Order by the event_holder_id column
 * @method     ChildEventQuery orderByApiCreatedDate($order = Criteria::ASC) Order by the api_created_date column
 * @method     ChildEventQuery orderByApiUpdatedDate($order = Criteria::ASC) Order by the api_updated_date column
 * @method     ChildEventQuery orderByIsGroup($order = Criteria::ASC) Order by the is_group column
 * @method     ChildEventQuery orderByCreatedDate($order = Criteria::ASC) Order by the created_date column
 * @method     ChildEventQuery orderByUpdatedDate($order = Criteria::ASC) Order by the updated_date column
 *
 * @method     ChildEventQuery groupById() Group by the id column
 * @method     ChildEventQuery groupBySamsEventId() Group by the sams_event_id column
 * @method     ChildEventQuery groupByJobId() Group by the job_id column
 * @method     ChildEventQuery groupByBidJobId() Group by the bid_job_id column
 * @method     ChildEventQuery groupByBidJobArchiveId() Group by the bid_job_archive_id column
 * @method     ChildEventQuery groupByRefRoomId() Group by the ref_room_id column
 * @method     ChildEventQuery groupByRefTimeSlotId() Group by the ref_time_slot_id column
 * @method     ChildEventQuery groupByEventStatusId() Group by the event_status_id column
 * @method     ChildEventQuery groupByDate() Group by the date column
 * @method     ChildEventQuery groupByConfirmedDate() Group by the confirmed_date column
 * @method     ChildEventQuery groupByActiveDate() Group by the active_date column
 * @method     ChildEventQuery groupByEventMethodologyId() Group by the event_methodology_id column
 * @method     ChildEventQuery groupByStatus() Group by the status column
 * @method     ChildEventQuery groupByComments() Group by the comments column
 * @method     ChildEventQuery groupByFacilityNote() Group by the facility_note column
 * @method     ChildEventQuery groupBySiteId() Group by the site_id column
 * @method     ChildEventQuery groupByAccountId() Group by the account_id column
 * @method     ChildEventQuery groupByAccountSfId() Group by the account_sf_id column
 * @method     ChildEventQuery groupByActivityCurrency() Group by the activity_currency column
 * @method     ChildEventQuery groupByAllDayEvent() Group by the all_day_event column
 * @method     ChildEventQuery groupByArchived() Group by the archived column
 * @method     ChildEventQuery groupByAssignedToId() Group by the assigned_to_id column
 * @method     ChildEventQuery groupByCancelled() Group by the cancelled column
 * @method     ChildEventQuery groupByRecurringEvent() Group by the recurring_event column
 * @method     ChildEventQuery groupByIsDeleted() Group by the is_deleted column
 * @method     ChildEventQuery groupByIsDeletedC() Group by the is_deleted_c column
 * @method     ChildEventQuery groupByDescription() Group by the description column
 * @method     ChildEventQuery groupByDurationMinutes() Group by the duration_minutes column
 * @method     ChildEventQuery groupByEndDateTime() Group by the end_date_time column
 * @method     ChildEventQuery groupByRecordTypeId() Group by the record_type_id column
 * @method     ChildEventQuery groupByEventSubTypeId() Group by the event_sub_type_id column
 * @method     ChildEventQuery groupByJobStatus() Group by the job_status column
 * @method     ChildEventQuery groupByLocationC() Group by the location_c column
 * @method     ChildEventQuery groupByReminderDate() Group by the reminder_date column
 * @method     ChildEventQuery groupByReminderSet() Group by the reminder_set column
 * @method     ChildEventQuery groupByStartDateTime() Group by the start_date_time column
 * @method     ChildEventQuery groupBySubject() Group by the subject column
 * @method     ChildEventQuery groupByRecurrenceTimeZone() Group by the recurrence_time_zone column
 * @method     ChildEventQuery groupByCreatedBySfId() Group by the created_by_sf_id column
 * @method     ChildEventQuery groupByPmtoolUpdated() Group by the pmtool_updated column
 * @method     ChildEventQuery groupByEventHolderId() Group by the event_holder_id column
 * @method     ChildEventQuery groupByApiCreatedDate() Group by the api_created_date column
 * @method     ChildEventQuery groupByApiUpdatedDate() Group by the api_updated_date column
 * @method     ChildEventQuery groupByIsGroup() Group by the is_group column
 * @method     ChildEventQuery groupByCreatedDate() Group by the created_date column
 * @method     ChildEventQuery groupByUpdatedDate() Group by the updated_date column
 *
 * @method     ChildEventQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEventQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEventQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEventQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEventQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEventQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEventQuery leftJoinEventHolderBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the EventHolderBy relation
 * @method     ChildEventQuery rightJoinEventHolderBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EventHolderBy relation
 * @method     ChildEventQuery innerJoinEventHolderBy($relationAlias = null) Adds a INNER JOIN clause to the query using the EventHolderBy relation
 *
 * @method     ChildEventQuery joinWithEventHolderBy($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EventHolderBy relation
 *
 * @method     ChildEventQuery leftJoinWithEventHolderBy() Adds a LEFT JOIN clause and with to the query using the EventHolderBy relation
 * @method     ChildEventQuery rightJoinWithEventHolderBy() Adds a RIGHT JOIN clause and with to the query using the EventHolderBy relation
 * @method     ChildEventQuery innerJoinWithEventHolderBy() Adds a INNER JOIN clause and with to the query using the EventHolderBy relation
 *
 * @method     ChildEventQuery leftJoinJob($relationAlias = null) Adds a LEFT JOIN clause to the query using the Job relation
 * @method     ChildEventQuery rightJoinJob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Job relation
 * @method     ChildEventQuery innerJoinJob($relationAlias = null) Adds a INNER JOIN clause to the query using the Job relation
 *
 * @method     ChildEventQuery joinWithJob($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Job relation
 *
 * @method     ChildEventQuery leftJoinWithJob() Adds a LEFT JOIN clause and with to the query using the Job relation
 * @method     ChildEventQuery rightJoinWithJob() Adds a RIGHT JOIN clause and with to the query using the Job relation
 * @method     ChildEventQuery innerJoinWithJob() Adds a INNER JOIN clause and with to the query using the Job relation
 *
 * @method     ChildEventQuery leftJoinBidJob($relationAlias = null) Adds a LEFT JOIN clause to the query using the BidJob relation
 * @method     ChildEventQuery rightJoinBidJob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BidJob relation
 * @method     ChildEventQuery innerJoinBidJob($relationAlias = null) Adds a INNER JOIN clause to the query using the BidJob relation
 *
 * @method     ChildEventQuery joinWithBidJob($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the BidJob relation
 *
 * @method     ChildEventQuery leftJoinWithBidJob() Adds a LEFT JOIN clause and with to the query using the BidJob relation
 * @method     ChildEventQuery rightJoinWithBidJob() Adds a RIGHT JOIN clause and with to the query using the BidJob relation
 * @method     ChildEventQuery innerJoinWithBidJob() Adds a INNER JOIN clause and with to the query using the BidJob relation
 *
 * @method     ChildEventQuery leftJoinRefRoom($relationAlias = null) Adds a LEFT JOIN clause to the query using the RefRoom relation
 * @method     ChildEventQuery rightJoinRefRoom($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RefRoom relation
 * @method     ChildEventQuery innerJoinRefRoom($relationAlias = null) Adds a INNER JOIN clause to the query using the RefRoom relation
 *
 * @method     ChildEventQuery joinWithRefRoom($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the RefRoom relation
 *
 * @method     ChildEventQuery leftJoinWithRefRoom() Adds a LEFT JOIN clause and with to the query using the RefRoom relation
 * @method     ChildEventQuery rightJoinWithRefRoom() Adds a RIGHT JOIN clause and with to the query using the RefRoom relation
 * @method     ChildEventQuery innerJoinWithRefRoom() Adds a INNER JOIN clause and with to the query using the RefRoom relation
 *
 * @method     ChildEventQuery leftJoinRefEventStatus($relationAlias = null) Adds a LEFT JOIN clause to the query using the RefEventStatus relation
 * @method     ChildEventQuery rightJoinRefEventStatus($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RefEventStatus relation
 * @method     ChildEventQuery innerJoinRefEventStatus($relationAlias = null) Adds a INNER JOIN clause to the query using the RefEventStatus relation
 *
 * @method     ChildEventQuery joinWithRefEventStatus($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the RefEventStatus relation
 *
 * @method     ChildEventQuery leftJoinWithRefEventStatus() Adds a LEFT JOIN clause and with to the query using the RefEventStatus relation
 * @method     ChildEventQuery rightJoinWithRefEventStatus() Adds a RIGHT JOIN clause and with to the query using the RefEventStatus relation
 * @method     ChildEventQuery innerJoinWithRefEventStatus() Adds a INNER JOIN clause and with to the query using the RefEventStatus relation
 *
 * @method     ChildEventQuery leftJoinRefTimeSlot($relationAlias = null) Adds a LEFT JOIN clause to the query using the RefTimeSlot relation
 * @method     ChildEventQuery rightJoinRefTimeSlot($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RefTimeSlot relation
 * @method     ChildEventQuery innerJoinRefTimeSlot($relationAlias = null) Adds a INNER JOIN clause to the query using the RefTimeSlot relation
 *
 * @method     ChildEventQuery joinWithRefTimeSlot($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the RefTimeSlot relation
 *
 * @method     ChildEventQuery leftJoinWithRefTimeSlot() Adds a LEFT JOIN clause and with to the query using the RefTimeSlot relation
 * @method     ChildEventQuery rightJoinWithRefTimeSlot() Adds a RIGHT JOIN clause and with to the query using the RefTimeSlot relation
 * @method     ChildEventQuery innerJoinWithRefTimeSlot() Adds a INNER JOIN clause and with to the query using the RefTimeSlot relation
 *
 * @method     ChildEventQuery leftJoinEventMethodology($relationAlias = null) Adds a LEFT JOIN clause to the query using the EventMethodology relation
 * @method     ChildEventQuery rightJoinEventMethodology($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EventMethodology relation
 * @method     ChildEventQuery innerJoinEventMethodology($relationAlias = null) Adds a INNER JOIN clause to the query using the EventMethodology relation
 *
 * @method     ChildEventQuery joinWithEventMethodology($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EventMethodology relation
 *
 * @method     ChildEventQuery leftJoinWithEventMethodology() Adds a LEFT JOIN clause and with to the query using the EventMethodology relation
 * @method     ChildEventQuery rightJoinWithEventMethodology() Adds a RIGHT JOIN clause and with to the query using the EventMethodology relation
 * @method     ChildEventQuery innerJoinWithEventMethodology() Adds a INNER JOIN clause and with to the query using the EventMethodology relation
 *
 * @method     ChildEventQuery leftJoinAccount($relationAlias = null) Adds a LEFT JOIN clause to the query using the Account relation
 * @method     ChildEventQuery rightJoinAccount($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Account relation
 * @method     ChildEventQuery innerJoinAccount($relationAlias = null) Adds a INNER JOIN clause to the query using the Account relation
 *
 * @method     ChildEventQuery joinWithAccount($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Account relation
 *
 * @method     ChildEventQuery leftJoinWithAccount() Adds a LEFT JOIN clause and with to the query using the Account relation
 * @method     ChildEventQuery rightJoinWithAccount() Adds a RIGHT JOIN clause and with to the query using the Account relation
 * @method     ChildEventQuery innerJoinWithAccount() Adds a INNER JOIN clause and with to the query using the Account relation
 *
 * @method     ChildEventQuery leftJoinAssignedTo($relationAlias = null) Adds a LEFT JOIN clause to the query using the AssignedTo relation
 * @method     ChildEventQuery rightJoinAssignedTo($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AssignedTo relation
 * @method     ChildEventQuery innerJoinAssignedTo($relationAlias = null) Adds a INNER JOIN clause to the query using the AssignedTo relation
 *
 * @method     ChildEventQuery joinWithAssignedTo($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the AssignedTo relation
 *
 * @method     ChildEventQuery leftJoinWithAssignedTo() Adds a LEFT JOIN clause and with to the query using the AssignedTo relation
 * @method     ChildEventQuery rightJoinWithAssignedTo() Adds a RIGHT JOIN clause and with to the query using the AssignedTo relation
 * @method     ChildEventQuery innerJoinWithAssignedTo() Adds a INNER JOIN clause and with to the query using the AssignedTo relation
 *
 * @method     ChildEventQuery leftJoinRecordType($relationAlias = null) Adds a LEFT JOIN clause to the query using the RecordType relation
 * @method     ChildEventQuery rightJoinRecordType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RecordType relation
 * @method     ChildEventQuery innerJoinRecordType($relationAlias = null) Adds a INNER JOIN clause to the query using the RecordType relation
 *
 * @method     ChildEventQuery joinWithRecordType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the RecordType relation
 *
 * @method     ChildEventQuery leftJoinWithRecordType() Adds a LEFT JOIN clause and with to the query using the RecordType relation
 * @method     ChildEventQuery rightJoinWithRecordType() Adds a RIGHT JOIN clause and with to the query using the RecordType relation
 * @method     ChildEventQuery innerJoinWithRecordType() Adds a INNER JOIN clause and with to the query using the RecordType relation
 *
 * @method     ChildEventQuery leftJoinEventSubType($relationAlias = null) Adds a LEFT JOIN clause to the query using the EventSubType relation
 * @method     ChildEventQuery rightJoinEventSubType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EventSubType relation
 * @method     ChildEventQuery innerJoinEventSubType($relationAlias = null) Adds a INNER JOIN clause to the query using the EventSubType relation
 *
 * @method     ChildEventQuery joinWithEventSubType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EventSubType relation
 *
 * @method     ChildEventQuery leftJoinWithEventSubType() Adds a LEFT JOIN clause and with to the query using the EventSubType relation
 * @method     ChildEventQuery rightJoinWithEventSubType() Adds a RIGHT JOIN clause and with to the query using the EventSubType relation
 * @method     ChildEventQuery innerJoinWithEventSubType() Adds a INNER JOIN clause and with to the query using the EventSubType relation
 *
 * @method     ChildEventQuery leftJoinSite($relationAlias = null) Adds a LEFT JOIN clause to the query using the Site relation
 * @method     ChildEventQuery rightJoinSite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Site relation
 * @method     ChildEventQuery innerJoinSite($relationAlias = null) Adds a INNER JOIN clause to the query using the Site relation
 *
 * @method     ChildEventQuery joinWithSite($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Site relation
 *
 * @method     ChildEventQuery leftJoinWithSite() Adds a LEFT JOIN clause and with to the query using the Site relation
 * @method     ChildEventQuery rightJoinWithSite() Adds a RIGHT JOIN clause and with to the query using the Site relation
 * @method     ChildEventQuery innerJoinWithSite() Adds a INNER JOIN clause and with to the query using the Site relation
 *
 * @method     ChildEventQuery leftJoinModule($relationAlias = null) Adds a LEFT JOIN clause to the query using the Module relation
 * @method     ChildEventQuery rightJoinModule($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Module relation
 * @method     ChildEventQuery innerJoinModule($relationAlias = null) Adds a INNER JOIN clause to the query using the Module relation
 *
 * @method     ChildEventQuery joinWithModule($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Module relation
 *
 * @method     ChildEventQuery leftJoinWithModule() Adds a LEFT JOIN clause and with to the query using the Module relation
 * @method     ChildEventQuery rightJoinWithModule() Adds a RIGHT JOIN clause and with to the query using the Module relation
 * @method     ChildEventQuery innerJoinWithModule() Adds a INNER JOIN clause and with to the query using the Module relation
 *
 * @method     ChildEventQuery leftJoinEvent($relationAlias = null) Adds a LEFT JOIN clause to the query using the Event relation
 * @method     ChildEventQuery rightJoinEvent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Event relation
 * @method     ChildEventQuery innerJoinEvent($relationAlias = null) Adds a INNER JOIN clause to the query using the Event relation
 *
 * @method     ChildEventQuery joinWithEvent($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Event relation
 *
 * @method     ChildEventQuery leftJoinWithEvent() Adds a LEFT JOIN clause and with to the query using the Event relation
 * @method     ChildEventQuery rightJoinWithEvent() Adds a RIGHT JOIN clause and with to the query using the Event relation
 * @method     ChildEventQuery innerJoinWithEvent() Adds a INNER JOIN clause and with to the query using the Event relation
 *
 * @method     ChildEventQuery leftJoinEventBidJobItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the EventBidJobItem relation
 * @method     ChildEventQuery rightJoinEventBidJobItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EventBidJobItem relation
 * @method     ChildEventQuery innerJoinEventBidJobItem($relationAlias = null) Adds a INNER JOIN clause to the query using the EventBidJobItem relation
 *
 * @method     ChildEventQuery joinWithEventBidJobItem($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EventBidJobItem relation
 *
 * @method     ChildEventQuery leftJoinWithEventBidJobItem() Adds a LEFT JOIN clause and with to the query using the EventBidJobItem relation
 * @method     ChildEventQuery rightJoinWithEventBidJobItem() Adds a RIGHT JOIN clause and with to the query using the EventBidJobItem relation
 * @method     ChildEventQuery innerJoinWithEventBidJobItem() Adds a INNER JOIN clause and with to the query using the EventBidJobItem relation
 *
 * @method     \Model\UserQuery|\Model\JobQuery|\Model\BidJobQuery|\Model\RefRoomQuery|\Model\RefEventStatusQuery|\Model\RefTimeSlotQuery|\Model\EventMethodologyQuery|\Model\AccountQuery|\Model\RefSalesForceQuery|\Model\SiteQuery|\Model\ModuleQuery|\Model\BidJobItemQuery|\Model\EventBidJobItemQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEvent|null findOne(ConnectionInterface $con = null) Return the first ChildEvent matching the query
 * @method     ChildEvent findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEvent matching the query, or a new ChildEvent object populated from the query conditions when no match is found
 *
 * @method     ChildEvent|null findOneById(int $id) Return the first ChildEvent filtered by the id column
 * @method     ChildEvent|null findOneBySamsEventId(string $sams_event_id) Return the first ChildEvent filtered by the sams_event_id column
 * @method     ChildEvent|null findOneByJobId(int $job_id) Return the first ChildEvent filtered by the job_id column
 * @method     ChildEvent|null findOneByBidJobId(int $bid_job_id) Return the first ChildEvent filtered by the bid_job_id column
 * @method     ChildEvent|null findOneByBidJobArchiveId(int $bid_job_archive_id) Return the first ChildEvent filtered by the bid_job_archive_id column
 * @method     ChildEvent|null findOneByRefRoomId(int $ref_room_id) Return the first ChildEvent filtered by the ref_room_id column
 * @method     ChildEvent|null findOneByRefTimeSlotId(int $ref_time_slot_id) Return the first ChildEvent filtered by the ref_time_slot_id column
 * @method     ChildEvent|null findOneByEventStatusId(int $event_status_id) Return the first ChildEvent filtered by the event_status_id column
 * @method     ChildEvent|null findOneByDate(string $date) Return the first ChildEvent filtered by the date column
 * @method     ChildEvent|null findOneByConfirmedDate(string $confirmed_date) Return the first ChildEvent filtered by the confirmed_date column
 * @method     ChildEvent|null findOneByActiveDate(string $active_date) Return the first ChildEvent filtered by the active_date column
 * @method     ChildEvent|null findOneByEventMethodologyId(int $event_methodology_id) Return the first ChildEvent filtered by the event_methodology_id column
 * @method     ChildEvent|null findOneByStatus(int $status) Return the first ChildEvent filtered by the status column
 * @method     ChildEvent|null findOneByComments(string $comments) Return the first ChildEvent filtered by the comments column
 * @method     ChildEvent|null findOneByFacilityNote(string $facility_note) Return the first ChildEvent filtered by the facility_note column
 * @method     ChildEvent|null findOneBySiteId(int $site_id) Return the first ChildEvent filtered by the site_id column
 * @method     ChildEvent|null findOneByAccountId(int $account_id) Return the first ChildEvent filtered by the account_id column
 * @method     ChildEvent|null findOneByAccountSfId(string $account_sf_id) Return the first ChildEvent filtered by the account_sf_id column
 * @method     ChildEvent|null findOneByActivityCurrency(string $activity_currency) Return the first ChildEvent filtered by the activity_currency column
 * @method     ChildEvent|null findOneByAllDayEvent(boolean $all_day_event) Return the first ChildEvent filtered by the all_day_event column
 * @method     ChildEvent|null findOneByArchived(boolean $archived) Return the first ChildEvent filtered by the archived column
 * @method     ChildEvent|null findOneByAssignedToId(int $assigned_to_id) Return the first ChildEvent filtered by the assigned_to_id column
 * @method     ChildEvent|null findOneByCancelled(boolean $cancelled) Return the first ChildEvent filtered by the cancelled column
 * @method     ChildEvent|null findOneByRecurringEvent(boolean $recurring_event) Return the first ChildEvent filtered by the recurring_event column
 * @method     ChildEvent|null findOneByIsDeleted(boolean $is_deleted) Return the first ChildEvent filtered by the is_deleted column
 * @method     ChildEvent|null findOneByIsDeletedC(boolean $is_deleted_c) Return the first ChildEvent filtered by the is_deleted_c column
 * @method     ChildEvent|null findOneByDescription(string $description) Return the first ChildEvent filtered by the description column
 * @method     ChildEvent|null findOneByDurationMinutes(int $duration_minutes) Return the first ChildEvent filtered by the duration_minutes column
 * @method     ChildEvent|null findOneByEndDateTime(string $end_date_time) Return the first ChildEvent filtered by the end_date_time column
 * @method     ChildEvent|null findOneByRecordTypeId(int $record_type_id) Return the first ChildEvent filtered by the record_type_id column
 * @method     ChildEvent|null findOneByEventSubTypeId(int $event_sub_type_id) Return the first ChildEvent filtered by the event_sub_type_id column
 * @method     ChildEvent|null findOneByJobStatus(string $job_status) Return the first ChildEvent filtered by the job_status column
 * @method     ChildEvent|null findOneByLocationC(string $location_c) Return the first ChildEvent filtered by the location_c column
 * @method     ChildEvent|null findOneByReminderDate(string $reminder_date) Return the first ChildEvent filtered by the reminder_date column
 * @method     ChildEvent|null findOneByReminderSet(boolean $reminder_set) Return the first ChildEvent filtered by the reminder_set column
 * @method     ChildEvent|null findOneByStartDateTime(string $start_date_time) Return the first ChildEvent filtered by the start_date_time column
 * @method     ChildEvent|null findOneBySubject(string $subject) Return the first ChildEvent filtered by the subject column
 * @method     ChildEvent|null findOneByRecurrenceTimeZone(string $recurrence_time_zone) Return the first ChildEvent filtered by the recurrence_time_zone column
 * @method     ChildEvent|null findOneByCreatedBySfId(string $created_by_sf_id) Return the first ChildEvent filtered by the created_by_sf_id column
 * @method     ChildEvent|null findOneByPmtoolUpdated(boolean $pmtool_updated) Return the first ChildEvent filtered by the pmtool_updated column
 * @method     ChildEvent|null findOneByEventHolderId(int $event_holder_id) Return the first ChildEvent filtered by the event_holder_id column
 * @method     ChildEvent|null findOneByApiCreatedDate(string $api_created_date) Return the first ChildEvent filtered by the api_created_date column
 * @method     ChildEvent|null findOneByApiUpdatedDate(string $api_updated_date) Return the first ChildEvent filtered by the api_updated_date column
 * @method     ChildEvent|null findOneByIsGroup(boolean $is_group) Return the first ChildEvent filtered by the is_group column
 * @method     ChildEvent|null findOneByCreatedDate(string $created_date) Return the first ChildEvent filtered by the created_date column
 * @method     ChildEvent|null findOneByUpdatedDate(string $updated_date) Return the first ChildEvent filtered by the updated_date column *

 * @method     ChildEvent requirePk($key, ConnectionInterface $con = null) Return the ChildEvent by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOne(ConnectionInterface $con = null) Return the first ChildEvent matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEvent requireOneById(int $id) Return the first ChildEvent filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneBySamsEventId(string $sams_event_id) Return the first ChildEvent filtered by the sams_event_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByJobId(int $job_id) Return the first ChildEvent filtered by the job_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByBidJobId(int $bid_job_id) Return the first ChildEvent filtered by the bid_job_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByBidJobArchiveId(int $bid_job_archive_id) Return the first ChildEvent filtered by the bid_job_archive_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByRefRoomId(int $ref_room_id) Return the first ChildEvent filtered by the ref_room_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByRefTimeSlotId(int $ref_time_slot_id) Return the first ChildEvent filtered by the ref_time_slot_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByEventStatusId(int $event_status_id) Return the first ChildEvent filtered by the event_status_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByDate(string $date) Return the first ChildEvent filtered by the date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByConfirmedDate(string $confirmed_date) Return the first ChildEvent filtered by the confirmed_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByActiveDate(string $active_date) Return the first ChildEvent filtered by the active_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByEventMethodologyId(int $event_methodology_id) Return the first ChildEvent filtered by the event_methodology_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByStatus(int $status) Return the first ChildEvent filtered by the status column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByComments(string $comments) Return the first ChildEvent filtered by the comments column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByFacilityNote(string $facility_note) Return the first ChildEvent filtered by the facility_note column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneBySiteId(int $site_id) Return the first ChildEvent filtered by the site_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByAccountId(int $account_id) Return the first ChildEvent filtered by the account_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByAccountSfId(string $account_sf_id) Return the first ChildEvent filtered by the account_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByActivityCurrency(string $activity_currency) Return the first ChildEvent filtered by the activity_currency column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByAllDayEvent(boolean $all_day_event) Return the first ChildEvent filtered by the all_day_event column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByArchived(boolean $archived) Return the first ChildEvent filtered by the archived column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByAssignedToId(int $assigned_to_id) Return the first ChildEvent filtered by the assigned_to_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByCancelled(boolean $cancelled) Return the first ChildEvent filtered by the cancelled column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByRecurringEvent(boolean $recurring_event) Return the first ChildEvent filtered by the recurring_event column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByIsDeleted(boolean $is_deleted) Return the first ChildEvent filtered by the is_deleted column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByIsDeletedC(boolean $is_deleted_c) Return the first ChildEvent filtered by the is_deleted_c column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByDescription(string $description) Return the first ChildEvent filtered by the description column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByDurationMinutes(int $duration_minutes) Return the first ChildEvent filtered by the duration_minutes column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByEndDateTime(string $end_date_time) Return the first ChildEvent filtered by the end_date_time column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByRecordTypeId(int $record_type_id) Return the first ChildEvent filtered by the record_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByEventSubTypeId(int $event_sub_type_id) Return the first ChildEvent filtered by the event_sub_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByJobStatus(string $job_status) Return the first ChildEvent filtered by the job_status column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByLocationC(string $location_c) Return the first ChildEvent filtered by the location_c column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByReminderDate(string $reminder_date) Return the first ChildEvent filtered by the reminder_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByReminderSet(boolean $reminder_set) Return the first ChildEvent filtered by the reminder_set column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByStartDateTime(string $start_date_time) Return the first ChildEvent filtered by the start_date_time column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneBySubject(string $subject) Return the first ChildEvent filtered by the subject column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByRecurrenceTimeZone(string $recurrence_time_zone) Return the first ChildEvent filtered by the recurrence_time_zone column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByCreatedBySfId(string $created_by_sf_id) Return the first ChildEvent filtered by the created_by_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByPmtoolUpdated(boolean $pmtool_updated) Return the first ChildEvent filtered by the pmtool_updated column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByEventHolderId(int $event_holder_id) Return the first ChildEvent filtered by the event_holder_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByApiCreatedDate(string $api_created_date) Return the first ChildEvent filtered by the api_created_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByApiUpdatedDate(string $api_updated_date) Return the first ChildEvent filtered by the api_updated_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByIsGroup(boolean $is_group) Return the first ChildEvent filtered by the is_group column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByCreatedDate(string $created_date) Return the first ChildEvent filtered by the created_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEvent requireOneByUpdatedDate(string $updated_date) Return the first ChildEvent filtered by the updated_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEvent[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEvent objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> find(ConnectionInterface $con = null) Return ChildEvent objects based on current ModelCriteria
 * @method     ChildEvent[]|ObjectCollection findById(int $id) Return ChildEvent objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findById(int $id) Return ChildEvent objects filtered by the id column
 * @method     ChildEvent[]|ObjectCollection findBySamsEventId(string $sams_event_id) Return ChildEvent objects filtered by the sams_event_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findBySamsEventId(string $sams_event_id) Return ChildEvent objects filtered by the sams_event_id column
 * @method     ChildEvent[]|ObjectCollection findByJobId(int $job_id) Return ChildEvent objects filtered by the job_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByJobId(int $job_id) Return ChildEvent objects filtered by the job_id column
 * @method     ChildEvent[]|ObjectCollection findByBidJobId(int $bid_job_id) Return ChildEvent objects filtered by the bid_job_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByBidJobId(int $bid_job_id) Return ChildEvent objects filtered by the bid_job_id column
 * @method     ChildEvent[]|ObjectCollection findByBidJobArchiveId(int $bid_job_archive_id) Return ChildEvent objects filtered by the bid_job_archive_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByBidJobArchiveId(int $bid_job_archive_id) Return ChildEvent objects filtered by the bid_job_archive_id column
 * @method     ChildEvent[]|ObjectCollection findByRefRoomId(int $ref_room_id) Return ChildEvent objects filtered by the ref_room_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByRefRoomId(int $ref_room_id) Return ChildEvent objects filtered by the ref_room_id column
 * @method     ChildEvent[]|ObjectCollection findByRefTimeSlotId(int $ref_time_slot_id) Return ChildEvent objects filtered by the ref_time_slot_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByRefTimeSlotId(int $ref_time_slot_id) Return ChildEvent objects filtered by the ref_time_slot_id column
 * @method     ChildEvent[]|ObjectCollection findByEventStatusId(int $event_status_id) Return ChildEvent objects filtered by the event_status_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByEventStatusId(int $event_status_id) Return ChildEvent objects filtered by the event_status_id column
 * @method     ChildEvent[]|ObjectCollection findByDate(string $date) Return ChildEvent objects filtered by the date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByDate(string $date) Return ChildEvent objects filtered by the date column
 * @method     ChildEvent[]|ObjectCollection findByConfirmedDate(string $confirmed_date) Return ChildEvent objects filtered by the confirmed_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByConfirmedDate(string $confirmed_date) Return ChildEvent objects filtered by the confirmed_date column
 * @method     ChildEvent[]|ObjectCollection findByActiveDate(string $active_date) Return ChildEvent objects filtered by the active_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByActiveDate(string $active_date) Return ChildEvent objects filtered by the active_date column
 * @method     ChildEvent[]|ObjectCollection findByEventMethodologyId(int $event_methodology_id) Return ChildEvent objects filtered by the event_methodology_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByEventMethodologyId(int $event_methodology_id) Return ChildEvent objects filtered by the event_methodology_id column
 * @method     ChildEvent[]|ObjectCollection findByStatus(int $status) Return ChildEvent objects filtered by the status column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByStatus(int $status) Return ChildEvent objects filtered by the status column
 * @method     ChildEvent[]|ObjectCollection findByComments(string $comments) Return ChildEvent objects filtered by the comments column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByComments(string $comments) Return ChildEvent objects filtered by the comments column
 * @method     ChildEvent[]|ObjectCollection findByFacilityNote(string $facility_note) Return ChildEvent objects filtered by the facility_note column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByFacilityNote(string $facility_note) Return ChildEvent objects filtered by the facility_note column
 * @method     ChildEvent[]|ObjectCollection findBySiteId(int $site_id) Return ChildEvent objects filtered by the site_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findBySiteId(int $site_id) Return ChildEvent objects filtered by the site_id column
 * @method     ChildEvent[]|ObjectCollection findByAccountId(int $account_id) Return ChildEvent objects filtered by the account_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByAccountId(int $account_id) Return ChildEvent objects filtered by the account_id column
 * @method     ChildEvent[]|ObjectCollection findByAccountSfId(string $account_sf_id) Return ChildEvent objects filtered by the account_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByAccountSfId(string $account_sf_id) Return ChildEvent objects filtered by the account_sf_id column
 * @method     ChildEvent[]|ObjectCollection findByActivityCurrency(string $activity_currency) Return ChildEvent objects filtered by the activity_currency column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByActivityCurrency(string $activity_currency) Return ChildEvent objects filtered by the activity_currency column
 * @method     ChildEvent[]|ObjectCollection findByAllDayEvent(boolean $all_day_event) Return ChildEvent objects filtered by the all_day_event column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByAllDayEvent(boolean $all_day_event) Return ChildEvent objects filtered by the all_day_event column
 * @method     ChildEvent[]|ObjectCollection findByArchived(boolean $archived) Return ChildEvent objects filtered by the archived column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByArchived(boolean $archived) Return ChildEvent objects filtered by the archived column
 * @method     ChildEvent[]|ObjectCollection findByAssignedToId(int $assigned_to_id) Return ChildEvent objects filtered by the assigned_to_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByAssignedToId(int $assigned_to_id) Return ChildEvent objects filtered by the assigned_to_id column
 * @method     ChildEvent[]|ObjectCollection findByCancelled(boolean $cancelled) Return ChildEvent objects filtered by the cancelled column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByCancelled(boolean $cancelled) Return ChildEvent objects filtered by the cancelled column
 * @method     ChildEvent[]|ObjectCollection findByRecurringEvent(boolean $recurring_event) Return ChildEvent objects filtered by the recurring_event column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByRecurringEvent(boolean $recurring_event) Return ChildEvent objects filtered by the recurring_event column
 * @method     ChildEvent[]|ObjectCollection findByIsDeleted(boolean $is_deleted) Return ChildEvent objects filtered by the is_deleted column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByIsDeleted(boolean $is_deleted) Return ChildEvent objects filtered by the is_deleted column
 * @method     ChildEvent[]|ObjectCollection findByIsDeletedC(boolean $is_deleted_c) Return ChildEvent objects filtered by the is_deleted_c column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByIsDeletedC(boolean $is_deleted_c) Return ChildEvent objects filtered by the is_deleted_c column
 * @method     ChildEvent[]|ObjectCollection findByDescription(string $description) Return ChildEvent objects filtered by the description column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByDescription(string $description) Return ChildEvent objects filtered by the description column
 * @method     ChildEvent[]|ObjectCollection findByDurationMinutes(int $duration_minutes) Return ChildEvent objects filtered by the duration_minutes column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByDurationMinutes(int $duration_minutes) Return ChildEvent objects filtered by the duration_minutes column
 * @method     ChildEvent[]|ObjectCollection findByEndDateTime(string $end_date_time) Return ChildEvent objects filtered by the end_date_time column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByEndDateTime(string $end_date_time) Return ChildEvent objects filtered by the end_date_time column
 * @method     ChildEvent[]|ObjectCollection findByRecordTypeId(int $record_type_id) Return ChildEvent objects filtered by the record_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByRecordTypeId(int $record_type_id) Return ChildEvent objects filtered by the record_type_id column
 * @method     ChildEvent[]|ObjectCollection findByEventSubTypeId(int $event_sub_type_id) Return ChildEvent objects filtered by the event_sub_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByEventSubTypeId(int $event_sub_type_id) Return ChildEvent objects filtered by the event_sub_type_id column
 * @method     ChildEvent[]|ObjectCollection findByJobStatus(string $job_status) Return ChildEvent objects filtered by the job_status column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByJobStatus(string $job_status) Return ChildEvent objects filtered by the job_status column
 * @method     ChildEvent[]|ObjectCollection findByLocationC(string $location_c) Return ChildEvent objects filtered by the location_c column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByLocationC(string $location_c) Return ChildEvent objects filtered by the location_c column
 * @method     ChildEvent[]|ObjectCollection findByReminderDate(string $reminder_date) Return ChildEvent objects filtered by the reminder_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByReminderDate(string $reminder_date) Return ChildEvent objects filtered by the reminder_date column
 * @method     ChildEvent[]|ObjectCollection findByReminderSet(boolean $reminder_set) Return ChildEvent objects filtered by the reminder_set column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByReminderSet(boolean $reminder_set) Return ChildEvent objects filtered by the reminder_set column
 * @method     ChildEvent[]|ObjectCollection findByStartDateTime(string $start_date_time) Return ChildEvent objects filtered by the start_date_time column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByStartDateTime(string $start_date_time) Return ChildEvent objects filtered by the start_date_time column
 * @method     ChildEvent[]|ObjectCollection findBySubject(string $subject) Return ChildEvent objects filtered by the subject column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findBySubject(string $subject) Return ChildEvent objects filtered by the subject column
 * @method     ChildEvent[]|ObjectCollection findByRecurrenceTimeZone(string $recurrence_time_zone) Return ChildEvent objects filtered by the recurrence_time_zone column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByRecurrenceTimeZone(string $recurrence_time_zone) Return ChildEvent objects filtered by the recurrence_time_zone column
 * @method     ChildEvent[]|ObjectCollection findByCreatedBySfId(string $created_by_sf_id) Return ChildEvent objects filtered by the created_by_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByCreatedBySfId(string $created_by_sf_id) Return ChildEvent objects filtered by the created_by_sf_id column
 * @method     ChildEvent[]|ObjectCollection findByPmtoolUpdated(boolean $pmtool_updated) Return ChildEvent objects filtered by the pmtool_updated column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByPmtoolUpdated(boolean $pmtool_updated) Return ChildEvent objects filtered by the pmtool_updated column
 * @method     ChildEvent[]|ObjectCollection findByEventHolderId(int $event_holder_id) Return ChildEvent objects filtered by the event_holder_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByEventHolderId(int $event_holder_id) Return ChildEvent objects filtered by the event_holder_id column
 * @method     ChildEvent[]|ObjectCollection findByApiCreatedDate(string $api_created_date) Return ChildEvent objects filtered by the api_created_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByApiCreatedDate(string $api_created_date) Return ChildEvent objects filtered by the api_created_date column
 * @method     ChildEvent[]|ObjectCollection findByApiUpdatedDate(string $api_updated_date) Return ChildEvent objects filtered by the api_updated_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByApiUpdatedDate(string $api_updated_date) Return ChildEvent objects filtered by the api_updated_date column
 * @method     ChildEvent[]|ObjectCollection findByIsGroup(boolean $is_group) Return ChildEvent objects filtered by the is_group column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByIsGroup(boolean $is_group) Return ChildEvent objects filtered by the is_group column
 * @method     ChildEvent[]|ObjectCollection findByCreatedDate(string $created_date) Return ChildEvent objects filtered by the created_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByCreatedDate(string $created_date) Return ChildEvent objects filtered by the created_date column
 * @method     ChildEvent[]|ObjectCollection findByUpdatedDate(string $updated_date) Return ChildEvent objects filtered by the updated_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEvent> findByUpdatedDate(string $updated_date) Return ChildEvent objects filtered by the updated_date column
 * @method     ChildEvent[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEvent> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EventQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EventQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\Event', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEventQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEventQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEventQuery) {
            return $criteria;
        }
        $query = new ChildEventQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEvent|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EventTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EventTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEvent A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `sams_event_id`, `job_id`, `bid_job_id`, `bid_job_archive_id`, `ref_room_id`, `ref_time_slot_id`, `event_status_id`, `date`, `confirmed_date`, `active_date`, `event_methodology_id`, `status`, `comments`, `facility_note`, `site_id`, `account_id`, `account_sf_id`, `activity_currency`, `all_day_event`, `archived`, `assigned_to_id`, `cancelled`, `recurring_event`, `is_deleted`, `is_deleted_c`, `description`, `duration_minutes`, `end_date_time`, `record_type_id`, `event_sub_type_id`, `job_status`, `location_c`, `reminder_date`, `reminder_set`, `start_date_time`, `subject`, `recurrence_time_zone`, `created_by_sf_id`, `pmtool_updated`, `event_holder_id`, `api_created_date`, `api_updated_date`, `is_group`, `created_date`, `updated_date` FROM `event` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEvent $obj */
            $obj = new ChildEvent();
            $obj->hydrate($row);
            EventTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEvent|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EventTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EventTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EventTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EventTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the sams_event_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySamsEventId('fooValue');   // WHERE sams_event_id = 'fooValue'
     * $query->filterBySamsEventId('%fooValue%', Criteria::LIKE); // WHERE sams_event_id LIKE '%fooValue%'
     * $query->filterBySamsEventId(['foo', 'bar']); // WHERE sams_event_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $samsEventId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterBySamsEventId($samsEventId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($samsEventId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_SAMS_EVENT_ID, $samsEventId, $comparison);
    }

    /**
     * Filter the query on the job_id column
     *
     * Example usage:
     * <code>
     * $query->filterByJobId(1234); // WHERE job_id = 1234
     * $query->filterByJobId(array(12, 34)); // WHERE job_id IN (12, 34)
     * $query->filterByJobId(array('min' => 12)); // WHERE job_id > 12
     * </code>
     *
     * @see       filterByJob()
     *
     * @param     mixed $jobId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByJobId($jobId = null, $comparison = null)
    {
        if (is_array($jobId)) {
            $useMinMax = false;
            if (isset($jobId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_JOB_ID, $jobId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jobId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_JOB_ID, $jobId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_JOB_ID, $jobId, $comparison);
    }

    /**
     * Filter the query on the bid_job_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBidJobId(1234); // WHERE bid_job_id = 1234
     * $query->filterByBidJobId(array(12, 34)); // WHERE bid_job_id IN (12, 34)
     * $query->filterByBidJobId(array('min' => 12)); // WHERE bid_job_id > 12
     * </code>
     *
     * @see       filterByBidJob()
     *
     * @param     mixed $bidJobId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByBidJobId($bidJobId = null, $comparison = null)
    {
        if (is_array($bidJobId)) {
            $useMinMax = false;
            if (isset($bidJobId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_BID_JOB_ID, $bidJobId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($bidJobId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_BID_JOB_ID, $bidJobId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_BID_JOB_ID, $bidJobId, $comparison);
    }

    /**
     * Filter the query on the bid_job_archive_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBidJobArchiveId(1234); // WHERE bid_job_archive_id = 1234
     * $query->filterByBidJobArchiveId(array(12, 34)); // WHERE bid_job_archive_id IN (12, 34)
     * $query->filterByBidJobArchiveId(array('min' => 12)); // WHERE bid_job_archive_id > 12
     * </code>
     *
     * @param     mixed $bidJobArchiveId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByBidJobArchiveId($bidJobArchiveId = null, $comparison = null)
    {
        if (is_array($bidJobArchiveId)) {
            $useMinMax = false;
            if (isset($bidJobArchiveId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_BID_JOB_ARCHIVE_ID, $bidJobArchiveId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($bidJobArchiveId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_BID_JOB_ARCHIVE_ID, $bidJobArchiveId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_BID_JOB_ARCHIVE_ID, $bidJobArchiveId, $comparison);
    }

    /**
     * Filter the query on the ref_room_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRefRoomId(1234); // WHERE ref_room_id = 1234
     * $query->filterByRefRoomId(array(12, 34)); // WHERE ref_room_id IN (12, 34)
     * $query->filterByRefRoomId(array('min' => 12)); // WHERE ref_room_id > 12
     * </code>
     *
     * @see       filterByRefRoom()
     *
     * @param     mixed $refRoomId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByRefRoomId($refRoomId = null, $comparison = null)
    {
        if (is_array($refRoomId)) {
            $useMinMax = false;
            if (isset($refRoomId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_REF_ROOM_ID, $refRoomId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($refRoomId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_REF_ROOM_ID, $refRoomId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_REF_ROOM_ID, $refRoomId, $comparison);
    }

    /**
     * Filter the query on the ref_time_slot_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRefTimeSlotId(1234); // WHERE ref_time_slot_id = 1234
     * $query->filterByRefTimeSlotId(array(12, 34)); // WHERE ref_time_slot_id IN (12, 34)
     * $query->filterByRefTimeSlotId(array('min' => 12)); // WHERE ref_time_slot_id > 12
     * </code>
     *
     * @see       filterByRefTimeSlot()
     *
     * @param     mixed $refTimeSlotId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByRefTimeSlotId($refTimeSlotId = null, $comparison = null)
    {
        if (is_array($refTimeSlotId)) {
            $useMinMax = false;
            if (isset($refTimeSlotId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_REF_TIME_SLOT_ID, $refTimeSlotId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($refTimeSlotId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_REF_TIME_SLOT_ID, $refTimeSlotId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_REF_TIME_SLOT_ID, $refTimeSlotId, $comparison);
    }

    /**
     * Filter the query on the event_status_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventStatusId(1234); // WHERE event_status_id = 1234
     * $query->filterByEventStatusId(array(12, 34)); // WHERE event_status_id IN (12, 34)
     * $query->filterByEventStatusId(array('min' => 12)); // WHERE event_status_id > 12
     * </code>
     *
     * @see       filterByRefEventStatus()
     *
     * @param     mixed $eventStatusId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventStatusId($eventStatusId = null, $comparison = null)
    {
        if (is_array($eventStatusId)) {
            $useMinMax = false;
            if (isset($eventStatusId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_STATUS_ID, $eventStatusId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventStatusId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_STATUS_ID, $eventStatusId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_EVENT_STATUS_ID, $eventStatusId, $comparison);
    }

    /**
     * Filter the query on the date column
     *
     * Example usage:
     * <code>
     * $query->filterByDate('2011-03-14'); // WHERE date = '2011-03-14'
     * $query->filterByDate('now'); // WHERE date = '2011-03-14'
     * $query->filterByDate(array('max' => 'yesterday')); // WHERE date > '2011-03-13'
     * </code>
     *
     * @param     mixed $date The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByDate($date = null, $comparison = null)
    {
        if (is_array($date)) {
            $useMinMax = false;
            if (isset($date['min'])) {
                $this->addUsingAlias(EventTableMap::COL_DATE, $date['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($date['max'])) {
                $this->addUsingAlias(EventTableMap::COL_DATE, $date['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_DATE, $date, $comparison);
    }

    /**
     * Filter the query on the confirmed_date column
     *
     * Example usage:
     * <code>
     * $query->filterByConfirmedDate('2011-03-14'); // WHERE confirmed_date = '2011-03-14'
     * $query->filterByConfirmedDate('now'); // WHERE confirmed_date = '2011-03-14'
     * $query->filterByConfirmedDate(array('max' => 'yesterday')); // WHERE confirmed_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $confirmedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByConfirmedDate($confirmedDate = null, $comparison = null)
    {
        if (is_array($confirmedDate)) {
            $useMinMax = false;
            if (isset($confirmedDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_CONFIRMED_DATE, $confirmedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($confirmedDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_CONFIRMED_DATE, $confirmedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_CONFIRMED_DATE, $confirmedDate, $comparison);
    }

    /**
     * Filter the query on the active_date column
     *
     * Example usage:
     * <code>
     * $query->filterByActiveDate('2011-03-14'); // WHERE active_date = '2011-03-14'
     * $query->filterByActiveDate('now'); // WHERE active_date = '2011-03-14'
     * $query->filterByActiveDate(array('max' => 'yesterday')); // WHERE active_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $activeDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByActiveDate($activeDate = null, $comparison = null)
    {
        if (is_array($activeDate)) {
            $useMinMax = false;
            if (isset($activeDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_ACTIVE_DATE, $activeDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($activeDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_ACTIVE_DATE, $activeDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ACTIVE_DATE, $activeDate, $comparison);
    }

    /**
     * Filter the query on the event_methodology_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventMethodologyId(1234); // WHERE event_methodology_id = 1234
     * $query->filterByEventMethodologyId(array(12, 34)); // WHERE event_methodology_id IN (12, 34)
     * $query->filterByEventMethodologyId(array('min' => 12)); // WHERE event_methodology_id > 12
     * </code>
     *
     * @see       filterByEventMethodology()
     *
     * @param     mixed $eventMethodologyId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventMethodologyId($eventMethodologyId = null, $comparison = null)
    {
        if (is_array($eventMethodologyId)) {
            $useMinMax = false;
            if (isset($eventMethodologyId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_METHODOLOGY_ID, $eventMethodologyId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventMethodologyId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_METHODOLOGY_ID, $eventMethodologyId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_EVENT_METHODOLOGY_ID, $eventMethodologyId, $comparison);
    }

    /**
     * Filter the query on the status column
     *
     * @param     mixed $status The value to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByStatus($status = null, $comparison = null)
    {
        $valueSet = EventTableMap::getValueSet(EventTableMap::COL_STATUS);
        if (is_scalar($status)) {
            if (!in_array($status, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $status));
            }
            $status = array_search($status, $valueSet);
        } elseif (is_array($status)) {
            $convertedValues = array();
            foreach ($status as $value) {
                if (!in_array($value, $valueSet)) {
                    throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $value));
                }
                $convertedValues []= array_search($value, $valueSet);
            }
            $status = $convertedValues;
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_STATUS, $status, $comparison);
    }

    /**
     * Filter the query on the comments column
     *
     * Example usage:
     * <code>
     * $query->filterByComments('fooValue');   // WHERE comments = 'fooValue'
     * $query->filterByComments('%fooValue%', Criteria::LIKE); // WHERE comments LIKE '%fooValue%'
     * $query->filterByComments(['foo', 'bar']); // WHERE comments IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $comments The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByComments($comments = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($comments)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_COMMENTS, $comments, $comparison);
    }

    /**
     * Filter the query on the facility_note column
     *
     * Example usage:
     * <code>
     * $query->filterByFacilityNote('fooValue');   // WHERE facility_note = 'fooValue'
     * $query->filterByFacilityNote('%fooValue%', Criteria::LIKE); // WHERE facility_note LIKE '%fooValue%'
     * $query->filterByFacilityNote(['foo', 'bar']); // WHERE facility_note IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $facilityNote The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByFacilityNote($facilityNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($facilityNote)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_FACILITY_NOTE, $facilityNote, $comparison);
    }

    /**
     * Filter the query on the site_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySiteId(1234); // WHERE site_id = 1234
     * $query->filterBySiteId(array(12, 34)); // WHERE site_id IN (12, 34)
     * $query->filterBySiteId(array('min' => 12)); // WHERE site_id > 12
     * </code>
     *
     * @see       filterBySite()
     *
     * @param     mixed $siteId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterBySiteId($siteId = null, $comparison = null)
    {
        if (is_array($siteId)) {
            $useMinMax = false;
            if (isset($siteId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_SITE_ID, $siteId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($siteId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_SITE_ID, $siteId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_SITE_ID, $siteId, $comparison);
    }

    /**
     * Filter the query on the account_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountId(1234); // WHERE account_id = 1234
     * $query->filterByAccountId(array(12, 34)); // WHERE account_id IN (12, 34)
     * $query->filterByAccountId(array('min' => 12)); // WHERE account_id > 12
     * </code>
     *
     * @see       filterByAccount()
     *
     * @param     mixed $accountId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByAccountId($accountId = null, $comparison = null)
    {
        if (is_array($accountId)) {
            $useMinMax = false;
            if (isset($accountId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_ACCOUNT_ID, $accountId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_ACCOUNT_ID, $accountId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ACCOUNT_ID, $accountId, $comparison);
    }

    /**
     * Filter the query on the account_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountSfId('fooValue');   // WHERE account_sf_id = 'fooValue'
     * $query->filterByAccountSfId('%fooValue%', Criteria::LIKE); // WHERE account_sf_id LIKE '%fooValue%'
     * $query->filterByAccountSfId(['foo', 'bar']); // WHERE account_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $accountSfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByAccountSfId($accountSfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($accountSfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ACCOUNT_SF_ID, $accountSfId, $comparison);
    }

    /**
     * Filter the query on the activity_currency column
     *
     * Example usage:
     * <code>
     * $query->filterByActivityCurrency('fooValue');   // WHERE activity_currency = 'fooValue'
     * $query->filterByActivityCurrency('%fooValue%', Criteria::LIKE); // WHERE activity_currency LIKE '%fooValue%'
     * $query->filterByActivityCurrency(['foo', 'bar']); // WHERE activity_currency IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $activityCurrency The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByActivityCurrency($activityCurrency = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($activityCurrency)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ACTIVITY_CURRENCY, $activityCurrency, $comparison);
    }

    /**
     * Filter the query on the all_day_event column
     *
     * Example usage:
     * <code>
     * $query->filterByAllDayEvent(true); // WHERE all_day_event = true
     * $query->filterByAllDayEvent('yes'); // WHERE all_day_event = true
     * </code>
     *
     * @param     boolean|string $allDayEvent The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByAllDayEvent($allDayEvent = null, $comparison = null)
    {
        if (is_string($allDayEvent)) {
            $allDayEvent = in_array(strtolower($allDayEvent), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_ALL_DAY_EVENT, $allDayEvent, $comparison);
    }

    /**
     * Filter the query on the archived column
     *
     * Example usage:
     * <code>
     * $query->filterByArchived(true); // WHERE archived = true
     * $query->filterByArchived('yes'); // WHERE archived = true
     * </code>
     *
     * @param     boolean|string $archived The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByArchived($archived = null, $comparison = null)
    {
        if (is_string($archived)) {
            $archived = in_array(strtolower($archived), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_ARCHIVED, $archived, $comparison);
    }

    /**
     * Filter the query on the assigned_to_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAssignedToId(1234); // WHERE assigned_to_id = 1234
     * $query->filterByAssignedToId(array(12, 34)); // WHERE assigned_to_id IN (12, 34)
     * $query->filterByAssignedToId(array('min' => 12)); // WHERE assigned_to_id > 12
     * </code>
     *
     * @see       filterByAssignedTo()
     *
     * @param     mixed $assignedToId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByAssignedToId($assignedToId = null, $comparison = null)
    {
        if (is_array($assignedToId)) {
            $useMinMax = false;
            if (isset($assignedToId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_ASSIGNED_TO_ID, $assignedToId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($assignedToId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_ASSIGNED_TO_ID, $assignedToId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_ASSIGNED_TO_ID, $assignedToId, $comparison);
    }

    /**
     * Filter the query on the cancelled column
     *
     * Example usage:
     * <code>
     * $query->filterByCancelled(true); // WHERE cancelled = true
     * $query->filterByCancelled('yes'); // WHERE cancelled = true
     * </code>
     *
     * @param     boolean|string $cancelled The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByCancelled($cancelled = null, $comparison = null)
    {
        if (is_string($cancelled)) {
            $cancelled = in_array(strtolower($cancelled), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_CANCELLED, $cancelled, $comparison);
    }

    /**
     * Filter the query on the recurring_event column
     *
     * Example usage:
     * <code>
     * $query->filterByRecurringEvent(true); // WHERE recurring_event = true
     * $query->filterByRecurringEvent('yes'); // WHERE recurring_event = true
     * </code>
     *
     * @param     boolean|string $recurringEvent The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByRecurringEvent($recurringEvent = null, $comparison = null)
    {
        if (is_string($recurringEvent)) {
            $recurringEvent = in_array(strtolower($recurringEvent), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_RECURRING_EVENT, $recurringEvent, $comparison);
    }

    /**
     * Filter the query on the is_deleted column
     *
     * Example usage:
     * <code>
     * $query->filterByIsDeleted(true); // WHERE is_deleted = true
     * $query->filterByIsDeleted('yes'); // WHERE is_deleted = true
     * </code>
     *
     * @param     boolean|string $isDeleted The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByIsDeleted($isDeleted = null, $comparison = null)
    {
        if (is_string($isDeleted)) {
            $isDeleted = in_array(strtolower($isDeleted), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_IS_DELETED, $isDeleted, $comparison);
    }

    /**
     * Filter the query on the is_deleted_c column
     *
     * Example usage:
     * <code>
     * $query->filterByIsDeletedC(true); // WHERE is_deleted_c = true
     * $query->filterByIsDeletedC('yes'); // WHERE is_deleted_c = true
     * </code>
     *
     * @param     boolean|string $isDeletedC The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByIsDeletedC($isDeletedC = null, $comparison = null)
    {
        if (is_string($isDeletedC)) {
            $isDeletedC = in_array(strtolower($isDeletedC), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_IS_DELETED_C, $isDeletedC, $comparison);
    }

    /**
     * Filter the query on the description column
     *
     * Example usage:
     * <code>
     * $query->filterByDescription('fooValue');   // WHERE description = 'fooValue'
     * $query->filterByDescription('%fooValue%', Criteria::LIKE); // WHERE description LIKE '%fooValue%'
     * $query->filterByDescription(['foo', 'bar']); // WHERE description IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $description The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByDescription($description = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($description)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_DESCRIPTION, $description, $comparison);
    }

    /**
     * Filter the query on the duration_minutes column
     *
     * Example usage:
     * <code>
     * $query->filterByDurationMinutes(1234); // WHERE duration_minutes = 1234
     * $query->filterByDurationMinutes(array(12, 34)); // WHERE duration_minutes IN (12, 34)
     * $query->filterByDurationMinutes(array('min' => 12)); // WHERE duration_minutes > 12
     * </code>
     *
     * @param     mixed $durationMinutes The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByDurationMinutes($durationMinutes = null, $comparison = null)
    {
        if (is_array($durationMinutes)) {
            $useMinMax = false;
            if (isset($durationMinutes['min'])) {
                $this->addUsingAlias(EventTableMap::COL_DURATION_MINUTES, $durationMinutes['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($durationMinutes['max'])) {
                $this->addUsingAlias(EventTableMap::COL_DURATION_MINUTES, $durationMinutes['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_DURATION_MINUTES, $durationMinutes, $comparison);
    }

    /**
     * Filter the query on the end_date_time column
     *
     * Example usage:
     * <code>
     * $query->filterByEndDateTime('2011-03-14'); // WHERE end_date_time = '2011-03-14'
     * $query->filterByEndDateTime('now'); // WHERE end_date_time = '2011-03-14'
     * $query->filterByEndDateTime(array('max' => 'yesterday')); // WHERE end_date_time > '2011-03-13'
     * </code>
     *
     * @param     mixed $endDateTime The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByEndDateTime($endDateTime = null, $comparison = null)
    {
        if (is_array($endDateTime)) {
            $useMinMax = false;
            if (isset($endDateTime['min'])) {
                $this->addUsingAlias(EventTableMap::COL_END_DATE_TIME, $endDateTime['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endDateTime['max'])) {
                $this->addUsingAlias(EventTableMap::COL_END_DATE_TIME, $endDateTime['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_END_DATE_TIME, $endDateTime, $comparison);
    }

    /**
     * Filter the query on the record_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRecordTypeId(1234); // WHERE record_type_id = 1234
     * $query->filterByRecordTypeId(array(12, 34)); // WHERE record_type_id IN (12, 34)
     * $query->filterByRecordTypeId(array('min' => 12)); // WHERE record_type_id > 12
     * </code>
     *
     * @see       filterByRecordType()
     *
     * @param     mixed $recordTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByRecordTypeId($recordTypeId = null, $comparison = null)
    {
        if (is_array($recordTypeId)) {
            $useMinMax = false;
            if (isset($recordTypeId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_RECORD_TYPE_ID, $recordTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($recordTypeId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_RECORD_TYPE_ID, $recordTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_RECORD_TYPE_ID, $recordTypeId, $comparison);
    }

    /**
     * Filter the query on the event_sub_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventSubTypeId(1234); // WHERE event_sub_type_id = 1234
     * $query->filterByEventSubTypeId(array(12, 34)); // WHERE event_sub_type_id IN (12, 34)
     * $query->filterByEventSubTypeId(array('min' => 12)); // WHERE event_sub_type_id > 12
     * </code>
     *
     * @see       filterByEventSubType()
     *
     * @param     mixed $eventSubTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventSubTypeId($eventSubTypeId = null, $comparison = null)
    {
        if (is_array($eventSubTypeId)) {
            $useMinMax = false;
            if (isset($eventSubTypeId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_SUB_TYPE_ID, $eventSubTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventSubTypeId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_SUB_TYPE_ID, $eventSubTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_EVENT_SUB_TYPE_ID, $eventSubTypeId, $comparison);
    }

    /**
     * Filter the query on the job_status column
     *
     * Example usage:
     * <code>
     * $query->filterByJobStatus('fooValue');   // WHERE job_status = 'fooValue'
     * $query->filterByJobStatus('%fooValue%', Criteria::LIKE); // WHERE job_status LIKE '%fooValue%'
     * $query->filterByJobStatus(['foo', 'bar']); // WHERE job_status IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $jobStatus The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByJobStatus($jobStatus = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($jobStatus)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_JOB_STATUS, $jobStatus, $comparison);
    }

    /**
     * Filter the query on the location_c column
     *
     * Example usage:
     * <code>
     * $query->filterByLocationC('fooValue');   // WHERE location_c = 'fooValue'
     * $query->filterByLocationC('%fooValue%', Criteria::LIKE); // WHERE location_c LIKE '%fooValue%'
     * $query->filterByLocationC(['foo', 'bar']); // WHERE location_c IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $locationC The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByLocationC($locationC = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($locationC)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_LOCATION_C, $locationC, $comparison);
    }

    /**
     * Filter the query on the reminder_date column
     *
     * Example usage:
     * <code>
     * $query->filterByReminderDate('2011-03-14'); // WHERE reminder_date = '2011-03-14'
     * $query->filterByReminderDate('now'); // WHERE reminder_date = '2011-03-14'
     * $query->filterByReminderDate(array('max' => 'yesterday')); // WHERE reminder_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $reminderDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByReminderDate($reminderDate = null, $comparison = null)
    {
        if (is_array($reminderDate)) {
            $useMinMax = false;
            if (isset($reminderDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_REMINDER_DATE, $reminderDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($reminderDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_REMINDER_DATE, $reminderDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_REMINDER_DATE, $reminderDate, $comparison);
    }

    /**
     * Filter the query on the reminder_set column
     *
     * Example usage:
     * <code>
     * $query->filterByReminderSet(true); // WHERE reminder_set = true
     * $query->filterByReminderSet('yes'); // WHERE reminder_set = true
     * </code>
     *
     * @param     boolean|string $reminderSet The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByReminderSet($reminderSet = null, $comparison = null)
    {
        if (is_string($reminderSet)) {
            $reminderSet = in_array(strtolower($reminderSet), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_REMINDER_SET, $reminderSet, $comparison);
    }

    /**
     * Filter the query on the start_date_time column
     *
     * Example usage:
     * <code>
     * $query->filterByStartDateTime('2011-03-14'); // WHERE start_date_time = '2011-03-14'
     * $query->filterByStartDateTime('now'); // WHERE start_date_time = '2011-03-14'
     * $query->filterByStartDateTime(array('max' => 'yesterday')); // WHERE start_date_time > '2011-03-13'
     * </code>
     *
     * @param     mixed $startDateTime The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByStartDateTime($startDateTime = null, $comparison = null)
    {
        if (is_array($startDateTime)) {
            $useMinMax = false;
            if (isset($startDateTime['min'])) {
                $this->addUsingAlias(EventTableMap::COL_START_DATE_TIME, $startDateTime['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($startDateTime['max'])) {
                $this->addUsingAlias(EventTableMap::COL_START_DATE_TIME, $startDateTime['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_START_DATE_TIME, $startDateTime, $comparison);
    }

    /**
     * Filter the query on the subject column
     *
     * Example usage:
     * <code>
     * $query->filterBySubject('fooValue');   // WHERE subject = 'fooValue'
     * $query->filterBySubject('%fooValue%', Criteria::LIKE); // WHERE subject LIKE '%fooValue%'
     * $query->filterBySubject(['foo', 'bar']); // WHERE subject IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $subject The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterBySubject($subject = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($subject)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_SUBJECT, $subject, $comparison);
    }

    /**
     * Filter the query on the recurrence_time_zone column
     *
     * Example usage:
     * <code>
     * $query->filterByRecurrenceTimeZone('fooValue');   // WHERE recurrence_time_zone = 'fooValue'
     * $query->filterByRecurrenceTimeZone('%fooValue%', Criteria::LIKE); // WHERE recurrence_time_zone LIKE '%fooValue%'
     * $query->filterByRecurrenceTimeZone(['foo', 'bar']); // WHERE recurrence_time_zone IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $recurrenceTimeZone The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByRecurrenceTimeZone($recurrenceTimeZone = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($recurrenceTimeZone)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_RECURRENCE_TIME_ZONE, $recurrenceTimeZone, $comparison);
    }

    /**
     * Filter the query on the created_by_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBySfId('fooValue');   // WHERE created_by_sf_id = 'fooValue'
     * $query->filterByCreatedBySfId('%fooValue%', Criteria::LIKE); // WHERE created_by_sf_id LIKE '%fooValue%'
     * $query->filterByCreatedBySfId(['foo', 'bar']); // WHERE created_by_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $createdBySfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByCreatedBySfId($createdBySfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBySfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_CREATED_BY_SF_ID, $createdBySfId, $comparison);
    }

    /**
     * Filter the query on the pmtool_updated column
     *
     * Example usage:
     * <code>
     * $query->filterByPmtoolUpdated(true); // WHERE pmtool_updated = true
     * $query->filterByPmtoolUpdated('yes'); // WHERE pmtool_updated = true
     * </code>
     *
     * @param     boolean|string $pmtoolUpdated The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByPmtoolUpdated($pmtoolUpdated = null, $comparison = null)
    {
        if (is_string($pmtoolUpdated)) {
            $pmtoolUpdated = in_array(strtolower($pmtoolUpdated), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_PMTOOL_UPDATED, $pmtoolUpdated, $comparison);
    }

    /**
     * Filter the query on the event_holder_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventHolderId(1234); // WHERE event_holder_id = 1234
     * $query->filterByEventHolderId(array(12, 34)); // WHERE event_holder_id IN (12, 34)
     * $query->filterByEventHolderId(array('min' => 12)); // WHERE event_holder_id > 12
     * </code>
     *
     * @see       filterByEventHolderBy()
     *
     * @param     mixed $eventHolderId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventHolderId($eventHolderId = null, $comparison = null)
    {
        if (is_array($eventHolderId)) {
            $useMinMax = false;
            if (isset($eventHolderId['min'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_HOLDER_ID, $eventHolderId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventHolderId['max'])) {
                $this->addUsingAlias(EventTableMap::COL_EVENT_HOLDER_ID, $eventHolderId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_EVENT_HOLDER_ID, $eventHolderId, $comparison);
    }

    /**
     * Filter the query on the api_created_date column
     *
     * Example usage:
     * <code>
     * $query->filterByApiCreatedDate('2011-03-14'); // WHERE api_created_date = '2011-03-14'
     * $query->filterByApiCreatedDate('now'); // WHERE api_created_date = '2011-03-14'
     * $query->filterByApiCreatedDate(array('max' => 'yesterday')); // WHERE api_created_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $apiCreatedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByApiCreatedDate($apiCreatedDate = null, $comparison = null)
    {
        if (is_array($apiCreatedDate)) {
            $useMinMax = false;
            if (isset($apiCreatedDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_API_CREATED_DATE, $apiCreatedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($apiCreatedDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_API_CREATED_DATE, $apiCreatedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_API_CREATED_DATE, $apiCreatedDate, $comparison);
    }

    /**
     * Filter the query on the api_updated_date column
     *
     * Example usage:
     * <code>
     * $query->filterByApiUpdatedDate('2011-03-14'); // WHERE api_updated_date = '2011-03-14'
     * $query->filterByApiUpdatedDate('now'); // WHERE api_updated_date = '2011-03-14'
     * $query->filterByApiUpdatedDate(array('max' => 'yesterday')); // WHERE api_updated_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $apiUpdatedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByApiUpdatedDate($apiUpdatedDate = null, $comparison = null)
    {
        if (is_array($apiUpdatedDate)) {
            $useMinMax = false;
            if (isset($apiUpdatedDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($apiUpdatedDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate, $comparison);
    }

    /**
     * Filter the query on the is_group column
     *
     * Example usage:
     * <code>
     * $query->filterByIsGroup(true); // WHERE is_group = true
     * $query->filterByIsGroup('yes'); // WHERE is_group = true
     * </code>
     *
     * @param     boolean|string $isGroup The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByIsGroup($isGroup = null, $comparison = null)
    {
        if (is_string($isGroup)) {
            $isGroup = in_array(strtolower($isGroup), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventTableMap::COL_IS_GROUP, $isGroup, $comparison);
    }

    /**
     * Filter the query on the created_date column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedDate('2011-03-14'); // WHERE created_date = '2011-03-14'
     * $query->filterByCreatedDate('now'); // WHERE created_date = '2011-03-14'
     * $query->filterByCreatedDate(array('max' => 'yesterday')); // WHERE created_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $createdDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByCreatedDate($createdDate = null, $comparison = null)
    {
        if (is_array($createdDate)) {
            $useMinMax = false;
            if (isset($createdDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_CREATED_DATE, $createdDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_CREATED_DATE, $createdDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_CREATED_DATE, $createdDate, $comparison);
    }

    /**
     * Filter the query on the updated_date column
     *
     * Example usage:
     * <code>
     * $query->filterByUpdatedDate('2011-03-14'); // WHERE updated_date = '2011-03-14'
     * $query->filterByUpdatedDate('now'); // WHERE updated_date = '2011-03-14'
     * $query->filterByUpdatedDate(array('max' => 'yesterday')); // WHERE updated_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $updatedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function filterByUpdatedDate($updatedDate = null, $comparison = null)
    {
        if (is_array($updatedDate)) {
            $useMinMax = false;
            if (isset($updatedDate['min'])) {
                $this->addUsingAlias(EventTableMap::COL_UPDATED_DATE, $updatedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($updatedDate['max'])) {
                $this->addUsingAlias(EventTableMap::COL_UPDATED_DATE, $updatedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventTableMap::COL_UPDATED_DATE, $updatedDate, $comparison);
    }

    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventHolderBy($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_HOLDER_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_HOLDER_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEventHolderBy() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EventHolderBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinEventHolderBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EventHolderBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EventHolderBy');
        }

        return $this;
    }

    /**
     * Use the EventHolderBy relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useEventHolderByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEventHolderBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EventHolderBy', '\Model\UserQuery');
    }

    /**
     * Use the EventHolderBy relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventHolderByQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEventHolderByQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EventHolderBy relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useEventHolderByExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EventHolderBy', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EventHolderBy relation to the User table for a NOT EXISTS query.
     *
     * @see useEventHolderByExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventHolderByNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EventHolderBy', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Job object
     *
     * @param \Model\Job|ObjectCollection $job The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByJob($job, $comparison = null)
    {
        if ($job instanceof \Model\Job) {
            return $this
                ->addUsingAlias(EventTableMap::COL_JOB_ID, $job->getId(), $comparison);
        } elseif ($job instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_JOB_ID, $job->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByJob() only accepts arguments of type \Model\Job or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Job relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinJob($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Job');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Job');
        }

        return $this;
    }

    /**
     * Use the Job relation Job object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\JobQuery A secondary query class using the current class as primary query
     */
    public function useJobQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinJob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Job', '\Model\JobQuery');
    }

    /**
     * Use the Job relation Job object
     *
     * @param callable(\Model\JobQuery):\Model\JobQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withJobQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useJobQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Job table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\JobQuery The inner query object of the EXISTS statement
     */
    public function useJobExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Job', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Job table for a NOT EXISTS query.
     *
     * @see useJobExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\JobQuery The inner query object of the NOT EXISTS statement
     */
    public function useJobNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Job', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\BidJob object
     *
     * @param \Model\BidJob|ObjectCollection $bidJob The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByBidJob($bidJob, $comparison = null)
    {
        if ($bidJob instanceof \Model\BidJob) {
            return $this
                ->addUsingAlias(EventTableMap::COL_BID_JOB_ID, $bidJob->getId(), $comparison);
        } elseif ($bidJob instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_BID_JOB_ID, $bidJob->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByBidJob() only accepts arguments of type \Model\BidJob or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BidJob relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinBidJob($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BidJob');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BidJob');
        }

        return $this;
    }

    /**
     * Use the BidJob relation BidJob object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\BidJobQuery A secondary query class using the current class as primary query
     */
    public function useBidJobQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinBidJob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BidJob', '\Model\BidJobQuery');
    }

    /**
     * Use the BidJob relation BidJob object
     *
     * @param callable(\Model\BidJobQuery):\Model\BidJobQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withBidJobQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useBidJobQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to BidJob table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\BidJobQuery The inner query object of the EXISTS statement
     */
    public function useBidJobExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('BidJob', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to BidJob table for a NOT EXISTS query.
     *
     * @see useBidJobExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\BidJobQuery The inner query object of the NOT EXISTS statement
     */
    public function useBidJobNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('BidJob', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefRoom object
     *
     * @param \Model\RefRoom|ObjectCollection $refRoom The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByRefRoom($refRoom, $comparison = null)
    {
        if ($refRoom instanceof \Model\RefRoom) {
            return $this
                ->addUsingAlias(EventTableMap::COL_REF_ROOM_ID, $refRoom->getId(), $comparison);
        } elseif ($refRoom instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_REF_ROOM_ID, $refRoom->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByRefRoom() only accepts arguments of type \Model\RefRoom or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RefRoom relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinRefRoom($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RefRoom');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RefRoom');
        }

        return $this;
    }

    /**
     * Use the RefRoom relation RefRoom object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefRoomQuery A secondary query class using the current class as primary query
     */
    public function useRefRoomQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinRefRoom($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RefRoom', '\Model\RefRoomQuery');
    }

    /**
     * Use the RefRoom relation RefRoom object
     *
     * @param callable(\Model\RefRoomQuery):\Model\RefRoomQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withRefRoomQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useRefRoomQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to RefRoom table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefRoomQuery The inner query object of the EXISTS statement
     */
    public function useRefRoomExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('RefRoom', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to RefRoom table for a NOT EXISTS query.
     *
     * @see useRefRoomExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefRoomQuery The inner query object of the NOT EXISTS statement
     */
    public function useRefRoomNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('RefRoom', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefEventStatus object
     *
     * @param \Model\RefEventStatus|ObjectCollection $refEventStatus The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByRefEventStatus($refEventStatus, $comparison = null)
    {
        if ($refEventStatus instanceof \Model\RefEventStatus) {
            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_STATUS_ID, $refEventStatus->getId(), $comparison);
        } elseif ($refEventStatus instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_STATUS_ID, $refEventStatus->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByRefEventStatus() only accepts arguments of type \Model\RefEventStatus or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RefEventStatus relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinRefEventStatus($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RefEventStatus');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RefEventStatus');
        }

        return $this;
    }

    /**
     * Use the RefEventStatus relation RefEventStatus object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefEventStatusQuery A secondary query class using the current class as primary query
     */
    public function useRefEventStatusQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinRefEventStatus($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RefEventStatus', '\Model\RefEventStatusQuery');
    }

    /**
     * Use the RefEventStatus relation RefEventStatus object
     *
     * @param callable(\Model\RefEventStatusQuery):\Model\RefEventStatusQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withRefEventStatusQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useRefEventStatusQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to RefEventStatus table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefEventStatusQuery The inner query object of the EXISTS statement
     */
    public function useRefEventStatusExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('RefEventStatus', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to RefEventStatus table for a NOT EXISTS query.
     *
     * @see useRefEventStatusExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefEventStatusQuery The inner query object of the NOT EXISTS statement
     */
    public function useRefEventStatusNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('RefEventStatus', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefTimeSlot object
     *
     * @param \Model\RefTimeSlot|ObjectCollection $refTimeSlot The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByRefTimeSlot($refTimeSlot, $comparison = null)
    {
        if ($refTimeSlot instanceof \Model\RefTimeSlot) {
            return $this
                ->addUsingAlias(EventTableMap::COL_REF_TIME_SLOT_ID, $refTimeSlot->getId(), $comparison);
        } elseif ($refTimeSlot instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_REF_TIME_SLOT_ID, $refTimeSlot->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByRefTimeSlot() only accepts arguments of type \Model\RefTimeSlot or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RefTimeSlot relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinRefTimeSlot($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RefTimeSlot');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RefTimeSlot');
        }

        return $this;
    }

    /**
     * Use the RefTimeSlot relation RefTimeSlot object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefTimeSlotQuery A secondary query class using the current class as primary query
     */
    public function useRefTimeSlotQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinRefTimeSlot($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RefTimeSlot', '\Model\RefTimeSlotQuery');
    }

    /**
     * Use the RefTimeSlot relation RefTimeSlot object
     *
     * @param callable(\Model\RefTimeSlotQuery):\Model\RefTimeSlotQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withRefTimeSlotQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useRefTimeSlotQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to RefTimeSlot table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefTimeSlotQuery The inner query object of the EXISTS statement
     */
    public function useRefTimeSlotExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('RefTimeSlot', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to RefTimeSlot table for a NOT EXISTS query.
     *
     * @see useRefTimeSlotExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefTimeSlotQuery The inner query object of the NOT EXISTS statement
     */
    public function useRefTimeSlotNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('RefTimeSlot', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EventMethodology object
     *
     * @param \Model\EventMethodology|ObjectCollection $eventMethodology The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventMethodology($eventMethodology, $comparison = null)
    {
        if ($eventMethodology instanceof \Model\EventMethodology) {
            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_METHODOLOGY_ID, $eventMethodology->getId(), $comparison);
        } elseif ($eventMethodology instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_METHODOLOGY_ID, $eventMethodology->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEventMethodology() only accepts arguments of type \Model\EventMethodology or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EventMethodology relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinEventMethodology($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EventMethodology');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EventMethodology');
        }

        return $this;
    }

    /**
     * Use the EventMethodology relation EventMethodology object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EventMethodologyQuery A secondary query class using the current class as primary query
     */
    public function useEventMethodologyQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEventMethodology($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EventMethodology', '\Model\EventMethodologyQuery');
    }

    /**
     * Use the EventMethodology relation EventMethodology object
     *
     * @param callable(\Model\EventMethodologyQuery):\Model\EventMethodologyQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventMethodologyQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEventMethodologyQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EventMethodology table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EventMethodologyQuery The inner query object of the EXISTS statement
     */
    public function useEventMethodologyExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EventMethodology', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EventMethodology table for a NOT EXISTS query.
     *
     * @see useEventMethodologyExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EventMethodologyQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventMethodologyNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EventMethodology', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Account object
     *
     * @param \Model\Account|ObjectCollection $account The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByAccount($account, $comparison = null)
    {
        if ($account instanceof \Model\Account) {
            return $this
                ->addUsingAlias(EventTableMap::COL_ACCOUNT_ID, $account->getId(), $comparison);
        } elseif ($account instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_ACCOUNT_ID, $account->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAccount() only accepts arguments of type \Model\Account or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Account relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinAccount($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Account');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Account');
        }

        return $this;
    }

    /**
     * Use the Account relation Account object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AccountQuery A secondary query class using the current class as primary query
     */
    public function useAccountQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAccount($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Account', '\Model\AccountQuery');
    }

    /**
     * Use the Account relation Account object
     *
     * @param callable(\Model\AccountQuery):\Model\AccountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAccountQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAccountQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Account table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AccountQuery The inner query object of the EXISTS statement
     */
    public function useAccountExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Account table for a NOT EXISTS query.
     *
     * @see useAccountExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AccountQuery The inner query object of the NOT EXISTS statement
     */
    public function useAccountNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByAssignedTo($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EventTableMap::COL_ASSIGNED_TO_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_ASSIGNED_TO_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAssignedTo() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AssignedTo relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinAssignedTo($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AssignedTo');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AssignedTo');
        }

        return $this;
    }

    /**
     * Use the AssignedTo relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useAssignedToQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAssignedTo($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AssignedTo', '\Model\UserQuery');
    }

    /**
     * Use the AssignedTo relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAssignedToQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAssignedToQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the AssignedTo relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useAssignedToExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('AssignedTo', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the AssignedTo relation to the User table for a NOT EXISTS query.
     *
     * @see useAssignedToExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useAssignedToNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('AssignedTo', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByRecordType($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EventTableMap::COL_RECORD_TYPE_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_RECORD_TYPE_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByRecordType() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RecordType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinRecordType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RecordType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RecordType');
        }

        return $this;
    }

    /**
     * Use the RecordType relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useRecordTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinRecordType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RecordType', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the RecordType relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withRecordTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useRecordTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the RecordType relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useRecordTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('RecordType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the RecordType relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useRecordTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useRecordTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('RecordType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventSubType($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_SUB_TYPE_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_EVENT_SUB_TYPE_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEventSubType() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EventSubType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinEventSubType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EventSubType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EventSubType');
        }

        return $this;
    }

    /**
     * Use the EventSubType relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useEventSubTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEventSubType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EventSubType', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the EventSubType relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventSubTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEventSubTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EventSubType relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useEventSubTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EventSubType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EventSubType relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useEventSubTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventSubTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EventSubType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Site object
     *
     * @param \Model\Site|ObjectCollection $site The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterBySite($site, $comparison = null)
    {
        if ($site instanceof \Model\Site) {
            return $this
                ->addUsingAlias(EventTableMap::COL_SITE_ID, $site->getId(), $comparison);
        } elseif ($site instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventTableMap::COL_SITE_ID, $site->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterBySite() only accepts arguments of type \Model\Site or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Site relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinSite($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Site');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Site');
        }

        return $this;
    }

    /**
     * Use the Site relation Site object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\SiteQuery A secondary query class using the current class as primary query
     */
    public function useSiteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinSite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Site', '\Model\SiteQuery');
    }

    /**
     * Use the Site relation Site object
     *
     * @param callable(\Model\SiteQuery):\Model\SiteQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withSiteQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useSiteQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Site table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\SiteQuery The inner query object of the EXISTS statement
     */
    public function useSiteExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Site', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Site table for a NOT EXISTS query.
     *
     * @see useSiteExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\SiteQuery The inner query object of the NOT EXISTS statement
     */
    public function useSiteNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Site', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Module object
     *
     * @param \Model\Module|ObjectCollection $module the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByModule($module, $comparison = null)
    {
        if ($module instanceof \Model\Module) {
            return $this
                ->addUsingAlias(EventTableMap::COL_ID, $module->getEventId(), $comparison);
        } elseif ($module instanceof ObjectCollection) {
            return $this
                ->useModuleQuery()
                ->filterByPrimaryKeys($module->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByModule() only accepts arguments of type \Model\Module or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Module relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinModule($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Module');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Module');
        }

        return $this;
    }

    /**
     * Use the Module relation Module object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ModuleQuery A secondary query class using the current class as primary query
     */
    public function useModuleQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinModule($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Module', '\Model\ModuleQuery');
    }

    /**
     * Use the Module relation Module object
     *
     * @param callable(\Model\ModuleQuery):\Model\ModuleQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withModuleQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useModuleQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Module table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ModuleQuery The inner query object of the EXISTS statement
     */
    public function useModuleExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Module', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Module table for a NOT EXISTS query.
     *
     * @see useModuleExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ModuleQuery The inner query object of the NOT EXISTS statement
     */
    public function useModuleNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Module', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\BidJobItem object
     *
     * @param \Model\BidJobItem|ObjectCollection $bidJobItem the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByEvent($bidJobItem, $comparison = null)
    {
        if ($bidJobItem instanceof \Model\BidJobItem) {
            return $this
                ->addUsingAlias(EventTableMap::COL_ID, $bidJobItem->getEventId(), $comparison);
        } elseif ($bidJobItem instanceof ObjectCollection) {
            return $this
                ->useEventQuery()
                ->filterByPrimaryKeys($bidJobItem->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEvent() only accepts arguments of type \Model\BidJobItem or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Event relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinEvent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Event');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Event');
        }

        return $this;
    }

    /**
     * Use the Event relation BidJobItem object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\BidJobItemQuery A secondary query class using the current class as primary query
     */
    public function useEventQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEvent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Event', '\Model\BidJobItemQuery');
    }

    /**
     * Use the Event relation BidJobItem object
     *
     * @param callable(\Model\BidJobItemQuery):\Model\BidJobItemQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEventQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the Event relation to the BidJobItem table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\BidJobItemQuery The inner query object of the EXISTS statement
     */
    public function useEventExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the Event relation to the BidJobItem table for a NOT EXISTS query.
     *
     * @see useEventExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\BidJobItemQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EventBidJobItem object
     *
     * @param \Model\EventBidJobItem|ObjectCollection $eventBidJobItem the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEventQuery The current query, for fluid interface
     */
    public function filterByEventBidJobItem($eventBidJobItem, $comparison = null)
    {
        if ($eventBidJobItem instanceof \Model\EventBidJobItem) {
            return $this
                ->addUsingAlias(EventTableMap::COL_ID, $eventBidJobItem->getEventId(), $comparison);
        } elseif ($eventBidJobItem instanceof ObjectCollection) {
            return $this
                ->useEventBidJobItemQuery()
                ->filterByPrimaryKeys($eventBidJobItem->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEventBidJobItem() only accepts arguments of type \Model\EventBidJobItem or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EventBidJobItem relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function joinEventBidJobItem($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EventBidJobItem');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EventBidJobItem');
        }

        return $this;
    }

    /**
     * Use the EventBidJobItem relation EventBidJobItem object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EventBidJobItemQuery A secondary query class using the current class as primary query
     */
    public function useEventBidJobItemQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEventBidJobItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EventBidJobItem', '\Model\EventBidJobItemQuery');
    }

    /**
     * Use the EventBidJobItem relation EventBidJobItem object
     *
     * @param callable(\Model\EventBidJobItemQuery):\Model\EventBidJobItemQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventBidJobItemQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEventBidJobItemQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EventBidJobItem table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EventBidJobItemQuery The inner query object of the EXISTS statement
     */
    public function useEventBidJobItemExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EventBidJobItem', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EventBidJobItem table for a NOT EXISTS query.
     *
     * @see useEventBidJobItemExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EventBidJobItemQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventBidJobItemNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EventBidJobItem', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEvent $event Object to remove from the list of results
     *
     * @return $this|ChildEventQuery The current query, for fluid interface
     */
    public function prune($event = null)
    {
        if ($event) {
            $this->addUsingAlias(EventTableMap::COL_ID, $event->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the event table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EventTableMap::clearInstancePool();
            EventTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EventTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EventTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EventTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(EventTableMap::COL_UPDATED_DATE, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(EventTableMap::COL_UPDATED_DATE);
    }

    /**
     * Order by update date asc
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(EventTableMap::COL_UPDATED_DATE);
    }

    /**
     * Order by create date desc
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(EventTableMap::COL_CREATED_DATE);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(EventTableMap::COL_CREATED_DATE, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date asc
     *
     * @return     $this|ChildEventQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(EventTableMap::COL_CREATED_DATE);
    }

} // EventQuery
