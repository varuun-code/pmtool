<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EventMethodology as ChildEventMethodology;
use Model\EventMethodologyQuery as ChildEventMethodologyQuery;
use Model\Map\EventMethodologyTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'ref_event_methodology' table.
 *
 *
 *
 * @method     ChildEventMethodologyQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEventMethodologyQuery orderByLabel($order = Criteria::ASC) Order by the label column
 * @method     ChildEventMethodologyQuery orderBySamsLabel($order = Criteria::ASC) Order by the sams_label column
 * @method     ChildEventMethodologyQuery orderByActive($order = Criteria::ASC) Order by the active column
 * @method     ChildEventMethodologyQuery orderByLocalisation($order = Criteria::ASC) Order by the localisation column
 * @method     ChildEventMethodologyQuery orderByLocalisation2($order = Criteria::ASC) Order by the localisation2 column
 * @method     ChildEventMethodologyQuery orderByText($order = Criteria::ASC) Order by the text column
 * @method     ChildEventMethodologyQuery orderByRank($order = Criteria::ASC) Order by the rank column
 *
 * @method     ChildEventMethodologyQuery groupById() Group by the id column
 * @method     ChildEventMethodologyQuery groupByLabel() Group by the label column
 * @method     ChildEventMethodologyQuery groupBySamsLabel() Group by the sams_label column
 * @method     ChildEventMethodologyQuery groupByActive() Group by the active column
 * @method     ChildEventMethodologyQuery groupByLocalisation() Group by the localisation column
 * @method     ChildEventMethodologyQuery groupByLocalisation2() Group by the localisation2 column
 * @method     ChildEventMethodologyQuery groupByText() Group by the text column
 * @method     ChildEventMethodologyQuery groupByRank() Group by the rank column
 *
 * @method     ChildEventMethodologyQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEventMethodologyQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEventMethodologyQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEventMethodologyQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEventMethodologyQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEventMethodologyQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEventMethodologyQuery leftJoinEvent($relationAlias = null) Adds a LEFT JOIN clause to the query using the Event relation
 * @method     ChildEventMethodologyQuery rightJoinEvent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Event relation
 * @method     ChildEventMethodologyQuery innerJoinEvent($relationAlias = null) Adds a INNER JOIN clause to the query using the Event relation
 *
 * @method     ChildEventMethodologyQuery joinWithEvent($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Event relation
 *
 * @method     ChildEventMethodologyQuery leftJoinWithEvent() Adds a LEFT JOIN clause and with to the query using the Event relation
 * @method     ChildEventMethodologyQuery rightJoinWithEvent() Adds a RIGHT JOIN clause and with to the query using the Event relation
 * @method     ChildEventMethodologyQuery innerJoinWithEvent() Adds a INNER JOIN clause and with to the query using the Event relation
 *
 * @method     \Model\EventQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEventMethodology|null findOne(ConnectionInterface $con = null) Return the first ChildEventMethodology matching the query
 * @method     ChildEventMethodology findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEventMethodology matching the query, or a new ChildEventMethodology object populated from the query conditions when no match is found
 *
 * @method     ChildEventMethodology|null findOneById(int $id) Return the first ChildEventMethodology filtered by the id column
 * @method     ChildEventMethodology|null findOneByLabel(string $label) Return the first ChildEventMethodology filtered by the label column
 * @method     ChildEventMethodology|null findOneBySamsLabel(string $sams_label) Return the first ChildEventMethodology filtered by the sams_label column
 * @method     ChildEventMethodology|null findOneByActive(boolean $active) Return the first ChildEventMethodology filtered by the active column
 * @method     ChildEventMethodology|null findOneByLocalisation(string $localisation) Return the first ChildEventMethodology filtered by the localisation column
 * @method     ChildEventMethodology|null findOneByLocalisation2(string $localisation2) Return the first ChildEventMethodology filtered by the localisation2 column
 * @method     ChildEventMethodology|null findOneByText(string $text) Return the first ChildEventMethodology filtered by the text column
 * @method     ChildEventMethodology|null findOneByRank(int $rank) Return the first ChildEventMethodology filtered by the rank column *

 * @method     ChildEventMethodology requirePk($key, ConnectionInterface $con = null) Return the ChildEventMethodology by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOne(ConnectionInterface $con = null) Return the first ChildEventMethodology matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEventMethodology requireOneById(int $id) Return the first ChildEventMethodology filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByLabel(string $label) Return the first ChildEventMethodology filtered by the label column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneBySamsLabel(string $sams_label) Return the first ChildEventMethodology filtered by the sams_label column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByActive(boolean $active) Return the first ChildEventMethodology filtered by the active column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByLocalisation(string $localisation) Return the first ChildEventMethodology filtered by the localisation column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByLocalisation2(string $localisation2) Return the first ChildEventMethodology filtered by the localisation2 column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByText(string $text) Return the first ChildEventMethodology filtered by the text column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventMethodology requireOneByRank(int $rank) Return the first ChildEventMethodology filtered by the rank column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEventMethodology[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEventMethodology objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> find(ConnectionInterface $con = null) Return ChildEventMethodology objects based on current ModelCriteria
 * @method     ChildEventMethodology[]|ObjectCollection findById(int $id) Return ChildEventMethodology objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findById(int $id) Return ChildEventMethodology objects filtered by the id column
 * @method     ChildEventMethodology[]|ObjectCollection findByLabel(string $label) Return ChildEventMethodology objects filtered by the label column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByLabel(string $label) Return ChildEventMethodology objects filtered by the label column
 * @method     ChildEventMethodology[]|ObjectCollection findBySamsLabel(string $sams_label) Return ChildEventMethodology objects filtered by the sams_label column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findBySamsLabel(string $sams_label) Return ChildEventMethodology objects filtered by the sams_label column
 * @method     ChildEventMethodology[]|ObjectCollection findByActive(boolean $active) Return ChildEventMethodology objects filtered by the active column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByActive(boolean $active) Return ChildEventMethodology objects filtered by the active column
 * @method     ChildEventMethodology[]|ObjectCollection findByLocalisation(string $localisation) Return ChildEventMethodology objects filtered by the localisation column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByLocalisation(string $localisation) Return ChildEventMethodology objects filtered by the localisation column
 * @method     ChildEventMethodology[]|ObjectCollection findByLocalisation2(string $localisation2) Return ChildEventMethodology objects filtered by the localisation2 column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByLocalisation2(string $localisation2) Return ChildEventMethodology objects filtered by the localisation2 column
 * @method     ChildEventMethodology[]|ObjectCollection findByText(string $text) Return ChildEventMethodology objects filtered by the text column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByText(string $text) Return ChildEventMethodology objects filtered by the text column
 * @method     ChildEventMethodology[]|ObjectCollection findByRank(int $rank) Return ChildEventMethodology objects filtered by the rank column
 * @psalm-method ObjectCollection&\Traversable<ChildEventMethodology> findByRank(int $rank) Return ChildEventMethodology objects filtered by the rank column
 * @method     ChildEventMethodology[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEventMethodology> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EventMethodologyQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EventMethodologyQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EventMethodology', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEventMethodologyQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEventMethodologyQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEventMethodologyQuery) {
            return $criteria;
        }
        $query = new ChildEventMethodologyQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEventMethodology|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EventMethodologyTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventMethodology A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `label`, `sams_label`, `active`, `localisation`, `localisation2`, `text`, `rank` FROM `ref_event_methodology` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEventMethodology $obj */
            $obj = new ChildEventMethodology();
            $obj->hydrate($row);
            EventMethodologyTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEventMethodology|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the label column
     *
     * Example usage:
     * <code>
     * $query->filterByLabel('fooValue');   // WHERE label = 'fooValue'
     * $query->filterByLabel('%fooValue%', Criteria::LIKE); // WHERE label LIKE '%fooValue%'
     * $query->filterByLabel(['foo', 'bar']); // WHERE label IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $label The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByLabel($label = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($label)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_LABEL, $label, $comparison);
    }

    /**
     * Filter the query on the sams_label column
     *
     * Example usage:
     * <code>
     * $query->filterBySamsLabel('fooValue');   // WHERE sams_label = 'fooValue'
     * $query->filterBySamsLabel('%fooValue%', Criteria::LIKE); // WHERE sams_label LIKE '%fooValue%'
     * $query->filterBySamsLabel(['foo', 'bar']); // WHERE sams_label IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $samsLabel The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterBySamsLabel($samsLabel = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($samsLabel)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_SAMS_LABEL, $samsLabel, $comparison);
    }

    /**
     * Filter the query on the active column
     *
     * Example usage:
     * <code>
     * $query->filterByActive(true); // WHERE active = true
     * $query->filterByActive('yes'); // WHERE active = true
     * </code>
     *
     * @param     boolean|string $active The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByActive($active = null, $comparison = null)
    {
        if (is_string($active)) {
            $active = in_array(strtolower($active), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_ACTIVE, $active, $comparison);
    }

    /**
     * Filter the query on the localisation column
     *
     * Example usage:
     * <code>
     * $query->filterByLocalisation('fooValue');   // WHERE localisation = 'fooValue'
     * $query->filterByLocalisation('%fooValue%', Criteria::LIKE); // WHERE localisation LIKE '%fooValue%'
     * $query->filterByLocalisation(['foo', 'bar']); // WHERE localisation IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $localisation The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByLocalisation($localisation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($localisation)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_LOCALISATION, $localisation, $comparison);
    }

    /**
     * Filter the query on the localisation2 column
     *
     * Example usage:
     * <code>
     * $query->filterByLocalisation2('fooValue');   // WHERE localisation2 = 'fooValue'
     * $query->filterByLocalisation2('%fooValue%', Criteria::LIKE); // WHERE localisation2 LIKE '%fooValue%'
     * $query->filterByLocalisation2(['foo', 'bar']); // WHERE localisation2 IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $localisation2 The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByLocalisation2($localisation2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($localisation2)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_LOCALISATION2, $localisation2, $comparison);
    }

    /**
     * Filter the query on the text column
     *
     * Example usage:
     * <code>
     * $query->filterByText('fooValue');   // WHERE text = 'fooValue'
     * $query->filterByText('%fooValue%', Criteria::LIKE); // WHERE text LIKE '%fooValue%'
     * $query->filterByText(['foo', 'bar']); // WHERE text IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $text The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByText($text = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_TEXT, $text, $comparison);
    }

    /**
     * Filter the query on the rank column
     *
     * Example usage:
     * <code>
     * $query->filterByRank(1234); // WHERE rank = 1234
     * $query->filterByRank(array(12, 34)); // WHERE rank IN (12, 34)
     * $query->filterByRank(array('min' => 12)); // WHERE rank > 12
     * </code>
     *
     * @param     mixed $rank The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByRank($rank = null, $comparison = null)
    {
        if (is_array($rank)) {
            $useMinMax = false;
            if (isset($rank['min'])) {
                $this->addUsingAlias(EventMethodologyTableMap::COL_RANK, $rank['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($rank['max'])) {
                $this->addUsingAlias(EventMethodologyTableMap::COL_RANK, $rank['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventMethodologyTableMap::COL_RANK, $rank, $comparison);
    }

    /**
     * Filter the query by a related \Model\Event object
     *
     * @param \Model\Event|ObjectCollection $event the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function filterByEvent($event, $comparison = null)
    {
        if ($event instanceof \Model\Event) {
            return $this
                ->addUsingAlias(EventMethodologyTableMap::COL_ID, $event->getEventMethodologyId(), $comparison);
        } elseif ($event instanceof ObjectCollection) {
            return $this
                ->useEventQuery()
                ->filterByPrimaryKeys($event->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEvent() only accepts arguments of type \Model\Event or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Event relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function joinEvent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Event');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Event');
        }

        return $this;
    }

    /**
     * Use the Event relation Event object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EventQuery A secondary query class using the current class as primary query
     */
    public function useEventQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEvent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Event', '\Model\EventQuery');
    }

    /**
     * Use the Event relation Event object
     *
     * @param callable(\Model\EventQuery):\Model\EventQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEventQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Event table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EventQuery The inner query object of the EXISTS statement
     */
    public function useEventExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Event table for a NOT EXISTS query.
     *
     * @see useEventExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EventQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEventMethodology $eventMethodology Object to remove from the list of results
     *
     * @return $this|ChildEventMethodologyQuery The current query, for fluid interface
     */
    public function prune($eventMethodology = null)
    {
        if ($eventMethodology) {
            $this->addUsingAlias(EventMethodologyTableMap::COL_ID, $eventMethodology->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the ref_event_methodology table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EventMethodologyTableMap::clearInstancePool();
            EventMethodologyTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EventMethodologyTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EventMethodologyTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EventMethodologyTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // sortable behavior

    /**
     * Returns the list of objects
     *
     * @param      ConnectionInterface $con    Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($con = null)
    {

        return $this
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EventMethodologyTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EventMethodologyTableMap::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray(ConnectionInterface $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(EventMethodologyTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EventMethodologyTableMap::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param     ConnectionInterface $con optional connection
     *
     * @return ChildEventMethodology
     */
    static public function retrieveByRank($rank, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        $c = new Criteria;
        $c->add(EventMethodologyTableMap::RANK_COL, $rank);

        return static::create(null, $c)->findOne($con);
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     mixed               $order id => rank pairs
     * @param     ConnectionInterface $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder($order, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con, $order) {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getRank() != $order[$pk]) {
                    $object->setRank($order[$pk]);
                    $object->save($con);
                }
            }
        });

        return true;
    }

    /**
     * Return an array of sortable objects ordered by position
     *
     * @param     Criteria  $criteria  optional criteria object
     * @param     string    $order     sorting order, to be chosen between Criteria::ASC (default) and Criteria::DESC
     * @param     ConnectionInterface $con       optional connection
     *
     * @return    array list of sortable objects
     */
    static public function doSelectOrderByRank(Criteria $criteria = null, $order = Criteria::ASC, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        if (null === $criteria) {
            $criteria = new Criteria();
        } elseif ($criteria instanceof Criteria) {
            $criteria = clone $criteria;
        }

        $criteria->clearOrderByColumns();

        if (Criteria::ASC == $order) {
            $criteria->addAscendingOrderByColumn(EventMethodologyTableMap::RANK_COL);
        } else {
            $criteria->addDescendingOrderByColumn(EventMethodologyTableMap::RANK_COL);
        }

        return ChildEventMethodologyQuery::create(null, $criteria)->find($con);
    }

    /**
     * Adds $delta to all Rank values that are >= $first and <= $last.
     * '$delta' can also be negative.
     *
     * @param      int $delta Value to be shifted by, can be negative
     * @param      int $first First node to be shifted
     * @param      int $last  Last node to be shifted
     * @param      ConnectionInterface $con Connection to use.
     */
    static public function sortableShiftRank($delta, $first, $last = null, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventMethodologyTableMap::DATABASE_NAME);
        }

        $whereCriteria = new Criteria(EventMethodologyTableMap::DATABASE_NAME);
        $criterion = $whereCriteria->getNewCriterion(EventMethodologyTableMap::RANK_COL, $first, Criteria::GREATER_EQUAL);
        if (null !== $last) {
            $criterion->addAnd($whereCriteria->getNewCriterion(EventMethodologyTableMap::RANK_COL, $last, Criteria::LESS_EQUAL));
        }
        $whereCriteria->add($criterion);

        $valuesCriteria = new Criteria(EventMethodologyTableMap::DATABASE_NAME);
        $valuesCriteria->add(EventMethodologyTableMap::RANK_COL, array('raw' => EventMethodologyTableMap::RANK_COL . ' + ?', 'value' => $delta), Criteria::CUSTOM_EQUAL);

        $whereCriteria->doUpdate($valuesCriteria, $con);
        EventMethodologyTableMap::clearInstancePool();
    }

} // EventMethodologyQuery
