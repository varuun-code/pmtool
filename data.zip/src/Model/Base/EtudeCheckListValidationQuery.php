<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EtudeCheckListValidation as ChildEtudeCheckListValidation;
use Model\EtudeCheckListValidationQuery as ChildEtudeCheckListValidationQuery;
use Model\Map\EtudeCheckListValidationTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'etude_checklist_validation' table.
 *
 *
 *
 * @method     ChildEtudeCheckListValidationQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEtudeCheckListValidationQuery orderByEtudeChecklistId($order = Criteria::ASC) Order by the etude_checklist_id column
 * @method     ChildEtudeCheckListValidationQuery orderByEtudeId($order = Criteria::ASC) Order by the etude_id column
 * @method     ChildEtudeCheckListValidationQuery orderByIsCheck($order = Criteria::ASC) Order by the is_check column
 *
 * @method     ChildEtudeCheckListValidationQuery groupById() Group by the id column
 * @method     ChildEtudeCheckListValidationQuery groupByEtudeChecklistId() Group by the etude_checklist_id column
 * @method     ChildEtudeCheckListValidationQuery groupByEtudeId() Group by the etude_id column
 * @method     ChildEtudeCheckListValidationQuery groupByIsCheck() Group by the is_check column
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtudeCheckListValidationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtudeCheckListValidationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtudeCheckListValidationQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtudeCheckListValidationQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoinEtudeCheckList($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeCheckList relation
 * @method     ChildEtudeCheckListValidationQuery rightJoinEtudeCheckList($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeCheckList relation
 * @method     ChildEtudeCheckListValidationQuery innerJoinEtudeCheckList($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeCheckList relation
 *
 * @method     ChildEtudeCheckListValidationQuery joinWithEtudeCheckList($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeCheckList relation
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoinWithEtudeCheckList() Adds a LEFT JOIN clause and with to the query using the EtudeCheckList relation
 * @method     ChildEtudeCheckListValidationQuery rightJoinWithEtudeCheckList() Adds a RIGHT JOIN clause and with to the query using the EtudeCheckList relation
 * @method     ChildEtudeCheckListValidationQuery innerJoinWithEtudeCheckList() Adds a INNER JOIN clause and with to the query using the EtudeCheckList relation
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoinEtude($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etude relation
 * @method     ChildEtudeCheckListValidationQuery rightJoinEtude($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etude relation
 * @method     ChildEtudeCheckListValidationQuery innerJoinEtude($relationAlias = null) Adds a INNER JOIN clause to the query using the Etude relation
 *
 * @method     ChildEtudeCheckListValidationQuery joinWithEtude($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etude relation
 *
 * @method     ChildEtudeCheckListValidationQuery leftJoinWithEtude() Adds a LEFT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtudeCheckListValidationQuery rightJoinWithEtude() Adds a RIGHT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtudeCheckListValidationQuery innerJoinWithEtude() Adds a INNER JOIN clause and with to the query using the Etude relation
 *
 * @method     \Model\EtudeChecklistQuery|\Model\EtudeQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtudeCheckListValidation|null findOne(ConnectionInterface $con = null) Return the first ChildEtudeCheckListValidation matching the query
 * @method     ChildEtudeCheckListValidation findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtudeCheckListValidation matching the query, or a new ChildEtudeCheckListValidation object populated from the query conditions when no match is found
 *
 * @method     ChildEtudeCheckListValidation|null findOneById(int $id) Return the first ChildEtudeCheckListValidation filtered by the id column
 * @method     ChildEtudeCheckListValidation|null findOneByEtudeChecklistId(int $etude_checklist_id) Return the first ChildEtudeCheckListValidation filtered by the etude_checklist_id column
 * @method     ChildEtudeCheckListValidation|null findOneByEtudeId(int $etude_id) Return the first ChildEtudeCheckListValidation filtered by the etude_id column
 * @method     ChildEtudeCheckListValidation|null findOneByIsCheck(boolean $is_check) Return the first ChildEtudeCheckListValidation filtered by the is_check column *

 * @method     ChildEtudeCheckListValidation requirePk($key, ConnectionInterface $con = null) Return the ChildEtudeCheckListValidation by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeCheckListValidation requireOne(ConnectionInterface $con = null) Return the first ChildEtudeCheckListValidation matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeCheckListValidation requireOneById(int $id) Return the first ChildEtudeCheckListValidation filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeCheckListValidation requireOneByEtudeChecklistId(int $etude_checklist_id) Return the first ChildEtudeCheckListValidation filtered by the etude_checklist_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeCheckListValidation requireOneByEtudeId(int $etude_id) Return the first ChildEtudeCheckListValidation filtered by the etude_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeCheckListValidation requireOneByIsCheck(boolean $is_check) Return the first ChildEtudeCheckListValidation filtered by the is_check column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeCheckListValidation[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtudeCheckListValidation objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeCheckListValidation> find(ConnectionInterface $con = null) Return ChildEtudeCheckListValidation objects based on current ModelCriteria
 * @method     ChildEtudeCheckListValidation[]|ObjectCollection findById(int $id) Return ChildEtudeCheckListValidation objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeCheckListValidation> findById(int $id) Return ChildEtudeCheckListValidation objects filtered by the id column
 * @method     ChildEtudeCheckListValidation[]|ObjectCollection findByEtudeChecklistId(int $etude_checklist_id) Return ChildEtudeCheckListValidation objects filtered by the etude_checklist_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeCheckListValidation> findByEtudeChecklistId(int $etude_checklist_id) Return ChildEtudeCheckListValidation objects filtered by the etude_checklist_id column
 * @method     ChildEtudeCheckListValidation[]|ObjectCollection findByEtudeId(int $etude_id) Return ChildEtudeCheckListValidation objects filtered by the etude_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeCheckListValidation> findByEtudeId(int $etude_id) Return ChildEtudeCheckListValidation objects filtered by the etude_id column
 * @method     ChildEtudeCheckListValidation[]|ObjectCollection findByIsCheck(boolean $is_check) Return ChildEtudeCheckListValidation objects filtered by the is_check column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeCheckListValidation> findByIsCheck(boolean $is_check) Return ChildEtudeCheckListValidation objects filtered by the is_check column
 * @method     ChildEtudeCheckListValidation[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtudeCheckListValidation> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtudeCheckListValidationQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtudeCheckListValidationQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EtudeCheckListValidation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtudeCheckListValidationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtudeCheckListValidationQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtudeCheckListValidationQuery) {
            return $criteria;
        }
        $query = new ChildEtudeCheckListValidationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtudeCheckListValidation|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeCheckListValidationTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtudeCheckListValidationTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeCheckListValidation A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `etude_checklist_id`, `etude_id`, `is_check` FROM `etude_checklist_validation` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtudeCheckListValidation $obj */
            $obj = new ChildEtudeCheckListValidation();
            $obj->hydrate($row);
            EtudeCheckListValidationTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtudeCheckListValidation|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the etude_checklist_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEtudeChecklistId(1234); // WHERE etude_checklist_id = 1234
     * $query->filterByEtudeChecklistId(array(12, 34)); // WHERE etude_checklist_id IN (12, 34)
     * $query->filterByEtudeChecklistId(array('min' => 12)); // WHERE etude_checklist_id > 12
     * </code>
     *
     * @see       filterByEtudeCheckList()
     *
     * @param     mixed $etudeChecklistId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByEtudeChecklistId($etudeChecklistId = null, $comparison = null)
    {
        if (is_array($etudeChecklistId)) {
            $useMinMax = false;
            if (isset($etudeChecklistId['min'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_CHECKLIST_ID, $etudeChecklistId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etudeChecklistId['max'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_CHECKLIST_ID, $etudeChecklistId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_CHECKLIST_ID, $etudeChecklistId, $comparison);
    }

    /**
     * Filter the query on the etude_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEtudeId(1234); // WHERE etude_id = 1234
     * $query->filterByEtudeId(array(12, 34)); // WHERE etude_id IN (12, 34)
     * $query->filterByEtudeId(array('min' => 12)); // WHERE etude_id > 12
     * </code>
     *
     * @see       filterByEtude()
     *
     * @param     mixed $etudeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByEtudeId($etudeId = null, $comparison = null)
    {
        if (is_array($etudeId)) {
            $useMinMax = false;
            if (isset($etudeId['min'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_ID, $etudeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etudeId['max'])) {
                $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_ID, $etudeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_ID, $etudeId, $comparison);
    }

    /**
     * Filter the query on the is_check column
     *
     * Example usage:
     * <code>
     * $query->filterByIsCheck(true); // WHERE is_check = true
     * $query->filterByIsCheck('yes'); // WHERE is_check = true
     * </code>
     *
     * @param     boolean|string $isCheck The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByIsCheck($isCheck = null, $comparison = null)
    {
        if (is_string($isCheck)) {
            $isCheck = in_array(strtolower($isCheck), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_IS_CHECK, $isCheck, $comparison);
    }

    /**
     * Filter the query by a related \Model\EtudeChecklist object
     *
     * @param \Model\EtudeChecklist|ObjectCollection $etudeChecklist The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByEtudeCheckList($etudeChecklist, $comparison = null)
    {
        if ($etudeChecklist instanceof \Model\EtudeChecklist) {
            return $this
                ->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_CHECKLIST_ID, $etudeChecklist->getId(), $comparison);
        } elseif ($etudeChecklist instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_CHECKLIST_ID, $etudeChecklist->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeCheckList() only accepts arguments of type \Model\EtudeChecklist or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeCheckList relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function joinEtudeCheckList($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeCheckList');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeCheckList');
        }

        return $this;
    }

    /**
     * Use the EtudeCheckList relation EtudeChecklist object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeChecklistQuery A secondary query class using the current class as primary query
     */
    public function useEtudeCheckListQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeCheckList($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeCheckList', '\Model\EtudeChecklistQuery');
    }

    /**
     * Use the EtudeCheckList relation EtudeChecklist object
     *
     * @param callable(\Model\EtudeChecklistQuery):\Model\EtudeChecklistQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeCheckListQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeCheckListQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EtudeCheckList relation to the EtudeChecklist table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeChecklistQuery The inner query object of the EXISTS statement
     */
    public function useEtudeCheckListExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeCheckList', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EtudeCheckList relation to the EtudeChecklist table for a NOT EXISTS query.
     *
     * @see useEtudeCheckListExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeChecklistQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeCheckListNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeCheckList', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Etude object
     *
     * @param \Model\Etude|ObjectCollection $etude The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function filterByEtude($etude, $comparison = null)
    {
        if ($etude instanceof \Model\Etude) {
            return $this
                ->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_ID, $etude->getId(), $comparison);
        } elseif ($etude instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeCheckListValidationTableMap::COL_ETUDE_ID, $etude->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtude() only accepts arguments of type \Model\Etude or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etude relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function joinEtude($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etude');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etude');
        }

        return $this;
    }

    /**
     * Use the Etude relation Etude object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeQuery A secondary query class using the current class as primary query
     */
    public function useEtudeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtude($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etude', '\Model\EtudeQuery');
    }

    /**
     * Use the Etude relation Etude object
     *
     * @param callable(\Model\EtudeQuery):\Model\EtudeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etude table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeQuery The inner query object of the EXISTS statement
     */
    public function useEtudeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etude table for a NOT EXISTS query.
     *
     * @see useEtudeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEtudeCheckListValidation $etudeCheckListValidation Object to remove from the list of results
     *
     * @return $this|ChildEtudeCheckListValidationQuery The current query, for fluid interface
     */
    public function prune($etudeCheckListValidation = null)
    {
        if ($etudeCheckListValidation) {
            $this->addUsingAlias(EtudeCheckListValidationTableMap::COL_ID, $etudeCheckListValidation->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the etude_checklist_validation table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeCheckListValidationTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtudeCheckListValidationTableMap::clearInstancePool();
            EtudeCheckListValidationTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeCheckListValidationTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtudeCheckListValidationTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtudeCheckListValidationTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtudeCheckListValidationTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // EtudeCheckListValidationQuery
