<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\Etude as ChildEtude;
use Model\EtudeQuery as ChildEtudeQuery;
use Model\Map\EtudeTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'etude' table.
 *
 *
 *
 * @method     ChildEtudeQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEtudeQuery orderByNumeroEtude($order = Criteria::ASC) Order by the numero_etude column
 * @method     ChildEtudeQuery orderByReferenceClient($order = Criteria::ASC) Order by the reference_client column
 * @method     ChildEtudeQuery orderByMasterProjectSfId($order = Criteria::ASC) Order by the master_project_sf_id column
 * @method     ChildEtudeQuery orderByTheme($order = Criteria::ASC) Order by the theme column
 * @method     ChildEtudeQuery orderByDateDebut($order = Criteria::ASC) Order by the date_debut column
 * @method     ChildEtudeQuery orderByDateFin($order = Criteria::ASC) Order by the date_fin column
 * @method     ChildEtudeQuery orderByAnnee($order = Criteria::ASC) Order by the annee column
 * @method     ChildEtudeQuery orderByRst($order = Criteria::ASC) Order by the rst column
 * @method     ChildEtudeQuery orderByCli($order = Criteria::ASC) Order by the cli column
 * @method     ChildEtudeQuery orderByGqs($order = Criteria::ASC) Order by the gqs column
 * @method     ChildEtudeQuery orderByIns($order = Criteria::ASC) Order by the ins column
 * @method     ChildEtudeQuery orderByHut($order = Criteria::ASC) Order by the hut column
 * @method     ChildEtudeQuery orderByDisplayTotalOnly($order = Criteria::ASC) Order by the display_total_only column
 * @method     ChildEtudeQuery orderByIdPm($order = Criteria::ASC) Order by the id_pm column
 * @method     ChildEtudeQuery orderByIdEtape($order = Criteria::ASC) Order by the id_etape column
 * @method     ChildEtudeQuery orderByPrixRevientInitial($order = Criteria::ASC) Order by the prix_revient_initial column
 * @method     ChildEtudeQuery orderByPrixRevientActualise($order = Criteria::ASC) Order by the prix_revient_actualise column
 * @method     ChildEtudeQuery orderByPrixVenteInitial($order = Criteria::ASC) Order by the prix_vente_initial column
 * @method     ChildEtudeQuery orderByPrixVenteActualise($order = Criteria::ASC) Order by the prix_vente_actualise column
 * @method     ChildEtudeQuery orderByConsolidatedInvoice($order = Criteria::ASC) Order by the consolidated_invoice column
 * @method     ChildEtudeQuery orderBySendCsatQuest($order = Criteria::ASC) Order by the send_csat_quest column
 * @method     ChildEtudeQuery orderByIsSendCsatQuestMail($order = Criteria::ASC) Order by the is_send_csat_quest_mail column
 * @method     ChildEtudeQuery orderByNumeroFacture($order = Criteria::ASC) Order by the numero_facture column
 * @method     ChildEtudeQuery orderByDontSetAmAuto($order = Criteria::ASC) Order by the dont_set_am_auto column
 * @method     ChildEtudeQuery orderBySetAmReason($order = Criteria::ASC) Order by the set_am_reason column
 * @method     ChildEtudeQuery orderByAmReasonTypeId($order = Criteria::ASC) Order by the am_reason_type_id column
 * @method     ChildEtudeQuery orderByDateEnvoiFacture($order = Criteria::ASC) Order by the date_envoi_facture column
 * @method     ChildEtudeQuery orderByDateReglement($order = Criteria::ASC) Order by the date_reglement column
 * @method     ChildEtudeQuery orderByCommentaire($order = Criteria::ASC) Order by the commentaire column
 * @method     ChildEtudeQuery orderByIndustryId($order = Criteria::ASC) Order by the industry_id column
 * @method     ChildEtudeQuery orderByPeriodeCutoff($order = Criteria::ASC) Order by the periode_cutoff column
 * @method     ChildEtudeQuery orderByThemeBr($order = Criteria::ASC) Order by the theme_br column
 * @method     ChildEtudeQuery orderByAreaId($order = Criteria::ASC) Order by the area_id column
 * @method     ChildEtudeQuery orderByIdSamsStudy($order = Criteria::ASC) Order by the id_sams_study column
 * @method     ChildEtudeQuery orderByRecrutementObjectif($order = Criteria::ASC) Order by the recrutement_objectif column
 * @method     ChildEtudeQuery orderByIdLocationPnl($order = Criteria::ASC) Order by the id_location_pnl column
 * @method     ChildEtudeQuery orderByIdMasterProjectLocationPnl($order = Criteria::ASC) Order by the id_master_project_location_pnl column
 * @method     ChildEtudeQuery orderByRecrutementObjectifPr($order = Criteria::ASC) Order by the recrutement_objectif_pr column
 * @method     ChildEtudeQuery orderByIdBm($order = Criteria::ASC) Order by the id_bm column
 * @method     ChildEtudeQuery orderByExtraInfo($order = Criteria::ASC) Order by the extra_info column
 * @method     ChildEtudeQuery orderByAccountId($order = Criteria::ASC) Order by the account_id column
 * @method     ChildEtudeQuery orderByAccountManagerId($order = Criteria::ASC) Order by the account_manager_id column
 * @method     ChildEtudeQuery orderByProjectSpecialtySponsorId($order = Criteria::ASC) Order by the project_specialty_sponsor_id column
 * @method     ChildEtudeQuery orderByLanguage($order = Criteria::ASC) Order by the language column
 * @method     ChildEtudeQuery orderByRemiseTaux($order = Criteria::ASC) Order by the remise_taux column
 * @method     ChildEtudeQuery orderByClientDiscountPercentage($order = Criteria::ASC) Order by the client_discount_percentage column
 * @method     ChildEtudeQuery orderByEndClientDiscountPercentage($order = Criteria::ASC) Order by the end_client_discount_percentage column
 * @method     ChildEtudeQuery orderByClientQuantDiscountPercentage($order = Criteria::ASC) Order by the client_quant_discount_percentage column
 * @method     ChildEtudeQuery orderByEndClientQuantDiscountPercentage($order = Criteria::ASC) Order by the end_client_quant_discount_percentage column
 * @method     ChildEtudeQuery orderBySamplePlan($order = Criteria::ASC) Order by the sample_plan column
 * @method     ChildEtudeQuery orderByIsToInvoice($order = Criteria::ASC) Order by the isToInvoice column
 * @method     ChildEtudeQuery orderByFilePath($order = Criteria::ASC) Order by the file_path column
 * @method     ChildEtudeQuery orderByAccountLeaderId($order = Criteria::ASC) Order by the account_leader_id column
 * @method     ChildEtudeQuery orderByAccountPMId($order = Criteria::ASC) Order by the account_pm_id column
 * @method     ChildEtudeQuery orderByAmEmail($order = Criteria::ASC) Order by the am_email column
 * @method     ChildEtudeQuery orderByClientPortalReady($order = Criteria::ASC) Order by the client_portal_ready column
 * @method     ChildEtudeQuery orderByLengthOfInterview($order = Criteria::ASC) Order by the length_of_interview column
 * @method     ChildEtudeQuery orderBysunshineAct($order = Criteria::ASC) Order by the sunshine_act column
 * @method     ChildEtudeQuery orderByIsConsolidated($order = Criteria::ASC) Order by the is_consolidated column
 * @method     ChildEtudeQuery orderBySharepointFolder($order = Criteria::ASC) Order by the sharepoint_folder column
 * @method     ChildEtudeQuery orderByMultiPhase($order = Criteria::ASC) Order by the multi_phase column
 * @method     ChildEtudeQuery orderByPoNumber($order = Criteria::ASC) Order by the po_number column
 * @method     ChildEtudeQuery orderByCurrencies($order = Criteria::ASC) Order by the currencies column
 * @method     ChildEtudeQuery orderBySmsRelance($order = Criteria::ASC) Order by the sms_relance column
 * @method     ChildEtudeQuery orderByIdEtudeGroup($order = Criteria::ASC) Order by the id_etude_group column
 * @method     ChildEtudeQuery orderByGms($order = Criteria::ASC) Order by the gms column
 * @method     ChildEtudeQuery orderByKol($order = Criteria::ASC) Order by the kol column
 * @method     ChildEtudeQuery orderByRoomRental($order = Criteria::ASC) Order by the room_rental column
 * @method     ChildEtudeQuery orderByRecruitsOffsite($order = Criteria::ASC) Order by the recruits_offsite column
 * @method     ChildEtudeQuery orderByStudySpecification($order = Criteria::ASC) Order by the study_specification column
 * @method     ChildEtudeQuery orderByisStudySpecification($order = Criteria::ASC) Order by the is_study_specification column
 * @method     ChildEtudeQuery orderByAdditionalNotes($order = Criteria::ASC) Order by the additional_notes column
 * @method     ChildEtudeQuery orderByProjectComment($order = Criteria::ASC) Order by the project_comment column
 * @method     ChildEtudeQuery orderByEndClientId($order = Criteria::ASC) Order by the end_client_id column
 * @method     ChildEtudeQuery orderByEndClientContactId($order = Criteria::ASC) Order by the end_client_contact_id column
 * @method     ChildEtudeQuery orderByContactId($order = Criteria::ASC) Order by the contact_id column
 * @method     ChildEtudeQuery orderByContactClientPmId($order = Criteria::ASC) Order by the contact_client_pm_id column
 * @method     ChildEtudeQuery orderByMasterProjectNumber($order = Criteria::ASC) Order by the master_project_number column
 * @method     ChildEtudeQuery orderByProposedLoi($order = Criteria::ASC) Order by the proposed_loi column
 * @method     ChildEtudeQuery orderByOpportunityId($order = Criteria::ASC) Order by the opportunity_id column
 * @method     ChildEtudeQuery orderBySiJobTypeId($order = Criteria::ASC) Order by the si_job_type_id column
 * @method     ChildEtudeQuery orderByBestEffort($order = Criteria::ASC) Order by the best_effort column
 * @method     ChildEtudeQuery orderByJobStatusSfId($order = Criteria::ASC) Order by the job_status_sf_id column
 * @method     ChildEtudeQuery orderByBookedBySfId($order = Criteria::ASC) Order by the booked_by_sf_id column
 * @method     ChildEtudeQuery orderByCreatedBySfId($order = Criteria::ASC) Order by the created_by_sf_id column
 * @method     ChildEtudeQuery orderByAccountManagerSfId($order = Criteria::ASC) Order by the account_manager_sf_id column
 * @method     ChildEtudeQuery orderByCreatedDate($order = Criteria::ASC) Order by the created_date column
 * @method     ChildEtudeQuery orderByJobQualificationId($order = Criteria::ASC) Order by the job_qualification_id column
 * @method     ChildEtudeQuery orderByProposedN($order = Criteria::ASC) Order by the proposed_n column
 * @method     ChildEtudeQuery orderByGermanJobTypeId($order = Criteria::ASC) Order by the german_job_type_id column
 * @method     ChildEtudeQuery orderByCreatedByComment($order = Criteria::ASC) Order by the created_by_comment column
 * @method     ChildEtudeQuery orderByFocusVision($order = Criteria::ASC) Order by the focus_vision column
 * @method     ChildEtudeQuery orderBySiEuJobType($order = Criteria::ASC) Order by the si_eu_job_type column
 * @method     ChildEtudeQuery orderByIntermediateClientId($order = Criteria::ASC) Order by the intermediate_client_id column
 * @method     ChildEtudeQuery orderByIntermediateClientContactId($order = Criteria::ASC) Order by the intermediate_client_contact_id column
 * @method     ChildEtudeQuery orderByUsGlobalQualGmsId($order = Criteria::ASC) Order by the us_global_qual_gms_id column
 * @method     ChildEtudeQuery orderByFaciltyNote($order = Criteria::ASC) Order by the facilty_note column
 * @method     ChildEtudeQuery orderByCurrencyIsoCodeId($order = Criteria::ASC) Order by the currency_iso_code_id column
 * @method     ChildEtudeQuery orderByClientListDeletionId($order = Criteria::ASC) Order by the client_list_deletion_id column
 * @method     ChildEtudeQuery orderByCreatedById($order = Criteria::ASC) Order by the created_by_id column
 * @method     ChildEtudeQuery orderByUpdatedById($order = Criteria::ASC) Order by the updated_by_id column
 * @method     ChildEtudeQuery orderByCreatedAt($order = Criteria::ASC) Order by the created_at column
 * @method     ChildEtudeQuery orderByUpdatedAt($order = Criteria::ASC) Order by the updated_at column
 *
 * @method     ChildEtudeQuery groupById() Group by the id column
 * @method     ChildEtudeQuery groupByNumeroEtude() Group by the numero_etude column
 * @method     ChildEtudeQuery groupByReferenceClient() Group by the reference_client column
 * @method     ChildEtudeQuery groupByMasterProjectSfId() Group by the master_project_sf_id column
 * @method     ChildEtudeQuery groupByTheme() Group by the theme column
 * @method     ChildEtudeQuery groupByDateDebut() Group by the date_debut column
 * @method     ChildEtudeQuery groupByDateFin() Group by the date_fin column
 * @method     ChildEtudeQuery groupByAnnee() Group by the annee column
 * @method     ChildEtudeQuery groupByRst() Group by the rst column
 * @method     ChildEtudeQuery groupByCli() Group by the cli column
 * @method     ChildEtudeQuery groupByGqs() Group by the gqs column
 * @method     ChildEtudeQuery groupByIns() Group by the ins column
 * @method     ChildEtudeQuery groupByHut() Group by the hut column
 * @method     ChildEtudeQuery groupByDisplayTotalOnly() Group by the display_total_only column
 * @method     ChildEtudeQuery groupByIdPm() Group by the id_pm column
 * @method     ChildEtudeQuery groupByIdEtape() Group by the id_etape column
 * @method     ChildEtudeQuery groupByPrixRevientInitial() Group by the prix_revient_initial column
 * @method     ChildEtudeQuery groupByPrixRevientActualise() Group by the prix_revient_actualise column
 * @method     ChildEtudeQuery groupByPrixVenteInitial() Group by the prix_vente_initial column
 * @method     ChildEtudeQuery groupByPrixVenteActualise() Group by the prix_vente_actualise column
 * @method     ChildEtudeQuery groupByConsolidatedInvoice() Group by the consolidated_invoice column
 * @method     ChildEtudeQuery groupBySendCsatQuest() Group by the send_csat_quest column
 * @method     ChildEtudeQuery groupByIsSendCsatQuestMail() Group by the is_send_csat_quest_mail column
 * @method     ChildEtudeQuery groupByNumeroFacture() Group by the numero_facture column
 * @method     ChildEtudeQuery groupByDontSetAmAuto() Group by the dont_set_am_auto column
 * @method     ChildEtudeQuery groupBySetAmReason() Group by the set_am_reason column
 * @method     ChildEtudeQuery groupByAmReasonTypeId() Group by the am_reason_type_id column
 * @method     ChildEtudeQuery groupByDateEnvoiFacture() Group by the date_envoi_facture column
 * @method     ChildEtudeQuery groupByDateReglement() Group by the date_reglement column
 * @method     ChildEtudeQuery groupByCommentaire() Group by the commentaire column
 * @method     ChildEtudeQuery groupByIndustryId() Group by the industry_id column
 * @method     ChildEtudeQuery groupByPeriodeCutoff() Group by the periode_cutoff column
 * @method     ChildEtudeQuery groupByThemeBr() Group by the theme_br column
 * @method     ChildEtudeQuery groupByAreaId() Group by the area_id column
 * @method     ChildEtudeQuery groupByIdSamsStudy() Group by the id_sams_study column
 * @method     ChildEtudeQuery groupByRecrutementObjectif() Group by the recrutement_objectif column
 * @method     ChildEtudeQuery groupByIdLocationPnl() Group by the id_location_pnl column
 * @method     ChildEtudeQuery groupByIdMasterProjectLocationPnl() Group by the id_master_project_location_pnl column
 * @method     ChildEtudeQuery groupByRecrutementObjectifPr() Group by the recrutement_objectif_pr column
 * @method     ChildEtudeQuery groupByIdBm() Group by the id_bm column
 * @method     ChildEtudeQuery groupByExtraInfo() Group by the extra_info column
 * @method     ChildEtudeQuery groupByAccountId() Group by the account_id column
 * @method     ChildEtudeQuery groupByAccountManagerId() Group by the account_manager_id column
 * @method     ChildEtudeQuery groupByProjectSpecialtySponsorId() Group by the project_specialty_sponsor_id column
 * @method     ChildEtudeQuery groupByLanguage() Group by the language column
 * @method     ChildEtudeQuery groupByRemiseTaux() Group by the remise_taux column
 * @method     ChildEtudeQuery groupByClientDiscountPercentage() Group by the client_discount_percentage column
 * @method     ChildEtudeQuery groupByEndClientDiscountPercentage() Group by the end_client_discount_percentage column
 * @method     ChildEtudeQuery groupByClientQuantDiscountPercentage() Group by the client_quant_discount_percentage column
 * @method     ChildEtudeQuery groupByEndClientQuantDiscountPercentage() Group by the end_client_quant_discount_percentage column
 * @method     ChildEtudeQuery groupBySamplePlan() Group by the sample_plan column
 * @method     ChildEtudeQuery groupByIsToInvoice() Group by the isToInvoice column
 * @method     ChildEtudeQuery groupByFilePath() Group by the file_path column
 * @method     ChildEtudeQuery groupByAccountLeaderId() Group by the account_leader_id column
 * @method     ChildEtudeQuery groupByAccountPMId() Group by the account_pm_id column
 * @method     ChildEtudeQuery groupByAmEmail() Group by the am_email column
 * @method     ChildEtudeQuery groupByClientPortalReady() Group by the client_portal_ready column
 * @method     ChildEtudeQuery groupByLengthOfInterview() Group by the length_of_interview column
 * @method     ChildEtudeQuery groupBysunshineAct() Group by the sunshine_act column
 * @method     ChildEtudeQuery groupByIsConsolidated() Group by the is_consolidated column
 * @method     ChildEtudeQuery groupBySharepointFolder() Group by the sharepoint_folder column
 * @method     ChildEtudeQuery groupByMultiPhase() Group by the multi_phase column
 * @method     ChildEtudeQuery groupByPoNumber() Group by the po_number column
 * @method     ChildEtudeQuery groupByCurrencies() Group by the currencies column
 * @method     ChildEtudeQuery groupBySmsRelance() Group by the sms_relance column
 * @method     ChildEtudeQuery groupByIdEtudeGroup() Group by the id_etude_group column
 * @method     ChildEtudeQuery groupByGms() Group by the gms column
 * @method     ChildEtudeQuery groupByKol() Group by the kol column
 * @method     ChildEtudeQuery groupByRoomRental() Group by the room_rental column
 * @method     ChildEtudeQuery groupByRecruitsOffsite() Group by the recruits_offsite column
 * @method     ChildEtudeQuery groupByStudySpecification() Group by the study_specification column
 * @method     ChildEtudeQuery groupByisStudySpecification() Group by the is_study_specification column
 * @method     ChildEtudeQuery groupByAdditionalNotes() Group by the additional_notes column
 * @method     ChildEtudeQuery groupByProjectComment() Group by the project_comment column
 * @method     ChildEtudeQuery groupByEndClientId() Group by the end_client_id column
 * @method     ChildEtudeQuery groupByEndClientContactId() Group by the end_client_contact_id column
 * @method     ChildEtudeQuery groupByContactId() Group by the contact_id column
 * @method     ChildEtudeQuery groupByContactClientPmId() Group by the contact_client_pm_id column
 * @method     ChildEtudeQuery groupByMasterProjectNumber() Group by the master_project_number column
 * @method     ChildEtudeQuery groupByProposedLoi() Group by the proposed_loi column
 * @method     ChildEtudeQuery groupByOpportunityId() Group by the opportunity_id column
 * @method     ChildEtudeQuery groupBySiJobTypeId() Group by the si_job_type_id column
 * @method     ChildEtudeQuery groupByBestEffort() Group by the best_effort column
 * @method     ChildEtudeQuery groupByJobStatusSfId() Group by the job_status_sf_id column
 * @method     ChildEtudeQuery groupByBookedBySfId() Group by the booked_by_sf_id column
 * @method     ChildEtudeQuery groupByCreatedBySfId() Group by the created_by_sf_id column
 * @method     ChildEtudeQuery groupByAccountManagerSfId() Group by the account_manager_sf_id column
 * @method     ChildEtudeQuery groupByCreatedDate() Group by the created_date column
 * @method     ChildEtudeQuery groupByJobQualificationId() Group by the job_qualification_id column
 * @method     ChildEtudeQuery groupByProposedN() Group by the proposed_n column
 * @method     ChildEtudeQuery groupByGermanJobTypeId() Group by the german_job_type_id column
 * @method     ChildEtudeQuery groupByCreatedByComment() Group by the created_by_comment column
 * @method     ChildEtudeQuery groupByFocusVision() Group by the focus_vision column
 * @method     ChildEtudeQuery groupBySiEuJobType() Group by the si_eu_job_type column
 * @method     ChildEtudeQuery groupByIntermediateClientId() Group by the intermediate_client_id column
 * @method     ChildEtudeQuery groupByIntermediateClientContactId() Group by the intermediate_client_contact_id column
 * @method     ChildEtudeQuery groupByUsGlobalQualGmsId() Group by the us_global_qual_gms_id column
 * @method     ChildEtudeQuery groupByFaciltyNote() Group by the facilty_note column
 * @method     ChildEtudeQuery groupByCurrencyIsoCodeId() Group by the currency_iso_code_id column
 * @method     ChildEtudeQuery groupByClientListDeletionId() Group by the client_list_deletion_id column
 * @method     ChildEtudeQuery groupByCreatedById() Group by the created_by_id column
 * @method     ChildEtudeQuery groupByUpdatedById() Group by the updated_by_id column
 * @method     ChildEtudeQuery groupByCreatedAt() Group by the created_at column
 * @method     ChildEtudeQuery groupByUpdatedAt() Group by the updated_at column
 *
 * @method     ChildEtudeQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtudeQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtudeQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtudeQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtudeQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtudeQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtudeQuery leftJoinUsGlobalQualGms($relationAlias = null) Adds a LEFT JOIN clause to the query using the UsGlobalQualGms relation
 * @method     ChildEtudeQuery rightJoinUsGlobalQualGms($relationAlias = null) Adds a RIGHT JOIN clause to the query using the UsGlobalQualGms relation
 * @method     ChildEtudeQuery innerJoinUsGlobalQualGms($relationAlias = null) Adds a INNER JOIN clause to the query using the UsGlobalQualGms relation
 *
 * @method     ChildEtudeQuery joinWithUsGlobalQualGms($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the UsGlobalQualGms relation
 *
 * @method     ChildEtudeQuery leftJoinWithUsGlobalQualGms() Adds a LEFT JOIN clause and with to the query using the UsGlobalQualGms relation
 * @method     ChildEtudeQuery rightJoinWithUsGlobalQualGms() Adds a RIGHT JOIN clause and with to the query using the UsGlobalQualGms relation
 * @method     ChildEtudeQuery innerJoinWithUsGlobalQualGms() Adds a INNER JOIN clause and with to the query using the UsGlobalQualGms relation
 *
 * @method     ChildEtudeQuery leftJoinAccountLeader($relationAlias = null) Adds a LEFT JOIN clause to the query using the AccountLeader relation
 * @method     ChildEtudeQuery rightJoinAccountLeader($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AccountLeader relation
 * @method     ChildEtudeQuery innerJoinAccountLeader($relationAlias = null) Adds a INNER JOIN clause to the query using the AccountLeader relation
 *
 * @method     ChildEtudeQuery joinWithAccountLeader($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the AccountLeader relation
 *
 * @method     ChildEtudeQuery leftJoinWithAccountLeader() Adds a LEFT JOIN clause and with to the query using the AccountLeader relation
 * @method     ChildEtudeQuery rightJoinWithAccountLeader() Adds a RIGHT JOIN clause and with to the query using the AccountLeader relation
 * @method     ChildEtudeQuery innerJoinWithAccountLeader() Adds a INNER JOIN clause and with to the query using the AccountLeader relation
 *
 * @method     ChildEtudeQuery leftJoinAccountPM($relationAlias = null) Adds a LEFT JOIN clause to the query using the AccountPM relation
 * @method     ChildEtudeQuery rightJoinAccountPM($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AccountPM relation
 * @method     ChildEtudeQuery innerJoinAccountPM($relationAlias = null) Adds a INNER JOIN clause to the query using the AccountPM relation
 *
 * @method     ChildEtudeQuery joinWithAccountPM($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the AccountPM relation
 *
 * @method     ChildEtudeQuery leftJoinWithAccountPM() Adds a LEFT JOIN clause and with to the query using the AccountPM relation
 * @method     ChildEtudeQuery rightJoinWithAccountPM() Adds a RIGHT JOIN clause and with to the query using the AccountPM relation
 * @method     ChildEtudeQuery innerJoinWithAccountPM() Adds a INNER JOIN clause and with to the query using the AccountPM relation
 *
 * @method     ChildEtudeQuery leftJoinIntermediateClient($relationAlias = null) Adds a LEFT JOIN clause to the query using the IntermediateClient relation
 * @method     ChildEtudeQuery rightJoinIntermediateClient($relationAlias = null) Adds a RIGHT JOIN clause to the query using the IntermediateClient relation
 * @method     ChildEtudeQuery innerJoinIntermediateClient($relationAlias = null) Adds a INNER JOIN clause to the query using the IntermediateClient relation
 *
 * @method     ChildEtudeQuery joinWithIntermediateClient($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the IntermediateClient relation
 *
 * @method     ChildEtudeQuery leftJoinWithIntermediateClient() Adds a LEFT JOIN clause and with to the query using the IntermediateClient relation
 * @method     ChildEtudeQuery rightJoinWithIntermediateClient() Adds a RIGHT JOIN clause and with to the query using the IntermediateClient relation
 * @method     ChildEtudeQuery innerJoinWithIntermediateClient() Adds a INNER JOIN clause and with to the query using the IntermediateClient relation
 *
 * @method     ChildEtudeQuery leftJoinEtape($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeQuery rightJoinEtape($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeQuery innerJoinEtape($relationAlias = null) Adds a INNER JOIN clause to the query using the Etape relation
 *
 * @method     ChildEtudeQuery joinWithEtape($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etape relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtape() Adds a LEFT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeQuery rightJoinWithEtape() Adds a RIGHT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeQuery innerJoinWithEtape() Adds a INNER JOIN clause and with to the query using the Etape relation
 *
 * @method     ChildEtudeQuery leftJoinContact($relationAlias = null) Adds a LEFT JOIN clause to the query using the Contact relation
 * @method     ChildEtudeQuery rightJoinContact($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Contact relation
 * @method     ChildEtudeQuery innerJoinContact($relationAlias = null) Adds a INNER JOIN clause to the query using the Contact relation
 *
 * @method     ChildEtudeQuery joinWithContact($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Contact relation
 *
 * @method     ChildEtudeQuery leftJoinWithContact() Adds a LEFT JOIN clause and with to the query using the Contact relation
 * @method     ChildEtudeQuery rightJoinWithContact() Adds a RIGHT JOIN clause and with to the query using the Contact relation
 * @method     ChildEtudeQuery innerJoinWithContact() Adds a INNER JOIN clause and with to the query using the Contact relation
 *
 * @method     ChildEtudeQuery leftJoinOpportunity($relationAlias = null) Adds a LEFT JOIN clause to the query using the Opportunity relation
 * @method     ChildEtudeQuery rightJoinOpportunity($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Opportunity relation
 * @method     ChildEtudeQuery innerJoinOpportunity($relationAlias = null) Adds a INNER JOIN clause to the query using the Opportunity relation
 *
 * @method     ChildEtudeQuery joinWithOpportunity($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Opportunity relation
 *
 * @method     ChildEtudeQuery leftJoinWithOpportunity() Adds a LEFT JOIN clause and with to the query using the Opportunity relation
 * @method     ChildEtudeQuery rightJoinWithOpportunity() Adds a RIGHT JOIN clause and with to the query using the Opportunity relation
 * @method     ChildEtudeQuery innerJoinWithOpportunity() Adds a INNER JOIN clause and with to the query using the Opportunity relation
 *
 * @method     ChildEtudeQuery leftJoinJobStatusSf($relationAlias = null) Adds a LEFT JOIN clause to the query using the JobStatusSf relation
 * @method     ChildEtudeQuery rightJoinJobStatusSf($relationAlias = null) Adds a RIGHT JOIN clause to the query using the JobStatusSf relation
 * @method     ChildEtudeQuery innerJoinJobStatusSf($relationAlias = null) Adds a INNER JOIN clause to the query using the JobStatusSf relation
 *
 * @method     ChildEtudeQuery joinWithJobStatusSf($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the JobStatusSf relation
 *
 * @method     ChildEtudeQuery leftJoinWithJobStatusSf() Adds a LEFT JOIN clause and with to the query using the JobStatusSf relation
 * @method     ChildEtudeQuery rightJoinWithJobStatusSf() Adds a RIGHT JOIN clause and with to the query using the JobStatusSf relation
 * @method     ChildEtudeQuery innerJoinWithJobStatusSf() Adds a INNER JOIN clause and with to the query using the JobStatusSf relation
 *
 * @method     ChildEtudeQuery leftJoinJobQualification($relationAlias = null) Adds a LEFT JOIN clause to the query using the JobQualification relation
 * @method     ChildEtudeQuery rightJoinJobQualification($relationAlias = null) Adds a RIGHT JOIN clause to the query using the JobQualification relation
 * @method     ChildEtudeQuery innerJoinJobQualification($relationAlias = null) Adds a INNER JOIN clause to the query using the JobQualification relation
 *
 * @method     ChildEtudeQuery joinWithJobQualification($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the JobQualification relation
 *
 * @method     ChildEtudeQuery leftJoinWithJobQualification() Adds a LEFT JOIN clause and with to the query using the JobQualification relation
 * @method     ChildEtudeQuery rightJoinWithJobQualification() Adds a RIGHT JOIN clause and with to the query using the JobQualification relation
 * @method     ChildEtudeQuery innerJoinWithJobQualification() Adds a INNER JOIN clause and with to the query using the JobQualification relation
 *
 * @method     ChildEtudeQuery leftJoinSiJobType($relationAlias = null) Adds a LEFT JOIN clause to the query using the SiJobType relation
 * @method     ChildEtudeQuery rightJoinSiJobType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the SiJobType relation
 * @method     ChildEtudeQuery innerJoinSiJobType($relationAlias = null) Adds a INNER JOIN clause to the query using the SiJobType relation
 *
 * @method     ChildEtudeQuery joinWithSiJobType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the SiJobType relation
 *
 * @method     ChildEtudeQuery leftJoinWithSiJobType() Adds a LEFT JOIN clause and with to the query using the SiJobType relation
 * @method     ChildEtudeQuery rightJoinWithSiJobType() Adds a RIGHT JOIN clause and with to the query using the SiJobType relation
 * @method     ChildEtudeQuery innerJoinWithSiJobType() Adds a INNER JOIN clause and with to the query using the SiJobType relation
 *
 * @method     ChildEtudeQuery leftJoinEndClientContact($relationAlias = null) Adds a LEFT JOIN clause to the query using the EndClientContact relation
 * @method     ChildEtudeQuery rightJoinEndClientContact($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EndClientContact relation
 * @method     ChildEtudeQuery innerJoinEndClientContact($relationAlias = null) Adds a INNER JOIN clause to the query using the EndClientContact relation
 *
 * @method     ChildEtudeQuery joinWithEndClientContact($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EndClientContact relation
 *
 * @method     ChildEtudeQuery leftJoinWithEndClientContact() Adds a LEFT JOIN clause and with to the query using the EndClientContact relation
 * @method     ChildEtudeQuery rightJoinWithEndClientContact() Adds a RIGHT JOIN clause and with to the query using the EndClientContact relation
 * @method     ChildEtudeQuery innerJoinWithEndClientContact() Adds a INNER JOIN clause and with to the query using the EndClientContact relation
 *
 * @method     ChildEtudeQuery leftJoinGermanJobType($relationAlias = null) Adds a LEFT JOIN clause to the query using the GermanJobType relation
 * @method     ChildEtudeQuery rightJoinGermanJobType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the GermanJobType relation
 * @method     ChildEtudeQuery innerJoinGermanJobType($relationAlias = null) Adds a INNER JOIN clause to the query using the GermanJobType relation
 *
 * @method     ChildEtudeQuery joinWithGermanJobType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the GermanJobType relation
 *
 * @method     ChildEtudeQuery leftJoinWithGermanJobType() Adds a LEFT JOIN clause and with to the query using the GermanJobType relation
 * @method     ChildEtudeQuery rightJoinWithGermanJobType() Adds a RIGHT JOIN clause and with to the query using the GermanJobType relation
 * @method     ChildEtudeQuery innerJoinWithGermanJobType() Adds a INNER JOIN clause and with to the query using the GermanJobType relation
 *
 * @method     ChildEtudeQuery leftJoinEndClient($relationAlias = null) Adds a LEFT JOIN clause to the query using the EndClient relation
 * @method     ChildEtudeQuery rightJoinEndClient($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EndClient relation
 * @method     ChildEtudeQuery innerJoinEndClient($relationAlias = null) Adds a INNER JOIN clause to the query using the EndClient relation
 *
 * @method     ChildEtudeQuery joinWithEndClient($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EndClient relation
 *
 * @method     ChildEtudeQuery leftJoinWithEndClient() Adds a LEFT JOIN clause and with to the query using the EndClient relation
 * @method     ChildEtudeQuery rightJoinWithEndClient() Adds a RIGHT JOIN clause and with to the query using the EndClient relation
 * @method     ChildEtudeQuery innerJoinWithEndClient() Adds a INNER JOIN clause and with to the query using the EndClient relation
 *
 * @method     ChildEtudeQuery leftJoinAccount($relationAlias = null) Adds a LEFT JOIN clause to the query using the Account relation
 * @method     ChildEtudeQuery rightJoinAccount($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Account relation
 * @method     ChildEtudeQuery innerJoinAccount($relationAlias = null) Adds a INNER JOIN clause to the query using the Account relation
 *
 * @method     ChildEtudeQuery joinWithAccount($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Account relation
 *
 * @method     ChildEtudeQuery leftJoinWithAccount() Adds a LEFT JOIN clause and with to the query using the Account relation
 * @method     ChildEtudeQuery rightJoinWithAccount() Adds a RIGHT JOIN clause and with to the query using the Account relation
 * @method     ChildEtudeQuery innerJoinWithAccount() Adds a INNER JOIN clause and with to the query using the Account relation
 *
 * @method     ChildEtudeQuery leftJoinIndustry($relationAlias = null) Adds a LEFT JOIN clause to the query using the Industry relation
 * @method     ChildEtudeQuery rightJoinIndustry($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Industry relation
 * @method     ChildEtudeQuery innerJoinIndustry($relationAlias = null) Adds a INNER JOIN clause to the query using the Industry relation
 *
 * @method     ChildEtudeQuery joinWithIndustry($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Industry relation
 *
 * @method     ChildEtudeQuery leftJoinWithIndustry() Adds a LEFT JOIN clause and with to the query using the Industry relation
 * @method     ChildEtudeQuery rightJoinWithIndustry() Adds a RIGHT JOIN clause and with to the query using the Industry relation
 * @method     ChildEtudeQuery innerJoinWithIndustry() Adds a INNER JOIN clause and with to the query using the Industry relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeLocation($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeLocation relation
 * @method     ChildEtudeQuery rightJoinEtudeLocation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeLocation relation
 * @method     ChildEtudeQuery innerJoinEtudeLocation($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeLocation relation
 *
 * @method     ChildEtudeQuery joinWithEtudeLocation($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeLocation relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeLocation() Adds a LEFT JOIN clause and with to the query using the EtudeLocation relation
 * @method     ChildEtudeQuery rightJoinWithEtudeLocation() Adds a RIGHT JOIN clause and with to the query using the EtudeLocation relation
 * @method     ChildEtudeQuery innerJoinWithEtudeLocation() Adds a INNER JOIN clause and with to the query using the EtudeLocation relation
 *
 * @method     ChildEtudeQuery leftJoinProjectLocationPrefix($relationAlias = null) Adds a LEFT JOIN clause to the query using the ProjectLocationPrefix relation
 * @method     ChildEtudeQuery rightJoinProjectLocationPrefix($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ProjectLocationPrefix relation
 * @method     ChildEtudeQuery innerJoinProjectLocationPrefix($relationAlias = null) Adds a INNER JOIN clause to the query using the ProjectLocationPrefix relation
 *
 * @method     ChildEtudeQuery joinWithProjectLocationPrefix($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the ProjectLocationPrefix relation
 *
 * @method     ChildEtudeQuery leftJoinWithProjectLocationPrefix() Adds a LEFT JOIN clause and with to the query using the ProjectLocationPrefix relation
 * @method     ChildEtudeQuery rightJoinWithProjectLocationPrefix() Adds a RIGHT JOIN clause and with to the query using the ProjectLocationPrefix relation
 * @method     ChildEtudeQuery innerJoinWithProjectLocationPrefix() Adds a INNER JOIN clause and with to the query using the ProjectLocationPrefix relation
 *
 * @method     ChildEtudeQuery leftJoinContactClientPm($relationAlias = null) Adds a LEFT JOIN clause to the query using the ContactClientPm relation
 * @method     ChildEtudeQuery rightJoinContactClientPm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ContactClientPm relation
 * @method     ChildEtudeQuery innerJoinContactClientPm($relationAlias = null) Adds a INNER JOIN clause to the query using the ContactClientPm relation
 *
 * @method     ChildEtudeQuery joinWithContactClientPm($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the ContactClientPm relation
 *
 * @method     ChildEtudeQuery leftJoinWithContactClientPm() Adds a LEFT JOIN clause and with to the query using the ContactClientPm relation
 * @method     ChildEtudeQuery rightJoinWithContactClientPm() Adds a RIGHT JOIN clause and with to the query using the ContactClientPm relation
 * @method     ChildEtudeQuery innerJoinWithContactClientPm() Adds a INNER JOIN clause and with to the query using the ContactClientPm relation
 *
 * @method     ChildEtudeQuery leftJoinBM($relationAlias = null) Adds a LEFT JOIN clause to the query using the BM relation
 * @method     ChildEtudeQuery rightJoinBM($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BM relation
 * @method     ChildEtudeQuery innerJoinBM($relationAlias = null) Adds a INNER JOIN clause to the query using the BM relation
 *
 * @method     ChildEtudeQuery joinWithBM($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the BM relation
 *
 * @method     ChildEtudeQuery leftJoinWithBM() Adds a LEFT JOIN clause and with to the query using the BM relation
 * @method     ChildEtudeQuery rightJoinWithBM() Adds a RIGHT JOIN clause and with to the query using the BM relation
 * @method     ChildEtudeQuery innerJoinWithBM() Adds a INNER JOIN clause and with to the query using the BM relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeProjectManager($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeProjectManager relation
 * @method     ChildEtudeQuery rightJoinEtudeProjectManager($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeProjectManager relation
 * @method     ChildEtudeQuery innerJoinEtudeProjectManager($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeProjectManager relation
 *
 * @method     ChildEtudeQuery joinWithEtudeProjectManager($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeProjectManager relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeProjectManager() Adds a LEFT JOIN clause and with to the query using the EtudeProjectManager relation
 * @method     ChildEtudeQuery rightJoinWithEtudeProjectManager() Adds a RIGHT JOIN clause and with to the query using the EtudeProjectManager relation
 * @method     ChildEtudeQuery innerJoinWithEtudeProjectManager() Adds a INNER JOIN clause and with to the query using the EtudeProjectManager relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeGroup($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeGroup relation
 * @method     ChildEtudeQuery rightJoinEtudeGroup($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeGroup relation
 * @method     ChildEtudeQuery innerJoinEtudeGroup($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeGroup relation
 *
 * @method     ChildEtudeQuery joinWithEtudeGroup($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeGroup relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeGroup() Adds a LEFT JOIN clause and with to the query using the EtudeGroup relation
 * @method     ChildEtudeQuery rightJoinWithEtudeGroup() Adds a RIGHT JOIN clause and with to the query using the EtudeGroup relation
 * @method     ChildEtudeQuery innerJoinWithEtudeGroup() Adds a INNER JOIN clause and with to the query using the EtudeGroup relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeArea($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeArea relation
 * @method     ChildEtudeQuery rightJoinEtudeArea($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeArea relation
 * @method     ChildEtudeQuery innerJoinEtudeArea($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeArea relation
 *
 * @method     ChildEtudeQuery joinWithEtudeArea($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeArea relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeArea() Adds a LEFT JOIN clause and with to the query using the EtudeArea relation
 * @method     ChildEtudeQuery rightJoinWithEtudeArea() Adds a RIGHT JOIN clause and with to the query using the EtudeArea relation
 * @method     ChildEtudeQuery innerJoinWithEtudeArea() Adds a INNER JOIN clause and with to the query using the EtudeArea relation
 *
 * @method     ChildEtudeQuery leftJoinCurrencyIsoCode($relationAlias = null) Adds a LEFT JOIN clause to the query using the CurrencyIsoCode relation
 * @method     ChildEtudeQuery rightJoinCurrencyIsoCode($relationAlias = null) Adds a RIGHT JOIN clause to the query using the CurrencyIsoCode relation
 * @method     ChildEtudeQuery innerJoinCurrencyIsoCode($relationAlias = null) Adds a INNER JOIN clause to the query using the CurrencyIsoCode relation
 *
 * @method     ChildEtudeQuery joinWithCurrencyIsoCode($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the CurrencyIsoCode relation
 *
 * @method     ChildEtudeQuery leftJoinWithCurrencyIsoCode() Adds a LEFT JOIN clause and with to the query using the CurrencyIsoCode relation
 * @method     ChildEtudeQuery rightJoinWithCurrencyIsoCode() Adds a RIGHT JOIN clause and with to the query using the CurrencyIsoCode relation
 * @method     ChildEtudeQuery innerJoinWithCurrencyIsoCode() Adds a INNER JOIN clause and with to the query using the CurrencyIsoCode relation
 *
 * @method     ChildEtudeQuery leftJoinClientListDeletion($relationAlias = null) Adds a LEFT JOIN clause to the query using the ClientListDeletion relation
 * @method     ChildEtudeQuery rightJoinClientListDeletion($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ClientListDeletion relation
 * @method     ChildEtudeQuery innerJoinClientListDeletion($relationAlias = null) Adds a INNER JOIN clause to the query using the ClientListDeletion relation
 *
 * @method     ChildEtudeQuery joinWithClientListDeletion($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the ClientListDeletion relation
 *
 * @method     ChildEtudeQuery leftJoinWithClientListDeletion() Adds a LEFT JOIN clause and with to the query using the ClientListDeletion relation
 * @method     ChildEtudeQuery rightJoinWithClientListDeletion() Adds a RIGHT JOIN clause and with to the query using the ClientListDeletion relation
 * @method     ChildEtudeQuery innerJoinWithClientListDeletion() Adds a INNER JOIN clause and with to the query using the ClientListDeletion relation
 *
 * @method     ChildEtudeQuery leftJoinCreatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the CreatedBy relation
 * @method     ChildEtudeQuery rightJoinCreatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the CreatedBy relation
 * @method     ChildEtudeQuery innerJoinCreatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the CreatedBy relation
 *
 * @method     ChildEtudeQuery joinWithCreatedBy($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the CreatedBy relation
 *
 * @method     ChildEtudeQuery leftJoinWithCreatedBy() Adds a LEFT JOIN clause and with to the query using the CreatedBy relation
 * @method     ChildEtudeQuery rightJoinWithCreatedBy() Adds a RIGHT JOIN clause and with to the query using the CreatedBy relation
 * @method     ChildEtudeQuery innerJoinWithCreatedBy() Adds a INNER JOIN clause and with to the query using the CreatedBy relation
 *
 * @method     ChildEtudeQuery leftJoinUpdatedBy($relationAlias = null) Adds a LEFT JOIN clause to the query using the UpdatedBy relation
 * @method     ChildEtudeQuery rightJoinUpdatedBy($relationAlias = null) Adds a RIGHT JOIN clause to the query using the UpdatedBy relation
 * @method     ChildEtudeQuery innerJoinUpdatedBy($relationAlias = null) Adds a INNER JOIN clause to the query using the UpdatedBy relation
 *
 * @method     ChildEtudeQuery joinWithUpdatedBy($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the UpdatedBy relation
 *
 * @method     ChildEtudeQuery leftJoinWithUpdatedBy() Adds a LEFT JOIN clause and with to the query using the UpdatedBy relation
 * @method     ChildEtudeQuery rightJoinWithUpdatedBy() Adds a RIGHT JOIN clause and with to the query using the UpdatedBy relation
 * @method     ChildEtudeQuery innerJoinWithUpdatedBy() Adds a INNER JOIN clause and with to the query using the UpdatedBy relation
 *
 * @method     ChildEtudeQuery leftJoinIntermediateClientContact($relationAlias = null) Adds a LEFT JOIN clause to the query using the IntermediateClientContact relation
 * @method     ChildEtudeQuery rightJoinIntermediateClientContact($relationAlias = null) Adds a RIGHT JOIN clause to the query using the IntermediateClientContact relation
 * @method     ChildEtudeQuery innerJoinIntermediateClientContact($relationAlias = null) Adds a INNER JOIN clause to the query using the IntermediateClientContact relation
 *
 * @method     ChildEtudeQuery joinWithIntermediateClientContact($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the IntermediateClientContact relation
 *
 * @method     ChildEtudeQuery leftJoinWithIntermediateClientContact() Adds a LEFT JOIN clause and with to the query using the IntermediateClientContact relation
 * @method     ChildEtudeQuery rightJoinWithIntermediateClientContact() Adds a RIGHT JOIN clause and with to the query using the IntermediateClientContact relation
 * @method     ChildEtudeQuery innerJoinWithIntermediateClientContact() Adds a INNER JOIN clause and with to the query using the IntermediateClientContact relation
 *
 * @method     ChildEtudeQuery leftJoinProjectAccountManager($relationAlias = null) Adds a LEFT JOIN clause to the query using the ProjectAccountManager relation
 * @method     ChildEtudeQuery rightJoinProjectAccountManager($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ProjectAccountManager relation
 * @method     ChildEtudeQuery innerJoinProjectAccountManager($relationAlias = null) Adds a INNER JOIN clause to the query using the ProjectAccountManager relation
 *
 * @method     ChildEtudeQuery joinWithProjectAccountManager($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the ProjectAccountManager relation
 *
 * @method     ChildEtudeQuery leftJoinWithProjectAccountManager() Adds a LEFT JOIN clause and with to the query using the ProjectAccountManager relation
 * @method     ChildEtudeQuery rightJoinWithProjectAccountManager() Adds a RIGHT JOIN clause and with to the query using the ProjectAccountManager relation
 * @method     ChildEtudeQuery innerJoinWithProjectAccountManager() Adds a INNER JOIN clause and with to the query using the ProjectAccountManager relation
 *
 * @method     ChildEtudeQuery leftJoinProjectSpecialtySponsor($relationAlias = null) Adds a LEFT JOIN clause to the query using the ProjectSpecialtySponsor relation
 * @method     ChildEtudeQuery rightJoinProjectSpecialtySponsor($relationAlias = null) Adds a RIGHT JOIN clause to the query using the ProjectSpecialtySponsor relation
 * @method     ChildEtudeQuery innerJoinProjectSpecialtySponsor($relationAlias = null) Adds a INNER JOIN clause to the query using the ProjectSpecialtySponsor relation
 *
 * @method     ChildEtudeQuery joinWithProjectSpecialtySponsor($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the ProjectSpecialtySponsor relation
 *
 * @method     ChildEtudeQuery leftJoinWithProjectSpecialtySponsor() Adds a LEFT JOIN clause and with to the query using the ProjectSpecialtySponsor relation
 * @method     ChildEtudeQuery rightJoinWithProjectSpecialtySponsor() Adds a RIGHT JOIN clause and with to the query using the ProjectSpecialtySponsor relation
 * @method     ChildEtudeQuery innerJoinWithProjectSpecialtySponsor() Adds a INNER JOIN clause and with to the query using the ProjectSpecialtySponsor relation
 *
 * @method     ChildEtudeQuery leftJoinAmReasonType($relationAlias = null) Adds a LEFT JOIN clause to the query using the AmReasonType relation
 * @method     ChildEtudeQuery rightJoinAmReasonType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the AmReasonType relation
 * @method     ChildEtudeQuery innerJoinAmReasonType($relationAlias = null) Adds a INNER JOIN clause to the query using the AmReasonType relation
 *
 * @method     ChildEtudeQuery joinWithAmReasonType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the AmReasonType relation
 *
 * @method     ChildEtudeQuery leftJoinWithAmReasonType() Adds a LEFT JOIN clause and with to the query using the AmReasonType relation
 * @method     ChildEtudeQuery rightJoinWithAmReasonType() Adds a RIGHT JOIN clause and with to the query using the AmReasonType relation
 * @method     ChildEtudeQuery innerJoinWithAmReasonType() Adds a INNER JOIN clause and with to the query using the AmReasonType relation
 *
 * @method     ChildEtudeQuery leftJoinDernierAcces($relationAlias = null) Adds a LEFT JOIN clause to the query using the DernierAcces relation
 * @method     ChildEtudeQuery rightJoinDernierAcces($relationAlias = null) Adds a RIGHT JOIN clause to the query using the DernierAcces relation
 * @method     ChildEtudeQuery innerJoinDernierAcces($relationAlias = null) Adds a INNER JOIN clause to the query using the DernierAcces relation
 *
 * @method     ChildEtudeQuery joinWithDernierAcces($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the DernierAcces relation
 *
 * @method     ChildEtudeQuery leftJoinWithDernierAcces() Adds a LEFT JOIN clause and with to the query using the DernierAcces relation
 * @method     ChildEtudeQuery rightJoinWithDernierAcces() Adds a RIGHT JOIN clause and with to the query using the DernierAcces relation
 * @method     ChildEtudeQuery innerJoinWithDernierAcces() Adds a INNER JOIN clause and with to the query using the DernierAcces relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeSampleSource($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeSampleSource relation
 * @method     ChildEtudeQuery rightJoinEtudeSampleSource($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeSampleSource relation
 * @method     ChildEtudeQuery innerJoinEtudeSampleSource($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeSampleSource relation
 *
 * @method     ChildEtudeQuery joinWithEtudeSampleSource($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeSampleSource relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeSampleSource() Adds a LEFT JOIN clause and with to the query using the EtudeSampleSource relation
 * @method     ChildEtudeQuery rightJoinWithEtudeSampleSource() Adds a RIGHT JOIN clause and with to the query using the EtudeSampleSource relation
 * @method     ChildEtudeQuery innerJoinWithEtudeSampleSource() Adds a INNER JOIN clause and with to the query using the EtudeSampleSource relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeMethodology($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeMethodology relation
 * @method     ChildEtudeQuery rightJoinEtudeMethodology($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeMethodology relation
 * @method     ChildEtudeQuery innerJoinEtudeMethodology($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeMethodology relation
 *
 * @method     ChildEtudeQuery joinWithEtudeMethodology($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeMethodology relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeMethodology() Adds a LEFT JOIN clause and with to the query using the EtudeMethodology relation
 * @method     ChildEtudeQuery rightJoinWithEtudeMethodology() Adds a RIGHT JOIN clause and with to the query using the EtudeMethodology relation
 * @method     ChildEtudeQuery innerJoinWithEtudeMethodology() Adds a INNER JOIN clause and with to the query using the EtudeMethodology relation
 *
 * @method     ChildEtudeQuery leftJoinFacture($relationAlias = null) Adds a LEFT JOIN clause to the query using the Facture relation
 * @method     ChildEtudeQuery rightJoinFacture($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Facture relation
 * @method     ChildEtudeQuery innerJoinFacture($relationAlias = null) Adds a INNER JOIN clause to the query using the Facture relation
 *
 * @method     ChildEtudeQuery joinWithFacture($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Facture relation
 *
 * @method     ChildEtudeQuery leftJoinWithFacture() Adds a LEFT JOIN clause and with to the query using the Facture relation
 * @method     ChildEtudeQuery rightJoinWithFacture() Adds a RIGHT JOIN clause and with to the query using the Facture relation
 * @method     ChildEtudeQuery innerJoinWithFacture() Adds a INNER JOIN clause and with to the query using the Facture relation
 *
 * @method     ChildEtudeQuery leftJoinJobEtude($relationAlias = null) Adds a LEFT JOIN clause to the query using the JobEtude relation
 * @method     ChildEtudeQuery rightJoinJobEtude($relationAlias = null) Adds a RIGHT JOIN clause to the query using the JobEtude relation
 * @method     ChildEtudeQuery innerJoinJobEtude($relationAlias = null) Adds a INNER JOIN clause to the query using the JobEtude relation
 *
 * @method     ChildEtudeQuery joinWithJobEtude($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the JobEtude relation
 *
 * @method     ChildEtudeQuery leftJoinWithJobEtude() Adds a LEFT JOIN clause and with to the query using the JobEtude relation
 * @method     ChildEtudeQuery rightJoinWithJobEtude() Adds a RIGHT JOIN clause and with to the query using the JobEtude relation
 * @method     ChildEtudeQuery innerJoinWithJobEtude() Adds a INNER JOIN clause and with to the query using the JobEtude relation
 *
 * @method     ChildEtudeQuery leftJoinReglement($relationAlias = null) Adds a LEFT JOIN clause to the query using the Reglement relation
 * @method     ChildEtudeQuery rightJoinReglement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Reglement relation
 * @method     ChildEtudeQuery innerJoinReglement($relationAlias = null) Adds a INNER JOIN clause to the query using the Reglement relation
 *
 * @method     ChildEtudeQuery joinWithReglement($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Reglement relation
 *
 * @method     ChildEtudeQuery leftJoinWithReglement() Adds a LEFT JOIN clause and with to the query using the Reglement relation
 * @method     ChildEtudeQuery rightJoinWithReglement() Adds a RIGHT JOIN clause and with to the query using the Reglement relation
 * @method     ChildEtudeQuery innerJoinWithReglement() Adds a INNER JOIN clause and with to the query using the Reglement relation
 *
 * @method     ChildEtudeQuery leftJoinSector($relationAlias = null) Adds a LEFT JOIN clause to the query using the Sector relation
 * @method     ChildEtudeQuery rightJoinSector($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Sector relation
 * @method     ChildEtudeQuery innerJoinSector($relationAlias = null) Adds a INNER JOIN clause to the query using the Sector relation
 *
 * @method     ChildEtudeQuery joinWithSector($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Sector relation
 *
 * @method     ChildEtudeQuery leftJoinWithSector() Adds a LEFT JOIN clause and with to the query using the Sector relation
 * @method     ChildEtudeQuery rightJoinWithSector() Adds a RIGHT JOIN clause and with to the query using the Sector relation
 * @method     ChildEtudeQuery innerJoinWithSector() Adds a INNER JOIN clause and with to the query using the Sector relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeCheckListValidation($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeQuery rightJoinEtudeCheckListValidation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeQuery innerJoinEtudeCheckListValidation($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeCheckListValidation relation
 *
 * @method     ChildEtudeQuery joinWithEtudeCheckListValidation($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeCheckListValidation relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeCheckListValidation() Adds a LEFT JOIN clause and with to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeQuery rightJoinWithEtudeCheckListValidation() Adds a RIGHT JOIN clause and with to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeQuery innerJoinWithEtudeCheckListValidation() Adds a INNER JOIN clause and with to the query using the EtudeCheckListValidation relation
 *
 * @method     ChildEtudeQuery leftJoinEtudeFichier($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeFichier relation
 * @method     ChildEtudeQuery rightJoinEtudeFichier($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeFichier relation
 * @method     ChildEtudeQuery innerJoinEtudeFichier($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeFichier relation
 *
 * @method     ChildEtudeQuery joinWithEtudeFichier($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeFichier relation
 *
 * @method     ChildEtudeQuery leftJoinWithEtudeFichier() Adds a LEFT JOIN clause and with to the query using the EtudeFichier relation
 * @method     ChildEtudeQuery rightJoinWithEtudeFichier() Adds a RIGHT JOIN clause and with to the query using the EtudeFichier relation
 * @method     ChildEtudeQuery innerJoinWithEtudeFichier() Adds a INNER JOIN clause and with to the query using the EtudeFichier relation
 *
 * @method     ChildEtudeQuery leftJoinLogProjectStatus($relationAlias = null) Adds a LEFT JOIN clause to the query using the LogProjectStatus relation
 * @method     ChildEtudeQuery rightJoinLogProjectStatus($relationAlias = null) Adds a RIGHT JOIN clause to the query using the LogProjectStatus relation
 * @method     ChildEtudeQuery innerJoinLogProjectStatus($relationAlias = null) Adds a INNER JOIN clause to the query using the LogProjectStatus relation
 *
 * @method     ChildEtudeQuery joinWithLogProjectStatus($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the LogProjectStatus relation
 *
 * @method     ChildEtudeQuery leftJoinWithLogProjectStatus() Adds a LEFT JOIN clause and with to the query using the LogProjectStatus relation
 * @method     ChildEtudeQuery rightJoinWithLogProjectStatus() Adds a RIGHT JOIN clause and with to the query using the LogProjectStatus relation
 * @method     ChildEtudeQuery innerJoinWithLogProjectStatus() Adds a INNER JOIN clause and with to the query using the LogProjectStatus relation
 *
 * @method     \Model\RefSalesForceQuery|\Model\UserQuery|\Model\AccountQuery|\Model\EtapeQuery|\Model\ContactQuery|\Model\OpportunityQuery|\Model\SiJobTypeQuery|\Model\IndustryQuery|\Model\LocationQuery|\Model\ProjectLocationPrefixQuery|\Model\EtudeGroupQuery|\Model\AreaQuery|\Model\AmReasonTypeQuery|\Model\DernierAccesQuery|\Model\EtudeSampleSourceQuery|\Model\EtudeMethodologyQuery|\Model\FactureQuery|\Model\JobQuery|\Model\ReglementQuery|\Model\RefSalesForceEtudeSectorQuery|\Model\EtudeCheckListValidationQuery|\Model\EtudeFichierQuery|\Model\LogProjectStatusQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtude|null findOne(ConnectionInterface $con = null) Return the first ChildEtude matching the query
 * @method     ChildEtude findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtude matching the query, or a new ChildEtude object populated from the query conditions when no match is found
 *
 * @method     ChildEtude|null findOneById(int $id) Return the first ChildEtude filtered by the id column
 * @method     ChildEtude|null findOneByNumeroEtude(string $numero_etude) Return the first ChildEtude filtered by the numero_etude column
 * @method     ChildEtude|null findOneByReferenceClient(string $reference_client) Return the first ChildEtude filtered by the reference_client column
 * @method     ChildEtude|null findOneByMasterProjectSfId(string $master_project_sf_id) Return the first ChildEtude filtered by the master_project_sf_id column
 * @method     ChildEtude|null findOneByTheme(string $theme) Return the first ChildEtude filtered by the theme column
 * @method     ChildEtude|null findOneByDateDebut(string $date_debut) Return the first ChildEtude filtered by the date_debut column
 * @method     ChildEtude|null findOneByDateFin(string $date_fin) Return the first ChildEtude filtered by the date_fin column
 * @method     ChildEtude|null findOneByAnnee(string $annee) Return the first ChildEtude filtered by the annee column
 * @method     ChildEtude|null findOneByRst(boolean $rst) Return the first ChildEtude filtered by the rst column
 * @method     ChildEtude|null findOneByCli(boolean $cli) Return the first ChildEtude filtered by the cli column
 * @method     ChildEtude|null findOneByGqs(boolean $gqs) Return the first ChildEtude filtered by the gqs column
 * @method     ChildEtude|null findOneByIns(boolean $ins) Return the first ChildEtude filtered by the ins column
 * @method     ChildEtude|null findOneByHut(boolean $hut) Return the first ChildEtude filtered by the hut column
 * @method     ChildEtude|null findOneByDisplayTotalOnly(boolean $display_total_only) Return the first ChildEtude filtered by the display_total_only column
 * @method     ChildEtude|null findOneByIdPm(int $id_pm) Return the first ChildEtude filtered by the id_pm column
 * @method     ChildEtude|null findOneByIdEtape(int $id_etape) Return the first ChildEtude filtered by the id_etape column
 * @method     ChildEtude|null findOneByPrixRevientInitial(string $prix_revient_initial) Return the first ChildEtude filtered by the prix_revient_initial column
 * @method     ChildEtude|null findOneByPrixRevientActualise(string $prix_revient_actualise) Return the first ChildEtude filtered by the prix_revient_actualise column
 * @method     ChildEtude|null findOneByPrixVenteInitial(string $prix_vente_initial) Return the first ChildEtude filtered by the prix_vente_initial column
 * @method     ChildEtude|null findOneByPrixVenteActualise(string $prix_vente_actualise) Return the first ChildEtude filtered by the prix_vente_actualise column
 * @method     ChildEtude|null findOneByConsolidatedInvoice(boolean $consolidated_invoice) Return the first ChildEtude filtered by the consolidated_invoice column
 * @method     ChildEtude|null findOneBySendCsatQuest(boolean $send_csat_quest) Return the first ChildEtude filtered by the send_csat_quest column
 * @method     ChildEtude|null findOneByIsSendCsatQuestMail(boolean $is_send_csat_quest_mail) Return the first ChildEtude filtered by the is_send_csat_quest_mail column
 * @method     ChildEtude|null findOneByNumeroFacture(string $numero_facture) Return the first ChildEtude filtered by the numero_facture column
 * @method     ChildEtude|null findOneByDontSetAmAuto(boolean $dont_set_am_auto) Return the first ChildEtude filtered by the dont_set_am_auto column
 * @method     ChildEtude|null findOneBySetAmReason(string $set_am_reason) Return the first ChildEtude filtered by the set_am_reason column
 * @method     ChildEtude|null findOneByAmReasonTypeId(int $am_reason_type_id) Return the first ChildEtude filtered by the am_reason_type_id column
 * @method     ChildEtude|null findOneByDateEnvoiFacture(string $date_envoi_facture) Return the first ChildEtude filtered by the date_envoi_facture column
 * @method     ChildEtude|null findOneByDateReglement(string $date_reglement) Return the first ChildEtude filtered by the date_reglement column
 * @method     ChildEtude|null findOneByCommentaire(string $commentaire) Return the first ChildEtude filtered by the commentaire column
 * @method     ChildEtude|null findOneByIndustryId(int $industry_id) Return the first ChildEtude filtered by the industry_id column
 * @method     ChildEtude|null findOneByPeriodeCutoff(string $periode_cutoff) Return the first ChildEtude filtered by the periode_cutoff column
 * @method     ChildEtude|null findOneByThemeBr(string $theme_br) Return the first ChildEtude filtered by the theme_br column
 * @method     ChildEtude|null findOneByAreaId(int $area_id) Return the first ChildEtude filtered by the area_id column
 * @method     ChildEtude|null findOneByIdSamsStudy(string $id_sams_study) Return the first ChildEtude filtered by the id_sams_study column
 * @method     ChildEtude|null findOneByRecrutementObjectif(int $recrutement_objectif) Return the first ChildEtude filtered by the recrutement_objectif column
 * @method     ChildEtude|null findOneByIdLocationPnl(int $id_location_pnl) Return the first ChildEtude filtered by the id_location_pnl column
 * @method     ChildEtude|null findOneByIdMasterProjectLocationPnl(int $id_master_project_location_pnl) Return the first ChildEtude filtered by the id_master_project_location_pnl column
 * @method     ChildEtude|null findOneByRecrutementObjectifPr(int $recrutement_objectif_pr) Return the first ChildEtude filtered by the recrutement_objectif_pr column
 * @method     ChildEtude|null findOneByIdBm(int $id_bm) Return the first ChildEtude filtered by the id_bm column
 * @method     ChildEtude|null findOneByExtraInfo(string $extra_info) Return the first ChildEtude filtered by the extra_info column
 * @method     ChildEtude|null findOneByAccountId(int $account_id) Return the first ChildEtude filtered by the account_id column
 * @method     ChildEtude|null findOneByAccountManagerId(int $account_manager_id) Return the first ChildEtude filtered by the account_manager_id column
 * @method     ChildEtude|null findOneByProjectSpecialtySponsorId(int $project_specialty_sponsor_id) Return the first ChildEtude filtered by the project_specialty_sponsor_id column
 * @method     ChildEtude|null findOneByLanguage(string $language) Return the first ChildEtude filtered by the language column
 * @method     ChildEtude|null findOneByRemiseTaux(string $remise_taux) Return the first ChildEtude filtered by the remise_taux column
 * @method     ChildEtude|null findOneByClientDiscountPercentage(string $client_discount_percentage) Return the first ChildEtude filtered by the client_discount_percentage column
 * @method     ChildEtude|null findOneByEndClientDiscountPercentage(string $end_client_discount_percentage) Return the first ChildEtude filtered by the end_client_discount_percentage column
 * @method     ChildEtude|null findOneByClientQuantDiscountPercentage(string $client_quant_discount_percentage) Return the first ChildEtude filtered by the client_quant_discount_percentage column
 * @method     ChildEtude|null findOneByEndClientQuantDiscountPercentage(string $end_client_quant_discount_percentage) Return the first ChildEtude filtered by the end_client_quant_discount_percentage column
 * @method     ChildEtude|null findOneBySamplePlan(string $sample_plan) Return the first ChildEtude filtered by the sample_plan column
 * @method     ChildEtude|null findOneByIsToInvoice(boolean $isToInvoice) Return the first ChildEtude filtered by the isToInvoice column
 * @method     ChildEtude|null findOneByFilePath(string $file_path) Return the first ChildEtude filtered by the file_path column
 * @method     ChildEtude|null findOneByAccountLeaderId(int $account_leader_id) Return the first ChildEtude filtered by the account_leader_id column
 * @method     ChildEtude|null findOneByAccountPMId(int $account_pm_id) Return the first ChildEtude filtered by the account_pm_id column
 * @method     ChildEtude|null findOneByAmEmail(string $am_email) Return the first ChildEtude filtered by the am_email column
 * @method     ChildEtude|null findOneByClientPortalReady(boolean $client_portal_ready) Return the first ChildEtude filtered by the client_portal_ready column
 * @method     ChildEtude|null findOneByLengthOfInterview(string $length_of_interview) Return the first ChildEtude filtered by the length_of_interview column
 * @method     ChildEtude|null findOneBysunshineAct(string $sunshine_act) Return the first ChildEtude filtered by the sunshine_act column
 * @method     ChildEtude|null findOneByIsConsolidated(boolean $is_consolidated) Return the first ChildEtude filtered by the is_consolidated column
 * @method     ChildEtude|null findOneBySharepointFolder(string $sharepoint_folder) Return the first ChildEtude filtered by the sharepoint_folder column
 * @method     ChildEtude|null findOneByMultiPhase(boolean $multi_phase) Return the first ChildEtude filtered by the multi_phase column
 * @method     ChildEtude|null findOneByPoNumber(string $po_number) Return the first ChildEtude filtered by the po_number column
 * @method     ChildEtude|null findOneByCurrencies(string $currencies) Return the first ChildEtude filtered by the currencies column
 * @method     ChildEtude|null findOneBySmsRelance(boolean $sms_relance) Return the first ChildEtude filtered by the sms_relance column
 * @method     ChildEtude|null findOneByIdEtudeGroup(int $id_etude_group) Return the first ChildEtude filtered by the id_etude_group column
 * @method     ChildEtude|null findOneByGms(string $gms) Return the first ChildEtude filtered by the gms column
 * @method     ChildEtude|null findOneByKol(string $kol) Return the first ChildEtude filtered by the kol column
 * @method     ChildEtude|null findOneByRoomRental(boolean $room_rental) Return the first ChildEtude filtered by the room_rental column
 * @method     ChildEtude|null findOneByRecruitsOffsite(boolean $recruits_offsite) Return the first ChildEtude filtered by the recruits_offsite column
 * @method     ChildEtude|null findOneByStudySpecification(string $study_specification) Return the first ChildEtude filtered by the study_specification column
 * @method     ChildEtude|null findOneByisStudySpecification(boolean $is_study_specification) Return the first ChildEtude filtered by the is_study_specification column
 * @method     ChildEtude|null findOneByAdditionalNotes(string $additional_notes) Return the first ChildEtude filtered by the additional_notes column
 * @method     ChildEtude|null findOneByProjectComment(string $project_comment) Return the first ChildEtude filtered by the project_comment column
 * @method     ChildEtude|null findOneByEndClientId(int $end_client_id) Return the first ChildEtude filtered by the end_client_id column
 * @method     ChildEtude|null findOneByEndClientContactId(int $end_client_contact_id) Return the first ChildEtude filtered by the end_client_contact_id column
 * @method     ChildEtude|null findOneByContactId(int $contact_id) Return the first ChildEtude filtered by the contact_id column
 * @method     ChildEtude|null findOneByContactClientPmId(int $contact_client_pm_id) Return the first ChildEtude filtered by the contact_client_pm_id column
 * @method     ChildEtude|null findOneByMasterProjectNumber(string $master_project_number) Return the first ChildEtude filtered by the master_project_number column
 * @method     ChildEtude|null findOneByProposedLoi(double $proposed_loi) Return the first ChildEtude filtered by the proposed_loi column
 * @method     ChildEtude|null findOneByOpportunityId(int $opportunity_id) Return the first ChildEtude filtered by the opportunity_id column
 * @method     ChildEtude|null findOneBySiJobTypeId(int $si_job_type_id) Return the first ChildEtude filtered by the si_job_type_id column
 * @method     ChildEtude|null findOneByBestEffort(boolean $best_effort) Return the first ChildEtude filtered by the best_effort column
 * @method     ChildEtude|null findOneByJobStatusSfId(int $job_status_sf_id) Return the first ChildEtude filtered by the job_status_sf_id column
 * @method     ChildEtude|null findOneByBookedBySfId(string $booked_by_sf_id) Return the first ChildEtude filtered by the booked_by_sf_id column
 * @method     ChildEtude|null findOneByCreatedBySfId(string $created_by_sf_id) Return the first ChildEtude filtered by the created_by_sf_id column
 * @method     ChildEtude|null findOneByAccountManagerSfId(string $account_manager_sf_id) Return the first ChildEtude filtered by the account_manager_sf_id column
 * @method     ChildEtude|null findOneByCreatedDate(string $created_date) Return the first ChildEtude filtered by the created_date column
 * @method     ChildEtude|null findOneByJobQualificationId(int $job_qualification_id) Return the first ChildEtude filtered by the job_qualification_id column
 * @method     ChildEtude|null findOneByProposedN(double $proposed_n) Return the first ChildEtude filtered by the proposed_n column
 * @method     ChildEtude|null findOneByGermanJobTypeId(int $german_job_type_id) Return the first ChildEtude filtered by the german_job_type_id column
 * @method     ChildEtude|null findOneByCreatedByComment(string $created_by_comment) Return the first ChildEtude filtered by the created_by_comment column
 * @method     ChildEtude|null findOneByFocusVision(boolean $focus_vision) Return the first ChildEtude filtered by the focus_vision column
 * @method     ChildEtude|null findOneBySiEuJobType(int $si_eu_job_type) Return the first ChildEtude filtered by the si_eu_job_type column
 * @method     ChildEtude|null findOneByIntermediateClientId(int $intermediate_client_id) Return the first ChildEtude filtered by the intermediate_client_id column
 * @method     ChildEtude|null findOneByIntermediateClientContactId(int $intermediate_client_contact_id) Return the first ChildEtude filtered by the intermediate_client_contact_id column
 * @method     ChildEtude|null findOneByUsGlobalQualGmsId(int $us_global_qual_gms_id) Return the first ChildEtude filtered by the us_global_qual_gms_id column
 * @method     ChildEtude|null findOneByFaciltyNote(string $facilty_note) Return the first ChildEtude filtered by the facilty_note column
 * @method     ChildEtude|null findOneByCurrencyIsoCodeId(int $currency_iso_code_id) Return the first ChildEtude filtered by the currency_iso_code_id column
 * @method     ChildEtude|null findOneByClientListDeletionId(int $client_list_deletion_id) Return the first ChildEtude filtered by the client_list_deletion_id column
 * @method     ChildEtude|null findOneByCreatedById(int $created_by_id) Return the first ChildEtude filtered by the created_by_id column
 * @method     ChildEtude|null findOneByUpdatedById(int $updated_by_id) Return the first ChildEtude filtered by the updated_by_id column
 * @method     ChildEtude|null findOneByCreatedAt(string $created_at) Return the first ChildEtude filtered by the created_at column
 * @method     ChildEtude|null findOneByUpdatedAt(string $updated_at) Return the first ChildEtude filtered by the updated_at column *

 * @method     ChildEtude requirePk($key, ConnectionInterface $con = null) Return the ChildEtude by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOne(ConnectionInterface $con = null) Return the first ChildEtude matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtude requireOneById(int $id) Return the first ChildEtude filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByNumeroEtude(string $numero_etude) Return the first ChildEtude filtered by the numero_etude column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByReferenceClient(string $reference_client) Return the first ChildEtude filtered by the reference_client column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByMasterProjectSfId(string $master_project_sf_id) Return the first ChildEtude filtered by the master_project_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByTheme(string $theme) Return the first ChildEtude filtered by the theme column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDateDebut(string $date_debut) Return the first ChildEtude filtered by the date_debut column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDateFin(string $date_fin) Return the first ChildEtude filtered by the date_fin column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAnnee(string $annee) Return the first ChildEtude filtered by the annee column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRst(boolean $rst) Return the first ChildEtude filtered by the rst column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCli(boolean $cli) Return the first ChildEtude filtered by the cli column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByGqs(boolean $gqs) Return the first ChildEtude filtered by the gqs column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIns(boolean $ins) Return the first ChildEtude filtered by the ins column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByHut(boolean $hut) Return the first ChildEtude filtered by the hut column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDisplayTotalOnly(boolean $display_total_only) Return the first ChildEtude filtered by the display_total_only column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdPm(int $id_pm) Return the first ChildEtude filtered by the id_pm column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdEtape(int $id_etape) Return the first ChildEtude filtered by the id_etape column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPrixRevientInitial(string $prix_revient_initial) Return the first ChildEtude filtered by the prix_revient_initial column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPrixRevientActualise(string $prix_revient_actualise) Return the first ChildEtude filtered by the prix_revient_actualise column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPrixVenteInitial(string $prix_vente_initial) Return the first ChildEtude filtered by the prix_vente_initial column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPrixVenteActualise(string $prix_vente_actualise) Return the first ChildEtude filtered by the prix_vente_actualise column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByConsolidatedInvoice(boolean $consolidated_invoice) Return the first ChildEtude filtered by the consolidated_invoice column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySendCsatQuest(boolean $send_csat_quest) Return the first ChildEtude filtered by the send_csat_quest column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIsSendCsatQuestMail(boolean $is_send_csat_quest_mail) Return the first ChildEtude filtered by the is_send_csat_quest_mail column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByNumeroFacture(string $numero_facture) Return the first ChildEtude filtered by the numero_facture column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDontSetAmAuto(boolean $dont_set_am_auto) Return the first ChildEtude filtered by the dont_set_am_auto column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySetAmReason(string $set_am_reason) Return the first ChildEtude filtered by the set_am_reason column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAmReasonTypeId(int $am_reason_type_id) Return the first ChildEtude filtered by the am_reason_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDateEnvoiFacture(string $date_envoi_facture) Return the first ChildEtude filtered by the date_envoi_facture column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByDateReglement(string $date_reglement) Return the first ChildEtude filtered by the date_reglement column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCommentaire(string $commentaire) Return the first ChildEtude filtered by the commentaire column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIndustryId(int $industry_id) Return the first ChildEtude filtered by the industry_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPeriodeCutoff(string $periode_cutoff) Return the first ChildEtude filtered by the periode_cutoff column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByThemeBr(string $theme_br) Return the first ChildEtude filtered by the theme_br column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAreaId(int $area_id) Return the first ChildEtude filtered by the area_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdSamsStudy(string $id_sams_study) Return the first ChildEtude filtered by the id_sams_study column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRecrutementObjectif(int $recrutement_objectif) Return the first ChildEtude filtered by the recrutement_objectif column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdLocationPnl(int $id_location_pnl) Return the first ChildEtude filtered by the id_location_pnl column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdMasterProjectLocationPnl(int $id_master_project_location_pnl) Return the first ChildEtude filtered by the id_master_project_location_pnl column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRecrutementObjectifPr(int $recrutement_objectif_pr) Return the first ChildEtude filtered by the recrutement_objectif_pr column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdBm(int $id_bm) Return the first ChildEtude filtered by the id_bm column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByExtraInfo(string $extra_info) Return the first ChildEtude filtered by the extra_info column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAccountId(int $account_id) Return the first ChildEtude filtered by the account_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAccountManagerId(int $account_manager_id) Return the first ChildEtude filtered by the account_manager_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByProjectSpecialtySponsorId(int $project_specialty_sponsor_id) Return the first ChildEtude filtered by the project_specialty_sponsor_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByLanguage(string $language) Return the first ChildEtude filtered by the language column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRemiseTaux(string $remise_taux) Return the first ChildEtude filtered by the remise_taux column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByClientDiscountPercentage(string $client_discount_percentage) Return the first ChildEtude filtered by the client_discount_percentage column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByEndClientDiscountPercentage(string $end_client_discount_percentage) Return the first ChildEtude filtered by the end_client_discount_percentage column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByClientQuantDiscountPercentage(string $client_quant_discount_percentage) Return the first ChildEtude filtered by the client_quant_discount_percentage column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByEndClientQuantDiscountPercentage(string $end_client_quant_discount_percentage) Return the first ChildEtude filtered by the end_client_quant_discount_percentage column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySamplePlan(string $sample_plan) Return the first ChildEtude filtered by the sample_plan column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIsToInvoice(boolean $isToInvoice) Return the first ChildEtude filtered by the isToInvoice column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByFilePath(string $file_path) Return the first ChildEtude filtered by the file_path column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAccountLeaderId(int $account_leader_id) Return the first ChildEtude filtered by the account_leader_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAccountPMId(int $account_pm_id) Return the first ChildEtude filtered by the account_pm_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAmEmail(string $am_email) Return the first ChildEtude filtered by the am_email column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByClientPortalReady(boolean $client_portal_ready) Return the first ChildEtude filtered by the client_portal_ready column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByLengthOfInterview(string $length_of_interview) Return the first ChildEtude filtered by the length_of_interview column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBysunshineAct(string $sunshine_act) Return the first ChildEtude filtered by the sunshine_act column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIsConsolidated(boolean $is_consolidated) Return the first ChildEtude filtered by the is_consolidated column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySharepointFolder(string $sharepoint_folder) Return the first ChildEtude filtered by the sharepoint_folder column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByMultiPhase(boolean $multi_phase) Return the first ChildEtude filtered by the multi_phase column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByPoNumber(string $po_number) Return the first ChildEtude filtered by the po_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCurrencies(string $currencies) Return the first ChildEtude filtered by the currencies column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySmsRelance(boolean $sms_relance) Return the first ChildEtude filtered by the sms_relance column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIdEtudeGroup(int $id_etude_group) Return the first ChildEtude filtered by the id_etude_group column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByGms(string $gms) Return the first ChildEtude filtered by the gms column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByKol(string $kol) Return the first ChildEtude filtered by the kol column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRoomRental(boolean $room_rental) Return the first ChildEtude filtered by the room_rental column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByRecruitsOffsite(boolean $recruits_offsite) Return the first ChildEtude filtered by the recruits_offsite column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByStudySpecification(string $study_specification) Return the first ChildEtude filtered by the study_specification column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByisStudySpecification(boolean $is_study_specification) Return the first ChildEtude filtered by the is_study_specification column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAdditionalNotes(string $additional_notes) Return the first ChildEtude filtered by the additional_notes column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByProjectComment(string $project_comment) Return the first ChildEtude filtered by the project_comment column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByEndClientId(int $end_client_id) Return the first ChildEtude filtered by the end_client_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByEndClientContactId(int $end_client_contact_id) Return the first ChildEtude filtered by the end_client_contact_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByContactId(int $contact_id) Return the first ChildEtude filtered by the contact_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByContactClientPmId(int $contact_client_pm_id) Return the first ChildEtude filtered by the contact_client_pm_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByMasterProjectNumber(string $master_project_number) Return the first ChildEtude filtered by the master_project_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByProposedLoi(double $proposed_loi) Return the first ChildEtude filtered by the proposed_loi column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByOpportunityId(int $opportunity_id) Return the first ChildEtude filtered by the opportunity_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySiJobTypeId(int $si_job_type_id) Return the first ChildEtude filtered by the si_job_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByBestEffort(boolean $best_effort) Return the first ChildEtude filtered by the best_effort column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByJobStatusSfId(int $job_status_sf_id) Return the first ChildEtude filtered by the job_status_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByBookedBySfId(string $booked_by_sf_id) Return the first ChildEtude filtered by the booked_by_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCreatedBySfId(string $created_by_sf_id) Return the first ChildEtude filtered by the created_by_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByAccountManagerSfId(string $account_manager_sf_id) Return the first ChildEtude filtered by the account_manager_sf_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCreatedDate(string $created_date) Return the first ChildEtude filtered by the created_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByJobQualificationId(int $job_qualification_id) Return the first ChildEtude filtered by the job_qualification_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByProposedN(double $proposed_n) Return the first ChildEtude filtered by the proposed_n column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByGermanJobTypeId(int $german_job_type_id) Return the first ChildEtude filtered by the german_job_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCreatedByComment(string $created_by_comment) Return the first ChildEtude filtered by the created_by_comment column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByFocusVision(boolean $focus_vision) Return the first ChildEtude filtered by the focus_vision column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneBySiEuJobType(int $si_eu_job_type) Return the first ChildEtude filtered by the si_eu_job_type column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIntermediateClientId(int $intermediate_client_id) Return the first ChildEtude filtered by the intermediate_client_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByIntermediateClientContactId(int $intermediate_client_contact_id) Return the first ChildEtude filtered by the intermediate_client_contact_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByUsGlobalQualGmsId(int $us_global_qual_gms_id) Return the first ChildEtude filtered by the us_global_qual_gms_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByFaciltyNote(string $facilty_note) Return the first ChildEtude filtered by the facilty_note column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCurrencyIsoCodeId(int $currency_iso_code_id) Return the first ChildEtude filtered by the currency_iso_code_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByClientListDeletionId(int $client_list_deletion_id) Return the first ChildEtude filtered by the client_list_deletion_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCreatedById(int $created_by_id) Return the first ChildEtude filtered by the created_by_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByUpdatedById(int $updated_by_id) Return the first ChildEtude filtered by the updated_by_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByCreatedAt(string $created_at) Return the first ChildEtude filtered by the created_at column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtude requireOneByUpdatedAt(string $updated_at) Return the first ChildEtude filtered by the updated_at column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtude[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtude objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> find(ConnectionInterface $con = null) Return ChildEtude objects based on current ModelCriteria
 * @method     ChildEtude[]|ObjectCollection findById(int $id) Return ChildEtude objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findById(int $id) Return ChildEtude objects filtered by the id column
 * @method     ChildEtude[]|ObjectCollection findByNumeroEtude(string $numero_etude) Return ChildEtude objects filtered by the numero_etude column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByNumeroEtude(string $numero_etude) Return ChildEtude objects filtered by the numero_etude column
 * @method     ChildEtude[]|ObjectCollection findByReferenceClient(string $reference_client) Return ChildEtude objects filtered by the reference_client column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByReferenceClient(string $reference_client) Return ChildEtude objects filtered by the reference_client column
 * @method     ChildEtude[]|ObjectCollection findByMasterProjectSfId(string $master_project_sf_id) Return ChildEtude objects filtered by the master_project_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByMasterProjectSfId(string $master_project_sf_id) Return ChildEtude objects filtered by the master_project_sf_id column
 * @method     ChildEtude[]|ObjectCollection findByTheme(string $theme) Return ChildEtude objects filtered by the theme column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByTheme(string $theme) Return ChildEtude objects filtered by the theme column
 * @method     ChildEtude[]|ObjectCollection findByDateDebut(string $date_debut) Return ChildEtude objects filtered by the date_debut column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDateDebut(string $date_debut) Return ChildEtude objects filtered by the date_debut column
 * @method     ChildEtude[]|ObjectCollection findByDateFin(string $date_fin) Return ChildEtude objects filtered by the date_fin column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDateFin(string $date_fin) Return ChildEtude objects filtered by the date_fin column
 * @method     ChildEtude[]|ObjectCollection findByAnnee(string $annee) Return ChildEtude objects filtered by the annee column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAnnee(string $annee) Return ChildEtude objects filtered by the annee column
 * @method     ChildEtude[]|ObjectCollection findByRst(boolean $rst) Return ChildEtude objects filtered by the rst column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRst(boolean $rst) Return ChildEtude objects filtered by the rst column
 * @method     ChildEtude[]|ObjectCollection findByCli(boolean $cli) Return ChildEtude objects filtered by the cli column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCli(boolean $cli) Return ChildEtude objects filtered by the cli column
 * @method     ChildEtude[]|ObjectCollection findByGqs(boolean $gqs) Return ChildEtude objects filtered by the gqs column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByGqs(boolean $gqs) Return ChildEtude objects filtered by the gqs column
 * @method     ChildEtude[]|ObjectCollection findByIns(boolean $ins) Return ChildEtude objects filtered by the ins column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIns(boolean $ins) Return ChildEtude objects filtered by the ins column
 * @method     ChildEtude[]|ObjectCollection findByHut(boolean $hut) Return ChildEtude objects filtered by the hut column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByHut(boolean $hut) Return ChildEtude objects filtered by the hut column
 * @method     ChildEtude[]|ObjectCollection findByDisplayTotalOnly(boolean $display_total_only) Return ChildEtude objects filtered by the display_total_only column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDisplayTotalOnly(boolean $display_total_only) Return ChildEtude objects filtered by the display_total_only column
 * @method     ChildEtude[]|ObjectCollection findByIdPm(int $id_pm) Return ChildEtude objects filtered by the id_pm column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdPm(int $id_pm) Return ChildEtude objects filtered by the id_pm column
 * @method     ChildEtude[]|ObjectCollection findByIdEtape(int $id_etape) Return ChildEtude objects filtered by the id_etape column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdEtape(int $id_etape) Return ChildEtude objects filtered by the id_etape column
 * @method     ChildEtude[]|ObjectCollection findByPrixRevientInitial(string $prix_revient_initial) Return ChildEtude objects filtered by the prix_revient_initial column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPrixRevientInitial(string $prix_revient_initial) Return ChildEtude objects filtered by the prix_revient_initial column
 * @method     ChildEtude[]|ObjectCollection findByPrixRevientActualise(string $prix_revient_actualise) Return ChildEtude objects filtered by the prix_revient_actualise column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPrixRevientActualise(string $prix_revient_actualise) Return ChildEtude objects filtered by the prix_revient_actualise column
 * @method     ChildEtude[]|ObjectCollection findByPrixVenteInitial(string $prix_vente_initial) Return ChildEtude objects filtered by the prix_vente_initial column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPrixVenteInitial(string $prix_vente_initial) Return ChildEtude objects filtered by the prix_vente_initial column
 * @method     ChildEtude[]|ObjectCollection findByPrixVenteActualise(string $prix_vente_actualise) Return ChildEtude objects filtered by the prix_vente_actualise column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPrixVenteActualise(string $prix_vente_actualise) Return ChildEtude objects filtered by the prix_vente_actualise column
 * @method     ChildEtude[]|ObjectCollection findByConsolidatedInvoice(boolean $consolidated_invoice) Return ChildEtude objects filtered by the consolidated_invoice column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByConsolidatedInvoice(boolean $consolidated_invoice) Return ChildEtude objects filtered by the consolidated_invoice column
 * @method     ChildEtude[]|ObjectCollection findBySendCsatQuest(boolean $send_csat_quest) Return ChildEtude objects filtered by the send_csat_quest column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySendCsatQuest(boolean $send_csat_quest) Return ChildEtude objects filtered by the send_csat_quest column
 * @method     ChildEtude[]|ObjectCollection findByIsSendCsatQuestMail(boolean $is_send_csat_quest_mail) Return ChildEtude objects filtered by the is_send_csat_quest_mail column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIsSendCsatQuestMail(boolean $is_send_csat_quest_mail) Return ChildEtude objects filtered by the is_send_csat_quest_mail column
 * @method     ChildEtude[]|ObjectCollection findByNumeroFacture(string $numero_facture) Return ChildEtude objects filtered by the numero_facture column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByNumeroFacture(string $numero_facture) Return ChildEtude objects filtered by the numero_facture column
 * @method     ChildEtude[]|ObjectCollection findByDontSetAmAuto(boolean $dont_set_am_auto) Return ChildEtude objects filtered by the dont_set_am_auto column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDontSetAmAuto(boolean $dont_set_am_auto) Return ChildEtude objects filtered by the dont_set_am_auto column
 * @method     ChildEtude[]|ObjectCollection findBySetAmReason(string $set_am_reason) Return ChildEtude objects filtered by the set_am_reason column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySetAmReason(string $set_am_reason) Return ChildEtude objects filtered by the set_am_reason column
 * @method     ChildEtude[]|ObjectCollection findByAmReasonTypeId(int $am_reason_type_id) Return ChildEtude objects filtered by the am_reason_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAmReasonTypeId(int $am_reason_type_id) Return ChildEtude objects filtered by the am_reason_type_id column
 * @method     ChildEtude[]|ObjectCollection findByDateEnvoiFacture(string $date_envoi_facture) Return ChildEtude objects filtered by the date_envoi_facture column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDateEnvoiFacture(string $date_envoi_facture) Return ChildEtude objects filtered by the date_envoi_facture column
 * @method     ChildEtude[]|ObjectCollection findByDateReglement(string $date_reglement) Return ChildEtude objects filtered by the date_reglement column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByDateReglement(string $date_reglement) Return ChildEtude objects filtered by the date_reglement column
 * @method     ChildEtude[]|ObjectCollection findByCommentaire(string $commentaire) Return ChildEtude objects filtered by the commentaire column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCommentaire(string $commentaire) Return ChildEtude objects filtered by the commentaire column
 * @method     ChildEtude[]|ObjectCollection findByIndustryId(int $industry_id) Return ChildEtude objects filtered by the industry_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIndustryId(int $industry_id) Return ChildEtude objects filtered by the industry_id column
 * @method     ChildEtude[]|ObjectCollection findByPeriodeCutoff(string $periode_cutoff) Return ChildEtude objects filtered by the periode_cutoff column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPeriodeCutoff(string $periode_cutoff) Return ChildEtude objects filtered by the periode_cutoff column
 * @method     ChildEtude[]|ObjectCollection findByThemeBr(string $theme_br) Return ChildEtude objects filtered by the theme_br column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByThemeBr(string $theme_br) Return ChildEtude objects filtered by the theme_br column
 * @method     ChildEtude[]|ObjectCollection findByAreaId(int $area_id) Return ChildEtude objects filtered by the area_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAreaId(int $area_id) Return ChildEtude objects filtered by the area_id column
 * @method     ChildEtude[]|ObjectCollection findByIdSamsStudy(string $id_sams_study) Return ChildEtude objects filtered by the id_sams_study column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdSamsStudy(string $id_sams_study) Return ChildEtude objects filtered by the id_sams_study column
 * @method     ChildEtude[]|ObjectCollection findByRecrutementObjectif(int $recrutement_objectif) Return ChildEtude objects filtered by the recrutement_objectif column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRecrutementObjectif(int $recrutement_objectif) Return ChildEtude objects filtered by the recrutement_objectif column
 * @method     ChildEtude[]|ObjectCollection findByIdLocationPnl(int $id_location_pnl) Return ChildEtude objects filtered by the id_location_pnl column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdLocationPnl(int $id_location_pnl) Return ChildEtude objects filtered by the id_location_pnl column
 * @method     ChildEtude[]|ObjectCollection findByIdMasterProjectLocationPnl(int $id_master_project_location_pnl) Return ChildEtude objects filtered by the id_master_project_location_pnl column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdMasterProjectLocationPnl(int $id_master_project_location_pnl) Return ChildEtude objects filtered by the id_master_project_location_pnl column
 * @method     ChildEtude[]|ObjectCollection findByRecrutementObjectifPr(int $recrutement_objectif_pr) Return ChildEtude objects filtered by the recrutement_objectif_pr column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRecrutementObjectifPr(int $recrutement_objectif_pr) Return ChildEtude objects filtered by the recrutement_objectif_pr column
 * @method     ChildEtude[]|ObjectCollection findByIdBm(int $id_bm) Return ChildEtude objects filtered by the id_bm column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdBm(int $id_bm) Return ChildEtude objects filtered by the id_bm column
 * @method     ChildEtude[]|ObjectCollection findByExtraInfo(string $extra_info) Return ChildEtude objects filtered by the extra_info column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByExtraInfo(string $extra_info) Return ChildEtude objects filtered by the extra_info column
 * @method     ChildEtude[]|ObjectCollection findByAccountId(int $account_id) Return ChildEtude objects filtered by the account_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAccountId(int $account_id) Return ChildEtude objects filtered by the account_id column
 * @method     ChildEtude[]|ObjectCollection findByAccountManagerId(int $account_manager_id) Return ChildEtude objects filtered by the account_manager_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAccountManagerId(int $account_manager_id) Return ChildEtude objects filtered by the account_manager_id column
 * @method     ChildEtude[]|ObjectCollection findByProjectSpecialtySponsorId(int $project_specialty_sponsor_id) Return ChildEtude objects filtered by the project_specialty_sponsor_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByProjectSpecialtySponsorId(int $project_specialty_sponsor_id) Return ChildEtude objects filtered by the project_specialty_sponsor_id column
 * @method     ChildEtude[]|ObjectCollection findByLanguage(string $language) Return ChildEtude objects filtered by the language column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByLanguage(string $language) Return ChildEtude objects filtered by the language column
 * @method     ChildEtude[]|ObjectCollection findByRemiseTaux(string $remise_taux) Return ChildEtude objects filtered by the remise_taux column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRemiseTaux(string $remise_taux) Return ChildEtude objects filtered by the remise_taux column
 * @method     ChildEtude[]|ObjectCollection findByClientDiscountPercentage(string $client_discount_percentage) Return ChildEtude objects filtered by the client_discount_percentage column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByClientDiscountPercentage(string $client_discount_percentage) Return ChildEtude objects filtered by the client_discount_percentage column
 * @method     ChildEtude[]|ObjectCollection findByEndClientDiscountPercentage(string $end_client_discount_percentage) Return ChildEtude objects filtered by the end_client_discount_percentage column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByEndClientDiscountPercentage(string $end_client_discount_percentage) Return ChildEtude objects filtered by the end_client_discount_percentage column
 * @method     ChildEtude[]|ObjectCollection findByClientQuantDiscountPercentage(string $client_quant_discount_percentage) Return ChildEtude objects filtered by the client_quant_discount_percentage column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByClientQuantDiscountPercentage(string $client_quant_discount_percentage) Return ChildEtude objects filtered by the client_quant_discount_percentage column
 * @method     ChildEtude[]|ObjectCollection findByEndClientQuantDiscountPercentage(string $end_client_quant_discount_percentage) Return ChildEtude objects filtered by the end_client_quant_discount_percentage column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByEndClientQuantDiscountPercentage(string $end_client_quant_discount_percentage) Return ChildEtude objects filtered by the end_client_quant_discount_percentage column
 * @method     ChildEtude[]|ObjectCollection findBySamplePlan(string $sample_plan) Return ChildEtude objects filtered by the sample_plan column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySamplePlan(string $sample_plan) Return ChildEtude objects filtered by the sample_plan column
 * @method     ChildEtude[]|ObjectCollection findByIsToInvoice(boolean $isToInvoice) Return ChildEtude objects filtered by the isToInvoice column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIsToInvoice(boolean $isToInvoice) Return ChildEtude objects filtered by the isToInvoice column
 * @method     ChildEtude[]|ObjectCollection findByFilePath(string $file_path) Return ChildEtude objects filtered by the file_path column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByFilePath(string $file_path) Return ChildEtude objects filtered by the file_path column
 * @method     ChildEtude[]|ObjectCollection findByAccountLeaderId(int $account_leader_id) Return ChildEtude objects filtered by the account_leader_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAccountLeaderId(int $account_leader_id) Return ChildEtude objects filtered by the account_leader_id column
 * @method     ChildEtude[]|ObjectCollection findByAccountPMId(int $account_pm_id) Return ChildEtude objects filtered by the account_pm_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAccountPMId(int $account_pm_id) Return ChildEtude objects filtered by the account_pm_id column
 * @method     ChildEtude[]|ObjectCollection findByAmEmail(string $am_email) Return ChildEtude objects filtered by the am_email column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAmEmail(string $am_email) Return ChildEtude objects filtered by the am_email column
 * @method     ChildEtude[]|ObjectCollection findByClientPortalReady(boolean $client_portal_ready) Return ChildEtude objects filtered by the client_portal_ready column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByClientPortalReady(boolean $client_portal_ready) Return ChildEtude objects filtered by the client_portal_ready column
 * @method     ChildEtude[]|ObjectCollection findByLengthOfInterview(string $length_of_interview) Return ChildEtude objects filtered by the length_of_interview column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByLengthOfInterview(string $length_of_interview) Return ChildEtude objects filtered by the length_of_interview column
 * @method     ChildEtude[]|ObjectCollection findBysunshineAct(string $sunshine_act) Return ChildEtude objects filtered by the sunshine_act column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBysunshineAct(string $sunshine_act) Return ChildEtude objects filtered by the sunshine_act column
 * @method     ChildEtude[]|ObjectCollection findByIsConsolidated(boolean $is_consolidated) Return ChildEtude objects filtered by the is_consolidated column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIsConsolidated(boolean $is_consolidated) Return ChildEtude objects filtered by the is_consolidated column
 * @method     ChildEtude[]|ObjectCollection findBySharepointFolder(string $sharepoint_folder) Return ChildEtude objects filtered by the sharepoint_folder column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySharepointFolder(string $sharepoint_folder) Return ChildEtude objects filtered by the sharepoint_folder column
 * @method     ChildEtude[]|ObjectCollection findByMultiPhase(boolean $multi_phase) Return ChildEtude objects filtered by the multi_phase column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByMultiPhase(boolean $multi_phase) Return ChildEtude objects filtered by the multi_phase column
 * @method     ChildEtude[]|ObjectCollection findByPoNumber(string $po_number) Return ChildEtude objects filtered by the po_number column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByPoNumber(string $po_number) Return ChildEtude objects filtered by the po_number column
 * @method     ChildEtude[]|ObjectCollection findByCurrencies(string $currencies) Return ChildEtude objects filtered by the currencies column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCurrencies(string $currencies) Return ChildEtude objects filtered by the currencies column
 * @method     ChildEtude[]|ObjectCollection findBySmsRelance(boolean $sms_relance) Return ChildEtude objects filtered by the sms_relance column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySmsRelance(boolean $sms_relance) Return ChildEtude objects filtered by the sms_relance column
 * @method     ChildEtude[]|ObjectCollection findByIdEtudeGroup(int $id_etude_group) Return ChildEtude objects filtered by the id_etude_group column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIdEtudeGroup(int $id_etude_group) Return ChildEtude objects filtered by the id_etude_group column
 * @method     ChildEtude[]|ObjectCollection findByGms(string $gms) Return ChildEtude objects filtered by the gms column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByGms(string $gms) Return ChildEtude objects filtered by the gms column
 * @method     ChildEtude[]|ObjectCollection findByKol(string $kol) Return ChildEtude objects filtered by the kol column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByKol(string $kol) Return ChildEtude objects filtered by the kol column
 * @method     ChildEtude[]|ObjectCollection findByRoomRental(boolean $room_rental) Return ChildEtude objects filtered by the room_rental column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRoomRental(boolean $room_rental) Return ChildEtude objects filtered by the room_rental column
 * @method     ChildEtude[]|ObjectCollection findByRecruitsOffsite(boolean $recruits_offsite) Return ChildEtude objects filtered by the recruits_offsite column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByRecruitsOffsite(boolean $recruits_offsite) Return ChildEtude objects filtered by the recruits_offsite column
 * @method     ChildEtude[]|ObjectCollection findByStudySpecification(string $study_specification) Return ChildEtude objects filtered by the study_specification column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByStudySpecification(string $study_specification) Return ChildEtude objects filtered by the study_specification column
 * @method     ChildEtude[]|ObjectCollection findByisStudySpecification(boolean $is_study_specification) Return ChildEtude objects filtered by the is_study_specification column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByisStudySpecification(boolean $is_study_specification) Return ChildEtude objects filtered by the is_study_specification column
 * @method     ChildEtude[]|ObjectCollection findByAdditionalNotes(string $additional_notes) Return ChildEtude objects filtered by the additional_notes column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAdditionalNotes(string $additional_notes) Return ChildEtude objects filtered by the additional_notes column
 * @method     ChildEtude[]|ObjectCollection findByProjectComment(string $project_comment) Return ChildEtude objects filtered by the project_comment column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByProjectComment(string $project_comment) Return ChildEtude objects filtered by the project_comment column
 * @method     ChildEtude[]|ObjectCollection findByEndClientId(int $end_client_id) Return ChildEtude objects filtered by the end_client_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByEndClientId(int $end_client_id) Return ChildEtude objects filtered by the end_client_id column
 * @method     ChildEtude[]|ObjectCollection findByEndClientContactId(int $end_client_contact_id) Return ChildEtude objects filtered by the end_client_contact_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByEndClientContactId(int $end_client_contact_id) Return ChildEtude objects filtered by the end_client_contact_id column
 * @method     ChildEtude[]|ObjectCollection findByContactId(int $contact_id) Return ChildEtude objects filtered by the contact_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByContactId(int $contact_id) Return ChildEtude objects filtered by the contact_id column
 * @method     ChildEtude[]|ObjectCollection findByContactClientPmId(int $contact_client_pm_id) Return ChildEtude objects filtered by the contact_client_pm_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByContactClientPmId(int $contact_client_pm_id) Return ChildEtude objects filtered by the contact_client_pm_id column
 * @method     ChildEtude[]|ObjectCollection findByMasterProjectNumber(string $master_project_number) Return ChildEtude objects filtered by the master_project_number column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByMasterProjectNumber(string $master_project_number) Return ChildEtude objects filtered by the master_project_number column
 * @method     ChildEtude[]|ObjectCollection findByProposedLoi(double $proposed_loi) Return ChildEtude objects filtered by the proposed_loi column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByProposedLoi(double $proposed_loi) Return ChildEtude objects filtered by the proposed_loi column
 * @method     ChildEtude[]|ObjectCollection findByOpportunityId(int $opportunity_id) Return ChildEtude objects filtered by the opportunity_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByOpportunityId(int $opportunity_id) Return ChildEtude objects filtered by the opportunity_id column
 * @method     ChildEtude[]|ObjectCollection findBySiJobTypeId(int $si_job_type_id) Return ChildEtude objects filtered by the si_job_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySiJobTypeId(int $si_job_type_id) Return ChildEtude objects filtered by the si_job_type_id column
 * @method     ChildEtude[]|ObjectCollection findByBestEffort(boolean $best_effort) Return ChildEtude objects filtered by the best_effort column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByBestEffort(boolean $best_effort) Return ChildEtude objects filtered by the best_effort column
 * @method     ChildEtude[]|ObjectCollection findByJobStatusSfId(int $job_status_sf_id) Return ChildEtude objects filtered by the job_status_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByJobStatusSfId(int $job_status_sf_id) Return ChildEtude objects filtered by the job_status_sf_id column
 * @method     ChildEtude[]|ObjectCollection findByBookedBySfId(string $booked_by_sf_id) Return ChildEtude objects filtered by the booked_by_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByBookedBySfId(string $booked_by_sf_id) Return ChildEtude objects filtered by the booked_by_sf_id column
 * @method     ChildEtude[]|ObjectCollection findByCreatedBySfId(string $created_by_sf_id) Return ChildEtude objects filtered by the created_by_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCreatedBySfId(string $created_by_sf_id) Return ChildEtude objects filtered by the created_by_sf_id column
 * @method     ChildEtude[]|ObjectCollection findByAccountManagerSfId(string $account_manager_sf_id) Return ChildEtude objects filtered by the account_manager_sf_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByAccountManagerSfId(string $account_manager_sf_id) Return ChildEtude objects filtered by the account_manager_sf_id column
 * @method     ChildEtude[]|ObjectCollection findByCreatedDate(string $created_date) Return ChildEtude objects filtered by the created_date column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCreatedDate(string $created_date) Return ChildEtude objects filtered by the created_date column
 * @method     ChildEtude[]|ObjectCollection findByJobQualificationId(int $job_qualification_id) Return ChildEtude objects filtered by the job_qualification_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByJobQualificationId(int $job_qualification_id) Return ChildEtude objects filtered by the job_qualification_id column
 * @method     ChildEtude[]|ObjectCollection findByProposedN(double $proposed_n) Return ChildEtude objects filtered by the proposed_n column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByProposedN(double $proposed_n) Return ChildEtude objects filtered by the proposed_n column
 * @method     ChildEtude[]|ObjectCollection findByGermanJobTypeId(int $german_job_type_id) Return ChildEtude objects filtered by the german_job_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByGermanJobTypeId(int $german_job_type_id) Return ChildEtude objects filtered by the german_job_type_id column
 * @method     ChildEtude[]|ObjectCollection findByCreatedByComment(string $created_by_comment) Return ChildEtude objects filtered by the created_by_comment column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCreatedByComment(string $created_by_comment) Return ChildEtude objects filtered by the created_by_comment column
 * @method     ChildEtude[]|ObjectCollection findByFocusVision(boolean $focus_vision) Return ChildEtude objects filtered by the focus_vision column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByFocusVision(boolean $focus_vision) Return ChildEtude objects filtered by the focus_vision column
 * @method     ChildEtude[]|ObjectCollection findBySiEuJobType(int $si_eu_job_type) Return ChildEtude objects filtered by the si_eu_job_type column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findBySiEuJobType(int $si_eu_job_type) Return ChildEtude objects filtered by the si_eu_job_type column
 * @method     ChildEtude[]|ObjectCollection findByIntermediateClientId(int $intermediate_client_id) Return ChildEtude objects filtered by the intermediate_client_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIntermediateClientId(int $intermediate_client_id) Return ChildEtude objects filtered by the intermediate_client_id column
 * @method     ChildEtude[]|ObjectCollection findByIntermediateClientContactId(int $intermediate_client_contact_id) Return ChildEtude objects filtered by the intermediate_client_contact_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByIntermediateClientContactId(int $intermediate_client_contact_id) Return ChildEtude objects filtered by the intermediate_client_contact_id column
 * @method     ChildEtude[]|ObjectCollection findByUsGlobalQualGmsId(int $us_global_qual_gms_id) Return ChildEtude objects filtered by the us_global_qual_gms_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByUsGlobalQualGmsId(int $us_global_qual_gms_id) Return ChildEtude objects filtered by the us_global_qual_gms_id column
 * @method     ChildEtude[]|ObjectCollection findByFaciltyNote(string $facilty_note) Return ChildEtude objects filtered by the facilty_note column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByFaciltyNote(string $facilty_note) Return ChildEtude objects filtered by the facilty_note column
 * @method     ChildEtude[]|ObjectCollection findByCurrencyIsoCodeId(int $currency_iso_code_id) Return ChildEtude objects filtered by the currency_iso_code_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCurrencyIsoCodeId(int $currency_iso_code_id) Return ChildEtude objects filtered by the currency_iso_code_id column
 * @method     ChildEtude[]|ObjectCollection findByClientListDeletionId(int $client_list_deletion_id) Return ChildEtude objects filtered by the client_list_deletion_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByClientListDeletionId(int $client_list_deletion_id) Return ChildEtude objects filtered by the client_list_deletion_id column
 * @method     ChildEtude[]|ObjectCollection findByCreatedById(int $created_by_id) Return ChildEtude objects filtered by the created_by_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCreatedById(int $created_by_id) Return ChildEtude objects filtered by the created_by_id column
 * @method     ChildEtude[]|ObjectCollection findByUpdatedById(int $updated_by_id) Return ChildEtude objects filtered by the updated_by_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByUpdatedById(int $updated_by_id) Return ChildEtude objects filtered by the updated_by_id column
 * @method     ChildEtude[]|ObjectCollection findByCreatedAt(string $created_at) Return ChildEtude objects filtered by the created_at column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByCreatedAt(string $created_at) Return ChildEtude objects filtered by the created_at column
 * @method     ChildEtude[]|ObjectCollection findByUpdatedAt(string $updated_at) Return ChildEtude objects filtered by the updated_at column
 * @psalm-method ObjectCollection&\Traversable<ChildEtude> findByUpdatedAt(string $updated_at) Return ChildEtude objects filtered by the updated_at column
 * @method     ChildEtude[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtude> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtudeQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtudeQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\Etude', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtudeQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtudeQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtudeQuery) {
            return $criteria;
        }
        $query = new ChildEtudeQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtude|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtudeTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtude A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `numero_etude`, `reference_client`, `master_project_sf_id`, `theme`, `date_debut`, `date_fin`, `annee`, `rst`, `cli`, `gqs`, `ins`, `hut`, `display_total_only`, `id_pm`, `id_etape`, `prix_revient_initial`, `prix_revient_actualise`, `prix_vente_initial`, `prix_vente_actualise`, `consolidated_invoice`, `send_csat_quest`, `is_send_csat_quest_mail`, `numero_facture`, `dont_set_am_auto`, `set_am_reason`, `am_reason_type_id`, `date_envoi_facture`, `date_reglement`, `commentaire`, `industry_id`, `periode_cutoff`, `theme_br`, `area_id`, `id_sams_study`, `recrutement_objectif`, `id_location_pnl`, `id_master_project_location_pnl`, `recrutement_objectif_pr`, `id_bm`, `extra_info`, `account_id`, `account_manager_id`, `project_specialty_sponsor_id`, `language`, `remise_taux`, `client_discount_percentage`, `end_client_discount_percentage`, `client_quant_discount_percentage`, `end_client_quant_discount_percentage`, `sample_plan`, `isToInvoice`, `file_path`, `account_leader_id`, `account_pm_id`, `am_email`, `client_portal_ready`, `length_of_interview`, `sunshine_act`, `is_consolidated`, `sharepoint_folder`, `multi_phase`, `po_number`, `currencies`, `sms_relance`, `id_etude_group`, `gms`, `kol`, `room_rental`, `recruits_offsite`, `study_specification`, `is_study_specification`, `additional_notes`, `project_comment`, `end_client_id`, `end_client_contact_id`, `contact_id`, `contact_client_pm_id`, `master_project_number`, `proposed_loi`, `opportunity_id`, `si_job_type_id`, `best_effort`, `job_status_sf_id`, `booked_by_sf_id`, `created_by_sf_id`, `account_manager_sf_id`, `created_date`, `job_qualification_id`, `proposed_n`, `german_job_type_id`, `created_by_comment`, `focus_vision`, `si_eu_job_type`, `intermediate_client_id`, `intermediate_client_contact_id`, `us_global_qual_gms_id`, `facilty_note`, `currency_iso_code_id`, `client_list_deletion_id`, `created_by_id`, `updated_by_id`, `created_at`, `updated_at` FROM `etude` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtude $obj */
            $obj = new ChildEtude();
            $obj->hydrate($row);
            EtudeTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtude|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EtudeTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EtudeTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the numero_etude column
     *
     * Example usage:
     * <code>
     * $query->filterByNumeroEtude('fooValue');   // WHERE numero_etude = 'fooValue'
     * $query->filterByNumeroEtude('%fooValue%', Criteria::LIKE); // WHERE numero_etude LIKE '%fooValue%'
     * $query->filterByNumeroEtude(['foo', 'bar']); // WHERE numero_etude IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $numeroEtude The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByNumeroEtude($numeroEtude = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($numeroEtude)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_NUMERO_ETUDE, $numeroEtude, $comparison);
    }

    /**
     * Filter the query on the reference_client column
     *
     * Example usage:
     * <code>
     * $query->filterByReferenceClient('fooValue');   // WHERE reference_client = 'fooValue'
     * $query->filterByReferenceClient('%fooValue%', Criteria::LIKE); // WHERE reference_client LIKE '%fooValue%'
     * $query->filterByReferenceClient(['foo', 'bar']); // WHERE reference_client IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $referenceClient The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByReferenceClient($referenceClient = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referenceClient)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_REFERENCE_CLIENT, $referenceClient, $comparison);
    }

    /**
     * Filter the query on the master_project_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByMasterProjectSfId('fooValue');   // WHERE master_project_sf_id = 'fooValue'
     * $query->filterByMasterProjectSfId('%fooValue%', Criteria::LIKE); // WHERE master_project_sf_id LIKE '%fooValue%'
     * $query->filterByMasterProjectSfId(['foo', 'bar']); // WHERE master_project_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $masterProjectSfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByMasterProjectSfId($masterProjectSfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($masterProjectSfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_MASTER_PROJECT_SF_ID, $masterProjectSfId, $comparison);
    }

    /**
     * Filter the query on the theme column
     *
     * Example usage:
     * <code>
     * $query->filterByTheme('fooValue');   // WHERE theme = 'fooValue'
     * $query->filterByTheme('%fooValue%', Criteria::LIKE); // WHERE theme LIKE '%fooValue%'
     * $query->filterByTheme(['foo', 'bar']); // WHERE theme IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $theme The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByTheme($theme = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($theme)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_THEME, $theme, $comparison);
    }

    /**
     * Filter the query on the date_debut column
     *
     * Example usage:
     * <code>
     * $query->filterByDateDebut('2011-03-14'); // WHERE date_debut = '2011-03-14'
     * $query->filterByDateDebut('now'); // WHERE date_debut = '2011-03-14'
     * $query->filterByDateDebut(array('max' => 'yesterday')); // WHERE date_debut > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateDebut The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDateDebut($dateDebut = null, $comparison = null)
    {
        if (is_array($dateDebut)) {
            $useMinMax = false;
            if (isset($dateDebut['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_DEBUT, $dateDebut['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateDebut['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_DEBUT, $dateDebut['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DATE_DEBUT, $dateDebut, $comparison);
    }

    /**
     * Filter the query on the date_fin column
     *
     * Example usage:
     * <code>
     * $query->filterByDateFin('2011-03-14'); // WHERE date_fin = '2011-03-14'
     * $query->filterByDateFin('now'); // WHERE date_fin = '2011-03-14'
     * $query->filterByDateFin(array('max' => 'yesterday')); // WHERE date_fin > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateFin The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDateFin($dateFin = null, $comparison = null)
    {
        if (is_array($dateFin)) {
            $useMinMax = false;
            if (isset($dateFin['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_FIN, $dateFin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateFin['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_FIN, $dateFin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DATE_FIN, $dateFin, $comparison);
    }

    /**
     * Filter the query on the annee column
     *
     * Example usage:
     * <code>
     * $query->filterByAnnee('fooValue');   // WHERE annee = 'fooValue'
     * $query->filterByAnnee('%fooValue%', Criteria::LIKE); // WHERE annee LIKE '%fooValue%'
     * $query->filterByAnnee(['foo', 'bar']); // WHERE annee IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $annee The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAnnee($annee = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($annee)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ANNEE, $annee, $comparison);
    }

    /**
     * Filter the query on the rst column
     *
     * Example usage:
     * <code>
     * $query->filterByRst(true); // WHERE rst = true
     * $query->filterByRst('yes'); // WHERE rst = true
     * </code>
     *
     * @param     boolean|string $rst The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRst($rst = null, $comparison = null)
    {
        if (is_string($rst)) {
            $rst = in_array(strtolower($rst), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_RST, $rst, $comparison);
    }

    /**
     * Filter the query on the cli column
     *
     * Example usage:
     * <code>
     * $query->filterByCli(true); // WHERE cli = true
     * $query->filterByCli('yes'); // WHERE cli = true
     * </code>
     *
     * @param     boolean|string $cli The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCli($cli = null, $comparison = null)
    {
        if (is_string($cli)) {
            $cli = in_array(strtolower($cli), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CLI, $cli, $comparison);
    }

    /**
     * Filter the query on the gqs column
     *
     * Example usage:
     * <code>
     * $query->filterByGqs(true); // WHERE gqs = true
     * $query->filterByGqs('yes'); // WHERE gqs = true
     * </code>
     *
     * @param     boolean|string $gqs The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByGqs($gqs = null, $comparison = null)
    {
        if (is_string($gqs)) {
            $gqs = in_array(strtolower($gqs), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_GQS, $gqs, $comparison);
    }

    /**
     * Filter the query on the ins column
     *
     * Example usage:
     * <code>
     * $query->filterByIns(true); // WHERE ins = true
     * $query->filterByIns('yes'); // WHERE ins = true
     * </code>
     *
     * @param     boolean|string $ins The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIns($ins = null, $comparison = null)
    {
        if (is_string($ins)) {
            $ins = in_array(strtolower($ins), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_INS, $ins, $comparison);
    }

    /**
     * Filter the query on the hut column
     *
     * Example usage:
     * <code>
     * $query->filterByHut(true); // WHERE hut = true
     * $query->filterByHut('yes'); // WHERE hut = true
     * </code>
     *
     * @param     boolean|string $hut The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByHut($hut = null, $comparison = null)
    {
        if (is_string($hut)) {
            $hut = in_array(strtolower($hut), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_HUT, $hut, $comparison);
    }

    /**
     * Filter the query on the display_total_only column
     *
     * Example usage:
     * <code>
     * $query->filterByDisplayTotalOnly(true); // WHERE display_total_only = true
     * $query->filterByDisplayTotalOnly('yes'); // WHERE display_total_only = true
     * </code>
     *
     * @param     boolean|string $displayTotalOnly The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDisplayTotalOnly($displayTotalOnly = null, $comparison = null)
    {
        if (is_string($displayTotalOnly)) {
            $displayTotalOnly = in_array(strtolower($displayTotalOnly), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY, $displayTotalOnly, $comparison);
    }

    /**
     * Filter the query on the id_pm column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPm(1234); // WHERE id_pm = 1234
     * $query->filterByIdPm(array(12, 34)); // WHERE id_pm IN (12, 34)
     * $query->filterByIdPm(array('min' => 12)); // WHERE id_pm > 12
     * </code>
     *
     * @see       filterByEtudeProjectManager()
     *
     * @param     mixed $idPm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdPm($idPm = null, $comparison = null)
    {
        if (is_array($idPm)) {
            $useMinMax = false;
            if (isset($idPm['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_PM, $idPm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPm['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_PM, $idPm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_PM, $idPm, $comparison);
    }

    /**
     * Filter the query on the id_etape column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtape(1234); // WHERE id_etape = 1234
     * $query->filterByIdEtape(array(12, 34)); // WHERE id_etape IN (12, 34)
     * $query->filterByIdEtape(array('min' => 12)); // WHERE id_etape > 12
     * </code>
     *
     * @see       filterByEtape()
     *
     * @param     mixed $idEtape The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdEtape($idEtape = null, $comparison = null)
    {
        if (is_array($idEtape)) {
            $useMinMax = false;
            if (isset($idEtape['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_ETAPE, $idEtape['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtape['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_ETAPE, $idEtape['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_ETAPE, $idEtape, $comparison);
    }

    /**
     * Filter the query on the prix_revient_initial column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixRevientInitial(1234); // WHERE prix_revient_initial = 1234
     * $query->filterByPrixRevientInitial(array(12, 34)); // WHERE prix_revient_initial IN (12, 34)
     * $query->filterByPrixRevientInitial(array('min' => 12)); // WHERE prix_revient_initial > 12
     * </code>
     *
     * @param     mixed $prixRevientInitial The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrixRevientInitial($prixRevientInitial = null, $comparison = null)
    {
        if (is_array($prixRevientInitial)) {
            $useMinMax = false;
            if (isset($prixRevientInitial['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixRevientInitial['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial, $comparison);
    }

    /**
     * Filter the query on the prix_revient_actualise column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixRevientActualise(1234); // WHERE prix_revient_actualise = 1234
     * $query->filterByPrixRevientActualise(array(12, 34)); // WHERE prix_revient_actualise IN (12, 34)
     * $query->filterByPrixRevientActualise(array('min' => 12)); // WHERE prix_revient_actualise > 12
     * </code>
     *
     * @param     mixed $prixRevientActualise The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrixRevientActualise($prixRevientActualise = null, $comparison = null)
    {
        if (is_array($prixRevientActualise)) {
            $useMinMax = false;
            if (isset($prixRevientActualise['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixRevientActualise['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise, $comparison);
    }

    /**
     * Filter the query on the prix_vente_initial column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixVenteInitial(1234); // WHERE prix_vente_initial = 1234
     * $query->filterByPrixVenteInitial(array(12, 34)); // WHERE prix_vente_initial IN (12, 34)
     * $query->filterByPrixVenteInitial(array('min' => 12)); // WHERE prix_vente_initial > 12
     * </code>
     *
     * @param     mixed $prixVenteInitial The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrixVenteInitial($prixVenteInitial = null, $comparison = null)
    {
        if (is_array($prixVenteInitial)) {
            $useMinMax = false;
            if (isset($prixVenteInitial['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixVenteInitial['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial, $comparison);
    }

    /**
     * Filter the query on the prix_vente_actualise column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixVenteActualise(1234); // WHERE prix_vente_actualise = 1234
     * $query->filterByPrixVenteActualise(array(12, 34)); // WHERE prix_vente_actualise IN (12, 34)
     * $query->filterByPrixVenteActualise(array('min' => 12)); // WHERE prix_vente_actualise > 12
     * </code>
     *
     * @param     mixed $prixVenteActualise The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPrixVenteActualise($prixVenteActualise = null, $comparison = null)
    {
        if (is_array($prixVenteActualise)) {
            $useMinMax = false;
            if (isset($prixVenteActualise['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixVenteActualise['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise, $comparison);
    }

    /**
     * Filter the query on the consolidated_invoice column
     *
     * Example usage:
     * <code>
     * $query->filterByConsolidatedInvoice(true); // WHERE consolidated_invoice = true
     * $query->filterByConsolidatedInvoice('yes'); // WHERE consolidated_invoice = true
     * </code>
     *
     * @param     boolean|string $consolidatedInvoice The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByConsolidatedInvoice($consolidatedInvoice = null, $comparison = null)
    {
        if (is_string($consolidatedInvoice)) {
            $consolidatedInvoice = in_array(strtolower($consolidatedInvoice), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CONSOLIDATED_INVOICE, $consolidatedInvoice, $comparison);
    }

    /**
     * Filter the query on the send_csat_quest column
     *
     * Example usage:
     * <code>
     * $query->filterBySendCsatQuest(true); // WHERE send_csat_quest = true
     * $query->filterBySendCsatQuest('yes'); // WHERE send_csat_quest = true
     * </code>
     *
     * @param     boolean|string $sendCsatQuest The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySendCsatQuest($sendCsatQuest = null, $comparison = null)
    {
        if (is_string($sendCsatQuest)) {
            $sendCsatQuest = in_array(strtolower($sendCsatQuest), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SEND_CSAT_QUEST, $sendCsatQuest, $comparison);
    }

    /**
     * Filter the query on the is_send_csat_quest_mail column
     *
     * Example usage:
     * <code>
     * $query->filterByIsSendCsatQuestMail(true); // WHERE is_send_csat_quest_mail = true
     * $query->filterByIsSendCsatQuestMail('yes'); // WHERE is_send_csat_quest_mail = true
     * </code>
     *
     * @param     boolean|string $isSendCsatQuestMail The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIsSendCsatQuestMail($isSendCsatQuestMail = null, $comparison = null)
    {
        if (is_string($isSendCsatQuestMail)) {
            $isSendCsatQuestMail = in_array(strtolower($isSendCsatQuestMail), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL, $isSendCsatQuestMail, $comparison);
    }

    /**
     * Filter the query on the numero_facture column
     *
     * Example usage:
     * <code>
     * $query->filterByNumeroFacture('fooValue');   // WHERE numero_facture = 'fooValue'
     * $query->filterByNumeroFacture('%fooValue%', Criteria::LIKE); // WHERE numero_facture LIKE '%fooValue%'
     * $query->filterByNumeroFacture(['foo', 'bar']); // WHERE numero_facture IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $numeroFacture The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByNumeroFacture($numeroFacture = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($numeroFacture)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_NUMERO_FACTURE, $numeroFacture, $comparison);
    }

    /**
     * Filter the query on the dont_set_am_auto column
     *
     * Example usage:
     * <code>
     * $query->filterByDontSetAmAuto(true); // WHERE dont_set_am_auto = true
     * $query->filterByDontSetAmAuto('yes'); // WHERE dont_set_am_auto = true
     * </code>
     *
     * @param     boolean|string $dontSetAmAuto The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDontSetAmAuto($dontSetAmAuto = null, $comparison = null)
    {
        if (is_string($dontSetAmAuto)) {
            $dontSetAmAuto = in_array(strtolower($dontSetAmAuto), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DONT_SET_AM_AUTO, $dontSetAmAuto, $comparison);
    }

    /**
     * Filter the query on the set_am_reason column
     *
     * Example usage:
     * <code>
     * $query->filterBySetAmReason('fooValue');   // WHERE set_am_reason = 'fooValue'
     * $query->filterBySetAmReason('%fooValue%', Criteria::LIKE); // WHERE set_am_reason LIKE '%fooValue%'
     * $query->filterBySetAmReason(['foo', 'bar']); // WHERE set_am_reason IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $setAmReason The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySetAmReason($setAmReason = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($setAmReason)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SET_AM_REASON, $setAmReason, $comparison);
    }

    /**
     * Filter the query on the am_reason_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAmReasonTypeId(1234); // WHERE am_reason_type_id = 1234
     * $query->filterByAmReasonTypeId(array(12, 34)); // WHERE am_reason_type_id IN (12, 34)
     * $query->filterByAmReasonTypeId(array('min' => 12)); // WHERE am_reason_type_id > 12
     * </code>
     *
     * @see       filterByAmReasonType()
     *
     * @param     mixed $amReasonTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAmReasonTypeId($amReasonTypeId = null, $comparison = null)
    {
        if (is_array($amReasonTypeId)) {
            $useMinMax = false;
            if (isset($amReasonTypeId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_AM_REASON_TYPE_ID, $amReasonTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($amReasonTypeId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_AM_REASON_TYPE_ID, $amReasonTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_AM_REASON_TYPE_ID, $amReasonTypeId, $comparison);
    }

    /**
     * Filter the query on the date_envoi_facture column
     *
     * Example usage:
     * <code>
     * $query->filterByDateEnvoiFacture('2011-03-14'); // WHERE date_envoi_facture = '2011-03-14'
     * $query->filterByDateEnvoiFacture('now'); // WHERE date_envoi_facture = '2011-03-14'
     * $query->filterByDateEnvoiFacture(array('max' => 'yesterday')); // WHERE date_envoi_facture > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateEnvoiFacture The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDateEnvoiFacture($dateEnvoiFacture = null, $comparison = null)
    {
        if (is_array($dateEnvoiFacture)) {
            $useMinMax = false;
            if (isset($dateEnvoiFacture['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateEnvoiFacture['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture, $comparison);
    }

    /**
     * Filter the query on the date_reglement column
     *
     * Example usage:
     * <code>
     * $query->filterByDateReglement('2011-03-14'); // WHERE date_reglement = '2011-03-14'
     * $query->filterByDateReglement('now'); // WHERE date_reglement = '2011-03-14'
     * $query->filterByDateReglement(array('max' => 'yesterday')); // WHERE date_reglement > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateReglement The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDateReglement($dateReglement = null, $comparison = null)
    {
        if (is_array($dateReglement)) {
            $useMinMax = false;
            if (isset($dateReglement['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_REGLEMENT, $dateReglement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateReglement['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_DATE_REGLEMENT, $dateReglement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_DATE_REGLEMENT, $dateReglement, $comparison);
    }

    /**
     * Filter the query on the commentaire column
     *
     * Example usage:
     * <code>
     * $query->filterByCommentaire('fooValue');   // WHERE commentaire = 'fooValue'
     * $query->filterByCommentaire('%fooValue%', Criteria::LIKE); // WHERE commentaire LIKE '%fooValue%'
     * $query->filterByCommentaire(['foo', 'bar']); // WHERE commentaire IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $commentaire The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCommentaire($commentaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($commentaire)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_COMMENTAIRE, $commentaire, $comparison);
    }

    /**
     * Filter the query on the industry_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIndustryId(1234); // WHERE industry_id = 1234
     * $query->filterByIndustryId(array(12, 34)); // WHERE industry_id IN (12, 34)
     * $query->filterByIndustryId(array('min' => 12)); // WHERE industry_id > 12
     * </code>
     *
     * @see       filterByIndustry()
     *
     * @param     mixed $industryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIndustryId($industryId = null, $comparison = null)
    {
        if (is_array($industryId)) {
            $useMinMax = false;
            if (isset($industryId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INDUSTRY_ID, $industryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($industryId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INDUSTRY_ID, $industryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_INDUSTRY_ID, $industryId, $comparison);
    }

    /**
     * Filter the query on the periode_cutoff column
     *
     * Example usage:
     * <code>
     * $query->filterByPeriodeCutoff('fooValue');   // WHERE periode_cutoff = 'fooValue'
     * $query->filterByPeriodeCutoff('%fooValue%', Criteria::LIKE); // WHERE periode_cutoff LIKE '%fooValue%'
     * $query->filterByPeriodeCutoff(['foo', 'bar']); // WHERE periode_cutoff IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $periodeCutoff The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPeriodeCutoff($periodeCutoff = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($periodeCutoff)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PERIODE_CUTOFF, $periodeCutoff, $comparison);
    }

    /**
     * Filter the query on the theme_br column
     *
     * Example usage:
     * <code>
     * $query->filterByThemeBr('fooValue');   // WHERE theme_br = 'fooValue'
     * $query->filterByThemeBr('%fooValue%', Criteria::LIKE); // WHERE theme_br LIKE '%fooValue%'
     * $query->filterByThemeBr(['foo', 'bar']); // WHERE theme_br IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $themeBr The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByThemeBr($themeBr = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($themeBr)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_THEME_BR, $themeBr, $comparison);
    }

    /**
     * Filter the query on the area_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAreaId(1234); // WHERE area_id = 1234
     * $query->filterByAreaId(array(12, 34)); // WHERE area_id IN (12, 34)
     * $query->filterByAreaId(array('min' => 12)); // WHERE area_id > 12
     * </code>
     *
     * @see       filterByEtudeArea()
     *
     * @param     mixed $areaId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAreaId($areaId = null, $comparison = null)
    {
        if (is_array($areaId)) {
            $useMinMax = false;
            if (isset($areaId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_AREA_ID, $areaId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($areaId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_AREA_ID, $areaId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_AREA_ID, $areaId, $comparison);
    }

    /**
     * Filter the query on the id_sams_study column
     *
     * Example usage:
     * <code>
     * $query->filterByIdSamsStudy('fooValue');   // WHERE id_sams_study = 'fooValue'
     * $query->filterByIdSamsStudy('%fooValue%', Criteria::LIKE); // WHERE id_sams_study LIKE '%fooValue%'
     * $query->filterByIdSamsStudy(['foo', 'bar']); // WHERE id_sams_study IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $idSamsStudy The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdSamsStudy($idSamsStudy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($idSamsStudy)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_SAMS_STUDY, $idSamsStudy, $comparison);
    }

    /**
     * Filter the query on the recrutement_objectif column
     *
     * Example usage:
     * <code>
     * $query->filterByRecrutementObjectif(1234); // WHERE recrutement_objectif = 1234
     * $query->filterByRecrutementObjectif(array(12, 34)); // WHERE recrutement_objectif IN (12, 34)
     * $query->filterByRecrutementObjectif(array('min' => 12)); // WHERE recrutement_objectif > 12
     * </code>
     *
     * @param     mixed $recrutementObjectif The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRecrutementObjectif($recrutementObjectif = null, $comparison = null)
    {
        if (is_array($recrutementObjectif)) {
            $useMinMax = false;
            if (isset($recrutementObjectif['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($recrutementObjectif['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif, $comparison);
    }

    /**
     * Filter the query on the id_location_pnl column
     *
     * Example usage:
     * <code>
     * $query->filterByIdLocationPnl(1234); // WHERE id_location_pnl = 1234
     * $query->filterByIdLocationPnl(array(12, 34)); // WHERE id_location_pnl IN (12, 34)
     * $query->filterByIdLocationPnl(array('min' => 12)); // WHERE id_location_pnl > 12
     * </code>
     *
     * @see       filterByEtudeLocation()
     *
     * @param     mixed $idLocationPnl The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdLocationPnl($idLocationPnl = null, $comparison = null)
    {
        if (is_array($idLocationPnl)) {
            $useMinMax = false;
            if (isset($idLocationPnl['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_LOCATION_PNL, $idLocationPnl['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idLocationPnl['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_LOCATION_PNL, $idLocationPnl['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_LOCATION_PNL, $idLocationPnl, $comparison);
    }

    /**
     * Filter the query on the id_master_project_location_pnl column
     *
     * Example usage:
     * <code>
     * $query->filterByIdMasterProjectLocationPnl(1234); // WHERE id_master_project_location_pnl = 1234
     * $query->filterByIdMasterProjectLocationPnl(array(12, 34)); // WHERE id_master_project_location_pnl IN (12, 34)
     * $query->filterByIdMasterProjectLocationPnl(array('min' => 12)); // WHERE id_master_project_location_pnl > 12
     * </code>
     *
     * @see       filterByProjectLocationPrefix()
     *
     * @param     mixed $idMasterProjectLocationPnl The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdMasterProjectLocationPnl($idMasterProjectLocationPnl = null, $comparison = null)
    {
        if (is_array($idMasterProjectLocationPnl)) {
            $useMinMax = false;
            if (isset($idMasterProjectLocationPnl['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $idMasterProjectLocationPnl['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idMasterProjectLocationPnl['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $idMasterProjectLocationPnl['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $idMasterProjectLocationPnl, $comparison);
    }

    /**
     * Filter the query on the recrutement_objectif_pr column
     *
     * Example usage:
     * <code>
     * $query->filterByRecrutementObjectifPr(1234); // WHERE recrutement_objectif_pr = 1234
     * $query->filterByRecrutementObjectifPr(array(12, 34)); // WHERE recrutement_objectif_pr IN (12, 34)
     * $query->filterByRecrutementObjectifPr(array('min' => 12)); // WHERE recrutement_objectif_pr > 12
     * </code>
     *
     * @param     mixed $recrutementObjectifPr The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRecrutementObjectifPr($recrutementObjectifPr = null, $comparison = null)
    {
        if (is_array($recrutementObjectifPr)) {
            $useMinMax = false;
            if (isset($recrutementObjectifPr['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($recrutementObjectifPr['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr, $comparison);
    }

    /**
     * Filter the query on the id_bm column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBm(1234); // WHERE id_bm = 1234
     * $query->filterByIdBm(array(12, 34)); // WHERE id_bm IN (12, 34)
     * $query->filterByIdBm(array('min' => 12)); // WHERE id_bm > 12
     * </code>
     *
     * @see       filterByBM()
     *
     * @param     mixed $idBm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdBm($idBm = null, $comparison = null)
    {
        if (is_array($idBm)) {
            $useMinMax = false;
            if (isset($idBm['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_BM, $idBm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBm['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_BM, $idBm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_BM, $idBm, $comparison);
    }

    /**
     * Filter the query on the extra_info column
     *
     * Example usage:
     * <code>
     * $query->filterByExtraInfo('fooValue');   // WHERE extra_info = 'fooValue'
     * $query->filterByExtraInfo('%fooValue%', Criteria::LIKE); // WHERE extra_info LIKE '%fooValue%'
     * $query->filterByExtraInfo(['foo', 'bar']); // WHERE extra_info IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $extraInfo The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByExtraInfo($extraInfo = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($extraInfo)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_EXTRA_INFO, $extraInfo, $comparison);
    }

    /**
     * Filter the query on the account_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountId(1234); // WHERE account_id = 1234
     * $query->filterByAccountId(array(12, 34)); // WHERE account_id IN (12, 34)
     * $query->filterByAccountId(array('min' => 12)); // WHERE account_id > 12
     * </code>
     *
     * @see       filterByAccount()
     *
     * @param     mixed $accountId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountId($accountId = null, $comparison = null)
    {
        if (is_array($accountId)) {
            $useMinMax = false;
            if (isset($accountId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_ID, $accountId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_ID, $accountId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_ID, $accountId, $comparison);
    }

    /**
     * Filter the query on the account_manager_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountManagerId(1234); // WHERE account_manager_id = 1234
     * $query->filterByAccountManagerId(array(12, 34)); // WHERE account_manager_id IN (12, 34)
     * $query->filterByAccountManagerId(array('min' => 12)); // WHERE account_manager_id > 12
     * </code>
     *
     * @see       filterByProjectAccountManager()
     *
     * @param     mixed $accountManagerId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountManagerId($accountManagerId = null, $comparison = null)
    {
        if (is_array($accountManagerId)) {
            $useMinMax = false;
            if (isset($accountManagerId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $accountManagerId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountManagerId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $accountManagerId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $accountManagerId, $comparison);
    }

    /**
     * Filter the query on the project_specialty_sponsor_id column
     *
     * Example usage:
     * <code>
     * $query->filterByProjectSpecialtySponsorId(1234); // WHERE project_specialty_sponsor_id = 1234
     * $query->filterByProjectSpecialtySponsorId(array(12, 34)); // WHERE project_specialty_sponsor_id IN (12, 34)
     * $query->filterByProjectSpecialtySponsorId(array('min' => 12)); // WHERE project_specialty_sponsor_id > 12
     * </code>
     *
     * @see       filterByProjectSpecialtySponsor()
     *
     * @param     mixed $projectSpecialtySponsorId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProjectSpecialtySponsorId($projectSpecialtySponsorId = null, $comparison = null)
    {
        if (is_array($projectSpecialtySponsorId)) {
            $useMinMax = false;
            if (isset($projectSpecialtySponsorId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $projectSpecialtySponsorId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($projectSpecialtySponsorId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $projectSpecialtySponsorId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $projectSpecialtySponsorId, $comparison);
    }

    /**
     * Filter the query on the language column
     *
     * Example usage:
     * <code>
     * $query->filterByLanguage('fooValue');   // WHERE language = 'fooValue'
     * $query->filterByLanguage('%fooValue%', Criteria::LIKE); // WHERE language LIKE '%fooValue%'
     * $query->filterByLanguage(['foo', 'bar']); // WHERE language IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $language The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByLanguage($language = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($language)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_LANGUAGE, $language, $comparison);
    }

    /**
     * Filter the query on the remise_taux column
     *
     * Example usage:
     * <code>
     * $query->filterByRemiseTaux(1234); // WHERE remise_taux = 1234
     * $query->filterByRemiseTaux(array(12, 34)); // WHERE remise_taux IN (12, 34)
     * $query->filterByRemiseTaux(array('min' => 12)); // WHERE remise_taux > 12
     * </code>
     *
     * @param     mixed $remiseTaux The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRemiseTaux($remiseTaux = null, $comparison = null)
    {
        if (is_array($remiseTaux)) {
            $useMinMax = false;
            if (isset($remiseTaux['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_REMISE_TAUX, $remiseTaux['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($remiseTaux['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_REMISE_TAUX, $remiseTaux['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_REMISE_TAUX, $remiseTaux, $comparison);
    }

    /**
     * Filter the query on the client_discount_percentage column
     *
     * Example usage:
     * <code>
     * $query->filterByClientDiscountPercentage(1234); // WHERE client_discount_percentage = 1234
     * $query->filterByClientDiscountPercentage(array(12, 34)); // WHERE client_discount_percentage IN (12, 34)
     * $query->filterByClientDiscountPercentage(array('min' => 12)); // WHERE client_discount_percentage > 12
     * </code>
     *
     * @param     mixed $clientDiscountPercentage The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByClientDiscountPercentage($clientDiscountPercentage = null, $comparison = null)
    {
        if (is_array($clientDiscountPercentage)) {
            $useMinMax = false;
            if (isset($clientDiscountPercentage['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE, $clientDiscountPercentage['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($clientDiscountPercentage['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE, $clientDiscountPercentage['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE, $clientDiscountPercentage, $comparison);
    }

    /**
     * Filter the query on the end_client_discount_percentage column
     *
     * Example usage:
     * <code>
     * $query->filterByEndClientDiscountPercentage(1234); // WHERE end_client_discount_percentage = 1234
     * $query->filterByEndClientDiscountPercentage(array(12, 34)); // WHERE end_client_discount_percentage IN (12, 34)
     * $query->filterByEndClientDiscountPercentage(array('min' => 12)); // WHERE end_client_discount_percentage > 12
     * </code>
     *
     * @param     mixed $endClientDiscountPercentage The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClientDiscountPercentage($endClientDiscountPercentage = null, $comparison = null)
    {
        if (is_array($endClientDiscountPercentage)) {
            $useMinMax = false;
            if (isset($endClientDiscountPercentage['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE, $endClientDiscountPercentage['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endClientDiscountPercentage['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE, $endClientDiscountPercentage['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE, $endClientDiscountPercentage, $comparison);
    }

    /**
     * Filter the query on the client_quant_discount_percentage column
     *
     * Example usage:
     * <code>
     * $query->filterByClientQuantDiscountPercentage(1234); // WHERE client_quant_discount_percentage = 1234
     * $query->filterByClientQuantDiscountPercentage(array(12, 34)); // WHERE client_quant_discount_percentage IN (12, 34)
     * $query->filterByClientQuantDiscountPercentage(array('min' => 12)); // WHERE client_quant_discount_percentage > 12
     * </code>
     *
     * @param     mixed $clientQuantDiscountPercentage The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByClientQuantDiscountPercentage($clientQuantDiscountPercentage = null, $comparison = null)
    {
        if (is_array($clientQuantDiscountPercentage)) {
            $useMinMax = false;
            if (isset($clientQuantDiscountPercentage['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $clientQuantDiscountPercentage['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($clientQuantDiscountPercentage['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $clientQuantDiscountPercentage['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $clientQuantDiscountPercentage, $comparison);
    }

    /**
     * Filter the query on the end_client_quant_discount_percentage column
     *
     * Example usage:
     * <code>
     * $query->filterByEndClientQuantDiscountPercentage(1234); // WHERE end_client_quant_discount_percentage = 1234
     * $query->filterByEndClientQuantDiscountPercentage(array(12, 34)); // WHERE end_client_quant_discount_percentage IN (12, 34)
     * $query->filterByEndClientQuantDiscountPercentage(array('min' => 12)); // WHERE end_client_quant_discount_percentage > 12
     * </code>
     *
     * @param     mixed $endClientQuantDiscountPercentage The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClientQuantDiscountPercentage($endClientQuantDiscountPercentage = null, $comparison = null)
    {
        if (is_array($endClientQuantDiscountPercentage)) {
            $useMinMax = false;
            if (isset($endClientQuantDiscountPercentage['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $endClientQuantDiscountPercentage['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endClientQuantDiscountPercentage['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $endClientQuantDiscountPercentage['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $endClientQuantDiscountPercentage, $comparison);
    }

    /**
     * Filter the query on the sample_plan column
     *
     * Example usage:
     * <code>
     * $query->filterBySamplePlan('fooValue');   // WHERE sample_plan = 'fooValue'
     * $query->filterBySamplePlan('%fooValue%', Criteria::LIKE); // WHERE sample_plan LIKE '%fooValue%'
     * $query->filterBySamplePlan(['foo', 'bar']); // WHERE sample_plan IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $samplePlan The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySamplePlan($samplePlan = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($samplePlan)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SAMPLE_PLAN, $samplePlan, $comparison);
    }

    /**
     * Filter the query on the isToInvoice column
     *
     * Example usage:
     * <code>
     * $query->filterByIsToInvoice(true); // WHERE isToInvoice = true
     * $query->filterByIsToInvoice('yes'); // WHERE isToInvoice = true
     * </code>
     *
     * @param     boolean|string $isToInvoice The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIsToInvoice($isToInvoice = null, $comparison = null)
    {
        if (is_string($isToInvoice)) {
            $isToInvoice = in_array(strtolower($isToInvoice), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ISTOINVOICE, $isToInvoice, $comparison);
    }

    /**
     * Filter the query on the file_path column
     *
     * Example usage:
     * <code>
     * $query->filterByFilePath('fooValue');   // WHERE file_path = 'fooValue'
     * $query->filterByFilePath('%fooValue%', Criteria::LIKE); // WHERE file_path LIKE '%fooValue%'
     * $query->filterByFilePath(['foo', 'bar']); // WHERE file_path IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $filePath The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByFilePath($filePath = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($filePath)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_FILE_PATH, $filePath, $comparison);
    }

    /**
     * Filter the query on the account_leader_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountLeaderId(1234); // WHERE account_leader_id = 1234
     * $query->filterByAccountLeaderId(array(12, 34)); // WHERE account_leader_id IN (12, 34)
     * $query->filterByAccountLeaderId(array('min' => 12)); // WHERE account_leader_id > 12
     * </code>
     *
     * @see       filterByAccountLeader()
     *
     * @param     mixed $accountLeaderId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountLeaderId($accountLeaderId = null, $comparison = null)
    {
        if (is_array($accountLeaderId)) {
            $useMinMax = false;
            if (isset($accountLeaderId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $accountLeaderId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountLeaderId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $accountLeaderId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $accountLeaderId, $comparison);
    }

    /**
     * Filter the query on the account_pm_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountPMId(1234); // WHERE account_pm_id = 1234
     * $query->filterByAccountPMId(array(12, 34)); // WHERE account_pm_id IN (12, 34)
     * $query->filterByAccountPMId(array('min' => 12)); // WHERE account_pm_id > 12
     * </code>
     *
     * @see       filterByAccountPM()
     *
     * @param     mixed $accountPMId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountPMId($accountPMId = null, $comparison = null)
    {
        if (is_array($accountPMId)) {
            $useMinMax = false;
            if (isset($accountPMId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_PM_ID, $accountPMId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountPMId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_PM_ID, $accountPMId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_PM_ID, $accountPMId, $comparison);
    }

    /**
     * Filter the query on the am_email column
     *
     * Example usage:
     * <code>
     * $query->filterByAmEmail('fooValue');   // WHERE am_email = 'fooValue'
     * $query->filterByAmEmail('%fooValue%', Criteria::LIKE); // WHERE am_email LIKE '%fooValue%'
     * $query->filterByAmEmail(['foo', 'bar']); // WHERE am_email IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $amEmail The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAmEmail($amEmail = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($amEmail)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_AM_EMAIL, $amEmail, $comparison);
    }

    /**
     * Filter the query on the client_portal_ready column
     *
     * Example usage:
     * <code>
     * $query->filterByClientPortalReady(true); // WHERE client_portal_ready = true
     * $query->filterByClientPortalReady('yes'); // WHERE client_portal_ready = true
     * </code>
     *
     * @param     boolean|string $clientPortalReady The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByClientPortalReady($clientPortalReady = null, $comparison = null)
    {
        if (is_string($clientPortalReady)) {
            $clientPortalReady = in_array(strtolower($clientPortalReady), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CLIENT_PORTAL_READY, $clientPortalReady, $comparison);
    }

    /**
     * Filter the query on the length_of_interview column
     *
     * Example usage:
     * <code>
     * $query->filterByLengthOfInterview('fooValue');   // WHERE length_of_interview = 'fooValue'
     * $query->filterByLengthOfInterview('%fooValue%', Criteria::LIKE); // WHERE length_of_interview LIKE '%fooValue%'
     * $query->filterByLengthOfInterview(['foo', 'bar']); // WHERE length_of_interview IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $lengthOfInterview The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByLengthOfInterview($lengthOfInterview = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($lengthOfInterview)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_LENGTH_OF_INTERVIEW, $lengthOfInterview, $comparison);
    }

    /**
     * Filter the query on the sunshine_act column
     *
     * Example usage:
     * <code>
     * $query->filterBysunshineAct('fooValue');   // WHERE sunshine_act = 'fooValue'
     * $query->filterBysunshineAct('%fooValue%', Criteria::LIKE); // WHERE sunshine_act LIKE '%fooValue%'
     * $query->filterBysunshineAct(['foo', 'bar']); // WHERE sunshine_act IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $sunshineAct The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBysunshineAct($sunshineAct = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sunshineAct)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SUNSHINE_ACT, $sunshineAct, $comparison);
    }

    /**
     * Filter the query on the is_consolidated column
     *
     * Example usage:
     * <code>
     * $query->filterByIsConsolidated(true); // WHERE is_consolidated = true
     * $query->filterByIsConsolidated('yes'); // WHERE is_consolidated = true
     * </code>
     *
     * @param     boolean|string $isConsolidated The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIsConsolidated($isConsolidated = null, $comparison = null)
    {
        if (is_string($isConsolidated)) {
            $isConsolidated = in_array(strtolower($isConsolidated), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_IS_CONSOLIDATED, $isConsolidated, $comparison);
    }

    /**
     * Filter the query on the sharepoint_folder column
     *
     * Example usage:
     * <code>
     * $query->filterBySharepointFolder('fooValue');   // WHERE sharepoint_folder = 'fooValue'
     * $query->filterBySharepointFolder('%fooValue%', Criteria::LIKE); // WHERE sharepoint_folder LIKE '%fooValue%'
     * $query->filterBySharepointFolder(['foo', 'bar']); // WHERE sharepoint_folder IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $sharepointFolder The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySharepointFolder($sharepointFolder = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sharepointFolder)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SHAREPOINT_FOLDER, $sharepointFolder, $comparison);
    }

    /**
     * Filter the query on the multi_phase column
     *
     * Example usage:
     * <code>
     * $query->filterByMultiPhase(true); // WHERE multi_phase = true
     * $query->filterByMultiPhase('yes'); // WHERE multi_phase = true
     * </code>
     *
     * @param     boolean|string $multiPhase The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByMultiPhase($multiPhase = null, $comparison = null)
    {
        if (is_string($multiPhase)) {
            $multiPhase = in_array(strtolower($multiPhase), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_MULTI_PHASE, $multiPhase, $comparison);
    }

    /**
     * Filter the query on the po_number column
     *
     * Example usage:
     * <code>
     * $query->filterByPoNumber('fooValue');   // WHERE po_number = 'fooValue'
     * $query->filterByPoNumber('%fooValue%', Criteria::LIKE); // WHERE po_number LIKE '%fooValue%'
     * $query->filterByPoNumber(['foo', 'bar']); // WHERE po_number IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $poNumber The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByPoNumber($poNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($poNumber)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PO_NUMBER, $poNumber, $comparison);
    }

    /**
     * Filter the query on the currencies column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrencies('fooValue');   // WHERE currencies = 'fooValue'
     * $query->filterByCurrencies('%fooValue%', Criteria::LIKE); // WHERE currencies LIKE '%fooValue%'
     * $query->filterByCurrencies(['foo', 'bar']); // WHERE currencies IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $currencies The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCurrencies($currencies = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($currencies)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CURRENCIES, $currencies, $comparison);
    }

    /**
     * Filter the query on the sms_relance column
     *
     * Example usage:
     * <code>
     * $query->filterBySmsRelance(true); // WHERE sms_relance = true
     * $query->filterBySmsRelance('yes'); // WHERE sms_relance = true
     * </code>
     *
     * @param     boolean|string $smsRelance The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySmsRelance($smsRelance = null, $comparison = null)
    {
        if (is_string($smsRelance)) {
            $smsRelance = in_array(strtolower($smsRelance), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SMS_RELANCE, $smsRelance, $comparison);
    }

    /**
     * Filter the query on the id_etude_group column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtudeGroup(1234); // WHERE id_etude_group = 1234
     * $query->filterByIdEtudeGroup(array(12, 34)); // WHERE id_etude_group IN (12, 34)
     * $query->filterByIdEtudeGroup(array('min' => 12)); // WHERE id_etude_group > 12
     * </code>
     *
     * @see       filterByEtudeGroup()
     *
     * @param     mixed $idEtudeGroup The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIdEtudeGroup($idEtudeGroup = null, $comparison = null)
    {
        if (is_array($idEtudeGroup)) {
            $useMinMax = false;
            if (isset($idEtudeGroup['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_ETUDE_GROUP, $idEtudeGroup['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtudeGroup['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_ID_ETUDE_GROUP, $idEtudeGroup['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ID_ETUDE_GROUP, $idEtudeGroup, $comparison);
    }

    /**
     * Filter the query on the gms column
     *
     * Example usage:
     * <code>
     * $query->filterByGms('fooValue');   // WHERE gms = 'fooValue'
     * $query->filterByGms('%fooValue%', Criteria::LIKE); // WHERE gms LIKE '%fooValue%'
     * $query->filterByGms(['foo', 'bar']); // WHERE gms IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $gms The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByGms($gms = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($gms)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_GMS, $gms, $comparison);
    }

    /**
     * Filter the query on the kol column
     *
     * Example usage:
     * <code>
     * $query->filterByKol('fooValue');   // WHERE kol = 'fooValue'
     * $query->filterByKol('%fooValue%', Criteria::LIKE); // WHERE kol LIKE '%fooValue%'
     * $query->filterByKol(['foo', 'bar']); // WHERE kol IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $kol The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByKol($kol = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($kol)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_KOL, $kol, $comparison);
    }

    /**
     * Filter the query on the room_rental column
     *
     * Example usage:
     * <code>
     * $query->filterByRoomRental(true); // WHERE room_rental = true
     * $query->filterByRoomRental('yes'); // WHERE room_rental = true
     * </code>
     *
     * @param     boolean|string $roomRental The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRoomRental($roomRental = null, $comparison = null)
    {
        if (is_string($roomRental)) {
            $roomRental = in_array(strtolower($roomRental), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ROOM_RENTAL, $roomRental, $comparison);
    }

    /**
     * Filter the query on the recruits_offsite column
     *
     * Example usage:
     * <code>
     * $query->filterByRecruitsOffsite(true); // WHERE recruits_offsite = true
     * $query->filterByRecruitsOffsite('yes'); // WHERE recruits_offsite = true
     * </code>
     *
     * @param     boolean|string $recruitsOffsite The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRecruitsOffsite($recruitsOffsite = null, $comparison = null)
    {
        if (is_string($recruitsOffsite)) {
            $recruitsOffsite = in_array(strtolower($recruitsOffsite), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_RECRUITS_OFFSITE, $recruitsOffsite, $comparison);
    }

    /**
     * Filter the query on the study_specification column
     *
     * Example usage:
     * <code>
     * $query->filterByStudySpecification('fooValue');   // WHERE study_specification = 'fooValue'
     * $query->filterByStudySpecification('%fooValue%', Criteria::LIKE); // WHERE study_specification LIKE '%fooValue%'
     * $query->filterByStudySpecification(['foo', 'bar']); // WHERE study_specification IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $studySpecification The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByStudySpecification($studySpecification = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($studySpecification)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_STUDY_SPECIFICATION, $studySpecification, $comparison);
    }

    /**
     * Filter the query on the is_study_specification column
     *
     * Example usage:
     * <code>
     * $query->filterByisStudySpecification(true); // WHERE is_study_specification = true
     * $query->filterByisStudySpecification('yes'); // WHERE is_study_specification = true
     * </code>
     *
     * @param     boolean|string $isStudySpecification The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByisStudySpecification($isStudySpecification = null, $comparison = null)
    {
        if (is_string($isStudySpecification)) {
            $isStudySpecification = in_array(strtolower($isStudySpecification), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_IS_STUDY_SPECIFICATION, $isStudySpecification, $comparison);
    }

    /**
     * Filter the query on the additional_notes column
     *
     * Example usage:
     * <code>
     * $query->filterByAdditionalNotes('fooValue');   // WHERE additional_notes = 'fooValue'
     * $query->filterByAdditionalNotes('%fooValue%', Criteria::LIKE); // WHERE additional_notes LIKE '%fooValue%'
     * $query->filterByAdditionalNotes(['foo', 'bar']); // WHERE additional_notes IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $additionalNotes The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAdditionalNotes($additionalNotes = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($additionalNotes)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ADDITIONAL_NOTES, $additionalNotes, $comparison);
    }

    /**
     * Filter the query on the project_comment column
     *
     * Example usage:
     * <code>
     * $query->filterByProjectComment('fooValue');   // WHERE project_comment = 'fooValue'
     * $query->filterByProjectComment('%fooValue%', Criteria::LIKE); // WHERE project_comment LIKE '%fooValue%'
     * $query->filterByProjectComment(['foo', 'bar']); // WHERE project_comment IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $projectComment The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProjectComment($projectComment = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($projectComment)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PROJECT_COMMENT, $projectComment, $comparison);
    }

    /**
     * Filter the query on the end_client_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEndClientId(1234); // WHERE end_client_id = 1234
     * $query->filterByEndClientId(array(12, 34)); // WHERE end_client_id IN (12, 34)
     * $query->filterByEndClientId(array('min' => 12)); // WHERE end_client_id > 12
     * </code>
     *
     * @see       filterByEndClient()
     *
     * @param     mixed $endClientId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClientId($endClientId = null, $comparison = null)
    {
        if (is_array($endClientId)) {
            $useMinMax = false;
            if (isset($endClientId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_ID, $endClientId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endClientId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_ID, $endClientId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_ID, $endClientId, $comparison);
    }

    /**
     * Filter the query on the end_client_contact_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEndClientContactId(1234); // WHERE end_client_contact_id = 1234
     * $query->filterByEndClientContactId(array(12, 34)); // WHERE end_client_contact_id IN (12, 34)
     * $query->filterByEndClientContactId(array('min' => 12)); // WHERE end_client_contact_id > 12
     * </code>
     *
     * @see       filterByEndClientContact()
     *
     * @param     mixed $endClientContactId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClientContactId($endClientContactId = null, $comparison = null)
    {
        if (is_array($endClientContactId)) {
            $useMinMax = false;
            if (isset($endClientContactId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $endClientContactId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($endClientContactId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $endClientContactId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $endClientContactId, $comparison);
    }

    /**
     * Filter the query on the contact_id column
     *
     * Example usage:
     * <code>
     * $query->filterByContactId(1234); // WHERE contact_id = 1234
     * $query->filterByContactId(array(12, 34)); // WHERE contact_id IN (12, 34)
     * $query->filterByContactId(array('min' => 12)); // WHERE contact_id > 12
     * </code>
     *
     * @see       filterByContact()
     *
     * @param     mixed $contactId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByContactId($contactId = null, $comparison = null)
    {
        if (is_array($contactId)) {
            $useMinMax = false;
            if (isset($contactId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CONTACT_ID, $contactId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($contactId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CONTACT_ID, $contactId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CONTACT_ID, $contactId, $comparison);
    }

    /**
     * Filter the query on the contact_client_pm_id column
     *
     * Example usage:
     * <code>
     * $query->filterByContactClientPmId(1234); // WHERE contact_client_pm_id = 1234
     * $query->filterByContactClientPmId(array(12, 34)); // WHERE contact_client_pm_id IN (12, 34)
     * $query->filterByContactClientPmId(array('min' => 12)); // WHERE contact_client_pm_id > 12
     * </code>
     *
     * @see       filterByContactClientPm()
     *
     * @param     mixed $contactClientPmId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByContactClientPmId($contactClientPmId = null, $comparison = null)
    {
        if (is_array($contactClientPmId)) {
            $useMinMax = false;
            if (isset($contactClientPmId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $contactClientPmId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($contactClientPmId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $contactClientPmId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $contactClientPmId, $comparison);
    }

    /**
     * Filter the query on the master_project_number column
     *
     * Example usage:
     * <code>
     * $query->filterByMasterProjectNumber('fooValue');   // WHERE master_project_number = 'fooValue'
     * $query->filterByMasterProjectNumber('%fooValue%', Criteria::LIKE); // WHERE master_project_number LIKE '%fooValue%'
     * $query->filterByMasterProjectNumber(['foo', 'bar']); // WHERE master_project_number IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $masterProjectNumber The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByMasterProjectNumber($masterProjectNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($masterProjectNumber)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_MASTER_PROJECT_NUMBER, $masterProjectNumber, $comparison);
    }

    /**
     * Filter the query on the proposed_loi column
     *
     * Example usage:
     * <code>
     * $query->filterByProposedLoi(1234); // WHERE proposed_loi = 1234
     * $query->filterByProposedLoi(array(12, 34)); // WHERE proposed_loi IN (12, 34)
     * $query->filterByProposedLoi(array('min' => 12)); // WHERE proposed_loi > 12
     * </code>
     *
     * @param     mixed $proposedLoi The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProposedLoi($proposedLoi = null, $comparison = null)
    {
        if (is_array($proposedLoi)) {
            $useMinMax = false;
            if (isset($proposedLoi['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_LOI, $proposedLoi['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($proposedLoi['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_LOI, $proposedLoi['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_LOI, $proposedLoi, $comparison);
    }

    /**
     * Filter the query on the opportunity_id column
     *
     * Example usage:
     * <code>
     * $query->filterByOpportunityId(1234); // WHERE opportunity_id = 1234
     * $query->filterByOpportunityId(array(12, 34)); // WHERE opportunity_id IN (12, 34)
     * $query->filterByOpportunityId(array('min' => 12)); // WHERE opportunity_id > 12
     * </code>
     *
     * @see       filterByOpportunity()
     *
     * @param     mixed $opportunityId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByOpportunityId($opportunityId = null, $comparison = null)
    {
        if (is_array($opportunityId)) {
            $useMinMax = false;
            if (isset($opportunityId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_OPPORTUNITY_ID, $opportunityId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($opportunityId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_OPPORTUNITY_ID, $opportunityId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_OPPORTUNITY_ID, $opportunityId, $comparison);
    }

    /**
     * Filter the query on the si_job_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySiJobTypeId(1234); // WHERE si_job_type_id = 1234
     * $query->filterBySiJobTypeId(array(12, 34)); // WHERE si_job_type_id IN (12, 34)
     * $query->filterBySiJobTypeId(array('min' => 12)); // WHERE si_job_type_id > 12
     * </code>
     *
     * @see       filterBySiJobType()
     *
     * @param     mixed $siJobTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySiJobTypeId($siJobTypeId = null, $comparison = null)
    {
        if (is_array($siJobTypeId)) {
            $useMinMax = false;
            if (isset($siJobTypeId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_SI_JOB_TYPE_ID, $siJobTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($siJobTypeId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_SI_JOB_TYPE_ID, $siJobTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SI_JOB_TYPE_ID, $siJobTypeId, $comparison);
    }

    /**
     * Filter the query on the best_effort column
     *
     * Example usage:
     * <code>
     * $query->filterByBestEffort(true); // WHERE best_effort = true
     * $query->filterByBestEffort('yes'); // WHERE best_effort = true
     * </code>
     *
     * @param     boolean|string $bestEffort The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByBestEffort($bestEffort = null, $comparison = null)
    {
        if (is_string($bestEffort)) {
            $bestEffort = in_array(strtolower($bestEffort), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_BEST_EFFORT, $bestEffort, $comparison);
    }

    /**
     * Filter the query on the job_status_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByJobStatusSfId(1234); // WHERE job_status_sf_id = 1234
     * $query->filterByJobStatusSfId(array(12, 34)); // WHERE job_status_sf_id IN (12, 34)
     * $query->filterByJobStatusSfId(array('min' => 12)); // WHERE job_status_sf_id > 12
     * </code>
     *
     * @see       filterByJobStatusSf()
     *
     * @param     mixed $jobStatusSfId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByJobStatusSfId($jobStatusSfId = null, $comparison = null)
    {
        if (is_array($jobStatusSfId)) {
            $useMinMax = false;
            if (isset($jobStatusSfId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_JOB_STATUS_SF_ID, $jobStatusSfId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jobStatusSfId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_JOB_STATUS_SF_ID, $jobStatusSfId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_JOB_STATUS_SF_ID, $jobStatusSfId, $comparison);
    }

    /**
     * Filter the query on the booked_by_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBookedBySfId('fooValue');   // WHERE booked_by_sf_id = 'fooValue'
     * $query->filterByBookedBySfId('%fooValue%', Criteria::LIKE); // WHERE booked_by_sf_id LIKE '%fooValue%'
     * $query->filterByBookedBySfId(['foo', 'bar']); // WHERE booked_by_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $bookedBySfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByBookedBySfId($bookedBySfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($bookedBySfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_BOOKED_BY_SF_ID, $bookedBySfId, $comparison);
    }

    /**
     * Filter the query on the created_by_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBySfId('fooValue');   // WHERE created_by_sf_id = 'fooValue'
     * $query->filterByCreatedBySfId('%fooValue%', Criteria::LIKE); // WHERE created_by_sf_id LIKE '%fooValue%'
     * $query->filterByCreatedBySfId(['foo', 'bar']); // WHERE created_by_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $createdBySfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedBySfId($createdBySfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBySfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_BY_SF_ID, $createdBySfId, $comparison);
    }

    /**
     * Filter the query on the account_manager_sf_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountManagerSfId('fooValue');   // WHERE account_manager_sf_id = 'fooValue'
     * $query->filterByAccountManagerSfId('%fooValue%', Criteria::LIKE); // WHERE account_manager_sf_id LIKE '%fooValue%'
     * $query->filterByAccountManagerSfId(['foo', 'bar']); // WHERE account_manager_sf_id IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $accountManagerSfId The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountManagerSfId($accountManagerSfId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($accountManagerSfId)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID, $accountManagerSfId, $comparison);
    }

    /**
     * Filter the query on the created_date column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedDate('2011-03-14'); // WHERE created_date = '2011-03-14'
     * $query->filterByCreatedDate('now'); // WHERE created_date = '2011-03-14'
     * $query->filterByCreatedDate(array('max' => 'yesterday')); // WHERE created_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $createdDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedDate($createdDate = null, $comparison = null)
    {
        if (is_array($createdDate)) {
            $useMinMax = false;
            if (isset($createdDate['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_DATE, $createdDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdDate['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_DATE, $createdDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_DATE, $createdDate, $comparison);
    }

    /**
     * Filter the query on the job_qualification_id column
     *
     * Example usage:
     * <code>
     * $query->filterByJobQualificationId(1234); // WHERE job_qualification_id = 1234
     * $query->filterByJobQualificationId(array(12, 34)); // WHERE job_qualification_id IN (12, 34)
     * $query->filterByJobQualificationId(array('min' => 12)); // WHERE job_qualification_id > 12
     * </code>
     *
     * @see       filterByJobQualification()
     *
     * @param     mixed $jobQualificationId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByJobQualificationId($jobQualificationId = null, $comparison = null)
    {
        if (is_array($jobQualificationId)) {
            $useMinMax = false;
            if (isset($jobQualificationId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $jobQualificationId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jobQualificationId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $jobQualificationId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $jobQualificationId, $comparison);
    }

    /**
     * Filter the query on the proposed_n column
     *
     * Example usage:
     * <code>
     * $query->filterByProposedN(1234); // WHERE proposed_n = 1234
     * $query->filterByProposedN(array(12, 34)); // WHERE proposed_n IN (12, 34)
     * $query->filterByProposedN(array('min' => 12)); // WHERE proposed_n > 12
     * </code>
     *
     * @param     mixed $proposedN The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProposedN($proposedN = null, $comparison = null)
    {
        if (is_array($proposedN)) {
            $useMinMax = false;
            if (isset($proposedN['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_N, $proposedN['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($proposedN['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_N, $proposedN['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_PROPOSED_N, $proposedN, $comparison);
    }

    /**
     * Filter the query on the german_job_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByGermanJobTypeId(1234); // WHERE german_job_type_id = 1234
     * $query->filterByGermanJobTypeId(array(12, 34)); // WHERE german_job_type_id IN (12, 34)
     * $query->filterByGermanJobTypeId(array('min' => 12)); // WHERE german_job_type_id > 12
     * </code>
     *
     * @see       filterByGermanJobType()
     *
     * @param     mixed $germanJobTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByGermanJobTypeId($germanJobTypeId = null, $comparison = null)
    {
        if (is_array($germanJobTypeId)) {
            $useMinMax = false;
            if (isset($germanJobTypeId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $germanJobTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($germanJobTypeId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $germanJobTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $germanJobTypeId, $comparison);
    }

    /**
     * Filter the query on the created_by_comment column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedByComment('fooValue');   // WHERE created_by_comment = 'fooValue'
     * $query->filterByCreatedByComment('%fooValue%', Criteria::LIKE); // WHERE created_by_comment LIKE '%fooValue%'
     * $query->filterByCreatedByComment(['foo', 'bar']); // WHERE created_by_comment IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $createdByComment The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedByComment($createdByComment = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdByComment)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_BY_COMMENT, $createdByComment, $comparison);
    }

    /**
     * Filter the query on the focus_vision column
     *
     * Example usage:
     * <code>
     * $query->filterByFocusVision(true); // WHERE focus_vision = true
     * $query->filterByFocusVision('yes'); // WHERE focus_vision = true
     * </code>
     *
     * @param     boolean|string $focusVision The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByFocusVision($focusVision = null, $comparison = null)
    {
        if (is_string($focusVision)) {
            $focusVision = in_array(strtolower($focusVision), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(EtudeTableMap::COL_FOCUS_VISION, $focusVision, $comparison);
    }

    /**
     * Filter the query on the si_eu_job_type column
     *
     * @param     mixed $siEuJobType The value to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySiEuJobType($siEuJobType = null, $comparison = null)
    {
        $valueSet = EtudeTableMap::getValueSet(EtudeTableMap::COL_SI_EU_JOB_TYPE);
        if (is_scalar($siEuJobType)) {
            if (!in_array($siEuJobType, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $siEuJobType));
            }
            $siEuJobType = array_search($siEuJobType, $valueSet);
        } elseif (is_array($siEuJobType)) {
            $convertedValues = array();
            foreach ($siEuJobType as $value) {
                if (!in_array($value, $valueSet)) {
                    throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $value));
                }
                $convertedValues []= array_search($value, $valueSet);
            }
            $siEuJobType = $convertedValues;
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_SI_EU_JOB_TYPE, $siEuJobType, $comparison);
    }

    /**
     * Filter the query on the intermediate_client_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIntermediateClientId(1234); // WHERE intermediate_client_id = 1234
     * $query->filterByIntermediateClientId(array(12, 34)); // WHERE intermediate_client_id IN (12, 34)
     * $query->filterByIntermediateClientId(array('min' => 12)); // WHERE intermediate_client_id > 12
     * </code>
     *
     * @see       filterByIntermediateClient()
     *
     * @param     mixed $intermediateClientId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIntermediateClientId($intermediateClientId = null, $comparison = null)
    {
        if (is_array($intermediateClientId)) {
            $useMinMax = false;
            if (isset($intermediateClientId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $intermediateClientId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($intermediateClientId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $intermediateClientId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $intermediateClientId, $comparison);
    }

    /**
     * Filter the query on the intermediate_client_contact_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIntermediateClientContactId(1234); // WHERE intermediate_client_contact_id = 1234
     * $query->filterByIntermediateClientContactId(array(12, 34)); // WHERE intermediate_client_contact_id IN (12, 34)
     * $query->filterByIntermediateClientContactId(array('min' => 12)); // WHERE intermediate_client_contact_id > 12
     * </code>
     *
     * @see       filterByIntermediateClientContact()
     *
     * @param     mixed $intermediateClientContactId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIntermediateClientContactId($intermediateClientContactId = null, $comparison = null)
    {
        if (is_array($intermediateClientContactId)) {
            $useMinMax = false;
            if (isset($intermediateClientContactId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $intermediateClientContactId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($intermediateClientContactId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $intermediateClientContactId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $intermediateClientContactId, $comparison);
    }

    /**
     * Filter the query on the us_global_qual_gms_id column
     *
     * Example usage:
     * <code>
     * $query->filterByUsGlobalQualGmsId(1234); // WHERE us_global_qual_gms_id = 1234
     * $query->filterByUsGlobalQualGmsId(array(12, 34)); // WHERE us_global_qual_gms_id IN (12, 34)
     * $query->filterByUsGlobalQualGmsId(array('min' => 12)); // WHERE us_global_qual_gms_id > 12
     * </code>
     *
     * @see       filterByUsGlobalQualGms()
     *
     * @param     mixed $usGlobalQualGmsId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByUsGlobalQualGmsId($usGlobalQualGmsId = null, $comparison = null)
    {
        if (is_array($usGlobalQualGmsId)) {
            $useMinMax = false;
            if (isset($usGlobalQualGmsId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $usGlobalQualGmsId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($usGlobalQualGmsId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $usGlobalQualGmsId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $usGlobalQualGmsId, $comparison);
    }

    /**
     * Filter the query on the facilty_note column
     *
     * Example usage:
     * <code>
     * $query->filterByFaciltyNote('fooValue');   // WHERE facilty_note = 'fooValue'
     * $query->filterByFaciltyNote('%fooValue%', Criteria::LIKE); // WHERE facilty_note LIKE '%fooValue%'
     * $query->filterByFaciltyNote(['foo', 'bar']); // WHERE facilty_note IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $faciltyNote The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByFaciltyNote($faciltyNote = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($faciltyNote)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_FACILTY_NOTE, $faciltyNote, $comparison);
    }

    /**
     * Filter the query on the currency_iso_code_id column
     *
     * Example usage:
     * <code>
     * $query->filterByCurrencyIsoCodeId(1234); // WHERE currency_iso_code_id = 1234
     * $query->filterByCurrencyIsoCodeId(array(12, 34)); // WHERE currency_iso_code_id IN (12, 34)
     * $query->filterByCurrencyIsoCodeId(array('min' => 12)); // WHERE currency_iso_code_id > 12
     * </code>
     *
     * @see       filterByCurrencyIsoCode()
     *
     * @param     mixed $currencyIsoCodeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCurrencyIsoCodeId($currencyIsoCodeId = null, $comparison = null)
    {
        if (is_array($currencyIsoCodeId)) {
            $useMinMax = false;
            if (isset($currencyIsoCodeId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $currencyIsoCodeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($currencyIsoCodeId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $currencyIsoCodeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $currencyIsoCodeId, $comparison);
    }

    /**
     * Filter the query on the client_list_deletion_id column
     *
     * Example usage:
     * <code>
     * $query->filterByClientListDeletionId(1234); // WHERE client_list_deletion_id = 1234
     * $query->filterByClientListDeletionId(array(12, 34)); // WHERE client_list_deletion_id IN (12, 34)
     * $query->filterByClientListDeletionId(array('min' => 12)); // WHERE client_list_deletion_id > 12
     * </code>
     *
     * @see       filterByClientListDeletion()
     *
     * @param     mixed $clientListDeletionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByClientListDeletionId($clientListDeletionId = null, $comparison = null)
    {
        if (is_array($clientListDeletionId)) {
            $useMinMax = false;
            if (isset($clientListDeletionId['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $clientListDeletionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($clientListDeletionId['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $clientListDeletionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $clientListDeletionId, $comparison);
    }

    /**
     * Filter the query on the created_by_id column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedById(1234); // WHERE created_by_id = 1234
     * $query->filterByCreatedById(array(12, 34)); // WHERE created_by_id IN (12, 34)
     * $query->filterByCreatedById(array('min' => 12)); // WHERE created_by_id > 12
     * </code>
     *
     * @see       filterByCreatedBy()
     *
     * @param     mixed $createdById The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedById($createdById = null, $comparison = null)
    {
        if (is_array($createdById)) {
            $useMinMax = false;
            if (isset($createdById['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_BY_ID, $createdById['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdById['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_BY_ID, $createdById['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_BY_ID, $createdById, $comparison);
    }

    /**
     * Filter the query on the updated_by_id column
     *
     * Example usage:
     * <code>
     * $query->filterByUpdatedById(1234); // WHERE updated_by_id = 1234
     * $query->filterByUpdatedById(array(12, 34)); // WHERE updated_by_id IN (12, 34)
     * $query->filterByUpdatedById(array('min' => 12)); // WHERE updated_by_id > 12
     * </code>
     *
     * @see       filterByUpdatedBy()
     *
     * @param     mixed $updatedById The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByUpdatedById($updatedById = null, $comparison = null)
    {
        if (is_array($updatedById)) {
            $useMinMax = false;
            if (isset($updatedById['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_UPDATED_BY_ID, $updatedById['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($updatedById['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_UPDATED_BY_ID, $updatedById['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_UPDATED_BY_ID, $updatedById, $comparison);
    }

    /**
     * Filter the query on the created_at column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedAt('2011-03-14'); // WHERE created_at = '2011-03-14'
     * $query->filterByCreatedAt('now'); // WHERE created_at = '2011-03-14'
     * $query->filterByCreatedAt(array('max' => 'yesterday')); // WHERE created_at > '2011-03-13'
     * </code>
     *
     * @param     mixed $createdAt The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedAt($createdAt = null, $comparison = null)
    {
        if (is_array($createdAt)) {
            $useMinMax = false;
            if (isset($createdAt['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_AT, $createdAt['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($createdAt['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_CREATED_AT, $createdAt['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_AT, $createdAt, $comparison);
    }

    /**
     * Filter the query on the updated_at column
     *
     * Example usage:
     * <code>
     * $query->filterByUpdatedAt('2011-03-14'); // WHERE updated_at = '2011-03-14'
     * $query->filterByUpdatedAt('now'); // WHERE updated_at = '2011-03-14'
     * $query->filterByUpdatedAt(array('max' => 'yesterday')); // WHERE updated_at > '2011-03-13'
     * </code>
     *
     * @param     mixed $updatedAt The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByUpdatedAt($updatedAt = null, $comparison = null)
    {
        if (is_array($updatedAt)) {
            $useMinMax = false;
            if (isset($updatedAt['min'])) {
                $this->addUsingAlias(EtudeTableMap::COL_UPDATED_AT, $updatedAt['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($updatedAt['max'])) {
                $this->addUsingAlias(EtudeTableMap::COL_UPDATED_AT, $updatedAt['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeTableMap::COL_UPDATED_AT, $updatedAt, $comparison);
    }

    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByUsGlobalQualGms($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByUsGlobalQualGms() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the UsGlobalQualGms relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinUsGlobalQualGms($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('UsGlobalQualGms');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'UsGlobalQualGms');
        }

        return $this;
    }

    /**
     * Use the UsGlobalQualGms relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useUsGlobalQualGmsQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinUsGlobalQualGms($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'UsGlobalQualGms', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the UsGlobalQualGms relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withUsGlobalQualGmsQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useUsGlobalQualGmsQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the UsGlobalQualGms relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useUsGlobalQualGmsExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('UsGlobalQualGms', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the UsGlobalQualGms relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useUsGlobalQualGmsExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useUsGlobalQualGmsNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('UsGlobalQualGms', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountLeader($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAccountLeader() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AccountLeader relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinAccountLeader($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AccountLeader');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AccountLeader');
        }

        return $this;
    }

    /**
     * Use the AccountLeader relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useAccountLeaderQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAccountLeader($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AccountLeader', '\Model\UserQuery');
    }

    /**
     * Use the AccountLeader relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAccountLeaderQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAccountLeaderQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the AccountLeader relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useAccountLeaderExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('AccountLeader', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the AccountLeader relation to the User table for a NOT EXISTS query.
     *
     * @see useAccountLeaderExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useAccountLeaderNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('AccountLeader', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccountPM($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_PM_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_PM_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAccountPM() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AccountPM relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinAccountPM($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AccountPM');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AccountPM');
        }

        return $this;
    }

    /**
     * Use the AccountPM relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useAccountPMQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAccountPM($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AccountPM', '\Model\UserQuery');
    }

    /**
     * Use the AccountPM relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAccountPMQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAccountPMQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the AccountPM relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useAccountPMExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('AccountPM', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the AccountPM relation to the User table for a NOT EXISTS query.
     *
     * @see useAccountPMExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useAccountPMNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('AccountPM', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Account object
     *
     * @param \Model\Account|ObjectCollection $account The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIntermediateClient($account, $comparison = null)
    {
        if ($account instanceof \Model\Account) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $account->getId(), $comparison);
        } elseif ($account instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $account->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByIntermediateClient() only accepts arguments of type \Model\Account or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the IntermediateClient relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinIntermediateClient($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('IntermediateClient');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'IntermediateClient');
        }

        return $this;
    }

    /**
     * Use the IntermediateClient relation Account object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AccountQuery A secondary query class using the current class as primary query
     */
    public function useIntermediateClientQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinIntermediateClient($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'IntermediateClient', '\Model\AccountQuery');
    }

    /**
     * Use the IntermediateClient relation Account object
     *
     * @param callable(\Model\AccountQuery):\Model\AccountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withIntermediateClientQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useIntermediateClientQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the IntermediateClient relation to the Account table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AccountQuery The inner query object of the EXISTS statement
     */
    public function useIntermediateClientExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('IntermediateClient', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the IntermediateClient relation to the Account table for a NOT EXISTS query.
     *
     * @see useIntermediateClientExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AccountQuery The inner query object of the NOT EXISTS statement
     */
    public function useIntermediateClientNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('IntermediateClient', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Etape object
     *
     * @param \Model\Etape|ObjectCollection $etape The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtape($etape, $comparison = null)
    {
        if ($etape instanceof \Model\Etape) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_ETAPE, $etape->getId(), $comparison);
        } elseif ($etape instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_ETAPE, $etape->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtape() only accepts arguments of type \Model\Etape or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etape relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtape($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etape');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etape');
        }

        return $this;
    }

    /**
     * Use the Etape relation Etape object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtapeQuery A secondary query class using the current class as primary query
     */
    public function useEtapeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtape($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etape', '\Model\EtapeQuery');
    }

    /**
     * Use the Etape relation Etape object
     *
     * @param callable(\Model\EtapeQuery):\Model\EtapeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtapeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtapeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etape table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtapeQuery The inner query object of the EXISTS statement
     */
    public function useEtapeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etape table for a NOT EXISTS query.
     *
     * @see useEtapeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtapeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtapeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Contact object
     *
     * @param \Model\Contact|ObjectCollection $contact The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByContact($contact, $comparison = null)
    {
        if ($contact instanceof \Model\Contact) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_CONTACT_ID, $contact->getId(), $comparison);
        } elseif ($contact instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_CONTACT_ID, $contact->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByContact() only accepts arguments of type \Model\Contact or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Contact relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinContact($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Contact');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Contact');
        }

        return $this;
    }

    /**
     * Use the Contact relation Contact object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ContactQuery A secondary query class using the current class as primary query
     */
    public function useContactQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinContact($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Contact', '\Model\ContactQuery');
    }

    /**
     * Use the Contact relation Contact object
     *
     * @param callable(\Model\ContactQuery):\Model\ContactQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withContactQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useContactQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Contact table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ContactQuery The inner query object of the EXISTS statement
     */
    public function useContactExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Contact', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Contact table for a NOT EXISTS query.
     *
     * @see useContactExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ContactQuery The inner query object of the NOT EXISTS statement
     */
    public function useContactNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Contact', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Opportunity object
     *
     * @param \Model\Opportunity|ObjectCollection $opportunity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByOpportunity($opportunity, $comparison = null)
    {
        if ($opportunity instanceof \Model\Opportunity) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_OPPORTUNITY_ID, $opportunity->getId(), $comparison);
        } elseif ($opportunity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_OPPORTUNITY_ID, $opportunity->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByOpportunity() only accepts arguments of type \Model\Opportunity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Opportunity relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinOpportunity($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Opportunity');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Opportunity');
        }

        return $this;
    }

    /**
     * Use the Opportunity relation Opportunity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\OpportunityQuery A secondary query class using the current class as primary query
     */
    public function useOpportunityQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinOpportunity($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Opportunity', '\Model\OpportunityQuery');
    }

    /**
     * Use the Opportunity relation Opportunity object
     *
     * @param callable(\Model\OpportunityQuery):\Model\OpportunityQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withOpportunityQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useOpportunityQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Opportunity table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\OpportunityQuery The inner query object of the EXISTS statement
     */
    public function useOpportunityExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Opportunity', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Opportunity table for a NOT EXISTS query.
     *
     * @see useOpportunityExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\OpportunityQuery The inner query object of the NOT EXISTS statement
     */
    public function useOpportunityNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Opportunity', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByJobStatusSf($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_JOB_STATUS_SF_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_JOB_STATUS_SF_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByJobStatusSf() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the JobStatusSf relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinJobStatusSf($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('JobStatusSf');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'JobStatusSf');
        }

        return $this;
    }

    /**
     * Use the JobStatusSf relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useJobStatusSfQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinJobStatusSf($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'JobStatusSf', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the JobStatusSf relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withJobStatusSfQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useJobStatusSfQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the JobStatusSf relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useJobStatusSfExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('JobStatusSf', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the JobStatusSf relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useJobStatusSfExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useJobStatusSfNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('JobStatusSf', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByJobQualification($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByJobQualification() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the JobQualification relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinJobQualification($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('JobQualification');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'JobQualification');
        }

        return $this;
    }

    /**
     * Use the JobQualification relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useJobQualificationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinJobQualification($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'JobQualification', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the JobQualification relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withJobQualificationQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useJobQualificationQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the JobQualification relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useJobQualificationExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('JobQualification', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the JobQualification relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useJobQualificationExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useJobQualificationNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('JobQualification', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\SiJobType object
     *
     * @param \Model\SiJobType|ObjectCollection $siJobType The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySiJobType($siJobType, $comparison = null)
    {
        if ($siJobType instanceof \Model\SiJobType) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_SI_JOB_TYPE_ID, $siJobType->getId(), $comparison);
        } elseif ($siJobType instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_SI_JOB_TYPE_ID, $siJobType->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterBySiJobType() only accepts arguments of type \Model\SiJobType or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the SiJobType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinSiJobType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('SiJobType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'SiJobType');
        }

        return $this;
    }

    /**
     * Use the SiJobType relation SiJobType object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\SiJobTypeQuery A secondary query class using the current class as primary query
     */
    public function useSiJobTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinSiJobType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'SiJobType', '\Model\SiJobTypeQuery');
    }

    /**
     * Use the SiJobType relation SiJobType object
     *
     * @param callable(\Model\SiJobTypeQuery):\Model\SiJobTypeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withSiJobTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useSiJobTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to SiJobType table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\SiJobTypeQuery The inner query object of the EXISTS statement
     */
    public function useSiJobTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('SiJobType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to SiJobType table for a NOT EXISTS query.
     *
     * @see useSiJobTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\SiJobTypeQuery The inner query object of the NOT EXISTS statement
     */
    public function useSiJobTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('SiJobType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Contact object
     *
     * @param \Model\Contact|ObjectCollection $contact The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClientContact($contact, $comparison = null)
    {
        if ($contact instanceof \Model\Contact) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $contact->getId(), $comparison);
        } elseif ($contact instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $contact->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEndClientContact() only accepts arguments of type \Model\Contact or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EndClientContact relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEndClientContact($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EndClientContact');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EndClientContact');
        }

        return $this;
    }

    /**
     * Use the EndClientContact relation Contact object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ContactQuery A secondary query class using the current class as primary query
     */
    public function useEndClientContactQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEndClientContact($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EndClientContact', '\Model\ContactQuery');
    }

    /**
     * Use the EndClientContact relation Contact object
     *
     * @param callable(\Model\ContactQuery):\Model\ContactQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEndClientContactQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEndClientContactQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EndClientContact relation to the Contact table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ContactQuery The inner query object of the EXISTS statement
     */
    public function useEndClientContactExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EndClientContact', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EndClientContact relation to the Contact table for a NOT EXISTS query.
     *
     * @see useEndClientContactExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ContactQuery The inner query object of the NOT EXISTS statement
     */
    public function useEndClientContactNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EndClientContact', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByGermanJobType($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByGermanJobType() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the GermanJobType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinGermanJobType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('GermanJobType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'GermanJobType');
        }

        return $this;
    }

    /**
     * Use the GermanJobType relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useGermanJobTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinGermanJobType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'GermanJobType', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the GermanJobType relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withGermanJobTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useGermanJobTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the GermanJobType relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useGermanJobTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('GermanJobType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the GermanJobType relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useGermanJobTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useGermanJobTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('GermanJobType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Account object
     *
     * @param \Model\Account|ObjectCollection $account The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEndClient($account, $comparison = null)
    {
        if ($account instanceof \Model\Account) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_END_CLIENT_ID, $account->getId(), $comparison);
        } elseif ($account instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_END_CLIENT_ID, $account->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEndClient() only accepts arguments of type \Model\Account or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EndClient relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEndClient($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EndClient');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EndClient');
        }

        return $this;
    }

    /**
     * Use the EndClient relation Account object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AccountQuery A secondary query class using the current class as primary query
     */
    public function useEndClientQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEndClient($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EndClient', '\Model\AccountQuery');
    }

    /**
     * Use the EndClient relation Account object
     *
     * @param callable(\Model\AccountQuery):\Model\AccountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEndClientQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEndClientQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EndClient relation to the Account table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AccountQuery The inner query object of the EXISTS statement
     */
    public function useEndClientExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EndClient', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EndClient relation to the Account table for a NOT EXISTS query.
     *
     * @see useEndClientExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AccountQuery The inner query object of the NOT EXISTS statement
     */
    public function useEndClientNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EndClient', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Account object
     *
     * @param \Model\Account|ObjectCollection $account The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAccount($account, $comparison = null)
    {
        if ($account instanceof \Model\Account) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_ID, $account->getId(), $comparison);
        } elseif ($account instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_ID, $account->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAccount() only accepts arguments of type \Model\Account or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Account relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinAccount($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Account');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Account');
        }

        return $this;
    }

    /**
     * Use the Account relation Account object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AccountQuery A secondary query class using the current class as primary query
     */
    public function useAccountQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAccount($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Account', '\Model\AccountQuery');
    }

    /**
     * Use the Account relation Account object
     *
     * @param callable(\Model\AccountQuery):\Model\AccountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAccountQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAccountQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Account table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AccountQuery The inner query object of the EXISTS statement
     */
    public function useAccountExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Account table for a NOT EXISTS query.
     *
     * @see useAccountExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AccountQuery The inner query object of the NOT EXISTS statement
     */
    public function useAccountNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Industry object
     *
     * @param \Model\Industry|ObjectCollection $industry The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIndustry($industry, $comparison = null)
    {
        if ($industry instanceof \Model\Industry) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_INDUSTRY_ID, $industry->getId(), $comparison);
        } elseif ($industry instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_INDUSTRY_ID, $industry->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByIndustry() only accepts arguments of type \Model\Industry or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Industry relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinIndustry($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Industry');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Industry');
        }

        return $this;
    }

    /**
     * Use the Industry relation Industry object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\IndustryQuery A secondary query class using the current class as primary query
     */
    public function useIndustryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinIndustry($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Industry', '\Model\IndustryQuery');
    }

    /**
     * Use the Industry relation Industry object
     *
     * @param callable(\Model\IndustryQuery):\Model\IndustryQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withIndustryQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useIndustryQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Industry table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\IndustryQuery The inner query object of the EXISTS statement
     */
    public function useIndustryExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Industry', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Industry table for a NOT EXISTS query.
     *
     * @see useIndustryExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\IndustryQuery The inner query object of the NOT EXISTS statement
     */
    public function useIndustryNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Industry', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Location object
     *
     * @param \Model\Location|ObjectCollection $location The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeLocation($location, $comparison = null)
    {
        if ($location instanceof \Model\Location) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_LOCATION_PNL, $location->getId(), $comparison);
        } elseif ($location instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_LOCATION_PNL, $location->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeLocation() only accepts arguments of type \Model\Location or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeLocation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeLocation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeLocation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeLocation');
        }

        return $this;
    }

    /**
     * Use the EtudeLocation relation Location object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\LocationQuery A secondary query class using the current class as primary query
     */
    public function useEtudeLocationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeLocation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeLocation', '\Model\LocationQuery');
    }

    /**
     * Use the EtudeLocation relation Location object
     *
     * @param callable(\Model\LocationQuery):\Model\LocationQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeLocationQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeLocationQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EtudeLocation relation to the Location table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\LocationQuery The inner query object of the EXISTS statement
     */
    public function useEtudeLocationExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeLocation', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EtudeLocation relation to the Location table for a NOT EXISTS query.
     *
     * @see useEtudeLocationExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\LocationQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeLocationNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeLocation', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\ProjectLocationPrefix object
     *
     * @param \Model\ProjectLocationPrefix|ObjectCollection $projectLocationPrefix The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProjectLocationPrefix($projectLocationPrefix, $comparison = null)
    {
        if ($projectLocationPrefix instanceof \Model\ProjectLocationPrefix) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $projectLocationPrefix->getId(), $comparison);
        } elseif ($projectLocationPrefix instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $projectLocationPrefix->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByProjectLocationPrefix() only accepts arguments of type \Model\ProjectLocationPrefix or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ProjectLocationPrefix relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinProjectLocationPrefix($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ProjectLocationPrefix');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ProjectLocationPrefix');
        }

        return $this;
    }

    /**
     * Use the ProjectLocationPrefix relation ProjectLocationPrefix object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ProjectLocationPrefixQuery A secondary query class using the current class as primary query
     */
    public function useProjectLocationPrefixQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinProjectLocationPrefix($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ProjectLocationPrefix', '\Model\ProjectLocationPrefixQuery');
    }

    /**
     * Use the ProjectLocationPrefix relation ProjectLocationPrefix object
     *
     * @param callable(\Model\ProjectLocationPrefixQuery):\Model\ProjectLocationPrefixQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withProjectLocationPrefixQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useProjectLocationPrefixQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to ProjectLocationPrefix table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ProjectLocationPrefixQuery The inner query object of the EXISTS statement
     */
    public function useProjectLocationPrefixExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('ProjectLocationPrefix', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to ProjectLocationPrefix table for a NOT EXISTS query.
     *
     * @see useProjectLocationPrefixExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ProjectLocationPrefixQuery The inner query object of the NOT EXISTS statement
     */
    public function useProjectLocationPrefixNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('ProjectLocationPrefix', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Contact object
     *
     * @param \Model\Contact|ObjectCollection $contact The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByContactClientPm($contact, $comparison = null)
    {
        if ($contact instanceof \Model\Contact) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $contact->getId(), $comparison);
        } elseif ($contact instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $contact->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByContactClientPm() only accepts arguments of type \Model\Contact or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ContactClientPm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinContactClientPm($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ContactClientPm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ContactClientPm');
        }

        return $this;
    }

    /**
     * Use the ContactClientPm relation Contact object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ContactQuery A secondary query class using the current class as primary query
     */
    public function useContactClientPmQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinContactClientPm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ContactClientPm', '\Model\ContactQuery');
    }

    /**
     * Use the ContactClientPm relation Contact object
     *
     * @param callable(\Model\ContactQuery):\Model\ContactQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withContactClientPmQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useContactClientPmQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the ContactClientPm relation to the Contact table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ContactQuery The inner query object of the EXISTS statement
     */
    public function useContactClientPmExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('ContactClientPm', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the ContactClientPm relation to the Contact table for a NOT EXISTS query.
     *
     * @see useContactClientPmExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ContactQuery The inner query object of the NOT EXISTS statement
     */
    public function useContactClientPmNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('ContactClientPm', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByBM($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_BM, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_BM, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByBM() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BM relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinBM($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BM');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BM');
        }

        return $this;
    }

    /**
     * Use the BM relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useBMQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinBM($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BM', '\Model\UserQuery');
    }

    /**
     * Use the BM relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withBMQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useBMQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the BM relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useBMExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('BM', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the BM relation to the User table for a NOT EXISTS query.
     *
     * @see useBMExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useBMNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('BM', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeProjectManager($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_PM, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_PM, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeProjectManager() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeProjectManager relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeProjectManager($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeProjectManager');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeProjectManager');
        }

        return $this;
    }

    /**
     * Use the EtudeProjectManager relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useEtudeProjectManagerQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeProjectManager($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeProjectManager', '\Model\UserQuery');
    }

    /**
     * Use the EtudeProjectManager relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeProjectManagerQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeProjectManagerQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EtudeProjectManager relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useEtudeProjectManagerExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeProjectManager', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EtudeProjectManager relation to the User table for a NOT EXISTS query.
     *
     * @see useEtudeProjectManagerExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeProjectManagerNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeProjectManager', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeGroup object
     *
     * @param \Model\EtudeGroup|ObjectCollection $etudeGroup The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeGroup($etudeGroup, $comparison = null)
    {
        if ($etudeGroup instanceof \Model\EtudeGroup) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_ETUDE_GROUP, $etudeGroup->getId(), $comparison);
        } elseif ($etudeGroup instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID_ETUDE_GROUP, $etudeGroup->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeGroup() only accepts arguments of type \Model\EtudeGroup or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeGroup relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeGroup($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeGroup');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeGroup');
        }

        return $this;
    }

    /**
     * Use the EtudeGroup relation EtudeGroup object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeGroupQuery A secondary query class using the current class as primary query
     */
    public function useEtudeGroupQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeGroup($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeGroup', '\Model\EtudeGroupQuery');
    }

    /**
     * Use the EtudeGroup relation EtudeGroup object
     *
     * @param callable(\Model\EtudeGroupQuery):\Model\EtudeGroupQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeGroupQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeGroupQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeGroup table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeGroupQuery The inner query object of the EXISTS statement
     */
    public function useEtudeGroupExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeGroup', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeGroup table for a NOT EXISTS query.
     *
     * @see useEtudeGroupExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeGroupQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeGroupNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeGroup', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Area object
     *
     * @param \Model\Area|ObjectCollection $area The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeArea($area, $comparison = null)
    {
        if ($area instanceof \Model\Area) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_AREA_ID, $area->getId(), $comparison);
        } elseif ($area instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_AREA_ID, $area->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeArea() only accepts arguments of type \Model\Area or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeArea relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeArea($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeArea');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeArea');
        }

        return $this;
    }

    /**
     * Use the EtudeArea relation Area object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AreaQuery A secondary query class using the current class as primary query
     */
    public function useEtudeAreaQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeArea($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeArea', '\Model\AreaQuery');
    }

    /**
     * Use the EtudeArea relation Area object
     *
     * @param callable(\Model\AreaQuery):\Model\AreaQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeAreaQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeAreaQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EtudeArea relation to the Area table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AreaQuery The inner query object of the EXISTS statement
     */
    public function useEtudeAreaExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeArea', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EtudeArea relation to the Area table for a NOT EXISTS query.
     *
     * @see useEtudeAreaExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AreaQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeAreaNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeArea', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCurrencyIsoCode($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByCurrencyIsoCode() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the CurrencyIsoCode relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinCurrencyIsoCode($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('CurrencyIsoCode');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'CurrencyIsoCode');
        }

        return $this;
    }

    /**
     * Use the CurrencyIsoCode relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useCurrencyIsoCodeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinCurrencyIsoCode($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'CurrencyIsoCode', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the CurrencyIsoCode relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withCurrencyIsoCodeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useCurrencyIsoCodeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the CurrencyIsoCode relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useCurrencyIsoCodeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('CurrencyIsoCode', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the CurrencyIsoCode relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useCurrencyIsoCodeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useCurrencyIsoCodeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('CurrencyIsoCode', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForce object
     *
     * @param \Model\RefSalesForce|ObjectCollection $refSalesForce The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByClientListDeletion($refSalesForce, $comparison = null)
    {
        if ($refSalesForce instanceof \Model\RefSalesForce) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $refSalesForce->getId(), $comparison);
        } elseif ($refSalesForce instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $refSalesForce->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByClientListDeletion() only accepts arguments of type \Model\RefSalesForce or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ClientListDeletion relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinClientListDeletion($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ClientListDeletion');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ClientListDeletion');
        }

        return $this;
    }

    /**
     * Use the ClientListDeletion relation RefSalesForce object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceQuery A secondary query class using the current class as primary query
     */
    public function useClientListDeletionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinClientListDeletion($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ClientListDeletion', '\Model\RefSalesForceQuery');
    }

    /**
     * Use the ClientListDeletion relation RefSalesForce object
     *
     * @param callable(\Model\RefSalesForceQuery):\Model\RefSalesForceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withClientListDeletionQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useClientListDeletionQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the ClientListDeletion relation to the RefSalesForce table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceQuery The inner query object of the EXISTS statement
     */
    public function useClientListDeletionExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('ClientListDeletion', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the ClientListDeletion relation to the RefSalesForce table for a NOT EXISTS query.
     *
     * @see useClientListDeletionExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceQuery The inner query object of the NOT EXISTS statement
     */
    public function useClientListDeletionNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('ClientListDeletion', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_CREATED_BY_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_CREATED_BY_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByCreatedBy() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the CreatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinCreatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('CreatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'CreatedBy');
        }

        return $this;
    }

    /**
     * Use the CreatedBy relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useCreatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinCreatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'CreatedBy', '\Model\UserQuery');
    }

    /**
     * Use the CreatedBy relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withCreatedByQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useCreatedByQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the CreatedBy relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useCreatedByExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('CreatedBy', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the CreatedBy relation to the User table for a NOT EXISTS query.
     *
     * @see useCreatedByExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useCreatedByNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('CreatedBy', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByUpdatedBy($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_UPDATED_BY_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_UPDATED_BY_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByUpdatedBy() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the UpdatedBy relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinUpdatedBy($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('UpdatedBy');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'UpdatedBy');
        }

        return $this;
    }

    /**
     * Use the UpdatedBy relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useUpdatedByQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinUpdatedBy($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'UpdatedBy', '\Model\UserQuery');
    }

    /**
     * Use the UpdatedBy relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withUpdatedByQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useUpdatedByQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the UpdatedBy relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useUpdatedByExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('UpdatedBy', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the UpdatedBy relation to the User table for a NOT EXISTS query.
     *
     * @see useUpdatedByExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useUpdatedByNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('UpdatedBy', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Contact object
     *
     * @param \Model\Contact|ObjectCollection $contact The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByIntermediateClientContact($contact, $comparison = null)
    {
        if ($contact instanceof \Model\Contact) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $contact->getId(), $comparison);
        } elseif ($contact instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $contact->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByIntermediateClientContact() only accepts arguments of type \Model\Contact or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the IntermediateClientContact relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinIntermediateClientContact($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('IntermediateClientContact');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'IntermediateClientContact');
        }

        return $this;
    }

    /**
     * Use the IntermediateClientContact relation Contact object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ContactQuery A secondary query class using the current class as primary query
     */
    public function useIntermediateClientContactQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinIntermediateClientContact($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'IntermediateClientContact', '\Model\ContactQuery');
    }

    /**
     * Use the IntermediateClientContact relation Contact object
     *
     * @param callable(\Model\ContactQuery):\Model\ContactQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withIntermediateClientContactQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useIntermediateClientContactQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the IntermediateClientContact relation to the Contact table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ContactQuery The inner query object of the EXISTS statement
     */
    public function useIntermediateClientContactExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('IntermediateClientContact', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the IntermediateClientContact relation to the Contact table for a NOT EXISTS query.
     *
     * @see useIntermediateClientContactExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ContactQuery The inner query object of the NOT EXISTS statement
     */
    public function useIntermediateClientContactNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('IntermediateClientContact', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProjectAccountManager($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByProjectAccountManager() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ProjectAccountManager relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinProjectAccountManager($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ProjectAccountManager');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ProjectAccountManager');
        }

        return $this;
    }

    /**
     * Use the ProjectAccountManager relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useProjectAccountManagerQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinProjectAccountManager($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ProjectAccountManager', '\Model\UserQuery');
    }

    /**
     * Use the ProjectAccountManager relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withProjectAccountManagerQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useProjectAccountManagerQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the ProjectAccountManager relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useProjectAccountManagerExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('ProjectAccountManager', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the ProjectAccountManager relation to the User table for a NOT EXISTS query.
     *
     * @see useProjectAccountManagerExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useProjectAccountManagerNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('ProjectAccountManager', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\User object
     *
     * @param \Model\User|ObjectCollection $user The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByProjectSpecialtySponsor($user, $comparison = null)
    {
        if ($user instanceof \Model\User) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $user->getId(), $comparison);
        } elseif ($user instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $user->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByProjectSpecialtySponsor() only accepts arguments of type \Model\User or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the ProjectSpecialtySponsor relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinProjectSpecialtySponsor($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('ProjectSpecialtySponsor');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'ProjectSpecialtySponsor');
        }

        return $this;
    }

    /**
     * Use the ProjectSpecialtySponsor relation User object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\UserQuery A secondary query class using the current class as primary query
     */
    public function useProjectSpecialtySponsorQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinProjectSpecialtySponsor($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'ProjectSpecialtySponsor', '\Model\UserQuery');
    }

    /**
     * Use the ProjectSpecialtySponsor relation User object
     *
     * @param callable(\Model\UserQuery):\Model\UserQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withProjectSpecialtySponsorQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useProjectSpecialtySponsorQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the ProjectSpecialtySponsor relation to the User table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\UserQuery The inner query object of the EXISTS statement
     */
    public function useProjectSpecialtySponsorExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('ProjectSpecialtySponsor', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the ProjectSpecialtySponsor relation to the User table for a NOT EXISTS query.
     *
     * @see useProjectSpecialtySponsorExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\UserQuery The inner query object of the NOT EXISTS statement
     */
    public function useProjectSpecialtySponsorNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('ProjectSpecialtySponsor', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\AmReasonType object
     *
     * @param \Model\AmReasonType|ObjectCollection $amReasonType The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByAmReasonType($amReasonType, $comparison = null)
    {
        if ($amReasonType instanceof \Model\AmReasonType) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_AM_REASON_TYPE_ID, $amReasonType->getId(), $comparison);
        } elseif ($amReasonType instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeTableMap::COL_AM_REASON_TYPE_ID, $amReasonType->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAmReasonType() only accepts arguments of type \Model\AmReasonType or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the AmReasonType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinAmReasonType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('AmReasonType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'AmReasonType');
        }

        return $this;
    }

    /**
     * Use the AmReasonType relation AmReasonType object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AmReasonTypeQuery A secondary query class using the current class as primary query
     */
    public function useAmReasonTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAmReasonType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'AmReasonType', '\Model\AmReasonTypeQuery');
    }

    /**
     * Use the AmReasonType relation AmReasonType object
     *
     * @param callable(\Model\AmReasonTypeQuery):\Model\AmReasonTypeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAmReasonTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAmReasonTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to AmReasonType table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AmReasonTypeQuery The inner query object of the EXISTS statement
     */
    public function useAmReasonTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('AmReasonType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to AmReasonType table for a NOT EXISTS query.
     *
     * @see useAmReasonTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AmReasonTypeQuery The inner query object of the NOT EXISTS statement
     */
    public function useAmReasonTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('AmReasonType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\DernierAcces object
     *
     * @param \Model\DernierAcces|ObjectCollection $dernierAcces the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByDernierAcces($dernierAcces, $comparison = null)
    {
        if ($dernierAcces instanceof \Model\DernierAcces) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $dernierAcces->getIdEtude(), $comparison);
        } elseif ($dernierAcces instanceof ObjectCollection) {
            return $this
                ->useDernierAccesQuery()
                ->filterByPrimaryKeys($dernierAcces->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByDernierAcces() only accepts arguments of type \Model\DernierAcces or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the DernierAcces relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinDernierAcces($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('DernierAcces');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'DernierAcces');
        }

        return $this;
    }

    /**
     * Use the DernierAcces relation DernierAcces object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\DernierAccesQuery A secondary query class using the current class as primary query
     */
    public function useDernierAccesQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinDernierAcces($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'DernierAcces', '\Model\DernierAccesQuery');
    }

    /**
     * Use the DernierAcces relation DernierAcces object
     *
     * @param callable(\Model\DernierAccesQuery):\Model\DernierAccesQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withDernierAccesQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useDernierAccesQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to DernierAcces table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\DernierAccesQuery The inner query object of the EXISTS statement
     */
    public function useDernierAccesExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('DernierAcces', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to DernierAcces table for a NOT EXISTS query.
     *
     * @see useDernierAccesExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\DernierAccesQuery The inner query object of the NOT EXISTS statement
     */
    public function useDernierAccesNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('DernierAcces', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeSampleSource object
     *
     * @param \Model\EtudeSampleSource|ObjectCollection $etudeSampleSource the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeSampleSource($etudeSampleSource, $comparison = null)
    {
        if ($etudeSampleSource instanceof \Model\EtudeSampleSource) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $etudeSampleSource->getEtudeId(), $comparison);
        } elseif ($etudeSampleSource instanceof ObjectCollection) {
            return $this
                ->useEtudeSampleSourceQuery()
                ->filterByPrimaryKeys($etudeSampleSource->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeSampleSource() only accepts arguments of type \Model\EtudeSampleSource or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeSampleSource relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeSampleSource($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeSampleSource');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeSampleSource');
        }

        return $this;
    }

    /**
     * Use the EtudeSampleSource relation EtudeSampleSource object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeSampleSourceQuery A secondary query class using the current class as primary query
     */
    public function useEtudeSampleSourceQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeSampleSource($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeSampleSource', '\Model\EtudeSampleSourceQuery');
    }

    /**
     * Use the EtudeSampleSource relation EtudeSampleSource object
     *
     * @param callable(\Model\EtudeSampleSourceQuery):\Model\EtudeSampleSourceQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeSampleSourceQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeSampleSourceQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeSampleSource table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeSampleSourceQuery The inner query object of the EXISTS statement
     */
    public function useEtudeSampleSourceExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeSampleSource', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeSampleSource table for a NOT EXISTS query.
     *
     * @see useEtudeSampleSourceExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeSampleSourceQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeSampleSourceNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeSampleSource', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeMethodology object
     *
     * @param \Model\EtudeMethodology|ObjectCollection $etudeMethodology the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeMethodology($etudeMethodology, $comparison = null)
    {
        if ($etudeMethodology instanceof \Model\EtudeMethodology) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $etudeMethodology->getEtudeId(), $comparison);
        } elseif ($etudeMethodology instanceof ObjectCollection) {
            return $this
                ->useEtudeMethodologyQuery()
                ->filterByPrimaryKeys($etudeMethodology->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeMethodology() only accepts arguments of type \Model\EtudeMethodology or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeMethodology relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeMethodology($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeMethodology');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeMethodology');
        }

        return $this;
    }

    /**
     * Use the EtudeMethodology relation EtudeMethodology object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeMethodologyQuery A secondary query class using the current class as primary query
     */
    public function useEtudeMethodologyQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeMethodology($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeMethodology', '\Model\EtudeMethodologyQuery');
    }

    /**
     * Use the EtudeMethodology relation EtudeMethodology object
     *
     * @param callable(\Model\EtudeMethodologyQuery):\Model\EtudeMethodologyQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeMethodologyQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeMethodologyQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeMethodology table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeMethodologyQuery The inner query object of the EXISTS statement
     */
    public function useEtudeMethodologyExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeMethodology', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeMethodology table for a NOT EXISTS query.
     *
     * @see useEtudeMethodologyExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeMethodologyQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeMethodologyNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeMethodology', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Facture object
     *
     * @param \Model\Facture|ObjectCollection $facture the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByFacture($facture, $comparison = null)
    {
        if ($facture instanceof \Model\Facture) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $facture->getIdEtude(), $comparison);
        } elseif ($facture instanceof ObjectCollection) {
            return $this
                ->useFactureQuery()
                ->filterByPrimaryKeys($facture->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByFacture() only accepts arguments of type \Model\Facture or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Facture relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinFacture($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Facture');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Facture');
        }

        return $this;
    }

    /**
     * Use the Facture relation Facture object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\FactureQuery A secondary query class using the current class as primary query
     */
    public function useFactureQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinFacture($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Facture', '\Model\FactureQuery');
    }

    /**
     * Use the Facture relation Facture object
     *
     * @param callable(\Model\FactureQuery):\Model\FactureQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withFactureQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useFactureQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Facture table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\FactureQuery The inner query object of the EXISTS statement
     */
    public function useFactureExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Facture', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Facture table for a NOT EXISTS query.
     *
     * @see useFactureExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\FactureQuery The inner query object of the NOT EXISTS statement
     */
    public function useFactureNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Facture', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Job object
     *
     * @param \Model\Job|ObjectCollection $job the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByJobEtude($job, $comparison = null)
    {
        if ($job instanceof \Model\Job) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $job->getEtudeId(), $comparison);
        } elseif ($job instanceof ObjectCollection) {
            return $this
                ->useJobEtudeQuery()
                ->filterByPrimaryKeys($job->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByJobEtude() only accepts arguments of type \Model\Job or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the JobEtude relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinJobEtude($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('JobEtude');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'JobEtude');
        }

        return $this;
    }

    /**
     * Use the JobEtude relation Job object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\JobQuery A secondary query class using the current class as primary query
     */
    public function useJobEtudeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinJobEtude($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'JobEtude', '\Model\JobQuery');
    }

    /**
     * Use the JobEtude relation Job object
     *
     * @param callable(\Model\JobQuery):\Model\JobQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withJobEtudeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useJobEtudeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the JobEtude relation to the Job table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\JobQuery The inner query object of the EXISTS statement
     */
    public function useJobEtudeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('JobEtude', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the JobEtude relation to the Job table for a NOT EXISTS query.
     *
     * @see useJobEtudeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\JobQuery The inner query object of the NOT EXISTS statement
     */
    public function useJobEtudeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('JobEtude', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Reglement object
     *
     * @param \Model\Reglement|ObjectCollection $reglement the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByReglement($reglement, $comparison = null)
    {
        if ($reglement instanceof \Model\Reglement) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $reglement->getIdEtude(), $comparison);
        } elseif ($reglement instanceof ObjectCollection) {
            return $this
                ->useReglementQuery()
                ->filterByPrimaryKeys($reglement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByReglement() only accepts arguments of type \Model\Reglement or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Reglement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinReglement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Reglement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Reglement');
        }

        return $this;
    }

    /**
     * Use the Reglement relation Reglement object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\ReglementQuery A secondary query class using the current class as primary query
     */
    public function useReglementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinReglement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Reglement', '\Model\ReglementQuery');
    }

    /**
     * Use the Reglement relation Reglement object
     *
     * @param callable(\Model\ReglementQuery):\Model\ReglementQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withReglementQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useReglementQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Reglement table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\ReglementQuery The inner query object of the EXISTS statement
     */
    public function useReglementExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Reglement', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Reglement table for a NOT EXISTS query.
     *
     * @see useReglementExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\ReglementQuery The inner query object of the NOT EXISTS statement
     */
    public function useReglementNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Reglement', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\RefSalesForceEtudeSector object
     *
     * @param \Model\RefSalesForceEtudeSector|ObjectCollection $refSalesForceEtudeSector the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySector($refSalesForceEtudeSector, $comparison = null)
    {
        if ($refSalesForceEtudeSector instanceof \Model\RefSalesForceEtudeSector) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $refSalesForceEtudeSector->getEtudeId(), $comparison);
        } elseif ($refSalesForceEtudeSector instanceof ObjectCollection) {
            return $this
                ->useSectorQuery()
                ->filterByPrimaryKeys($refSalesForceEtudeSector->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterBySector() only accepts arguments of type \Model\RefSalesForceEtudeSector or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Sector relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinSector($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Sector');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Sector');
        }

        return $this;
    }

    /**
     * Use the Sector relation RefSalesForceEtudeSector object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\RefSalesForceEtudeSectorQuery A secondary query class using the current class as primary query
     */
    public function useSectorQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinSector($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Sector', '\Model\RefSalesForceEtudeSectorQuery');
    }

    /**
     * Use the Sector relation RefSalesForceEtudeSector object
     *
     * @param callable(\Model\RefSalesForceEtudeSectorQuery):\Model\RefSalesForceEtudeSectorQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withSectorQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useSectorQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the Sector relation to the RefSalesForceEtudeSector table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\RefSalesForceEtudeSectorQuery The inner query object of the EXISTS statement
     */
    public function useSectorExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Sector', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the Sector relation to the RefSalesForceEtudeSector table for a NOT EXISTS query.
     *
     * @see useSectorExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\RefSalesForceEtudeSectorQuery The inner query object of the NOT EXISTS statement
     */
    public function useSectorNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Sector', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeCheckListValidation object
     *
     * @param \Model\EtudeCheckListValidation|ObjectCollection $etudeCheckListValidation the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeCheckListValidation($etudeCheckListValidation, $comparison = null)
    {
        if ($etudeCheckListValidation instanceof \Model\EtudeCheckListValidation) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $etudeCheckListValidation->getEtudeId(), $comparison);
        } elseif ($etudeCheckListValidation instanceof ObjectCollection) {
            return $this
                ->useEtudeCheckListValidationQuery()
                ->filterByPrimaryKeys($etudeCheckListValidation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeCheckListValidation() only accepts arguments of type \Model\EtudeCheckListValidation or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeCheckListValidation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeCheckListValidation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeCheckListValidation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeCheckListValidation');
        }

        return $this;
    }

    /**
     * Use the EtudeCheckListValidation relation EtudeCheckListValidation object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeCheckListValidationQuery A secondary query class using the current class as primary query
     */
    public function useEtudeCheckListValidationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeCheckListValidation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeCheckListValidation', '\Model\EtudeCheckListValidationQuery');
    }

    /**
     * Use the EtudeCheckListValidation relation EtudeCheckListValidation object
     *
     * @param callable(\Model\EtudeCheckListValidationQuery):\Model\EtudeCheckListValidationQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeCheckListValidationQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeCheckListValidationQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeCheckListValidation table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeCheckListValidationQuery The inner query object of the EXISTS statement
     */
    public function useEtudeCheckListValidationExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeCheckListValidation', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeCheckListValidation table for a NOT EXISTS query.
     *
     * @see useEtudeCheckListValidationExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeCheckListValidationQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeCheckListValidationNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeCheckListValidation', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeFichier object
     *
     * @param \Model\EtudeFichier|ObjectCollection $etudeFichier the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByEtudeFichier($etudeFichier, $comparison = null)
    {
        if ($etudeFichier instanceof \Model\EtudeFichier) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $etudeFichier->getEtudeId(), $comparison);
        } elseif ($etudeFichier instanceof ObjectCollection) {
            return $this
                ->useEtudeFichierQuery()
                ->filterByPrimaryKeys($etudeFichier->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeFichier() only accepts arguments of type \Model\EtudeFichier or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeFichier relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinEtudeFichier($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeFichier');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeFichier');
        }

        return $this;
    }

    /**
     * Use the EtudeFichier relation EtudeFichier object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeFichierQuery A secondary query class using the current class as primary query
     */
    public function useEtudeFichierQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeFichier($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeFichier', '\Model\EtudeFichierQuery');
    }

    /**
     * Use the EtudeFichier relation EtudeFichier object
     *
     * @param callable(\Model\EtudeFichierQuery):\Model\EtudeFichierQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeFichierQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeFichierQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeFichier table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeFichierQuery The inner query object of the EXISTS statement
     */
    public function useEtudeFichierExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeFichier', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeFichier table for a NOT EXISTS query.
     *
     * @see useEtudeFichierExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeFichierQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeFichierNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeFichier', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\LogProjectStatus object
     *
     * @param \Model\LogProjectStatus|ObjectCollection $logProjectStatus the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByLogProjectStatus($logProjectStatus, $comparison = null)
    {
        if ($logProjectStatus instanceof \Model\LogProjectStatus) {
            return $this
                ->addUsingAlias(EtudeTableMap::COL_ID, $logProjectStatus->getEtudeId(), $comparison);
        } elseif ($logProjectStatus instanceof ObjectCollection) {
            return $this
                ->useLogProjectStatusQuery()
                ->filterByPrimaryKeys($logProjectStatus->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByLogProjectStatus() only accepts arguments of type \Model\LogProjectStatus or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the LogProjectStatus relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function joinLogProjectStatus($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('LogProjectStatus');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'LogProjectStatus');
        }

        return $this;
    }

    /**
     * Use the LogProjectStatus relation LogProjectStatus object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\LogProjectStatusQuery A secondary query class using the current class as primary query
     */
    public function useLogProjectStatusQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinLogProjectStatus($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'LogProjectStatus', '\Model\LogProjectStatusQuery');
    }

    /**
     * Use the LogProjectStatus relation LogProjectStatus object
     *
     * @param callable(\Model\LogProjectStatusQuery):\Model\LogProjectStatusQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withLogProjectStatusQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useLogProjectStatusQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to LogProjectStatus table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\LogProjectStatusQuery The inner query object of the EXISTS statement
     */
    public function useLogProjectStatusExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('LogProjectStatus', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to LogProjectStatus table for a NOT EXISTS query.
     *
     * @see useLogProjectStatusExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\LogProjectStatusQuery The inner query object of the NOT EXISTS statement
     */
    public function useLogProjectStatusNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('LogProjectStatus', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related SampleSource object
     * using the etude_sample_source table as cross reference
     *
     * @param SampleSource $sampleSource the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterBySampleSource($sampleSource, $comparison = Criteria::EQUAL)
    {
        return $this
            ->useEtudeSampleSourceQuery()
            ->filterBySampleSource($sampleSource, $comparison)
            ->endUse();
    }

    /**
     * Filter the query by a related Methodology object
     * using the etude_methodology table as cross reference
     *
     * @param Methodology $methodology the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByMethodology($methodology, $comparison = Criteria::EQUAL)
    {
        return $this
            ->useEtudeMethodologyQuery()
            ->filterByMethodology($methodology, $comparison)
            ->endUse();
    }

    /**
     * Filter the query by a related RefSalesForce object
     * using the sf_ref_salesforce_etude_sector table as cross reference
     *
     * @param RefSalesForce $refSalesForce the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeQuery The current query, for fluid interface
     */
    public function filterByRefSalesForceEtudeRefSector($refSalesForce, $comparison = Criteria::EQUAL)
    {
        return $this
            ->useSectorQuery()
            ->filterByRefSalesForceEtudeRefSector($refSalesForce, $comparison)
            ->endUse();
    }

    /**
     * Exclude object from result
     *
     * @param   ChildEtude $etude Object to remove from the list of results
     *
     * @return $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function prune($etude = null)
    {
        if ($etude) {
            $this->addUsingAlias(EtudeTableMap::COL_ID, $etude->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the etude table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtudeTableMap::clearInstancePool();
            EtudeTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtudeTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtudeTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtudeTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(EtudeTableMap::COL_UPDATED_AT, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(EtudeTableMap::COL_UPDATED_AT);
    }

    /**
     * Order by update date asc
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(EtudeTableMap::COL_UPDATED_AT);
    }

    /**
     * Order by create date desc
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(EtudeTableMap::COL_CREATED_AT);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(EtudeTableMap::COL_CREATED_AT, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date asc
     *
     * @return     $this|ChildEtudeQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(EtudeTableMap::COL_CREATED_AT);
    }

} // EtudeQuery
