<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\SfOpportunityMethodology as ChildSfOpportunityMethodology;
use Model\SfOpportunityMethodologyQuery as ChildSfOpportunityMethodologyQuery;
use Model\Map\SfOpportunityMethodologyTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'sf_opportunity_methodology' table.
 *
 *
 *
 * @method     ChildSfOpportunityMethodologyQuery orderByRefMethodologyId($order = Criteria::ASC) Order by the ref_methodology_id column
 * @method     ChildSfOpportunityMethodologyQuery orderByOpportunityId($order = Criteria::ASC) Order by the opportunity_id column
 * @method     ChildSfOpportunityMethodologyQuery orderByApiCreatedDate($order = Criteria::ASC) Order by the api_created_date column
 * @method     ChildSfOpportunityMethodologyQuery orderByApiUpdatedDate($order = Criteria::ASC) Order by the api_updated_date column
 *
 * @method     ChildSfOpportunityMethodologyQuery groupByRefMethodologyId() Group by the ref_methodology_id column
 * @method     ChildSfOpportunityMethodologyQuery groupByOpportunityId() Group by the opportunity_id column
 * @method     ChildSfOpportunityMethodologyQuery groupByApiCreatedDate() Group by the api_created_date column
 * @method     ChildSfOpportunityMethodologyQuery groupByApiUpdatedDate() Group by the api_updated_date column
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildSfOpportunityMethodologyQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildSfOpportunityMethodologyQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildSfOpportunityMethodologyQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildSfOpportunityMethodologyQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoinSalesForceOpportunityMethodology($relationAlias = null) Adds a LEFT JOIN clause to the query using the SalesForceOpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery rightJoinSalesForceOpportunityMethodology($relationAlias = null) Adds a RIGHT JOIN clause to the query using the SalesForceOpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery innerJoinSalesForceOpportunityMethodology($relationAlias = null) Adds a INNER JOIN clause to the query using the SalesForceOpportunityMethodology relation
 *
 * @method     ChildSfOpportunityMethodologyQuery joinWithSalesForceOpportunityMethodology($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the SalesForceOpportunityMethodology relation
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoinWithSalesForceOpportunityMethodology() Adds a LEFT JOIN clause and with to the query using the SalesForceOpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery rightJoinWithSalesForceOpportunityMethodology() Adds a RIGHT JOIN clause and with to the query using the SalesForceOpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery innerJoinWithSalesForceOpportunityMethodology() Adds a INNER JOIN clause and with to the query using the SalesForceOpportunityMethodology relation
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoinOpportunityMethodology($relationAlias = null) Adds a LEFT JOIN clause to the query using the OpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery rightJoinOpportunityMethodology($relationAlias = null) Adds a RIGHT JOIN clause to the query using the OpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery innerJoinOpportunityMethodology($relationAlias = null) Adds a INNER JOIN clause to the query using the OpportunityMethodology relation
 *
 * @method     ChildSfOpportunityMethodologyQuery joinWithOpportunityMethodology($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the OpportunityMethodology relation
 *
 * @method     ChildSfOpportunityMethodologyQuery leftJoinWithOpportunityMethodology() Adds a LEFT JOIN clause and with to the query using the OpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery rightJoinWithOpportunityMethodology() Adds a RIGHT JOIN clause and with to the query using the OpportunityMethodology relation
 * @method     ChildSfOpportunityMethodologyQuery innerJoinWithOpportunityMethodology() Adds a INNER JOIN clause and with to the query using the OpportunityMethodology relation
 *
 * @method     \Model\MethodologyQuery|\Model\OpportunityQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildSfOpportunityMethodology|null findOne(ConnectionInterface $con = null) Return the first ChildSfOpportunityMethodology matching the query
 * @method     ChildSfOpportunityMethodology findOneOrCreate(ConnectionInterface $con = null) Return the first ChildSfOpportunityMethodology matching the query, or a new ChildSfOpportunityMethodology object populated from the query conditions when no match is found
 *
 * @method     ChildSfOpportunityMethodology|null findOneByRefMethodologyId(int $ref_methodology_id) Return the first ChildSfOpportunityMethodology filtered by the ref_methodology_id column
 * @method     ChildSfOpportunityMethodology|null findOneByOpportunityId(int $opportunity_id) Return the first ChildSfOpportunityMethodology filtered by the opportunity_id column
 * @method     ChildSfOpportunityMethodology|null findOneByApiCreatedDate(string $api_created_date) Return the first ChildSfOpportunityMethodology filtered by the api_created_date column
 * @method     ChildSfOpportunityMethodology|null findOneByApiUpdatedDate(string $api_updated_date) Return the first ChildSfOpportunityMethodology filtered by the api_updated_date column *

 * @method     ChildSfOpportunityMethodology requirePk($key, ConnectionInterface $con = null) Return the ChildSfOpportunityMethodology by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildSfOpportunityMethodology requireOne(ConnectionInterface $con = null) Return the first ChildSfOpportunityMethodology matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildSfOpportunityMethodology requireOneByRefMethodologyId(int $ref_methodology_id) Return the first ChildSfOpportunityMethodology filtered by the ref_methodology_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildSfOpportunityMethodology requireOneByOpportunityId(int $opportunity_id) Return the first ChildSfOpportunityMethodology filtered by the opportunity_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildSfOpportunityMethodology requireOneByApiCreatedDate(string $api_created_date) Return the first ChildSfOpportunityMethodology filtered by the api_created_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildSfOpportunityMethodology requireOneByApiUpdatedDate(string $api_updated_date) Return the first ChildSfOpportunityMethodology filtered by the api_updated_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildSfOpportunityMethodology[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildSfOpportunityMethodology objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildSfOpportunityMethodology> find(ConnectionInterface $con = null) Return ChildSfOpportunityMethodology objects based on current ModelCriteria
 * @method     ChildSfOpportunityMethodology[]|ObjectCollection findByRefMethodologyId(int $ref_methodology_id) Return ChildSfOpportunityMethodology objects filtered by the ref_methodology_id column
 * @psalm-method ObjectCollection&\Traversable<ChildSfOpportunityMethodology> findByRefMethodologyId(int $ref_methodology_id) Return ChildSfOpportunityMethodology objects filtered by the ref_methodology_id column
 * @method     ChildSfOpportunityMethodology[]|ObjectCollection findByOpportunityId(int $opportunity_id) Return ChildSfOpportunityMethodology objects filtered by the opportunity_id column
 * @psalm-method ObjectCollection&\Traversable<ChildSfOpportunityMethodology> findByOpportunityId(int $opportunity_id) Return ChildSfOpportunityMethodology objects filtered by the opportunity_id column
 * @method     ChildSfOpportunityMethodology[]|ObjectCollection findByApiCreatedDate(string $api_created_date) Return ChildSfOpportunityMethodology objects filtered by the api_created_date column
 * @psalm-method ObjectCollection&\Traversable<ChildSfOpportunityMethodology> findByApiCreatedDate(string $api_created_date) Return ChildSfOpportunityMethodology objects filtered by the api_created_date column
 * @method     ChildSfOpportunityMethodology[]|ObjectCollection findByApiUpdatedDate(string $api_updated_date) Return ChildSfOpportunityMethodology objects filtered by the api_updated_date column
 * @psalm-method ObjectCollection&\Traversable<ChildSfOpportunityMethodology> findByApiUpdatedDate(string $api_updated_date) Return ChildSfOpportunityMethodology objects filtered by the api_updated_date column
 * @method     ChildSfOpportunityMethodology[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildSfOpportunityMethodology> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class SfOpportunityMethodologyQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\SfOpportunityMethodologyQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\SfOpportunityMethodology', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildSfOpportunityMethodologyQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildSfOpportunityMethodologyQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildSfOpportunityMethodologyQuery) {
            return $criteria;
        }
        $query = new ChildSfOpportunityMethodologyQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$ref_methodology_id, $opportunity_id] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildSfOpportunityMethodology|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(SfOpportunityMethodologyTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = SfOpportunityMethodologyTableMap::getInstanceFromPool(serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]))))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildSfOpportunityMethodology A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `ref_methodology_id`, `opportunity_id`, `api_created_date`, `api_updated_date` FROM `sf_opportunity_methodology` WHERE `ref_methodology_id` = :p0 AND `opportunity_id` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_INT);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildSfOpportunityMethodology $obj */
            $obj = new ChildSfOpportunityMethodology();
            $obj->hydrate($row);
            SfOpportunityMethodologyTableMap::addInstanceToPool($obj, serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildSfOpportunityMethodology|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the ref_methodology_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRefMethodologyId(1234); // WHERE ref_methodology_id = 1234
     * $query->filterByRefMethodologyId(array(12, 34)); // WHERE ref_methodology_id IN (12, 34)
     * $query->filterByRefMethodologyId(array('min' => 12)); // WHERE ref_methodology_id > 12
     * </code>
     *
     * @see       filterBySalesForceOpportunityMethodology()
     *
     * @param     mixed $refMethodologyId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByRefMethodologyId($refMethodologyId = null, $comparison = null)
    {
        if (is_array($refMethodologyId)) {
            $useMinMax = false;
            if (isset($refMethodologyId['min'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $refMethodologyId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($refMethodologyId['max'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $refMethodologyId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $refMethodologyId, $comparison);
    }

    /**
     * Filter the query on the opportunity_id column
     *
     * Example usage:
     * <code>
     * $query->filterByOpportunityId(1234); // WHERE opportunity_id = 1234
     * $query->filterByOpportunityId(array(12, 34)); // WHERE opportunity_id IN (12, 34)
     * $query->filterByOpportunityId(array('min' => 12)); // WHERE opportunity_id > 12
     * </code>
     *
     * @see       filterByOpportunityMethodology()
     *
     * @param     mixed $opportunityId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByOpportunityId($opportunityId = null, $comparison = null)
    {
        if (is_array($opportunityId)) {
            $useMinMax = false;
            if (isset($opportunityId['min'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $opportunityId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($opportunityId['max'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $opportunityId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $opportunityId, $comparison);
    }

    /**
     * Filter the query on the api_created_date column
     *
     * Example usage:
     * <code>
     * $query->filterByApiCreatedDate('2011-03-14'); // WHERE api_created_date = '2011-03-14'
     * $query->filterByApiCreatedDate('now'); // WHERE api_created_date = '2011-03-14'
     * $query->filterByApiCreatedDate(array('max' => 'yesterday')); // WHERE api_created_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $apiCreatedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByApiCreatedDate($apiCreatedDate = null, $comparison = null)
    {
        if (is_array($apiCreatedDate)) {
            $useMinMax = false;
            if (isset($apiCreatedDate['min'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE, $apiCreatedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($apiCreatedDate['max'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE, $apiCreatedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE, $apiCreatedDate, $comparison);
    }

    /**
     * Filter the query on the api_updated_date column
     *
     * Example usage:
     * <code>
     * $query->filterByApiUpdatedDate('2011-03-14'); // WHERE api_updated_date = '2011-03-14'
     * $query->filterByApiUpdatedDate('now'); // WHERE api_updated_date = '2011-03-14'
     * $query->filterByApiUpdatedDate(array('max' => 'yesterday')); // WHERE api_updated_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $apiUpdatedDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByApiUpdatedDate($apiUpdatedDate = null, $comparison = null)
    {
        if (is_array($apiUpdatedDate)) {
            $useMinMax = false;
            if (isset($apiUpdatedDate['min'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($apiUpdatedDate['max'])) {
                $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE, $apiUpdatedDate, $comparison);
    }

    /**
     * Filter the query by a related \Model\Methodology object
     *
     * @param \Model\Methodology|ObjectCollection $methodology The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterBySalesForceOpportunityMethodology($methodology, $comparison = null)
    {
        if ($methodology instanceof \Model\Methodology) {
            return $this
                ->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $methodology->getId(), $comparison);
        } elseif ($methodology instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID, $methodology->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterBySalesForceOpportunityMethodology() only accepts arguments of type \Model\Methodology or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the SalesForceOpportunityMethodology relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function joinSalesForceOpportunityMethodology($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('SalesForceOpportunityMethodology');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'SalesForceOpportunityMethodology');
        }

        return $this;
    }

    /**
     * Use the SalesForceOpportunityMethodology relation Methodology object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\MethodologyQuery A secondary query class using the current class as primary query
     */
    public function useSalesForceOpportunityMethodologyQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinSalesForceOpportunityMethodology($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'SalesForceOpportunityMethodology', '\Model\MethodologyQuery');
    }

    /**
     * Use the SalesForceOpportunityMethodology relation Methodology object
     *
     * @param callable(\Model\MethodologyQuery):\Model\MethodologyQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withSalesForceOpportunityMethodologyQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useSalesForceOpportunityMethodologyQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the SalesForceOpportunityMethodology relation to the Methodology table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\MethodologyQuery The inner query object of the EXISTS statement
     */
    public function useSalesForceOpportunityMethodologyExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('SalesForceOpportunityMethodology', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the SalesForceOpportunityMethodology relation to the Methodology table for a NOT EXISTS query.
     *
     * @see useSalesForceOpportunityMethodologyExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\MethodologyQuery The inner query object of the NOT EXISTS statement
     */
    public function useSalesForceOpportunityMethodologyNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('SalesForceOpportunityMethodology', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Opportunity object
     *
     * @param \Model\Opportunity|ObjectCollection $opportunity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function filterByOpportunityMethodology($opportunity, $comparison = null)
    {
        if ($opportunity instanceof \Model\Opportunity) {
            return $this
                ->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $opportunity->getId(), $comparison);
        } elseif ($opportunity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID, $opportunity->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByOpportunityMethodology() only accepts arguments of type \Model\Opportunity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the OpportunityMethodology relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function joinOpportunityMethodology($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('OpportunityMethodology');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'OpportunityMethodology');
        }

        return $this;
    }

    /**
     * Use the OpportunityMethodology relation Opportunity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\OpportunityQuery A secondary query class using the current class as primary query
     */
    public function useOpportunityMethodologyQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinOpportunityMethodology($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'OpportunityMethodology', '\Model\OpportunityQuery');
    }

    /**
     * Use the OpportunityMethodology relation Opportunity object
     *
     * @param callable(\Model\OpportunityQuery):\Model\OpportunityQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withOpportunityMethodologyQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useOpportunityMethodologyQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the OpportunityMethodology relation to the Opportunity table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\OpportunityQuery The inner query object of the EXISTS statement
     */
    public function useOpportunityMethodologyExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('OpportunityMethodology', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the OpportunityMethodology relation to the Opportunity table for a NOT EXISTS query.
     *
     * @see useOpportunityMethodologyExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\OpportunityQuery The inner query object of the NOT EXISTS statement
     */
    public function useOpportunityMethodologyNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('OpportunityMethodology', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildSfOpportunityMethodology $sfOpportunityMethodology Object to remove from the list of results
     *
     * @return $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function prune($sfOpportunityMethodology = null)
    {
        if ($sfOpportunityMethodology) {
            $this->addCond('pruneCond0', $this->getAliasedColName(SfOpportunityMethodologyTableMap::COL_REF_METHODOLOGY_ID), $sfOpportunityMethodology->getRefMethodologyId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(SfOpportunityMethodologyTableMap::COL_OPPORTUNITY_ID), $sfOpportunityMethodology->getOpportunityId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the sf_opportunity_methodology table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(SfOpportunityMethodologyTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            SfOpportunityMethodologyTableMap::clearInstancePool();
            SfOpportunityMethodologyTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(SfOpportunityMethodologyTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(SfOpportunityMethodologyTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            SfOpportunityMethodologyTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            SfOpportunityMethodologyTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // timestampable behavior

    /**
     * Filter by the latest updated
     *
     * @param      int $nbDays Maximum age of the latest update in days
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function recentlyUpdated($nbDays = 7)
    {
        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by update date desc
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function lastUpdatedFirst()
    {
        return $this->addDescendingOrderByColumn(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE);
    }

    /**
     * Order by update date asc
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function firstUpdatedFirst()
    {
        return $this->addAscendingOrderByColumn(SfOpportunityMethodologyTableMap::COL_API_UPDATED_DATE);
    }

    /**
     * Order by create date desc
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function lastCreatedFirst()
    {
        return $this->addDescendingOrderByColumn(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE);
    }

    /**
     * Filter by the latest created
     *
     * @param      int $nbDays Maximum age of in days
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function recentlyCreated($nbDays = 7)
    {
        return $this->addUsingAlias(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE, time() - $nbDays * 24 * 60 * 60, Criteria::GREATER_EQUAL);
    }

    /**
     * Order by create date asc
     *
     * @return     $this|ChildSfOpportunityMethodologyQuery The current query, for fluid interface
     */
    public function firstCreatedFirst()
    {
        return $this->addAscendingOrderByColumn(SfOpportunityMethodologyTableMap::COL_API_CREATED_DATE);
    }

} // SfOpportunityMethodologyQuery
