<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\Etape as ChildEtape;
use Model\EtapeQuery as ChildEtapeQuery;
use Model\Map\EtapeTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'ref_etape' table.
 *
 *
 *
 * @method     ChildEtapeQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEtapeQuery orderByEtape($order = Criteria::ASC) Order by the etape column
 * @method     ChildEtapeQuery orderBySfLabel($order = Criteria::ASC) Order by the sf_label column
 * @method     ChildEtapeQuery orderByIdGroupe($order = Criteria::ASC) Order by the id_groupe column
 * @method     ChildEtapeQuery orderByOrdre($order = Criteria::ASC) Order by the ordre column
 *
 * @method     ChildEtapeQuery groupById() Group by the id column
 * @method     ChildEtapeQuery groupByEtape() Group by the etape column
 * @method     ChildEtapeQuery groupBySfLabel() Group by the sf_label column
 * @method     ChildEtapeQuery groupByIdGroupe() Group by the id_groupe column
 * @method     ChildEtapeQuery groupByOrdre() Group by the ordre column
 *
 * @method     ChildEtapeQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtapeQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtapeQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtapeQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtapeQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtapeQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtapeQuery leftJoinGroupe($relationAlias = null) Adds a LEFT JOIN clause to the query using the Groupe relation
 * @method     ChildEtapeQuery rightJoinGroupe($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Groupe relation
 * @method     ChildEtapeQuery innerJoinGroupe($relationAlias = null) Adds a INNER JOIN clause to the query using the Groupe relation
 *
 * @method     ChildEtapeQuery joinWithGroupe($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Groupe relation
 *
 * @method     ChildEtapeQuery leftJoinWithGroupe() Adds a LEFT JOIN clause and with to the query using the Groupe relation
 * @method     ChildEtapeQuery rightJoinWithGroupe() Adds a RIGHT JOIN clause and with to the query using the Groupe relation
 * @method     ChildEtapeQuery innerJoinWithGroupe() Adds a INNER JOIN clause and with to the query using the Groupe relation
 *
 * @method     ChildEtapeQuery leftJoinEtude($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etude relation
 * @method     ChildEtapeQuery rightJoinEtude($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etude relation
 * @method     ChildEtapeQuery innerJoinEtude($relationAlias = null) Adds a INNER JOIN clause to the query using the Etude relation
 *
 * @method     ChildEtapeQuery joinWithEtude($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etude relation
 *
 * @method     ChildEtapeQuery leftJoinWithEtude() Adds a LEFT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtapeQuery rightJoinWithEtude() Adds a RIGHT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtapeQuery innerJoinWithEtude() Adds a INNER JOIN clause and with to the query using the Etude relation
 *
 * @method     ChildEtapeQuery leftJoinJobItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the JobItem relation
 * @method     ChildEtapeQuery rightJoinJobItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the JobItem relation
 * @method     ChildEtapeQuery innerJoinJobItem($relationAlias = null) Adds a INNER JOIN clause to the query using the JobItem relation
 *
 * @method     ChildEtapeQuery joinWithJobItem($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the JobItem relation
 *
 * @method     ChildEtapeQuery leftJoinWithJobItem() Adds a LEFT JOIN clause and with to the query using the JobItem relation
 * @method     ChildEtapeQuery rightJoinWithJobItem() Adds a RIGHT JOIN clause and with to the query using the JobItem relation
 * @method     ChildEtapeQuery innerJoinWithJobItem() Adds a INNER JOIN clause and with to the query using the JobItem relation
 *
 * @method     ChildEtapeQuery leftJoinEtudeMaster($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeMaster relation
 * @method     ChildEtapeQuery rightJoinEtudeMaster($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeMaster relation
 * @method     ChildEtapeQuery innerJoinEtudeMaster($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeMaster relation
 *
 * @method     ChildEtapeQuery joinWithEtudeMaster($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeMaster relation
 *
 * @method     ChildEtapeQuery leftJoinWithEtudeMaster() Adds a LEFT JOIN clause and with to the query using the EtudeMaster relation
 * @method     ChildEtapeQuery rightJoinWithEtudeMaster() Adds a RIGHT JOIN clause and with to the query using the EtudeMaster relation
 * @method     ChildEtapeQuery innerJoinWithEtudeMaster() Adds a INNER JOIN clause and with to the query using the EtudeMaster relation
 *
 * @method     ChildEtapeQuery leftJoinGroupeEtape($relationAlias = null) Adds a LEFT JOIN clause to the query using the GroupeEtape relation
 * @method     ChildEtapeQuery rightJoinGroupeEtape($relationAlias = null) Adds a RIGHT JOIN clause to the query using the GroupeEtape relation
 * @method     ChildEtapeQuery innerJoinGroupeEtape($relationAlias = null) Adds a INNER JOIN clause to the query using the GroupeEtape relation
 *
 * @method     ChildEtapeQuery joinWithGroupeEtape($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the GroupeEtape relation
 *
 * @method     ChildEtapeQuery leftJoinWithGroupeEtape() Adds a LEFT JOIN clause and with to the query using the GroupeEtape relation
 * @method     ChildEtapeQuery rightJoinWithGroupeEtape() Adds a RIGHT JOIN clause and with to the query using the GroupeEtape relation
 * @method     ChildEtapeQuery innerJoinWithGroupeEtape() Adds a INNER JOIN clause and with to the query using the GroupeEtape relation
 *
 * @method     ChildEtapeQuery leftJoinEtudeChecklist($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeChecklist relation
 * @method     ChildEtapeQuery rightJoinEtudeChecklist($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeChecklist relation
 * @method     ChildEtapeQuery innerJoinEtudeChecklist($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeChecklist relation
 *
 * @method     ChildEtapeQuery joinWithEtudeChecklist($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeChecklist relation
 *
 * @method     ChildEtapeQuery leftJoinWithEtudeChecklist() Adds a LEFT JOIN clause and with to the query using the EtudeChecklist relation
 * @method     ChildEtapeQuery rightJoinWithEtudeChecklist() Adds a RIGHT JOIN clause and with to the query using the EtudeChecklist relation
 * @method     ChildEtapeQuery innerJoinWithEtudeChecklist() Adds a INNER JOIN clause and with to the query using the EtudeChecklist relation
 *
 * @method     \Model\GroupeQuery|\Model\EtudeQuery|\Model\JobItemQuery|\Model\EtudeMasterQuery|\Model\GroupeEtapeQuery|\Model\EtudeChecklistQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtape|null findOne(ConnectionInterface $con = null) Return the first ChildEtape matching the query
 * @method     ChildEtape findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtape matching the query, or a new ChildEtape object populated from the query conditions when no match is found
 *
 * @method     ChildEtape|null findOneById(int $id) Return the first ChildEtape filtered by the id column
 * @method     ChildEtape|null findOneByEtape(string $etape) Return the first ChildEtape filtered by the etape column
 * @method     ChildEtape|null findOneBySfLabel(string $sf_label) Return the first ChildEtape filtered by the sf_label column
 * @method     ChildEtape|null findOneByIdGroupe(int $id_groupe) Return the first ChildEtape filtered by the id_groupe column
 * @method     ChildEtape|null findOneByOrdre(int $ordre) Return the first ChildEtape filtered by the ordre column *

 * @method     ChildEtape requirePk($key, ConnectionInterface $con = null) Return the ChildEtape by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtape requireOne(ConnectionInterface $con = null) Return the first ChildEtape matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtape requireOneById(int $id) Return the first ChildEtape filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtape requireOneByEtape(string $etape) Return the first ChildEtape filtered by the etape column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtape requireOneBySfLabel(string $sf_label) Return the first ChildEtape filtered by the sf_label column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtape requireOneByIdGroupe(int $id_groupe) Return the first ChildEtape filtered by the id_groupe column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtape requireOneByOrdre(int $ordre) Return the first ChildEtape filtered by the ordre column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtape[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtape objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> find(ConnectionInterface $con = null) Return ChildEtape objects based on current ModelCriteria
 * @method     ChildEtape[]|ObjectCollection findById(int $id) Return ChildEtape objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> findById(int $id) Return ChildEtape objects filtered by the id column
 * @method     ChildEtape[]|ObjectCollection findByEtape(string $etape) Return ChildEtape objects filtered by the etape column
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> findByEtape(string $etape) Return ChildEtape objects filtered by the etape column
 * @method     ChildEtape[]|ObjectCollection findBySfLabel(string $sf_label) Return ChildEtape objects filtered by the sf_label column
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> findBySfLabel(string $sf_label) Return ChildEtape objects filtered by the sf_label column
 * @method     ChildEtape[]|ObjectCollection findByIdGroupe(int $id_groupe) Return ChildEtape objects filtered by the id_groupe column
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> findByIdGroupe(int $id_groupe) Return ChildEtape objects filtered by the id_groupe column
 * @method     ChildEtape[]|ObjectCollection findByOrdre(int $ordre) Return ChildEtape objects filtered by the ordre column
 * @psalm-method ObjectCollection&\Traversable<ChildEtape> findByOrdre(int $ordre) Return ChildEtape objects filtered by the ordre column
 * @method     ChildEtape[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtape> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtapeQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtapeQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\Etape', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtapeQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtapeQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtapeQuery) {
            return $criteria;
        }
        $query = new ChildEtapeQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtape|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtapeTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtapeTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtape A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `etape`, `sf_label`, `id_groupe`, `ordre` FROM `ref_etape` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtape $obj */
            $obj = new ChildEtape();
            $obj->hydrate($row);
            EtapeTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtape|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EtapeTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EtapeTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtapeTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the etape column
     *
     * Example usage:
     * <code>
     * $query->filterByEtape('fooValue');   // WHERE etape = 'fooValue'
     * $query->filterByEtape('%fooValue%', Criteria::LIKE); // WHERE etape LIKE '%fooValue%'
     * $query->filterByEtape(['foo', 'bar']); // WHERE etape IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $etape The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByEtape($etape = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($etape)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtapeTableMap::COL_ETAPE, $etape, $comparison);
    }

    /**
     * Filter the query on the sf_label column
     *
     * Example usage:
     * <code>
     * $query->filterBySfLabel('fooValue');   // WHERE sf_label = 'fooValue'
     * $query->filterBySfLabel('%fooValue%', Criteria::LIKE); // WHERE sf_label LIKE '%fooValue%'
     * $query->filterBySfLabel(['foo', 'bar']); // WHERE sf_label IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $sfLabel The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterBySfLabel($sfLabel = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sfLabel)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtapeTableMap::COL_SF_LABEL, $sfLabel, $comparison);
    }

    /**
     * Filter the query on the id_groupe column
     *
     * Example usage:
     * <code>
     * $query->filterByIdGroupe(1234); // WHERE id_groupe = 1234
     * $query->filterByIdGroupe(array(12, 34)); // WHERE id_groupe IN (12, 34)
     * $query->filterByIdGroupe(array('min' => 12)); // WHERE id_groupe > 12
     * </code>
     *
     * @see       filterByGroupe()
     *
     * @param     mixed $idGroupe The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByIdGroupe($idGroupe = null, $comparison = null)
    {
        if (is_array($idGroupe)) {
            $useMinMax = false;
            if (isset($idGroupe['min'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ID_GROUPE, $idGroupe['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idGroupe['max'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ID_GROUPE, $idGroupe['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtapeTableMap::COL_ID_GROUPE, $idGroupe, $comparison);
    }

    /**
     * Filter the query on the ordre column
     *
     * Example usage:
     * <code>
     * $query->filterByOrdre(1234); // WHERE ordre = 1234
     * $query->filterByOrdre(array(12, 34)); // WHERE ordre IN (12, 34)
     * $query->filterByOrdre(array('min' => 12)); // WHERE ordre > 12
     * </code>
     *
     * @param     mixed $ordre The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByOrdre($ordre = null, $comparison = null)
    {
        if (is_array($ordre)) {
            $useMinMax = false;
            if (isset($ordre['min'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ORDRE, $ordre['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($ordre['max'])) {
                $this->addUsingAlias(EtapeTableMap::COL_ORDRE, $ordre['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtapeTableMap::COL_ORDRE, $ordre, $comparison);
    }

    /**
     * Filter the query by a related \Model\Groupe object
     *
     * @param \Model\Groupe|ObjectCollection $groupe The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByGroupe($groupe, $comparison = null)
    {
        if ($groupe instanceof \Model\Groupe) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID_GROUPE, $groupe->getId(), $comparison);
        } elseif ($groupe instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID_GROUPE, $groupe->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByGroupe() only accepts arguments of type \Model\Groupe or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Groupe relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinGroupe($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Groupe');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Groupe');
        }

        return $this;
    }

    /**
     * Use the Groupe relation Groupe object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\GroupeQuery A secondary query class using the current class as primary query
     */
    public function useGroupeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinGroupe($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Groupe', '\Model\GroupeQuery');
    }

    /**
     * Use the Groupe relation Groupe object
     *
     * @param callable(\Model\GroupeQuery):\Model\GroupeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withGroupeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useGroupeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Groupe table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\GroupeQuery The inner query object of the EXISTS statement
     */
    public function useGroupeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Groupe', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Groupe table for a NOT EXISTS query.
     *
     * @see useGroupeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\GroupeQuery The inner query object of the NOT EXISTS statement
     */
    public function useGroupeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Groupe', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Etude object
     *
     * @param \Model\Etude|ObjectCollection $etude the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByEtude($etude, $comparison = null)
    {
        if ($etude instanceof \Model\Etude) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID, $etude->getIdEtape(), $comparison);
        } elseif ($etude instanceof ObjectCollection) {
            return $this
                ->useEtudeQuery()
                ->filterByPrimaryKeys($etude->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtude() only accepts arguments of type \Model\Etude or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etude relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinEtude($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etude');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etude');
        }

        return $this;
    }

    /**
     * Use the Etude relation Etude object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeQuery A secondary query class using the current class as primary query
     */
    public function useEtudeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtude($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etude', '\Model\EtudeQuery');
    }

    /**
     * Use the Etude relation Etude object
     *
     * @param callable(\Model\EtudeQuery):\Model\EtudeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etude table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeQuery The inner query object of the EXISTS statement
     */
    public function useEtudeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etude table for a NOT EXISTS query.
     *
     * @see useEtudeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\JobItem object
     *
     * @param \Model\JobItem|ObjectCollection $jobItem the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByJobItem($jobItem, $comparison = null)
    {
        if ($jobItem instanceof \Model\JobItem) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID, $jobItem->getEtapeLogId(), $comparison);
        } elseif ($jobItem instanceof ObjectCollection) {
            return $this
                ->useJobItemQuery()
                ->filterByPrimaryKeys($jobItem->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByJobItem() only accepts arguments of type \Model\JobItem or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the JobItem relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinJobItem($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('JobItem');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'JobItem');
        }

        return $this;
    }

    /**
     * Use the JobItem relation JobItem object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\JobItemQuery A secondary query class using the current class as primary query
     */
    public function useJobItemQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinJobItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'JobItem', '\Model\JobItemQuery');
    }

    /**
     * Use the JobItem relation JobItem object
     *
     * @param callable(\Model\JobItemQuery):\Model\JobItemQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withJobItemQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useJobItemQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to JobItem table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\JobItemQuery The inner query object of the EXISTS statement
     */
    public function useJobItemExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('JobItem', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to JobItem table for a NOT EXISTS query.
     *
     * @see useJobItemExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\JobItemQuery The inner query object of the NOT EXISTS statement
     */
    public function useJobItemNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('JobItem', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeMaster object
     *
     * @param \Model\EtudeMaster|ObjectCollection $etudeMaster the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByEtudeMaster($etudeMaster, $comparison = null)
    {
        if ($etudeMaster instanceof \Model\EtudeMaster) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID, $etudeMaster->getIdEtape(), $comparison);
        } elseif ($etudeMaster instanceof ObjectCollection) {
            return $this
                ->useEtudeMasterQuery()
                ->filterByPrimaryKeys($etudeMaster->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeMaster() only accepts arguments of type \Model\EtudeMaster or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeMaster relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinEtudeMaster($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeMaster');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeMaster');
        }

        return $this;
    }

    /**
     * Use the EtudeMaster relation EtudeMaster object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeMasterQuery A secondary query class using the current class as primary query
     */
    public function useEtudeMasterQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeMaster($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeMaster', '\Model\EtudeMasterQuery');
    }

    /**
     * Use the EtudeMaster relation EtudeMaster object
     *
     * @param callable(\Model\EtudeMasterQuery):\Model\EtudeMasterQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeMasterQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeMasterQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeMaster table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeMasterQuery The inner query object of the EXISTS statement
     */
    public function useEtudeMasterExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeMaster', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeMaster table for a NOT EXISTS query.
     *
     * @see useEtudeMasterExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeMasterQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeMasterNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeMaster', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\GroupeEtape object
     *
     * @param \Model\GroupeEtape|ObjectCollection $groupeEtape the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByGroupeEtape($groupeEtape, $comparison = null)
    {
        if ($groupeEtape instanceof \Model\GroupeEtape) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID, $groupeEtape->getIdEtape(), $comparison);
        } elseif ($groupeEtape instanceof ObjectCollection) {
            return $this
                ->useGroupeEtapeQuery()
                ->filterByPrimaryKeys($groupeEtape->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByGroupeEtape() only accepts arguments of type \Model\GroupeEtape or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the GroupeEtape relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinGroupeEtape($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('GroupeEtape');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'GroupeEtape');
        }

        return $this;
    }

    /**
     * Use the GroupeEtape relation GroupeEtape object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\GroupeEtapeQuery A secondary query class using the current class as primary query
     */
    public function useGroupeEtapeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinGroupeEtape($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'GroupeEtape', '\Model\GroupeEtapeQuery');
    }

    /**
     * Use the GroupeEtape relation GroupeEtape object
     *
     * @param callable(\Model\GroupeEtapeQuery):\Model\GroupeEtapeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withGroupeEtapeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useGroupeEtapeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to GroupeEtape table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\GroupeEtapeQuery The inner query object of the EXISTS statement
     */
    public function useGroupeEtapeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('GroupeEtape', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to GroupeEtape table for a NOT EXISTS query.
     *
     * @see useGroupeEtapeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\GroupeEtapeQuery The inner query object of the NOT EXISTS statement
     */
    public function useGroupeEtapeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('GroupeEtape', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeChecklist object
     *
     * @param \Model\EtudeChecklist|ObjectCollection $etudeChecklist the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByEtudeChecklist($etudeChecklist, $comparison = null)
    {
        if ($etudeChecklist instanceof \Model\EtudeChecklist) {
            return $this
                ->addUsingAlias(EtapeTableMap::COL_ID, $etudeChecklist->getEtudeEtapeId(), $comparison);
        } elseif ($etudeChecklist instanceof ObjectCollection) {
            return $this
                ->useEtudeChecklistQuery()
                ->filterByPrimaryKeys($etudeChecklist->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeChecklist() only accepts arguments of type \Model\EtudeChecklist or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeChecklist relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function joinEtudeChecklist($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeChecklist');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeChecklist');
        }

        return $this;
    }

    /**
     * Use the EtudeChecklist relation EtudeChecklist object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeChecklistQuery A secondary query class using the current class as primary query
     */
    public function useEtudeChecklistQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeChecklist($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeChecklist', '\Model\EtudeChecklistQuery');
    }

    /**
     * Use the EtudeChecklist relation EtudeChecklist object
     *
     * @param callable(\Model\EtudeChecklistQuery):\Model\EtudeChecklistQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeChecklistQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeChecklistQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeChecklist table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeChecklistQuery The inner query object of the EXISTS statement
     */
    public function useEtudeChecklistExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeChecklist', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeChecklist table for a NOT EXISTS query.
     *
     * @see useEtudeChecklistExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeChecklistQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeChecklistNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeChecklist', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEtape $etape Object to remove from the list of results
     *
     * @return $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function prune($etape = null)
    {
        if ($etape) {
            $this->addUsingAlias(EtapeTableMap::COL_ID, $etape->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the ref_etape table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtapeTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtapeTableMap::clearInstancePool();
            EtapeTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtapeTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtapeTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtapeTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtapeTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // sortable behavior

    /**
     * Filter the query based on a rank in the list
     *
     * @param     integer   $rank rank
     *
     * @return    ChildEtapeQuery The current query, for fluid interface
     */
    public function filterByRank($rank)
    {

        return $this
            ->addUsingAlias(EtapeTableMap::RANK_COL, $rank, Criteria::EQUAL);
    }

    /**
     * Order the query based on the rank in the list.
     * Using the default $order, returns the item with the lowest rank first
     *
     * @param     string $order either Criteria::ASC (default) or Criteria::DESC
     *
     * @return    $this|ChildEtapeQuery The current query, for fluid interface
     */
    public function orderByRank($order = Criteria::ASC)
    {
        $order = strtoupper($order);
        switch ($order) {
            case Criteria::ASC:
                return $this->addAscendingOrderByColumn($this->getAliasedColName(EtapeTableMap::RANK_COL));
                break;
            case Criteria::DESC:
                return $this->addDescendingOrderByColumn($this->getAliasedColName(EtapeTableMap::RANK_COL));
                break;
            default:
                throw new \Propel\Runtime\Exception\PropelException('ChildEtapeQuery::orderBy() only accepts "asc" or "desc" as argument');
        }
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param     ConnectionInterface $con optional connection
     *
     * @return    ChildEtape
     */
    public function findOneByRank($rank, ConnectionInterface $con = null)
    {

        return $this
            ->filterByRank($rank)
            ->findOne($con);
    }

    /**
     * Returns the list of objects
     *
     * @param      ConnectionInterface $con    Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($con = null)
    {

        return $this
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtapeTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EtapeTableMap::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray(ConnectionInterface $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(EtapeTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EtapeTableMap::RANK_COL . ')');
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param     ConnectionInterface $con optional connection
     *
     * @return ChildEtape
     */
    static public function retrieveByRank($rank, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtapeTableMap::DATABASE_NAME);
        }

        $c = new Criteria;
        $c->add(EtapeTableMap::RANK_COL, $rank);

        return static::create(null, $c)->findOne($con);
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     mixed               $order id => rank pairs
     * @param     ConnectionInterface $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder($order, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtapeTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con, $order) {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getOrdre() != $order[$pk]) {
                    $object->setOrdre($order[$pk]);
                    $object->save($con);
                }
            }
        });

        return true;
    }

    /**
     * Return an array of sortable objects ordered by position
     *
     * @param     Criteria  $criteria  optional criteria object
     * @param     string    $order     sorting order, to be chosen between Criteria::ASC (default) and Criteria::DESC
     * @param     ConnectionInterface $con       optional connection
     *
     * @return    array list of sortable objects
     */
    static public function doSelectOrderByRank(Criteria $criteria = null, $order = Criteria::ASC, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtapeTableMap::DATABASE_NAME);
        }

        if (null === $criteria) {
            $criteria = new Criteria();
        } elseif ($criteria instanceof Criteria) {
            $criteria = clone $criteria;
        }

        $criteria->clearOrderByColumns();

        if (Criteria::ASC == $order) {
            $criteria->addAscendingOrderByColumn(EtapeTableMap::RANK_COL);
        } else {
            $criteria->addDescendingOrderByColumn(EtapeTableMap::RANK_COL);
        }

        return ChildEtapeQuery::create(null, $criteria)->find($con);
    }

    /**
     * Adds $delta to all Rank values that are >= $first and <= $last.
     * '$delta' can also be negative.
     *
     * @param      int $delta Value to be shifted by, can be negative
     * @param      int $first First node to be shifted
     * @param      int $last  Last node to be shifted
     * @param      ConnectionInterface $con Connection to use.
     */
    static public function sortableShiftRank($delta, $first, $last = null, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtapeTableMap::DATABASE_NAME);
        }

        $whereCriteria = new Criteria(EtapeTableMap::DATABASE_NAME);
        $criterion = $whereCriteria->getNewCriterion(EtapeTableMap::RANK_COL, $first, Criteria::GREATER_EQUAL);
        if (null !== $last) {
            $criterion->addAnd($whereCriteria->getNewCriterion(EtapeTableMap::RANK_COL, $last, Criteria::LESS_EQUAL));
        }
        $whereCriteria->add($criterion);

        $valuesCriteria = new Criteria(EtapeTableMap::DATABASE_NAME);
        $valuesCriteria->add(EtapeTableMap::RANK_COL, array('raw' => EtapeTableMap::RANK_COL . ' + ?', 'value' => $delta), Criteria::CUSTOM_EQUAL);

        $whereCriteria->doUpdate($valuesCriteria, $con);
        EtapeTableMap::clearInstancePool();
    }

} // EtapeQuery
