<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\DiscountProgram as ChildDiscountProgram;
use Model\DiscountProgramQuery as ChildDiscountProgramQuery;
use Model\Map\DiscountProgramTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'discount_program' table.
 *
 *
 *
 * @method     ChildDiscountProgramQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildDiscountProgramQuery orderByName($order = Criteria::ASC) Order by the name column
 * @method     ChildDiscountProgramQuery orderByActive($order = Criteria::ASC) Order by the active column
 * @method     ChildDiscountProgramQuery orderByGroupe($order = Criteria::ASC) Order by the groupe column
 * @method     ChildDiscountProgramQuery orderByType($order = Criteria::ASC) Order by the type column
 *
 * @method     ChildDiscountProgramQuery groupById() Group by the id column
 * @method     ChildDiscountProgramQuery groupByName() Group by the name column
 * @method     ChildDiscountProgramQuery groupByActive() Group by the active column
 * @method     ChildDiscountProgramQuery groupByGroupe() Group by the groupe column
 * @method     ChildDiscountProgramQuery groupByType() Group by the type column
 *
 * @method     ChildDiscountProgramQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildDiscountProgramQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildDiscountProgramQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildDiscountProgramQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildDiscountProgramQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildDiscountProgramQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildDiscountProgramQuery leftJoinDiscountProgram($relationAlias = null) Adds a LEFT JOIN clause to the query using the DiscountProgram relation
 * @method     ChildDiscountProgramQuery rightJoinDiscountProgram($relationAlias = null) Adds a RIGHT JOIN clause to the query using the DiscountProgram relation
 * @method     ChildDiscountProgramQuery innerJoinDiscountProgram($relationAlias = null) Adds a INNER JOIN clause to the query using the DiscountProgram relation
 *
 * @method     ChildDiscountProgramQuery joinWithDiscountProgram($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the DiscountProgram relation
 *
 * @method     ChildDiscountProgramQuery leftJoinWithDiscountProgram() Adds a LEFT JOIN clause and with to the query using the DiscountProgram relation
 * @method     ChildDiscountProgramQuery rightJoinWithDiscountProgram() Adds a RIGHT JOIN clause and with to the query using the DiscountProgram relation
 * @method     ChildDiscountProgramQuery innerJoinWithDiscountProgram() Adds a INNER JOIN clause and with to the query using the DiscountProgram relation
 *
 * @method     \Model\CategoriePrestationDiscountQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildDiscountProgram|null findOne(ConnectionInterface $con = null) Return the first ChildDiscountProgram matching the query
 * @method     ChildDiscountProgram findOneOrCreate(ConnectionInterface $con = null) Return the first ChildDiscountProgram matching the query, or a new ChildDiscountProgram object populated from the query conditions when no match is found
 *
 * @method     ChildDiscountProgram|null findOneById(int $id) Return the first ChildDiscountProgram filtered by the id column
 * @method     ChildDiscountProgram|null findOneByName(string $name) Return the first ChildDiscountProgram filtered by the name column
 * @method     ChildDiscountProgram|null findOneByActive(boolean $active) Return the first ChildDiscountProgram filtered by the active column
 * @method     ChildDiscountProgram|null findOneByGroupe(int $groupe) Return the first ChildDiscountProgram filtered by the groupe column
 * @method     ChildDiscountProgram|null findOneByType(int $type) Return the first ChildDiscountProgram filtered by the type column *

 * @method     ChildDiscountProgram requirePk($key, ConnectionInterface $con = null) Return the ChildDiscountProgram by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDiscountProgram requireOne(ConnectionInterface $con = null) Return the first ChildDiscountProgram matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDiscountProgram requireOneById(int $id) Return the first ChildDiscountProgram filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDiscountProgram requireOneByName(string $name) Return the first ChildDiscountProgram filtered by the name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDiscountProgram requireOneByActive(boolean $active) Return the first ChildDiscountProgram filtered by the active column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDiscountProgram requireOneByGroupe(int $groupe) Return the first ChildDiscountProgram filtered by the groupe column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildDiscountProgram requireOneByType(int $type) Return the first ChildDiscountProgram filtered by the type column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildDiscountProgram[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildDiscountProgram objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> find(ConnectionInterface $con = null) Return ChildDiscountProgram objects based on current ModelCriteria
 * @method     ChildDiscountProgram[]|ObjectCollection findById(int $id) Return ChildDiscountProgram objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> findById(int $id) Return ChildDiscountProgram objects filtered by the id column
 * @method     ChildDiscountProgram[]|ObjectCollection findByName(string $name) Return ChildDiscountProgram objects filtered by the name column
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> findByName(string $name) Return ChildDiscountProgram objects filtered by the name column
 * @method     ChildDiscountProgram[]|ObjectCollection findByActive(boolean $active) Return ChildDiscountProgram objects filtered by the active column
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> findByActive(boolean $active) Return ChildDiscountProgram objects filtered by the active column
 * @method     ChildDiscountProgram[]|ObjectCollection findByGroupe(int $groupe) Return ChildDiscountProgram objects filtered by the groupe column
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> findByGroupe(int $groupe) Return ChildDiscountProgram objects filtered by the groupe column
 * @method     ChildDiscountProgram[]|ObjectCollection findByType(int $type) Return ChildDiscountProgram objects filtered by the type column
 * @psalm-method ObjectCollection&\Traversable<ChildDiscountProgram> findByType(int $type) Return ChildDiscountProgram objects filtered by the type column
 * @method     ChildDiscountProgram[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildDiscountProgram> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class DiscountProgramQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\DiscountProgramQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\DiscountProgram', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildDiscountProgramQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildDiscountProgramQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildDiscountProgramQuery) {
            return $criteria;
        }
        $query = new ChildDiscountProgramQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildDiscountProgram|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(DiscountProgramTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = DiscountProgramTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildDiscountProgram A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `name`, `active`, `groupe`, `type` FROM `discount_program` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildDiscountProgram $obj */
            $obj = new ChildDiscountProgram();
            $obj->hydrate($row);
            DiscountProgramTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildDiscountProgram|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the name column
     *
     * Example usage:
     * <code>
     * $query->filterByName('fooValue');   // WHERE name = 'fooValue'
     * $query->filterByName('%fooValue%', Criteria::LIKE); // WHERE name LIKE '%fooValue%'
     * $query->filterByName(['foo', 'bar']); // WHERE name IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $name The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByName($name = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($name)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DiscountProgramTableMap::COL_NAME, $name, $comparison);
    }

    /**
     * Filter the query on the active column
     *
     * Example usage:
     * <code>
     * $query->filterByActive(true); // WHERE active = true
     * $query->filterByActive('yes'); // WHERE active = true
     * </code>
     *
     * @param     boolean|string $active The value to use as filter.
     *              Non-boolean arguments are converted using the following rules:
     *                * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *                * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     *              Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByActive($active = null, $comparison = null)
    {
        if (is_string($active)) {
            $active = in_array(strtolower($active), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
        }

        return $this->addUsingAlias(DiscountProgramTableMap::COL_ACTIVE, $active, $comparison);
    }

    /**
     * Filter the query on the groupe column
     *
     * @param     mixed $groupe The value to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByGroupe($groupe = null, $comparison = null)
    {
        $valueSet = DiscountProgramTableMap::getValueSet(DiscountProgramTableMap::COL_GROUPE);
        if (is_scalar($groupe)) {
            if (!in_array($groupe, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $groupe));
            }
            $groupe = array_search($groupe, $valueSet);
        } elseif (is_array($groupe)) {
            $convertedValues = array();
            foreach ($groupe as $value) {
                if (!in_array($value, $valueSet)) {
                    throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $value));
                }
                $convertedValues []= array_search($value, $valueSet);
            }
            $groupe = $convertedValues;
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DiscountProgramTableMap::COL_GROUPE, $groupe, $comparison);
    }

    /**
     * Filter the query on the type column
     *
     * @param     mixed $type The value to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByType($type = null, $comparison = null)
    {
        $valueSet = DiscountProgramTableMap::getValueSet(DiscountProgramTableMap::COL_TYPE);
        if (is_scalar($type)) {
            if (!in_array($type, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $type));
            }
            $type = array_search($type, $valueSet);
        } elseif (is_array($type)) {
            $convertedValues = array();
            foreach ($type as $value) {
                if (!in_array($value, $valueSet)) {
                    throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $value));
                }
                $convertedValues []= array_search($value, $valueSet);
            }
            $type = $convertedValues;
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(DiscountProgramTableMap::COL_TYPE, $type, $comparison);
    }

    /**
     * Filter the query by a related \Model\CategoriePrestationDiscount object
     *
     * @param \Model\CategoriePrestationDiscount|ObjectCollection $categoriePrestationDiscount the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByDiscountProgram($categoriePrestationDiscount, $comparison = null)
    {
        if ($categoriePrestationDiscount instanceof \Model\CategoriePrestationDiscount) {
            return $this
                ->addUsingAlias(DiscountProgramTableMap::COL_ID, $categoriePrestationDiscount->getDiscountProgramId(), $comparison);
        } elseif ($categoriePrestationDiscount instanceof ObjectCollection) {
            return $this
                ->useDiscountProgramQuery()
                ->filterByPrimaryKeys($categoriePrestationDiscount->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByDiscountProgram() only accepts arguments of type \Model\CategoriePrestationDiscount or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the DiscountProgram relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function joinDiscountProgram($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('DiscountProgram');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'DiscountProgram');
        }

        return $this;
    }

    /**
     * Use the DiscountProgram relation CategoriePrestationDiscount object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\CategoriePrestationDiscountQuery A secondary query class using the current class as primary query
     */
    public function useDiscountProgramQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinDiscountProgram($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'DiscountProgram', '\Model\CategoriePrestationDiscountQuery');
    }

    /**
     * Use the DiscountProgram relation CategoriePrestationDiscount object
     *
     * @param callable(\Model\CategoriePrestationDiscountQuery):\Model\CategoriePrestationDiscountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withDiscountProgramQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useDiscountProgramQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the DiscountProgram relation to the CategoriePrestationDiscount table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\CategoriePrestationDiscountQuery The inner query object of the EXISTS statement
     */
    public function useDiscountProgramExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('DiscountProgram', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the DiscountProgram relation to the CategoriePrestationDiscount table for a NOT EXISTS query.
     *
     * @see useDiscountProgramExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\CategoriePrestationDiscountQuery The inner query object of the NOT EXISTS statement
     */
    public function useDiscountProgramNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('DiscountProgram', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related CategoriePrestation object
     * using the categorie_prestation_discount table as cross reference
     *
     * @param CategoriePrestation $categoriePrestation the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function filterByCategoriePrestation($categoriePrestation, $comparison = Criteria::EQUAL)
    {
        return $this
            ->useDiscountProgramQuery()
            ->filterByCategoriePrestation($categoriePrestation, $comparison)
            ->endUse();
    }

    /**
     * Exclude object from result
     *
     * @param   ChildDiscountProgram $discountProgram Object to remove from the list of results
     *
     * @return $this|ChildDiscountProgramQuery The current query, for fluid interface
     */
    public function prune($discountProgram = null)
    {
        if ($discountProgram) {
            $this->addUsingAlias(DiscountProgramTableMap::COL_ID, $discountProgram->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the discount_program table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DiscountProgramTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            DiscountProgramTableMap::clearInstancePool();
            DiscountProgramTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(DiscountProgramTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(DiscountProgramTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            DiscountProgramTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            DiscountProgramTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // DiscountProgramQuery
