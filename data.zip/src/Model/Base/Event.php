<?php

namespace Model\Base;

use \DateTime;
use \Exception;
use \PDO;
use Model\Account as ChildAccount;
use Model\AccountQuery as ChildAccountQuery;
use Model\BidJob as ChildBidJob;
use Model\BidJobItem as ChildBidJobItem;
use Model\BidJobItemQuery as ChildBidJobItemQuery;
use Model\BidJobQuery as ChildBidJobQuery;
use Model\Event as ChildEvent;
use Model\EventBidJobItem as ChildEventBidJobItem;
use Model\EventBidJobItemQuery as ChildEventBidJobItemQuery;
use Model\EventMethodology as ChildEventMethodology;
use Model\EventMethodologyQuery as ChildEventMethodologyQuery;
use Model\EventQuery as ChildEventQuery;
use Model\Job as ChildJob;
use Model\JobQuery as ChildJobQuery;
use Model\Module as ChildModule;
use Model\ModuleQuery as ChildModuleQuery;
use Model\RefEventStatus as ChildRefEventStatus;
use Model\RefEventStatusQuery as ChildRefEventStatusQuery;
use Model\RefRoom as ChildRefRoom;
use Model\RefRoomQuery as ChildRefRoomQuery;
use Model\RefSalesForce as ChildRefSalesForce;
use Model\RefSalesForceQuery as ChildRefSalesForceQuery;
use Model\RefTimeSlot as ChildRefTimeSlot;
use Model\RefTimeSlotQuery as ChildRefTimeSlotQuery;
use Model\Site as ChildSite;
use Model\SiteQuery as ChildSiteQuery;
use Model\User as ChildUser;
use Model\UserQuery as ChildUserQuery;
use Model\Map\BidJobItemTableMap;
use Model\Map\EventBidJobItemTableMap;
use Model\Map\EventTableMap;
use Model\Map\ModuleTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveRecord\ActiveRecordInterface;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\BadMethodCallException;
use Propel\Runtime\Exception\LogicException;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Parser\AbstractParser;
use Propel\Runtime\Util\PropelDateTime;

/**
 * Base class that represents a row from the 'event' table.
 *
 *
 *
 * @package    propel.generator.src.Model.Base
 */
abstract class Event implements ActiveRecordInterface
{
    /**
     * TableMap class name
     */
    const TABLE_MAP = '\\Model\\Map\\EventTableMap';


    /**
     * attribute to determine if this object has previously been saved.
     * @var boolean
     */
    protected $new = true;

    /**
     * attribute to determine whether this object has been deleted.
     * @var boolean
     */
    protected $deleted = false;

    /**
     * The columns that have been modified in current object.
     * Tracking modified columns allows us to only update modified columns.
     * @var array
     */
    protected $modifiedColumns = array();

    /**
     * The (virtual) columns that are added at runtime
     * The formatters can add supplementary columns based on a resultset
     * @var array
     */
    protected $virtualColumns = array();

    /**
     * The value for the id field.
     *
     * @var        int
     */
    protected $id;

    /**
     * The value for the sams_event_id field.
     *
     * @var        string
     */
    protected $sams_event_id;

    /**
     * The value for the job_id field.
     *
     * @var        int|null
     */
    protected $job_id;

    /**
     * The value for the bid_job_id field.
     *
     * @var        int|null
     */
    protected $bid_job_id;

    /**
     * The value for the bid_job_archive_id field.
     *
     * @var        int|null
     */
    protected $bid_job_archive_id;

    /**
     * The value for the ref_room_id field.
     *
     * @var        int|null
     */
    protected $ref_room_id;

    /**
     * The value for the ref_time_slot_id field.
     *
     * @var        int|null
     */
    protected $ref_time_slot_id;

    /**
     * The value for the event_status_id field.
     *
     * @var        int|null
     */
    protected $event_status_id;

    /**
     * The value for the date field.
     *
     * @var        DateTime|null
     */
    protected $date;

    /**
     * The value for the confirmed_date field.
     *
     * @var        DateTime|null
     */
    protected $confirmed_date;

    /**
     * The value for the active_date field.
     *
     * @var        DateTime|null
     */
    protected $active_date;

    /**
     * The value for the event_methodology_id field.
     *
     * @var        int|null
     */
    protected $event_methodology_id;

    /**
     * The value for the status field.
     *
     * Note: this column has a database default value of: 0
     * @var        int|null
     */
    protected $status;

    /**
     * The value for the comments field.
     *
     * @var        string|null
     */
    protected $comments;

    /**
     * The value for the facility_note field.
     *
     * @var        string|null
     */
    protected $facility_note;

    /**
     * The value for the site_id field.
     *
     * @var        int|null
     */
    protected $site_id;

    /**
     * The value for the account_id field.
     *
     * @var        int|null
     */
    protected $account_id;

    /**
     * The value for the account_sf_id field.
     *
     * @var        string|null
     */
    protected $account_sf_id;

    /**
     * The value for the activity_currency field.
     *
     * @var        string|null
     */
    protected $activity_currency;

    /**
     * The value for the all_day_event field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $all_day_event;

    /**
     * The value for the archived field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $archived;

    /**
     * The value for the assigned_to_id field.
     *
     * @var        int|null
     */
    protected $assigned_to_id;

    /**
     * The value for the cancelled field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $cancelled;

    /**
     * The value for the recurring_event field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $recurring_event;

    /**
     * The value for the is_deleted field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $is_deleted;

    /**
     * The value for the is_deleted_c field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $is_deleted_c;

    /**
     * The value for the description field.
     *
     * @var        string|null
     */
    protected $description;

    /**
     * The value for the duration_minutes field.
     *
     * @var        int|null
     */
    protected $duration_minutes;

    /**
     * The value for the end_date_time field.
     *
     * @var        DateTime|null
     */
    protected $end_date_time;

    /**
     * The value for the record_type_id field.
     *
     * @var        int|null
     */
    protected $record_type_id;

    /**
     * The value for the event_sub_type_id field.
     *
     * @var        int|null
     */
    protected $event_sub_type_id;

    /**
     * The value for the job_status field.
     *
     * @var        string|null
     */
    protected $job_status;

    /**
     * The value for the location_c field.
     *
     * @var        string|null
     */
    protected $location_c;

    /**
     * The value for the reminder_date field.
     *
     * @var        DateTime|null
     */
    protected $reminder_date;

    /**
     * The value for the reminder_set field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $reminder_set;

    /**
     * The value for the start_date_time field.
     *
     * @var        DateTime|null
     */
    protected $start_date_time;

    /**
     * The value for the subject field.
     *
     * @var        string|null
     */
    protected $subject;

    /**
     * The value for the recurrence_time_zone field.
     *
     * @var        string|null
     */
    protected $recurrence_time_zone;

    /**
     * The value for the created_by_sf_id field.
     *
     * @var        string
     */
    protected $created_by_sf_id;

    /**
     * The value for the pmtool_updated field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $pmtool_updated;

    /**
     * The value for the event_holder_id field.
     *
     * @var        int|null
     */
    protected $event_holder_id;

    /**
     * The value for the api_created_date field.
     *
     * @var        DateTime|null
     */
    protected $api_created_date;

    /**
     * The value for the api_updated_date field.
     *
     * @var        DateTime|null
     */
    protected $api_updated_date;

    /**
     * The value for the is_group field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $is_group;

    /**
     * The value for the created_date field.
     *
     * @var        DateTime|null
     */
    protected $created_date;

    /**
     * The value for the updated_date field.
     *
     * @var        DateTime|null
     */
    protected $updated_date;

    /**
     * @var        ChildUser
     */
    protected $aEventHolderBy;

    /**
     * @var        ChildJob
     */
    protected $aJob;

    /**
     * @var        ChildBidJob
     */
    protected $aBidJob;

    /**
     * @var        ChildRefRoom
     */
    protected $aRefRoom;

    /**
     * @var        ChildRefEventStatus
     */
    protected $aRefEventStatus;

    /**
     * @var        ChildRefTimeSlot
     */
    protected $aRefTimeSlot;

    /**
     * @var        ChildEventMethodology
     */
    protected $aEventMethodology;

    /**
     * @var        ChildAccount
     */
    protected $aAccount;

    /**
     * @var        ChildUser
     */
    protected $aAssignedTo;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aRecordType;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aEventSubType;

    /**
     * @var        ChildSite
     */
    protected $aSite;

    /**
     * @var        ObjectCollection|ChildModule[] Collection to store aggregation of ChildModule objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildModule> Collection to store aggregation of ChildModule objects.
     */
    protected $collModules;
    protected $collModulesPartial;

    /**
     * @var        ObjectCollection|ChildBidJobItem[] Collection to store aggregation of ChildBidJobItem objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildBidJobItem> Collection to store aggregation of ChildBidJobItem objects.
     */
    protected $collEvents;
    protected $collEventsPartial;

    /**
     * @var        ObjectCollection|ChildEventBidJobItem[] Collection to store aggregation of ChildEventBidJobItem objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEventBidJobItem> Collection to store aggregation of ChildEventBidJobItem objects.
     */
    protected $collEventBidJobItems;
    protected $collEventBidJobItemsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     *
     * @var boolean
     */
    protected $alreadyInSave = false;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildModule[]
     * @phpstan-var ObjectCollection&\Traversable<ChildModule>
     */
    protected $modulesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildBidJobItem[]
     * @phpstan-var ObjectCollection&\Traversable<ChildBidJobItem>
     */
    protected $eventsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEventBidJobItem[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEventBidJobItem>
     */
    protected $eventBidJobItemsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see __construct()
     */
    public function applyDefaultValues()
    {
        $this->status = 0;
        $this->all_day_event = false;
        $this->archived = false;
        $this->cancelled = false;
        $this->recurring_event = false;
        $this->is_deleted = false;
        $this->is_deleted_c = false;
        $this->reminder_set = false;
        $this->pmtool_updated = false;
        $this->is_group = false;
    }

    /**
     * Initializes internal state of Model\Base\Event object.
     * @see applyDefaults()
     */
    public function __construct()
    {
        $this->applyDefaultValues();
    }

    /**
     * Returns whether the object has been modified.
     *
     * @return boolean True if the object has been modified.
     */
    public function isModified()
    {
        return !!$this->modifiedColumns;
    }

    /**
     * Has specified column been modified?
     *
     * @param  string  $col column fully qualified name (TableMap::TYPE_COLNAME), e.g. Book::AUTHOR_ID
     * @return boolean True if $col has been modified.
     */
    public function isColumnModified($col)
    {
        return $this->modifiedColumns && isset($this->modifiedColumns[$col]);
    }

    /**
     * Get the columns that have been modified in this object.
     * @return array A unique list of the modified column names for this object.
     */
    public function getModifiedColumns()
    {
        return $this->modifiedColumns ? array_keys($this->modifiedColumns) : [];
    }

    /**
     * Returns whether the object has ever been saved.  This will
     * be false, if the object was retrieved from storage or was created
     * and then saved.
     *
     * @return boolean true, if the object has never been persisted.
     */
    public function isNew()
    {
        return $this->new;
    }

    /**
     * Setter for the isNew attribute.  This method will be called
     * by Propel-generated children and objects.
     *
     * @param boolean $b the state of the object.
     */
    public function setNew($b)
    {
        $this->new = (boolean) $b;
    }

    /**
     * Whether this object has been deleted.
     * @return boolean The deleted state of this object.
     */
    public function isDeleted()
    {
        return $this->deleted;
    }

    /**
     * Specify whether this object has been deleted.
     * @param  boolean $b The deleted state of this object.
     * @return void
     */
    public function setDeleted($b)
    {
        $this->deleted = (boolean) $b;
    }

    /**
     * Sets the modified state for the object to be false.
     * @param  string $col If supplied, only the specified column is reset.
     * @return void
     */
    public function resetModified($col = null)
    {
        if (null !== $col) {
            unset($this->modifiedColumns[$col]);
        } else {
            $this->modifiedColumns = array();
        }
    }

    /**
     * Compares this with another <code>Event</code> instance.  If
     * <code>obj</code> is an instance of <code>Event</code>, delegates to
     * <code>equals(Event)</code>.  Otherwise, returns <code>false</code>.
     *
     * @param  mixed   $obj The object to compare to.
     * @return boolean Whether equal to the object specified.
     */
    public function equals($obj)
    {
        if (!$obj instanceof static) {
            return false;
        }

        if ($this === $obj) {
            return true;
        }

        if (null === $this->getPrimaryKey() || null === $obj->getPrimaryKey()) {
            return false;
        }

        return $this->getPrimaryKey() === $obj->getPrimaryKey();
    }

    /**
     * Get the associative array of the virtual columns in this object
     *
     * @return array
     */
    public function getVirtualColumns()
    {
        return $this->virtualColumns;
    }

    /**
     * Checks the existence of a virtual column in this object
     *
     * @param  string  $name The virtual column name
     * @return boolean
     */
    public function hasVirtualColumn($name)
    {
        return array_key_exists($name, $this->virtualColumns);
    }

    /**
     * Get the value of a virtual column in this object
     *
     * @param  string $name The virtual column name
     * @return mixed
     *
     * @throws PropelException
     */
    public function getVirtualColumn($name)
    {
        if (!$this->hasVirtualColumn($name)) {
            throw new PropelException(sprintf('Cannot get value of inexistent virtual column %s.', $name));
        }

        return $this->virtualColumns[$name];
    }

    /**
     * Set the value of a virtual column in this object
     *
     * @param string $name  The virtual column name
     * @param mixed  $value The value to give to the virtual column
     *
     * @return $this The current object, for fluid interface
     */
    public function setVirtualColumn($name, $value)
    {
        $this->virtualColumns[$name] = $value;

        return $this;
    }

    /**
     * Logs a message using Propel::log().
     *
     * @param  string  $msg
     * @param  int     $priority One of the Propel::LOG_* logging levels
     * @return void
     */
    protected function log($msg, $priority = Propel::LOG_INFO)
    {
        Propel::log(get_class($this) . ': ' . $msg, $priority);
    }

    /**
     * Export the current object properties to a string, using a given parser format
     * <code>
     * $book = BookQuery::create()->findPk(9012);
     * echo $book->exportTo('JSON');
     *  => {"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * @param  mixed   $parser                 A AbstractParser instance, or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param  boolean $includeLazyLoadColumns (optional) Whether to include lazy load(ed) columns. Defaults to TRUE.
     * @param  string  $keyType                (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM. Defaults to TableMap::TYPE_PHPNAME.
     * @return string  The exported data
     */
    public function exportTo($parser, $includeLazyLoadColumns = true, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        return $parser->fromArray($this->toArray($keyType, $includeLazyLoadColumns, array(), true));
    }

    /**
     * Clean up internal collections prior to serializing
     * Avoids recursive loops that turn into segmentation faults when serializing
     */
    public function __sleep()
    {
        $this->clearAllReferences();

        $cls = new \ReflectionClass($this);
        $propertyNames = [];
        $serializableProperties = array_diff($cls->getProperties(), $cls->getProperties(\ReflectionProperty::IS_STATIC));

        foreach($serializableProperties as $property) {
            $propertyNames[] = $property->getName();
        }

        return $propertyNames;
    }

    /**
     * Get the [id] column value.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the [sams_event_id] column value.
     *
     * @return string
     */
    public function getSamsEventId()
    {
        return $this->sams_event_id;
    }

    /**
     * Get the [job_id] column value.
     *
     * @return int|null
     */
    public function getJobId()
    {
        return $this->job_id;
    }

    /**
     * Get the [bid_job_id] column value.
     *
     * @return int|null
     */
    public function getBidJobId()
    {
        return $this->bid_job_id;
    }

    /**
     * Get the [bid_job_archive_id] column value.
     *
     * @return int|null
     */
    public function getBidJobArchiveId()
    {
        return $this->bid_job_archive_id;
    }

    /**
     * Get the [ref_room_id] column value.
     *
     * @return int|null
     */
    public function getRefRoomId()
    {
        return $this->ref_room_id;
    }

    /**
     * Get the [ref_time_slot_id] column value.
     *
     * @return int|null
     */
    public function getRefTimeSlotId()
    {
        return $this->ref_time_slot_id;
    }

    /**
     * Get the [event_status_id] column value.
     *
     * @return int|null
     */
    public function getEventStatusId()
    {
        return $this->event_status_id;
    }

    /**
     * Get the [optionally formatted] temporal [date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getDate($format = null)
    {
        if ($format === null) {
            return $this->date;
        } else {
            return $this->date instanceof \DateTimeInterface ? $this->date->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [confirmed_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getConfirmedDate($format = null)
    {
        if ($format === null) {
            return $this->confirmed_date;
        } else {
            return $this->confirmed_date instanceof \DateTimeInterface ? $this->confirmed_date->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [active_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getActiveDate($format = null)
    {
        if ($format === null) {
            return $this->active_date;
        } else {
            return $this->active_date instanceof \DateTimeInterface ? $this->active_date->format($format) : null;
        }
    }

    /**
     * Get the [event_methodology_id] column value.
     *
     * @return int|null
     */
    public function getEventMethodologyId()
    {
        return $this->event_methodology_id;
    }

    /**
     * Get the [status] column value.
     *
     * @return string|null
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function getStatus()
    {
        if (null === $this->status) {
            return null;
        }
        $valueSet = EventTableMap::getValueSet(EventTableMap::COL_STATUS);
        if (!isset($valueSet[$this->status])) {
            throw new PropelException('Unknown stored enum key: ' . $this->status);
        }

        return $valueSet[$this->status];
    }

    /**
     * Get the [comments] column value.
     *
     * @return string|null
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Get the [facility_note] column value.
     *
     * @return string|null
     */
    public function getFacilityNote()
    {
        return $this->facility_note;
    }

    /**
     * Get the [site_id] column value.
     *
     * @return int|null
     */
    public function getSiteId()
    {
        return $this->site_id;
    }

    /**
     * Get the [account_id] column value.
     *
     * @return int|null
     */
    public function getAccountId()
    {
        return $this->account_id;
    }

    /**
     * Get the [account_sf_id] column value.
     *
     * @return string|null
     */
    public function getAccountSfId()
    {
        return $this->account_sf_id;
    }

    /**
     * Get the [activity_currency] column value.
     *
     * @return string|null
     */
    public function getActivityCurrency()
    {
        return $this->activity_currency;
    }

    /**
     * Get the [all_day_event] column value.
     *
     * @return boolean
     */
    public function getAllDayEvent()
    {
        return $this->all_day_event;
    }

    /**
     * Get the [all_day_event] column value.
     *
     * @return boolean
     */
    public function isAllDayEvent()
    {
        return $this->getAllDayEvent();
    }

    /**
     * Get the [archived] column value.
     *
     * @return boolean
     */
    public function getArchived()
    {
        return $this->archived;
    }

    /**
     * Get the [archived] column value.
     *
     * @return boolean
     */
    public function isArchived()
    {
        return $this->getArchived();
    }

    /**
     * Get the [assigned_to_id] column value.
     *
     * @return int|null
     */
    public function getAssignedToId()
    {
        return $this->assigned_to_id;
    }

    /**
     * Get the [cancelled] column value.
     *
     * @return boolean
     */
    public function getCancelled()
    {
        return $this->cancelled;
    }

    /**
     * Get the [cancelled] column value.
     *
     * @return boolean
     */
    public function isCancelled()
    {
        return $this->getCancelled();
    }

    /**
     * Get the [recurring_event] column value.
     *
     * @return boolean
     */
    public function getRecurringEvent()
    {
        return $this->recurring_event;
    }

    /**
     * Get the [recurring_event] column value.
     *
     * @return boolean
     */
    public function isRecurringEvent()
    {
        return $this->getRecurringEvent();
    }

    /**
     * Get the [is_deleted] column value.
     *
     * @return boolean
     */
    public function getIsDeleted()
    {
        return $this->is_deleted;
    }

    /**
     * Get the [is_deleted_c] column value.
     *
     * @return boolean
     */
    public function getIsDeletedC()
    {
        return $this->is_deleted_c;
    }

    /**
     * Get the [is_deleted_c] column value.
     *
     * @return boolean
     */
    public function isDeletedC()
    {
        return $this->getIsDeletedC();
    }

    /**
     * Get the [description] column value.
     *
     * @return string|null
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Get the [duration_minutes] column value.
     *
     * @return int|null
     */
    public function getDurationMinutes()
    {
        return $this->duration_minutes;
    }

    /**
     * Get the [optionally formatted] temporal [end_date_time] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getEndDateTime($format = null)
    {
        if ($format === null) {
            return $this->end_date_time;
        } else {
            return $this->end_date_time instanceof \DateTimeInterface ? $this->end_date_time->format($format) : null;
        }
    }

    /**
     * Get the [record_type_id] column value.
     *
     * @return int|null
     */
    public function getRecordTypeId()
    {
        return $this->record_type_id;
    }

    /**
     * Get the [event_sub_type_id] column value.
     *
     * @return int|null
     */
    public function getEventSubTypeId()
    {
        return $this->event_sub_type_id;
    }

    /**
     * Get the [job_status] column value.
     *
     * @return string|null
     */
    public function getJobStatus()
    {
        return $this->job_status;
    }

    /**
     * Get the [location_c] column value.
     *
     * @return string|null
     */
    public function getLocationC()
    {
        return $this->location_c;
    }

    /**
     * Get the [optionally formatted] temporal [reminder_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getReminderDate($format = null)
    {
        if ($format === null) {
            return $this->reminder_date;
        } else {
            return $this->reminder_date instanceof \DateTimeInterface ? $this->reminder_date->format($format) : null;
        }
    }

    /**
     * Get the [reminder_set] column value.
     *
     * @return boolean
     */
    public function getReminderSet()
    {
        return $this->reminder_set;
    }

    /**
     * Get the [reminder_set] column value.
     *
     * @return boolean
     */
    public function isReminderSet()
    {
        return $this->getReminderSet();
    }

    /**
     * Get the [optionally formatted] temporal [start_date_time] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getStartDateTime($format = null)
    {
        if ($format === null) {
            return $this->start_date_time;
        } else {
            return $this->start_date_time instanceof \DateTimeInterface ? $this->start_date_time->format($format) : null;
        }
    }

    /**
     * Get the [subject] column value.
     *
     * @return string|null
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * Get the [recurrence_time_zone] column value.
     *
     * @return string|null
     */
    public function getRecurrenceTimeZone()
    {
        return $this->recurrence_time_zone;
    }

    /**
     * Get the [created_by_sf_id] column value.
     *
     * @return string
     */
    public function getCreatedBySfId()
    {
        return $this->created_by_sf_id;
    }

    /**
     * Get the [pmtool_updated] column value.
     *
     * @return boolean
     */
    public function getPmtoolUpdated()
    {
        return $this->pmtool_updated;
    }

    /**
     * Get the [pmtool_updated] column value.
     *
     * @return boolean
     */
    public function isPmtoolUpdated()
    {
        return $this->getPmtoolUpdated();
    }

    /**
     * Get the [event_holder_id] column value.
     *
     * @return int|null
     */
    public function getEventHolderId()
    {
        return $this->event_holder_id;
    }

    /**
     * Get the [optionally formatted] temporal [api_created_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getApiCreatedDate($format = null)
    {
        if ($format === null) {
            return $this->api_created_date;
        } else {
            return $this->api_created_date instanceof \DateTimeInterface ? $this->api_created_date->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [api_updated_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getApiUpdatedDate($format = null)
    {
        if ($format === null) {
            return $this->api_updated_date;
        } else {
            return $this->api_updated_date instanceof \DateTimeInterface ? $this->api_updated_date->format($format) : null;
        }
    }

    /**
     * Get the [is_group] column value.
     *
     * @return boolean
     */
    public function getIsGroup()
    {
        return $this->is_group;
    }

    /**
     * Get the [is_group] column value.
     *
     * @return boolean
     */
    public function isGroup()
    {
        return $this->getIsGroup();
    }

    /**
     * Get the [optionally formatted] temporal [created_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getCreatedDate($format = null)
    {
        if ($format === null) {
            return $this->created_date;
        } else {
            return $this->created_date instanceof \DateTimeInterface ? $this->created_date->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [updated_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getUpdatedDate($format = null)
    {
        if ($format === null) {
            return $this->updated_date;
        } else {
            return $this->updated_date instanceof \DateTimeInterface ? $this->updated_date->format($format) : null;
        }
    }

    /**
     * Set the value of [id] column.
     *
     * @param int $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id !== $v) {
            $this->id = $v;
            $this->modifiedColumns[EventTableMap::COL_ID] = true;
        }

        return $this;
    } // setId()

    /**
     * Set the value of [sams_event_id] column.
     *
     * @param string $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setSamsEventId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sams_event_id !== $v) {
            $this->sams_event_id = $v;
            $this->modifiedColumns[EventTableMap::COL_SAMS_EVENT_ID] = true;
        }

        return $this;
    } // setSamsEventId()

    /**
     * Set the value of [job_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setJobId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->job_id !== $v) {
            $this->job_id = $v;
            $this->modifiedColumns[EventTableMap::COL_JOB_ID] = true;
        }

        if ($this->aJob !== null && $this->aJob->getId() !== $v) {
            $this->aJob = null;
        }

        return $this;
    } // setJobId()

    /**
     * Set the value of [bid_job_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setBidJobId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->bid_job_id !== $v) {
            $this->bid_job_id = $v;
            $this->modifiedColumns[EventTableMap::COL_BID_JOB_ID] = true;
        }

        if ($this->aBidJob !== null && $this->aBidJob->getId() !== $v) {
            $this->aBidJob = null;
        }

        return $this;
    } // setBidJobId()

    /**
     * Set the value of [bid_job_archive_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setBidJobArchiveId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->bid_job_archive_id !== $v) {
            $this->bid_job_archive_id = $v;
            $this->modifiedColumns[EventTableMap::COL_BID_JOB_ARCHIVE_ID] = true;
        }

        return $this;
    } // setBidJobArchiveId()

    /**
     * Set the value of [ref_room_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setRefRoomId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->ref_room_id !== $v) {
            $this->ref_room_id = $v;
            $this->modifiedColumns[EventTableMap::COL_REF_ROOM_ID] = true;
        }

        if ($this->aRefRoom !== null && $this->aRefRoom->getId() !== $v) {
            $this->aRefRoom = null;
        }

        return $this;
    } // setRefRoomId()

    /**
     * Set the value of [ref_time_slot_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setRefTimeSlotId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->ref_time_slot_id !== $v) {
            $this->ref_time_slot_id = $v;
            $this->modifiedColumns[EventTableMap::COL_REF_TIME_SLOT_ID] = true;
        }

        if ($this->aRefTimeSlot !== null && $this->aRefTimeSlot->getId() !== $v) {
            $this->aRefTimeSlot = null;
        }

        return $this;
    } // setRefTimeSlotId()

    /**
     * Set the value of [event_status_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setEventStatusId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->event_status_id !== $v) {
            $this->event_status_id = $v;
            $this->modifiedColumns[EventTableMap::COL_EVENT_STATUS_ID] = true;
        }

        if ($this->aRefEventStatus !== null && $this->aRefEventStatus->getId() !== $v) {
            $this->aRefEventStatus = null;
        }

        return $this;
    } // setEventStatusId()

    /**
     * Sets the value of [date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date !== null || $dt !== null) {
            if ($this->date === null || $dt === null || $dt->format("Y-m-d") !== $this->date->format("Y-m-d")) {
                $this->date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setDate()

    /**
     * Sets the value of [confirmed_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setConfirmedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->confirmed_date !== null || $dt !== null) {
            if ($this->confirmed_date === null || $dt === null || $dt->format("Y-m-d") !== $this->confirmed_date->format("Y-m-d")) {
                $this->confirmed_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_CONFIRMED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setConfirmedDate()

    /**
     * Sets the value of [active_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setActiveDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->active_date !== null || $dt !== null) {
            if ($this->active_date === null || $dt === null || $dt->format("Y-m-d") !== $this->active_date->format("Y-m-d")) {
                $this->active_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_ACTIVE_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setActiveDate()

    /**
     * Set the value of [event_methodology_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setEventMethodologyId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->event_methodology_id !== $v) {
            $this->event_methodology_id = $v;
            $this->modifiedColumns[EventTableMap::COL_EVENT_METHODOLOGY_ID] = true;
        }

        if ($this->aEventMethodology !== null && $this->aEventMethodology->getId() !== $v) {
            $this->aEventMethodology = null;
        }

        return $this;
    } // setEventMethodologyId()

    /**
     * Set the value of [status] column.
     *
     * @param  string|null $v new value
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function setStatus($v)
    {
        if ($v !== null) {
            $valueSet = EventTableMap::getValueSet(EventTableMap::COL_STATUS);
            if (!in_array($v, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $v));
            }
            $v = array_search($v, $valueSet);
        }

        if ($this->status !== $v) {
            $this->status = $v;
            $this->modifiedColumns[EventTableMap::COL_STATUS] = true;
        }

        return $this;
    } // setStatus()

    /**
     * Set the value of [comments] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setComments($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->comments !== $v) {
            $this->comments = $v;
            $this->modifiedColumns[EventTableMap::COL_COMMENTS] = true;
        }

        return $this;
    } // setComments()

    /**
     * Set the value of [facility_note] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setFacilityNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->facility_note !== $v) {
            $this->facility_note = $v;
            $this->modifiedColumns[EventTableMap::COL_FACILITY_NOTE] = true;
        }

        return $this;
    } // setFacilityNote()

    /**
     * Set the value of [site_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setSiteId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->site_id !== $v) {
            $this->site_id = $v;
            $this->modifiedColumns[EventTableMap::COL_SITE_ID] = true;
        }

        if ($this->aSite !== null && $this->aSite->getId() !== $v) {
            $this->aSite = null;
        }

        return $this;
    } // setSiteId()

    /**
     * Set the value of [account_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setAccountId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->account_id !== $v) {
            $this->account_id = $v;
            $this->modifiedColumns[EventTableMap::COL_ACCOUNT_ID] = true;
        }

        if ($this->aAccount !== null && $this->aAccount->getId() !== $v) {
            $this->aAccount = null;
        }

        return $this;
    } // setAccountId()

    /**
     * Set the value of [account_sf_id] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setAccountSfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->account_sf_id !== $v) {
            $this->account_sf_id = $v;
            $this->modifiedColumns[EventTableMap::COL_ACCOUNT_SF_ID] = true;
        }

        return $this;
    } // setAccountSfId()

    /**
     * Set the value of [activity_currency] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setActivityCurrency($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->activity_currency !== $v) {
            $this->activity_currency = $v;
            $this->modifiedColumns[EventTableMap::COL_ACTIVITY_CURRENCY] = true;
        }

        return $this;
    } // setActivityCurrency()

    /**
     * Sets the value of the [all_day_event] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setAllDayEvent($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->all_day_event !== $v) {
            $this->all_day_event = $v;
            $this->modifiedColumns[EventTableMap::COL_ALL_DAY_EVENT] = true;
        }

        return $this;
    } // setAllDayEvent()

    /**
     * Sets the value of the [archived] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setArchived($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->archived !== $v) {
            $this->archived = $v;
            $this->modifiedColumns[EventTableMap::COL_ARCHIVED] = true;
        }

        return $this;
    } // setArchived()

    /**
     * Set the value of [assigned_to_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setAssignedToId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->assigned_to_id !== $v) {
            $this->assigned_to_id = $v;
            $this->modifiedColumns[EventTableMap::COL_ASSIGNED_TO_ID] = true;
        }

        if ($this->aAssignedTo !== null && $this->aAssignedTo->getId() !== $v) {
            $this->aAssignedTo = null;
        }

        return $this;
    } // setAssignedToId()

    /**
     * Sets the value of the [cancelled] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setCancelled($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->cancelled !== $v) {
            $this->cancelled = $v;
            $this->modifiedColumns[EventTableMap::COL_CANCELLED] = true;
        }

        return $this;
    } // setCancelled()

    /**
     * Sets the value of the [recurring_event] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setRecurringEvent($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->recurring_event !== $v) {
            $this->recurring_event = $v;
            $this->modifiedColumns[EventTableMap::COL_RECURRING_EVENT] = true;
        }

        return $this;
    } // setRecurringEvent()

    /**
     * Sets the value of the [is_deleted] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setIsDeleted($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_deleted !== $v) {
            $this->is_deleted = $v;
            $this->modifiedColumns[EventTableMap::COL_IS_DELETED] = true;
        }

        return $this;
    } // setIsDeleted()

    /**
     * Sets the value of the [is_deleted_c] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setIsDeletedC($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_deleted_c !== $v) {
            $this->is_deleted_c = $v;
            $this->modifiedColumns[EventTableMap::COL_IS_DELETED_C] = true;
        }

        return $this;
    } // setIsDeletedC()

    /**
     * Set the value of [description] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setDescription($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->description !== $v) {
            $this->description = $v;
            $this->modifiedColumns[EventTableMap::COL_DESCRIPTION] = true;
        }

        return $this;
    } // setDescription()

    /**
     * Set the value of [duration_minutes] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setDurationMinutes($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->duration_minutes !== $v) {
            $this->duration_minutes = $v;
            $this->modifiedColumns[EventTableMap::COL_DURATION_MINUTES] = true;
        }

        return $this;
    } // setDurationMinutes()

    /**
     * Sets the value of [end_date_time] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setEndDateTime($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->end_date_time !== null || $dt !== null) {
            if ($this->end_date_time === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->end_date_time->format("Y-m-d H:i:s.u")) {
                $this->end_date_time = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_END_DATE_TIME] = true;
            }
        } // if either are not null

        return $this;
    } // setEndDateTime()

    /**
     * Set the value of [record_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setRecordTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->record_type_id !== $v) {
            $this->record_type_id = $v;
            $this->modifiedColumns[EventTableMap::COL_RECORD_TYPE_ID] = true;
        }

        if ($this->aRecordType !== null && $this->aRecordType->getId() !== $v) {
            $this->aRecordType = null;
        }

        return $this;
    } // setRecordTypeId()

    /**
     * Set the value of [event_sub_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setEventSubTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->event_sub_type_id !== $v) {
            $this->event_sub_type_id = $v;
            $this->modifiedColumns[EventTableMap::COL_EVENT_SUB_TYPE_ID] = true;
        }

        if ($this->aEventSubType !== null && $this->aEventSubType->getId() !== $v) {
            $this->aEventSubType = null;
        }

        return $this;
    } // setEventSubTypeId()

    /**
     * Set the value of [job_status] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setJobStatus($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->job_status !== $v) {
            $this->job_status = $v;
            $this->modifiedColumns[EventTableMap::COL_JOB_STATUS] = true;
        }

        return $this;
    } // setJobStatus()

    /**
     * Set the value of [location_c] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setLocationC($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->location_c !== $v) {
            $this->location_c = $v;
            $this->modifiedColumns[EventTableMap::COL_LOCATION_C] = true;
        }

        return $this;
    } // setLocationC()

    /**
     * Sets the value of [reminder_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setReminderDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->reminder_date !== null || $dt !== null) {
            if ($this->reminder_date === null || $dt === null || $dt->format("Y-m-d") !== $this->reminder_date->format("Y-m-d")) {
                $this->reminder_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_REMINDER_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setReminderDate()

    /**
     * Sets the value of the [reminder_set] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setReminderSet($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->reminder_set !== $v) {
            $this->reminder_set = $v;
            $this->modifiedColumns[EventTableMap::COL_REMINDER_SET] = true;
        }

        return $this;
    } // setReminderSet()

    /**
     * Sets the value of [start_date_time] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setStartDateTime($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->start_date_time !== null || $dt !== null) {
            if ($this->start_date_time === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->start_date_time->format("Y-m-d H:i:s.u")) {
                $this->start_date_time = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_START_DATE_TIME] = true;
            }
        } // if either are not null

        return $this;
    } // setStartDateTime()

    /**
     * Set the value of [subject] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setSubject($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->subject !== $v) {
            $this->subject = $v;
            $this->modifiedColumns[EventTableMap::COL_SUBJECT] = true;
        }

        return $this;
    } // setSubject()

    /**
     * Set the value of [recurrence_time_zone] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setRecurrenceTimeZone($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->recurrence_time_zone !== $v) {
            $this->recurrence_time_zone = $v;
            $this->modifiedColumns[EventTableMap::COL_RECURRENCE_TIME_ZONE] = true;
        }

        return $this;
    } // setRecurrenceTimeZone()

    /**
     * Set the value of [created_by_sf_id] column.
     *
     * @param string $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setCreatedBySfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->created_by_sf_id !== $v) {
            $this->created_by_sf_id = $v;
            $this->modifiedColumns[EventTableMap::COL_CREATED_BY_SF_ID] = true;
        }

        return $this;
    } // setCreatedBySfId()

    /**
     * Sets the value of the [pmtool_updated] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setPmtoolUpdated($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->pmtool_updated !== $v) {
            $this->pmtool_updated = $v;
            $this->modifiedColumns[EventTableMap::COL_PMTOOL_UPDATED] = true;
        }

        return $this;
    } // setPmtoolUpdated()

    /**
     * Set the value of [event_holder_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setEventHolderId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->event_holder_id !== $v) {
            $this->event_holder_id = $v;
            $this->modifiedColumns[EventTableMap::COL_EVENT_HOLDER_ID] = true;
        }

        if ($this->aEventHolderBy !== null && $this->aEventHolderBy->getId() !== $v) {
            $this->aEventHolderBy = null;
        }

        return $this;
    } // setEventHolderId()

    /**
     * Sets the value of [api_created_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setApiCreatedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->api_created_date !== null || $dt !== null) {
            if ($this->api_created_date === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->api_created_date->format("Y-m-d H:i:s.u")) {
                $this->api_created_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_API_CREATED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setApiCreatedDate()

    /**
     * Sets the value of [api_updated_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setApiUpdatedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->api_updated_date !== null || $dt !== null) {
            if ($this->api_updated_date === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->api_updated_date->format("Y-m-d H:i:s.u")) {
                $this->api_updated_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_API_UPDATED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setApiUpdatedDate()

    /**
     * Sets the value of the [is_group] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setIsGroup($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_group !== $v) {
            $this->is_group = $v;
            $this->modifiedColumns[EventTableMap::COL_IS_GROUP] = true;
        }

        return $this;
    } // setIsGroup()

    /**
     * Sets the value of [created_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setCreatedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->created_date !== null || $dt !== null) {
            if ($this->created_date === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->created_date->format("Y-m-d H:i:s.u")) {
                $this->created_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_CREATED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setCreatedDate()

    /**
     * Sets the value of [updated_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function setUpdatedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->updated_date !== null || $dt !== null) {
            if ($this->updated_date === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->updated_date->format("Y-m-d H:i:s.u")) {
                $this->updated_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EventTableMap::COL_UPDATED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setUpdatedDate()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->status !== 0) {
                return false;
            }

            if ($this->all_day_event !== false) {
                return false;
            }

            if ($this->archived !== false) {
                return false;
            }

            if ($this->cancelled !== false) {
                return false;
            }

            if ($this->recurring_event !== false) {
                return false;
            }

            if ($this->is_deleted !== false) {
                return false;
            }

            if ($this->is_deleted_c !== false) {
                return false;
            }

            if ($this->reminder_set !== false) {
                return false;
            }

            if ($this->pmtool_updated !== false) {
                return false;
            }

            if ($this->is_group !== false) {
                return false;
            }

        // otherwise, everything was equal, so return TRUE
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array   $row       The row returned by DataFetcher->fetch().
     * @param int     $startcol  0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @param string  $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                  One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                            TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false, $indexType = TableMap::TYPE_NUM)
    {
        try {

            $col = $row[TableMap::TYPE_NUM == $indexType ? 0 + $startcol : EventTableMap::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 1 + $startcol : EventTableMap::translateFieldName('SamsEventId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sams_event_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 2 + $startcol : EventTableMap::translateFieldName('JobId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->job_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 3 + $startcol : EventTableMap::translateFieldName('BidJobId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->bid_job_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 4 + $startcol : EventTableMap::translateFieldName('BidJobArchiveId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->bid_job_archive_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 5 + $startcol : EventTableMap::translateFieldName('RefRoomId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->ref_room_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 6 + $startcol : EventTableMap::translateFieldName('RefTimeSlotId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->ref_time_slot_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 7 + $startcol : EventTableMap::translateFieldName('EventStatusId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->event_status_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 8 + $startcol : EventTableMap::translateFieldName('Date', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 9 + $startcol : EventTableMap::translateFieldName('ConfirmedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->confirmed_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 10 + $startcol : EventTableMap::translateFieldName('ActiveDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->active_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 11 + $startcol : EventTableMap::translateFieldName('EventMethodologyId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->event_methodology_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 12 + $startcol : EventTableMap::translateFieldName('Status', TableMap::TYPE_PHPNAME, $indexType)];
            $this->status = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 13 + $startcol : EventTableMap::translateFieldName('Comments', TableMap::TYPE_PHPNAME, $indexType)];
            $this->comments = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 14 + $startcol : EventTableMap::translateFieldName('FacilityNote', TableMap::TYPE_PHPNAME, $indexType)];
            $this->facility_note = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 15 + $startcol : EventTableMap::translateFieldName('SiteId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->site_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 16 + $startcol : EventTableMap::translateFieldName('AccountId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 17 + $startcol : EventTableMap::translateFieldName('AccountSfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 18 + $startcol : EventTableMap::translateFieldName('ActivityCurrency', TableMap::TYPE_PHPNAME, $indexType)];
            $this->activity_currency = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 19 + $startcol : EventTableMap::translateFieldName('AllDayEvent', TableMap::TYPE_PHPNAME, $indexType)];
            $this->all_day_event = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 20 + $startcol : EventTableMap::translateFieldName('Archived', TableMap::TYPE_PHPNAME, $indexType)];
            $this->archived = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 21 + $startcol : EventTableMap::translateFieldName('AssignedToId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->assigned_to_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 22 + $startcol : EventTableMap::translateFieldName('Cancelled', TableMap::TYPE_PHPNAME, $indexType)];
            $this->cancelled = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 23 + $startcol : EventTableMap::translateFieldName('RecurringEvent', TableMap::TYPE_PHPNAME, $indexType)];
            $this->recurring_event = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 24 + $startcol : EventTableMap::translateFieldName('IsDeleted', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_deleted = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 25 + $startcol : EventTableMap::translateFieldName('IsDeletedC', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_deleted_c = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 26 + $startcol : EventTableMap::translateFieldName('Description', TableMap::TYPE_PHPNAME, $indexType)];
            $this->description = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 27 + $startcol : EventTableMap::translateFieldName('DurationMinutes', TableMap::TYPE_PHPNAME, $indexType)];
            $this->duration_minutes = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 28 + $startcol : EventTableMap::translateFieldName('EndDateTime', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->end_date_time = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 29 + $startcol : EventTableMap::translateFieldName('RecordTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->record_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 30 + $startcol : EventTableMap::translateFieldName('EventSubTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->event_sub_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 31 + $startcol : EventTableMap::translateFieldName('JobStatus', TableMap::TYPE_PHPNAME, $indexType)];
            $this->job_status = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 32 + $startcol : EventTableMap::translateFieldName('LocationC', TableMap::TYPE_PHPNAME, $indexType)];
            $this->location_c = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 33 + $startcol : EventTableMap::translateFieldName('ReminderDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->reminder_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 34 + $startcol : EventTableMap::translateFieldName('ReminderSet', TableMap::TYPE_PHPNAME, $indexType)];
            $this->reminder_set = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 35 + $startcol : EventTableMap::translateFieldName('StartDateTime', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->start_date_time = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 36 + $startcol : EventTableMap::translateFieldName('Subject', TableMap::TYPE_PHPNAME, $indexType)];
            $this->subject = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 37 + $startcol : EventTableMap::translateFieldName('RecurrenceTimeZone', TableMap::TYPE_PHPNAME, $indexType)];
            $this->recurrence_time_zone = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 38 + $startcol : EventTableMap::translateFieldName('CreatedBySfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->created_by_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 39 + $startcol : EventTableMap::translateFieldName('PmtoolUpdated', TableMap::TYPE_PHPNAME, $indexType)];
            $this->pmtool_updated = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 40 + $startcol : EventTableMap::translateFieldName('EventHolderId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->event_holder_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 41 + $startcol : EventTableMap::translateFieldName('ApiCreatedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->api_created_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 42 + $startcol : EventTableMap::translateFieldName('ApiUpdatedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->api_updated_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 43 + $startcol : EventTableMap::translateFieldName('IsGroup', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_group = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 44 + $startcol : EventTableMap::translateFieldName('CreatedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->created_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 45 + $startcol : EventTableMap::translateFieldName('UpdatedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->updated_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }

            return $startcol + 46; // 46 = EventTableMap::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException(sprintf('Error populating %s object', '\\Model\\Event'), 0, $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {
        if ($this->aJob !== null && $this->job_id !== $this->aJob->getId()) {
            $this->aJob = null;
        }
        if ($this->aBidJob !== null && $this->bid_job_id !== $this->aBidJob->getId()) {
            $this->aBidJob = null;
        }
        if ($this->aRefRoom !== null && $this->ref_room_id !== $this->aRefRoom->getId()) {
            $this->aRefRoom = null;
        }
        if ($this->aRefTimeSlot !== null && $this->ref_time_slot_id !== $this->aRefTimeSlot->getId()) {
            $this->aRefTimeSlot = null;
        }
        if ($this->aRefEventStatus !== null && $this->event_status_id !== $this->aRefEventStatus->getId()) {
            $this->aRefEventStatus = null;
        }
        if ($this->aEventMethodology !== null && $this->event_methodology_id !== $this->aEventMethodology->getId()) {
            $this->aEventMethodology = null;
        }
        if ($this->aSite !== null && $this->site_id !== $this->aSite->getId()) {
            $this->aSite = null;
        }
        if ($this->aAccount !== null && $this->account_id !== $this->aAccount->getId()) {
            $this->aAccount = null;
        }
        if ($this->aAssignedTo !== null && $this->assigned_to_id !== $this->aAssignedTo->getId()) {
            $this->aAssignedTo = null;
        }
        if ($this->aRecordType !== null && $this->record_type_id !== $this->aRecordType->getId()) {
            $this->aRecordType = null;
        }
        if ($this->aEventSubType !== null && $this->event_sub_type_id !== $this->aEventSubType->getId()) {
            $this->aEventSubType = null;
        }
        if ($this->aEventHolderBy !== null && $this->event_holder_id !== $this->aEventHolderBy->getId()) {
            $this->aEventHolderBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param      boolean $deep (optional) Whether to also de-associated any related objects.
     * @param      ConnectionInterface $con (optional) The ConnectionInterface connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EventTableMap::DATABASE_NAME);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $dataFetcher = ChildEventQuery::create(null, $this->buildPkeyCriteria())->setFormatter(ModelCriteria::FORMAT_STATEMENT)->find($con);
        $row = $dataFetcher->fetch();
        $dataFetcher->close();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true, $dataFetcher->getIndexType()); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aEventHolderBy = null;
            $this->aJob = null;
            $this->aBidJob = null;
            $this->aRefRoom = null;
            $this->aRefEventStatus = null;
            $this->aRefTimeSlot = null;
            $this->aEventMethodology = null;
            $this->aAccount = null;
            $this->aAssignedTo = null;
            $this->aRecordType = null;
            $this->aEventSubType = null;
            $this->aSite = null;
            $this->collModules = null;

            $this->collEvents = null;

            $this->collEventBidJobItems = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param      ConnectionInterface $con
     * @return void
     * @throws PropelException
     * @see Event::setDeleted()
     * @see Event::isDeleted()
     */
    public function delete(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con) {
            $deleteQuery = ChildEventQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $this->setDeleted(true);
            }
        });
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see doSave()
     */
    public function save(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($this->alreadyInSave) {
            return 0;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventTableMap::DATABASE_NAME);
        }

        return $con->transaction(function () use ($con) {
            $ret = $this->preSave($con);
            $isInsert = $this->isNew();
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                $time = time();
                $highPrecision = \Propel\Runtime\Util\PropelDateTime::createHighPrecision();
                if (!$this->isColumnModified(EventTableMap::COL_CREATED_DATE)) {
                    $this->setCreatedDate($highPrecision);
                }
                if (!$this->isColumnModified(EventTableMap::COL_UPDATED_DATE)) {
                    $this->setUpdatedDate($highPrecision);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(EventTableMap::COL_UPDATED_DATE)) {
                    $this->setUpdatedDate(\Propel\Runtime\Util\PropelDateTime::createHighPrecision());
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                EventTableMap::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }

            return $affectedRows;
        });
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see save()
     */
    protected function doSave(ConnectionInterface $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aEventHolderBy !== null) {
                if ($this->aEventHolderBy->isModified() || $this->aEventHolderBy->isNew()) {
                    $affectedRows += $this->aEventHolderBy->save($con);
                }
                $this->setEventHolderBy($this->aEventHolderBy);
            }

            if ($this->aJob !== null) {
                if ($this->aJob->isModified() || $this->aJob->isNew()) {
                    $affectedRows += $this->aJob->save($con);
                }
                $this->setJob($this->aJob);
            }

            if ($this->aBidJob !== null) {
                if ($this->aBidJob->isModified() || $this->aBidJob->isNew()) {
                    $affectedRows += $this->aBidJob->save($con);
                }
                $this->setBidJob($this->aBidJob);
            }

            if ($this->aRefRoom !== null) {
                if ($this->aRefRoom->isModified() || $this->aRefRoom->isNew()) {
                    $affectedRows += $this->aRefRoom->save($con);
                }
                $this->setRefRoom($this->aRefRoom);
            }

            if ($this->aRefEventStatus !== null) {
                if ($this->aRefEventStatus->isModified() || $this->aRefEventStatus->isNew()) {
                    $affectedRows += $this->aRefEventStatus->save($con);
                }
                $this->setRefEventStatus($this->aRefEventStatus);
            }

            if ($this->aRefTimeSlot !== null) {
                if ($this->aRefTimeSlot->isModified() || $this->aRefTimeSlot->isNew()) {
                    $affectedRows += $this->aRefTimeSlot->save($con);
                }
                $this->setRefTimeSlot($this->aRefTimeSlot);
            }

            if ($this->aEventMethodology !== null) {
                if ($this->aEventMethodology->isModified() || $this->aEventMethodology->isNew()) {
                    $affectedRows += $this->aEventMethodology->save($con);
                }
                $this->setEventMethodology($this->aEventMethodology);
            }

            if ($this->aAccount !== null) {
                if ($this->aAccount->isModified() || $this->aAccount->isNew()) {
                    $affectedRows += $this->aAccount->save($con);
                }
                $this->setAccount($this->aAccount);
            }

            if ($this->aAssignedTo !== null) {
                if ($this->aAssignedTo->isModified() || $this->aAssignedTo->isNew()) {
                    $affectedRows += $this->aAssignedTo->save($con);
                }
                $this->setAssignedTo($this->aAssignedTo);
            }

            if ($this->aRecordType !== null) {
                if ($this->aRecordType->isModified() || $this->aRecordType->isNew()) {
                    $affectedRows += $this->aRecordType->save($con);
                }
                $this->setRecordType($this->aRecordType);
            }

            if ($this->aEventSubType !== null) {
                if ($this->aEventSubType->isModified() || $this->aEventSubType->isNew()) {
                    $affectedRows += $this->aEventSubType->save($con);
                }
                $this->setEventSubType($this->aEventSubType);
            }

            if ($this->aSite !== null) {
                if ($this->aSite->isModified() || $this->aSite->isNew()) {
                    $affectedRows += $this->aSite->save($con);
                }
                $this->setSite($this->aSite);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                    $affectedRows += 1;
                } else {
                    $affectedRows += $this->doUpdate($con);
                }
                $this->resetModified();
            }

            if ($this->modulesScheduledForDeletion !== null) {
                if (!$this->modulesScheduledForDeletion->isEmpty()) {
                    \Model\ModuleQuery::create()
                        ->filterByPrimaryKeys($this->modulesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->modulesScheduledForDeletion = null;
                }
            }

            if ($this->collModules !== null) {
                foreach ($this->collModules as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->eventsScheduledForDeletion !== null) {
                if (!$this->eventsScheduledForDeletion->isEmpty()) {
                    \Model\BidJobItemQuery::create()
                        ->filterByPrimaryKeys($this->eventsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->eventsScheduledForDeletion = null;
                }
            }

            if ($this->collEvents !== null) {
                foreach ($this->collEvents as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->eventBidJobItemsScheduledForDeletion !== null) {
                if (!$this->eventBidJobItemsScheduledForDeletion->isEmpty()) {
                    \Model\EventBidJobItemQuery::create()
                        ->filterByPrimaryKeys($this->eventBidJobItemsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->eventBidJobItemsScheduledForDeletion = null;
                }
            }

            if ($this->collEventBidJobItems !== null) {
                foreach ($this->collEventBidJobItems as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @throws PropelException
     * @see doSave()
     */
    protected function doInsert(ConnectionInterface $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[EventTableMap::COL_ID] = true;
        if (null !== $this->id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . EventTableMap::COL_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(EventTableMap::COL_ID)) {
            $modifiedColumns[':p' . $index++]  = '`id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_SAMS_EVENT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`sams_event_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_JOB_ID)) {
            $modifiedColumns[':p' . $index++]  = '`job_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_BID_JOB_ID)) {
            $modifiedColumns[':p' . $index++]  = '`bid_job_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_BID_JOB_ARCHIVE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`bid_job_archive_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_REF_ROOM_ID)) {
            $modifiedColumns[':p' . $index++]  = '`ref_room_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_REF_TIME_SLOT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`ref_time_slot_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_STATUS_ID)) {
            $modifiedColumns[':p' . $index++]  = '`event_status_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_CONFIRMED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`confirmed_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ACTIVE_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`active_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_METHODOLOGY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`event_methodology_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`status`';
        }
        if ($this->isColumnModified(EventTableMap::COL_COMMENTS)) {
            $modifiedColumns[':p' . $index++]  = '`comments`';
        }
        if ($this->isColumnModified(EventTableMap::COL_FACILITY_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`facility_note`';
        }
        if ($this->isColumnModified(EventTableMap::COL_SITE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`site_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ACCOUNT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ACCOUNT_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_sf_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ACTIVITY_CURRENCY)) {
            $modifiedColumns[':p' . $index++]  = '`activity_currency`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ALL_DAY_EVENT)) {
            $modifiedColumns[':p' . $index++]  = '`all_day_event`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ARCHIVED)) {
            $modifiedColumns[':p' . $index++]  = '`archived`';
        }
        if ($this->isColumnModified(EventTableMap::COL_ASSIGNED_TO_ID)) {
            $modifiedColumns[':p' . $index++]  = '`assigned_to_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_CANCELLED)) {
            $modifiedColumns[':p' . $index++]  = '`cancelled`';
        }
        if ($this->isColumnModified(EventTableMap::COL_RECURRING_EVENT)) {
            $modifiedColumns[':p' . $index++]  = '`recurring_event`';
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_DELETED)) {
            $modifiedColumns[':p' . $index++]  = '`is_deleted`';
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_DELETED_C)) {
            $modifiedColumns[':p' . $index++]  = '`is_deleted_c`';
        }
        if ($this->isColumnModified(EventTableMap::COL_DESCRIPTION)) {
            $modifiedColumns[':p' . $index++]  = '`description`';
        }
        if ($this->isColumnModified(EventTableMap::COL_DURATION_MINUTES)) {
            $modifiedColumns[':p' . $index++]  = '`duration_minutes`';
        }
        if ($this->isColumnModified(EventTableMap::COL_END_DATE_TIME)) {
            $modifiedColumns[':p' . $index++]  = '`end_date_time`';
        }
        if ($this->isColumnModified(EventTableMap::COL_RECORD_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`record_type_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_SUB_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`event_sub_type_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_JOB_STATUS)) {
            $modifiedColumns[':p' . $index++]  = '`job_status`';
        }
        if ($this->isColumnModified(EventTableMap::COL_LOCATION_C)) {
            $modifiedColumns[':p' . $index++]  = '`location_c`';
        }
        if ($this->isColumnModified(EventTableMap::COL_REMINDER_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`reminder_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_REMINDER_SET)) {
            $modifiedColumns[':p' . $index++]  = '`reminder_set`';
        }
        if ($this->isColumnModified(EventTableMap::COL_START_DATE_TIME)) {
            $modifiedColumns[':p' . $index++]  = '`start_date_time`';
        }
        if ($this->isColumnModified(EventTableMap::COL_SUBJECT)) {
            $modifiedColumns[':p' . $index++]  = '`subject`';
        }
        if ($this->isColumnModified(EventTableMap::COL_RECURRENCE_TIME_ZONE)) {
            $modifiedColumns[':p' . $index++]  = '`recurrence_time_zone`';
        }
        if ($this->isColumnModified(EventTableMap::COL_CREATED_BY_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`created_by_sf_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_PMTOOL_UPDATED)) {
            $modifiedColumns[':p' . $index++]  = '`pmtool_updated`';
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_HOLDER_ID)) {
            $modifiedColumns[':p' . $index++]  = '`event_holder_id`';
        }
        if ($this->isColumnModified(EventTableMap::COL_API_CREATED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`api_created_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_API_UPDATED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`api_updated_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_GROUP)) {
            $modifiedColumns[':p' . $index++]  = '`is_group`';
        }
        if ($this->isColumnModified(EventTableMap::COL_CREATED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`created_date`';
        }
        if ($this->isColumnModified(EventTableMap::COL_UPDATED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`updated_date`';
        }

        $sql = sprintf(
            'INSERT INTO `event` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`id`':
                        $stmt->bindValue($identifier, $this->id, PDO::PARAM_INT);
                        break;
                    case '`sams_event_id`':
                        $stmt->bindValue($identifier, $this->sams_event_id, PDO::PARAM_STR);
                        break;
                    case '`job_id`':
                        $stmt->bindValue($identifier, $this->job_id, PDO::PARAM_INT);
                        break;
                    case '`bid_job_id`':
                        $stmt->bindValue($identifier, $this->bid_job_id, PDO::PARAM_INT);
                        break;
                    case '`bid_job_archive_id`':
                        $stmt->bindValue($identifier, $this->bid_job_archive_id, PDO::PARAM_INT);
                        break;
                    case '`ref_room_id`':
                        $stmt->bindValue($identifier, $this->ref_room_id, PDO::PARAM_INT);
                        break;
                    case '`ref_time_slot_id`':
                        $stmt->bindValue($identifier, $this->ref_time_slot_id, PDO::PARAM_INT);
                        break;
                    case '`event_status_id`':
                        $stmt->bindValue($identifier, $this->event_status_id, PDO::PARAM_INT);
                        break;
                    case '`date`':
                        $stmt->bindValue($identifier, $this->date ? $this->date->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`confirmed_date`':
                        $stmt->bindValue($identifier, $this->confirmed_date ? $this->confirmed_date->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`active_date`':
                        $stmt->bindValue($identifier, $this->active_date ? $this->active_date->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`event_methodology_id`':
                        $stmt->bindValue($identifier, $this->event_methodology_id, PDO::PARAM_INT);
                        break;
                    case '`status`':
                        $stmt->bindValue($identifier, $this->status, PDO::PARAM_INT);
                        break;
                    case '`comments`':
                        $stmt->bindValue($identifier, $this->comments, PDO::PARAM_STR);
                        break;
                    case '`facility_note`':
                        $stmt->bindValue($identifier, $this->facility_note, PDO::PARAM_STR);
                        break;
                    case '`site_id`':
                        $stmt->bindValue($identifier, $this->site_id, PDO::PARAM_INT);
                        break;
                    case '`account_id`':
                        $stmt->bindValue($identifier, $this->account_id, PDO::PARAM_INT);
                        break;
                    case '`account_sf_id`':
                        $stmt->bindValue($identifier, $this->account_sf_id, PDO::PARAM_STR);
                        break;
                    case '`activity_currency`':
                        $stmt->bindValue($identifier, $this->activity_currency, PDO::PARAM_STR);
                        break;
                    case '`all_day_event`':
                        $stmt->bindValue($identifier, (int) $this->all_day_event, PDO::PARAM_INT);
                        break;
                    case '`archived`':
                        $stmt->bindValue($identifier, (int) $this->archived, PDO::PARAM_INT);
                        break;
                    case '`assigned_to_id`':
                        $stmt->bindValue($identifier, $this->assigned_to_id, PDO::PARAM_INT);
                        break;
                    case '`cancelled`':
                        $stmt->bindValue($identifier, (int) $this->cancelled, PDO::PARAM_INT);
                        break;
                    case '`recurring_event`':
                        $stmt->bindValue($identifier, (int) $this->recurring_event, PDO::PARAM_INT);
                        break;
                    case '`is_deleted`':
                        $stmt->bindValue($identifier, (int) $this->is_deleted, PDO::PARAM_INT);
                        break;
                    case '`is_deleted_c`':
                        $stmt->bindValue($identifier, (int) $this->is_deleted_c, PDO::PARAM_INT);
                        break;
                    case '`description`':
                        $stmt->bindValue($identifier, $this->description, PDO::PARAM_STR);
                        break;
                    case '`duration_minutes`':
                        $stmt->bindValue($identifier, $this->duration_minutes, PDO::PARAM_INT);
                        break;
                    case '`end_date_time`':
                        $stmt->bindValue($identifier, $this->end_date_time ? $this->end_date_time->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`record_type_id`':
                        $stmt->bindValue($identifier, $this->record_type_id, PDO::PARAM_INT);
                        break;
                    case '`event_sub_type_id`':
                        $stmt->bindValue($identifier, $this->event_sub_type_id, PDO::PARAM_INT);
                        break;
                    case '`job_status`':
                        $stmt->bindValue($identifier, $this->job_status, PDO::PARAM_STR);
                        break;
                    case '`location_c`':
                        $stmt->bindValue($identifier, $this->location_c, PDO::PARAM_STR);
                        break;
                    case '`reminder_date`':
                        $stmt->bindValue($identifier, $this->reminder_date ? $this->reminder_date->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`reminder_set`':
                        $stmt->bindValue($identifier, (int) $this->reminder_set, PDO::PARAM_INT);
                        break;
                    case '`start_date_time`':
                        $stmt->bindValue($identifier, $this->start_date_time ? $this->start_date_time->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`subject`':
                        $stmt->bindValue($identifier, $this->subject, PDO::PARAM_STR);
                        break;
                    case '`recurrence_time_zone`':
                        $stmt->bindValue($identifier, $this->recurrence_time_zone, PDO::PARAM_STR);
                        break;
                    case '`created_by_sf_id`':
                        $stmt->bindValue($identifier, $this->created_by_sf_id, PDO::PARAM_STR);
                        break;
                    case '`pmtool_updated`':
                        $stmt->bindValue($identifier, (int) $this->pmtool_updated, PDO::PARAM_INT);
                        break;
                    case '`event_holder_id`':
                        $stmt->bindValue($identifier, $this->event_holder_id, PDO::PARAM_INT);
                        break;
                    case '`api_created_date`':
                        $stmt->bindValue($identifier, $this->api_created_date ? $this->api_created_date->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`api_updated_date`':
                        $stmt->bindValue($identifier, $this->api_updated_date ? $this->api_updated_date->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`is_group`':
                        $stmt->bindValue($identifier, (int) $this->is_group, PDO::PARAM_INT);
                        break;
                    case '`created_date`':
                        $stmt->bindValue($identifier, $this->created_date ? $this->created_date->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`updated_date`':
                        $stmt->bindValue($identifier, $this->updated_date ? $this->updated_date->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), 0, $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', 0, $e);
        }
        $this->setId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @return Integer Number of updated rows
     * @see doSave()
     */
    protected function doUpdate(ConnectionInterface $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();

        return $selectCriteria->doUpdate($valuesCriteria, $con);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param      string $name name
     * @param      string $type The type of fieldname the $name is of:
     *                     one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                     TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                     Defaults to TableMap::TYPE_PHPNAME.
     * @return mixed Value of field.
     */
    public function getByName($name, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EventTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param      int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getId();
                break;
            case 1:
                return $this->getSamsEventId();
                break;
            case 2:
                return $this->getJobId();
                break;
            case 3:
                return $this->getBidJobId();
                break;
            case 4:
                return $this->getBidJobArchiveId();
                break;
            case 5:
                return $this->getRefRoomId();
                break;
            case 6:
                return $this->getRefTimeSlotId();
                break;
            case 7:
                return $this->getEventStatusId();
                break;
            case 8:
                return $this->getDate();
                break;
            case 9:
                return $this->getConfirmedDate();
                break;
            case 10:
                return $this->getActiveDate();
                break;
            case 11:
                return $this->getEventMethodologyId();
                break;
            case 12:
                return $this->getStatus();
                break;
            case 13:
                return $this->getComments();
                break;
            case 14:
                return $this->getFacilityNote();
                break;
            case 15:
                return $this->getSiteId();
                break;
            case 16:
                return $this->getAccountId();
                break;
            case 17:
                return $this->getAccountSfId();
                break;
            case 18:
                return $this->getActivityCurrency();
                break;
            case 19:
                return $this->getAllDayEvent();
                break;
            case 20:
                return $this->getArchived();
                break;
            case 21:
                return $this->getAssignedToId();
                break;
            case 22:
                return $this->getCancelled();
                break;
            case 23:
                return $this->getRecurringEvent();
                break;
            case 24:
                return $this->getIsDeleted();
                break;
            case 25:
                return $this->getIsDeletedC();
                break;
            case 26:
                return $this->getDescription();
                break;
            case 27:
                return $this->getDurationMinutes();
                break;
            case 28:
                return $this->getEndDateTime();
                break;
            case 29:
                return $this->getRecordTypeId();
                break;
            case 30:
                return $this->getEventSubTypeId();
                break;
            case 31:
                return $this->getJobStatus();
                break;
            case 32:
                return $this->getLocationC();
                break;
            case 33:
                return $this->getReminderDate();
                break;
            case 34:
                return $this->getReminderSet();
                break;
            case 35:
                return $this->getStartDateTime();
                break;
            case 36:
                return $this->getSubject();
                break;
            case 37:
                return $this->getRecurrenceTimeZone();
                break;
            case 38:
                return $this->getCreatedBySfId();
                break;
            case 39:
                return $this->getPmtoolUpdated();
                break;
            case 40:
                return $this->getEventHolderId();
                break;
            case 41:
                return $this->getApiCreatedDate();
                break;
            case 42:
                return $this->getApiUpdatedDate();
                break;
            case 43:
                return $this->getIsGroup();
                break;
            case 44:
                return $this->getCreatedDate();
                break;
            case 45:
                return $this->getUpdatedDate();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     *                    TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                    Defaults to TableMap::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to TRUE.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = TableMap::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {

        if (isset($alreadyDumpedObjects['Event'][$this->hashCode()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Event'][$this->hashCode()] = true;
        $keys = EventTableMap::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getId(),
            $keys[1] => $this->getSamsEventId(),
            $keys[2] => $this->getJobId(),
            $keys[3] => $this->getBidJobId(),
            $keys[4] => $this->getBidJobArchiveId(),
            $keys[5] => $this->getRefRoomId(),
            $keys[6] => $this->getRefTimeSlotId(),
            $keys[7] => $this->getEventStatusId(),
            $keys[8] => $this->getDate(),
            $keys[9] => $this->getConfirmedDate(),
            $keys[10] => $this->getActiveDate(),
            $keys[11] => $this->getEventMethodologyId(),
            $keys[12] => $this->getStatus(),
            $keys[13] => $this->getComments(),
            $keys[14] => $this->getFacilityNote(),
            $keys[15] => $this->getSiteId(),
            $keys[16] => $this->getAccountId(),
            $keys[17] => $this->getAccountSfId(),
            $keys[18] => $this->getActivityCurrency(),
            $keys[19] => $this->getAllDayEvent(),
            $keys[20] => $this->getArchived(),
            $keys[21] => $this->getAssignedToId(),
            $keys[22] => $this->getCancelled(),
            $keys[23] => $this->getRecurringEvent(),
            $keys[24] => $this->getIsDeleted(),
            $keys[25] => $this->getIsDeletedC(),
            $keys[26] => $this->getDescription(),
            $keys[27] => $this->getDurationMinutes(),
            $keys[28] => $this->getEndDateTime(),
            $keys[29] => $this->getRecordTypeId(),
            $keys[30] => $this->getEventSubTypeId(),
            $keys[31] => $this->getJobStatus(),
            $keys[32] => $this->getLocationC(),
            $keys[33] => $this->getReminderDate(),
            $keys[34] => $this->getReminderSet(),
            $keys[35] => $this->getStartDateTime(),
            $keys[36] => $this->getSubject(),
            $keys[37] => $this->getRecurrenceTimeZone(),
            $keys[38] => $this->getCreatedBySfId(),
            $keys[39] => $this->getPmtoolUpdated(),
            $keys[40] => $this->getEventHolderId(),
            $keys[41] => $this->getApiCreatedDate(),
            $keys[42] => $this->getApiUpdatedDate(),
            $keys[43] => $this->getIsGroup(),
            $keys[44] => $this->getCreatedDate(),
            $keys[45] => $this->getUpdatedDate(),
        );
        if ($result[$keys[8]] instanceof \DateTimeInterface) {
            $result[$keys[8]] = $result[$keys[8]]->format('Y-m-d');
        }

        if ($result[$keys[9]] instanceof \DateTimeInterface) {
            $result[$keys[9]] = $result[$keys[9]]->format('Y-m-d');
        }

        if ($result[$keys[10]] instanceof \DateTimeInterface) {
            $result[$keys[10]] = $result[$keys[10]]->format('Y-m-d');
        }

        if ($result[$keys[28]] instanceof \DateTimeInterface) {
            $result[$keys[28]] = $result[$keys[28]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[33]] instanceof \DateTimeInterface) {
            $result[$keys[33]] = $result[$keys[33]]->format('Y-m-d');
        }

        if ($result[$keys[35]] instanceof \DateTimeInterface) {
            $result[$keys[35]] = $result[$keys[35]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[41]] instanceof \DateTimeInterface) {
            $result[$keys[41]] = $result[$keys[41]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[42]] instanceof \DateTimeInterface) {
            $result[$keys[42]] = $result[$keys[42]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[44]] instanceof \DateTimeInterface) {
            $result[$keys[44]] = $result[$keys[44]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[45]] instanceof \DateTimeInterface) {
            $result[$keys[45]] = $result[$keys[45]]->format('Y-m-d H:i:s.u');
        }

        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aEventHolderBy) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'EventHolderBy';
                }

                $result[$key] = $this->aEventHolderBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aJob) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'job';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'job';
                        break;
                    default:
                        $key = 'Job';
                }

                $result[$key] = $this->aJob->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aBidJob) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'bidJob';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_opportunity_bid_job';
                        break;
                    default:
                        $key = 'BidJob';
                }

                $result[$key] = $this->aBidJob->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aRefRoom) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refRoom';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_room';
                        break;
                    default:
                        $key = 'RefRoom';
                }

                $result[$key] = $this->aRefRoom->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aRefEventStatus) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refEventStatus';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_event_status';
                        break;
                    default:
                        $key = 'RefEventStatus';
                }

                $result[$key] = $this->aRefEventStatus->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aRefTimeSlot) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refTimeSlot';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_time_slot';
                        break;
                    default:
                        $key = 'RefTimeSlot';
                }

                $result[$key] = $this->aRefTimeSlot->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEventMethodology) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'eventMethodology';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_event_methodology';
                        break;
                    default:
                        $key = 'EventMethodology';
                }

                $result[$key] = $this->aEventMethodology->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAccount) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'account';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_account';
                        break;
                    default:
                        $key = 'Account';
                }

                $result[$key] = $this->aAccount->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAssignedTo) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'AssignedTo';
                }

                $result[$key] = $this->aAssignedTo->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aRecordType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'RecordType';
                }

                $result[$key] = $this->aRecordType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEventSubType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'EventSubType';
                }

                $result[$key] = $this->aEventSubType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aSite) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'site';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_site';
                        break;
                    default:
                        $key = 'Site';
                }

                $result[$key] = $this->aSite->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collModules) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'modules';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'modules';
                        break;
                    default:
                        $key = 'Modules';
                }

                $result[$key] = $this->collModules->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEvents) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'bidJobItems';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_opportunity_bid_job_items';
                        break;
                    default:
                        $key = 'Events';
                }

                $result[$key] = $this->collEvents->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEventBidJobItems) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'eventBidJobItems';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'event_bidjobitems';
                        break;
                    default:
                        $key = 'EventBidJobItems';
                }

                $result[$key] = $this->collEventBidJobItems->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param  string $name
     * @param  mixed  $value field value
     * @param  string $type The type of fieldname the $name is of:
     *                one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                Defaults to TableMap::TYPE_PHPNAME.
     * @return $this|\Model\Event
     */
    public function setByName($name, $value, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EventTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);

        return $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param  int $pos position in xml schema
     * @param  mixed $value field value
     * @return $this|\Model\Event
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setId($value);
                break;
            case 1:
                $this->setSamsEventId($value);
                break;
            case 2:
                $this->setJobId($value);
                break;
            case 3:
                $this->setBidJobId($value);
                break;
            case 4:
                $this->setBidJobArchiveId($value);
                break;
            case 5:
                $this->setRefRoomId($value);
                break;
            case 6:
                $this->setRefTimeSlotId($value);
                break;
            case 7:
                $this->setEventStatusId($value);
                break;
            case 8:
                $this->setDate($value);
                break;
            case 9:
                $this->setConfirmedDate($value);
                break;
            case 10:
                $this->setActiveDate($value);
                break;
            case 11:
                $this->setEventMethodologyId($value);
                break;
            case 12:
                $valueSet = EventTableMap::getValueSet(EventTableMap::COL_STATUS);
                if (isset($valueSet[$value])) {
                    $value = $valueSet[$value];
                }
                $this->setStatus($value);
                break;
            case 13:
                $this->setComments($value);
                break;
            case 14:
                $this->setFacilityNote($value);
                break;
            case 15:
                $this->setSiteId($value);
                break;
            case 16:
                $this->setAccountId($value);
                break;
            case 17:
                $this->setAccountSfId($value);
                break;
            case 18:
                $this->setActivityCurrency($value);
                break;
            case 19:
                $this->setAllDayEvent($value);
                break;
            case 20:
                $this->setArchived($value);
                break;
            case 21:
                $this->setAssignedToId($value);
                break;
            case 22:
                $this->setCancelled($value);
                break;
            case 23:
                $this->setRecurringEvent($value);
                break;
            case 24:
                $this->setIsDeleted($value);
                break;
            case 25:
                $this->setIsDeletedC($value);
                break;
            case 26:
                $this->setDescription($value);
                break;
            case 27:
                $this->setDurationMinutes($value);
                break;
            case 28:
                $this->setEndDateTime($value);
                break;
            case 29:
                $this->setRecordTypeId($value);
                break;
            case 30:
                $this->setEventSubTypeId($value);
                break;
            case 31:
                $this->setJobStatus($value);
                break;
            case 32:
                $this->setLocationC($value);
                break;
            case 33:
                $this->setReminderDate($value);
                break;
            case 34:
                $this->setReminderSet($value);
                break;
            case 35:
                $this->setStartDateTime($value);
                break;
            case 36:
                $this->setSubject($value);
                break;
            case 37:
                $this->setRecurrenceTimeZone($value);
                break;
            case 38:
                $this->setCreatedBySfId($value);
                break;
            case 39:
                $this->setPmtoolUpdated($value);
                break;
            case 40:
                $this->setEventHolderId($value);
                break;
            case 41:
                $this->setApiCreatedDate($value);
                break;
            case 42:
                $this->setApiUpdatedDate($value);
                break;
            case 43:
                $this->setIsGroup($value);
                break;
            case 44:
                $this->setCreatedDate($value);
                break;
            case 45:
                $this->setUpdatedDate($value);
                break;
        } // switch()

        return $this;
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param      array  $arr     An array to populate the object from.
     * @param      string $keyType The type of keys the array uses.
     * @return     $this|\Model\Event
     */
    public function fromArray($arr, $keyType = TableMap::TYPE_PHPNAME)
    {
        $keys = EventTableMap::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) {
            $this->setId($arr[$keys[0]]);
        }
        if (array_key_exists($keys[1], $arr)) {
            $this->setSamsEventId($arr[$keys[1]]);
        }
        if (array_key_exists($keys[2], $arr)) {
            $this->setJobId($arr[$keys[2]]);
        }
        if (array_key_exists($keys[3], $arr)) {
            $this->setBidJobId($arr[$keys[3]]);
        }
        if (array_key_exists($keys[4], $arr)) {
            $this->setBidJobArchiveId($arr[$keys[4]]);
        }
        if (array_key_exists($keys[5], $arr)) {
            $this->setRefRoomId($arr[$keys[5]]);
        }
        if (array_key_exists($keys[6], $arr)) {
            $this->setRefTimeSlotId($arr[$keys[6]]);
        }
        if (array_key_exists($keys[7], $arr)) {
            $this->setEventStatusId($arr[$keys[7]]);
        }
        if (array_key_exists($keys[8], $arr)) {
            $this->setDate($arr[$keys[8]]);
        }
        if (array_key_exists($keys[9], $arr)) {
            $this->setConfirmedDate($arr[$keys[9]]);
        }
        if (array_key_exists($keys[10], $arr)) {
            $this->setActiveDate($arr[$keys[10]]);
        }
        if (array_key_exists($keys[11], $arr)) {
            $this->setEventMethodologyId($arr[$keys[11]]);
        }
        if (array_key_exists($keys[12], $arr)) {
            $this->setStatus($arr[$keys[12]]);
        }
        if (array_key_exists($keys[13], $arr)) {
            $this->setComments($arr[$keys[13]]);
        }
        if (array_key_exists($keys[14], $arr)) {
            $this->setFacilityNote($arr[$keys[14]]);
        }
        if (array_key_exists($keys[15], $arr)) {
            $this->setSiteId($arr[$keys[15]]);
        }
        if (array_key_exists($keys[16], $arr)) {
            $this->setAccountId($arr[$keys[16]]);
        }
        if (array_key_exists($keys[17], $arr)) {
            $this->setAccountSfId($arr[$keys[17]]);
        }
        if (array_key_exists($keys[18], $arr)) {
            $this->setActivityCurrency($arr[$keys[18]]);
        }
        if (array_key_exists($keys[19], $arr)) {
            $this->setAllDayEvent($arr[$keys[19]]);
        }
        if (array_key_exists($keys[20], $arr)) {
            $this->setArchived($arr[$keys[20]]);
        }
        if (array_key_exists($keys[21], $arr)) {
            $this->setAssignedToId($arr[$keys[21]]);
        }
        if (array_key_exists($keys[22], $arr)) {
            $this->setCancelled($arr[$keys[22]]);
        }
        if (array_key_exists($keys[23], $arr)) {
            $this->setRecurringEvent($arr[$keys[23]]);
        }
        if (array_key_exists($keys[24], $arr)) {
            $this->setIsDeleted($arr[$keys[24]]);
        }
        if (array_key_exists($keys[25], $arr)) {
            $this->setIsDeletedC($arr[$keys[25]]);
        }
        if (array_key_exists($keys[26], $arr)) {
            $this->setDescription($arr[$keys[26]]);
        }
        if (array_key_exists($keys[27], $arr)) {
            $this->setDurationMinutes($arr[$keys[27]]);
        }
        if (array_key_exists($keys[28], $arr)) {
            $this->setEndDateTime($arr[$keys[28]]);
        }
        if (array_key_exists($keys[29], $arr)) {
            $this->setRecordTypeId($arr[$keys[29]]);
        }
        if (array_key_exists($keys[30], $arr)) {
            $this->setEventSubTypeId($arr[$keys[30]]);
        }
        if (array_key_exists($keys[31], $arr)) {
            $this->setJobStatus($arr[$keys[31]]);
        }
        if (array_key_exists($keys[32], $arr)) {
            $this->setLocationC($arr[$keys[32]]);
        }
        if (array_key_exists($keys[33], $arr)) {
            $this->setReminderDate($arr[$keys[33]]);
        }
        if (array_key_exists($keys[34], $arr)) {
            $this->setReminderSet($arr[$keys[34]]);
        }
        if (array_key_exists($keys[35], $arr)) {
            $this->setStartDateTime($arr[$keys[35]]);
        }
        if (array_key_exists($keys[36], $arr)) {
            $this->setSubject($arr[$keys[36]]);
        }
        if (array_key_exists($keys[37], $arr)) {
            $this->setRecurrenceTimeZone($arr[$keys[37]]);
        }
        if (array_key_exists($keys[38], $arr)) {
            $this->setCreatedBySfId($arr[$keys[38]]);
        }
        if (array_key_exists($keys[39], $arr)) {
            $this->setPmtoolUpdated($arr[$keys[39]]);
        }
        if (array_key_exists($keys[40], $arr)) {
            $this->setEventHolderId($arr[$keys[40]]);
        }
        if (array_key_exists($keys[41], $arr)) {
            $this->setApiCreatedDate($arr[$keys[41]]);
        }
        if (array_key_exists($keys[42], $arr)) {
            $this->setApiUpdatedDate($arr[$keys[42]]);
        }
        if (array_key_exists($keys[43], $arr)) {
            $this->setIsGroup($arr[$keys[43]]);
        }
        if (array_key_exists($keys[44], $arr)) {
            $this->setCreatedDate($arr[$keys[44]]);
        }
        if (array_key_exists($keys[45], $arr)) {
            $this->setUpdatedDate($arr[$keys[45]]);
        }

        return $this;
    }

     /**
     * Populate the current object from a string, using a given parser format
     * <code>
     * $book = new Book();
     * $book->importFrom('JSON', '{"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param mixed $parser A AbstractParser instance,
     *                       or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param string $data The source data to import from
     * @param string $keyType The type of keys the array uses.
     *
     * @return $this|\Model\Event The current object, for fluid interface
     */
    public function importFrom($parser, $data, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        $this->fromArray($parser->toArray($data), $keyType);

        return $this;
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(EventTableMap::DATABASE_NAME);

        if ($this->isColumnModified(EventTableMap::COL_ID)) {
            $criteria->add(EventTableMap::COL_ID, $this->id);
        }
        if ($this->isColumnModified(EventTableMap::COL_SAMS_EVENT_ID)) {
            $criteria->add(EventTableMap::COL_SAMS_EVENT_ID, $this->sams_event_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_JOB_ID)) {
            $criteria->add(EventTableMap::COL_JOB_ID, $this->job_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_BID_JOB_ID)) {
            $criteria->add(EventTableMap::COL_BID_JOB_ID, $this->bid_job_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_BID_JOB_ARCHIVE_ID)) {
            $criteria->add(EventTableMap::COL_BID_JOB_ARCHIVE_ID, $this->bid_job_archive_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_REF_ROOM_ID)) {
            $criteria->add(EventTableMap::COL_REF_ROOM_ID, $this->ref_room_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_REF_TIME_SLOT_ID)) {
            $criteria->add(EventTableMap::COL_REF_TIME_SLOT_ID, $this->ref_time_slot_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_STATUS_ID)) {
            $criteria->add(EventTableMap::COL_EVENT_STATUS_ID, $this->event_status_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_DATE)) {
            $criteria->add(EventTableMap::COL_DATE, $this->date);
        }
        if ($this->isColumnModified(EventTableMap::COL_CONFIRMED_DATE)) {
            $criteria->add(EventTableMap::COL_CONFIRMED_DATE, $this->confirmed_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_ACTIVE_DATE)) {
            $criteria->add(EventTableMap::COL_ACTIVE_DATE, $this->active_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_METHODOLOGY_ID)) {
            $criteria->add(EventTableMap::COL_EVENT_METHODOLOGY_ID, $this->event_methodology_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_STATUS)) {
            $criteria->add(EventTableMap::COL_STATUS, $this->status);
        }
        if ($this->isColumnModified(EventTableMap::COL_COMMENTS)) {
            $criteria->add(EventTableMap::COL_COMMENTS, $this->comments);
        }
        if ($this->isColumnModified(EventTableMap::COL_FACILITY_NOTE)) {
            $criteria->add(EventTableMap::COL_FACILITY_NOTE, $this->facility_note);
        }
        if ($this->isColumnModified(EventTableMap::COL_SITE_ID)) {
            $criteria->add(EventTableMap::COL_SITE_ID, $this->site_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_ACCOUNT_ID)) {
            $criteria->add(EventTableMap::COL_ACCOUNT_ID, $this->account_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_ACCOUNT_SF_ID)) {
            $criteria->add(EventTableMap::COL_ACCOUNT_SF_ID, $this->account_sf_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_ACTIVITY_CURRENCY)) {
            $criteria->add(EventTableMap::COL_ACTIVITY_CURRENCY, $this->activity_currency);
        }
        if ($this->isColumnModified(EventTableMap::COL_ALL_DAY_EVENT)) {
            $criteria->add(EventTableMap::COL_ALL_DAY_EVENT, $this->all_day_event);
        }
        if ($this->isColumnModified(EventTableMap::COL_ARCHIVED)) {
            $criteria->add(EventTableMap::COL_ARCHIVED, $this->archived);
        }
        if ($this->isColumnModified(EventTableMap::COL_ASSIGNED_TO_ID)) {
            $criteria->add(EventTableMap::COL_ASSIGNED_TO_ID, $this->assigned_to_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_CANCELLED)) {
            $criteria->add(EventTableMap::COL_CANCELLED, $this->cancelled);
        }
        if ($this->isColumnModified(EventTableMap::COL_RECURRING_EVENT)) {
            $criteria->add(EventTableMap::COL_RECURRING_EVENT, $this->recurring_event);
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_DELETED)) {
            $criteria->add(EventTableMap::COL_IS_DELETED, $this->is_deleted);
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_DELETED_C)) {
            $criteria->add(EventTableMap::COL_IS_DELETED_C, $this->is_deleted_c);
        }
        if ($this->isColumnModified(EventTableMap::COL_DESCRIPTION)) {
            $criteria->add(EventTableMap::COL_DESCRIPTION, $this->description);
        }
        if ($this->isColumnModified(EventTableMap::COL_DURATION_MINUTES)) {
            $criteria->add(EventTableMap::COL_DURATION_MINUTES, $this->duration_minutes);
        }
        if ($this->isColumnModified(EventTableMap::COL_END_DATE_TIME)) {
            $criteria->add(EventTableMap::COL_END_DATE_TIME, $this->end_date_time);
        }
        if ($this->isColumnModified(EventTableMap::COL_RECORD_TYPE_ID)) {
            $criteria->add(EventTableMap::COL_RECORD_TYPE_ID, $this->record_type_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_SUB_TYPE_ID)) {
            $criteria->add(EventTableMap::COL_EVENT_SUB_TYPE_ID, $this->event_sub_type_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_JOB_STATUS)) {
            $criteria->add(EventTableMap::COL_JOB_STATUS, $this->job_status);
        }
        if ($this->isColumnModified(EventTableMap::COL_LOCATION_C)) {
            $criteria->add(EventTableMap::COL_LOCATION_C, $this->location_c);
        }
        if ($this->isColumnModified(EventTableMap::COL_REMINDER_DATE)) {
            $criteria->add(EventTableMap::COL_REMINDER_DATE, $this->reminder_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_REMINDER_SET)) {
            $criteria->add(EventTableMap::COL_REMINDER_SET, $this->reminder_set);
        }
        if ($this->isColumnModified(EventTableMap::COL_START_DATE_TIME)) {
            $criteria->add(EventTableMap::COL_START_DATE_TIME, $this->start_date_time);
        }
        if ($this->isColumnModified(EventTableMap::COL_SUBJECT)) {
            $criteria->add(EventTableMap::COL_SUBJECT, $this->subject);
        }
        if ($this->isColumnModified(EventTableMap::COL_RECURRENCE_TIME_ZONE)) {
            $criteria->add(EventTableMap::COL_RECURRENCE_TIME_ZONE, $this->recurrence_time_zone);
        }
        if ($this->isColumnModified(EventTableMap::COL_CREATED_BY_SF_ID)) {
            $criteria->add(EventTableMap::COL_CREATED_BY_SF_ID, $this->created_by_sf_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_PMTOOL_UPDATED)) {
            $criteria->add(EventTableMap::COL_PMTOOL_UPDATED, $this->pmtool_updated);
        }
        if ($this->isColumnModified(EventTableMap::COL_EVENT_HOLDER_ID)) {
            $criteria->add(EventTableMap::COL_EVENT_HOLDER_ID, $this->event_holder_id);
        }
        if ($this->isColumnModified(EventTableMap::COL_API_CREATED_DATE)) {
            $criteria->add(EventTableMap::COL_API_CREATED_DATE, $this->api_created_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_API_UPDATED_DATE)) {
            $criteria->add(EventTableMap::COL_API_UPDATED_DATE, $this->api_updated_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_IS_GROUP)) {
            $criteria->add(EventTableMap::COL_IS_GROUP, $this->is_group);
        }
        if ($this->isColumnModified(EventTableMap::COL_CREATED_DATE)) {
            $criteria->add(EventTableMap::COL_CREATED_DATE, $this->created_date);
        }
        if ($this->isColumnModified(EventTableMap::COL_UPDATED_DATE)) {
            $criteria->add(EventTableMap::COL_UPDATED_DATE, $this->updated_date);
        }

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @throws LogicException if no primary key is defined
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = ChildEventQuery::create();
        $criteria->add(EventTableMap::COL_ID, $this->id);

        return $criteria;
    }

    /**
     * If the primary key is not null, return the hashcode of the
     * primary key. Otherwise, return the hash code of the object.
     *
     * @return int Hashcode
     */
    public function hashCode()
    {
        $validPk = null !== $this->getId();

        $validPrimaryKeyFKs = 0;
        $primaryKeyFKs = [];

        if ($validPk) {
            return crc32(json_encode($this->getPrimaryKey(), JSON_UNESCAPED_UNICODE));
        } elseif ($validPrimaryKeyFKs) {
            return crc32(json_encode($primaryKeyFKs, JSON_UNESCAPED_UNICODE));
        }

        return spl_object_hash($this);
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getId();
    }

    /**
     * Generic method to set the primary key (id column).
     *
     * @param       int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {
        return null === $this->getId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param      object $copyObj An object of \Model\Event (or compatible) type.
     * @param      boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param      boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setSamsEventId($this->getSamsEventId());
        $copyObj->setJobId($this->getJobId());
        $copyObj->setBidJobId($this->getBidJobId());
        $copyObj->setBidJobArchiveId($this->getBidJobArchiveId());
        $copyObj->setRefRoomId($this->getRefRoomId());
        $copyObj->setRefTimeSlotId($this->getRefTimeSlotId());
        $copyObj->setEventStatusId($this->getEventStatusId());
        $copyObj->setDate($this->getDate());
        $copyObj->setConfirmedDate($this->getConfirmedDate());
        $copyObj->setActiveDate($this->getActiveDate());
        $copyObj->setEventMethodologyId($this->getEventMethodologyId());
        $copyObj->setStatus($this->getStatus());
        $copyObj->setComments($this->getComments());
        $copyObj->setFacilityNote($this->getFacilityNote());
        $copyObj->setSiteId($this->getSiteId());
        $copyObj->setAccountId($this->getAccountId());
        $copyObj->setAccountSfId($this->getAccountSfId());
        $copyObj->setActivityCurrency($this->getActivityCurrency());
        $copyObj->setAllDayEvent($this->getAllDayEvent());
        $copyObj->setArchived($this->getArchived());
        $copyObj->setAssignedToId($this->getAssignedToId());
        $copyObj->setCancelled($this->getCancelled());
        $copyObj->setRecurringEvent($this->getRecurringEvent());
        $copyObj->setIsDeleted($this->getIsDeleted());
        $copyObj->setIsDeletedC($this->getIsDeletedC());
        $copyObj->setDescription($this->getDescription());
        $copyObj->setDurationMinutes($this->getDurationMinutes());
        $copyObj->setEndDateTime($this->getEndDateTime());
        $copyObj->setRecordTypeId($this->getRecordTypeId());
        $copyObj->setEventSubTypeId($this->getEventSubTypeId());
        $copyObj->setJobStatus($this->getJobStatus());
        $copyObj->setLocationC($this->getLocationC());
        $copyObj->setReminderDate($this->getReminderDate());
        $copyObj->setReminderSet($this->getReminderSet());
        $copyObj->setStartDateTime($this->getStartDateTime());
        $copyObj->setSubject($this->getSubject());
        $copyObj->setRecurrenceTimeZone($this->getRecurrenceTimeZone());
        $copyObj->setCreatedBySfId($this->getCreatedBySfId());
        $copyObj->setPmtoolUpdated($this->getPmtoolUpdated());
        $copyObj->setEventHolderId($this->getEventHolderId());
        $copyObj->setApiCreatedDate($this->getApiCreatedDate());
        $copyObj->setApiUpdatedDate($this->getApiUpdatedDate());
        $copyObj->setIsGroup($this->getIsGroup());
        $copyObj->setCreatedDate($this->getCreatedDate());
        $copyObj->setUpdatedDate($this->getUpdatedDate());

        if ($deepCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);

            foreach ($this->getModules() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addModule($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEvents() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEvent($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEventBidJobItems() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEventBidJobItem($relObj->copy($deepCopy));
                }
            }

        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param  boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return \Model\Event Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEventHolderBy(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setEventHolderId(NULL);
        } else {
            $this->setEventHolderId($v->getId());
        }

        $this->aEventHolderBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEventRelatedByEventHolderId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getEventHolderBy(ConnectionInterface $con = null)
    {
        if ($this->aEventHolderBy === null && ($this->event_holder_id != 0)) {
            $this->aEventHolderBy = ChildUserQuery::create()->findPk($this->event_holder_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEventHolderBy->addEventsRelatedByEventHolderId($this);
             */
        }

        return $this->aEventHolderBy;
    }

    /**
     * Declares an association between this object and a ChildJob object.
     *
     * @param  ChildJob|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setJob(ChildJob $v = null)
    {
        if ($v === null) {
            $this->setJobId(NULL);
        } else {
            $this->setJobId($v->getId());
        }

        $this->aJob = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildJob object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildJob object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildJob|null The associated ChildJob object.
     * @throws PropelException
     */
    public function getJob(ConnectionInterface $con = null)
    {
        if ($this->aJob === null && ($this->job_id != 0)) {
            $this->aJob = ChildJobQuery::create()->findPk($this->job_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aJob->addEvents($this);
             */
        }

        return $this->aJob;
    }

    /**
     * Declares an association between this object and a ChildBidJob object.
     *
     * @param  ChildBidJob|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setBidJob(ChildBidJob $v = null)
    {
        if ($v === null) {
            $this->setBidJobId(NULL);
        } else {
            $this->setBidJobId($v->getId());
        }

        $this->aBidJob = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildBidJob object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildBidJob object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildBidJob|null The associated ChildBidJob object.
     * @throws PropelException
     */
    public function getBidJob(ConnectionInterface $con = null)
    {
        if ($this->aBidJob === null && ($this->bid_job_id != 0)) {
            $this->aBidJob = ChildBidJobQuery::create()->findPk($this->bid_job_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aBidJob->addEvents($this);
             */
        }

        return $this->aBidJob;
    }

    /**
     * Declares an association between this object and a ChildRefRoom object.
     *
     * @param  ChildRefRoom|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRefRoom(ChildRefRoom $v = null)
    {
        if ($v === null) {
            $this->setRefRoomId(NULL);
        } else {
            $this->setRefRoomId($v->getId());
        }

        $this->aRefRoom = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefRoom object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefRoom object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefRoom|null The associated ChildRefRoom object.
     * @throws PropelException
     */
    public function getRefRoom(ConnectionInterface $con = null)
    {
        if ($this->aRefRoom === null && ($this->ref_room_id != 0)) {
            $this->aRefRoom = ChildRefRoomQuery::create()->findPk($this->ref_room_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRefRoom->addEvents($this);
             */
        }

        return $this->aRefRoom;
    }

    /**
     * Declares an association between this object and a ChildRefEventStatus object.
     *
     * @param  ChildRefEventStatus|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRefEventStatus(ChildRefEventStatus $v = null)
    {
        if ($v === null) {
            $this->setEventStatusId(NULL);
        } else {
            $this->setEventStatusId($v->getId());
        }

        $this->aRefEventStatus = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefEventStatus object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefEventStatus object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefEventStatus|null The associated ChildRefEventStatus object.
     * @throws PropelException
     */
    public function getRefEventStatus(ConnectionInterface $con = null)
    {
        if ($this->aRefEventStatus === null && ($this->event_status_id != 0)) {
            $this->aRefEventStatus = ChildRefEventStatusQuery::create()->findPk($this->event_status_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRefEventStatus->addEvents($this);
             */
        }

        return $this->aRefEventStatus;
    }

    /**
     * Declares an association between this object and a ChildRefTimeSlot object.
     *
     * @param  ChildRefTimeSlot|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRefTimeSlot(ChildRefTimeSlot $v = null)
    {
        if ($v === null) {
            $this->setRefTimeSlotId(NULL);
        } else {
            $this->setRefTimeSlotId($v->getId());
        }

        $this->aRefTimeSlot = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefTimeSlot object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefTimeSlot object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefTimeSlot|null The associated ChildRefTimeSlot object.
     * @throws PropelException
     */
    public function getRefTimeSlot(ConnectionInterface $con = null)
    {
        if ($this->aRefTimeSlot === null && ($this->ref_time_slot_id != 0)) {
            $this->aRefTimeSlot = ChildRefTimeSlotQuery::create()->findPk($this->ref_time_slot_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRefTimeSlot->addEvents($this);
             */
        }

        return $this->aRefTimeSlot;
    }

    /**
     * Declares an association between this object and a ChildEventMethodology object.
     *
     * @param  ChildEventMethodology|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEventMethodology(ChildEventMethodology $v = null)
    {
        if ($v === null) {
            $this->setEventMethodologyId(NULL);
        } else {
            $this->setEventMethodologyId($v->getId());
        }

        $this->aEventMethodology = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildEventMethodology object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildEventMethodology object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildEventMethodology|null The associated ChildEventMethodology object.
     * @throws PropelException
     */
    public function getEventMethodology(ConnectionInterface $con = null)
    {
        if ($this->aEventMethodology === null && ($this->event_methodology_id != 0)) {
            $this->aEventMethodology = ChildEventMethodologyQuery::create()->findPk($this->event_methodology_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEventMethodology->addEvents($this);
             */
        }

        return $this->aEventMethodology;
    }

    /**
     * Declares an association between this object and a ChildAccount object.
     *
     * @param  ChildAccount|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAccount(ChildAccount $v = null)
    {
        if ($v === null) {
            $this->setAccountId(NULL);
        } else {
            $this->setAccountId($v->getId());
        }

        $this->aAccount = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildAccount object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildAccount object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildAccount|null The associated ChildAccount object.
     * @throws PropelException
     */
    public function getAccount(ConnectionInterface $con = null)
    {
        if ($this->aAccount === null && ($this->account_id != 0)) {
            $this->aAccount = ChildAccountQuery::create()->findPk($this->account_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAccount->addEvents($this);
             */
        }

        return $this->aAccount;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAssignedTo(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setAssignedToId(NULL);
        } else {
            $this->setAssignedToId($v->getId());
        }

        $this->aAssignedTo = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEventRelatedByAssignedToId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getAssignedTo(ConnectionInterface $con = null)
    {
        if ($this->aAssignedTo === null && ($this->assigned_to_id != 0)) {
            $this->aAssignedTo = ChildUserQuery::create()->findPk($this->assigned_to_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAssignedTo->addEventsRelatedByAssignedToId($this);
             */
        }

        return $this->aAssignedTo;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRecordType(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setRecordTypeId(NULL);
        } else {
            $this->setRecordTypeId($v->getId());
        }

        $this->aRecordType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEventRelatedByRecordTypeId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getRecordType(ConnectionInterface $con = null)
    {
        if ($this->aRecordType === null && ($this->record_type_id != 0)) {
            $this->aRecordType = ChildRefSalesForceQuery::create()->findPk($this->record_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRecordType->addEventsRelatedByRecordTypeId($this);
             */
        }

        return $this->aRecordType;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEventSubType(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setEventSubTypeId(NULL);
        } else {
            $this->setEventSubTypeId($v->getId());
        }

        $this->aEventSubType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEventRelatedByEventSubTypeId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getEventSubType(ConnectionInterface $con = null)
    {
        if ($this->aEventSubType === null && ($this->event_sub_type_id != 0)) {
            $this->aEventSubType = ChildRefSalesForceQuery::create()->findPk($this->event_sub_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEventSubType->addEventsRelatedByEventSubTypeId($this);
             */
        }

        return $this->aEventSubType;
    }

    /**
     * Declares an association between this object and a ChildSite object.
     *
     * @param  ChildSite|null $v
     * @return $this|\Model\Event The current object (for fluent API support)
     * @throws PropelException
     */
    public function setSite(ChildSite $v = null)
    {
        if ($v === null) {
            $this->setSiteId(NULL);
        } else {
            $this->setSiteId($v->getId());
        }

        $this->aSite = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildSite object, it will not be re-added.
        if ($v !== null) {
            $v->addEvent($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildSite object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildSite|null The associated ChildSite object.
     * @throws PropelException
     */
    public function getSite(ConnectionInterface $con = null)
    {
        if ($this->aSite === null && ($this->site_id != 0)) {
            $this->aSite = ChildSiteQuery::create()->findPk($this->site_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aSite->addEvents($this);
             */
        }

        return $this->aSite;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param      string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('Module' === $relationName) {
            $this->initModules();
            return;
        }
        if ('Event' === $relationName) {
            $this->initEvents();
            return;
        }
        if ('EventBidJobItem' === $relationName) {
            $this->initEventBidJobItems();
            return;
        }
    }

    /**
     * Clears out the collModules collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addModules()
     */
    public function clearModules()
    {
        $this->collModules = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collModules collection loaded partially.
     */
    public function resetPartialModules($v = true)
    {
        $this->collModulesPartial = $v;
    }

    /**
     * Initializes the collModules collection.
     *
     * By default this just sets the collModules collection to an empty array (like clearcollModules());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initModules($overrideExisting = true)
    {
        if (null !== $this->collModules && !$overrideExisting) {
            return;
        }

        $collectionClassName = ModuleTableMap::getTableMap()->getCollectionClassName();

        $this->collModules = new $collectionClassName;
        $this->collModules->setModel('\Model\Module');
    }

    /**
     * Gets an array of ChildModule objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEvent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule> List of ChildModule objects
     * @throws PropelException
     */
    public function getModules(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collModulesPartial && !$this->isNew();
        if (null === $this->collModules || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collModules) {
                    $this->initModules();
                } else {
                    $collectionClassName = ModuleTableMap::getTableMap()->getCollectionClassName();

                    $collModules = new $collectionClassName;
                    $collModules->setModel('\Model\Module');

                    return $collModules;
                }
            } else {
                $collModules = ChildModuleQuery::create(null, $criteria)
                    ->filterByEvent($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collModulesPartial && count($collModules)) {
                        $this->initModules(false);

                        foreach ($collModules as $obj) {
                            if (false == $this->collModules->contains($obj)) {
                                $this->collModules->append($obj);
                            }
                        }

                        $this->collModulesPartial = true;
                    }

                    return $collModules;
                }

                if ($partial && $this->collModules) {
                    foreach ($this->collModules as $obj) {
                        if ($obj->isNew()) {
                            $collModules[] = $obj;
                        }
                    }
                }

                $this->collModules = $collModules;
                $this->collModulesPartial = false;
            }
        }

        return $this->collModules;
    }

    /**
     * Sets a collection of ChildModule objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $modules A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function setModules(Collection $modules, ConnectionInterface $con = null)
    {
        /** @var ChildModule[] $modulesToDelete */
        $modulesToDelete = $this->getModules(new Criteria(), $con)->diff($modules);


        $this->modulesScheduledForDeletion = $modulesToDelete;

        foreach ($modulesToDelete as $moduleRemoved) {
            $moduleRemoved->setEvent(null);
        }

        $this->collModules = null;
        foreach ($modules as $module) {
            $this->addModule($module);
        }

        $this->collModules = $modules;
        $this->collModulesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Module objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related Module objects.
     * @throws PropelException
     */
    public function countModules(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collModulesPartial && !$this->isNew();
        if (null === $this->collModules || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collModules) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getModules());
            }

            $query = ChildModuleQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEvent($this)
                ->count($con);
        }

        return count($this->collModules);
    }

    /**
     * Method called to associate a ChildModule object to this object
     * through the ChildModule foreign key attribute.
     *
     * @param  ChildModule $l ChildModule
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function addModule(ChildModule $l)
    {
        if ($this->collModules === null) {
            $this->initModules();
            $this->collModulesPartial = true;
        }

        if (!$this->collModules->contains($l)) {
            $this->doAddModule($l);

            if ($this->modulesScheduledForDeletion and $this->modulesScheduledForDeletion->contains($l)) {
                $this->modulesScheduledForDeletion->remove($this->modulesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildModule $module The ChildModule object to add.
     */
    protected function doAddModule(ChildModule $module)
    {
        $this->collModules[]= $module;
        $module->setEvent($this);
    }

    /**
     * @param  ChildModule $module The ChildModule object to remove.
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function removeModule(ChildModule $module)
    {
        if ($this->getModules()->contains($module)) {
            $pos = $this->collModules->search($module);
            $this->collModules->remove($pos);
            if (null === $this->modulesScheduledForDeletion) {
                $this->modulesScheduledForDeletion = clone $this->collModules;
                $this->modulesScheduledForDeletion->clear();
            }
            $this->modulesScheduledForDeletion[]= $module;
            $module->setEvent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Modules from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule}> List of ChildModule objects
     */
    public function getModulesJoinDuree(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildModuleQuery::create(null, $criteria);
        $query->joinWith('Duree', $joinBehavior);

        return $this->getModules($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Modules from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule}> List of ChildModule objects
     */
    public function getModulesJoinSite(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildModuleQuery::create(null, $criteria);
        $query->joinWith('Site', $joinBehavior);

        return $this->getModules($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Modules from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule}> List of ChildModule objects
     */
    public function getModulesJoinQuota(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildModuleQuery::create(null, $criteria);
        $query->joinWith('Quota', $joinBehavior);

        return $this->getModules($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Modules from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule}> List of ChildModule objects
     */
    public function getModulesJoinRepondant(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildModuleQuery::create(null, $criteria);
        $query->joinWith('Repondant', $joinBehavior);

        return $this->getModules($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Modules from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildModule[] List of ChildModule objects
     * @phpstan-return ObjectCollection&\Traversable<ChildModule}> List of ChildModule objects
     */
    public function getModulesJoinConfirmation(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildModuleQuery::create(null, $criteria);
        $query->joinWith('Confirmation', $joinBehavior);

        return $this->getModules($query, $con);
    }

    /**
     * Clears out the collEvents collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEvents()
     */
    public function clearEvents()
    {
        $this->collEvents = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEvents collection loaded partially.
     */
    public function resetPartialEvents($v = true)
    {
        $this->collEventsPartial = $v;
    }

    /**
     * Initializes the collEvents collection.
     *
     * By default this just sets the collEvents collection to an empty array (like clearcollEvents());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEvents($overrideExisting = true)
    {
        if (null !== $this->collEvents && !$overrideExisting) {
            return;
        }

        $collectionClassName = BidJobItemTableMap::getTableMap()->getCollectionClassName();

        $this->collEvents = new $collectionClassName;
        $this->collEvents->setModel('\Model\BidJobItem');
    }

    /**
     * Gets an array of ChildBidJobItem objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEvent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem> List of ChildBidJobItem objects
     * @throws PropelException
     */
    public function getEvents(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEventsPartial && !$this->isNew();
        if (null === $this->collEvents || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEvents) {
                    $this->initEvents();
                } else {
                    $collectionClassName = BidJobItemTableMap::getTableMap()->getCollectionClassName();

                    $collEvents = new $collectionClassName;
                    $collEvents->setModel('\Model\BidJobItem');

                    return $collEvents;
                }
            } else {
                $collEvents = ChildBidJobItemQuery::create(null, $criteria)
                    ->filterByEvent($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEventsPartial && count($collEvents)) {
                        $this->initEvents(false);

                        foreach ($collEvents as $obj) {
                            if (false == $this->collEvents->contains($obj)) {
                                $this->collEvents->append($obj);
                            }
                        }

                        $this->collEventsPartial = true;
                    }

                    return $collEvents;
                }

                if ($partial && $this->collEvents) {
                    foreach ($this->collEvents as $obj) {
                        if ($obj->isNew()) {
                            $collEvents[] = $obj;
                        }
                    }
                }

                $this->collEvents = $collEvents;
                $this->collEventsPartial = false;
            }
        }

        return $this->collEvents;
    }

    /**
     * Sets a collection of ChildBidJobItem objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $events A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function setEvents(Collection $events, ConnectionInterface $con = null)
    {
        /** @var ChildBidJobItem[] $eventsToDelete */
        $eventsToDelete = $this->getEvents(new Criteria(), $con)->diff($events);


        $this->eventsScheduledForDeletion = $eventsToDelete;

        foreach ($eventsToDelete as $eventRemoved) {
            $eventRemoved->setEvent(null);
        }

        $this->collEvents = null;
        foreach ($events as $event) {
            $this->addEvent($event);
        }

        $this->collEvents = $events;
        $this->collEventsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related BidJobItem objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related BidJobItem objects.
     * @throws PropelException
     */
    public function countEvents(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEventsPartial && !$this->isNew();
        if (null === $this->collEvents || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEvents) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEvents());
            }

            $query = ChildBidJobItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEvent($this)
                ->count($con);
        }

        return count($this->collEvents);
    }

    /**
     * Method called to associate a ChildBidJobItem object to this object
     * through the ChildBidJobItem foreign key attribute.
     *
     * @param  ChildBidJobItem $l ChildBidJobItem
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function addEvent(ChildBidJobItem $l)
    {
        if ($this->collEvents === null) {
            $this->initEvents();
            $this->collEventsPartial = true;
        }

        if (!$this->collEvents->contains($l)) {
            $this->doAddEvent($l);

            if ($this->eventsScheduledForDeletion and $this->eventsScheduledForDeletion->contains($l)) {
                $this->eventsScheduledForDeletion->remove($this->eventsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildBidJobItem $event The ChildBidJobItem object to add.
     */
    protected function doAddEvent(ChildBidJobItem $event)
    {
        $this->collEvents[]= $event;
        $event->setEvent($this);
    }

    /**
     * @param  ChildBidJobItem $event The ChildBidJobItem object to remove.
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function removeEvent(ChildBidJobItem $event)
    {
        if ($this->getEvents()->contains($event)) {
            $pos = $this->collEvents->search($event);
            $this->collEvents->remove($pos);
            if (null === $this->eventsScheduledForDeletion) {
                $this->eventsScheduledForDeletion = clone $this->collEvents;
                $this->eventsScheduledForDeletion->clear();
            }
            $this->eventsScheduledForDeletion[]= $event;
            $event->setEvent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinBidJob(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('BidJob', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinSection(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('Section', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinVendor(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('Vendor', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinRespLocation(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('RespLocation', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinMethodology(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('Methodology', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinFirstDiscountSection(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('FirstDiscountSection', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinSecondDiscountSection(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('SecondDiscountSection', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinRespondentType(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('RespondentType', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinCreatedBy(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('CreatedBy', $joinBehavior);

        return $this->getEvents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related Events from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildBidJobItem[] List of ChildBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildBidJobItem}> List of ChildBidJobItem objects
     */
    public function getEventsJoinUpdatedBy(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildBidJobItemQuery::create(null, $criteria);
        $query->joinWith('UpdatedBy', $joinBehavior);

        return $this->getEvents($query, $con);
    }

    /**
     * Clears out the collEventBidJobItems collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEventBidJobItems()
     */
    public function clearEventBidJobItems()
    {
        $this->collEventBidJobItems = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEventBidJobItems collection loaded partially.
     */
    public function resetPartialEventBidJobItems($v = true)
    {
        $this->collEventBidJobItemsPartial = $v;
    }

    /**
     * Initializes the collEventBidJobItems collection.
     *
     * By default this just sets the collEventBidJobItems collection to an empty array (like clearcollEventBidJobItems());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEventBidJobItems($overrideExisting = true)
    {
        if (null !== $this->collEventBidJobItems && !$overrideExisting) {
            return;
        }

        $collectionClassName = EventBidJobItemTableMap::getTableMap()->getCollectionClassName();

        $this->collEventBidJobItems = new $collectionClassName;
        $this->collEventBidJobItems->setModel('\Model\EventBidJobItem');
    }

    /**
     * Gets an array of ChildEventBidJobItem objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEvent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEventBidJobItem[] List of ChildEventBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEventBidJobItem> List of ChildEventBidJobItem objects
     * @throws PropelException
     */
    public function getEventBidJobItems(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEventBidJobItemsPartial && !$this->isNew();
        if (null === $this->collEventBidJobItems || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEventBidJobItems) {
                    $this->initEventBidJobItems();
                } else {
                    $collectionClassName = EventBidJobItemTableMap::getTableMap()->getCollectionClassName();

                    $collEventBidJobItems = new $collectionClassName;
                    $collEventBidJobItems->setModel('\Model\EventBidJobItem');

                    return $collEventBidJobItems;
                }
            } else {
                $collEventBidJobItems = ChildEventBidJobItemQuery::create(null, $criteria)
                    ->filterByEvent($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEventBidJobItemsPartial && count($collEventBidJobItems)) {
                        $this->initEventBidJobItems(false);

                        foreach ($collEventBidJobItems as $obj) {
                            if (false == $this->collEventBidJobItems->contains($obj)) {
                                $this->collEventBidJobItems->append($obj);
                            }
                        }

                        $this->collEventBidJobItemsPartial = true;
                    }

                    return $collEventBidJobItems;
                }

                if ($partial && $this->collEventBidJobItems) {
                    foreach ($this->collEventBidJobItems as $obj) {
                        if ($obj->isNew()) {
                            $collEventBidJobItems[] = $obj;
                        }
                    }
                }

                $this->collEventBidJobItems = $collEventBidJobItems;
                $this->collEventBidJobItemsPartial = false;
            }
        }

        return $this->collEventBidJobItems;
    }

    /**
     * Sets a collection of ChildEventBidJobItem objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $eventBidJobItems A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function setEventBidJobItems(Collection $eventBidJobItems, ConnectionInterface $con = null)
    {
        /** @var ChildEventBidJobItem[] $eventBidJobItemsToDelete */
        $eventBidJobItemsToDelete = $this->getEventBidJobItems(new Criteria(), $con)->diff($eventBidJobItems);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->eventBidJobItemsScheduledForDeletion = clone $eventBidJobItemsToDelete;

        foreach ($eventBidJobItemsToDelete as $eventBidJobItemRemoved) {
            $eventBidJobItemRemoved->setEvent(null);
        }

        $this->collEventBidJobItems = null;
        foreach ($eventBidJobItems as $eventBidJobItem) {
            $this->addEventBidJobItem($eventBidJobItem);
        }

        $this->collEventBidJobItems = $eventBidJobItems;
        $this->collEventBidJobItemsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EventBidJobItem objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EventBidJobItem objects.
     * @throws PropelException
     */
    public function countEventBidJobItems(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEventBidJobItemsPartial && !$this->isNew();
        if (null === $this->collEventBidJobItems || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEventBidJobItems) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEventBidJobItems());
            }

            $query = ChildEventBidJobItemQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEvent($this)
                ->count($con);
        }

        return count($this->collEventBidJobItems);
    }

    /**
     * Method called to associate a ChildEventBidJobItem object to this object
     * through the ChildEventBidJobItem foreign key attribute.
     *
     * @param  ChildEventBidJobItem $l ChildEventBidJobItem
     * @return $this|\Model\Event The current object (for fluent API support)
     */
    public function addEventBidJobItem(ChildEventBidJobItem $l)
    {
        if ($this->collEventBidJobItems === null) {
            $this->initEventBidJobItems();
            $this->collEventBidJobItemsPartial = true;
        }

        if (!$this->collEventBidJobItems->contains($l)) {
            $this->doAddEventBidJobItem($l);

            if ($this->eventBidJobItemsScheduledForDeletion and $this->eventBidJobItemsScheduledForDeletion->contains($l)) {
                $this->eventBidJobItemsScheduledForDeletion->remove($this->eventBidJobItemsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEventBidJobItem $eventBidJobItem The ChildEventBidJobItem object to add.
     */
    protected function doAddEventBidJobItem(ChildEventBidJobItem $eventBidJobItem)
    {
        $this->collEventBidJobItems[]= $eventBidJobItem;
        $eventBidJobItem->setEvent($this);
    }

    /**
     * @param  ChildEventBidJobItem $eventBidJobItem The ChildEventBidJobItem object to remove.
     * @return $this|ChildEvent The current object (for fluent API support)
     */
    public function removeEventBidJobItem(ChildEventBidJobItem $eventBidJobItem)
    {
        if ($this->getEventBidJobItems()->contains($eventBidJobItem)) {
            $pos = $this->collEventBidJobItems->search($eventBidJobItem);
            $this->collEventBidJobItems->remove($pos);
            if (null === $this->eventBidJobItemsScheduledForDeletion) {
                $this->eventBidJobItemsScheduledForDeletion = clone $this->collEventBidJobItems;
                $this->eventBidJobItemsScheduledForDeletion->clear();
            }
            $this->eventBidJobItemsScheduledForDeletion[]= clone $eventBidJobItem;
            $eventBidJobItem->setEvent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Event is new, it will return
     * an empty collection; or if this Event has previously
     * been saved, it will retrieve related EventBidJobItems from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Event.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEventBidJobItem[] List of ChildEventBidJobItem objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEventBidJobItem}> List of ChildEventBidJobItem objects
     */
    public function getEventBidJobItemsJoinBidJobItem(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEventBidJobItemQuery::create(null, $criteria);
        $query->joinWith('BidJobItem', $joinBehavior);

        return $this->getEventBidJobItems($query, $con);
    }

    /**
     * Clears the current object, sets all attributes to their default values and removes
     * outgoing references as well as back-references (from other objects to this one. Results probably in a database
     * change of those foreign objects when you call `save` there).
     */
    public function clear()
    {
        if (null !== $this->aEventHolderBy) {
            $this->aEventHolderBy->removeEventRelatedByEventHolderId($this);
        }
        if (null !== $this->aJob) {
            $this->aJob->removeEvent($this);
        }
        if (null !== $this->aBidJob) {
            $this->aBidJob->removeEvent($this);
        }
        if (null !== $this->aRefRoom) {
            $this->aRefRoom->removeEvent($this);
        }
        if (null !== $this->aRefEventStatus) {
            $this->aRefEventStatus->removeEvent($this);
        }
        if (null !== $this->aRefTimeSlot) {
            $this->aRefTimeSlot->removeEvent($this);
        }
        if (null !== $this->aEventMethodology) {
            $this->aEventMethodology->removeEvent($this);
        }
        if (null !== $this->aAccount) {
            $this->aAccount->removeEvent($this);
        }
        if (null !== $this->aAssignedTo) {
            $this->aAssignedTo->removeEventRelatedByAssignedToId($this);
        }
        if (null !== $this->aRecordType) {
            $this->aRecordType->removeEventRelatedByRecordTypeId($this);
        }
        if (null !== $this->aEventSubType) {
            $this->aEventSubType->removeEventRelatedByEventSubTypeId($this);
        }
        if (null !== $this->aSite) {
            $this->aSite->removeEvent($this);
        }
        $this->id = null;
        $this->sams_event_id = null;
        $this->job_id = null;
        $this->bid_job_id = null;
        $this->bid_job_archive_id = null;
        $this->ref_room_id = null;
        $this->ref_time_slot_id = null;
        $this->event_status_id = null;
        $this->date = null;
        $this->confirmed_date = null;
        $this->active_date = null;
        $this->event_methodology_id = null;
        $this->status = null;
        $this->comments = null;
        $this->facility_note = null;
        $this->site_id = null;
        $this->account_id = null;
        $this->account_sf_id = null;
        $this->activity_currency = null;
        $this->all_day_event = null;
        $this->archived = null;
        $this->assigned_to_id = null;
        $this->cancelled = null;
        $this->recurring_event = null;
        $this->is_deleted = null;
        $this->is_deleted_c = null;
        $this->description = null;
        $this->duration_minutes = null;
        $this->end_date_time = null;
        $this->record_type_id = null;
        $this->event_sub_type_id = null;
        $this->job_status = null;
        $this->location_c = null;
        $this->reminder_date = null;
        $this->reminder_set = null;
        $this->start_date_time = null;
        $this->subject = null;
        $this->recurrence_time_zone = null;
        $this->created_by_sf_id = null;
        $this->pmtool_updated = null;
        $this->event_holder_id = null;
        $this->api_created_date = null;
        $this->api_updated_date = null;
        $this->is_group = null;
        $this->created_date = null;
        $this->updated_date = null;
        $this->alreadyInSave = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references and back-references to other model objects or collections of model objects.
     *
     * This method is used to reset all php object references (not the actual reference in the database).
     * Necessary for object serialisation.
     *
     * @param      boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep) {
            if ($this->collModules) {
                foreach ($this->collModules as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEvents) {
                foreach ($this->collEvents as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEventBidJobItems) {
                foreach ($this->collEventBidJobItems as $o) {
                    $o->clearAllReferences($deep);
                }
            }
        } // if ($deep)

        $this->collModules = null;
        $this->collEvents = null;
        $this->collEventBidJobItems = null;
        $this->aEventHolderBy = null;
        $this->aJob = null;
        $this->aBidJob = null;
        $this->aRefRoom = null;
        $this->aRefEventStatus = null;
        $this->aRefTimeSlot = null;
        $this->aEventMethodology = null;
        $this->aAccount = null;
        $this->aAssignedTo = null;
        $this->aRecordType = null;
        $this->aEventSubType = null;
        $this->aSite = null;
    }

    /**
     * Return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(EventTableMap::DEFAULT_STRING_FORMAT);
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     $this|ChildEvent The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[EventTableMap::COL_UPDATED_DATE] = true;

        return $this;
    }

    /**
     * Code to be run before persisting the object
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preSave(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after persisting the object
     * @param ConnectionInterface $con
     */
    public function postSave(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before inserting to database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preInsert(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after inserting to database
     * @param ConnectionInterface $con
     */
    public function postInsert(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before updating the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preUpdate(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after updating the object in database
     * @param ConnectionInterface $con
     */
    public function postUpdate(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before deleting the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preDelete(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after deleting the object in database
     * @param ConnectionInterface $con
     */
    public function postDelete(ConnectionInterface $con = null)
    {
            }


    /**
     * Derived method to catches calls to undefined methods.
     *
     * Provides magic import/export method support (fromXML()/toXML(), fromYAML()/toYAML(), etc.).
     * Allows to define default __call() behavior if you overwrite __call()
     *
     * @param string $name
     * @param mixed  $params
     *
     * @return array|string
     */
    public function __call($name, $params)
    {
        if (0 === strpos($name, 'get')) {
            $virtualColumn = substr($name, 3);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }

            $virtualColumn = lcfirst($virtualColumn);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }
        }

        if (0 === strpos($name, 'from')) {
            $format = substr($name, 4);
            $inputData = $params[0];
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->importFrom($format, $inputData, $keyType);
        }

        if (0 === strpos($name, 'to')) {
            $format = substr($name, 2);
            $includeLazyLoadColumns = $params[0] ?? true;
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->exportTo($format, $includeLazyLoadColumns, $keyType);
        }

        throw new BadMethodCallException(sprintf('Call to undefined method: %s.', $name));
    }

}
