<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EventBidJobItem as ChildEventBidJobItem;
use Model\EventBidJobItemQuery as ChildEventBidJobItemQuery;
use Model\Map\EventBidJobItemTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'event_bidjobitem' table.
 *
 *
 *
 * @method     ChildEventBidJobItemQuery orderByEventId($order = Criteria::ASC) Order by the event_id column
 * @method     ChildEventBidJobItemQuery orderByBidJobItemId($order = Criteria::ASC) Order by the bid_job_item_id column
 *
 * @method     ChildEventBidJobItemQuery groupByEventId() Group by the event_id column
 * @method     ChildEventBidJobItemQuery groupByBidJobItemId() Group by the bid_job_item_id column
 *
 * @method     ChildEventBidJobItemQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEventBidJobItemQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEventBidJobItemQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEventBidJobItemQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEventBidJobItemQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEventBidJobItemQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEventBidJobItemQuery leftJoinEvent($relationAlias = null) Adds a LEFT JOIN clause to the query using the Event relation
 * @method     ChildEventBidJobItemQuery rightJoinEvent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Event relation
 * @method     ChildEventBidJobItemQuery innerJoinEvent($relationAlias = null) Adds a INNER JOIN clause to the query using the Event relation
 *
 * @method     ChildEventBidJobItemQuery joinWithEvent($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Event relation
 *
 * @method     ChildEventBidJobItemQuery leftJoinWithEvent() Adds a LEFT JOIN clause and with to the query using the Event relation
 * @method     ChildEventBidJobItemQuery rightJoinWithEvent() Adds a RIGHT JOIN clause and with to the query using the Event relation
 * @method     ChildEventBidJobItemQuery innerJoinWithEvent() Adds a INNER JOIN clause and with to the query using the Event relation
 *
 * @method     ChildEventBidJobItemQuery leftJoinBidJobItem($relationAlias = null) Adds a LEFT JOIN clause to the query using the BidJobItem relation
 * @method     ChildEventBidJobItemQuery rightJoinBidJobItem($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BidJobItem relation
 * @method     ChildEventBidJobItemQuery innerJoinBidJobItem($relationAlias = null) Adds a INNER JOIN clause to the query using the BidJobItem relation
 *
 * @method     ChildEventBidJobItemQuery joinWithBidJobItem($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the BidJobItem relation
 *
 * @method     ChildEventBidJobItemQuery leftJoinWithBidJobItem() Adds a LEFT JOIN clause and with to the query using the BidJobItem relation
 * @method     ChildEventBidJobItemQuery rightJoinWithBidJobItem() Adds a RIGHT JOIN clause and with to the query using the BidJobItem relation
 * @method     ChildEventBidJobItemQuery innerJoinWithBidJobItem() Adds a INNER JOIN clause and with to the query using the BidJobItem relation
 *
 * @method     \Model\EventQuery|\Model\BidJobItemQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEventBidJobItem|null findOne(ConnectionInterface $con = null) Return the first ChildEventBidJobItem matching the query
 * @method     ChildEventBidJobItem findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEventBidJobItem matching the query, or a new ChildEventBidJobItem object populated from the query conditions when no match is found
 *
 * @method     ChildEventBidJobItem|null findOneByEventId(int $event_id) Return the first ChildEventBidJobItem filtered by the event_id column
 * @method     ChildEventBidJobItem|null findOneByBidJobItemId(int $bid_job_item_id) Return the first ChildEventBidJobItem filtered by the bid_job_item_id column *

 * @method     ChildEventBidJobItem requirePk($key, ConnectionInterface $con = null) Return the ChildEventBidJobItem by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventBidJobItem requireOne(ConnectionInterface $con = null) Return the first ChildEventBidJobItem matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEventBidJobItem requireOneByEventId(int $event_id) Return the first ChildEventBidJobItem filtered by the event_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEventBidJobItem requireOneByBidJobItemId(int $bid_job_item_id) Return the first ChildEventBidJobItem filtered by the bid_job_item_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEventBidJobItem[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEventBidJobItem objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEventBidJobItem> find(ConnectionInterface $con = null) Return ChildEventBidJobItem objects based on current ModelCriteria
 * @method     ChildEventBidJobItem[]|ObjectCollection findByEventId(int $event_id) Return ChildEventBidJobItem objects filtered by the event_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEventBidJobItem> findByEventId(int $event_id) Return ChildEventBidJobItem objects filtered by the event_id column
 * @method     ChildEventBidJobItem[]|ObjectCollection findByBidJobItemId(int $bid_job_item_id) Return ChildEventBidJobItem objects filtered by the bid_job_item_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEventBidJobItem> findByBidJobItemId(int $bid_job_item_id) Return ChildEventBidJobItem objects filtered by the bid_job_item_id column
 * @method     ChildEventBidJobItem[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEventBidJobItem> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EventBidJobItemQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EventBidJobItemQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EventBidJobItem', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEventBidJobItemQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEventBidJobItemQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEventBidJobItemQuery) {
            return $criteria;
        }
        $query = new ChildEventBidJobItemQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$event_id, $bid_job_item_id] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEventBidJobItem|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EventBidJobItemTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EventBidJobItemTableMap::getInstanceFromPool(serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]))))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventBidJobItem A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `event_id`, `bid_job_item_id` FROM `event_bidjobitem` WHERE `event_id` = :p0 AND `bid_job_item_id` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_INT);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEventBidJobItem $obj */
            $obj = new ChildEventBidJobItem();
            $obj->hydrate($row);
            EventBidJobItemTableMap::addInstanceToPool($obj, serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEventBidJobItem|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(EventBidJobItemTableMap::COL_EVENT_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the event_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEventId(1234); // WHERE event_id = 1234
     * $query->filterByEventId(array(12, 34)); // WHERE event_id IN (12, 34)
     * $query->filterByEventId(array('min' => 12)); // WHERE event_id > 12
     * </code>
     *
     * @see       filterByEvent()
     *
     * @param     mixed $eventId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByEventId($eventId = null, $comparison = null)
    {
        if (is_array($eventId)) {
            $useMinMax = false;
            if (isset($eventId['min'])) {
                $this->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $eventId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($eventId['max'])) {
                $this->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $eventId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $eventId, $comparison);
    }

    /**
     * Filter the query on the bid_job_item_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBidJobItemId(1234); // WHERE bid_job_item_id = 1234
     * $query->filterByBidJobItemId(array(12, 34)); // WHERE bid_job_item_id IN (12, 34)
     * $query->filterByBidJobItemId(array('min' => 12)); // WHERE bid_job_item_id > 12
     * </code>
     *
     * @see       filterByBidJobItem()
     *
     * @param     mixed $bidJobItemId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByBidJobItemId($bidJobItemId = null, $comparison = null)
    {
        if (is_array($bidJobItemId)) {
            $useMinMax = false;
            if (isset($bidJobItemId['min'])) {
                $this->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $bidJobItemId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($bidJobItemId['max'])) {
                $this->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $bidJobItemId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $bidJobItemId, $comparison);
    }

    /**
     * Filter the query by a related \Model\Event object
     *
     * @param \Model\Event|ObjectCollection $event The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByEvent($event, $comparison = null)
    {
        if ($event instanceof \Model\Event) {
            return $this
                ->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $event->getId(), $comparison);
        } elseif ($event instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventBidJobItemTableMap::COL_EVENT_ID, $event->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEvent() only accepts arguments of type \Model\Event or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Event relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function joinEvent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Event');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Event');
        }

        return $this;
    }

    /**
     * Use the Event relation Event object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EventQuery A secondary query class using the current class as primary query
     */
    public function useEventQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEvent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Event', '\Model\EventQuery');
    }

    /**
     * Use the Event relation Event object
     *
     * @param callable(\Model\EventQuery):\Model\EventQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEventQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEventQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Event table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EventQuery The inner query object of the EXISTS statement
     */
    public function useEventExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Event table for a NOT EXISTS query.
     *
     * @see useEventExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EventQuery The inner query object of the NOT EXISTS statement
     */
    public function useEventNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Event', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\BidJobItem object
     *
     * @param \Model\BidJobItem|ObjectCollection $bidJobItem The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function filterByBidJobItem($bidJobItem, $comparison = null)
    {
        if ($bidJobItem instanceof \Model\BidJobItem) {
            return $this
                ->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $bidJobItem->getId(), $comparison);
        } elseif ($bidJobItem instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID, $bidJobItem->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByBidJobItem() only accepts arguments of type \Model\BidJobItem or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BidJobItem relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function joinBidJobItem($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BidJobItem');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BidJobItem');
        }

        return $this;
    }

    /**
     * Use the BidJobItem relation BidJobItem object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\BidJobItemQuery A secondary query class using the current class as primary query
     */
    public function useBidJobItemQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBidJobItem($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BidJobItem', '\Model\BidJobItemQuery');
    }

    /**
     * Use the BidJobItem relation BidJobItem object
     *
     * @param callable(\Model\BidJobItemQuery):\Model\BidJobItemQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withBidJobItemQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useBidJobItemQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to BidJobItem table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\BidJobItemQuery The inner query object of the EXISTS statement
     */
    public function useBidJobItemExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('BidJobItem', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to BidJobItem table for a NOT EXISTS query.
     *
     * @see useBidJobItemExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\BidJobItemQuery The inner query object of the NOT EXISTS statement
     */
    public function useBidJobItemNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('BidJobItem', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEventBidJobItem $eventBidJobItem Object to remove from the list of results
     *
     * @return $this|ChildEventBidJobItemQuery The current query, for fluid interface
     */
    public function prune($eventBidJobItem = null)
    {
        if ($eventBidJobItem) {
            $this->addCond('pruneCond0', $this->getAliasedColName(EventBidJobItemTableMap::COL_EVENT_ID), $eventBidJobItem->getEventId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(EventBidJobItemTableMap::COL_BID_JOB_ITEM_ID), $eventBidJobItem->getBidJobItemId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the event_bidjobitem table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventBidJobItemTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EventBidJobItemTableMap::clearInstancePool();
            EventBidJobItemTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EventBidJobItemTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EventBidJobItemTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EventBidJobItemTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EventBidJobItemTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // EventBidJobItemQuery
