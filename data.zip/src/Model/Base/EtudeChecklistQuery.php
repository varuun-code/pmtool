<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EtudeChecklist as ChildEtudeChecklist;
use Model\EtudeChecklistQuery as ChildEtudeChecklistQuery;
use Model\Map\EtudeChecklistTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'ref_etude_checklist' table.
 *
 *
 *
 * @method     ChildEtudeChecklistQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEtudeChecklistQuery orderByLibelle($order = Criteria::ASC) Order by the libelle column
 * @method     ChildEtudeChecklistQuery orderByEtudeEtapeId($order = Criteria::ASC) Order by the etude_etape_id column
 * @method     ChildEtudeChecklistQuery orderByGroupeId($order = Criteria::ASC) Order by the groupe_id column
 * @method     ChildEtudeChecklistQuery orderByEtudeChecklistTypeId($order = Criteria::ASC) Order by the etude_checklist_type_id column
 * @method     ChildEtudeChecklistQuery orderBySort($order = Criteria::ASC) Order by the sort column
 *
 * @method     ChildEtudeChecklistQuery groupById() Group by the id column
 * @method     ChildEtudeChecklistQuery groupByLibelle() Group by the libelle column
 * @method     ChildEtudeChecklistQuery groupByEtudeEtapeId() Group by the etude_etape_id column
 * @method     ChildEtudeChecklistQuery groupByGroupeId() Group by the groupe_id column
 * @method     ChildEtudeChecklistQuery groupByEtudeChecklistTypeId() Group by the etude_checklist_type_id column
 * @method     ChildEtudeChecklistQuery groupBySort() Group by the sort column
 *
 * @method     ChildEtudeChecklistQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtudeChecklistQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtudeChecklistQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtudeChecklistQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtudeChecklistQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtudeChecklistQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtudeChecklistQuery leftJoinGroupe($relationAlias = null) Adds a LEFT JOIN clause to the query using the Groupe relation
 * @method     ChildEtudeChecklistQuery rightJoinGroupe($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Groupe relation
 * @method     ChildEtudeChecklistQuery innerJoinGroupe($relationAlias = null) Adds a INNER JOIN clause to the query using the Groupe relation
 *
 * @method     ChildEtudeChecklistQuery joinWithGroupe($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Groupe relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinWithGroupe() Adds a LEFT JOIN clause and with to the query using the Groupe relation
 * @method     ChildEtudeChecklistQuery rightJoinWithGroupe() Adds a RIGHT JOIN clause and with to the query using the Groupe relation
 * @method     ChildEtudeChecklistQuery innerJoinWithGroupe() Adds a INNER JOIN clause and with to the query using the Groupe relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinEtape($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeChecklistQuery rightJoinEtape($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeChecklistQuery innerJoinEtape($relationAlias = null) Adds a INNER JOIN clause to the query using the Etape relation
 *
 * @method     ChildEtudeChecklistQuery joinWithEtape($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etape relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinWithEtape() Adds a LEFT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeChecklistQuery rightJoinWithEtape() Adds a RIGHT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeChecklistQuery innerJoinWithEtape() Adds a INNER JOIN clause and with to the query using the Etape relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinEtudeCheckListType($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeCheckListType relation
 * @method     ChildEtudeChecklistQuery rightJoinEtudeCheckListType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeCheckListType relation
 * @method     ChildEtudeChecklistQuery innerJoinEtudeCheckListType($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeCheckListType relation
 *
 * @method     ChildEtudeChecklistQuery joinWithEtudeCheckListType($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeCheckListType relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinWithEtudeCheckListType() Adds a LEFT JOIN clause and with to the query using the EtudeCheckListType relation
 * @method     ChildEtudeChecklistQuery rightJoinWithEtudeCheckListType() Adds a RIGHT JOIN clause and with to the query using the EtudeCheckListType relation
 * @method     ChildEtudeChecklistQuery innerJoinWithEtudeCheckListType() Adds a INNER JOIN clause and with to the query using the EtudeCheckListType relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinEtudeCheckListValidation($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeChecklistQuery rightJoinEtudeCheckListValidation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeChecklistQuery innerJoinEtudeCheckListValidation($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeCheckListValidation relation
 *
 * @method     ChildEtudeChecklistQuery joinWithEtudeCheckListValidation($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeCheckListValidation relation
 *
 * @method     ChildEtudeChecklistQuery leftJoinWithEtudeCheckListValidation() Adds a LEFT JOIN clause and with to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeChecklistQuery rightJoinWithEtudeCheckListValidation() Adds a RIGHT JOIN clause and with to the query using the EtudeCheckListValidation relation
 * @method     ChildEtudeChecklistQuery innerJoinWithEtudeCheckListValidation() Adds a INNER JOIN clause and with to the query using the EtudeCheckListValidation relation
 *
 * @method     \Model\GroupeQuery|\Model\EtapeQuery|\Model\EtudeCheckListTypeQuery|\Model\EtudeCheckListValidationQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtudeChecklist|null findOne(ConnectionInterface $con = null) Return the first ChildEtudeChecklist matching the query
 * @method     ChildEtudeChecklist findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtudeChecklist matching the query, or a new ChildEtudeChecklist object populated from the query conditions when no match is found
 *
 * @method     ChildEtudeChecklist|null findOneById(int $id) Return the first ChildEtudeChecklist filtered by the id column
 * @method     ChildEtudeChecklist|null findOneByLibelle(string $libelle) Return the first ChildEtudeChecklist filtered by the libelle column
 * @method     ChildEtudeChecklist|null findOneByEtudeEtapeId(int $etude_etape_id) Return the first ChildEtudeChecklist filtered by the etude_etape_id column
 * @method     ChildEtudeChecklist|null findOneByGroupeId(int $groupe_id) Return the first ChildEtudeChecklist filtered by the groupe_id column
 * @method     ChildEtudeChecklist|null findOneByEtudeChecklistTypeId(int $etude_checklist_type_id) Return the first ChildEtudeChecklist filtered by the etude_checklist_type_id column
 * @method     ChildEtudeChecklist|null findOneBySort(int $sort) Return the first ChildEtudeChecklist filtered by the sort column *

 * @method     ChildEtudeChecklist requirePk($key, ConnectionInterface $con = null) Return the ChildEtudeChecklist by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOne(ConnectionInterface $con = null) Return the first ChildEtudeChecklist matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeChecklist requireOneById(int $id) Return the first ChildEtudeChecklist filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOneByLibelle(string $libelle) Return the first ChildEtudeChecklist filtered by the libelle column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOneByEtudeEtapeId(int $etude_etape_id) Return the first ChildEtudeChecklist filtered by the etude_etape_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOneByGroupeId(int $groupe_id) Return the first ChildEtudeChecklist filtered by the groupe_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOneByEtudeChecklistTypeId(int $etude_checklist_type_id) Return the first ChildEtudeChecklist filtered by the etude_checklist_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeChecklist requireOneBySort(int $sort) Return the first ChildEtudeChecklist filtered by the sort column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeChecklist[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtudeChecklist objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> find(ConnectionInterface $con = null) Return ChildEtudeChecklist objects based on current ModelCriteria
 * @method     ChildEtudeChecklist[]|ObjectCollection findById(int $id) Return ChildEtudeChecklist objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findById(int $id) Return ChildEtudeChecklist objects filtered by the id column
 * @method     ChildEtudeChecklist[]|ObjectCollection findByLibelle(string $libelle) Return ChildEtudeChecklist objects filtered by the libelle column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findByLibelle(string $libelle) Return ChildEtudeChecklist objects filtered by the libelle column
 * @method     ChildEtudeChecklist[]|ObjectCollection findByEtudeEtapeId(int $etude_etape_id) Return ChildEtudeChecklist objects filtered by the etude_etape_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findByEtudeEtapeId(int $etude_etape_id) Return ChildEtudeChecklist objects filtered by the etude_etape_id column
 * @method     ChildEtudeChecklist[]|ObjectCollection findByGroupeId(int $groupe_id) Return ChildEtudeChecklist objects filtered by the groupe_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findByGroupeId(int $groupe_id) Return ChildEtudeChecklist objects filtered by the groupe_id column
 * @method     ChildEtudeChecklist[]|ObjectCollection findByEtudeChecklistTypeId(int $etude_checklist_type_id) Return ChildEtudeChecklist objects filtered by the etude_checklist_type_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findByEtudeChecklistTypeId(int $etude_checklist_type_id) Return ChildEtudeChecklist objects filtered by the etude_checklist_type_id column
 * @method     ChildEtudeChecklist[]|ObjectCollection findBySort(int $sort) Return ChildEtudeChecklist objects filtered by the sort column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeChecklist> findBySort(int $sort) Return ChildEtudeChecklist objects filtered by the sort column
 * @method     ChildEtudeChecklist[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtudeChecklist> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtudeChecklistQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtudeChecklistQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EtudeChecklist', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtudeChecklistQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtudeChecklistQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtudeChecklistQuery) {
            return $criteria;
        }
        $query = new ChildEtudeChecklistQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtudeChecklist|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtudeChecklistTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeChecklist A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `libelle`, `etude_etape_id`, `groupe_id`, `etude_checklist_type_id`, `sort` FROM `ref_etude_checklist` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtudeChecklist $obj */
            $obj = new ChildEtudeChecklist();
            $obj->hydrate($row);
            EtudeChecklistTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtudeChecklist|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the libelle column
     *
     * Example usage:
     * <code>
     * $query->filterByLibelle('fooValue');   // WHERE libelle = 'fooValue'
     * $query->filterByLibelle('%fooValue%', Criteria::LIKE); // WHERE libelle LIKE '%fooValue%'
     * $query->filterByLibelle(['foo', 'bar']); // WHERE libelle IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $libelle The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByLibelle($libelle = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($libelle)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_LIBELLE, $libelle, $comparison);
    }

    /**
     * Filter the query on the etude_etape_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEtudeEtapeId(1234); // WHERE etude_etape_id = 1234
     * $query->filterByEtudeEtapeId(array(12, 34)); // WHERE etude_etape_id IN (12, 34)
     * $query->filterByEtudeEtapeId(array('min' => 12)); // WHERE etude_etape_id > 12
     * </code>
     *
     * @see       filterByEtape()
     *
     * @param     mixed $etudeEtapeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByEtudeEtapeId($etudeEtapeId = null, $comparison = null)
    {
        if (is_array($etudeEtapeId)) {
            $useMinMax = false;
            if (isset($etudeEtapeId['min'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $etudeEtapeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etudeEtapeId['max'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $etudeEtapeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $etudeEtapeId, $comparison);
    }

    /**
     * Filter the query on the groupe_id column
     *
     * Example usage:
     * <code>
     * $query->filterByGroupeId(1234); // WHERE groupe_id = 1234
     * $query->filterByGroupeId(array(12, 34)); // WHERE groupe_id IN (12, 34)
     * $query->filterByGroupeId(array('min' => 12)); // WHERE groupe_id > 12
     * </code>
     *
     * @see       filterByGroupe()
     *
     * @param     mixed $groupeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByGroupeId($groupeId = null, $comparison = null)
    {
        if (is_array($groupeId)) {
            $useMinMax = false;
            if (isset($groupeId['min'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_GROUPE_ID, $groupeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($groupeId['max'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_GROUPE_ID, $groupeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_GROUPE_ID, $groupeId, $comparison);
    }

    /**
     * Filter the query on the etude_checklist_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEtudeChecklistTypeId(1234); // WHERE etude_checklist_type_id = 1234
     * $query->filterByEtudeChecklistTypeId(array(12, 34)); // WHERE etude_checklist_type_id IN (12, 34)
     * $query->filterByEtudeChecklistTypeId(array('min' => 12)); // WHERE etude_checklist_type_id > 12
     * </code>
     *
     * @see       filterByEtudeCheckListType()
     *
     * @param     mixed $etudeChecklistTypeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByEtudeChecklistTypeId($etudeChecklistTypeId = null, $comparison = null)
    {
        if (is_array($etudeChecklistTypeId)) {
            $useMinMax = false;
            if (isset($etudeChecklistTypeId['min'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $etudeChecklistTypeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etudeChecklistTypeId['max'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $etudeChecklistTypeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $etudeChecklistTypeId, $comparison);
    }

    /**
     * Filter the query on the sort column
     *
     * Example usage:
     * <code>
     * $query->filterBySort(1234); // WHERE sort = 1234
     * $query->filterBySort(array(12, 34)); // WHERE sort IN (12, 34)
     * $query->filterBySort(array('min' => 12)); // WHERE sort > 12
     * </code>
     *
     * @param     mixed $sort The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterBySort($sort = null, $comparison = null)
    {
        if (is_array($sort)) {
            $useMinMax = false;
            if (isset($sort['min'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_SORT, $sort['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($sort['max'])) {
                $this->addUsingAlias(EtudeChecklistTableMap::COL_SORT, $sort['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeChecklistTableMap::COL_SORT, $sort, $comparison);
    }

    /**
     * Filter the query by a related \Model\Groupe object
     *
     * @param \Model\Groupe|ObjectCollection $groupe The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByGroupe($groupe, $comparison = null)
    {
        if ($groupe instanceof \Model\Groupe) {
            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_GROUPE_ID, $groupe->getId(), $comparison);
        } elseif ($groupe instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_GROUPE_ID, $groupe->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByGroupe() only accepts arguments of type \Model\Groupe or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Groupe relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function joinGroupe($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Groupe');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Groupe');
        }

        return $this;
    }

    /**
     * Use the Groupe relation Groupe object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\GroupeQuery A secondary query class using the current class as primary query
     */
    public function useGroupeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinGroupe($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Groupe', '\Model\GroupeQuery');
    }

    /**
     * Use the Groupe relation Groupe object
     *
     * @param callable(\Model\GroupeQuery):\Model\GroupeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withGroupeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useGroupeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Groupe table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\GroupeQuery The inner query object of the EXISTS statement
     */
    public function useGroupeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Groupe', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Groupe table for a NOT EXISTS query.
     *
     * @see useGroupeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\GroupeQuery The inner query object of the NOT EXISTS statement
     */
    public function useGroupeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Groupe', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Etape object
     *
     * @param \Model\Etape|ObjectCollection $etape The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByEtape($etape, $comparison = null)
    {
        if ($etape instanceof \Model\Etape) {
            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $etape->getId(), $comparison);
        } elseif ($etape instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $etape->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtape() only accepts arguments of type \Model\Etape or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etape relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function joinEtape($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etape');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etape');
        }

        return $this;
    }

    /**
     * Use the Etape relation Etape object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtapeQuery A secondary query class using the current class as primary query
     */
    public function useEtapeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtape($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etape', '\Model\EtapeQuery');
    }

    /**
     * Use the Etape relation Etape object
     *
     * @param callable(\Model\EtapeQuery):\Model\EtapeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtapeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtapeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etape table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtapeQuery The inner query object of the EXISTS statement
     */
    public function useEtapeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etape table for a NOT EXISTS query.
     *
     * @see useEtapeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtapeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtapeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeCheckListType object
     *
     * @param \Model\EtudeCheckListType|ObjectCollection $etudeCheckListType The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByEtudeCheckListType($etudeCheckListType, $comparison = null)
    {
        if ($etudeCheckListType instanceof \Model\EtudeCheckListType) {
            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $etudeCheckListType->getId(), $comparison);
        } elseif ($etudeCheckListType instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $etudeCheckListType->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeCheckListType() only accepts arguments of type \Model\EtudeCheckListType or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeCheckListType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function joinEtudeCheckListType($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeCheckListType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeCheckListType');
        }

        return $this;
    }

    /**
     * Use the EtudeCheckListType relation EtudeCheckListType object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeCheckListTypeQuery A secondary query class using the current class as primary query
     */
    public function useEtudeCheckListTypeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeCheckListType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeCheckListType', '\Model\EtudeCheckListTypeQuery');
    }

    /**
     * Use the EtudeCheckListType relation EtudeCheckListType object
     *
     * @param callable(\Model\EtudeCheckListTypeQuery):\Model\EtudeCheckListTypeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeCheckListTypeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeCheckListTypeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeCheckListType table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeCheckListTypeQuery The inner query object of the EXISTS statement
     */
    public function useEtudeCheckListTypeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeCheckListType', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeCheckListType table for a NOT EXISTS query.
     *
     * @see useEtudeCheckListTypeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeCheckListTypeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeCheckListTypeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeCheckListType', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\EtudeCheckListValidation object
     *
     * @param \Model\EtudeCheckListValidation|ObjectCollection $etudeCheckListValidation the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByEtudeCheckListValidation($etudeCheckListValidation, $comparison = null)
    {
        if ($etudeCheckListValidation instanceof \Model\EtudeCheckListValidation) {
            return $this
                ->addUsingAlias(EtudeChecklistTableMap::COL_ID, $etudeCheckListValidation->getEtudeChecklistId(), $comparison);
        } elseif ($etudeCheckListValidation instanceof ObjectCollection) {
            return $this
                ->useEtudeCheckListValidationQuery()
                ->filterByPrimaryKeys($etudeCheckListValidation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByEtudeCheckListValidation() only accepts arguments of type \Model\EtudeCheckListValidation or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeCheckListValidation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function joinEtudeCheckListValidation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeCheckListValidation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeCheckListValidation');
        }

        return $this;
    }

    /**
     * Use the EtudeCheckListValidation relation EtudeCheckListValidation object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeCheckListValidationQuery A secondary query class using the current class as primary query
     */
    public function useEtudeCheckListValidationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtudeCheckListValidation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeCheckListValidation', '\Model\EtudeCheckListValidationQuery');
    }

    /**
     * Use the EtudeCheckListValidation relation EtudeCheckListValidation object
     *
     * @param callable(\Model\EtudeCheckListValidationQuery):\Model\EtudeCheckListValidationQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeCheckListValidationQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeCheckListValidationQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to EtudeCheckListValidation table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeCheckListValidationQuery The inner query object of the EXISTS statement
     */
    public function useEtudeCheckListValidationExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeCheckListValidation', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to EtudeCheckListValidation table for a NOT EXISTS query.
     *
     * @see useEtudeCheckListValidationExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeCheckListValidationQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeCheckListValidationNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeCheckListValidation', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEtudeChecklist $etudeChecklist Object to remove from the list of results
     *
     * @return $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function prune($etudeChecklist = null)
    {
        if ($etudeChecklist) {
            $this->addUsingAlias(EtudeChecklistTableMap::COL_ID, $etudeChecklist->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the ref_etude_checklist table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtudeChecklistTableMap::clearInstancePool();
            EtudeChecklistTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtudeChecklistTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtudeChecklistTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtudeChecklistTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    // sortable behavior

    /**
     * Returns the objects in a certain list, from the list scope
     *
     * @param int $scope Scope to determine which objects node to return
     *
     * @return    $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function inList($scope = null)
    {

        static::sortableApplyScopeCriteria($this, $scope, 'addUsingAlias');

        return $this;
    }

    /**
     * Filter the query based on a rank in the list
     *
     * @param     integer   $rank rank
     * @param int $scope Scope to determine which objects node to return

     *
     * @return    ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function filterByRank($rank, $scope = null)
    {

        return $this
            ->inList($scope)
            ->addUsingAlias(EtudeChecklistTableMap::RANK_COL, $rank, Criteria::EQUAL);
    }

    /**
     * Order the query based on the rank in the list.
     * Using the default $order, returns the item with the lowest rank first
     *
     * @param     string $order either Criteria::ASC (default) or Criteria::DESC
     *
     * @return    $this|ChildEtudeChecklistQuery The current query, for fluid interface
     */
    public function orderByRank($order = Criteria::ASC)
    {
        $order = strtoupper($order);
        switch ($order) {
            case Criteria::ASC:
                return $this->addAscendingOrderByColumn($this->getAliasedColName(EtudeChecklistTableMap::RANK_COL));
                break;
            case Criteria::DESC:
                return $this->addDescendingOrderByColumn($this->getAliasedColName(EtudeChecklistTableMap::RANK_COL));
                break;
            default:
                throw new \Propel\Runtime\Exception\PropelException('ChildEtudeChecklistQuery::orderBy() only accepts "asc" or "desc" as argument');
        }
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param int $scope Scope to determine which objects node to return
     * @param     ConnectionInterface $con optional connection
     *
     * @return    ChildEtudeChecklist
     */
    public function findOneByRank($rank, $scope = null, ConnectionInterface $con = null)
    {

        return $this
            ->filterByRank($rank, $scope)
            ->findOne($con);
    }

    /**
     * Returns a list of objects
     *
     * @param int $scope Scope to determine which objects node to return

     * @param      ConnectionInterface $con    Connection to use.
     *
     * @return     mixed the list of results, formatted by the current formatter
     */
    public function findList($scope = null, $con = null)
    {

        return $this
            ->inList($scope)
            ->orderByRank()
            ->find($con);
    }

    /**
     * Get the highest rank
     *
     * @param int $scope Scope to determine which objects node to return
     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRank($scope = null, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EtudeChecklistTableMap::RANK_COL . ')');

                static::sortableApplyScopeCriteria($this, $scope);
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get the highest rank by a scope with a array format.
     *
     * @param     mixed $scope      The scope value as scalar type or array($value1, ...).

     * @param     ConnectionInterface optional connection
     *
     * @return    integer highest position
     */
    public function getMaxRankArray($scope, ConnectionInterface $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        // shift the objects with a position lower than the one of object
        $this->addSelectColumn('MAX(' . EtudeChecklistTableMap::RANK_COL . ')');
        static::sortableApplyScopeCriteria($this, $scope);
        $stmt = $this->doSelect($con);

        return $stmt->fetchColumn();
    }

    /**
     * Get an item from the list based on its rank
     *
     * @param     integer   $rank rank
     * @param      int $scope        Scope to determine which suite to consider
     * @param     ConnectionInterface $con optional connection
     *
     * @return ChildEtudeChecklist
     */
    static public function retrieveByRank($rank, $scope = null, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $c = new Criteria;
        $c->add(EtudeChecklistTableMap::RANK_COL, $rank);
                static::sortableApplyScopeCriteria($c, $scope);

        return static::create(null, $c)->findOne($con);
    }

    /**
     * Reorder a set of sortable objects based on a list of id/position
     * Beware that there is no check made on the positions passed
     * So incoherent positions will result in an incoherent list
     *
     * @param     mixed               $order id => rank pairs
     * @param     ConnectionInterface $con   optional connection
     *
     * @return    boolean true if the reordering took place, false if a database problem prevented it
     */
    public function reorder($order, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con, $order) {
            $ids = array_keys($order);
            $objects = $this->findPks($ids, $con);
            foreach ($objects as $object) {
                $pk = $object->getPrimaryKey();
                if ($object->getSort() != $order[$pk]) {
                    $object->setSort($order[$pk]);
                    $object->save($con);
                }
            }
        });

        return true;
    }

    /**
     * Return an array of sortable objects ordered by position
     *
     * @param     Criteria  $criteria  optional criteria object
     * @param     string    $order     sorting order, to be chosen between Criteria::ASC (default) and Criteria::DESC
     * @param     ConnectionInterface $con       optional connection
     *
     * @return    array list of sortable objects
     */
    static public function doSelectOrderByRank(Criteria $criteria = null, $order = Criteria::ASC, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        if (null === $criteria) {
            $criteria = new Criteria();
        } elseif ($criteria instanceof Criteria) {
            $criteria = clone $criteria;
        }

        $criteria->clearOrderByColumns();

        if (Criteria::ASC == $order) {
            $criteria->addAscendingOrderByColumn(EtudeChecklistTableMap::RANK_COL);
        } else {
            $criteria->addDescendingOrderByColumn(EtudeChecklistTableMap::RANK_COL);
        }

        return ChildEtudeChecklistQuery::create(null, $criteria)->find($con);
    }

    /**
     * Return an array of sortable objects in the given scope ordered by position
     *
     * @param     int       $scope  the scope of the list
     * @param     string    $order  sorting order, to be chosen between Criteria::ASC (default) and Criteria::DESC
     * @param     ConnectionInterface $con    optional connection
     *
     * @return    array list of sortable objects
     */
    static public function retrieveList($scope, $order = Criteria::ASC, ConnectionInterface $con = null)
    {
        $c = new Criteria();
        static::sortableApplyScopeCriteria($c, $scope);

        return ChildEtudeChecklistQuery::doSelectOrderByRank($c, $order, $con);
    }

    /**
     * Return the number of sortable objects in the given scope
     *
     * @param     int       $scope  the scope of the list
     * @param     ConnectionInterface $con    optional connection
     *
     * @return    array list of sortable objects
     */
    static public function countList($scope, ConnectionInterface $con = null)
    {
        $c = new Criteria();
        $c->add(EtudeChecklistTableMap::SCOPE_COL, $scope);

        return ChildEtudeChecklistQuery::create(null, $c)->count($con);
    }

    /**
     * Deletes the sortable objects in the given scope
     *
     * @param     int       $scope  the scope of the list
     * @param     ConnectionInterface $con    optional connection
     *
     * @return    int number of deleted objects
     */
    static public function deleteList($scope, ConnectionInterface $con = null)
    {
        $c = new Criteria();
        static::sortableApplyScopeCriteria($c, $scope);

        return EtudeChecklistTableMap::doDelete($c, $con);
    }

    /**
     * Applies all scope fields to the given criteria.
     *
     * @param  Criteria $criteria Applies the values directly to this criteria.
     * @param  mixed    $scope    The scope value as scalar type or array($value1, ...).
     * @param  string   $method   The method we use to apply the values.
     *
     */
    static public function sortableApplyScopeCriteria(Criteria $criteria, $scope, $method = 'add')
    {

        $criteria->$method(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $scope, Criteria::EQUAL);

    }

    /**
     * Adds $delta to all Rank values that are >= $first and <= $last.
     * '$delta' can also be negative.
     *
     * @param      int $delta Value to be shifted by, can be negative
     * @param      int $first First node to be shifted
     * @param      int $last  Last node to be shifted
     * @param      int $scope Scope to use for the shift
     * @param      ConnectionInterface $con Connection to use.
     */
    static public function sortableShiftRank($delta, $first, $last = null, $scope = null, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $whereCriteria = new Criteria(EtudeChecklistTableMap::DATABASE_NAME);
        $criterion = $whereCriteria->getNewCriterion(EtudeChecklistTableMap::RANK_COL, $first, Criteria::GREATER_EQUAL);
        if (null !== $last) {
            $criterion->addAnd($whereCriteria->getNewCriterion(EtudeChecklistTableMap::RANK_COL, $last, Criteria::LESS_EQUAL));
        }
        $whereCriteria->add($criterion);
                static::sortableApplyScopeCriteria($whereCriteria, $scope);

        $valuesCriteria = new Criteria(EtudeChecklistTableMap::DATABASE_NAME);
        $valuesCriteria->add(EtudeChecklistTableMap::RANK_COL, array('raw' => EtudeChecklistTableMap::RANK_COL . ' + ?', 'value' => $delta), Criteria::CUSTOM_EQUAL);

        $whereCriteria->doUpdate($valuesCriteria, $con);
        EtudeChecklistTableMap::clearInstancePool();
    }

} // EtudeChecklistQuery
