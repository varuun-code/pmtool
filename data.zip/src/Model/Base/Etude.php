<?php

namespace Model\Base;

use \DateTime;
use \Exception;
use \PDO;
use Model\Account as ChildAccount;
use Model\AccountQuery as ChildAccountQuery;
use Model\AmReasonType as ChildAmReasonType;
use Model\AmReasonTypeQuery as ChildAmReasonTypeQuery;
use Model\Area as ChildArea;
use Model\AreaQuery as ChildAreaQuery;
use Model\Contact as ChildContact;
use Model\ContactQuery as ChildContactQuery;
use Model\DernierAcces as ChildDernierAcces;
use Model\DernierAccesQuery as ChildDernierAccesQuery;
use Model\Etape as ChildEtape;
use Model\EtapeQuery as ChildEtapeQuery;
use Model\Etude as ChildEtude;
use Model\EtudeCheckListValidation as ChildEtudeCheckListValidation;
use Model\EtudeCheckListValidationQuery as ChildEtudeCheckListValidationQuery;
use Model\EtudeFichier as ChildEtudeFichier;
use Model\EtudeFichierQuery as ChildEtudeFichierQuery;
use Model\EtudeGroup as ChildEtudeGroup;
use Model\EtudeGroupQuery as ChildEtudeGroupQuery;
use Model\EtudeMethodology as ChildEtudeMethodology;
use Model\EtudeMethodologyQuery as ChildEtudeMethodologyQuery;
use Model\EtudeQuery as ChildEtudeQuery;
use Model\EtudeSampleSource as ChildEtudeSampleSource;
use Model\EtudeSampleSourceQuery as ChildEtudeSampleSourceQuery;
use Model\Facture as ChildFacture;
use Model\FactureQuery as ChildFactureQuery;
use Model\Industry as ChildIndustry;
use Model\IndustryQuery as ChildIndustryQuery;
use Model\Job as ChildJob;
use Model\JobQuery as ChildJobQuery;
use Model\Location as ChildLocation;
use Model\LocationQuery as ChildLocationQuery;
use Model\LogProjectStatus as ChildLogProjectStatus;
use Model\LogProjectStatusQuery as ChildLogProjectStatusQuery;
use Model\Methodology as ChildMethodology;
use Model\MethodologyQuery as ChildMethodologyQuery;
use Model\Opportunity as ChildOpportunity;
use Model\OpportunityQuery as ChildOpportunityQuery;
use Model\ProjectLocationPrefix as ChildProjectLocationPrefix;
use Model\ProjectLocationPrefixQuery as ChildProjectLocationPrefixQuery;
use Model\RefSalesForce as ChildRefSalesForce;
use Model\RefSalesForceEtudeSector as ChildRefSalesForceEtudeSector;
use Model\RefSalesForceEtudeSectorQuery as ChildRefSalesForceEtudeSectorQuery;
use Model\RefSalesForceQuery as ChildRefSalesForceQuery;
use Model\Reglement as ChildReglement;
use Model\ReglementQuery as ChildReglementQuery;
use Model\SampleSource as ChildSampleSource;
use Model\SampleSourceQuery as ChildSampleSourceQuery;
use Model\SiJobType as ChildSiJobType;
use Model\SiJobTypeQuery as ChildSiJobTypeQuery;
use Model\User as ChildUser;
use Model\UserQuery as ChildUserQuery;
use Model\Map\DernierAccesTableMap;
use Model\Map\EtudeCheckListValidationTableMap;
use Model\Map\EtudeFichierTableMap;
use Model\Map\EtudeMethodologyTableMap;
use Model\Map\EtudeSampleSourceTableMap;
use Model\Map\EtudeTableMap;
use Model\Map\FactureTableMap;
use Model\Map\JobTableMap;
use Model\Map\LogProjectStatusTableMap;
use Model\Map\RefSalesForceEtudeSectorTableMap;
use Model\Map\ReglementTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveRecord\ActiveRecordInterface;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\BadMethodCallException;
use Propel\Runtime\Exception\LogicException;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Parser\AbstractParser;
use Propel\Runtime\Util\PropelDateTime;

/**
 * Base class that represents a row from the 'etude' table.
 *
 *
 *
 * @package    propel.generator.src.Model.Base
 */
abstract class Etude implements ActiveRecordInterface
{
    /**
     * TableMap class name
     */
    const TABLE_MAP = '\\Model\\Map\\EtudeTableMap';


    /**
     * attribute to determine if this object has previously been saved.
     * @var boolean
     */
    protected $new = true;

    /**
     * attribute to determine whether this object has been deleted.
     * @var boolean
     */
    protected $deleted = false;

    /**
     * The columns that have been modified in current object.
     * Tracking modified columns allows us to only update modified columns.
     * @var array
     */
    protected $modifiedColumns = array();

    /**
     * The (virtual) columns that are added at runtime
     * The formatters can add supplementary columns based on a resultset
     * @var array
     */
    protected $virtualColumns = array();

    /**
     * The value for the id field.
     *
     * @var        int
     */
    protected $id;

    /**
     * The value for the numero_etude field.
     *
     * @var        string
     */
    protected $numero_etude;

    /**
     * The value for the reference_client field.
     *
     * @var        string
     */
    protected $reference_client;

    /**
     * The value for the master_project_sf_id field.
     *
     * @var        string|null
     */
    protected $master_project_sf_id;

    /**
     * The value for the theme field.
     *
     * @var        string|null
     */
    protected $theme;

    /**
     * The value for the date_debut field.
     *
     * @var        DateTime
     */
    protected $date_debut;

    /**
     * The value for the date_fin field.
     *
     * @var        DateTime
     */
    protected $date_fin;

    /**
     * The value for the annee field.
     *
     * @var        string
     */
    protected $annee;

    /**
     * The value for the rst field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $rst;

    /**
     * The value for the cli field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $cli;

    /**
     * The value for the gqs field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $gqs;

    /**
     * The value for the ins field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $ins;

    /**
     * The value for the hut field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $hut;

    /**
     * The value for the display_total_only field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $display_total_only;

    /**
     * The value for the id_pm field.
     *
     * @var        int|null
     */
    protected $id_pm;

    /**
     * The value for the id_etape field.
     *
     * @var        int|null
     */
    protected $id_etape;

    /**
     * The value for the prix_revient_initial field.
     *
     * @var        string
     */
    protected $prix_revient_initial;

    /**
     * The value for the prix_revient_actualise field.
     *
     * @var        string
     */
    protected $prix_revient_actualise;

    /**
     * The value for the prix_vente_initial field.
     *
     * @var        string
     */
    protected $prix_vente_initial;

    /**
     * The value for the prix_vente_actualise field.
     *
     * @var        string
     */
    protected $prix_vente_actualise;

    /**
     * The value for the consolidated_invoice field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $consolidated_invoice;

    /**
     * The value for the send_csat_quest field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $send_csat_quest;

    /**
     * The value for the is_send_csat_quest_mail field.
     *
     * Note: this column has a database default value of: true
     * @var        boolean
     */
    protected $is_send_csat_quest_mail;

    /**
     * The value for the numero_facture field.
     *
     * @var        string|null
     */
    protected $numero_facture;

    /**
     * The value for the dont_set_am_auto field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $dont_set_am_auto;

    /**
     * The value for the set_am_reason field.
     *
     * @var        string|null
     */
    protected $set_am_reason;

    /**
     * The value for the am_reason_type_id field.
     *
     * @var        int|null
     */
    protected $am_reason_type_id;

    /**
     * The value for the date_envoi_facture field.
     *
     * @var        DateTime|null
     */
    protected $date_envoi_facture;

    /**
     * The value for the date_reglement field.
     *
     * @var        DateTime|null
     */
    protected $date_reglement;

    /**
     * The value for the commentaire field.
     *
     * @var        string|null
     */
    protected $commentaire;

    /**
     * The value for the industry_id field.
     *
     * @var        int
     */
    protected $industry_id;

    /**
     * The value for the periode_cutoff field.
     *
     * @var        string
     */
    protected $periode_cutoff;

    /**
     * The value for the theme_br field.
     *
     * @var        string
     */
    protected $theme_br;

    /**
     * The value for the area_id field.
     *
     * @var        int|null
     */
    protected $area_id;

    /**
     * The value for the id_sams_study field.
     *
     * @var        string
     */
    protected $id_sams_study;

    /**
     * The value for the recrutement_objectif field.
     *
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $recrutement_objectif;

    /**
     * The value for the id_location_pnl field.
     *
     * @var        int|null
     */
    protected $id_location_pnl;

    /**
     * The value for the id_master_project_location_pnl field.
     *
     * @var        int|null
     */
    protected $id_master_project_location_pnl;

    /**
     * The value for the recrutement_objectif_pr field.
     *
     * @var        int
     */
    protected $recrutement_objectif_pr;

    /**
     * The value for the id_bm field.
     *
     * @var        int|null
     */
    protected $id_bm;

    /**
     * The value for the extra_info field.
     *
     * @var        string|null
     */
    protected $extra_info;

    /**
     * The value for the account_id field.
     *
     * @var        int|null
     */
    protected $account_id;

    /**
     * The value for the account_manager_id field.
     *
     * @var        int|null
     */
    protected $account_manager_id;

    /**
     * The value for the project_specialty_sponsor_id field.
     *
     * @var        int|null
     */
    protected $project_specialty_sponsor_id;

    /**
     * The value for the language field.
     *
     * @var        string|null
     */
    protected $language;

    /**
     * The value for the remise_taux field.
     *
     * @var        string|null
     */
    protected $remise_taux;

    /**
     * The value for the client_discount_percentage field.
     *
     * @var        string|null
     */
    protected $client_discount_percentage;

    /**
     * The value for the end_client_discount_percentage field.
     *
     * @var        string|null
     */
    protected $end_client_discount_percentage;

    /**
     * The value for the client_quant_discount_percentage field.
     *
     * @var        string|null
     */
    protected $client_quant_discount_percentage;

    /**
     * The value for the end_client_quant_discount_percentage field.
     *
     * @var        string|null
     */
    protected $end_client_quant_discount_percentage;

    /**
     * The value for the sample_plan field.
     *
     * @var        string|null
     */
    protected $sample_plan;

    /**
     * The value for the istoinvoice field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $istoinvoice;

    /**
     * The value for the file_path field.
     *
     * @var        string|null
     */
    protected $file_path;

    /**
     * The value for the account_leader_id field.
     *
     * @var        int|null
     */
    protected $account_leader_id;

    /**
     * The value for the account_pm_id field.
     *
     * @var        int|null
     */
    protected $account_pm_id;

    /**
     * The value for the am_email field.
     *
     * @var        string|null
     */
    protected $am_email;

    /**
     * The value for the client_portal_ready field.
     *
     * Note: this column has a database default value of: true
     * @var        boolean|null
     */
    protected $client_portal_ready;

    /**
     * The value for the length_of_interview field.
     *
     * @var        string|null
     */
    protected $length_of_interview;

    /**
     * The value for the sunshine_act field.
     *
     * @var        string|null
     */
    protected $sunshine_act;

    /**
     * The value for the is_consolidated field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $is_consolidated;

    /**
     * The value for the sharepoint_folder field.
     *
     * @var        string|null
     */
    protected $sharepoint_folder;

    /**
     * The value for the multi_phase field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $multi_phase;

    /**
     * The value for the po_number field.
     *
     * @var        string
     */
    protected $po_number;

    /**
     * The value for the currencies field.
     *
     * @var        string|null
     */
    protected $currencies;

    /**
     * The value for the sms_relance field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean
     */
    protected $sms_relance;

    /**
     * The value for the id_etude_group field.
     *
     * @var        int|null
     */
    protected $id_etude_group;

    /**
     * The value for the gms field.
     *
     * @var        string
     */
    protected $gms;

    /**
     * The value for the kol field.
     *
     * @var        string
     */
    protected $kol;

    /**
     * The value for the room_rental field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $room_rental;

    /**
     * The value for the recruits_offsite field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $recruits_offsite;

    /**
     * The value for the study_specification field.
     *
     * @var        string|null
     */
    protected $study_specification;

    /**
     * The value for the is_study_specification field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $is_study_specification;

    /**
     * The value for the additional_notes field.
     *
     * @var        string|null
     */
    protected $additional_notes;

    /**
     * The value for the project_comment field.
     *
     * @var        string|null
     */
    protected $project_comment;

    /**
     * The value for the end_client_id field.
     *
     * @var        int|null
     */
    protected $end_client_id;

    /**
     * The value for the end_client_contact_id field.
     *
     * @var        int|null
     */
    protected $end_client_contact_id;

    /**
     * The value for the contact_id field.
     *
     * @var        int|null
     */
    protected $contact_id;

    /**
     * The value for the contact_client_pm_id field.
     *
     * @var        int|null
     */
    protected $contact_client_pm_id;

    /**
     * The value for the master_project_number field.
     *
     * @var        string|null
     */
    protected $master_project_number;

    /**
     * The value for the proposed_loi field.
     *
     * Note: this column has a database default value of: 0.0
     * @var        double|null
     */
    protected $proposed_loi;

    /**
     * The value for the opportunity_id field.
     *
     * @var        int|null
     */
    protected $opportunity_id;

    /**
     * The value for the si_job_type_id field.
     *
     * @var        int|null
     */
    protected $si_job_type_id;

    /**
     * The value for the best_effort field.
     *
     * Note: this column has a database default value of: false
     * @var        boolean|null
     */
    protected $best_effort;

    /**
     * The value for the job_status_sf_id field.
     *
     * @var        int|null
     */
    protected $job_status_sf_id;

    /**
     * The value for the booked_by_sf_id field.
     *
     * @var        string|null
     */
    protected $booked_by_sf_id;

    /**
     * The value for the created_by_sf_id field.
     *
     * @var        string|null
     */
    protected $created_by_sf_id;

    /**
     * The value for the account_manager_sf_id field.
     *
     * @var        string|null
     */
    protected $account_manager_sf_id;

    /**
     * The value for the created_date field.
     *
     * @var        DateTime|null
     */
    protected $created_date;

    /**
     * The value for the job_qualification_id field.
     *
     * @var        int|null
     */
    protected $job_qualification_id;

    /**
     * The value for the proposed_n field.
     *
     * Note: this column has a database default value of: 0.0
     * @var        double|null
     */
    protected $proposed_n;

    /**
     * The value for the german_job_type_id field.
     *
     * @var        int|null
     */
    protected $german_job_type_id;

    /**
     * The value for the created_by_comment field.
     *
     * @var        string|null
     */
    protected $created_by_comment;

    /**
     * The value for the focus_vision field.
     *
     * @var        boolean|null
     */
    protected $focus_vision;

    /**
     * The value for the si_eu_job_type field.
     *
     * @var        int|null
     */
    protected $si_eu_job_type;

    /**
     * The value for the intermediate_client_id field.
     *
     * @var        int|null
     */
    protected $intermediate_client_id;

    /**
     * The value for the intermediate_client_contact_id field.
     *
     * @var        int|null
     */
    protected $intermediate_client_contact_id;

    /**
     * The value for the us_global_qual_gms_id field.
     *
     * @var        int|null
     */
    protected $us_global_qual_gms_id;

    /**
     * The value for the facilty_note field.
     *
     * @var        string|null
     */
    protected $facilty_note;

    /**
     * The value for the currency_iso_code_id field.
     *
     * @var        int|null
     */
    protected $currency_iso_code_id;

    /**
     * The value for the client_list_deletion_id field.
     *
     * @var        int|null
     */
    protected $client_list_deletion_id;

    /**
     * The value for the created_by_id field.
     *
     * @var        int|null
     */
    protected $created_by_id;

    /**
     * The value for the updated_by_id field.
     *
     * @var        int|null
     */
    protected $updated_by_id;

    /**
     * The value for the created_at field.
     *
     * @var        DateTime|null
     */
    protected $created_at;

    /**
     * The value for the updated_at field.
     *
     * @var        DateTime|null
     */
    protected $updated_at;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aUsGlobalQualGms;

    /**
     * @var        ChildUser
     */
    protected $aAccountLeader;

    /**
     * @var        ChildUser
     */
    protected $aAccountPM;

    /**
     * @var        ChildAccount
     */
    protected $aIntermediateClient;

    /**
     * @var        ChildEtape
     */
    protected $aEtape;

    /**
     * @var        ChildContact
     */
    protected $aContact;

    /**
     * @var        ChildOpportunity
     */
    protected $aOpportunity;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aJobStatusSf;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aJobQualification;

    /**
     * @var        ChildSiJobType
     */
    protected $aSiJobType;

    /**
     * @var        ChildContact
     */
    protected $aEndClientContact;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aGermanJobType;

    /**
     * @var        ChildAccount
     */
    protected $aEndClient;

    /**
     * @var        ChildAccount
     */
    protected $aAccount;

    /**
     * @var        ChildIndustry
     */
    protected $aIndustry;

    /**
     * @var        ChildLocation
     */
    protected $aEtudeLocation;

    /**
     * @var        ChildProjectLocationPrefix
     */
    protected $aProjectLocationPrefix;

    /**
     * @var        ChildContact
     */
    protected $aContactClientPm;

    /**
     * @var        ChildUser
     */
    protected $aBM;

    /**
     * @var        ChildUser
     */
    protected $aEtudeProjectManager;

    /**
     * @var        ChildEtudeGroup
     */
    protected $aEtudeGroup;

    /**
     * @var        ChildArea
     */
    protected $aEtudeArea;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aCurrencyIsoCode;

    /**
     * @var        ChildRefSalesForce
     */
    protected $aClientListDeletion;

    /**
     * @var        ChildUser
     */
    protected $aCreatedBy;

    /**
     * @var        ChildUser
     */
    protected $aUpdatedBy;

    /**
     * @var        ChildContact
     */
    protected $aIntermediateClientContact;

    /**
     * @var        ChildUser
     */
    protected $aProjectAccountManager;

    /**
     * @var        ChildUser
     */
    protected $aProjectSpecialtySponsor;

    /**
     * @var        ChildAmReasonType
     */
    protected $aAmReasonType;

    /**
     * @var        ObjectCollection|ChildDernierAcces[] Collection to store aggregation of ChildDernierAcces objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildDernierAcces> Collection to store aggregation of ChildDernierAcces objects.
     */
    protected $collDernierAccess;
    protected $collDernierAccessPartial;

    /**
     * @var        ObjectCollection|ChildEtudeSampleSource[] Collection to store aggregation of ChildEtudeSampleSource objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeSampleSource> Collection to store aggregation of ChildEtudeSampleSource objects.
     */
    protected $collEtudeSampleSources;
    protected $collEtudeSampleSourcesPartial;

    /**
     * @var        ObjectCollection|ChildEtudeMethodology[] Collection to store aggregation of ChildEtudeMethodology objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeMethodology> Collection to store aggregation of ChildEtudeMethodology objects.
     */
    protected $collEtudeMethodologies;
    protected $collEtudeMethodologiesPartial;

    /**
     * @var        ObjectCollection|ChildFacture[] Collection to store aggregation of ChildFacture objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildFacture> Collection to store aggregation of ChildFacture objects.
     */
    protected $collFactures;
    protected $collFacturesPartial;

    /**
     * @var        ObjectCollection|ChildJob[] Collection to store aggregation of ChildJob objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildJob> Collection to store aggregation of ChildJob objects.
     */
    protected $collJobEtudes;
    protected $collJobEtudesPartial;

    /**
     * @var        ObjectCollection|ChildReglement[] Collection to store aggregation of ChildReglement objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildReglement> Collection to store aggregation of ChildReglement objects.
     */
    protected $collReglements;
    protected $collReglementsPartial;

    /**
     * @var        ObjectCollection|ChildRefSalesForceEtudeSector[] Collection to store aggregation of ChildRefSalesForceEtudeSector objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildRefSalesForceEtudeSector> Collection to store aggregation of ChildRefSalesForceEtudeSector objects.
     */
    protected $collSectors;
    protected $collSectorsPartial;

    /**
     * @var        ObjectCollection|ChildEtudeCheckListValidation[] Collection to store aggregation of ChildEtudeCheckListValidation objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeCheckListValidation> Collection to store aggregation of ChildEtudeCheckListValidation objects.
     */
    protected $collEtudeCheckListValidations;
    protected $collEtudeCheckListValidationsPartial;

    /**
     * @var        ObjectCollection|ChildEtudeFichier[] Collection to store aggregation of ChildEtudeFichier objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeFichier> Collection to store aggregation of ChildEtudeFichier objects.
     */
    protected $collEtudeFichiers;
    protected $collEtudeFichiersPartial;

    /**
     * @var        ObjectCollection|ChildLogProjectStatus[] Collection to store aggregation of ChildLogProjectStatus objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildLogProjectStatus> Collection to store aggregation of ChildLogProjectStatus objects.
     */
    protected $collLogProjectStatuses;
    protected $collLogProjectStatusesPartial;

    /**
     * @var        ObjectCollection|ChildSampleSource[] Cross Collection to store aggregation of ChildSampleSource objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildSampleSource> Cross Collection to store aggregation of ChildSampleSource objects.
     */
    protected $collSampleSources;

    /**
     * @var bool
     */
    protected $collSampleSourcesPartial;

    /**
     * @var        ObjectCollection|ChildMethodology[] Cross Collection to store aggregation of ChildMethodology objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildMethodology> Cross Collection to store aggregation of ChildMethodology objects.
     */
    protected $collMethodologies;

    /**
     * @var bool
     */
    protected $collMethodologiesPartial;

    /**
     * @var        ObjectCollection|ChildRefSalesForce[] Cross Collection to store aggregation of ChildRefSalesForce objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildRefSalesForce> Cross Collection to store aggregation of ChildRefSalesForce objects.
     */
    protected $collRefSalesForceEtudeRefSectors;

    /**
     * @var bool
     */
    protected $collRefSalesForceEtudeRefSectorsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     *
     * @var boolean
     */
    protected $alreadyInSave = false;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildSampleSource[]
     * @phpstan-var ObjectCollection&\Traversable<ChildSampleSource>
     */
    protected $sampleSourcesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildMethodology[]
     * @phpstan-var ObjectCollection&\Traversable<ChildMethodology>
     */
    protected $methodologiesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildRefSalesForce[]
     * @phpstan-var ObjectCollection&\Traversable<ChildRefSalesForce>
     */
    protected $refSalesForceEtudeRefSectorsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildDernierAcces[]
     * @phpstan-var ObjectCollection&\Traversable<ChildDernierAcces>
     */
    protected $dernierAccessScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEtudeSampleSource[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeSampleSource>
     */
    protected $etudeSampleSourcesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEtudeMethodology[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeMethodology>
     */
    protected $etudeMethodologiesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildFacture[]
     * @phpstan-var ObjectCollection&\Traversable<ChildFacture>
     */
    protected $facturesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildJob[]
     * @phpstan-var ObjectCollection&\Traversable<ChildJob>
     */
    protected $jobEtudesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildReglement[]
     * @phpstan-var ObjectCollection&\Traversable<ChildReglement>
     */
    protected $reglementsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildRefSalesForceEtudeSector[]
     * @phpstan-var ObjectCollection&\Traversable<ChildRefSalesForceEtudeSector>
     */
    protected $sectorsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEtudeCheckListValidation[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeCheckListValidation>
     */
    protected $etudeCheckListValidationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEtudeFichier[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeFichier>
     */
    protected $etudeFichiersScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildLogProjectStatus[]
     * @phpstan-var ObjectCollection&\Traversable<ChildLogProjectStatus>
     */
    protected $logProjectStatusesScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see __construct()
     */
    public function applyDefaultValues()
    {
        $this->rst = false;
        $this->cli = false;
        $this->gqs = false;
        $this->ins = false;
        $this->hut = false;
        $this->display_total_only = false;
        $this->consolidated_invoice = false;
        $this->send_csat_quest = false;
        $this->is_send_csat_quest_mail = true;
        $this->dont_set_am_auto = false;
        $this->recrutement_objectif = 0;
        $this->istoinvoice = false;
        $this->client_portal_ready = true;
        $this->is_consolidated = false;
        $this->multi_phase = false;
        $this->sms_relance = false;
        $this->room_rental = false;
        $this->recruits_offsite = false;
        $this->is_study_specification = false;
        $this->proposed_loi = 0.0;
        $this->best_effort = false;
        $this->proposed_n = 0.0;
    }

    /**
     * Initializes internal state of Model\Base\Etude object.
     * @see applyDefaults()
     */
    public function __construct()
    {
        $this->applyDefaultValues();
    }

    /**
     * Returns whether the object has been modified.
     *
     * @return boolean True if the object has been modified.
     */
    public function isModified()
    {
        return !!$this->modifiedColumns;
    }

    /**
     * Has specified column been modified?
     *
     * @param  string  $col column fully qualified name (TableMap::TYPE_COLNAME), e.g. Book::AUTHOR_ID
     * @return boolean True if $col has been modified.
     */
    public function isColumnModified($col)
    {
        return $this->modifiedColumns && isset($this->modifiedColumns[$col]);
    }

    /**
     * Get the columns that have been modified in this object.
     * @return array A unique list of the modified column names for this object.
     */
    public function getModifiedColumns()
    {
        return $this->modifiedColumns ? array_keys($this->modifiedColumns) : [];
    }

    /**
     * Returns whether the object has ever been saved.  This will
     * be false, if the object was retrieved from storage or was created
     * and then saved.
     *
     * @return boolean true, if the object has never been persisted.
     */
    public function isNew()
    {
        return $this->new;
    }

    /**
     * Setter for the isNew attribute.  This method will be called
     * by Propel-generated children and objects.
     *
     * @param boolean $b the state of the object.
     */
    public function setNew($b)
    {
        $this->new = (boolean) $b;
    }

    /**
     * Whether this object has been deleted.
     * @return boolean The deleted state of this object.
     */
    public function isDeleted()
    {
        return $this->deleted;
    }

    /**
     * Specify whether this object has been deleted.
     * @param  boolean $b The deleted state of this object.
     * @return void
     */
    public function setDeleted($b)
    {
        $this->deleted = (boolean) $b;
    }

    /**
     * Sets the modified state for the object to be false.
     * @param  string $col If supplied, only the specified column is reset.
     * @return void
     */
    public function resetModified($col = null)
    {
        if (null !== $col) {
            unset($this->modifiedColumns[$col]);
        } else {
            $this->modifiedColumns = array();
        }
    }

    /**
     * Compares this with another <code>Etude</code> instance.  If
     * <code>obj</code> is an instance of <code>Etude</code>, delegates to
     * <code>equals(Etude)</code>.  Otherwise, returns <code>false</code>.
     *
     * @param  mixed   $obj The object to compare to.
     * @return boolean Whether equal to the object specified.
     */
    public function equals($obj)
    {
        if (!$obj instanceof static) {
            return false;
        }

        if ($this === $obj) {
            return true;
        }

        if (null === $this->getPrimaryKey() || null === $obj->getPrimaryKey()) {
            return false;
        }

        return $this->getPrimaryKey() === $obj->getPrimaryKey();
    }

    /**
     * Get the associative array of the virtual columns in this object
     *
     * @return array
     */
    public function getVirtualColumns()
    {
        return $this->virtualColumns;
    }

    /**
     * Checks the existence of a virtual column in this object
     *
     * @param  string  $name The virtual column name
     * @return boolean
     */
    public function hasVirtualColumn($name)
    {
        return array_key_exists($name, $this->virtualColumns);
    }

    /**
     * Get the value of a virtual column in this object
     *
     * @param  string $name The virtual column name
     * @return mixed
     *
     * @throws PropelException
     */
    public function getVirtualColumn($name)
    {
        if (!$this->hasVirtualColumn($name)) {
            throw new PropelException(sprintf('Cannot get value of inexistent virtual column %s.', $name));
        }

        return $this->virtualColumns[$name];
    }

    /**
     * Set the value of a virtual column in this object
     *
     * @param string $name  The virtual column name
     * @param mixed  $value The value to give to the virtual column
     *
     * @return $this The current object, for fluid interface
     */
    public function setVirtualColumn($name, $value)
    {
        $this->virtualColumns[$name] = $value;

        return $this;
    }

    /**
     * Logs a message using Propel::log().
     *
     * @param  string  $msg
     * @param  int     $priority One of the Propel::LOG_* logging levels
     * @return void
     */
    protected function log($msg, $priority = Propel::LOG_INFO)
    {
        Propel::log(get_class($this) . ': ' . $msg, $priority);
    }

    /**
     * Export the current object properties to a string, using a given parser format
     * <code>
     * $book = BookQuery::create()->findPk(9012);
     * echo $book->exportTo('JSON');
     *  => {"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * @param  mixed   $parser                 A AbstractParser instance, or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param  boolean $includeLazyLoadColumns (optional) Whether to include lazy load(ed) columns. Defaults to TRUE.
     * @param  string  $keyType                (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM. Defaults to TableMap::TYPE_PHPNAME.
     * @return string  The exported data
     */
    public function exportTo($parser, $includeLazyLoadColumns = true, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        return $parser->fromArray($this->toArray($keyType, $includeLazyLoadColumns, array(), true));
    }

    /**
     * Clean up internal collections prior to serializing
     * Avoids recursive loops that turn into segmentation faults when serializing
     */
    public function __sleep()
    {
        $this->clearAllReferences();

        $cls = new \ReflectionClass($this);
        $propertyNames = [];
        $serializableProperties = array_diff($cls->getProperties(), $cls->getProperties(\ReflectionProperty::IS_STATIC));

        foreach($serializableProperties as $property) {
            $propertyNames[] = $property->getName();
        }

        return $propertyNames;
    }

    /**
     * Get the [id] column value.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the [numero_etude] column value.
     *
     * @return string
     */
    public function getNumeroEtude()
    {
        return $this->numero_etude;
    }

    /**
     * Get the [reference_client] column value.
     *
     * @return string
     */
    public function getReferenceClient()
    {
        return $this->reference_client;
    }

    /**
     * Get the [master_project_sf_id] column value.
     *
     * @return string|null
     */
    public function getMasterProjectSfId()
    {
        return $this->master_project_sf_id;
    }

    /**
     * Get the [theme] column value.
     *
     * @return string|null
     */
    public function getTheme()
    {
        return $this->theme;
    }

    /**
     * Get the [optionally formatted] temporal [date_debut] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime : string)
     */
    public function getDateDebut($format = null)
    {
        if ($format === null) {
            return $this->date_debut;
        } else {
            return $this->date_debut instanceof \DateTimeInterface ? $this->date_debut->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [date_fin] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime : string)
     */
    public function getDateFin($format = null)
    {
        if ($format === null) {
            return $this->date_fin;
        } else {
            return $this->date_fin instanceof \DateTimeInterface ? $this->date_fin->format($format) : null;
        }
    }

    /**
     * Get the [annee] column value.
     *
     * @return string
     */
    public function getAnnee()
    {
        return $this->annee;
    }

    /**
     * Get the [rst] column value.
     *
     * @return boolean
     */
    public function getRst()
    {
        return $this->rst;
    }

    /**
     * Get the [rst] column value.
     *
     * @return boolean
     */
    public function isRst()
    {
        return $this->getRst();
    }

    /**
     * Get the [cli] column value.
     *
     * @return boolean
     */
    public function getCli()
    {
        return $this->cli;
    }

    /**
     * Get the [cli] column value.
     *
     * @return boolean
     */
    public function isCli()
    {
        return $this->getCli();
    }

    /**
     * Get the [gqs] column value.
     *
     * @return boolean
     */
    public function getGqs()
    {
        return $this->gqs;
    }

    /**
     * Get the [gqs] column value.
     *
     * @return boolean
     */
    public function isGqs()
    {
        return $this->getGqs();
    }

    /**
     * Get the [ins] column value.
     *
     * @return boolean
     */
    public function getIns()
    {
        return $this->ins;
    }

    /**
     * Get the [ins] column value.
     *
     * @return boolean
     */
    public function isIns()
    {
        return $this->getIns();
    }

    /**
     * Get the [hut] column value.
     *
     * @return boolean
     */
    public function getHut()
    {
        return $this->hut;
    }

    /**
     * Get the [hut] column value.
     *
     * @return boolean
     */
    public function isHut()
    {
        return $this->getHut();
    }

    /**
     * Get the [display_total_only] column value.
     *
     * @return boolean
     */
    public function getDisplayTotalOnly()
    {
        return $this->display_total_only;
    }

    /**
     * Get the [display_total_only] column value.
     *
     * @return boolean
     */
    public function isDisplayTotalOnly()
    {
        return $this->getDisplayTotalOnly();
    }

    /**
     * Get the [id_pm] column value.
     *
     * @return int|null
     */
    public function getIdPm()
    {
        return $this->id_pm;
    }

    /**
     * Get the [id_etape] column value.
     *
     * @return int|null
     */
    public function getIdEtape()
    {
        return $this->id_etape;
    }

    /**
     * Get the [prix_revient_initial] column value.
     *
     * @return string
     */
    public function getPrixRevientInitial()
    {
        return $this->prix_revient_initial;
    }

    /**
     * Get the [prix_revient_actualise] column value.
     *
     * @return string
     */
    public function getPrixRevientActualise()
    {
        return $this->prix_revient_actualise;
    }

    /**
     * Get the [prix_vente_initial] column value.
     *
     * @return string
     */
    public function getPrixVenteInitial()
    {
        return $this->prix_vente_initial;
    }

    /**
     * Get the [prix_vente_actualise] column value.
     *
     * @return string
     */
    public function getPrixVenteActualise()
    {
        return $this->prix_vente_actualise;
    }

    /**
     * Get the [consolidated_invoice] column value.
     *
     * @return boolean
     */
    public function getConsolidatedInvoice()
    {
        return $this->consolidated_invoice;
    }

    /**
     * Get the [consolidated_invoice] column value.
     *
     * @return boolean
     */
    public function isConsolidatedInvoice()
    {
        return $this->getConsolidatedInvoice();
    }

    /**
     * Get the [send_csat_quest] column value.
     *
     * @return boolean|null
     */
    public function getSendCsatQuest()
    {
        return $this->send_csat_quest;
    }

    /**
     * Get the [send_csat_quest] column value.
     *
     * @return boolean|null
     */
    public function isSendCsatQuest()
    {
        return $this->getSendCsatQuest();
    }

    /**
     * Get the [is_send_csat_quest_mail] column value.
     *
     * @return boolean
     */
    public function getIsSendCsatQuestMail()
    {
        return $this->is_send_csat_quest_mail;
    }

    /**
     * Get the [is_send_csat_quest_mail] column value.
     *
     * @return boolean
     */
    public function isSendCsatQuestMail()
    {
        return $this->getIsSendCsatQuestMail();
    }

    /**
     * Get the [numero_facture] column value.
     *
     * @return string|null
     */
    public function getNumeroFacture()
    {
        return $this->numero_facture;
    }

    /**
     * Get the [dont_set_am_auto] column value.
     *
     * @return boolean
     */
    public function getDontSetAmAuto()
    {
        return $this->dont_set_am_auto;
    }

    /**
     * Get the [dont_set_am_auto] column value.
     *
     * @return boolean
     */
    public function isDontSetAmAuto()
    {
        return $this->getDontSetAmAuto();
    }

    /**
     * Get the [set_am_reason] column value.
     *
     * @return string|null
     */
    public function getSetAmReason()
    {
        return $this->set_am_reason;
    }

    /**
     * Get the [am_reason_type_id] column value.
     *
     * @return int|null
     */
    public function getAmReasonTypeId()
    {
        return $this->am_reason_type_id;
    }

    /**
     * Get the [optionally formatted] temporal [date_envoi_facture] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getDateEnvoiFacture($format = null)
    {
        if ($format === null) {
            return $this->date_envoi_facture;
        } else {
            return $this->date_envoi_facture instanceof \DateTimeInterface ? $this->date_envoi_facture->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [date_reglement] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getDateReglement($format = null)
    {
        if ($format === null) {
            return $this->date_reglement;
        } else {
            return $this->date_reglement instanceof \DateTimeInterface ? $this->date_reglement->format($format) : null;
        }
    }

    /**
     * Get the [commentaire] column value.
     *
     * @return string|null
     */
    public function getCommentaire()
    {
        return $this->commentaire;
    }

    /**
     * Get the [industry_id] column value.
     *
     * @return int
     */
    public function getIndustryId()
    {
        return $this->industry_id;
    }

    /**
     * Get the [periode_cutoff] column value.
     *
     * @return string
     */
    public function getPeriodeCutoff()
    {
        return $this->periode_cutoff;
    }

    /**
     * Get the [theme_br] column value.
     *
     * @return string
     */
    public function getThemeBr()
    {
        return $this->theme_br;
    }

    /**
     * Get the [area_id] column value.
     *
     * @return int|null
     */
    public function getAreaId()
    {
        return $this->area_id;
    }

    /**
     * Get the [id_sams_study] column value.
     *
     * @return string
     */
    public function getIdSamsStudy()
    {
        return $this->id_sams_study;
    }

    /**
     * Get the [recrutement_objectif] column value.
     *
     * @return int
     */
    public function getRecrutementObjectif()
    {
        return $this->recrutement_objectif;
    }

    /**
     * Get the [id_location_pnl] column value.
     *
     * @return int|null
     */
    public function getIdLocationPnl()
    {
        return $this->id_location_pnl;
    }

    /**
     * Get the [id_master_project_location_pnl] column value.
     *
     * @return int|null
     */
    public function getIdMasterProjectLocationPnl()
    {
        return $this->id_master_project_location_pnl;
    }

    /**
     * Get the [recrutement_objectif_pr] column value.
     *
     * @return int
     */
    public function getRecrutementObjectifPr()
    {
        return $this->recrutement_objectif_pr;
    }

    /**
     * Get the [id_bm] column value.
     *
     * @return int|null
     */
    public function getIdBm()
    {
        return $this->id_bm;
    }

    /**
     * Get the [extra_info] column value.
     *
     * @return string|null
     */
    public function getExtraInfo()
    {
        return $this->extra_info;
    }

    /**
     * Get the [account_id] column value.
     *
     * @return int|null
     */
    public function getAccountId()
    {
        return $this->account_id;
    }

    /**
     * Get the [account_manager_id] column value.
     *
     * @return int|null
     */
    public function getAccountManagerId()
    {
        return $this->account_manager_id;
    }

    /**
     * Get the [project_specialty_sponsor_id] column value.
     *
     * @return int|null
     */
    public function getProjectSpecialtySponsorId()
    {
        return $this->project_specialty_sponsor_id;
    }

    /**
     * Get the [language] column value.
     *
     * @return string|null
     */
    public function getLanguage()
    {
        return $this->language;
    }

    /**
     * Get the [remise_taux] column value.
     *
     * @return string|null
     */
    public function getRemiseTaux()
    {
        return $this->remise_taux;
    }

    /**
     * Get the [client_discount_percentage] column value.
     *
     * @return string|null
     */
    public function getClientDiscountPercentage()
    {
        return $this->client_discount_percentage;
    }

    /**
     * Get the [end_client_discount_percentage] column value.
     *
     * @return string|null
     */
    public function getEndClientDiscountPercentage()
    {
        return $this->end_client_discount_percentage;
    }

    /**
     * Get the [client_quant_discount_percentage] column value.
     *
     * @return string|null
     */
    public function getClientQuantDiscountPercentage()
    {
        return $this->client_quant_discount_percentage;
    }

    /**
     * Get the [end_client_quant_discount_percentage] column value.
     *
     * @return string|null
     */
    public function getEndClientQuantDiscountPercentage()
    {
        return $this->end_client_quant_discount_percentage;
    }

    /**
     * Get the [sample_plan] column value.
     *
     * @return string|null
     */
    public function getSamplePlan()
    {
        return $this->sample_plan;
    }

    /**
     * Get the [istoinvoice] column value.
     *
     * @return boolean|null
     */
    public function getIsToInvoice()
    {
        return $this->istoinvoice;
    }

    /**
     * Get the [istoinvoice] column value.
     *
     * @return boolean|null
     */
    public function isToInvoice()
    {
        return $this->getIsToInvoice();
    }

    /**
     * Get the [file_path] column value.
     *
     * @return string|null
     */
    public function getFilePath()
    {
        return $this->file_path;
    }

    /**
     * Get the [account_leader_id] column value.
     *
     * @return int|null
     */
    public function getAccountLeaderId()
    {
        return $this->account_leader_id;
    }

    /**
     * Get the [account_pm_id] column value.
     *
     * @return int|null
     */
    public function getAccountPMId()
    {
        return $this->account_pm_id;
    }

    /**
     * Get the [am_email] column value.
     *
     * @return string|null
     */
    public function getAmEmail()
    {
        return $this->am_email;
    }

    /**
     * Get the [client_portal_ready] column value.
     *
     * @return boolean|null
     */
    public function getClientPortalReady()
    {
        return $this->client_portal_ready;
    }

    /**
     * Get the [client_portal_ready] column value.
     *
     * @return boolean|null
     */
    public function isClientPortalReady()
    {
        return $this->getClientPortalReady();
    }

    /**
     * Get the [length_of_interview] column value.
     *
     * @return string|null
     */
    public function getLengthOfInterview()
    {
        return $this->length_of_interview;
    }

    /**
     * Get the [sunshine_act] column value.
     *
     * @return string|null
     */
    public function getsunshineAct()
    {
        return $this->sunshine_act;
    }

    /**
     * Get the [is_consolidated] column value.
     *
     * @return boolean|null
     */
    public function getIsConsolidated()
    {
        return $this->is_consolidated;
    }

    /**
     * Get the [is_consolidated] column value.
     *
     * @return boolean|null
     */
    public function isConsolidated()
    {
        return $this->getIsConsolidated();
    }

    /**
     * Get the [sharepoint_folder] column value.
     *
     * @return string|null
     */
    public function getSharepointFolder()
    {
        return $this->sharepoint_folder;
    }

    /**
     * Get the [multi_phase] column value.
     *
     * @return boolean
     */
    public function getMultiPhase()
    {
        return $this->multi_phase;
    }

    /**
     * Get the [multi_phase] column value.
     *
     * @return boolean
     */
    public function isMultiPhase()
    {
        return $this->getMultiPhase();
    }

    /**
     * Get the [po_number] column value.
     *
     * @return string
     */
    public function getPoNumber()
    {
        return $this->po_number;
    }

    /**
     * Get the [currencies] column value.
     *
     * @return string|null
     */
    public function getCurrencies()
    {
        return $this->currencies;
    }

    /**
     * Get the [sms_relance] column value.
     *
     * @return boolean
     */
    public function getSmsRelance()
    {
        return $this->sms_relance;
    }

    /**
     * Get the [sms_relance] column value.
     *
     * @return boolean
     */
    public function isSmsRelance()
    {
        return $this->getSmsRelance();
    }

    /**
     * Get the [id_etude_group] column value.
     *
     * @return int|null
     */
    public function getIdEtudeGroup()
    {
        return $this->id_etude_group;
    }

    /**
     * Get the [gms] column value.
     *
     * @return string
     */
    public function getGms()
    {
        return $this->gms;
    }

    /**
     * Get the [kol] column value.
     *
     * @return string
     */
    public function getKol()
    {
        return $this->kol;
    }

    /**
     * Get the [room_rental] column value.
     *
     * @return boolean|null
     */
    public function getRoomRental()
    {
        return $this->room_rental;
    }

    /**
     * Get the [room_rental] column value.
     *
     * @return boolean|null
     */
    public function isRoomRental()
    {
        return $this->getRoomRental();
    }

    /**
     * Get the [recruits_offsite] column value.
     *
     * @return boolean|null
     */
    public function getRecruitsOffsite()
    {
        return $this->recruits_offsite;
    }

    /**
     * Get the [recruits_offsite] column value.
     *
     * @return boolean|null
     */
    public function isRecruitsOffsite()
    {
        return $this->getRecruitsOffsite();
    }

    /**
     * Get the [study_specification] column value.
     *
     * @return string|null
     */
    public function getStudySpecification()
    {
        return $this->study_specification;
    }

    /**
     * Get the [is_study_specification] column value.
     *
     * @return boolean|null
     */
    public function getisStudySpecification()
    {
        return $this->is_study_specification;
    }

    /**
     * Get the [is_study_specification] column value.
     *
     * @return boolean|null
     */
    public function isStudySpecification()
    {
        return $this->getisStudySpecification();
    }

    /**
     * Get the [additional_notes] column value.
     *
     * @return string|null
     */
    public function getAdditionalNotes()
    {
        return $this->additional_notes;
    }

    /**
     * Get the [project_comment] column value.
     *
     * @return string|null
     */
    public function getProjectComment()
    {
        return $this->project_comment;
    }

    /**
     * Get the [end_client_id] column value.
     *
     * @return int|null
     */
    public function getEndClientId()
    {
        return $this->end_client_id;
    }

    /**
     * Get the [end_client_contact_id] column value.
     *
     * @return int|null
     */
    public function getEndClientContactId()
    {
        return $this->end_client_contact_id;
    }

    /**
     * Get the [contact_id] column value.
     *
     * @return int|null
     */
    public function getContactId()
    {
        return $this->contact_id;
    }

    /**
     * Get the [contact_client_pm_id] column value.
     *
     * @return int|null
     */
    public function getContactClientPmId()
    {
        return $this->contact_client_pm_id;
    }

    /**
     * Get the [master_project_number] column value.
     *
     * @return string|null
     */
    public function getMasterProjectNumber()
    {
        return $this->master_project_number;
    }

    /**
     * Get the [proposed_loi] column value.
     *
     * @return double|null
     */
    public function getProposedLoi()
    {
        return $this->proposed_loi;
    }

    /**
     * Get the [opportunity_id] column value.
     *
     * @return int|null
     */
    public function getOpportunityId()
    {
        return $this->opportunity_id;
    }

    /**
     * Get the [si_job_type_id] column value.
     *
     * @return int|null
     */
    public function getSiJobTypeId()
    {
        return $this->si_job_type_id;
    }

    /**
     * Get the [best_effort] column value.
     *
     * @return boolean|null
     */
    public function getBestEffort()
    {
        return $this->best_effort;
    }

    /**
     * Get the [best_effort] column value.
     *
     * @return boolean|null
     */
    public function isBestEffort()
    {
        return $this->getBestEffort();
    }

    /**
     * Get the [job_status_sf_id] column value.
     *
     * @return int|null
     */
    public function getJobStatusSfId()
    {
        return $this->job_status_sf_id;
    }

    /**
     * Get the [booked_by_sf_id] column value.
     *
     * @return string|null
     */
    public function getBookedBySfId()
    {
        return $this->booked_by_sf_id;
    }

    /**
     * Get the [created_by_sf_id] column value.
     *
     * @return string|null
     */
    public function getCreatedBySfId()
    {
        return $this->created_by_sf_id;
    }

    /**
     * Get the [account_manager_sf_id] column value.
     *
     * @return string|null
     */
    public function getAccountManagerSfId()
    {
        return $this->account_manager_sf_id;
    }

    /**
     * Get the [optionally formatted] temporal [created_date] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getCreatedDate($format = null)
    {
        if ($format === null) {
            return $this->created_date;
        } else {
            return $this->created_date instanceof \DateTimeInterface ? $this->created_date->format($format) : null;
        }
    }

    /**
     * Get the [job_qualification_id] column value.
     *
     * @return int|null
     */
    public function getJobQualificationId()
    {
        return $this->job_qualification_id;
    }

    /**
     * Get the [proposed_n] column value.
     *
     * @return double|null
     */
    public function getProposedN()
    {
        return $this->proposed_n;
    }

    /**
     * Get the [german_job_type_id] column value.
     *
     * @return int|null
     */
    public function getGermanJobTypeId()
    {
        return $this->german_job_type_id;
    }

    /**
     * Get the [created_by_comment] column value.
     *
     * @return string|null
     */
    public function getCreatedByComment()
    {
        return $this->created_by_comment;
    }

    /**
     * Get the [focus_vision] column value.
     *
     * @return boolean|null
     */
    public function getFocusVision()
    {
        return $this->focus_vision;
    }

    /**
     * Get the [focus_vision] column value.
     *
     * @return boolean|null
     */
    public function isFocusVision()
    {
        return $this->getFocusVision();
    }

    /**
     * Get the [si_eu_job_type] column value.
     *
     * @return string|null
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function getSiEuJobType()
    {
        if (null === $this->si_eu_job_type) {
            return null;
        }
        $valueSet = EtudeTableMap::getValueSet(EtudeTableMap::COL_SI_EU_JOB_TYPE);
        if (!isset($valueSet[$this->si_eu_job_type])) {
            throw new PropelException('Unknown stored enum key: ' . $this->si_eu_job_type);
        }

        return $valueSet[$this->si_eu_job_type];
    }

    /**
     * Get the [intermediate_client_id] column value.
     *
     * @return int|null
     */
    public function getIntermediateClientId()
    {
        return $this->intermediate_client_id;
    }

    /**
     * Get the [intermediate_client_contact_id] column value.
     *
     * @return int|null
     */
    public function getIntermediateClientContactId()
    {
        return $this->intermediate_client_contact_id;
    }

    /**
     * Get the [us_global_qual_gms_id] column value.
     *
     * @return int|null
     */
    public function getUsGlobalQualGmsId()
    {
        return $this->us_global_qual_gms_id;
    }

    /**
     * Get the [facilty_note] column value.
     *
     * @return string|null
     */
    public function getFaciltyNote()
    {
        return $this->facilty_note;
    }

    /**
     * Get the [currency_iso_code_id] column value.
     *
     * @return int|null
     */
    public function getCurrencyIsoCodeId()
    {
        return $this->currency_iso_code_id;
    }

    /**
     * Get the [client_list_deletion_id] column value.
     *
     * @return int|null
     */
    public function getClientListDeletionId()
    {
        return $this->client_list_deletion_id;
    }

    /**
     * Get the [created_by_id] column value.
     *
     * @return int|null
     */
    public function getCreatedById()
    {
        return $this->created_by_id;
    }

    /**
     * Get the [updated_by_id] column value.
     *
     * @return int|null
     */
    public function getUpdatedById()
    {
        return $this->updated_by_id;
    }

    /**
     * Get the [optionally formatted] temporal [created_at] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getCreatedAt($format = null)
    {
        if ($format === null) {
            return $this->created_at;
        } else {
            return $this->created_at instanceof \DateTimeInterface ? $this->created_at->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [updated_at] column value.
     *
     *
     * @param string|null $format The date/time format string (either date()-style or strftime()-style).
     *   If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime|null Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     *
     * @psalm-return ($format is null ? DateTime|null : string|null)
     */
    public function getUpdatedAt($format = null)
    {
        if ($format === null) {
            return $this->updated_at;
        } else {
            return $this->updated_at instanceof \DateTimeInterface ? $this->updated_at->format($format) : null;
        }
    }

    /**
     * Set the value of [id] column.
     *
     * @param int $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id !== $v) {
            $this->id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID] = true;
        }

        return $this;
    } // setId()

    /**
     * Set the value of [numero_etude] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setNumeroEtude($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->numero_etude !== $v) {
            $this->numero_etude = $v;
            $this->modifiedColumns[EtudeTableMap::COL_NUMERO_ETUDE] = true;
        }

        return $this;
    } // setNumeroEtude()

    /**
     * Set the value of [reference_client] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setReferenceClient($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->reference_client !== $v) {
            $this->reference_client = $v;
            $this->modifiedColumns[EtudeTableMap::COL_REFERENCE_CLIENT] = true;
        }

        return $this;
    } // setReferenceClient()

    /**
     * Set the value of [master_project_sf_id] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setMasterProjectSfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->master_project_sf_id !== $v) {
            $this->master_project_sf_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_MASTER_PROJECT_SF_ID] = true;
        }

        return $this;
    } // setMasterProjectSfId()

    /**
     * Set the value of [theme] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setTheme($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->theme !== $v) {
            $this->theme = $v;
            $this->modifiedColumns[EtudeTableMap::COL_THEME] = true;
        }

        return $this;
    } // setTheme()

    /**
     * Sets the value of [date_debut] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDateDebut($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_debut !== null || $dt !== null) {
            if ($this->date_debut === null || $dt === null || $dt->format("Y-m-d") !== $this->date_debut->format("Y-m-d")) {
                $this->date_debut = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_DATE_DEBUT] = true;
            }
        } // if either are not null

        return $this;
    } // setDateDebut()

    /**
     * Sets the value of [date_fin] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDateFin($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_fin !== null || $dt !== null) {
            if ($this->date_fin === null || $dt === null || $dt->format("Y-m-d") !== $this->date_fin->format("Y-m-d")) {
                $this->date_fin = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_DATE_FIN] = true;
            }
        } // if either are not null

        return $this;
    } // setDateFin()

    /**
     * Set the value of [annee] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAnnee($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->annee !== $v) {
            $this->annee = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ANNEE] = true;
        }

        return $this;
    } // setAnnee()

    /**
     * Sets the value of the [rst] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRst($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->rst !== $v) {
            $this->rst = $v;
            $this->modifiedColumns[EtudeTableMap::COL_RST] = true;
        }

        return $this;
    } // setRst()

    /**
     * Sets the value of the [cli] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCli($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->cli !== $v) {
            $this->cli = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CLI] = true;
        }

        return $this;
    } // setCli()

    /**
     * Sets the value of the [gqs] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setGqs($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->gqs !== $v) {
            $this->gqs = $v;
            $this->modifiedColumns[EtudeTableMap::COL_GQS] = true;
        }

        return $this;
    } // setGqs()

    /**
     * Sets the value of the [ins] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIns($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->ins !== $v) {
            $this->ins = $v;
            $this->modifiedColumns[EtudeTableMap::COL_INS] = true;
        }

        return $this;
    } // setIns()

    /**
     * Sets the value of the [hut] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setHut($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->hut !== $v) {
            $this->hut = $v;
            $this->modifiedColumns[EtudeTableMap::COL_HUT] = true;
        }

        return $this;
    } // setHut()

    /**
     * Sets the value of the [display_total_only] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDisplayTotalOnly($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->display_total_only !== $v) {
            $this->display_total_only = $v;
            $this->modifiedColumns[EtudeTableMap::COL_DISPLAY_TOTAL_ONLY] = true;
        }

        return $this;
    } // setDisplayTotalOnly()

    /**
     * Set the value of [id_pm] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdPm($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_pm !== $v) {
            $this->id_pm = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_PM] = true;
        }

        if ($this->aEtudeProjectManager !== null && $this->aEtudeProjectManager->getId() !== $v) {
            $this->aEtudeProjectManager = null;
        }

        return $this;
    } // setIdPm()

    /**
     * Set the value of [id_etape] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdEtape($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_etape !== $v) {
            $this->id_etape = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_ETAPE] = true;
        }

        if ($this->aEtape !== null && $this->aEtape->getId() !== $v) {
            $this->aEtape = null;
        }

        return $this;
    } // setIdEtape()

    /**
     * Set the value of [prix_revient_initial] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPrixRevientInitial($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->prix_revient_initial !== $v) {
            $this->prix_revient_initial = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PRIX_REVIENT_INITIAL] = true;
        }

        return $this;
    } // setPrixRevientInitial()

    /**
     * Set the value of [prix_revient_actualise] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPrixRevientActualise($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->prix_revient_actualise !== $v) {
            $this->prix_revient_actualise = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE] = true;
        }

        return $this;
    } // setPrixRevientActualise()

    /**
     * Set the value of [prix_vente_initial] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPrixVenteInitial($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->prix_vente_initial !== $v) {
            $this->prix_vente_initial = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PRIX_VENTE_INITIAL] = true;
        }

        return $this;
    } // setPrixVenteInitial()

    /**
     * Set the value of [prix_vente_actualise] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPrixVenteActualise($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->prix_vente_actualise !== $v) {
            $this->prix_vente_actualise = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PRIX_VENTE_ACTUALISE] = true;
        }

        return $this;
    } // setPrixVenteActualise()

    /**
     * Sets the value of the [consolidated_invoice] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setConsolidatedInvoice($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->consolidated_invoice !== $v) {
            $this->consolidated_invoice = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CONSOLIDATED_INVOICE] = true;
        }

        return $this;
    } // setConsolidatedInvoice()

    /**
     * Sets the value of the [send_csat_quest] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSendCsatQuest($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->send_csat_quest !== $v) {
            $this->send_csat_quest = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SEND_CSAT_QUEST] = true;
        }

        return $this;
    } // setSendCsatQuest()

    /**
     * Sets the value of the [is_send_csat_quest_mail] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIsSendCsatQuestMail($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_send_csat_quest_mail !== $v) {
            $this->is_send_csat_quest_mail = $v;
            $this->modifiedColumns[EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL] = true;
        }

        return $this;
    } // setIsSendCsatQuestMail()

    /**
     * Set the value of [numero_facture] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setNumeroFacture($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->numero_facture !== $v) {
            $this->numero_facture = $v;
            $this->modifiedColumns[EtudeTableMap::COL_NUMERO_FACTURE] = true;
        }

        return $this;
    } // setNumeroFacture()

    /**
     * Sets the value of the [dont_set_am_auto] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDontSetAmAuto($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->dont_set_am_auto !== $v) {
            $this->dont_set_am_auto = $v;
            $this->modifiedColumns[EtudeTableMap::COL_DONT_SET_AM_AUTO] = true;
        }

        return $this;
    } // setDontSetAmAuto()

    /**
     * Set the value of [set_am_reason] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSetAmReason($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->set_am_reason !== $v) {
            $this->set_am_reason = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SET_AM_REASON] = true;
        }

        return $this;
    } // setSetAmReason()

    /**
     * Set the value of [am_reason_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAmReasonTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->am_reason_type_id !== $v) {
            $this->am_reason_type_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_AM_REASON_TYPE_ID] = true;
        }

        if ($this->aAmReasonType !== null && $this->aAmReasonType->getId() !== $v) {
            $this->aAmReasonType = null;
        }

        return $this;
    } // setAmReasonTypeId()

    /**
     * Sets the value of [date_envoi_facture] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDateEnvoiFacture($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_envoi_facture !== null || $dt !== null) {
            if ($this->date_envoi_facture === null || $dt === null || $dt->format("Y-m-d") !== $this->date_envoi_facture->format("Y-m-d")) {
                $this->date_envoi_facture = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_DATE_ENVOI_FACTURE] = true;
            }
        } // if either are not null

        return $this;
    } // setDateEnvoiFacture()

    /**
     * Sets the value of [date_reglement] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setDateReglement($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_reglement !== null || $dt !== null) {
            if ($this->date_reglement === null || $dt === null || $dt->format("Y-m-d") !== $this->date_reglement->format("Y-m-d")) {
                $this->date_reglement = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_DATE_REGLEMENT] = true;
            }
        } // if either are not null

        return $this;
    } // setDateReglement()

    /**
     * Set the value of [commentaire] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCommentaire($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->commentaire !== $v) {
            $this->commentaire = $v;
            $this->modifiedColumns[EtudeTableMap::COL_COMMENTAIRE] = true;
        }

        return $this;
    } // setCommentaire()

    /**
     * Set the value of [industry_id] column.
     *
     * @param int $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIndustryId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->industry_id !== $v) {
            $this->industry_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_INDUSTRY_ID] = true;
        }

        if ($this->aIndustry !== null && $this->aIndustry->getId() !== $v) {
            $this->aIndustry = null;
        }

        return $this;
    } // setIndustryId()

    /**
     * Set the value of [periode_cutoff] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPeriodeCutoff($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->periode_cutoff !== $v) {
            $this->periode_cutoff = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PERIODE_CUTOFF] = true;
        }

        return $this;
    } // setPeriodeCutoff()

    /**
     * Set the value of [theme_br] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setThemeBr($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->theme_br !== $v) {
            $this->theme_br = $v;
            $this->modifiedColumns[EtudeTableMap::COL_THEME_BR] = true;
        }

        return $this;
    } // setThemeBr()

    /**
     * Set the value of [area_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAreaId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->area_id !== $v) {
            $this->area_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_AREA_ID] = true;
        }

        if ($this->aEtudeArea !== null && $this->aEtudeArea->getId() !== $v) {
            $this->aEtudeArea = null;
        }

        return $this;
    } // setAreaId()

    /**
     * Set the value of [id_sams_study] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdSamsStudy($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->id_sams_study !== $v) {
            $this->id_sams_study = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_SAMS_STUDY] = true;
        }

        return $this;
    } // setIdSamsStudy()

    /**
     * Set the value of [recrutement_objectif] column.
     *
     * @param int $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRecrutementObjectif($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->recrutement_objectif !== $v) {
            $this->recrutement_objectif = $v;
            $this->modifiedColumns[EtudeTableMap::COL_RECRUTEMENT_OBJECTIF] = true;
        }

        return $this;
    } // setRecrutementObjectif()

    /**
     * Set the value of [id_location_pnl] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdLocationPnl($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_location_pnl !== $v) {
            $this->id_location_pnl = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_LOCATION_PNL] = true;
        }

        if ($this->aEtudeLocation !== null && $this->aEtudeLocation->getId() !== $v) {
            $this->aEtudeLocation = null;
        }

        return $this;
    } // setIdLocationPnl()

    /**
     * Set the value of [id_master_project_location_pnl] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdMasterProjectLocationPnl($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_master_project_location_pnl !== $v) {
            $this->id_master_project_location_pnl = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL] = true;
        }

        if ($this->aProjectLocationPrefix !== null && $this->aProjectLocationPrefix->getId() !== $v) {
            $this->aProjectLocationPrefix = null;
        }

        return $this;
    } // setIdMasterProjectLocationPnl()

    /**
     * Set the value of [recrutement_objectif_pr] column.
     *
     * @param int $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRecrutementObjectifPr($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->recrutement_objectif_pr !== $v) {
            $this->recrutement_objectif_pr = $v;
            $this->modifiedColumns[EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR] = true;
        }

        return $this;
    } // setRecrutementObjectifPr()

    /**
     * Set the value of [id_bm] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdBm($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_bm !== $v) {
            $this->id_bm = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_BM] = true;
        }

        if ($this->aBM !== null && $this->aBM->getId() !== $v) {
            $this->aBM = null;
        }

        return $this;
    } // setIdBm()

    /**
     * Set the value of [extra_info] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setExtraInfo($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->extra_info !== $v) {
            $this->extra_info = $v;
            $this->modifiedColumns[EtudeTableMap::COL_EXTRA_INFO] = true;
        }

        return $this;
    } // setExtraInfo()

    /**
     * Set the value of [account_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAccountId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->account_id !== $v) {
            $this->account_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ACCOUNT_ID] = true;
        }

        if ($this->aAccount !== null && $this->aAccount->getId() !== $v) {
            $this->aAccount = null;
        }

        return $this;
    } // setAccountId()

    /**
     * Set the value of [account_manager_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAccountManagerId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->account_manager_id !== $v) {
            $this->account_manager_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ACCOUNT_MANAGER_ID] = true;
        }

        if ($this->aProjectAccountManager !== null && $this->aProjectAccountManager->getId() !== $v) {
            $this->aProjectAccountManager = null;
        }

        return $this;
    } // setAccountManagerId()

    /**
     * Set the value of [project_specialty_sponsor_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setProjectSpecialtySponsorId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->project_specialty_sponsor_id !== $v) {
            $this->project_specialty_sponsor_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID] = true;
        }

        if ($this->aProjectSpecialtySponsor !== null && $this->aProjectSpecialtySponsor->getId() !== $v) {
            $this->aProjectSpecialtySponsor = null;
        }

        return $this;
    } // setProjectSpecialtySponsorId()

    /**
     * Set the value of [language] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setLanguage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->language !== $v) {
            $this->language = $v;
            $this->modifiedColumns[EtudeTableMap::COL_LANGUAGE] = true;
        }

        return $this;
    } // setLanguage()

    /**
     * Set the value of [remise_taux] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRemiseTaux($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->remise_taux !== $v) {
            $this->remise_taux = $v;
            $this->modifiedColumns[EtudeTableMap::COL_REMISE_TAUX] = true;
        }

        return $this;
    } // setRemiseTaux()

    /**
     * Set the value of [client_discount_percentage] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setClientDiscountPercentage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->client_discount_percentage !== $v) {
            $this->client_discount_percentage = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE] = true;
        }

        return $this;
    } // setClientDiscountPercentage()

    /**
     * Set the value of [end_client_discount_percentage] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setEndClientDiscountPercentage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->end_client_discount_percentage !== $v) {
            $this->end_client_discount_percentage = $v;
            $this->modifiedColumns[EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE] = true;
        }

        return $this;
    } // setEndClientDiscountPercentage()

    /**
     * Set the value of [client_quant_discount_percentage] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setClientQuantDiscountPercentage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->client_quant_discount_percentage !== $v) {
            $this->client_quant_discount_percentage = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE] = true;
        }

        return $this;
    } // setClientQuantDiscountPercentage()

    /**
     * Set the value of [end_client_quant_discount_percentage] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setEndClientQuantDiscountPercentage($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->end_client_quant_discount_percentage !== $v) {
            $this->end_client_quant_discount_percentage = $v;
            $this->modifiedColumns[EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE] = true;
        }

        return $this;
    } // setEndClientQuantDiscountPercentage()

    /**
     * Set the value of [sample_plan] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSamplePlan($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sample_plan !== $v) {
            $this->sample_plan = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SAMPLE_PLAN] = true;
        }

        return $this;
    } // setSamplePlan()

    /**
     * Sets the value of the [istoinvoice] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIsToInvoice($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->istoinvoice !== $v) {
            $this->istoinvoice = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ISTOINVOICE] = true;
        }

        return $this;
    } // setIsToInvoice()

    /**
     * Set the value of [file_path] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setFilePath($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->file_path !== $v) {
            $this->file_path = $v;
            $this->modifiedColumns[EtudeTableMap::COL_FILE_PATH] = true;
        }

        return $this;
    } // setFilePath()

    /**
     * Set the value of [account_leader_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAccountLeaderId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->account_leader_id !== $v) {
            $this->account_leader_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ACCOUNT_LEADER_ID] = true;
        }

        if ($this->aAccountLeader !== null && $this->aAccountLeader->getId() !== $v) {
            $this->aAccountLeader = null;
        }

        return $this;
    } // setAccountLeaderId()

    /**
     * Set the value of [account_pm_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAccountPMId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->account_pm_id !== $v) {
            $this->account_pm_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ACCOUNT_PM_ID] = true;
        }

        if ($this->aAccountPM !== null && $this->aAccountPM->getId() !== $v) {
            $this->aAccountPM = null;
        }

        return $this;
    } // setAccountPMId()

    /**
     * Set the value of [am_email] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAmEmail($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->am_email !== $v) {
            $this->am_email = $v;
            $this->modifiedColumns[EtudeTableMap::COL_AM_EMAIL] = true;
        }

        return $this;
    } // setAmEmail()

    /**
     * Sets the value of the [client_portal_ready] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setClientPortalReady($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->client_portal_ready !== $v) {
            $this->client_portal_ready = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CLIENT_PORTAL_READY] = true;
        }

        return $this;
    } // setClientPortalReady()

    /**
     * Set the value of [length_of_interview] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setLengthOfInterview($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->length_of_interview !== $v) {
            $this->length_of_interview = $v;
            $this->modifiedColumns[EtudeTableMap::COL_LENGTH_OF_INTERVIEW] = true;
        }

        return $this;
    } // setLengthOfInterview()

    /**
     * Set the value of [sunshine_act] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setsunshineAct($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sunshine_act !== $v) {
            $this->sunshine_act = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SUNSHINE_ACT] = true;
        }

        return $this;
    } // setsunshineAct()

    /**
     * Sets the value of the [is_consolidated] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIsConsolidated($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_consolidated !== $v) {
            $this->is_consolidated = $v;
            $this->modifiedColumns[EtudeTableMap::COL_IS_CONSOLIDATED] = true;
        }

        return $this;
    } // setIsConsolidated()

    /**
     * Set the value of [sharepoint_folder] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSharepointFolder($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->sharepoint_folder !== $v) {
            $this->sharepoint_folder = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SHAREPOINT_FOLDER] = true;
        }

        return $this;
    } // setSharepointFolder()

    /**
     * Sets the value of the [multi_phase] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setMultiPhase($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->multi_phase !== $v) {
            $this->multi_phase = $v;
            $this->modifiedColumns[EtudeTableMap::COL_MULTI_PHASE] = true;
        }

        return $this;
    } // setMultiPhase()

    /**
     * Set the value of [po_number] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setPoNumber($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->po_number !== $v) {
            $this->po_number = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PO_NUMBER] = true;
        }

        return $this;
    } // setPoNumber()

    /**
     * Set the value of [currencies] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCurrencies($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->currencies !== $v) {
            $this->currencies = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CURRENCIES] = true;
        }

        return $this;
    } // setCurrencies()

    /**
     * Sets the value of the [sms_relance] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSmsRelance($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->sms_relance !== $v) {
            $this->sms_relance = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SMS_RELANCE] = true;
        }

        return $this;
    } // setSmsRelance()

    /**
     * Set the value of [id_etude_group] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIdEtudeGroup($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id_etude_group !== $v) {
            $this->id_etude_group = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ID_ETUDE_GROUP] = true;
        }

        if ($this->aEtudeGroup !== null && $this->aEtudeGroup->getId() !== $v) {
            $this->aEtudeGroup = null;
        }

        return $this;
    } // setIdEtudeGroup()

    /**
     * Set the value of [gms] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setGms($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->gms !== $v) {
            $this->gms = $v;
            $this->modifiedColumns[EtudeTableMap::COL_GMS] = true;
        }

        return $this;
    } // setGms()

    /**
     * Set the value of [kol] column.
     *
     * @param string $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setKol($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->kol !== $v) {
            $this->kol = $v;
            $this->modifiedColumns[EtudeTableMap::COL_KOL] = true;
        }

        return $this;
    } // setKol()

    /**
     * Sets the value of the [room_rental] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRoomRental($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->room_rental !== $v) {
            $this->room_rental = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ROOM_RENTAL] = true;
        }

        return $this;
    } // setRoomRental()

    /**
     * Sets the value of the [recruits_offsite] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setRecruitsOffsite($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->recruits_offsite !== $v) {
            $this->recruits_offsite = $v;
            $this->modifiedColumns[EtudeTableMap::COL_RECRUITS_OFFSITE] = true;
        }

        return $this;
    } // setRecruitsOffsite()

    /**
     * Set the value of [study_specification] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setStudySpecification($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->study_specification !== $v) {
            $this->study_specification = $v;
            $this->modifiedColumns[EtudeTableMap::COL_STUDY_SPECIFICATION] = true;
        }

        return $this;
    } // setStudySpecification()

    /**
     * Sets the value of the [is_study_specification] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setisStudySpecification($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->is_study_specification !== $v) {
            $this->is_study_specification = $v;
            $this->modifiedColumns[EtudeTableMap::COL_IS_STUDY_SPECIFICATION] = true;
        }

        return $this;
    } // setisStudySpecification()

    /**
     * Set the value of [additional_notes] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAdditionalNotes($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->additional_notes !== $v) {
            $this->additional_notes = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ADDITIONAL_NOTES] = true;
        }

        return $this;
    } // setAdditionalNotes()

    /**
     * Set the value of [project_comment] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setProjectComment($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->project_comment !== $v) {
            $this->project_comment = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PROJECT_COMMENT] = true;
        }

        return $this;
    } // setProjectComment()

    /**
     * Set the value of [end_client_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setEndClientId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->end_client_id !== $v) {
            $this->end_client_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_END_CLIENT_ID] = true;
        }

        if ($this->aEndClient !== null && $this->aEndClient->getId() !== $v) {
            $this->aEndClient = null;
        }

        return $this;
    } // setEndClientId()

    /**
     * Set the value of [end_client_contact_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setEndClientContactId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->end_client_contact_id !== $v) {
            $this->end_client_contact_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_END_CLIENT_CONTACT_ID] = true;
        }

        if ($this->aEndClientContact !== null && $this->aEndClientContact->getId() !== $v) {
            $this->aEndClientContact = null;
        }

        return $this;
    } // setEndClientContactId()

    /**
     * Set the value of [contact_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setContactId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->contact_id !== $v) {
            $this->contact_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CONTACT_ID] = true;
        }

        if ($this->aContact !== null && $this->aContact->getId() !== $v) {
            $this->aContact = null;
        }

        return $this;
    } // setContactId()

    /**
     * Set the value of [contact_client_pm_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setContactClientPmId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->contact_client_pm_id !== $v) {
            $this->contact_client_pm_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CONTACT_CLIENT_PM_ID] = true;
        }

        if ($this->aContactClientPm !== null && $this->aContactClientPm->getId() !== $v) {
            $this->aContactClientPm = null;
        }

        return $this;
    } // setContactClientPmId()

    /**
     * Set the value of [master_project_number] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setMasterProjectNumber($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->master_project_number !== $v) {
            $this->master_project_number = $v;
            $this->modifiedColumns[EtudeTableMap::COL_MASTER_PROJECT_NUMBER] = true;
        }

        return $this;
    } // setMasterProjectNumber()

    /**
     * Set the value of [proposed_loi] column.
     *
     * @param double|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setProposedLoi($v)
    {
        if ($v !== null) {
            $v = (double) $v;
        }

        if ($this->proposed_loi !== $v) {
            $this->proposed_loi = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PROPOSED_LOI] = true;
        }

        return $this;
    } // setProposedLoi()

    /**
     * Set the value of [opportunity_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setOpportunityId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->opportunity_id !== $v) {
            $this->opportunity_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_OPPORTUNITY_ID] = true;
        }

        if ($this->aOpportunity !== null && $this->aOpportunity->getId() !== $v) {
            $this->aOpportunity = null;
        }

        return $this;
    } // setOpportunityId()

    /**
     * Set the value of [si_job_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setSiJobTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->si_job_type_id !== $v) {
            $this->si_job_type_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SI_JOB_TYPE_ID] = true;
        }

        if ($this->aSiJobType !== null && $this->aSiJobType->getId() !== $v) {
            $this->aSiJobType = null;
        }

        return $this;
    } // setSiJobTypeId()

    /**
     * Sets the value of the [best_effort] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setBestEffort($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->best_effort !== $v) {
            $this->best_effort = $v;
            $this->modifiedColumns[EtudeTableMap::COL_BEST_EFFORT] = true;
        }

        return $this;
    } // setBestEffort()

    /**
     * Set the value of [job_status_sf_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setJobStatusSfId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->job_status_sf_id !== $v) {
            $this->job_status_sf_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_JOB_STATUS_SF_ID] = true;
        }

        if ($this->aJobStatusSf !== null && $this->aJobStatusSf->getId() !== $v) {
            $this->aJobStatusSf = null;
        }

        return $this;
    } // setJobStatusSfId()

    /**
     * Set the value of [booked_by_sf_id] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setBookedBySfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->booked_by_sf_id !== $v) {
            $this->booked_by_sf_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_BOOKED_BY_SF_ID] = true;
        }

        return $this;
    } // setBookedBySfId()

    /**
     * Set the value of [created_by_sf_id] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCreatedBySfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->created_by_sf_id !== $v) {
            $this->created_by_sf_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CREATED_BY_SF_ID] = true;
        }

        return $this;
    } // setCreatedBySfId()

    /**
     * Set the value of [account_manager_sf_id] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setAccountManagerSfId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->account_manager_sf_id !== $v) {
            $this->account_manager_sf_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID] = true;
        }

        return $this;
    } // setAccountManagerSfId()

    /**
     * Sets the value of [created_date] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCreatedDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->created_date !== null || $dt !== null) {
            if ($this->created_date === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->created_date->format("Y-m-d H:i:s.u")) {
                $this->created_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_CREATED_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setCreatedDate()

    /**
     * Set the value of [job_qualification_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setJobQualificationId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->job_qualification_id !== $v) {
            $this->job_qualification_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_JOB_QUALIFICATION_ID] = true;
        }

        if ($this->aJobQualification !== null && $this->aJobQualification->getId() !== $v) {
            $this->aJobQualification = null;
        }

        return $this;
    } // setJobQualificationId()

    /**
     * Set the value of [proposed_n] column.
     *
     * @param double|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setProposedN($v)
    {
        if ($v !== null) {
            $v = (double) $v;
        }

        if ($this->proposed_n !== $v) {
            $this->proposed_n = $v;
            $this->modifiedColumns[EtudeTableMap::COL_PROPOSED_N] = true;
        }

        return $this;
    } // setProposedN()

    /**
     * Set the value of [german_job_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setGermanJobTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->german_job_type_id !== $v) {
            $this->german_job_type_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_GERMAN_JOB_TYPE_ID] = true;
        }

        if ($this->aGermanJobType !== null && $this->aGermanJobType->getId() !== $v) {
            $this->aGermanJobType = null;
        }

        return $this;
    } // setGermanJobTypeId()

    /**
     * Set the value of [created_by_comment] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCreatedByComment($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->created_by_comment !== $v) {
            $this->created_by_comment = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CREATED_BY_COMMENT] = true;
        }

        return $this;
    } // setCreatedByComment()

    /**
     * Sets the value of the [focus_vision] column.
     * Non-boolean arguments are converted using the following rules:
     *   * 1, '1', 'true',  'on',  and 'yes' are converted to boolean true
     *   * 0, '0', 'false', 'off', and 'no'  are converted to boolean false
     * Check on string values is case insensitive (so 'FaLsE' is seen as 'false').
     *
     * @param  boolean|integer|string|null $v The new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setFocusVision($v)
    {
        if ($v !== null) {
            if (is_string($v)) {
                $v = in_array(strtolower($v), array('false', 'off', '-', 'no', 'n', '0', '')) ? false : true;
            } else {
                $v = (boolean) $v;
            }
        }

        if ($this->focus_vision !== $v) {
            $this->focus_vision = $v;
            $this->modifiedColumns[EtudeTableMap::COL_FOCUS_VISION] = true;
        }

        return $this;
    } // setFocusVision()

    /**
     * Set the value of [si_eu_job_type] column.
     *
     * @param  string|null $v new value
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function setSiEuJobType($v)
    {
        if ($v !== null) {
            $valueSet = EtudeTableMap::getValueSet(EtudeTableMap::COL_SI_EU_JOB_TYPE);
            if (!in_array($v, $valueSet)) {
                throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $v));
            }
            $v = array_search($v, $valueSet);
        }

        if ($this->si_eu_job_type !== $v) {
            $this->si_eu_job_type = $v;
            $this->modifiedColumns[EtudeTableMap::COL_SI_EU_JOB_TYPE] = true;
        }

        return $this;
    } // setSiEuJobType()

    /**
     * Set the value of [intermediate_client_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIntermediateClientId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->intermediate_client_id !== $v) {
            $this->intermediate_client_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID] = true;
        }

        if ($this->aIntermediateClient !== null && $this->aIntermediateClient->getId() !== $v) {
            $this->aIntermediateClient = null;
        }

        return $this;
    } // setIntermediateClientId()

    /**
     * Set the value of [intermediate_client_contact_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setIntermediateClientContactId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->intermediate_client_contact_id !== $v) {
            $this->intermediate_client_contact_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID] = true;
        }

        if ($this->aIntermediateClientContact !== null && $this->aIntermediateClientContact->getId() !== $v) {
            $this->aIntermediateClientContact = null;
        }

        return $this;
    } // setIntermediateClientContactId()

    /**
     * Set the value of [us_global_qual_gms_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setUsGlobalQualGmsId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->us_global_qual_gms_id !== $v) {
            $this->us_global_qual_gms_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID] = true;
        }

        if ($this->aUsGlobalQualGms !== null && $this->aUsGlobalQualGms->getId() !== $v) {
            $this->aUsGlobalQualGms = null;
        }

        return $this;
    } // setUsGlobalQualGmsId()

    /**
     * Set the value of [facilty_note] column.
     *
     * @param string|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setFaciltyNote($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->facilty_note !== $v) {
            $this->facilty_note = $v;
            $this->modifiedColumns[EtudeTableMap::COL_FACILTY_NOTE] = true;
        }

        return $this;
    } // setFaciltyNote()

    /**
     * Set the value of [currency_iso_code_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCurrencyIsoCodeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->currency_iso_code_id !== $v) {
            $this->currency_iso_code_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CURRENCY_ISO_CODE_ID] = true;
        }

        if ($this->aCurrencyIsoCode !== null && $this->aCurrencyIsoCode->getId() !== $v) {
            $this->aCurrencyIsoCode = null;
        }

        return $this;
    } // setCurrencyIsoCodeId()

    /**
     * Set the value of [client_list_deletion_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setClientListDeletionId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->client_list_deletion_id !== $v) {
            $this->client_list_deletion_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CLIENT_LIST_DELETION_ID] = true;
        }

        if ($this->aClientListDeletion !== null && $this->aClientListDeletion->getId() !== $v) {
            $this->aClientListDeletion = null;
        }

        return $this;
    } // setClientListDeletionId()

    /**
     * Set the value of [created_by_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCreatedById($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->created_by_id !== $v) {
            $this->created_by_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_CREATED_BY_ID] = true;
        }

        if ($this->aCreatedBy !== null && $this->aCreatedBy->getId() !== $v) {
            $this->aCreatedBy = null;
        }

        return $this;
    } // setCreatedById()

    /**
     * Set the value of [updated_by_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setUpdatedById($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->updated_by_id !== $v) {
            $this->updated_by_id = $v;
            $this->modifiedColumns[EtudeTableMap::COL_UPDATED_BY_ID] = true;
        }

        if ($this->aUpdatedBy !== null && $this->aUpdatedBy->getId() !== $v) {
            $this->aUpdatedBy = null;
        }

        return $this;
    } // setUpdatedById()

    /**
     * Sets the value of [created_at] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setCreatedAt($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->created_at !== null || $dt !== null) {
            if ($this->created_at === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->created_at->format("Y-m-d H:i:s.u")) {
                $this->created_at = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_CREATED_AT] = true;
            }
        } // if either are not null

        return $this;
    } // setCreatedAt()

    /**
     * Sets the value of [updated_at] column to a normalized version of the date/time value specified.
     *
     * @param  string|integer|\DateTimeInterface|null $v string, integer (timestamp), or \DateTimeInterface value.
     *               Empty strings are treated as NULL.
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function setUpdatedAt($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->updated_at !== null || $dt !== null) {
            if ($this->updated_at === null || $dt === null || $dt->format("Y-m-d H:i:s.u") !== $this->updated_at->format("Y-m-d H:i:s.u")) {
                $this->updated_at = $dt === null ? null : clone $dt;
                $this->modifiedColumns[EtudeTableMap::COL_UPDATED_AT] = true;
            }
        } // if either are not null

        return $this;
    } // setUpdatedAt()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->rst !== false) {
                return false;
            }

            if ($this->cli !== false) {
                return false;
            }

            if ($this->gqs !== false) {
                return false;
            }

            if ($this->ins !== false) {
                return false;
            }

            if ($this->hut !== false) {
                return false;
            }

            if ($this->display_total_only !== false) {
                return false;
            }

            if ($this->consolidated_invoice !== false) {
                return false;
            }

            if ($this->send_csat_quest !== false) {
                return false;
            }

            if ($this->is_send_csat_quest_mail !== true) {
                return false;
            }

            if ($this->dont_set_am_auto !== false) {
                return false;
            }

            if ($this->recrutement_objectif !== 0) {
                return false;
            }

            if ($this->istoinvoice !== false) {
                return false;
            }

            if ($this->client_portal_ready !== true) {
                return false;
            }

            if ($this->is_consolidated !== false) {
                return false;
            }

            if ($this->multi_phase !== false) {
                return false;
            }

            if ($this->sms_relance !== false) {
                return false;
            }

            if ($this->room_rental !== false) {
                return false;
            }

            if ($this->recruits_offsite !== false) {
                return false;
            }

            if ($this->is_study_specification !== false) {
                return false;
            }

            if ($this->proposed_loi !== 0.0) {
                return false;
            }

            if ($this->best_effort !== false) {
                return false;
            }

            if ($this->proposed_n !== 0.0) {
                return false;
            }

        // otherwise, everything was equal, so return TRUE
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array   $row       The row returned by DataFetcher->fetch().
     * @param int     $startcol  0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @param string  $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                  One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                            TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false, $indexType = TableMap::TYPE_NUM)
    {
        try {

            $col = $row[TableMap::TYPE_NUM == $indexType ? 0 + $startcol : EtudeTableMap::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 1 + $startcol : EtudeTableMap::translateFieldName('NumeroEtude', TableMap::TYPE_PHPNAME, $indexType)];
            $this->numero_etude = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 2 + $startcol : EtudeTableMap::translateFieldName('ReferenceClient', TableMap::TYPE_PHPNAME, $indexType)];
            $this->reference_client = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 3 + $startcol : EtudeTableMap::translateFieldName('MasterProjectSfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->master_project_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 4 + $startcol : EtudeTableMap::translateFieldName('Theme', TableMap::TYPE_PHPNAME, $indexType)];
            $this->theme = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 5 + $startcol : EtudeTableMap::translateFieldName('DateDebut', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->date_debut = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 6 + $startcol : EtudeTableMap::translateFieldName('DateFin', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->date_fin = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 7 + $startcol : EtudeTableMap::translateFieldName('Annee', TableMap::TYPE_PHPNAME, $indexType)];
            $this->annee = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 8 + $startcol : EtudeTableMap::translateFieldName('Rst', TableMap::TYPE_PHPNAME, $indexType)];
            $this->rst = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 9 + $startcol : EtudeTableMap::translateFieldName('Cli', TableMap::TYPE_PHPNAME, $indexType)];
            $this->cli = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 10 + $startcol : EtudeTableMap::translateFieldName('Gqs', TableMap::TYPE_PHPNAME, $indexType)];
            $this->gqs = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 11 + $startcol : EtudeTableMap::translateFieldName('Ins', TableMap::TYPE_PHPNAME, $indexType)];
            $this->ins = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 12 + $startcol : EtudeTableMap::translateFieldName('Hut', TableMap::TYPE_PHPNAME, $indexType)];
            $this->hut = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 13 + $startcol : EtudeTableMap::translateFieldName('DisplayTotalOnly', TableMap::TYPE_PHPNAME, $indexType)];
            $this->display_total_only = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 14 + $startcol : EtudeTableMap::translateFieldName('IdPm', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_pm = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 15 + $startcol : EtudeTableMap::translateFieldName('IdEtape', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_etape = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 16 + $startcol : EtudeTableMap::translateFieldName('PrixRevientInitial', TableMap::TYPE_PHPNAME, $indexType)];
            $this->prix_revient_initial = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 17 + $startcol : EtudeTableMap::translateFieldName('PrixRevientActualise', TableMap::TYPE_PHPNAME, $indexType)];
            $this->prix_revient_actualise = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 18 + $startcol : EtudeTableMap::translateFieldName('PrixVenteInitial', TableMap::TYPE_PHPNAME, $indexType)];
            $this->prix_vente_initial = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 19 + $startcol : EtudeTableMap::translateFieldName('PrixVenteActualise', TableMap::TYPE_PHPNAME, $indexType)];
            $this->prix_vente_actualise = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 20 + $startcol : EtudeTableMap::translateFieldName('ConsolidatedInvoice', TableMap::TYPE_PHPNAME, $indexType)];
            $this->consolidated_invoice = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 21 + $startcol : EtudeTableMap::translateFieldName('SendCsatQuest', TableMap::TYPE_PHPNAME, $indexType)];
            $this->send_csat_quest = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 22 + $startcol : EtudeTableMap::translateFieldName('IsSendCsatQuestMail', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_send_csat_quest_mail = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 23 + $startcol : EtudeTableMap::translateFieldName('NumeroFacture', TableMap::TYPE_PHPNAME, $indexType)];
            $this->numero_facture = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 24 + $startcol : EtudeTableMap::translateFieldName('DontSetAmAuto', TableMap::TYPE_PHPNAME, $indexType)];
            $this->dont_set_am_auto = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 25 + $startcol : EtudeTableMap::translateFieldName('SetAmReason', TableMap::TYPE_PHPNAME, $indexType)];
            $this->set_am_reason = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 26 + $startcol : EtudeTableMap::translateFieldName('AmReasonTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->am_reason_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 27 + $startcol : EtudeTableMap::translateFieldName('DateEnvoiFacture', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->date_envoi_facture = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 28 + $startcol : EtudeTableMap::translateFieldName('DateReglement', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->date_reglement = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 29 + $startcol : EtudeTableMap::translateFieldName('Commentaire', TableMap::TYPE_PHPNAME, $indexType)];
            $this->commentaire = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 30 + $startcol : EtudeTableMap::translateFieldName('IndustryId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->industry_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 31 + $startcol : EtudeTableMap::translateFieldName('PeriodeCutoff', TableMap::TYPE_PHPNAME, $indexType)];
            $this->periode_cutoff = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 32 + $startcol : EtudeTableMap::translateFieldName('ThemeBr', TableMap::TYPE_PHPNAME, $indexType)];
            $this->theme_br = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 33 + $startcol : EtudeTableMap::translateFieldName('AreaId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->area_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 34 + $startcol : EtudeTableMap::translateFieldName('IdSamsStudy', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_sams_study = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 35 + $startcol : EtudeTableMap::translateFieldName('RecrutementObjectif', TableMap::TYPE_PHPNAME, $indexType)];
            $this->recrutement_objectif = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 36 + $startcol : EtudeTableMap::translateFieldName('IdLocationPnl', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_location_pnl = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 37 + $startcol : EtudeTableMap::translateFieldName('IdMasterProjectLocationPnl', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_master_project_location_pnl = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 38 + $startcol : EtudeTableMap::translateFieldName('RecrutementObjectifPr', TableMap::TYPE_PHPNAME, $indexType)];
            $this->recrutement_objectif_pr = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 39 + $startcol : EtudeTableMap::translateFieldName('IdBm', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_bm = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 40 + $startcol : EtudeTableMap::translateFieldName('ExtraInfo', TableMap::TYPE_PHPNAME, $indexType)];
            $this->extra_info = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 41 + $startcol : EtudeTableMap::translateFieldName('AccountId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 42 + $startcol : EtudeTableMap::translateFieldName('AccountManagerId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_manager_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 43 + $startcol : EtudeTableMap::translateFieldName('ProjectSpecialtySponsorId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->project_specialty_sponsor_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 44 + $startcol : EtudeTableMap::translateFieldName('Language', TableMap::TYPE_PHPNAME, $indexType)];
            $this->language = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 45 + $startcol : EtudeTableMap::translateFieldName('RemiseTaux', TableMap::TYPE_PHPNAME, $indexType)];
            $this->remise_taux = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 46 + $startcol : EtudeTableMap::translateFieldName('ClientDiscountPercentage', TableMap::TYPE_PHPNAME, $indexType)];
            $this->client_discount_percentage = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 47 + $startcol : EtudeTableMap::translateFieldName('EndClientDiscountPercentage', TableMap::TYPE_PHPNAME, $indexType)];
            $this->end_client_discount_percentage = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 48 + $startcol : EtudeTableMap::translateFieldName('ClientQuantDiscountPercentage', TableMap::TYPE_PHPNAME, $indexType)];
            $this->client_quant_discount_percentage = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 49 + $startcol : EtudeTableMap::translateFieldName('EndClientQuantDiscountPercentage', TableMap::TYPE_PHPNAME, $indexType)];
            $this->end_client_quant_discount_percentage = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 50 + $startcol : EtudeTableMap::translateFieldName('SamplePlan', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sample_plan = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 51 + $startcol : EtudeTableMap::translateFieldName('IsToInvoice', TableMap::TYPE_PHPNAME, $indexType)];
            $this->istoinvoice = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 52 + $startcol : EtudeTableMap::translateFieldName('FilePath', TableMap::TYPE_PHPNAME, $indexType)];
            $this->file_path = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 53 + $startcol : EtudeTableMap::translateFieldName('AccountLeaderId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_leader_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 54 + $startcol : EtudeTableMap::translateFieldName('AccountPMId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_pm_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 55 + $startcol : EtudeTableMap::translateFieldName('AmEmail', TableMap::TYPE_PHPNAME, $indexType)];
            $this->am_email = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 56 + $startcol : EtudeTableMap::translateFieldName('ClientPortalReady', TableMap::TYPE_PHPNAME, $indexType)];
            $this->client_portal_ready = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 57 + $startcol : EtudeTableMap::translateFieldName('LengthOfInterview', TableMap::TYPE_PHPNAME, $indexType)];
            $this->length_of_interview = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 58 + $startcol : EtudeTableMap::translateFieldName('sunshineAct', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sunshine_act = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 59 + $startcol : EtudeTableMap::translateFieldName('IsConsolidated', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_consolidated = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 60 + $startcol : EtudeTableMap::translateFieldName('SharepointFolder', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sharepoint_folder = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 61 + $startcol : EtudeTableMap::translateFieldName('MultiPhase', TableMap::TYPE_PHPNAME, $indexType)];
            $this->multi_phase = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 62 + $startcol : EtudeTableMap::translateFieldName('PoNumber', TableMap::TYPE_PHPNAME, $indexType)];
            $this->po_number = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 63 + $startcol : EtudeTableMap::translateFieldName('Currencies', TableMap::TYPE_PHPNAME, $indexType)];
            $this->currencies = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 64 + $startcol : EtudeTableMap::translateFieldName('SmsRelance', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sms_relance = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 65 + $startcol : EtudeTableMap::translateFieldName('IdEtudeGroup', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id_etude_group = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 66 + $startcol : EtudeTableMap::translateFieldName('Gms', TableMap::TYPE_PHPNAME, $indexType)];
            $this->gms = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 67 + $startcol : EtudeTableMap::translateFieldName('Kol', TableMap::TYPE_PHPNAME, $indexType)];
            $this->kol = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 68 + $startcol : EtudeTableMap::translateFieldName('RoomRental', TableMap::TYPE_PHPNAME, $indexType)];
            $this->room_rental = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 69 + $startcol : EtudeTableMap::translateFieldName('RecruitsOffsite', TableMap::TYPE_PHPNAME, $indexType)];
            $this->recruits_offsite = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 70 + $startcol : EtudeTableMap::translateFieldName('StudySpecification', TableMap::TYPE_PHPNAME, $indexType)];
            $this->study_specification = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 71 + $startcol : EtudeTableMap::translateFieldName('isStudySpecification', TableMap::TYPE_PHPNAME, $indexType)];
            $this->is_study_specification = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 72 + $startcol : EtudeTableMap::translateFieldName('AdditionalNotes', TableMap::TYPE_PHPNAME, $indexType)];
            $this->additional_notes = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 73 + $startcol : EtudeTableMap::translateFieldName('ProjectComment', TableMap::TYPE_PHPNAME, $indexType)];
            $this->project_comment = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 74 + $startcol : EtudeTableMap::translateFieldName('EndClientId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->end_client_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 75 + $startcol : EtudeTableMap::translateFieldName('EndClientContactId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->end_client_contact_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 76 + $startcol : EtudeTableMap::translateFieldName('ContactId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->contact_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 77 + $startcol : EtudeTableMap::translateFieldName('ContactClientPmId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->contact_client_pm_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 78 + $startcol : EtudeTableMap::translateFieldName('MasterProjectNumber', TableMap::TYPE_PHPNAME, $indexType)];
            $this->master_project_number = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 79 + $startcol : EtudeTableMap::translateFieldName('ProposedLoi', TableMap::TYPE_PHPNAME, $indexType)];
            $this->proposed_loi = (null !== $col) ? (double) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 80 + $startcol : EtudeTableMap::translateFieldName('OpportunityId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->opportunity_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 81 + $startcol : EtudeTableMap::translateFieldName('SiJobTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->si_job_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 82 + $startcol : EtudeTableMap::translateFieldName('BestEffort', TableMap::TYPE_PHPNAME, $indexType)];
            $this->best_effort = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 83 + $startcol : EtudeTableMap::translateFieldName('JobStatusSfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->job_status_sf_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 84 + $startcol : EtudeTableMap::translateFieldName('BookedBySfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->booked_by_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 85 + $startcol : EtudeTableMap::translateFieldName('CreatedBySfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->created_by_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 86 + $startcol : EtudeTableMap::translateFieldName('AccountManagerSfId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->account_manager_sf_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 87 + $startcol : EtudeTableMap::translateFieldName('CreatedDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->created_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 88 + $startcol : EtudeTableMap::translateFieldName('JobQualificationId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->job_qualification_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 89 + $startcol : EtudeTableMap::translateFieldName('ProposedN', TableMap::TYPE_PHPNAME, $indexType)];
            $this->proposed_n = (null !== $col) ? (double) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 90 + $startcol : EtudeTableMap::translateFieldName('GermanJobTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->german_job_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 91 + $startcol : EtudeTableMap::translateFieldName('CreatedByComment', TableMap::TYPE_PHPNAME, $indexType)];
            $this->created_by_comment = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 92 + $startcol : EtudeTableMap::translateFieldName('FocusVision', TableMap::TYPE_PHPNAME, $indexType)];
            $this->focus_vision = (null !== $col) ? (boolean) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 93 + $startcol : EtudeTableMap::translateFieldName('SiEuJobType', TableMap::TYPE_PHPNAME, $indexType)];
            $this->si_eu_job_type = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 94 + $startcol : EtudeTableMap::translateFieldName('IntermediateClientId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->intermediate_client_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 95 + $startcol : EtudeTableMap::translateFieldName('IntermediateClientContactId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->intermediate_client_contact_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 96 + $startcol : EtudeTableMap::translateFieldName('UsGlobalQualGmsId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->us_global_qual_gms_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 97 + $startcol : EtudeTableMap::translateFieldName('FaciltyNote', TableMap::TYPE_PHPNAME, $indexType)];
            $this->facilty_note = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 98 + $startcol : EtudeTableMap::translateFieldName('CurrencyIsoCodeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->currency_iso_code_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 99 + $startcol : EtudeTableMap::translateFieldName('ClientListDeletionId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->client_list_deletion_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 100 + $startcol : EtudeTableMap::translateFieldName('CreatedById', TableMap::TYPE_PHPNAME, $indexType)];
            $this->created_by_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 101 + $startcol : EtudeTableMap::translateFieldName('UpdatedById', TableMap::TYPE_PHPNAME, $indexType)];
            $this->updated_by_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 102 + $startcol : EtudeTableMap::translateFieldName('CreatedAt', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->created_at = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 103 + $startcol : EtudeTableMap::translateFieldName('UpdatedAt', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->updated_at = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }

            return $startcol + 104; // 104 = EtudeTableMap::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException(sprintf('Error populating %s object', '\\Model\\Etude'), 0, $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {
        if ($this->aEtudeProjectManager !== null && $this->id_pm !== $this->aEtudeProjectManager->getId()) {
            $this->aEtudeProjectManager = null;
        }
        if ($this->aEtape !== null && $this->id_etape !== $this->aEtape->getId()) {
            $this->aEtape = null;
        }
        if ($this->aAmReasonType !== null && $this->am_reason_type_id !== $this->aAmReasonType->getId()) {
            $this->aAmReasonType = null;
        }
        if ($this->aIndustry !== null && $this->industry_id !== $this->aIndustry->getId()) {
            $this->aIndustry = null;
        }
        if ($this->aEtudeArea !== null && $this->area_id !== $this->aEtudeArea->getId()) {
            $this->aEtudeArea = null;
        }
        if ($this->aEtudeLocation !== null && $this->id_location_pnl !== $this->aEtudeLocation->getId()) {
            $this->aEtudeLocation = null;
        }
        if ($this->aProjectLocationPrefix !== null && $this->id_master_project_location_pnl !== $this->aProjectLocationPrefix->getId()) {
            $this->aProjectLocationPrefix = null;
        }
        if ($this->aBM !== null && $this->id_bm !== $this->aBM->getId()) {
            $this->aBM = null;
        }
        if ($this->aAccount !== null && $this->account_id !== $this->aAccount->getId()) {
            $this->aAccount = null;
        }
        if ($this->aProjectAccountManager !== null && $this->account_manager_id !== $this->aProjectAccountManager->getId()) {
            $this->aProjectAccountManager = null;
        }
        if ($this->aProjectSpecialtySponsor !== null && $this->project_specialty_sponsor_id !== $this->aProjectSpecialtySponsor->getId()) {
            $this->aProjectSpecialtySponsor = null;
        }
        if ($this->aAccountLeader !== null && $this->account_leader_id !== $this->aAccountLeader->getId()) {
            $this->aAccountLeader = null;
        }
        if ($this->aAccountPM !== null && $this->account_pm_id !== $this->aAccountPM->getId()) {
            $this->aAccountPM = null;
        }
        if ($this->aEtudeGroup !== null && $this->id_etude_group !== $this->aEtudeGroup->getId()) {
            $this->aEtudeGroup = null;
        }
        if ($this->aEndClient !== null && $this->end_client_id !== $this->aEndClient->getId()) {
            $this->aEndClient = null;
        }
        if ($this->aEndClientContact !== null && $this->end_client_contact_id !== $this->aEndClientContact->getId()) {
            $this->aEndClientContact = null;
        }
        if ($this->aContact !== null && $this->contact_id !== $this->aContact->getId()) {
            $this->aContact = null;
        }
        if ($this->aContactClientPm !== null && $this->contact_client_pm_id !== $this->aContactClientPm->getId()) {
            $this->aContactClientPm = null;
        }
        if ($this->aOpportunity !== null && $this->opportunity_id !== $this->aOpportunity->getId()) {
            $this->aOpportunity = null;
        }
        if ($this->aSiJobType !== null && $this->si_job_type_id !== $this->aSiJobType->getId()) {
            $this->aSiJobType = null;
        }
        if ($this->aJobStatusSf !== null && $this->job_status_sf_id !== $this->aJobStatusSf->getId()) {
            $this->aJobStatusSf = null;
        }
        if ($this->aJobQualification !== null && $this->job_qualification_id !== $this->aJobQualification->getId()) {
            $this->aJobQualification = null;
        }
        if ($this->aGermanJobType !== null && $this->german_job_type_id !== $this->aGermanJobType->getId()) {
            $this->aGermanJobType = null;
        }
        if ($this->aIntermediateClient !== null && $this->intermediate_client_id !== $this->aIntermediateClient->getId()) {
            $this->aIntermediateClient = null;
        }
        if ($this->aIntermediateClientContact !== null && $this->intermediate_client_contact_id !== $this->aIntermediateClientContact->getId()) {
            $this->aIntermediateClientContact = null;
        }
        if ($this->aUsGlobalQualGms !== null && $this->us_global_qual_gms_id !== $this->aUsGlobalQualGms->getId()) {
            $this->aUsGlobalQualGms = null;
        }
        if ($this->aCurrencyIsoCode !== null && $this->currency_iso_code_id !== $this->aCurrencyIsoCode->getId()) {
            $this->aCurrencyIsoCode = null;
        }
        if ($this->aClientListDeletion !== null && $this->client_list_deletion_id !== $this->aClientListDeletion->getId()) {
            $this->aClientListDeletion = null;
        }
        if ($this->aCreatedBy !== null && $this->created_by_id !== $this->aCreatedBy->getId()) {
            $this->aCreatedBy = null;
        }
        if ($this->aUpdatedBy !== null && $this->updated_by_id !== $this->aUpdatedBy->getId()) {
            $this->aUpdatedBy = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param      boolean $deep (optional) Whether to also de-associated any related objects.
     * @param      ConnectionInterface $con (optional) The ConnectionInterface connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeTableMap::DATABASE_NAME);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $dataFetcher = ChildEtudeQuery::create(null, $this->buildPkeyCriteria())->setFormatter(ModelCriteria::FORMAT_STATEMENT)->find($con);
        $row = $dataFetcher->fetch();
        $dataFetcher->close();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true, $dataFetcher->getIndexType()); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aUsGlobalQualGms = null;
            $this->aAccountLeader = null;
            $this->aAccountPM = null;
            $this->aIntermediateClient = null;
            $this->aEtape = null;
            $this->aContact = null;
            $this->aOpportunity = null;
            $this->aJobStatusSf = null;
            $this->aJobQualification = null;
            $this->aSiJobType = null;
            $this->aEndClientContact = null;
            $this->aGermanJobType = null;
            $this->aEndClient = null;
            $this->aAccount = null;
            $this->aIndustry = null;
            $this->aEtudeLocation = null;
            $this->aProjectLocationPrefix = null;
            $this->aContactClientPm = null;
            $this->aBM = null;
            $this->aEtudeProjectManager = null;
            $this->aEtudeGroup = null;
            $this->aEtudeArea = null;
            $this->aCurrencyIsoCode = null;
            $this->aClientListDeletion = null;
            $this->aCreatedBy = null;
            $this->aUpdatedBy = null;
            $this->aIntermediateClientContact = null;
            $this->aProjectAccountManager = null;
            $this->aProjectSpecialtySponsor = null;
            $this->aAmReasonType = null;
            $this->collDernierAccess = null;

            $this->collEtudeSampleSources = null;

            $this->collEtudeMethodologies = null;

            $this->collFactures = null;

            $this->collJobEtudes = null;

            $this->collReglements = null;

            $this->collSectors = null;

            $this->collEtudeCheckListValidations = null;

            $this->collEtudeFichiers = null;

            $this->collLogProjectStatuses = null;

            $this->collSampleSources = null;
            $this->collMethodologies = null;
            $this->collRefSalesForceEtudeRefSectors = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param      ConnectionInterface $con
     * @return void
     * @throws PropelException
     * @see Etude::setDeleted()
     * @see Etude::isDeleted()
     */
    public function delete(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con) {
            $deleteQuery = ChildEtudeQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $this->setDeleted(true);
            }
        });
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see doSave()
     */
    public function save(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($this->alreadyInSave) {
            return 0;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeTableMap::DATABASE_NAME);
        }

        return $con->transaction(function () use ($con) {
            $ret = $this->preSave($con);
            $isInsert = $this->isNew();
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // timestampable behavior
                $time = time();
                $highPrecision = \Propel\Runtime\Util\PropelDateTime::createHighPrecision();
                if (!$this->isColumnModified(EtudeTableMap::COL_CREATED_AT)) {
                    $this->setCreatedAt($highPrecision);
                }
                if (!$this->isColumnModified(EtudeTableMap::COL_UPDATED_AT)) {
                    $this->setUpdatedAt($highPrecision);
                }
            } else {
                $ret = $ret && $this->preUpdate($con);
                // timestampable behavior
                if ($this->isModified() && !$this->isColumnModified(EtudeTableMap::COL_UPDATED_AT)) {
                    $this->setUpdatedAt(\Propel\Runtime\Util\PropelDateTime::createHighPrecision());
                }
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                EtudeTableMap::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }

            return $affectedRows;
        });
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see save()
     */
    protected function doSave(ConnectionInterface $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aUsGlobalQualGms !== null) {
                if ($this->aUsGlobalQualGms->isModified() || $this->aUsGlobalQualGms->isNew()) {
                    $affectedRows += $this->aUsGlobalQualGms->save($con);
                }
                $this->setUsGlobalQualGms($this->aUsGlobalQualGms);
            }

            if ($this->aAccountLeader !== null) {
                if ($this->aAccountLeader->isModified() || $this->aAccountLeader->isNew()) {
                    $affectedRows += $this->aAccountLeader->save($con);
                }
                $this->setAccountLeader($this->aAccountLeader);
            }

            if ($this->aAccountPM !== null) {
                if ($this->aAccountPM->isModified() || $this->aAccountPM->isNew()) {
                    $affectedRows += $this->aAccountPM->save($con);
                }
                $this->setAccountPM($this->aAccountPM);
            }

            if ($this->aIntermediateClient !== null) {
                if ($this->aIntermediateClient->isModified() || $this->aIntermediateClient->isNew()) {
                    $affectedRows += $this->aIntermediateClient->save($con);
                }
                $this->setIntermediateClient($this->aIntermediateClient);
            }

            if ($this->aEtape !== null) {
                if ($this->aEtape->isModified() || $this->aEtape->isNew()) {
                    $affectedRows += $this->aEtape->save($con);
                }
                $this->setEtape($this->aEtape);
            }

            if ($this->aContact !== null) {
                if ($this->aContact->isModified() || $this->aContact->isNew()) {
                    $affectedRows += $this->aContact->save($con);
                }
                $this->setContact($this->aContact);
            }

            if ($this->aOpportunity !== null) {
                if ($this->aOpportunity->isModified() || $this->aOpportunity->isNew()) {
                    $affectedRows += $this->aOpportunity->save($con);
                }
                $this->setOpportunity($this->aOpportunity);
            }

            if ($this->aJobStatusSf !== null) {
                if ($this->aJobStatusSf->isModified() || $this->aJobStatusSf->isNew()) {
                    $affectedRows += $this->aJobStatusSf->save($con);
                }
                $this->setJobStatusSf($this->aJobStatusSf);
            }

            if ($this->aJobQualification !== null) {
                if ($this->aJobQualification->isModified() || $this->aJobQualification->isNew()) {
                    $affectedRows += $this->aJobQualification->save($con);
                }
                $this->setJobQualification($this->aJobQualification);
            }

            if ($this->aSiJobType !== null) {
                if ($this->aSiJobType->isModified() || $this->aSiJobType->isNew()) {
                    $affectedRows += $this->aSiJobType->save($con);
                }
                $this->setSiJobType($this->aSiJobType);
            }

            if ($this->aEndClientContact !== null) {
                if ($this->aEndClientContact->isModified() || $this->aEndClientContact->isNew()) {
                    $affectedRows += $this->aEndClientContact->save($con);
                }
                $this->setEndClientContact($this->aEndClientContact);
            }

            if ($this->aGermanJobType !== null) {
                if ($this->aGermanJobType->isModified() || $this->aGermanJobType->isNew()) {
                    $affectedRows += $this->aGermanJobType->save($con);
                }
                $this->setGermanJobType($this->aGermanJobType);
            }

            if ($this->aEndClient !== null) {
                if ($this->aEndClient->isModified() || $this->aEndClient->isNew()) {
                    $affectedRows += $this->aEndClient->save($con);
                }
                $this->setEndClient($this->aEndClient);
            }

            if ($this->aAccount !== null) {
                if ($this->aAccount->isModified() || $this->aAccount->isNew()) {
                    $affectedRows += $this->aAccount->save($con);
                }
                $this->setAccount($this->aAccount);
            }

            if ($this->aIndustry !== null) {
                if ($this->aIndustry->isModified() || $this->aIndustry->isNew()) {
                    $affectedRows += $this->aIndustry->save($con);
                }
                $this->setIndustry($this->aIndustry);
            }

            if ($this->aEtudeLocation !== null) {
                if ($this->aEtudeLocation->isModified() || $this->aEtudeLocation->isNew()) {
                    $affectedRows += $this->aEtudeLocation->save($con);
                }
                $this->setEtudeLocation($this->aEtudeLocation);
            }

            if ($this->aProjectLocationPrefix !== null) {
                if ($this->aProjectLocationPrefix->isModified() || $this->aProjectLocationPrefix->isNew()) {
                    $affectedRows += $this->aProjectLocationPrefix->save($con);
                }
                $this->setProjectLocationPrefix($this->aProjectLocationPrefix);
            }

            if ($this->aContactClientPm !== null) {
                if ($this->aContactClientPm->isModified() || $this->aContactClientPm->isNew()) {
                    $affectedRows += $this->aContactClientPm->save($con);
                }
                $this->setContactClientPm($this->aContactClientPm);
            }

            if ($this->aBM !== null) {
                if ($this->aBM->isModified() || $this->aBM->isNew()) {
                    $affectedRows += $this->aBM->save($con);
                }
                $this->setBM($this->aBM);
            }

            if ($this->aEtudeProjectManager !== null) {
                if ($this->aEtudeProjectManager->isModified() || $this->aEtudeProjectManager->isNew()) {
                    $affectedRows += $this->aEtudeProjectManager->save($con);
                }
                $this->setEtudeProjectManager($this->aEtudeProjectManager);
            }

            if ($this->aEtudeGroup !== null) {
                if ($this->aEtudeGroup->isModified() || $this->aEtudeGroup->isNew()) {
                    $affectedRows += $this->aEtudeGroup->save($con);
                }
                $this->setEtudeGroup($this->aEtudeGroup);
            }

            if ($this->aEtudeArea !== null) {
                if ($this->aEtudeArea->isModified() || $this->aEtudeArea->isNew()) {
                    $affectedRows += $this->aEtudeArea->save($con);
                }
                $this->setEtudeArea($this->aEtudeArea);
            }

            if ($this->aCurrencyIsoCode !== null) {
                if ($this->aCurrencyIsoCode->isModified() || $this->aCurrencyIsoCode->isNew()) {
                    $affectedRows += $this->aCurrencyIsoCode->save($con);
                }
                $this->setCurrencyIsoCode($this->aCurrencyIsoCode);
            }

            if ($this->aClientListDeletion !== null) {
                if ($this->aClientListDeletion->isModified() || $this->aClientListDeletion->isNew()) {
                    $affectedRows += $this->aClientListDeletion->save($con);
                }
                $this->setClientListDeletion($this->aClientListDeletion);
            }

            if ($this->aCreatedBy !== null) {
                if ($this->aCreatedBy->isModified() || $this->aCreatedBy->isNew()) {
                    $affectedRows += $this->aCreatedBy->save($con);
                }
                $this->setCreatedBy($this->aCreatedBy);
            }

            if ($this->aUpdatedBy !== null) {
                if ($this->aUpdatedBy->isModified() || $this->aUpdatedBy->isNew()) {
                    $affectedRows += $this->aUpdatedBy->save($con);
                }
                $this->setUpdatedBy($this->aUpdatedBy);
            }

            if ($this->aIntermediateClientContact !== null) {
                if ($this->aIntermediateClientContact->isModified() || $this->aIntermediateClientContact->isNew()) {
                    $affectedRows += $this->aIntermediateClientContact->save($con);
                }
                $this->setIntermediateClientContact($this->aIntermediateClientContact);
            }

            if ($this->aProjectAccountManager !== null) {
                if ($this->aProjectAccountManager->isModified() || $this->aProjectAccountManager->isNew()) {
                    $affectedRows += $this->aProjectAccountManager->save($con);
                }
                $this->setProjectAccountManager($this->aProjectAccountManager);
            }

            if ($this->aProjectSpecialtySponsor !== null) {
                if ($this->aProjectSpecialtySponsor->isModified() || $this->aProjectSpecialtySponsor->isNew()) {
                    $affectedRows += $this->aProjectSpecialtySponsor->save($con);
                }
                $this->setProjectSpecialtySponsor($this->aProjectSpecialtySponsor);
            }

            if ($this->aAmReasonType !== null) {
                if ($this->aAmReasonType->isModified() || $this->aAmReasonType->isNew()) {
                    $affectedRows += $this->aAmReasonType->save($con);
                }
                $this->setAmReasonType($this->aAmReasonType);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                    $affectedRows += 1;
                } else {
                    $affectedRows += $this->doUpdate($con);
                }
                $this->resetModified();
            }

            if ($this->sampleSourcesScheduledForDeletion !== null) {
                if (!$this->sampleSourcesScheduledForDeletion->isEmpty()) {
                    $pks = array();
                    foreach ($this->sampleSourcesScheduledForDeletion as $entry) {
                        $entryPk = [];

                        $entryPk[1] = $this->getId();
                        $entryPk[0] = $entry->getId();
                        $pks[] = $entryPk;
                    }

                    \Model\EtudeSampleSourceQuery::create()
                        ->filterByPrimaryKeys($pks)
                        ->delete($con);

                    $this->sampleSourcesScheduledForDeletion = null;
                }

            }

            if ($this->collSampleSources) {
                foreach ($this->collSampleSources as $sampleSource) {
                    if (!$sampleSource->isDeleted() && ($sampleSource->isNew() || $sampleSource->isModified())) {
                        $sampleSource->save($con);
                    }
                }
            }


            if ($this->methodologiesScheduledForDeletion !== null) {
                if (!$this->methodologiesScheduledForDeletion->isEmpty()) {
                    $pks = array();
                    foreach ($this->methodologiesScheduledForDeletion as $entry) {
                        $entryPk = [];

                        $entryPk[1] = $this->getId();
                        $entryPk[0] = $entry->getId();
                        $pks[] = $entryPk;
                    }

                    \Model\EtudeMethodologyQuery::create()
                        ->filterByPrimaryKeys($pks)
                        ->delete($con);

                    $this->methodologiesScheduledForDeletion = null;
                }

            }

            if ($this->collMethodologies) {
                foreach ($this->collMethodologies as $methodology) {
                    if (!$methodology->isDeleted() && ($methodology->isNew() || $methodology->isModified())) {
                        $methodology->save($con);
                    }
                }
            }


            if ($this->refSalesForceEtudeRefSectorsScheduledForDeletion !== null) {
                if (!$this->refSalesForceEtudeRefSectorsScheduledForDeletion->isEmpty()) {
                    $pks = array();
                    foreach ($this->refSalesForceEtudeRefSectorsScheduledForDeletion as $entry) {
                        $entryPk = [];

                        $entryPk[1] = $this->getId();
                        $entryPk[0] = $entry->getId();
                        $pks[] = $entryPk;
                    }

                    \Model\RefSalesForceEtudeSectorQuery::create()
                        ->filterByPrimaryKeys($pks)
                        ->delete($con);

                    $this->refSalesForceEtudeRefSectorsScheduledForDeletion = null;
                }

            }

            if ($this->collRefSalesForceEtudeRefSectors) {
                foreach ($this->collRefSalesForceEtudeRefSectors as $refSalesForceEtudeRefSector) {
                    if (!$refSalesForceEtudeRefSector->isDeleted() && ($refSalesForceEtudeRefSector->isNew() || $refSalesForceEtudeRefSector->isModified())) {
                        $refSalesForceEtudeRefSector->save($con);
                    }
                }
            }


            if ($this->dernierAccessScheduledForDeletion !== null) {
                if (!$this->dernierAccessScheduledForDeletion->isEmpty()) {
                    \Model\DernierAccesQuery::create()
                        ->filterByPrimaryKeys($this->dernierAccessScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->dernierAccessScheduledForDeletion = null;
                }
            }

            if ($this->collDernierAccess !== null) {
                foreach ($this->collDernierAccess as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->etudeSampleSourcesScheduledForDeletion !== null) {
                if (!$this->etudeSampleSourcesScheduledForDeletion->isEmpty()) {
                    \Model\EtudeSampleSourceQuery::create()
                        ->filterByPrimaryKeys($this->etudeSampleSourcesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->etudeSampleSourcesScheduledForDeletion = null;
                }
            }

            if ($this->collEtudeSampleSources !== null) {
                foreach ($this->collEtudeSampleSources as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->etudeMethodologiesScheduledForDeletion !== null) {
                if (!$this->etudeMethodologiesScheduledForDeletion->isEmpty()) {
                    \Model\EtudeMethodologyQuery::create()
                        ->filterByPrimaryKeys($this->etudeMethodologiesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->etudeMethodologiesScheduledForDeletion = null;
                }
            }

            if ($this->collEtudeMethodologies !== null) {
                foreach ($this->collEtudeMethodologies as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->facturesScheduledForDeletion !== null) {
                if (!$this->facturesScheduledForDeletion->isEmpty()) {
                    \Model\FactureQuery::create()
                        ->filterByPrimaryKeys($this->facturesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->facturesScheduledForDeletion = null;
                }
            }

            if ($this->collFactures !== null) {
                foreach ($this->collFactures as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->jobEtudesScheduledForDeletion !== null) {
                if (!$this->jobEtudesScheduledForDeletion->isEmpty()) {
                    \Model\JobQuery::create()
                        ->filterByPrimaryKeys($this->jobEtudesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->jobEtudesScheduledForDeletion = null;
                }
            }

            if ($this->collJobEtudes !== null) {
                foreach ($this->collJobEtudes as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->reglementsScheduledForDeletion !== null) {
                if (!$this->reglementsScheduledForDeletion->isEmpty()) {
                    \Model\ReglementQuery::create()
                        ->filterByPrimaryKeys($this->reglementsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->reglementsScheduledForDeletion = null;
                }
            }

            if ($this->collReglements !== null) {
                foreach ($this->collReglements as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->sectorsScheduledForDeletion !== null) {
                if (!$this->sectorsScheduledForDeletion->isEmpty()) {
                    \Model\RefSalesForceEtudeSectorQuery::create()
                        ->filterByPrimaryKeys($this->sectorsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->sectorsScheduledForDeletion = null;
                }
            }

            if ($this->collSectors !== null) {
                foreach ($this->collSectors as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->etudeCheckListValidationsScheduledForDeletion !== null) {
                if (!$this->etudeCheckListValidationsScheduledForDeletion->isEmpty()) {
                    \Model\EtudeCheckListValidationQuery::create()
                        ->filterByPrimaryKeys($this->etudeCheckListValidationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->etudeCheckListValidationsScheduledForDeletion = null;
                }
            }

            if ($this->collEtudeCheckListValidations !== null) {
                foreach ($this->collEtudeCheckListValidations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->etudeFichiersScheduledForDeletion !== null) {
                if (!$this->etudeFichiersScheduledForDeletion->isEmpty()) {
                    \Model\EtudeFichierQuery::create()
                        ->filterByPrimaryKeys($this->etudeFichiersScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->etudeFichiersScheduledForDeletion = null;
                }
            }

            if ($this->collEtudeFichiers !== null) {
                foreach ($this->collEtudeFichiers as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->logProjectStatusesScheduledForDeletion !== null) {
                if (!$this->logProjectStatusesScheduledForDeletion->isEmpty()) {
                    \Model\LogProjectStatusQuery::create()
                        ->filterByPrimaryKeys($this->logProjectStatusesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->logProjectStatusesScheduledForDeletion = null;
                }
            }

            if ($this->collLogProjectStatuses !== null) {
                foreach ($this->collLogProjectStatuses as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @throws PropelException
     * @see doSave()
     */
    protected function doInsert(ConnectionInterface $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[EtudeTableMap::COL_ID] = true;
        if (null !== $this->id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . EtudeTableMap::COL_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(EtudeTableMap::COL_ID)) {
            $modifiedColumns[':p' . $index++]  = '`id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_NUMERO_ETUDE)) {
            $modifiedColumns[':p' . $index++]  = '`numero_etude`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_REFERENCE_CLIENT)) {
            $modifiedColumns[':p' . $index++]  = '`reference_client`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MASTER_PROJECT_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`master_project_sf_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_THEME)) {
            $modifiedColumns[':p' . $index++]  = '`theme`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_DEBUT)) {
            $modifiedColumns[':p' . $index++]  = '`date_debut`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_FIN)) {
            $modifiedColumns[':p' . $index++]  = '`date_fin`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ANNEE)) {
            $modifiedColumns[':p' . $index++]  = '`annee`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RST)) {
            $modifiedColumns[':p' . $index++]  = '`rst`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLI)) {
            $modifiedColumns[':p' . $index++]  = '`cli`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GQS)) {
            $modifiedColumns[':p' . $index++]  = '`gqs`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INS)) {
            $modifiedColumns[':p' . $index++]  = '`ins`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_HUT)) {
            $modifiedColumns[':p' . $index++]  = '`hut`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY)) {
            $modifiedColumns[':p' . $index++]  = '`display_total_only`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_PM)) {
            $modifiedColumns[':p' . $index++]  = '`id_pm`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_ETAPE)) {
            $modifiedColumns[':p' . $index++]  = '`id_etape`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_REVIENT_INITIAL)) {
            $modifiedColumns[':p' . $index++]  = '`prix_revient_initial`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE)) {
            $modifiedColumns[':p' . $index++]  = '`prix_revient_actualise`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_VENTE_INITIAL)) {
            $modifiedColumns[':p' . $index++]  = '`prix_vente_initial`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE)) {
            $modifiedColumns[':p' . $index++]  = '`prix_vente_actualise`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONSOLIDATED_INVOICE)) {
            $modifiedColumns[':p' . $index++]  = '`consolidated_invoice`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SEND_CSAT_QUEST)) {
            $modifiedColumns[':p' . $index++]  = '`send_csat_quest`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL)) {
            $modifiedColumns[':p' . $index++]  = '`is_send_csat_quest_mail`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_NUMERO_FACTURE)) {
            $modifiedColumns[':p' . $index++]  = '`numero_facture`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DONT_SET_AM_AUTO)) {
            $modifiedColumns[':p' . $index++]  = '`dont_set_am_auto`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SET_AM_REASON)) {
            $modifiedColumns[':p' . $index++]  = '`set_am_reason`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AM_REASON_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`am_reason_type_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_ENVOI_FACTURE)) {
            $modifiedColumns[':p' . $index++]  = '`date_envoi_facture`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_REGLEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`date_reglement`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_COMMENTAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`commentaire`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INDUSTRY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`industry_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PERIODE_CUTOFF)) {
            $modifiedColumns[':p' . $index++]  = '`periode_cutoff`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_THEME_BR)) {
            $modifiedColumns[':p' . $index++]  = '`theme_br`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AREA_ID)) {
            $modifiedColumns[':p' . $index++]  = '`area_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_SAMS_STUDY)) {
            $modifiedColumns[':p' . $index++]  = '`id_sams_study`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF)) {
            $modifiedColumns[':p' . $index++]  = '`recrutement_objectif`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_LOCATION_PNL)) {
            $modifiedColumns[':p' . $index++]  = '`id_location_pnl`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL)) {
            $modifiedColumns[':p' . $index++]  = '`id_master_project_location_pnl`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR)) {
            $modifiedColumns[':p' . $index++]  = '`recrutement_objectif_pr`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_BM)) {
            $modifiedColumns[':p' . $index++]  = '`id_bm`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_EXTRA_INFO)) {
            $modifiedColumns[':p' . $index++]  = '`extra_info`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_MANAGER_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_manager_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID)) {
            $modifiedColumns[':p' . $index++]  = '`project_specialty_sponsor_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_LANGUAGE)) {
            $modifiedColumns[':p' . $index++]  = '`language`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_REMISE_TAUX)) {
            $modifiedColumns[':p' . $index++]  = '`remise_taux`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE)) {
            $modifiedColumns[':p' . $index++]  = '`client_discount_percentage`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE)) {
            $modifiedColumns[':p' . $index++]  = '`end_client_discount_percentage`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE)) {
            $modifiedColumns[':p' . $index++]  = '`client_quant_discount_percentage`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE)) {
            $modifiedColumns[':p' . $index++]  = '`end_client_quant_discount_percentage`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SAMPLE_PLAN)) {
            $modifiedColumns[':p' . $index++]  = '`sample_plan`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ISTOINVOICE)) {
            $modifiedColumns[':p' . $index++]  = '`isToInvoice`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FILE_PATH)) {
            $modifiedColumns[':p' . $index++]  = '`file_path`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_LEADER_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_leader_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_PM_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_pm_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AM_EMAIL)) {
            $modifiedColumns[':p' . $index++]  = '`am_email`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_PORTAL_READY)) {
            $modifiedColumns[':p' . $index++]  = '`client_portal_ready`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_LENGTH_OF_INTERVIEW)) {
            $modifiedColumns[':p' . $index++]  = '`length_of_interview`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SUNSHINE_ACT)) {
            $modifiedColumns[':p' . $index++]  = '`sunshine_act`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_CONSOLIDATED)) {
            $modifiedColumns[':p' . $index++]  = '`is_consolidated`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SHAREPOINT_FOLDER)) {
            $modifiedColumns[':p' . $index++]  = '`sharepoint_folder`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MULTI_PHASE)) {
            $modifiedColumns[':p' . $index++]  = '`multi_phase`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PO_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`po_number`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CURRENCIES)) {
            $modifiedColumns[':p' . $index++]  = '`currencies`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SMS_RELANCE)) {
            $modifiedColumns[':p' . $index++]  = '`sms_relance`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_ETUDE_GROUP)) {
            $modifiedColumns[':p' . $index++]  = '`id_etude_group`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GMS)) {
            $modifiedColumns[':p' . $index++]  = '`gms`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_KOL)) {
            $modifiedColumns[':p' . $index++]  = '`kol`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ROOM_RENTAL)) {
            $modifiedColumns[':p' . $index++]  = '`room_rental`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUITS_OFFSITE)) {
            $modifiedColumns[':p' . $index++]  = '`recruits_offsite`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_STUDY_SPECIFICATION)) {
            $modifiedColumns[':p' . $index++]  = '`study_specification`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_STUDY_SPECIFICATION)) {
            $modifiedColumns[':p' . $index++]  = '`is_study_specification`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ADDITIONAL_NOTES)) {
            $modifiedColumns[':p' . $index++]  = '`additional_notes`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROJECT_COMMENT)) {
            $modifiedColumns[':p' . $index++]  = '`project_comment`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`end_client_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_CONTACT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`end_client_contact_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONTACT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`contact_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID)) {
            $modifiedColumns[':p' . $index++]  = '`contact_client_pm_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MASTER_PROJECT_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = '`master_project_number`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROPOSED_LOI)) {
            $modifiedColumns[':p' . $index++]  = '`proposed_loi`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_OPPORTUNITY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`opportunity_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SI_JOB_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`si_job_type_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_BEST_EFFORT)) {
            $modifiedColumns[':p' . $index++]  = '`best_effort`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_JOB_STATUS_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`job_status_sf_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_BOOKED_BY_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`booked_by_sf_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`created_by_sf_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID)) {
            $modifiedColumns[':p' . $index++]  = '`account_manager_sf_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_DATE)) {
            $modifiedColumns[':p' . $index++]  = '`created_date`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_JOB_QUALIFICATION_ID)) {
            $modifiedColumns[':p' . $index++]  = '`job_qualification_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROPOSED_N)) {
            $modifiedColumns[':p' . $index++]  = '`proposed_n`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`german_job_type_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_COMMENT)) {
            $modifiedColumns[':p' . $index++]  = '`created_by_comment`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FOCUS_VISION)) {
            $modifiedColumns[':p' . $index++]  = '`focus_vision`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SI_EU_JOB_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`si_eu_job_type`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`intermediate_client_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID)) {
            $modifiedColumns[':p' . $index++]  = '`intermediate_client_contact_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID)) {
            $modifiedColumns[':p' . $index++]  = '`us_global_qual_gms_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FACILTY_NOTE)) {
            $modifiedColumns[':p' . $index++]  = '`facilty_note`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`currency_iso_code_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID)) {
            $modifiedColumns[':p' . $index++]  = '`client_list_deletion_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`created_by_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_UPDATED_BY_ID)) {
            $modifiedColumns[':p' . $index++]  = '`updated_by_id`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_AT)) {
            $modifiedColumns[':p' . $index++]  = '`created_at`';
        }
        if ($this->isColumnModified(EtudeTableMap::COL_UPDATED_AT)) {
            $modifiedColumns[':p' . $index++]  = '`updated_at`';
        }

        $sql = sprintf(
            'INSERT INTO `etude` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`id`':
                        $stmt->bindValue($identifier, $this->id, PDO::PARAM_INT);
                        break;
                    case '`numero_etude`':
                        $stmt->bindValue($identifier, $this->numero_etude, PDO::PARAM_STR);
                        break;
                    case '`reference_client`':
                        $stmt->bindValue($identifier, $this->reference_client, PDO::PARAM_STR);
                        break;
                    case '`master_project_sf_id`':
                        $stmt->bindValue($identifier, $this->master_project_sf_id, PDO::PARAM_STR);
                        break;
                    case '`theme`':
                        $stmt->bindValue($identifier, $this->theme, PDO::PARAM_STR);
                        break;
                    case '`date_debut`':
                        $stmt->bindValue($identifier, $this->date_debut ? $this->date_debut->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`date_fin`':
                        $stmt->bindValue($identifier, $this->date_fin ? $this->date_fin->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`annee`':
                        $stmt->bindValue($identifier, $this->annee, PDO::PARAM_STR);
                        break;
                    case '`rst`':
                        $stmt->bindValue($identifier, (int) $this->rst, PDO::PARAM_INT);
                        break;
                    case '`cli`':
                        $stmt->bindValue($identifier, (int) $this->cli, PDO::PARAM_INT);
                        break;
                    case '`gqs`':
                        $stmt->bindValue($identifier, (int) $this->gqs, PDO::PARAM_INT);
                        break;
                    case '`ins`':
                        $stmt->bindValue($identifier, (int) $this->ins, PDO::PARAM_INT);
                        break;
                    case '`hut`':
                        $stmt->bindValue($identifier, (int) $this->hut, PDO::PARAM_INT);
                        break;
                    case '`display_total_only`':
                        $stmt->bindValue($identifier, (int) $this->display_total_only, PDO::PARAM_INT);
                        break;
                    case '`id_pm`':
                        $stmt->bindValue($identifier, $this->id_pm, PDO::PARAM_INT);
                        break;
                    case '`id_etape`':
                        $stmt->bindValue($identifier, $this->id_etape, PDO::PARAM_INT);
                        break;
                    case '`prix_revient_initial`':
                        $stmt->bindValue($identifier, $this->prix_revient_initial, PDO::PARAM_STR);
                        break;
                    case '`prix_revient_actualise`':
                        $stmt->bindValue($identifier, $this->prix_revient_actualise, PDO::PARAM_STR);
                        break;
                    case '`prix_vente_initial`':
                        $stmt->bindValue($identifier, $this->prix_vente_initial, PDO::PARAM_STR);
                        break;
                    case '`prix_vente_actualise`':
                        $stmt->bindValue($identifier, $this->prix_vente_actualise, PDO::PARAM_STR);
                        break;
                    case '`consolidated_invoice`':
                        $stmt->bindValue($identifier, (int) $this->consolidated_invoice, PDO::PARAM_INT);
                        break;
                    case '`send_csat_quest`':
                        $stmt->bindValue($identifier, (int) $this->send_csat_quest, PDO::PARAM_INT);
                        break;
                    case '`is_send_csat_quest_mail`':
                        $stmt->bindValue($identifier, (int) $this->is_send_csat_quest_mail, PDO::PARAM_INT);
                        break;
                    case '`numero_facture`':
                        $stmt->bindValue($identifier, $this->numero_facture, PDO::PARAM_STR);
                        break;
                    case '`dont_set_am_auto`':
                        $stmt->bindValue($identifier, (int) $this->dont_set_am_auto, PDO::PARAM_INT);
                        break;
                    case '`set_am_reason`':
                        $stmt->bindValue($identifier, $this->set_am_reason, PDO::PARAM_STR);
                        break;
                    case '`am_reason_type_id`':
                        $stmt->bindValue($identifier, $this->am_reason_type_id, PDO::PARAM_INT);
                        break;
                    case '`date_envoi_facture`':
                        $stmt->bindValue($identifier, $this->date_envoi_facture ? $this->date_envoi_facture->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`date_reglement`':
                        $stmt->bindValue($identifier, $this->date_reglement ? $this->date_reglement->format("Y-m-d") : null, PDO::PARAM_STR);
                        break;
                    case '`commentaire`':
                        $stmt->bindValue($identifier, $this->commentaire, PDO::PARAM_STR);
                        break;
                    case '`industry_id`':
                        $stmt->bindValue($identifier, $this->industry_id, PDO::PARAM_INT);
                        break;
                    case '`periode_cutoff`':
                        $stmt->bindValue($identifier, $this->periode_cutoff, PDO::PARAM_STR);
                        break;
                    case '`theme_br`':
                        $stmt->bindValue($identifier, $this->theme_br, PDO::PARAM_STR);
                        break;
                    case '`area_id`':
                        $stmt->bindValue($identifier, $this->area_id, PDO::PARAM_INT);
                        break;
                    case '`id_sams_study`':
                        $stmt->bindValue($identifier, $this->id_sams_study, PDO::PARAM_STR);
                        break;
                    case '`recrutement_objectif`':
                        $stmt->bindValue($identifier, $this->recrutement_objectif, PDO::PARAM_INT);
                        break;
                    case '`id_location_pnl`':
                        $stmt->bindValue($identifier, $this->id_location_pnl, PDO::PARAM_INT);
                        break;
                    case '`id_master_project_location_pnl`':
                        $stmt->bindValue($identifier, $this->id_master_project_location_pnl, PDO::PARAM_INT);
                        break;
                    case '`recrutement_objectif_pr`':
                        $stmt->bindValue($identifier, $this->recrutement_objectif_pr, PDO::PARAM_INT);
                        break;
                    case '`id_bm`':
                        $stmt->bindValue($identifier, $this->id_bm, PDO::PARAM_INT);
                        break;
                    case '`extra_info`':
                        $stmt->bindValue($identifier, $this->extra_info, PDO::PARAM_STR);
                        break;
                    case '`account_id`':
                        $stmt->bindValue($identifier, $this->account_id, PDO::PARAM_INT);
                        break;
                    case '`account_manager_id`':
                        $stmt->bindValue($identifier, $this->account_manager_id, PDO::PARAM_INT);
                        break;
                    case '`project_specialty_sponsor_id`':
                        $stmt->bindValue($identifier, $this->project_specialty_sponsor_id, PDO::PARAM_INT);
                        break;
                    case '`language`':
                        $stmt->bindValue($identifier, $this->language, PDO::PARAM_STR);
                        break;
                    case '`remise_taux`':
                        $stmt->bindValue($identifier, $this->remise_taux, PDO::PARAM_STR);
                        break;
                    case '`client_discount_percentage`':
                        $stmt->bindValue($identifier, $this->client_discount_percentage, PDO::PARAM_STR);
                        break;
                    case '`end_client_discount_percentage`':
                        $stmt->bindValue($identifier, $this->end_client_discount_percentage, PDO::PARAM_STR);
                        break;
                    case '`client_quant_discount_percentage`':
                        $stmt->bindValue($identifier, $this->client_quant_discount_percentage, PDO::PARAM_STR);
                        break;
                    case '`end_client_quant_discount_percentage`':
                        $stmt->bindValue($identifier, $this->end_client_quant_discount_percentage, PDO::PARAM_STR);
                        break;
                    case '`sample_plan`':
                        $stmt->bindValue($identifier, $this->sample_plan, PDO::PARAM_STR);
                        break;
                    case '`isToInvoice`':
                        $stmt->bindValue($identifier, (int) $this->istoinvoice, PDO::PARAM_INT);
                        break;
                    case '`file_path`':
                        $stmt->bindValue($identifier, $this->file_path, PDO::PARAM_STR);
                        break;
                    case '`account_leader_id`':
                        $stmt->bindValue($identifier, $this->account_leader_id, PDO::PARAM_INT);
                        break;
                    case '`account_pm_id`':
                        $stmt->bindValue($identifier, $this->account_pm_id, PDO::PARAM_INT);
                        break;
                    case '`am_email`':
                        $stmt->bindValue($identifier, $this->am_email, PDO::PARAM_STR);
                        break;
                    case '`client_portal_ready`':
                        $stmt->bindValue($identifier, (int) $this->client_portal_ready, PDO::PARAM_INT);
                        break;
                    case '`length_of_interview`':
                        $stmt->bindValue($identifier, $this->length_of_interview, PDO::PARAM_STR);
                        break;
                    case '`sunshine_act`':
                        $stmt->bindValue($identifier, $this->sunshine_act, PDO::PARAM_STR);
                        break;
                    case '`is_consolidated`':
                        $stmt->bindValue($identifier, (int) $this->is_consolidated, PDO::PARAM_INT);
                        break;
                    case '`sharepoint_folder`':
                        $stmt->bindValue($identifier, $this->sharepoint_folder, PDO::PARAM_STR);
                        break;
                    case '`multi_phase`':
                        $stmt->bindValue($identifier, (int) $this->multi_phase, PDO::PARAM_INT);
                        break;
                    case '`po_number`':
                        $stmt->bindValue($identifier, $this->po_number, PDO::PARAM_STR);
                        break;
                    case '`currencies`':
                        $stmt->bindValue($identifier, $this->currencies, PDO::PARAM_STR);
                        break;
                    case '`sms_relance`':
                        $stmt->bindValue($identifier, (int) $this->sms_relance, PDO::PARAM_INT);
                        break;
                    case '`id_etude_group`':
                        $stmt->bindValue($identifier, $this->id_etude_group, PDO::PARAM_INT);
                        break;
                    case '`gms`':
                        $stmt->bindValue($identifier, $this->gms, PDO::PARAM_STR);
                        break;
                    case '`kol`':
                        $stmt->bindValue($identifier, $this->kol, PDO::PARAM_STR);
                        break;
                    case '`room_rental`':
                        $stmt->bindValue($identifier, (int) $this->room_rental, PDO::PARAM_INT);
                        break;
                    case '`recruits_offsite`':
                        $stmt->bindValue($identifier, (int) $this->recruits_offsite, PDO::PARAM_INT);
                        break;
                    case '`study_specification`':
                        $stmt->bindValue($identifier, $this->study_specification, PDO::PARAM_STR);
                        break;
                    case '`is_study_specification`':
                        $stmt->bindValue($identifier, (int) $this->is_study_specification, PDO::PARAM_INT);
                        break;
                    case '`additional_notes`':
                        $stmt->bindValue($identifier, $this->additional_notes, PDO::PARAM_STR);
                        break;
                    case '`project_comment`':
                        $stmt->bindValue($identifier, $this->project_comment, PDO::PARAM_STR);
                        break;
                    case '`end_client_id`':
                        $stmt->bindValue($identifier, $this->end_client_id, PDO::PARAM_INT);
                        break;
                    case '`end_client_contact_id`':
                        $stmt->bindValue($identifier, $this->end_client_contact_id, PDO::PARAM_INT);
                        break;
                    case '`contact_id`':
                        $stmt->bindValue($identifier, $this->contact_id, PDO::PARAM_INT);
                        break;
                    case '`contact_client_pm_id`':
                        $stmt->bindValue($identifier, $this->contact_client_pm_id, PDO::PARAM_INT);
                        break;
                    case '`master_project_number`':
                        $stmt->bindValue($identifier, $this->master_project_number, PDO::PARAM_STR);
                        break;
                    case '`proposed_loi`':
                        $stmt->bindValue($identifier, $this->proposed_loi, PDO::PARAM_STR);
                        break;
                    case '`opportunity_id`':
                        $stmt->bindValue($identifier, $this->opportunity_id, PDO::PARAM_INT);
                        break;
                    case '`si_job_type_id`':
                        $stmt->bindValue($identifier, $this->si_job_type_id, PDO::PARAM_INT);
                        break;
                    case '`best_effort`':
                        $stmt->bindValue($identifier, (int) $this->best_effort, PDO::PARAM_INT);
                        break;
                    case '`job_status_sf_id`':
                        $stmt->bindValue($identifier, $this->job_status_sf_id, PDO::PARAM_INT);
                        break;
                    case '`booked_by_sf_id`':
                        $stmt->bindValue($identifier, $this->booked_by_sf_id, PDO::PARAM_STR);
                        break;
                    case '`created_by_sf_id`':
                        $stmt->bindValue($identifier, $this->created_by_sf_id, PDO::PARAM_STR);
                        break;
                    case '`account_manager_sf_id`':
                        $stmt->bindValue($identifier, $this->account_manager_sf_id, PDO::PARAM_STR);
                        break;
                    case '`created_date`':
                        $stmt->bindValue($identifier, $this->created_date ? $this->created_date->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`job_qualification_id`':
                        $stmt->bindValue($identifier, $this->job_qualification_id, PDO::PARAM_INT);
                        break;
                    case '`proposed_n`':
                        $stmt->bindValue($identifier, $this->proposed_n, PDO::PARAM_STR);
                        break;
                    case '`german_job_type_id`':
                        $stmt->bindValue($identifier, $this->german_job_type_id, PDO::PARAM_INT);
                        break;
                    case '`created_by_comment`':
                        $stmt->bindValue($identifier, $this->created_by_comment, PDO::PARAM_STR);
                        break;
                    case '`focus_vision`':
                        $stmt->bindValue($identifier, (int) $this->focus_vision, PDO::PARAM_INT);
                        break;
                    case '`si_eu_job_type`':
                        $stmt->bindValue($identifier, $this->si_eu_job_type, PDO::PARAM_INT);
                        break;
                    case '`intermediate_client_id`':
                        $stmt->bindValue($identifier, $this->intermediate_client_id, PDO::PARAM_INT);
                        break;
                    case '`intermediate_client_contact_id`':
                        $stmt->bindValue($identifier, $this->intermediate_client_contact_id, PDO::PARAM_INT);
                        break;
                    case '`us_global_qual_gms_id`':
                        $stmt->bindValue($identifier, $this->us_global_qual_gms_id, PDO::PARAM_INT);
                        break;
                    case '`facilty_note`':
                        $stmt->bindValue($identifier, $this->facilty_note, PDO::PARAM_STR);
                        break;
                    case '`currency_iso_code_id`':
                        $stmt->bindValue($identifier, $this->currency_iso_code_id, PDO::PARAM_INT);
                        break;
                    case '`client_list_deletion_id`':
                        $stmt->bindValue($identifier, $this->client_list_deletion_id, PDO::PARAM_INT);
                        break;
                    case '`created_by_id`':
                        $stmt->bindValue($identifier, $this->created_by_id, PDO::PARAM_INT);
                        break;
                    case '`updated_by_id`':
                        $stmt->bindValue($identifier, $this->updated_by_id, PDO::PARAM_INT);
                        break;
                    case '`created_at`':
                        $stmt->bindValue($identifier, $this->created_at ? $this->created_at->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                    case '`updated_at`':
                        $stmt->bindValue($identifier, $this->updated_at ? $this->updated_at->format("Y-m-d H:i:s.u") : null, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), 0, $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', 0, $e);
        }
        $this->setId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @return Integer Number of updated rows
     * @see doSave()
     */
    protected function doUpdate(ConnectionInterface $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();

        return $selectCriteria->doUpdate($valuesCriteria, $con);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param      string $name name
     * @param      string $type The type of fieldname the $name is of:
     *                     one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                     TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                     Defaults to TableMap::TYPE_PHPNAME.
     * @return mixed Value of field.
     */
    public function getByName($name, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EtudeTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param      int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getId();
                break;
            case 1:
                return $this->getNumeroEtude();
                break;
            case 2:
                return $this->getReferenceClient();
                break;
            case 3:
                return $this->getMasterProjectSfId();
                break;
            case 4:
                return $this->getTheme();
                break;
            case 5:
                return $this->getDateDebut();
                break;
            case 6:
                return $this->getDateFin();
                break;
            case 7:
                return $this->getAnnee();
                break;
            case 8:
                return $this->getRst();
                break;
            case 9:
                return $this->getCli();
                break;
            case 10:
                return $this->getGqs();
                break;
            case 11:
                return $this->getIns();
                break;
            case 12:
                return $this->getHut();
                break;
            case 13:
                return $this->getDisplayTotalOnly();
                break;
            case 14:
                return $this->getIdPm();
                break;
            case 15:
                return $this->getIdEtape();
                break;
            case 16:
                return $this->getPrixRevientInitial();
                break;
            case 17:
                return $this->getPrixRevientActualise();
                break;
            case 18:
                return $this->getPrixVenteInitial();
                break;
            case 19:
                return $this->getPrixVenteActualise();
                break;
            case 20:
                return $this->getConsolidatedInvoice();
                break;
            case 21:
                return $this->getSendCsatQuest();
                break;
            case 22:
                return $this->getIsSendCsatQuestMail();
                break;
            case 23:
                return $this->getNumeroFacture();
                break;
            case 24:
                return $this->getDontSetAmAuto();
                break;
            case 25:
                return $this->getSetAmReason();
                break;
            case 26:
                return $this->getAmReasonTypeId();
                break;
            case 27:
                return $this->getDateEnvoiFacture();
                break;
            case 28:
                return $this->getDateReglement();
                break;
            case 29:
                return $this->getCommentaire();
                break;
            case 30:
                return $this->getIndustryId();
                break;
            case 31:
                return $this->getPeriodeCutoff();
                break;
            case 32:
                return $this->getThemeBr();
                break;
            case 33:
                return $this->getAreaId();
                break;
            case 34:
                return $this->getIdSamsStudy();
                break;
            case 35:
                return $this->getRecrutementObjectif();
                break;
            case 36:
                return $this->getIdLocationPnl();
                break;
            case 37:
                return $this->getIdMasterProjectLocationPnl();
                break;
            case 38:
                return $this->getRecrutementObjectifPr();
                break;
            case 39:
                return $this->getIdBm();
                break;
            case 40:
                return $this->getExtraInfo();
                break;
            case 41:
                return $this->getAccountId();
                break;
            case 42:
                return $this->getAccountManagerId();
                break;
            case 43:
                return $this->getProjectSpecialtySponsorId();
                break;
            case 44:
                return $this->getLanguage();
                break;
            case 45:
                return $this->getRemiseTaux();
                break;
            case 46:
                return $this->getClientDiscountPercentage();
                break;
            case 47:
                return $this->getEndClientDiscountPercentage();
                break;
            case 48:
                return $this->getClientQuantDiscountPercentage();
                break;
            case 49:
                return $this->getEndClientQuantDiscountPercentage();
                break;
            case 50:
                return $this->getSamplePlan();
                break;
            case 51:
                return $this->getIsToInvoice();
                break;
            case 52:
                return $this->getFilePath();
                break;
            case 53:
                return $this->getAccountLeaderId();
                break;
            case 54:
                return $this->getAccountPMId();
                break;
            case 55:
                return $this->getAmEmail();
                break;
            case 56:
                return $this->getClientPortalReady();
                break;
            case 57:
                return $this->getLengthOfInterview();
                break;
            case 58:
                return $this->getsunshineAct();
                break;
            case 59:
                return $this->getIsConsolidated();
                break;
            case 60:
                return $this->getSharepointFolder();
                break;
            case 61:
                return $this->getMultiPhase();
                break;
            case 62:
                return $this->getPoNumber();
                break;
            case 63:
                return $this->getCurrencies();
                break;
            case 64:
                return $this->getSmsRelance();
                break;
            case 65:
                return $this->getIdEtudeGroup();
                break;
            case 66:
                return $this->getGms();
                break;
            case 67:
                return $this->getKol();
                break;
            case 68:
                return $this->getRoomRental();
                break;
            case 69:
                return $this->getRecruitsOffsite();
                break;
            case 70:
                return $this->getStudySpecification();
                break;
            case 71:
                return $this->getisStudySpecification();
                break;
            case 72:
                return $this->getAdditionalNotes();
                break;
            case 73:
                return $this->getProjectComment();
                break;
            case 74:
                return $this->getEndClientId();
                break;
            case 75:
                return $this->getEndClientContactId();
                break;
            case 76:
                return $this->getContactId();
                break;
            case 77:
                return $this->getContactClientPmId();
                break;
            case 78:
                return $this->getMasterProjectNumber();
                break;
            case 79:
                return $this->getProposedLoi();
                break;
            case 80:
                return $this->getOpportunityId();
                break;
            case 81:
                return $this->getSiJobTypeId();
                break;
            case 82:
                return $this->getBestEffort();
                break;
            case 83:
                return $this->getJobStatusSfId();
                break;
            case 84:
                return $this->getBookedBySfId();
                break;
            case 85:
                return $this->getCreatedBySfId();
                break;
            case 86:
                return $this->getAccountManagerSfId();
                break;
            case 87:
                return $this->getCreatedDate();
                break;
            case 88:
                return $this->getJobQualificationId();
                break;
            case 89:
                return $this->getProposedN();
                break;
            case 90:
                return $this->getGermanJobTypeId();
                break;
            case 91:
                return $this->getCreatedByComment();
                break;
            case 92:
                return $this->getFocusVision();
                break;
            case 93:
                return $this->getSiEuJobType();
                break;
            case 94:
                return $this->getIntermediateClientId();
                break;
            case 95:
                return $this->getIntermediateClientContactId();
                break;
            case 96:
                return $this->getUsGlobalQualGmsId();
                break;
            case 97:
                return $this->getFaciltyNote();
                break;
            case 98:
                return $this->getCurrencyIsoCodeId();
                break;
            case 99:
                return $this->getClientListDeletionId();
                break;
            case 100:
                return $this->getCreatedById();
                break;
            case 101:
                return $this->getUpdatedById();
                break;
            case 102:
                return $this->getCreatedAt();
                break;
            case 103:
                return $this->getUpdatedAt();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     *                    TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                    Defaults to TableMap::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to TRUE.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = TableMap::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {

        if (isset($alreadyDumpedObjects['Etude'][$this->hashCode()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['Etude'][$this->hashCode()] = true;
        $keys = EtudeTableMap::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getId(),
            $keys[1] => $this->getNumeroEtude(),
            $keys[2] => $this->getReferenceClient(),
            $keys[3] => $this->getMasterProjectSfId(),
            $keys[4] => $this->getTheme(),
            $keys[5] => $this->getDateDebut(),
            $keys[6] => $this->getDateFin(),
            $keys[7] => $this->getAnnee(),
            $keys[8] => $this->getRst(),
            $keys[9] => $this->getCli(),
            $keys[10] => $this->getGqs(),
            $keys[11] => $this->getIns(),
            $keys[12] => $this->getHut(),
            $keys[13] => $this->getDisplayTotalOnly(),
            $keys[14] => $this->getIdPm(),
            $keys[15] => $this->getIdEtape(),
            $keys[16] => $this->getPrixRevientInitial(),
            $keys[17] => $this->getPrixRevientActualise(),
            $keys[18] => $this->getPrixVenteInitial(),
            $keys[19] => $this->getPrixVenteActualise(),
            $keys[20] => $this->getConsolidatedInvoice(),
            $keys[21] => $this->getSendCsatQuest(),
            $keys[22] => $this->getIsSendCsatQuestMail(),
            $keys[23] => $this->getNumeroFacture(),
            $keys[24] => $this->getDontSetAmAuto(),
            $keys[25] => $this->getSetAmReason(),
            $keys[26] => $this->getAmReasonTypeId(),
            $keys[27] => $this->getDateEnvoiFacture(),
            $keys[28] => $this->getDateReglement(),
            $keys[29] => $this->getCommentaire(),
            $keys[30] => $this->getIndustryId(),
            $keys[31] => $this->getPeriodeCutoff(),
            $keys[32] => $this->getThemeBr(),
            $keys[33] => $this->getAreaId(),
            $keys[34] => $this->getIdSamsStudy(),
            $keys[35] => $this->getRecrutementObjectif(),
            $keys[36] => $this->getIdLocationPnl(),
            $keys[37] => $this->getIdMasterProjectLocationPnl(),
            $keys[38] => $this->getRecrutementObjectifPr(),
            $keys[39] => $this->getIdBm(),
            $keys[40] => $this->getExtraInfo(),
            $keys[41] => $this->getAccountId(),
            $keys[42] => $this->getAccountManagerId(),
            $keys[43] => $this->getProjectSpecialtySponsorId(),
            $keys[44] => $this->getLanguage(),
            $keys[45] => $this->getRemiseTaux(),
            $keys[46] => $this->getClientDiscountPercentage(),
            $keys[47] => $this->getEndClientDiscountPercentage(),
            $keys[48] => $this->getClientQuantDiscountPercentage(),
            $keys[49] => $this->getEndClientQuantDiscountPercentage(),
            $keys[50] => $this->getSamplePlan(),
            $keys[51] => $this->getIsToInvoice(),
            $keys[52] => $this->getFilePath(),
            $keys[53] => $this->getAccountLeaderId(),
            $keys[54] => $this->getAccountPMId(),
            $keys[55] => $this->getAmEmail(),
            $keys[56] => $this->getClientPortalReady(),
            $keys[57] => $this->getLengthOfInterview(),
            $keys[58] => $this->getsunshineAct(),
            $keys[59] => $this->getIsConsolidated(),
            $keys[60] => $this->getSharepointFolder(),
            $keys[61] => $this->getMultiPhase(),
            $keys[62] => $this->getPoNumber(),
            $keys[63] => $this->getCurrencies(),
            $keys[64] => $this->getSmsRelance(),
            $keys[65] => $this->getIdEtudeGroup(),
            $keys[66] => $this->getGms(),
            $keys[67] => $this->getKol(),
            $keys[68] => $this->getRoomRental(),
            $keys[69] => $this->getRecruitsOffsite(),
            $keys[70] => $this->getStudySpecification(),
            $keys[71] => $this->getisStudySpecification(),
            $keys[72] => $this->getAdditionalNotes(),
            $keys[73] => $this->getProjectComment(),
            $keys[74] => $this->getEndClientId(),
            $keys[75] => $this->getEndClientContactId(),
            $keys[76] => $this->getContactId(),
            $keys[77] => $this->getContactClientPmId(),
            $keys[78] => $this->getMasterProjectNumber(),
            $keys[79] => $this->getProposedLoi(),
            $keys[80] => $this->getOpportunityId(),
            $keys[81] => $this->getSiJobTypeId(),
            $keys[82] => $this->getBestEffort(),
            $keys[83] => $this->getJobStatusSfId(),
            $keys[84] => $this->getBookedBySfId(),
            $keys[85] => $this->getCreatedBySfId(),
            $keys[86] => $this->getAccountManagerSfId(),
            $keys[87] => $this->getCreatedDate(),
            $keys[88] => $this->getJobQualificationId(),
            $keys[89] => $this->getProposedN(),
            $keys[90] => $this->getGermanJobTypeId(),
            $keys[91] => $this->getCreatedByComment(),
            $keys[92] => $this->getFocusVision(),
            $keys[93] => $this->getSiEuJobType(),
            $keys[94] => $this->getIntermediateClientId(),
            $keys[95] => $this->getIntermediateClientContactId(),
            $keys[96] => $this->getUsGlobalQualGmsId(),
            $keys[97] => $this->getFaciltyNote(),
            $keys[98] => $this->getCurrencyIsoCodeId(),
            $keys[99] => $this->getClientListDeletionId(),
            $keys[100] => $this->getCreatedById(),
            $keys[101] => $this->getUpdatedById(),
            $keys[102] => $this->getCreatedAt(),
            $keys[103] => $this->getUpdatedAt(),
        );
        if ($result[$keys[5]] instanceof \DateTimeInterface) {
            $result[$keys[5]] = $result[$keys[5]]->format('Y-m-d');
        }

        if ($result[$keys[6]] instanceof \DateTimeInterface) {
            $result[$keys[6]] = $result[$keys[6]]->format('Y-m-d');
        }

        if ($result[$keys[27]] instanceof \DateTimeInterface) {
            $result[$keys[27]] = $result[$keys[27]]->format('Y-m-d');
        }

        if ($result[$keys[28]] instanceof \DateTimeInterface) {
            $result[$keys[28]] = $result[$keys[28]]->format('Y-m-d');
        }

        if ($result[$keys[87]] instanceof \DateTimeInterface) {
            $result[$keys[87]] = $result[$keys[87]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[102]] instanceof \DateTimeInterface) {
            $result[$keys[102]] = $result[$keys[102]]->format('Y-m-d H:i:s.u');
        }

        if ($result[$keys[103]] instanceof \DateTimeInterface) {
            $result[$keys[103]] = $result[$keys[103]]->format('Y-m-d H:i:s.u');
        }

        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aUsGlobalQualGms) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'UsGlobalQualGms';
                }

                $result[$key] = $this->aUsGlobalQualGms->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAccountLeader) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'AccountLeader';
                }

                $result[$key] = $this->aAccountLeader->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAccountPM) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'AccountPM';
                }

                $result[$key] = $this->aAccountPM->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aIntermediateClient) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'account';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_account';
                        break;
                    default:
                        $key = 'IntermediateClient';
                }

                $result[$key] = $this->aIntermediateClient->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtape) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etape';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_etape';
                        break;
                    default:
                        $key = 'Etape';
                }

                $result[$key] = $this->aEtape->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aContact) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'contact';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_contact';
                        break;
                    default:
                        $key = 'Contact';
                }

                $result[$key] = $this->aContact->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aOpportunity) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'opportunity';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_opportunity';
                        break;
                    default:
                        $key = 'Opportunity';
                }

                $result[$key] = $this->aOpportunity->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aJobStatusSf) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'JobStatusSf';
                }

                $result[$key] = $this->aJobStatusSf->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aJobQualification) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'JobQualification';
                }

                $result[$key] = $this->aJobQualification->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aSiJobType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'siJobType';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_si_job_type';
                        break;
                    default:
                        $key = 'SiJobType';
                }

                $result[$key] = $this->aSiJobType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEndClientContact) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'contact';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_contact';
                        break;
                    default:
                        $key = 'EndClientContact';
                }

                $result[$key] = $this->aEndClientContact->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aGermanJobType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'GermanJobType';
                }

                $result[$key] = $this->aGermanJobType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEndClient) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'account';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_account';
                        break;
                    default:
                        $key = 'EndClient';
                }

                $result[$key] = $this->aEndClient->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAccount) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'account';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_account';
                        break;
                    default:
                        $key = 'Account';
                }

                $result[$key] = $this->aAccount->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aIndustry) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'industry';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_industry';
                        break;
                    default:
                        $key = 'Industry';
                }

                $result[$key] = $this->aIndustry->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtudeLocation) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'location';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_location';
                        break;
                    default:
                        $key = 'EtudeLocation';
                }

                $result[$key] = $this->aEtudeLocation->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aProjectLocationPrefix) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'projectLocationPrefix';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'project_location_prefix';
                        break;
                    default:
                        $key = 'ProjectLocationPrefix';
                }

                $result[$key] = $this->aProjectLocationPrefix->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aContactClientPm) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'contact';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_contact';
                        break;
                    default:
                        $key = 'ContactClientPm';
                }

                $result[$key] = $this->aContactClientPm->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aBM) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'BM';
                }

                $result[$key] = $this->aBM->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtudeProjectManager) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'EtudeProjectManager';
                }

                $result[$key] = $this->aEtudeProjectManager->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtudeGroup) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeGroup';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_group';
                        break;
                    default:
                        $key = 'EtudeGroup';
                }

                $result[$key] = $this->aEtudeGroup->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtudeArea) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'area';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_area';
                        break;
                    default:
                        $key = 'EtudeArea';
                }

                $result[$key] = $this->aEtudeArea->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aCurrencyIsoCode) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'CurrencyIsoCode';
                }

                $result[$key] = $this->aCurrencyIsoCode->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aClientListDeletion) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForce';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce';
                        break;
                    default:
                        $key = 'ClientListDeletion';
                }

                $result[$key] = $this->aClientListDeletion->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aCreatedBy) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'CreatedBy';
                }

                $result[$key] = $this->aCreatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aUpdatedBy) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'UpdatedBy';
                }

                $result[$key] = $this->aUpdatedBy->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aIntermediateClientContact) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'contact';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_contact';
                        break;
                    default:
                        $key = 'IntermediateClientContact';
                }

                $result[$key] = $this->aIntermediateClientContact->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aProjectAccountManager) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'ProjectAccountManager';
                }

                $result[$key] = $this->aProjectAccountManager->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aProjectSpecialtySponsor) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'user';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'user';
                        break;
                    default:
                        $key = 'ProjectSpecialtySponsor';
                }

                $result[$key] = $this->aProjectSpecialtySponsor->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aAmReasonType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'amReasonType';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'am_reason_type';
                        break;
                    default:
                        $key = 'AmReasonType';
                }

                $result[$key] = $this->aAmReasonType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collDernierAccess) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'dernierAccess';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'dernier_access';
                        break;
                    default:
                        $key = 'DernierAccess';
                }

                $result[$key] = $this->collDernierAccess->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEtudeSampleSources) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeSampleSources';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_sample_sources';
                        break;
                    default:
                        $key = 'EtudeSampleSources';
                }

                $result[$key] = $this->collEtudeSampleSources->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEtudeMethodologies) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeMethodologies';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_methodologies';
                        break;
                    default:
                        $key = 'EtudeMethodologies';
                }

                $result[$key] = $this->collEtudeMethodologies->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collFactures) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'factures';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'factures';
                        break;
                    default:
                        $key = 'Factures';
                }

                $result[$key] = $this->collFactures->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collJobEtudes) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'jobs';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'jobs';
                        break;
                    default:
                        $key = 'JobEtudes';
                }

                $result[$key] = $this->collJobEtudes->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collReglements) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'reglements';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'reglements';
                        break;
                    default:
                        $key = 'Reglements';
                }

                $result[$key] = $this->collReglements->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collSectors) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'refSalesForceEtudeSectors';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'sf_ref_salesforce_etude_sectors';
                        break;
                    default:
                        $key = 'Sectors';
                }

                $result[$key] = $this->collSectors->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEtudeCheckListValidations) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeCheckListValidations';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_checklist_validations';
                        break;
                    default:
                        $key = 'EtudeCheckListValidations';
                }

                $result[$key] = $this->collEtudeCheckListValidations->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collEtudeFichiers) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeFichiers';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_fichiers';
                        break;
                    default:
                        $key = 'EtudeFichiers';
                }

                $result[$key] = $this->collEtudeFichiers->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
            if (null !== $this->collLogProjectStatuses) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'logProjectStatuses';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'log_project_statuses';
                        break;
                    default:
                        $key = 'LogProjectStatuses';
                }

                $result[$key] = $this->collLogProjectStatuses->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param  string $name
     * @param  mixed  $value field value
     * @param  string $type The type of fieldname the $name is of:
     *                one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                Defaults to TableMap::TYPE_PHPNAME.
     * @return $this|\Model\Etude
     */
    public function setByName($name, $value, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EtudeTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);

        return $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param  int $pos position in xml schema
     * @param  mixed $value field value
     * @return $this|\Model\Etude
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setId($value);
                break;
            case 1:
                $this->setNumeroEtude($value);
                break;
            case 2:
                $this->setReferenceClient($value);
                break;
            case 3:
                $this->setMasterProjectSfId($value);
                break;
            case 4:
                $this->setTheme($value);
                break;
            case 5:
                $this->setDateDebut($value);
                break;
            case 6:
                $this->setDateFin($value);
                break;
            case 7:
                $this->setAnnee($value);
                break;
            case 8:
                $this->setRst($value);
                break;
            case 9:
                $this->setCli($value);
                break;
            case 10:
                $this->setGqs($value);
                break;
            case 11:
                $this->setIns($value);
                break;
            case 12:
                $this->setHut($value);
                break;
            case 13:
                $this->setDisplayTotalOnly($value);
                break;
            case 14:
                $this->setIdPm($value);
                break;
            case 15:
                $this->setIdEtape($value);
                break;
            case 16:
                $this->setPrixRevientInitial($value);
                break;
            case 17:
                $this->setPrixRevientActualise($value);
                break;
            case 18:
                $this->setPrixVenteInitial($value);
                break;
            case 19:
                $this->setPrixVenteActualise($value);
                break;
            case 20:
                $this->setConsolidatedInvoice($value);
                break;
            case 21:
                $this->setSendCsatQuest($value);
                break;
            case 22:
                $this->setIsSendCsatQuestMail($value);
                break;
            case 23:
                $this->setNumeroFacture($value);
                break;
            case 24:
                $this->setDontSetAmAuto($value);
                break;
            case 25:
                $this->setSetAmReason($value);
                break;
            case 26:
                $this->setAmReasonTypeId($value);
                break;
            case 27:
                $this->setDateEnvoiFacture($value);
                break;
            case 28:
                $this->setDateReglement($value);
                break;
            case 29:
                $this->setCommentaire($value);
                break;
            case 30:
                $this->setIndustryId($value);
                break;
            case 31:
                $this->setPeriodeCutoff($value);
                break;
            case 32:
                $this->setThemeBr($value);
                break;
            case 33:
                $this->setAreaId($value);
                break;
            case 34:
                $this->setIdSamsStudy($value);
                break;
            case 35:
                $this->setRecrutementObjectif($value);
                break;
            case 36:
                $this->setIdLocationPnl($value);
                break;
            case 37:
                $this->setIdMasterProjectLocationPnl($value);
                break;
            case 38:
                $this->setRecrutementObjectifPr($value);
                break;
            case 39:
                $this->setIdBm($value);
                break;
            case 40:
                $this->setExtraInfo($value);
                break;
            case 41:
                $this->setAccountId($value);
                break;
            case 42:
                $this->setAccountManagerId($value);
                break;
            case 43:
                $this->setProjectSpecialtySponsorId($value);
                break;
            case 44:
                $this->setLanguage($value);
                break;
            case 45:
                $this->setRemiseTaux($value);
                break;
            case 46:
                $this->setClientDiscountPercentage($value);
                break;
            case 47:
                $this->setEndClientDiscountPercentage($value);
                break;
            case 48:
                $this->setClientQuantDiscountPercentage($value);
                break;
            case 49:
                $this->setEndClientQuantDiscountPercentage($value);
                break;
            case 50:
                $this->setSamplePlan($value);
                break;
            case 51:
                $this->setIsToInvoice($value);
                break;
            case 52:
                $this->setFilePath($value);
                break;
            case 53:
                $this->setAccountLeaderId($value);
                break;
            case 54:
                $this->setAccountPMId($value);
                break;
            case 55:
                $this->setAmEmail($value);
                break;
            case 56:
                $this->setClientPortalReady($value);
                break;
            case 57:
                $this->setLengthOfInterview($value);
                break;
            case 58:
                $this->setsunshineAct($value);
                break;
            case 59:
                $this->setIsConsolidated($value);
                break;
            case 60:
                $this->setSharepointFolder($value);
                break;
            case 61:
                $this->setMultiPhase($value);
                break;
            case 62:
                $this->setPoNumber($value);
                break;
            case 63:
                $this->setCurrencies($value);
                break;
            case 64:
                $this->setSmsRelance($value);
                break;
            case 65:
                $this->setIdEtudeGroup($value);
                break;
            case 66:
                $this->setGms($value);
                break;
            case 67:
                $this->setKol($value);
                break;
            case 68:
                $this->setRoomRental($value);
                break;
            case 69:
                $this->setRecruitsOffsite($value);
                break;
            case 70:
                $this->setStudySpecification($value);
                break;
            case 71:
                $this->setisStudySpecification($value);
                break;
            case 72:
                $this->setAdditionalNotes($value);
                break;
            case 73:
                $this->setProjectComment($value);
                break;
            case 74:
                $this->setEndClientId($value);
                break;
            case 75:
                $this->setEndClientContactId($value);
                break;
            case 76:
                $this->setContactId($value);
                break;
            case 77:
                $this->setContactClientPmId($value);
                break;
            case 78:
                $this->setMasterProjectNumber($value);
                break;
            case 79:
                $this->setProposedLoi($value);
                break;
            case 80:
                $this->setOpportunityId($value);
                break;
            case 81:
                $this->setSiJobTypeId($value);
                break;
            case 82:
                $this->setBestEffort($value);
                break;
            case 83:
                $this->setJobStatusSfId($value);
                break;
            case 84:
                $this->setBookedBySfId($value);
                break;
            case 85:
                $this->setCreatedBySfId($value);
                break;
            case 86:
                $this->setAccountManagerSfId($value);
                break;
            case 87:
                $this->setCreatedDate($value);
                break;
            case 88:
                $this->setJobQualificationId($value);
                break;
            case 89:
                $this->setProposedN($value);
                break;
            case 90:
                $this->setGermanJobTypeId($value);
                break;
            case 91:
                $this->setCreatedByComment($value);
                break;
            case 92:
                $this->setFocusVision($value);
                break;
            case 93:
                $valueSet = EtudeTableMap::getValueSet(EtudeTableMap::COL_SI_EU_JOB_TYPE);
                if (isset($valueSet[$value])) {
                    $value = $valueSet[$value];
                }
                $this->setSiEuJobType($value);
                break;
            case 94:
                $this->setIntermediateClientId($value);
                break;
            case 95:
                $this->setIntermediateClientContactId($value);
                break;
            case 96:
                $this->setUsGlobalQualGmsId($value);
                break;
            case 97:
                $this->setFaciltyNote($value);
                break;
            case 98:
                $this->setCurrencyIsoCodeId($value);
                break;
            case 99:
                $this->setClientListDeletionId($value);
                break;
            case 100:
                $this->setCreatedById($value);
                break;
            case 101:
                $this->setUpdatedById($value);
                break;
            case 102:
                $this->setCreatedAt($value);
                break;
            case 103:
                $this->setUpdatedAt($value);
                break;
        } // switch()

        return $this;
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param      array  $arr     An array to populate the object from.
     * @param      string $keyType The type of keys the array uses.
     * @return     $this|\Model\Etude
     */
    public function fromArray($arr, $keyType = TableMap::TYPE_PHPNAME)
    {
        $keys = EtudeTableMap::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) {
            $this->setId($arr[$keys[0]]);
        }
        if (array_key_exists($keys[1], $arr)) {
            $this->setNumeroEtude($arr[$keys[1]]);
        }
        if (array_key_exists($keys[2], $arr)) {
            $this->setReferenceClient($arr[$keys[2]]);
        }
        if (array_key_exists($keys[3], $arr)) {
            $this->setMasterProjectSfId($arr[$keys[3]]);
        }
        if (array_key_exists($keys[4], $arr)) {
            $this->setTheme($arr[$keys[4]]);
        }
        if (array_key_exists($keys[5], $arr)) {
            $this->setDateDebut($arr[$keys[5]]);
        }
        if (array_key_exists($keys[6], $arr)) {
            $this->setDateFin($arr[$keys[6]]);
        }
        if (array_key_exists($keys[7], $arr)) {
            $this->setAnnee($arr[$keys[7]]);
        }
        if (array_key_exists($keys[8], $arr)) {
            $this->setRst($arr[$keys[8]]);
        }
        if (array_key_exists($keys[9], $arr)) {
            $this->setCli($arr[$keys[9]]);
        }
        if (array_key_exists($keys[10], $arr)) {
            $this->setGqs($arr[$keys[10]]);
        }
        if (array_key_exists($keys[11], $arr)) {
            $this->setIns($arr[$keys[11]]);
        }
        if (array_key_exists($keys[12], $arr)) {
            $this->setHut($arr[$keys[12]]);
        }
        if (array_key_exists($keys[13], $arr)) {
            $this->setDisplayTotalOnly($arr[$keys[13]]);
        }
        if (array_key_exists($keys[14], $arr)) {
            $this->setIdPm($arr[$keys[14]]);
        }
        if (array_key_exists($keys[15], $arr)) {
            $this->setIdEtape($arr[$keys[15]]);
        }
        if (array_key_exists($keys[16], $arr)) {
            $this->setPrixRevientInitial($arr[$keys[16]]);
        }
        if (array_key_exists($keys[17], $arr)) {
            $this->setPrixRevientActualise($arr[$keys[17]]);
        }
        if (array_key_exists($keys[18], $arr)) {
            $this->setPrixVenteInitial($arr[$keys[18]]);
        }
        if (array_key_exists($keys[19], $arr)) {
            $this->setPrixVenteActualise($arr[$keys[19]]);
        }
        if (array_key_exists($keys[20], $arr)) {
            $this->setConsolidatedInvoice($arr[$keys[20]]);
        }
        if (array_key_exists($keys[21], $arr)) {
            $this->setSendCsatQuest($arr[$keys[21]]);
        }
        if (array_key_exists($keys[22], $arr)) {
            $this->setIsSendCsatQuestMail($arr[$keys[22]]);
        }
        if (array_key_exists($keys[23], $arr)) {
            $this->setNumeroFacture($arr[$keys[23]]);
        }
        if (array_key_exists($keys[24], $arr)) {
            $this->setDontSetAmAuto($arr[$keys[24]]);
        }
        if (array_key_exists($keys[25], $arr)) {
            $this->setSetAmReason($arr[$keys[25]]);
        }
        if (array_key_exists($keys[26], $arr)) {
            $this->setAmReasonTypeId($arr[$keys[26]]);
        }
        if (array_key_exists($keys[27], $arr)) {
            $this->setDateEnvoiFacture($arr[$keys[27]]);
        }
        if (array_key_exists($keys[28], $arr)) {
            $this->setDateReglement($arr[$keys[28]]);
        }
        if (array_key_exists($keys[29], $arr)) {
            $this->setCommentaire($arr[$keys[29]]);
        }
        if (array_key_exists($keys[30], $arr)) {
            $this->setIndustryId($arr[$keys[30]]);
        }
        if (array_key_exists($keys[31], $arr)) {
            $this->setPeriodeCutoff($arr[$keys[31]]);
        }
        if (array_key_exists($keys[32], $arr)) {
            $this->setThemeBr($arr[$keys[32]]);
        }
        if (array_key_exists($keys[33], $arr)) {
            $this->setAreaId($arr[$keys[33]]);
        }
        if (array_key_exists($keys[34], $arr)) {
            $this->setIdSamsStudy($arr[$keys[34]]);
        }
        if (array_key_exists($keys[35], $arr)) {
            $this->setRecrutementObjectif($arr[$keys[35]]);
        }
        if (array_key_exists($keys[36], $arr)) {
            $this->setIdLocationPnl($arr[$keys[36]]);
        }
        if (array_key_exists($keys[37], $arr)) {
            $this->setIdMasterProjectLocationPnl($arr[$keys[37]]);
        }
        if (array_key_exists($keys[38], $arr)) {
            $this->setRecrutementObjectifPr($arr[$keys[38]]);
        }
        if (array_key_exists($keys[39], $arr)) {
            $this->setIdBm($arr[$keys[39]]);
        }
        if (array_key_exists($keys[40], $arr)) {
            $this->setExtraInfo($arr[$keys[40]]);
        }
        if (array_key_exists($keys[41], $arr)) {
            $this->setAccountId($arr[$keys[41]]);
        }
        if (array_key_exists($keys[42], $arr)) {
            $this->setAccountManagerId($arr[$keys[42]]);
        }
        if (array_key_exists($keys[43], $arr)) {
            $this->setProjectSpecialtySponsorId($arr[$keys[43]]);
        }
        if (array_key_exists($keys[44], $arr)) {
            $this->setLanguage($arr[$keys[44]]);
        }
        if (array_key_exists($keys[45], $arr)) {
            $this->setRemiseTaux($arr[$keys[45]]);
        }
        if (array_key_exists($keys[46], $arr)) {
            $this->setClientDiscountPercentage($arr[$keys[46]]);
        }
        if (array_key_exists($keys[47], $arr)) {
            $this->setEndClientDiscountPercentage($arr[$keys[47]]);
        }
        if (array_key_exists($keys[48], $arr)) {
            $this->setClientQuantDiscountPercentage($arr[$keys[48]]);
        }
        if (array_key_exists($keys[49], $arr)) {
            $this->setEndClientQuantDiscountPercentage($arr[$keys[49]]);
        }
        if (array_key_exists($keys[50], $arr)) {
            $this->setSamplePlan($arr[$keys[50]]);
        }
        if (array_key_exists($keys[51], $arr)) {
            $this->setIsToInvoice($arr[$keys[51]]);
        }
        if (array_key_exists($keys[52], $arr)) {
            $this->setFilePath($arr[$keys[52]]);
        }
        if (array_key_exists($keys[53], $arr)) {
            $this->setAccountLeaderId($arr[$keys[53]]);
        }
        if (array_key_exists($keys[54], $arr)) {
            $this->setAccountPMId($arr[$keys[54]]);
        }
        if (array_key_exists($keys[55], $arr)) {
            $this->setAmEmail($arr[$keys[55]]);
        }
        if (array_key_exists($keys[56], $arr)) {
            $this->setClientPortalReady($arr[$keys[56]]);
        }
        if (array_key_exists($keys[57], $arr)) {
            $this->setLengthOfInterview($arr[$keys[57]]);
        }
        if (array_key_exists($keys[58], $arr)) {
            $this->setsunshineAct($arr[$keys[58]]);
        }
        if (array_key_exists($keys[59], $arr)) {
            $this->setIsConsolidated($arr[$keys[59]]);
        }
        if (array_key_exists($keys[60], $arr)) {
            $this->setSharepointFolder($arr[$keys[60]]);
        }
        if (array_key_exists($keys[61], $arr)) {
            $this->setMultiPhase($arr[$keys[61]]);
        }
        if (array_key_exists($keys[62], $arr)) {
            $this->setPoNumber($arr[$keys[62]]);
        }
        if (array_key_exists($keys[63], $arr)) {
            $this->setCurrencies($arr[$keys[63]]);
        }
        if (array_key_exists($keys[64], $arr)) {
            $this->setSmsRelance($arr[$keys[64]]);
        }
        if (array_key_exists($keys[65], $arr)) {
            $this->setIdEtudeGroup($arr[$keys[65]]);
        }
        if (array_key_exists($keys[66], $arr)) {
            $this->setGms($arr[$keys[66]]);
        }
        if (array_key_exists($keys[67], $arr)) {
            $this->setKol($arr[$keys[67]]);
        }
        if (array_key_exists($keys[68], $arr)) {
            $this->setRoomRental($arr[$keys[68]]);
        }
        if (array_key_exists($keys[69], $arr)) {
            $this->setRecruitsOffsite($arr[$keys[69]]);
        }
        if (array_key_exists($keys[70], $arr)) {
            $this->setStudySpecification($arr[$keys[70]]);
        }
        if (array_key_exists($keys[71], $arr)) {
            $this->setisStudySpecification($arr[$keys[71]]);
        }
        if (array_key_exists($keys[72], $arr)) {
            $this->setAdditionalNotes($arr[$keys[72]]);
        }
        if (array_key_exists($keys[73], $arr)) {
            $this->setProjectComment($arr[$keys[73]]);
        }
        if (array_key_exists($keys[74], $arr)) {
            $this->setEndClientId($arr[$keys[74]]);
        }
        if (array_key_exists($keys[75], $arr)) {
            $this->setEndClientContactId($arr[$keys[75]]);
        }
        if (array_key_exists($keys[76], $arr)) {
            $this->setContactId($arr[$keys[76]]);
        }
        if (array_key_exists($keys[77], $arr)) {
            $this->setContactClientPmId($arr[$keys[77]]);
        }
        if (array_key_exists($keys[78], $arr)) {
            $this->setMasterProjectNumber($arr[$keys[78]]);
        }
        if (array_key_exists($keys[79], $arr)) {
            $this->setProposedLoi($arr[$keys[79]]);
        }
        if (array_key_exists($keys[80], $arr)) {
            $this->setOpportunityId($arr[$keys[80]]);
        }
        if (array_key_exists($keys[81], $arr)) {
            $this->setSiJobTypeId($arr[$keys[81]]);
        }
        if (array_key_exists($keys[82], $arr)) {
            $this->setBestEffort($arr[$keys[82]]);
        }
        if (array_key_exists($keys[83], $arr)) {
            $this->setJobStatusSfId($arr[$keys[83]]);
        }
        if (array_key_exists($keys[84], $arr)) {
            $this->setBookedBySfId($arr[$keys[84]]);
        }
        if (array_key_exists($keys[85], $arr)) {
            $this->setCreatedBySfId($arr[$keys[85]]);
        }
        if (array_key_exists($keys[86], $arr)) {
            $this->setAccountManagerSfId($arr[$keys[86]]);
        }
        if (array_key_exists($keys[87], $arr)) {
            $this->setCreatedDate($arr[$keys[87]]);
        }
        if (array_key_exists($keys[88], $arr)) {
            $this->setJobQualificationId($arr[$keys[88]]);
        }
        if (array_key_exists($keys[89], $arr)) {
            $this->setProposedN($arr[$keys[89]]);
        }
        if (array_key_exists($keys[90], $arr)) {
            $this->setGermanJobTypeId($arr[$keys[90]]);
        }
        if (array_key_exists($keys[91], $arr)) {
            $this->setCreatedByComment($arr[$keys[91]]);
        }
        if (array_key_exists($keys[92], $arr)) {
            $this->setFocusVision($arr[$keys[92]]);
        }
        if (array_key_exists($keys[93], $arr)) {
            $this->setSiEuJobType($arr[$keys[93]]);
        }
        if (array_key_exists($keys[94], $arr)) {
            $this->setIntermediateClientId($arr[$keys[94]]);
        }
        if (array_key_exists($keys[95], $arr)) {
            $this->setIntermediateClientContactId($arr[$keys[95]]);
        }
        if (array_key_exists($keys[96], $arr)) {
            $this->setUsGlobalQualGmsId($arr[$keys[96]]);
        }
        if (array_key_exists($keys[97], $arr)) {
            $this->setFaciltyNote($arr[$keys[97]]);
        }
        if (array_key_exists($keys[98], $arr)) {
            $this->setCurrencyIsoCodeId($arr[$keys[98]]);
        }
        if (array_key_exists($keys[99], $arr)) {
            $this->setClientListDeletionId($arr[$keys[99]]);
        }
        if (array_key_exists($keys[100], $arr)) {
            $this->setCreatedById($arr[$keys[100]]);
        }
        if (array_key_exists($keys[101], $arr)) {
            $this->setUpdatedById($arr[$keys[101]]);
        }
        if (array_key_exists($keys[102], $arr)) {
            $this->setCreatedAt($arr[$keys[102]]);
        }
        if (array_key_exists($keys[103], $arr)) {
            $this->setUpdatedAt($arr[$keys[103]]);
        }

        return $this;
    }

     /**
     * Populate the current object from a string, using a given parser format
     * <code>
     * $book = new Book();
     * $book->importFrom('JSON', '{"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param mixed $parser A AbstractParser instance,
     *                       or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param string $data The source data to import from
     * @param string $keyType The type of keys the array uses.
     *
     * @return $this|\Model\Etude The current object, for fluid interface
     */
    public function importFrom($parser, $data, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        $this->fromArray($parser->toArray($data), $keyType);

        return $this;
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(EtudeTableMap::DATABASE_NAME);

        if ($this->isColumnModified(EtudeTableMap::COL_ID)) {
            $criteria->add(EtudeTableMap::COL_ID, $this->id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_NUMERO_ETUDE)) {
            $criteria->add(EtudeTableMap::COL_NUMERO_ETUDE, $this->numero_etude);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_REFERENCE_CLIENT)) {
            $criteria->add(EtudeTableMap::COL_REFERENCE_CLIENT, $this->reference_client);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MASTER_PROJECT_SF_ID)) {
            $criteria->add(EtudeTableMap::COL_MASTER_PROJECT_SF_ID, $this->master_project_sf_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_THEME)) {
            $criteria->add(EtudeTableMap::COL_THEME, $this->theme);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_DEBUT)) {
            $criteria->add(EtudeTableMap::COL_DATE_DEBUT, $this->date_debut);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_FIN)) {
            $criteria->add(EtudeTableMap::COL_DATE_FIN, $this->date_fin);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ANNEE)) {
            $criteria->add(EtudeTableMap::COL_ANNEE, $this->annee);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RST)) {
            $criteria->add(EtudeTableMap::COL_RST, $this->rst);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLI)) {
            $criteria->add(EtudeTableMap::COL_CLI, $this->cli);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GQS)) {
            $criteria->add(EtudeTableMap::COL_GQS, $this->gqs);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INS)) {
            $criteria->add(EtudeTableMap::COL_INS, $this->ins);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_HUT)) {
            $criteria->add(EtudeTableMap::COL_HUT, $this->hut);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY)) {
            $criteria->add(EtudeTableMap::COL_DISPLAY_TOTAL_ONLY, $this->display_total_only);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_PM)) {
            $criteria->add(EtudeTableMap::COL_ID_PM, $this->id_pm);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_ETAPE)) {
            $criteria->add(EtudeTableMap::COL_ID_ETAPE, $this->id_etape);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_REVIENT_INITIAL)) {
            $criteria->add(EtudeTableMap::COL_PRIX_REVIENT_INITIAL, $this->prix_revient_initial);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE)) {
            $criteria->add(EtudeTableMap::COL_PRIX_REVIENT_ACTUALISE, $this->prix_revient_actualise);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_VENTE_INITIAL)) {
            $criteria->add(EtudeTableMap::COL_PRIX_VENTE_INITIAL, $this->prix_vente_initial);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE)) {
            $criteria->add(EtudeTableMap::COL_PRIX_VENTE_ACTUALISE, $this->prix_vente_actualise);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONSOLIDATED_INVOICE)) {
            $criteria->add(EtudeTableMap::COL_CONSOLIDATED_INVOICE, $this->consolidated_invoice);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SEND_CSAT_QUEST)) {
            $criteria->add(EtudeTableMap::COL_SEND_CSAT_QUEST, $this->send_csat_quest);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL)) {
            $criteria->add(EtudeTableMap::COL_IS_SEND_CSAT_QUEST_MAIL, $this->is_send_csat_quest_mail);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_NUMERO_FACTURE)) {
            $criteria->add(EtudeTableMap::COL_NUMERO_FACTURE, $this->numero_facture);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DONT_SET_AM_AUTO)) {
            $criteria->add(EtudeTableMap::COL_DONT_SET_AM_AUTO, $this->dont_set_am_auto);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SET_AM_REASON)) {
            $criteria->add(EtudeTableMap::COL_SET_AM_REASON, $this->set_am_reason);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AM_REASON_TYPE_ID)) {
            $criteria->add(EtudeTableMap::COL_AM_REASON_TYPE_ID, $this->am_reason_type_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_ENVOI_FACTURE)) {
            $criteria->add(EtudeTableMap::COL_DATE_ENVOI_FACTURE, $this->date_envoi_facture);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_DATE_REGLEMENT)) {
            $criteria->add(EtudeTableMap::COL_DATE_REGLEMENT, $this->date_reglement);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_COMMENTAIRE)) {
            $criteria->add(EtudeTableMap::COL_COMMENTAIRE, $this->commentaire);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INDUSTRY_ID)) {
            $criteria->add(EtudeTableMap::COL_INDUSTRY_ID, $this->industry_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PERIODE_CUTOFF)) {
            $criteria->add(EtudeTableMap::COL_PERIODE_CUTOFF, $this->periode_cutoff);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_THEME_BR)) {
            $criteria->add(EtudeTableMap::COL_THEME_BR, $this->theme_br);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AREA_ID)) {
            $criteria->add(EtudeTableMap::COL_AREA_ID, $this->area_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_SAMS_STUDY)) {
            $criteria->add(EtudeTableMap::COL_ID_SAMS_STUDY, $this->id_sams_study);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF)) {
            $criteria->add(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF, $this->recrutement_objectif);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_LOCATION_PNL)) {
            $criteria->add(EtudeTableMap::COL_ID_LOCATION_PNL, $this->id_location_pnl);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL)) {
            $criteria->add(EtudeTableMap::COL_ID_MASTER_PROJECT_LOCATION_PNL, $this->id_master_project_location_pnl);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR)) {
            $criteria->add(EtudeTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $this->recrutement_objectif_pr);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_BM)) {
            $criteria->add(EtudeTableMap::COL_ID_BM, $this->id_bm);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_EXTRA_INFO)) {
            $criteria->add(EtudeTableMap::COL_EXTRA_INFO, $this->extra_info);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_ID)) {
            $criteria->add(EtudeTableMap::COL_ACCOUNT_ID, $this->account_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_MANAGER_ID)) {
            $criteria->add(EtudeTableMap::COL_ACCOUNT_MANAGER_ID, $this->account_manager_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID)) {
            $criteria->add(EtudeTableMap::COL_PROJECT_SPECIALTY_SPONSOR_ID, $this->project_specialty_sponsor_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_LANGUAGE)) {
            $criteria->add(EtudeTableMap::COL_LANGUAGE, $this->language);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_REMISE_TAUX)) {
            $criteria->add(EtudeTableMap::COL_REMISE_TAUX, $this->remise_taux);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE)) {
            $criteria->add(EtudeTableMap::COL_CLIENT_DISCOUNT_PERCENTAGE, $this->client_discount_percentage);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE)) {
            $criteria->add(EtudeTableMap::COL_END_CLIENT_DISCOUNT_PERCENTAGE, $this->end_client_discount_percentage);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE)) {
            $criteria->add(EtudeTableMap::COL_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $this->client_quant_discount_percentage);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE)) {
            $criteria->add(EtudeTableMap::COL_END_CLIENT_QUANT_DISCOUNT_PERCENTAGE, $this->end_client_quant_discount_percentage);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SAMPLE_PLAN)) {
            $criteria->add(EtudeTableMap::COL_SAMPLE_PLAN, $this->sample_plan);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ISTOINVOICE)) {
            $criteria->add(EtudeTableMap::COL_ISTOINVOICE, $this->istoinvoice);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FILE_PATH)) {
            $criteria->add(EtudeTableMap::COL_FILE_PATH, $this->file_path);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_LEADER_ID)) {
            $criteria->add(EtudeTableMap::COL_ACCOUNT_LEADER_ID, $this->account_leader_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_PM_ID)) {
            $criteria->add(EtudeTableMap::COL_ACCOUNT_PM_ID, $this->account_pm_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_AM_EMAIL)) {
            $criteria->add(EtudeTableMap::COL_AM_EMAIL, $this->am_email);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_PORTAL_READY)) {
            $criteria->add(EtudeTableMap::COL_CLIENT_PORTAL_READY, $this->client_portal_ready);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_LENGTH_OF_INTERVIEW)) {
            $criteria->add(EtudeTableMap::COL_LENGTH_OF_INTERVIEW, $this->length_of_interview);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SUNSHINE_ACT)) {
            $criteria->add(EtudeTableMap::COL_SUNSHINE_ACT, $this->sunshine_act);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_CONSOLIDATED)) {
            $criteria->add(EtudeTableMap::COL_IS_CONSOLIDATED, $this->is_consolidated);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SHAREPOINT_FOLDER)) {
            $criteria->add(EtudeTableMap::COL_SHAREPOINT_FOLDER, $this->sharepoint_folder);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MULTI_PHASE)) {
            $criteria->add(EtudeTableMap::COL_MULTI_PHASE, $this->multi_phase);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PO_NUMBER)) {
            $criteria->add(EtudeTableMap::COL_PO_NUMBER, $this->po_number);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CURRENCIES)) {
            $criteria->add(EtudeTableMap::COL_CURRENCIES, $this->currencies);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SMS_RELANCE)) {
            $criteria->add(EtudeTableMap::COL_SMS_RELANCE, $this->sms_relance);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ID_ETUDE_GROUP)) {
            $criteria->add(EtudeTableMap::COL_ID_ETUDE_GROUP, $this->id_etude_group);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GMS)) {
            $criteria->add(EtudeTableMap::COL_GMS, $this->gms);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_KOL)) {
            $criteria->add(EtudeTableMap::COL_KOL, $this->kol);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ROOM_RENTAL)) {
            $criteria->add(EtudeTableMap::COL_ROOM_RENTAL, $this->room_rental);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_RECRUITS_OFFSITE)) {
            $criteria->add(EtudeTableMap::COL_RECRUITS_OFFSITE, $this->recruits_offsite);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_STUDY_SPECIFICATION)) {
            $criteria->add(EtudeTableMap::COL_STUDY_SPECIFICATION, $this->study_specification);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_IS_STUDY_SPECIFICATION)) {
            $criteria->add(EtudeTableMap::COL_IS_STUDY_SPECIFICATION, $this->is_study_specification);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ADDITIONAL_NOTES)) {
            $criteria->add(EtudeTableMap::COL_ADDITIONAL_NOTES, $this->additional_notes);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROJECT_COMMENT)) {
            $criteria->add(EtudeTableMap::COL_PROJECT_COMMENT, $this->project_comment);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_ID)) {
            $criteria->add(EtudeTableMap::COL_END_CLIENT_ID, $this->end_client_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_END_CLIENT_CONTACT_ID)) {
            $criteria->add(EtudeTableMap::COL_END_CLIENT_CONTACT_ID, $this->end_client_contact_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONTACT_ID)) {
            $criteria->add(EtudeTableMap::COL_CONTACT_ID, $this->contact_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID)) {
            $criteria->add(EtudeTableMap::COL_CONTACT_CLIENT_PM_ID, $this->contact_client_pm_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_MASTER_PROJECT_NUMBER)) {
            $criteria->add(EtudeTableMap::COL_MASTER_PROJECT_NUMBER, $this->master_project_number);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROPOSED_LOI)) {
            $criteria->add(EtudeTableMap::COL_PROPOSED_LOI, $this->proposed_loi);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_OPPORTUNITY_ID)) {
            $criteria->add(EtudeTableMap::COL_OPPORTUNITY_ID, $this->opportunity_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SI_JOB_TYPE_ID)) {
            $criteria->add(EtudeTableMap::COL_SI_JOB_TYPE_ID, $this->si_job_type_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_BEST_EFFORT)) {
            $criteria->add(EtudeTableMap::COL_BEST_EFFORT, $this->best_effort);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_JOB_STATUS_SF_ID)) {
            $criteria->add(EtudeTableMap::COL_JOB_STATUS_SF_ID, $this->job_status_sf_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_BOOKED_BY_SF_ID)) {
            $criteria->add(EtudeTableMap::COL_BOOKED_BY_SF_ID, $this->booked_by_sf_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_SF_ID)) {
            $criteria->add(EtudeTableMap::COL_CREATED_BY_SF_ID, $this->created_by_sf_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID)) {
            $criteria->add(EtudeTableMap::COL_ACCOUNT_MANAGER_SF_ID, $this->account_manager_sf_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_DATE)) {
            $criteria->add(EtudeTableMap::COL_CREATED_DATE, $this->created_date);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_JOB_QUALIFICATION_ID)) {
            $criteria->add(EtudeTableMap::COL_JOB_QUALIFICATION_ID, $this->job_qualification_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_PROPOSED_N)) {
            $criteria->add(EtudeTableMap::COL_PROPOSED_N, $this->proposed_n);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID)) {
            $criteria->add(EtudeTableMap::COL_GERMAN_JOB_TYPE_ID, $this->german_job_type_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_COMMENT)) {
            $criteria->add(EtudeTableMap::COL_CREATED_BY_COMMENT, $this->created_by_comment);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FOCUS_VISION)) {
            $criteria->add(EtudeTableMap::COL_FOCUS_VISION, $this->focus_vision);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_SI_EU_JOB_TYPE)) {
            $criteria->add(EtudeTableMap::COL_SI_EU_JOB_TYPE, $this->si_eu_job_type);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID)) {
            $criteria->add(EtudeTableMap::COL_INTERMEDIATE_CLIENT_ID, $this->intermediate_client_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID)) {
            $criteria->add(EtudeTableMap::COL_INTERMEDIATE_CLIENT_CONTACT_ID, $this->intermediate_client_contact_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID)) {
            $criteria->add(EtudeTableMap::COL_US_GLOBAL_QUAL_GMS_ID, $this->us_global_qual_gms_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_FACILTY_NOTE)) {
            $criteria->add(EtudeTableMap::COL_FACILTY_NOTE, $this->facilty_note);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID)) {
            $criteria->add(EtudeTableMap::COL_CURRENCY_ISO_CODE_ID, $this->currency_iso_code_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID)) {
            $criteria->add(EtudeTableMap::COL_CLIENT_LIST_DELETION_ID, $this->client_list_deletion_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_BY_ID)) {
            $criteria->add(EtudeTableMap::COL_CREATED_BY_ID, $this->created_by_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_UPDATED_BY_ID)) {
            $criteria->add(EtudeTableMap::COL_UPDATED_BY_ID, $this->updated_by_id);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_CREATED_AT)) {
            $criteria->add(EtudeTableMap::COL_CREATED_AT, $this->created_at);
        }
        if ($this->isColumnModified(EtudeTableMap::COL_UPDATED_AT)) {
            $criteria->add(EtudeTableMap::COL_UPDATED_AT, $this->updated_at);
        }

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @throws LogicException if no primary key is defined
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = ChildEtudeQuery::create();
        $criteria->add(EtudeTableMap::COL_ID, $this->id);

        return $criteria;
    }

    /**
     * If the primary key is not null, return the hashcode of the
     * primary key. Otherwise, return the hash code of the object.
     *
     * @return int Hashcode
     */
    public function hashCode()
    {
        $validPk = null !== $this->getId();

        $validPrimaryKeyFKs = 0;
        $primaryKeyFKs = [];

        if ($validPk) {
            return crc32(json_encode($this->getPrimaryKey(), JSON_UNESCAPED_UNICODE));
        } elseif ($validPrimaryKeyFKs) {
            return crc32(json_encode($primaryKeyFKs, JSON_UNESCAPED_UNICODE));
        }

        return spl_object_hash($this);
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getId();
    }

    /**
     * Generic method to set the primary key (id column).
     *
     * @param       int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {
        return null === $this->getId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param      object $copyObj An object of \Model\Etude (or compatible) type.
     * @param      boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param      boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setNumeroEtude($this->getNumeroEtude());
        $copyObj->setReferenceClient($this->getReferenceClient());
        $copyObj->setMasterProjectSfId($this->getMasterProjectSfId());
        $copyObj->setTheme($this->getTheme());
        $copyObj->setDateDebut($this->getDateDebut());
        $copyObj->setDateFin($this->getDateFin());
        $copyObj->setAnnee($this->getAnnee());
        $copyObj->setRst($this->getRst());
        $copyObj->setCli($this->getCli());
        $copyObj->setGqs($this->getGqs());
        $copyObj->setIns($this->getIns());
        $copyObj->setHut($this->getHut());
        $copyObj->setDisplayTotalOnly($this->getDisplayTotalOnly());
        $copyObj->setIdPm($this->getIdPm());
        $copyObj->setIdEtape($this->getIdEtape());
        $copyObj->setPrixRevientInitial($this->getPrixRevientInitial());
        $copyObj->setPrixRevientActualise($this->getPrixRevientActualise());
        $copyObj->setPrixVenteInitial($this->getPrixVenteInitial());
        $copyObj->setPrixVenteActualise($this->getPrixVenteActualise());
        $copyObj->setConsolidatedInvoice($this->getConsolidatedInvoice());
        $copyObj->setSendCsatQuest($this->getSendCsatQuest());
        $copyObj->setIsSendCsatQuestMail($this->getIsSendCsatQuestMail());
        $copyObj->setNumeroFacture($this->getNumeroFacture());
        $copyObj->setDontSetAmAuto($this->getDontSetAmAuto());
        $copyObj->setSetAmReason($this->getSetAmReason());
        $copyObj->setAmReasonTypeId($this->getAmReasonTypeId());
        $copyObj->setDateEnvoiFacture($this->getDateEnvoiFacture());
        $copyObj->setDateReglement($this->getDateReglement());
        $copyObj->setCommentaire($this->getCommentaire());
        $copyObj->setIndustryId($this->getIndustryId());
        $copyObj->setPeriodeCutoff($this->getPeriodeCutoff());
        $copyObj->setThemeBr($this->getThemeBr());
        $copyObj->setAreaId($this->getAreaId());
        $copyObj->setIdSamsStudy($this->getIdSamsStudy());
        $copyObj->setRecrutementObjectif($this->getRecrutementObjectif());
        $copyObj->setIdLocationPnl($this->getIdLocationPnl());
        $copyObj->setIdMasterProjectLocationPnl($this->getIdMasterProjectLocationPnl());
        $copyObj->setRecrutementObjectifPr($this->getRecrutementObjectifPr());
        $copyObj->setIdBm($this->getIdBm());
        $copyObj->setExtraInfo($this->getExtraInfo());
        $copyObj->setAccountId($this->getAccountId());
        $copyObj->setAccountManagerId($this->getAccountManagerId());
        $copyObj->setProjectSpecialtySponsorId($this->getProjectSpecialtySponsorId());
        $copyObj->setLanguage($this->getLanguage());
        $copyObj->setRemiseTaux($this->getRemiseTaux());
        $copyObj->setClientDiscountPercentage($this->getClientDiscountPercentage());
        $copyObj->setEndClientDiscountPercentage($this->getEndClientDiscountPercentage());
        $copyObj->setClientQuantDiscountPercentage($this->getClientQuantDiscountPercentage());
        $copyObj->setEndClientQuantDiscountPercentage($this->getEndClientQuantDiscountPercentage());
        $copyObj->setSamplePlan($this->getSamplePlan());
        $copyObj->setIsToInvoice($this->getIsToInvoice());
        $copyObj->setFilePath($this->getFilePath());
        $copyObj->setAccountLeaderId($this->getAccountLeaderId());
        $copyObj->setAccountPMId($this->getAccountPMId());
        $copyObj->setAmEmail($this->getAmEmail());
        $copyObj->setClientPortalReady($this->getClientPortalReady());
        $copyObj->setLengthOfInterview($this->getLengthOfInterview());
        $copyObj->setsunshineAct($this->getsunshineAct());
        $copyObj->setIsConsolidated($this->getIsConsolidated());
        $copyObj->setSharepointFolder($this->getSharepointFolder());
        $copyObj->setMultiPhase($this->getMultiPhase());
        $copyObj->setPoNumber($this->getPoNumber());
        $copyObj->setCurrencies($this->getCurrencies());
        $copyObj->setSmsRelance($this->getSmsRelance());
        $copyObj->setIdEtudeGroup($this->getIdEtudeGroup());
        $copyObj->setGms($this->getGms());
        $copyObj->setKol($this->getKol());
        $copyObj->setRoomRental($this->getRoomRental());
        $copyObj->setRecruitsOffsite($this->getRecruitsOffsite());
        $copyObj->setStudySpecification($this->getStudySpecification());
        $copyObj->setisStudySpecification($this->getisStudySpecification());
        $copyObj->setAdditionalNotes($this->getAdditionalNotes());
        $copyObj->setProjectComment($this->getProjectComment());
        $copyObj->setEndClientId($this->getEndClientId());
        $copyObj->setEndClientContactId($this->getEndClientContactId());
        $copyObj->setContactId($this->getContactId());
        $copyObj->setContactClientPmId($this->getContactClientPmId());
        $copyObj->setMasterProjectNumber($this->getMasterProjectNumber());
        $copyObj->setProposedLoi($this->getProposedLoi());
        $copyObj->setOpportunityId($this->getOpportunityId());
        $copyObj->setSiJobTypeId($this->getSiJobTypeId());
        $copyObj->setBestEffort($this->getBestEffort());
        $copyObj->setJobStatusSfId($this->getJobStatusSfId());
        $copyObj->setBookedBySfId($this->getBookedBySfId());
        $copyObj->setCreatedBySfId($this->getCreatedBySfId());
        $copyObj->setAccountManagerSfId($this->getAccountManagerSfId());
        $copyObj->setCreatedDate($this->getCreatedDate());
        $copyObj->setJobQualificationId($this->getJobQualificationId());
        $copyObj->setProposedN($this->getProposedN());
        $copyObj->setGermanJobTypeId($this->getGermanJobTypeId());
        $copyObj->setCreatedByComment($this->getCreatedByComment());
        $copyObj->setFocusVision($this->getFocusVision());
        $copyObj->setSiEuJobType($this->getSiEuJobType());
        $copyObj->setIntermediateClientId($this->getIntermediateClientId());
        $copyObj->setIntermediateClientContactId($this->getIntermediateClientContactId());
        $copyObj->setUsGlobalQualGmsId($this->getUsGlobalQualGmsId());
        $copyObj->setFaciltyNote($this->getFaciltyNote());
        $copyObj->setCurrencyIsoCodeId($this->getCurrencyIsoCodeId());
        $copyObj->setClientListDeletionId($this->getClientListDeletionId());
        $copyObj->setCreatedById($this->getCreatedById());
        $copyObj->setUpdatedById($this->getUpdatedById());
        $copyObj->setCreatedAt($this->getCreatedAt());
        $copyObj->setUpdatedAt($this->getUpdatedAt());

        if ($deepCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);

            foreach ($this->getDernierAccess() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addDernierAcces($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEtudeSampleSources() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEtudeSampleSource($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEtudeMethodologies() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEtudeMethodology($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getFactures() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addFacture($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getJobEtudes() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addJobEtude($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getReglements() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addReglement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getSectors() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addSector($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEtudeCheckListValidations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEtudeCheckListValidation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getEtudeFichiers() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEtudeFichier($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getLogProjectStatuses() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addLogProjectStatus($relObj->copy($deepCopy));
                }
            }

        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param  boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return \Model\Etude Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setUsGlobalQualGms(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setUsGlobalQualGmsId(NULL);
        } else {
            $this->setUsGlobalQualGmsId($v->getId());
        }

        $this->aUsGlobalQualGms = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByUsGlobalQualGmsId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getUsGlobalQualGms(ConnectionInterface $con = null)
    {
        if ($this->aUsGlobalQualGms === null && ($this->us_global_qual_gms_id != 0)) {
            $this->aUsGlobalQualGms = ChildRefSalesForceQuery::create()->findPk($this->us_global_qual_gms_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aUsGlobalQualGms->addEtudesRelatedByUsGlobalQualGmsId($this);
             */
        }

        return $this->aUsGlobalQualGms;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAccountLeader(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setAccountLeaderId(NULL);
        } else {
            $this->setAccountLeaderId($v->getId());
        }

        $this->aAccountLeader = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addAccountLeader($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getAccountLeader(ConnectionInterface $con = null)
    {
        if ($this->aAccountLeader === null && ($this->account_leader_id != 0)) {
            $this->aAccountLeader = ChildUserQuery::create()->findPk($this->account_leader_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAccountLeader->addAccountLeaders($this);
             */
        }

        return $this->aAccountLeader;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAccountPM(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setAccountPMId(NULL);
        } else {
            $this->setAccountPMId($v->getId());
        }

        $this->aAccountPM = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addAccountPM($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getAccountPM(ConnectionInterface $con = null)
    {
        if ($this->aAccountPM === null && ($this->account_pm_id != 0)) {
            $this->aAccountPM = ChildUserQuery::create()->findPk($this->account_pm_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAccountPM->addAccountPMs($this);
             */
        }

        return $this->aAccountPM;
    }

    /**
     * Declares an association between this object and a ChildAccount object.
     *
     * @param  ChildAccount|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setIntermediateClient(ChildAccount $v = null)
    {
        if ($v === null) {
            $this->setIntermediateClientId(NULL);
        } else {
            $this->setIntermediateClientId($v->getId());
        }

        $this->aIntermediateClient = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildAccount object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByIntermediateClientId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildAccount object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildAccount|null The associated ChildAccount object.
     * @throws PropelException
     */
    public function getIntermediateClient(ConnectionInterface $con = null)
    {
        if ($this->aIntermediateClient === null && ($this->intermediate_client_id != 0)) {
            $this->aIntermediateClient = ChildAccountQuery::create()->findPk($this->intermediate_client_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aIntermediateClient->addEtudesRelatedByIntermediateClientId($this);
             */
        }

        return $this->aIntermediateClient;
    }

    /**
     * Declares an association between this object and a ChildEtape object.
     *
     * @param  ChildEtape|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtape(ChildEtape $v = null)
    {
        if ($v === null) {
            $this->setIdEtape(NULL);
        } else {
            $this->setIdEtape($v->getId());
        }

        $this->aEtape = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildEtape object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildEtape object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildEtape|null The associated ChildEtape object.
     * @throws PropelException
     */
    public function getEtape(ConnectionInterface $con = null)
    {
        if ($this->aEtape === null && ($this->id_etape != 0)) {
            $this->aEtape = ChildEtapeQuery::create()->findPk($this->id_etape, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtape->addEtudes($this);
             */
        }

        return $this->aEtape;
    }

    /**
     * Declares an association between this object and a ChildContact object.
     *
     * @param  ChildContact|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setContact(ChildContact $v = null)
    {
        if ($v === null) {
            $this->setContactId(NULL);
        } else {
            $this->setContactId($v->getId());
        }

        $this->aContact = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildContact object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByContactId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildContact object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildContact|null The associated ChildContact object.
     * @throws PropelException
     */
    public function getContact(ConnectionInterface $con = null)
    {
        if ($this->aContact === null && ($this->contact_id != 0)) {
            $this->aContact = ChildContactQuery::create()->findPk($this->contact_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aContact->addEtudesRelatedByContactId($this);
             */
        }

        return $this->aContact;
    }

    /**
     * Declares an association between this object and a ChildOpportunity object.
     *
     * @param  ChildOpportunity|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setOpportunity(ChildOpportunity $v = null)
    {
        if ($v === null) {
            $this->setOpportunityId(NULL);
        } else {
            $this->setOpportunityId($v->getId());
        }

        $this->aOpportunity = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildOpportunity object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildOpportunity object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildOpportunity|null The associated ChildOpportunity object.
     * @throws PropelException
     */
    public function getOpportunity(ConnectionInterface $con = null)
    {
        if ($this->aOpportunity === null && ($this->opportunity_id != 0)) {
            $this->aOpportunity = ChildOpportunityQuery::create()->findPk($this->opportunity_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aOpportunity->addEtudes($this);
             */
        }

        return $this->aOpportunity;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setJobStatusSf(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setJobStatusSfId(NULL);
        } else {
            $this->setJobStatusSfId($v->getId());
        }

        $this->aJobStatusSf = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByJobStatusSfId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getJobStatusSf(ConnectionInterface $con = null)
    {
        if ($this->aJobStatusSf === null && ($this->job_status_sf_id != 0)) {
            $this->aJobStatusSf = ChildRefSalesForceQuery::create()->findPk($this->job_status_sf_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aJobStatusSf->addEtudesRelatedByJobStatusSfId($this);
             */
        }

        return $this->aJobStatusSf;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setJobQualification(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setJobQualificationId(NULL);
        } else {
            $this->setJobQualificationId($v->getId());
        }

        $this->aJobQualification = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByJobQualificationId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getJobQualification(ConnectionInterface $con = null)
    {
        if ($this->aJobQualification === null && ($this->job_qualification_id != 0)) {
            $this->aJobQualification = ChildRefSalesForceQuery::create()->findPk($this->job_qualification_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aJobQualification->addEtudesRelatedByJobQualificationId($this);
             */
        }

        return $this->aJobQualification;
    }

    /**
     * Declares an association between this object and a ChildSiJobType object.
     *
     * @param  ChildSiJobType|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setSiJobType(ChildSiJobType $v = null)
    {
        if ($v === null) {
            $this->setSiJobTypeId(NULL);
        } else {
            $this->setSiJobTypeId($v->getId());
        }

        $this->aSiJobType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildSiJobType object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildSiJobType object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildSiJobType|null The associated ChildSiJobType object.
     * @throws PropelException
     */
    public function getSiJobType(ConnectionInterface $con = null)
    {
        if ($this->aSiJobType === null && ($this->si_job_type_id != 0)) {
            $this->aSiJobType = ChildSiJobTypeQuery::create()->findPk($this->si_job_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aSiJobType->addEtudes($this);
             */
        }

        return $this->aSiJobType;
    }

    /**
     * Declares an association between this object and a ChildContact object.
     *
     * @param  ChildContact|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEndClientContact(ChildContact $v = null)
    {
        if ($v === null) {
            $this->setEndClientContactId(NULL);
        } else {
            $this->setEndClientContactId($v->getId());
        }

        $this->aEndClientContact = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildContact object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeEndClientContact($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildContact object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildContact|null The associated ChildContact object.
     * @throws PropelException
     */
    public function getEndClientContact(ConnectionInterface $con = null)
    {
        if ($this->aEndClientContact === null && ($this->end_client_contact_id != 0)) {
            $this->aEndClientContact = ChildContactQuery::create()->findPk($this->end_client_contact_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEndClientContact->addEtudeEndClientContacts($this);
             */
        }

        return $this->aEndClientContact;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setGermanJobType(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setGermanJobTypeId(NULL);
        } else {
            $this->setGermanJobTypeId($v->getId());
        }

        $this->aGermanJobType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByGermanJobTypeId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getGermanJobType(ConnectionInterface $con = null)
    {
        if ($this->aGermanJobType === null && ($this->german_job_type_id != 0)) {
            $this->aGermanJobType = ChildRefSalesForceQuery::create()->findPk($this->german_job_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aGermanJobType->addEtudesRelatedByGermanJobTypeId($this);
             */
        }

        return $this->aGermanJobType;
    }

    /**
     * Declares an association between this object and a ChildAccount object.
     *
     * @param  ChildAccount|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEndClient(ChildAccount $v = null)
    {
        if ($v === null) {
            $this->setEndClientId(NULL);
        } else {
            $this->setEndClientId($v->getId());
        }

        $this->aEndClient = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildAccount object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByEndClientId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildAccount object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildAccount|null The associated ChildAccount object.
     * @throws PropelException
     */
    public function getEndClient(ConnectionInterface $con = null)
    {
        if ($this->aEndClient === null && ($this->end_client_id != 0)) {
            $this->aEndClient = ChildAccountQuery::create()->findPk($this->end_client_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEndClient->addEtudesRelatedByEndClientId($this);
             */
        }

        return $this->aEndClient;
    }

    /**
     * Declares an association between this object and a ChildAccount object.
     *
     * @param  ChildAccount|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAccount(ChildAccount $v = null)
    {
        if ($v === null) {
            $this->setAccountId(NULL);
        } else {
            $this->setAccountId($v->getId());
        }

        $this->aAccount = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildAccount object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByAccountId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildAccount object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildAccount|null The associated ChildAccount object.
     * @throws PropelException
     */
    public function getAccount(ConnectionInterface $con = null)
    {
        if ($this->aAccount === null && ($this->account_id != 0)) {
            $this->aAccount = ChildAccountQuery::create()->findPk($this->account_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAccount->addEtudesRelatedByAccountId($this);
             */
        }

        return $this->aAccount;
    }

    /**
     * Declares an association between this object and a ChildIndustry object.
     *
     * @param  ChildIndustry $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setIndustry(ChildIndustry $v = null)
    {
        if ($v === null) {
            $this->setIndustryId(NULL);
        } else {
            $this->setIndustryId($v->getId());
        }

        $this->aIndustry = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildIndustry object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildIndustry object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildIndustry The associated ChildIndustry object.
     * @throws PropelException
     */
    public function getIndustry(ConnectionInterface $con = null)
    {
        if ($this->aIndustry === null && ($this->industry_id != 0)) {
            $this->aIndustry = ChildIndustryQuery::create()->findPk($this->industry_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aIndustry->addEtudes($this);
             */
        }

        return $this->aIndustry;
    }

    /**
     * Declares an association between this object and a ChildLocation object.
     *
     * @param  ChildLocation|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtudeLocation(ChildLocation $v = null)
    {
        if ($v === null) {
            $this->setIdLocationPnl(NULL);
        } else {
            $this->setIdLocationPnl($v->getId());
        }

        $this->aEtudeLocation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildLocation object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeLocation($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildLocation object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildLocation|null The associated ChildLocation object.
     * @throws PropelException
     */
    public function getEtudeLocation(ConnectionInterface $con = null)
    {
        if ($this->aEtudeLocation === null && ($this->id_location_pnl != 0)) {
            $this->aEtudeLocation = ChildLocationQuery::create()->findPk($this->id_location_pnl, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtudeLocation->addEtudeLocations($this);
             */
        }

        return $this->aEtudeLocation;
    }

    /**
     * Declares an association between this object and a ChildProjectLocationPrefix object.
     *
     * @param  ChildProjectLocationPrefix|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setProjectLocationPrefix(ChildProjectLocationPrefix $v = null)
    {
        if ($v === null) {
            $this->setIdMasterProjectLocationPnl(NULL);
        } else {
            $this->setIdMasterProjectLocationPnl($v->getId());
        }

        $this->aProjectLocationPrefix = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildProjectLocationPrefix object, it will not be re-added.
        if ($v !== null) {
            $v->addProjectLocationPrefix($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildProjectLocationPrefix object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildProjectLocationPrefix|null The associated ChildProjectLocationPrefix object.
     * @throws PropelException
     */
    public function getProjectLocationPrefix(ConnectionInterface $con = null)
    {
        if ($this->aProjectLocationPrefix === null && ($this->id_master_project_location_pnl != 0)) {
            $this->aProjectLocationPrefix = ChildProjectLocationPrefixQuery::create()->findPk($this->id_master_project_location_pnl, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aProjectLocationPrefix->addProjectLocationPrefixes($this);
             */
        }

        return $this->aProjectLocationPrefix;
    }

    /**
     * Declares an association between this object and a ChildContact object.
     *
     * @param  ChildContact|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setContactClientPm(ChildContact $v = null)
    {
        if ($v === null) {
            $this->setContactClientPmId(NULL);
        } else {
            $this->setContactClientPmId($v->getId());
        }

        $this->aContactClientPm = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildContact object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeContactClientPm($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildContact object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildContact|null The associated ChildContact object.
     * @throws PropelException
     */
    public function getContactClientPm(ConnectionInterface $con = null)
    {
        if ($this->aContactClientPm === null && ($this->contact_client_pm_id != 0)) {
            $this->aContactClientPm = ChildContactQuery::create()->findPk($this->contact_client_pm_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aContactClientPm->addEtudeContactClientPms($this);
             */
        }

        return $this->aContactClientPm;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setBM(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setIdBm(NULL);
        } else {
            $this->setIdBm($v->getId());
        }

        $this->aBM = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByIdBm($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getBM(ConnectionInterface $con = null)
    {
        if ($this->aBM === null && ($this->id_bm != 0)) {
            $this->aBM = ChildUserQuery::create()->findPk($this->id_bm, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aBM->addEtudesRelatedByIdBm($this);
             */
        }

        return $this->aBM;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtudeProjectManager(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setIdPm(NULL);
        } else {
            $this->setIdPm($v->getId());
        }

        $this->aEtudeProjectManager = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeEtudeProjectManager($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getEtudeProjectManager(ConnectionInterface $con = null)
    {
        if ($this->aEtudeProjectManager === null && ($this->id_pm != 0)) {
            $this->aEtudeProjectManager = ChildUserQuery::create()->findPk($this->id_pm, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtudeProjectManager->addEtudeEtudeProjectManagers($this);
             */
        }

        return $this->aEtudeProjectManager;
    }

    /**
     * Declares an association between this object and a ChildEtudeGroup object.
     *
     * @param  ChildEtudeGroup|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtudeGroup(ChildEtudeGroup $v = null)
    {
        if ($v === null) {
            $this->setIdEtudeGroup(NULL);
        } else {
            $this->setIdEtudeGroup($v->getId());
        }

        $this->aEtudeGroup = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildEtudeGroup object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildEtudeGroup object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildEtudeGroup|null The associated ChildEtudeGroup object.
     * @throws PropelException
     */
    public function getEtudeGroup(ConnectionInterface $con = null)
    {
        if ($this->aEtudeGroup === null && ($this->id_etude_group != 0)) {
            $this->aEtudeGroup = ChildEtudeGroupQuery::create()->findPk($this->id_etude_group, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtudeGroup->addEtudes($this);
             */
        }

        return $this->aEtudeGroup;
    }

    /**
     * Declares an association between this object and a ChildArea object.
     *
     * @param  ChildArea|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtudeArea(ChildArea $v = null)
    {
        if ($v === null) {
            $this->setAreaId(NULL);
        } else {
            $this->setAreaId($v->getId());
        }

        $this->aEtudeArea = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildArea object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildArea object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildArea|null The associated ChildArea object.
     * @throws PropelException
     */
    public function getEtudeArea(ConnectionInterface $con = null)
    {
        if ($this->aEtudeArea === null && ($this->area_id != 0)) {
            $this->aEtudeArea = ChildAreaQuery::create()->findPk($this->area_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtudeArea->addEtudes($this);
             */
        }

        return $this->aEtudeArea;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setCurrencyIsoCode(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setCurrencyIsoCodeId(NULL);
        } else {
            $this->setCurrencyIsoCodeId($v->getId());
        }

        $this->aCurrencyIsoCode = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByCurrencyIsoCodeId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getCurrencyIsoCode(ConnectionInterface $con = null)
    {
        if ($this->aCurrencyIsoCode === null && ($this->currency_iso_code_id != 0)) {
            $this->aCurrencyIsoCode = ChildRefSalesForceQuery::create()->findPk($this->currency_iso_code_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aCurrencyIsoCode->addEtudesRelatedByCurrencyIsoCodeId($this);
             */
        }

        return $this->aCurrencyIsoCode;
    }

    /**
     * Declares an association between this object and a ChildRefSalesForce object.
     *
     * @param  ChildRefSalesForce|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setClientListDeletion(ChildRefSalesForce $v = null)
    {
        if ($v === null) {
            $this->setClientListDeletionId(NULL);
        } else {
            $this->setClientListDeletionId($v->getId());
        }

        $this->aClientListDeletion = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRefSalesForce object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByClientListDeletionId($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRefSalesForce object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRefSalesForce|null The associated ChildRefSalesForce object.
     * @throws PropelException
     */
    public function getClientListDeletion(ConnectionInterface $con = null)
    {
        if ($this->aClientListDeletion === null && ($this->client_list_deletion_id != 0)) {
            $this->aClientListDeletion = ChildRefSalesForceQuery::create()->findPk($this->client_list_deletion_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aClientListDeletion->addEtudesRelatedByClientListDeletionId($this);
             */
        }

        return $this->aClientListDeletion;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setCreatedBy(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setCreatedById(NULL);
        } else {
            $this->setCreatedById($v->getId());
        }

        $this->aCreatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByCreatedById($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getCreatedBy(ConnectionInterface $con = null)
    {
        if ($this->aCreatedBy === null && ($this->created_by_id != 0)) {
            $this->aCreatedBy = ChildUserQuery::create()->findPk($this->created_by_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aCreatedBy->addEtudesRelatedByCreatedById($this);
             */
        }

        return $this->aCreatedBy;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setUpdatedBy(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setUpdatedById(NULL);
        } else {
            $this->setUpdatedById($v->getId());
        }

        $this->aUpdatedBy = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeRelatedByUpdatedById($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getUpdatedBy(ConnectionInterface $con = null)
    {
        if ($this->aUpdatedBy === null && ($this->updated_by_id != 0)) {
            $this->aUpdatedBy = ChildUserQuery::create()->findPk($this->updated_by_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aUpdatedBy->addEtudesRelatedByUpdatedById($this);
             */
        }

        return $this->aUpdatedBy;
    }

    /**
     * Declares an association between this object and a ChildContact object.
     *
     * @param  ChildContact|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setIntermediateClientContact(ChildContact $v = null)
    {
        if ($v === null) {
            $this->setIntermediateClientContactId(NULL);
        } else {
            $this->setIntermediateClientContactId($v->getId());
        }

        $this->aIntermediateClientContact = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildContact object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeIntermediateClientContact($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildContact object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildContact|null The associated ChildContact object.
     * @throws PropelException
     */
    public function getIntermediateClientContact(ConnectionInterface $con = null)
    {
        if ($this->aIntermediateClientContact === null && ($this->intermediate_client_contact_id != 0)) {
            $this->aIntermediateClientContact = ChildContactQuery::create()->findPk($this->intermediate_client_contact_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aIntermediateClientContact->addEtudeIntermediateClientContacts($this);
             */
        }

        return $this->aIntermediateClientContact;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setProjectAccountManager(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setAccountManagerId(NULL);
        } else {
            $this->setAccountManagerId($v->getId());
        }

        $this->aProjectAccountManager = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addProjectAccountManager($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getProjectAccountManager(ConnectionInterface $con = null)
    {
        if ($this->aProjectAccountManager === null && ($this->account_manager_id != 0)) {
            $this->aProjectAccountManager = ChildUserQuery::create()->findPk($this->account_manager_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aProjectAccountManager->addProjectAccountManagers($this);
             */
        }

        return $this->aProjectAccountManager;
    }

    /**
     * Declares an association between this object and a ChildUser object.
     *
     * @param  ChildUser|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setProjectSpecialtySponsor(ChildUser $v = null)
    {
        if ($v === null) {
            $this->setProjectSpecialtySponsorId(NULL);
        } else {
            $this->setProjectSpecialtySponsorId($v->getId());
        }

        $this->aProjectSpecialtySponsor = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildUser object, it will not be re-added.
        if ($v !== null) {
            $v->addProjectSpecialtySponsor($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildUser object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildUser|null The associated ChildUser object.
     * @throws PropelException
     */
    public function getProjectSpecialtySponsor(ConnectionInterface $con = null)
    {
        if ($this->aProjectSpecialtySponsor === null && ($this->project_specialty_sponsor_id != 0)) {
            $this->aProjectSpecialtySponsor = ChildUserQuery::create()->findPk($this->project_specialty_sponsor_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aProjectSpecialtySponsor->addProjectSpecialtySponsors($this);
             */
        }

        return $this->aProjectSpecialtySponsor;
    }

    /**
     * Declares an association between this object and a ChildAmReasonType object.
     *
     * @param  ChildAmReasonType|null $v
     * @return $this|\Model\Etude The current object (for fluent API support)
     * @throws PropelException
     */
    public function setAmReasonType(ChildAmReasonType $v = null)
    {
        if ($v === null) {
            $this->setAmReasonTypeId(NULL);
        } else {
            $this->setAmReasonTypeId($v->getId());
        }

        $this->aAmReasonType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildAmReasonType object, it will not be re-added.
        if ($v !== null) {
            $v->addEtude($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildAmReasonType object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildAmReasonType|null The associated ChildAmReasonType object.
     * @throws PropelException
     */
    public function getAmReasonType(ConnectionInterface $con = null)
    {
        if ($this->aAmReasonType === null && ($this->am_reason_type_id != 0)) {
            $this->aAmReasonType = ChildAmReasonTypeQuery::create()->findPk($this->am_reason_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aAmReasonType->addEtudes($this);
             */
        }

        return $this->aAmReasonType;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param      string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('DernierAcces' === $relationName) {
            $this->initDernierAccess();
            return;
        }
        if ('EtudeSampleSource' === $relationName) {
            $this->initEtudeSampleSources();
            return;
        }
        if ('EtudeMethodology' === $relationName) {
            $this->initEtudeMethodologies();
            return;
        }
        if ('Facture' === $relationName) {
            $this->initFactures();
            return;
        }
        if ('JobEtude' === $relationName) {
            $this->initJobEtudes();
            return;
        }
        if ('Reglement' === $relationName) {
            $this->initReglements();
            return;
        }
        if ('Sector' === $relationName) {
            $this->initSectors();
            return;
        }
        if ('EtudeCheckListValidation' === $relationName) {
            $this->initEtudeCheckListValidations();
            return;
        }
        if ('EtudeFichier' === $relationName) {
            $this->initEtudeFichiers();
            return;
        }
        if ('LogProjectStatus' === $relationName) {
            $this->initLogProjectStatuses();
            return;
        }
    }

    /**
     * Clears out the collDernierAccess collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addDernierAccess()
     */
    public function clearDernierAccess()
    {
        $this->collDernierAccess = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collDernierAccess collection loaded partially.
     */
    public function resetPartialDernierAccess($v = true)
    {
        $this->collDernierAccessPartial = $v;
    }

    /**
     * Initializes the collDernierAccess collection.
     *
     * By default this just sets the collDernierAccess collection to an empty array (like clearcollDernierAccess());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initDernierAccess($overrideExisting = true)
    {
        if (null !== $this->collDernierAccess && !$overrideExisting) {
            return;
        }

        $collectionClassName = DernierAccesTableMap::getTableMap()->getCollectionClassName();

        $this->collDernierAccess = new $collectionClassName;
        $this->collDernierAccess->setModel('\Model\DernierAcces');
    }

    /**
     * Gets an array of ChildDernierAcces objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildDernierAcces[] List of ChildDernierAcces objects
     * @phpstan-return ObjectCollection&\Traversable<ChildDernierAcces> List of ChildDernierAcces objects
     * @throws PropelException
     */
    public function getDernierAccess(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collDernierAccessPartial && !$this->isNew();
        if (null === $this->collDernierAccess || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collDernierAccess) {
                    $this->initDernierAccess();
                } else {
                    $collectionClassName = DernierAccesTableMap::getTableMap()->getCollectionClassName();

                    $collDernierAccess = new $collectionClassName;
                    $collDernierAccess->setModel('\Model\DernierAcces');

                    return $collDernierAccess;
                }
            } else {
                $collDernierAccess = ChildDernierAccesQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collDernierAccessPartial && count($collDernierAccess)) {
                        $this->initDernierAccess(false);

                        foreach ($collDernierAccess as $obj) {
                            if (false == $this->collDernierAccess->contains($obj)) {
                                $this->collDernierAccess->append($obj);
                            }
                        }

                        $this->collDernierAccessPartial = true;
                    }

                    return $collDernierAccess;
                }

                if ($partial && $this->collDernierAccess) {
                    foreach ($this->collDernierAccess as $obj) {
                        if ($obj->isNew()) {
                            $collDernierAccess[] = $obj;
                        }
                    }
                }

                $this->collDernierAccess = $collDernierAccess;
                $this->collDernierAccessPartial = false;
            }
        }

        return $this->collDernierAccess;
    }

    /**
     * Sets a collection of ChildDernierAcces objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $dernierAccess A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setDernierAccess(Collection $dernierAccess, ConnectionInterface $con = null)
    {
        /** @var ChildDernierAcces[] $dernierAccessToDelete */
        $dernierAccessToDelete = $this->getDernierAccess(new Criteria(), $con)->diff($dernierAccess);


        $this->dernierAccessScheduledForDeletion = $dernierAccessToDelete;

        foreach ($dernierAccessToDelete as $dernierAccesRemoved) {
            $dernierAccesRemoved->setEtude(null);
        }

        $this->collDernierAccess = null;
        foreach ($dernierAccess as $dernierAcces) {
            $this->addDernierAcces($dernierAcces);
        }

        $this->collDernierAccess = $dernierAccess;
        $this->collDernierAccessPartial = false;

        return $this;
    }

    /**
     * Returns the number of related DernierAcces objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related DernierAcces objects.
     * @throws PropelException
     */
    public function countDernierAccess(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collDernierAccessPartial && !$this->isNew();
        if (null === $this->collDernierAccess || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collDernierAccess) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getDernierAccess());
            }

            $query = ChildDernierAccesQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collDernierAccess);
    }

    /**
     * Method called to associate a ChildDernierAcces object to this object
     * through the ChildDernierAcces foreign key attribute.
     *
     * @param  ChildDernierAcces $l ChildDernierAcces
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addDernierAcces(ChildDernierAcces $l)
    {
        if ($this->collDernierAccess === null) {
            $this->initDernierAccess();
            $this->collDernierAccessPartial = true;
        }

        if (!$this->collDernierAccess->contains($l)) {
            $this->doAddDernierAcces($l);

            if ($this->dernierAccessScheduledForDeletion and $this->dernierAccessScheduledForDeletion->contains($l)) {
                $this->dernierAccessScheduledForDeletion->remove($this->dernierAccessScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildDernierAcces $dernierAcces The ChildDernierAcces object to add.
     */
    protected function doAddDernierAcces(ChildDernierAcces $dernierAcces)
    {
        $this->collDernierAccess[]= $dernierAcces;
        $dernierAcces->setEtude($this);
    }

    /**
     * @param  ChildDernierAcces $dernierAcces The ChildDernierAcces object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeDernierAcces(ChildDernierAcces $dernierAcces)
    {
        if ($this->getDernierAccess()->contains($dernierAcces)) {
            $pos = $this->collDernierAccess->search($dernierAcces);
            $this->collDernierAccess->remove($pos);
            if (null === $this->dernierAccessScheduledForDeletion) {
                $this->dernierAccessScheduledForDeletion = clone $this->collDernierAccess;
                $this->dernierAccessScheduledForDeletion->clear();
            }
            $this->dernierAccessScheduledForDeletion[]= clone $dernierAcces;
            $dernierAcces->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related DernierAccess from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildDernierAcces[] List of ChildDernierAcces objects
     * @phpstan-return ObjectCollection&\Traversable<ChildDernierAcces}> List of ChildDernierAcces objects
     */
    public function getDernierAccessJoinUser(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildDernierAccesQuery::create(null, $criteria);
        $query->joinWith('User', $joinBehavior);

        return $this->getDernierAccess($query, $con);
    }

    /**
     * Clears out the collEtudeSampleSources collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEtudeSampleSources()
     */
    public function clearEtudeSampleSources()
    {
        $this->collEtudeSampleSources = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEtudeSampleSources collection loaded partially.
     */
    public function resetPartialEtudeSampleSources($v = true)
    {
        $this->collEtudeSampleSourcesPartial = $v;
    }

    /**
     * Initializes the collEtudeSampleSources collection.
     *
     * By default this just sets the collEtudeSampleSources collection to an empty array (like clearcollEtudeSampleSources());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEtudeSampleSources($overrideExisting = true)
    {
        if (null !== $this->collEtudeSampleSources && !$overrideExisting) {
            return;
        }

        $collectionClassName = EtudeSampleSourceTableMap::getTableMap()->getCollectionClassName();

        $this->collEtudeSampleSources = new $collectionClassName;
        $this->collEtudeSampleSources->setModel('\Model\EtudeSampleSource');
    }

    /**
     * Gets an array of ChildEtudeSampleSource objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEtudeSampleSource[] List of ChildEtudeSampleSource objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeSampleSource> List of ChildEtudeSampleSource objects
     * @throws PropelException
     */
    public function getEtudeSampleSources(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeSampleSourcesPartial && !$this->isNew();
        if (null === $this->collEtudeSampleSources || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEtudeSampleSources) {
                    $this->initEtudeSampleSources();
                } else {
                    $collectionClassName = EtudeSampleSourceTableMap::getTableMap()->getCollectionClassName();

                    $collEtudeSampleSources = new $collectionClassName;
                    $collEtudeSampleSources->setModel('\Model\EtudeSampleSource');

                    return $collEtudeSampleSources;
                }
            } else {
                $collEtudeSampleSources = ChildEtudeSampleSourceQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEtudeSampleSourcesPartial && count($collEtudeSampleSources)) {
                        $this->initEtudeSampleSources(false);

                        foreach ($collEtudeSampleSources as $obj) {
                            if (false == $this->collEtudeSampleSources->contains($obj)) {
                                $this->collEtudeSampleSources->append($obj);
                            }
                        }

                        $this->collEtudeSampleSourcesPartial = true;
                    }

                    return $collEtudeSampleSources;
                }

                if ($partial && $this->collEtudeSampleSources) {
                    foreach ($this->collEtudeSampleSources as $obj) {
                        if ($obj->isNew()) {
                            $collEtudeSampleSources[] = $obj;
                        }
                    }
                }

                $this->collEtudeSampleSources = $collEtudeSampleSources;
                $this->collEtudeSampleSourcesPartial = false;
            }
        }

        return $this->collEtudeSampleSources;
    }

    /**
     * Sets a collection of ChildEtudeSampleSource objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $etudeSampleSources A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setEtudeSampleSources(Collection $etudeSampleSources, ConnectionInterface $con = null)
    {
        /** @var ChildEtudeSampleSource[] $etudeSampleSourcesToDelete */
        $etudeSampleSourcesToDelete = $this->getEtudeSampleSources(new Criteria(), $con)->diff($etudeSampleSources);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->etudeSampleSourcesScheduledForDeletion = clone $etudeSampleSourcesToDelete;

        foreach ($etudeSampleSourcesToDelete as $etudeSampleSourceRemoved) {
            $etudeSampleSourceRemoved->setEtude(null);
        }

        $this->collEtudeSampleSources = null;
        foreach ($etudeSampleSources as $etudeSampleSource) {
            $this->addEtudeSampleSource($etudeSampleSource);
        }

        $this->collEtudeSampleSources = $etudeSampleSources;
        $this->collEtudeSampleSourcesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EtudeSampleSource objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EtudeSampleSource objects.
     * @throws PropelException
     */
    public function countEtudeSampleSources(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeSampleSourcesPartial && !$this->isNew();
        if (null === $this->collEtudeSampleSources || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEtudeSampleSources) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEtudeSampleSources());
            }

            $query = ChildEtudeSampleSourceQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collEtudeSampleSources);
    }

    /**
     * Method called to associate a ChildEtudeSampleSource object to this object
     * through the ChildEtudeSampleSource foreign key attribute.
     *
     * @param  ChildEtudeSampleSource $l ChildEtudeSampleSource
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addEtudeSampleSource(ChildEtudeSampleSource $l)
    {
        if ($this->collEtudeSampleSources === null) {
            $this->initEtudeSampleSources();
            $this->collEtudeSampleSourcesPartial = true;
        }

        if (!$this->collEtudeSampleSources->contains($l)) {
            $this->doAddEtudeSampleSource($l);

            if ($this->etudeSampleSourcesScheduledForDeletion and $this->etudeSampleSourcesScheduledForDeletion->contains($l)) {
                $this->etudeSampleSourcesScheduledForDeletion->remove($this->etudeSampleSourcesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEtudeSampleSource $etudeSampleSource The ChildEtudeSampleSource object to add.
     */
    protected function doAddEtudeSampleSource(ChildEtudeSampleSource $etudeSampleSource)
    {
        $this->collEtudeSampleSources[]= $etudeSampleSource;
        $etudeSampleSource->setEtude($this);
    }

    /**
     * @param  ChildEtudeSampleSource $etudeSampleSource The ChildEtudeSampleSource object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeEtudeSampleSource(ChildEtudeSampleSource $etudeSampleSource)
    {
        if ($this->getEtudeSampleSources()->contains($etudeSampleSource)) {
            $pos = $this->collEtudeSampleSources->search($etudeSampleSource);
            $this->collEtudeSampleSources->remove($pos);
            if (null === $this->etudeSampleSourcesScheduledForDeletion) {
                $this->etudeSampleSourcesScheduledForDeletion = clone $this->collEtudeSampleSources;
                $this->etudeSampleSourcesScheduledForDeletion->clear();
            }
            $this->etudeSampleSourcesScheduledForDeletion[]= clone $etudeSampleSource;
            $etudeSampleSource->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related EtudeSampleSources from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEtudeSampleSource[] List of ChildEtudeSampleSource objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeSampleSource}> List of ChildEtudeSampleSource objects
     */
    public function getEtudeSampleSourcesJoinSampleSource(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEtudeSampleSourceQuery::create(null, $criteria);
        $query->joinWith('SampleSource', $joinBehavior);

        return $this->getEtudeSampleSources($query, $con);
    }

    /**
     * Clears out the collEtudeMethodologies collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEtudeMethodologies()
     */
    public function clearEtudeMethodologies()
    {
        $this->collEtudeMethodologies = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEtudeMethodologies collection loaded partially.
     */
    public function resetPartialEtudeMethodologies($v = true)
    {
        $this->collEtudeMethodologiesPartial = $v;
    }

    /**
     * Initializes the collEtudeMethodologies collection.
     *
     * By default this just sets the collEtudeMethodologies collection to an empty array (like clearcollEtudeMethodologies());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEtudeMethodologies($overrideExisting = true)
    {
        if (null !== $this->collEtudeMethodologies && !$overrideExisting) {
            return;
        }

        $collectionClassName = EtudeMethodologyTableMap::getTableMap()->getCollectionClassName();

        $this->collEtudeMethodologies = new $collectionClassName;
        $this->collEtudeMethodologies->setModel('\Model\EtudeMethodology');
    }

    /**
     * Gets an array of ChildEtudeMethodology objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEtudeMethodology[] List of ChildEtudeMethodology objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeMethodology> List of ChildEtudeMethodology objects
     * @throws PropelException
     */
    public function getEtudeMethodologies(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeMethodologiesPartial && !$this->isNew();
        if (null === $this->collEtudeMethodologies || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEtudeMethodologies) {
                    $this->initEtudeMethodologies();
                } else {
                    $collectionClassName = EtudeMethodologyTableMap::getTableMap()->getCollectionClassName();

                    $collEtudeMethodologies = new $collectionClassName;
                    $collEtudeMethodologies->setModel('\Model\EtudeMethodology');

                    return $collEtudeMethodologies;
                }
            } else {
                $collEtudeMethodologies = ChildEtudeMethodologyQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEtudeMethodologiesPartial && count($collEtudeMethodologies)) {
                        $this->initEtudeMethodologies(false);

                        foreach ($collEtudeMethodologies as $obj) {
                            if (false == $this->collEtudeMethodologies->contains($obj)) {
                                $this->collEtudeMethodologies->append($obj);
                            }
                        }

                        $this->collEtudeMethodologiesPartial = true;
                    }

                    return $collEtudeMethodologies;
                }

                if ($partial && $this->collEtudeMethodologies) {
                    foreach ($this->collEtudeMethodologies as $obj) {
                        if ($obj->isNew()) {
                            $collEtudeMethodologies[] = $obj;
                        }
                    }
                }

                $this->collEtudeMethodologies = $collEtudeMethodologies;
                $this->collEtudeMethodologiesPartial = false;
            }
        }

        return $this->collEtudeMethodologies;
    }

    /**
     * Sets a collection of ChildEtudeMethodology objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $etudeMethodologies A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setEtudeMethodologies(Collection $etudeMethodologies, ConnectionInterface $con = null)
    {
        /** @var ChildEtudeMethodology[] $etudeMethodologiesToDelete */
        $etudeMethodologiesToDelete = $this->getEtudeMethodologies(new Criteria(), $con)->diff($etudeMethodologies);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->etudeMethodologiesScheduledForDeletion = clone $etudeMethodologiesToDelete;

        foreach ($etudeMethodologiesToDelete as $etudeMethodologyRemoved) {
            $etudeMethodologyRemoved->setEtude(null);
        }

        $this->collEtudeMethodologies = null;
        foreach ($etudeMethodologies as $etudeMethodology) {
            $this->addEtudeMethodology($etudeMethodology);
        }

        $this->collEtudeMethodologies = $etudeMethodologies;
        $this->collEtudeMethodologiesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EtudeMethodology objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EtudeMethodology objects.
     * @throws PropelException
     */
    public function countEtudeMethodologies(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeMethodologiesPartial && !$this->isNew();
        if (null === $this->collEtudeMethodologies || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEtudeMethodologies) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEtudeMethodologies());
            }

            $query = ChildEtudeMethodologyQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collEtudeMethodologies);
    }

    /**
     * Method called to associate a ChildEtudeMethodology object to this object
     * through the ChildEtudeMethodology foreign key attribute.
     *
     * @param  ChildEtudeMethodology $l ChildEtudeMethodology
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addEtudeMethodology(ChildEtudeMethodology $l)
    {
        if ($this->collEtudeMethodologies === null) {
            $this->initEtudeMethodologies();
            $this->collEtudeMethodologiesPartial = true;
        }

        if (!$this->collEtudeMethodologies->contains($l)) {
            $this->doAddEtudeMethodology($l);

            if ($this->etudeMethodologiesScheduledForDeletion and $this->etudeMethodologiesScheduledForDeletion->contains($l)) {
                $this->etudeMethodologiesScheduledForDeletion->remove($this->etudeMethodologiesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEtudeMethodology $etudeMethodology The ChildEtudeMethodology object to add.
     */
    protected function doAddEtudeMethodology(ChildEtudeMethodology $etudeMethodology)
    {
        $this->collEtudeMethodologies[]= $etudeMethodology;
        $etudeMethodology->setEtude($this);
    }

    /**
     * @param  ChildEtudeMethodology $etudeMethodology The ChildEtudeMethodology object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeEtudeMethodology(ChildEtudeMethodology $etudeMethodology)
    {
        if ($this->getEtudeMethodologies()->contains($etudeMethodology)) {
            $pos = $this->collEtudeMethodologies->search($etudeMethodology);
            $this->collEtudeMethodologies->remove($pos);
            if (null === $this->etudeMethodologiesScheduledForDeletion) {
                $this->etudeMethodologiesScheduledForDeletion = clone $this->collEtudeMethodologies;
                $this->etudeMethodologiesScheduledForDeletion->clear();
            }
            $this->etudeMethodologiesScheduledForDeletion[]= clone $etudeMethodology;
            $etudeMethodology->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related EtudeMethodologies from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEtudeMethodology[] List of ChildEtudeMethodology objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeMethodology}> List of ChildEtudeMethodology objects
     */
    public function getEtudeMethodologiesJoinMethodology(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEtudeMethodologyQuery::create(null, $criteria);
        $query->joinWith('Methodology', $joinBehavior);

        return $this->getEtudeMethodologies($query, $con);
    }

    /**
     * Clears out the collFactures collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addFactures()
     */
    public function clearFactures()
    {
        $this->collFactures = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collFactures collection loaded partially.
     */
    public function resetPartialFactures($v = true)
    {
        $this->collFacturesPartial = $v;
    }

    /**
     * Initializes the collFactures collection.
     *
     * By default this just sets the collFactures collection to an empty array (like clearcollFactures());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initFactures($overrideExisting = true)
    {
        if (null !== $this->collFactures && !$overrideExisting) {
            return;
        }

        $collectionClassName = FactureTableMap::getTableMap()->getCollectionClassName();

        $this->collFactures = new $collectionClassName;
        $this->collFactures->setModel('\Model\Facture');
    }

    /**
     * Gets an array of ChildFacture objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildFacture[] List of ChildFacture objects
     * @phpstan-return ObjectCollection&\Traversable<ChildFacture> List of ChildFacture objects
     * @throws PropelException
     */
    public function getFactures(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collFacturesPartial && !$this->isNew();
        if (null === $this->collFactures || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collFactures) {
                    $this->initFactures();
                } else {
                    $collectionClassName = FactureTableMap::getTableMap()->getCollectionClassName();

                    $collFactures = new $collectionClassName;
                    $collFactures->setModel('\Model\Facture');

                    return $collFactures;
                }
            } else {
                $collFactures = ChildFactureQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collFacturesPartial && count($collFactures)) {
                        $this->initFactures(false);

                        foreach ($collFactures as $obj) {
                            if (false == $this->collFactures->contains($obj)) {
                                $this->collFactures->append($obj);
                            }
                        }

                        $this->collFacturesPartial = true;
                    }

                    return $collFactures;
                }

                if ($partial && $this->collFactures) {
                    foreach ($this->collFactures as $obj) {
                        if ($obj->isNew()) {
                            $collFactures[] = $obj;
                        }
                    }
                }

                $this->collFactures = $collFactures;
                $this->collFacturesPartial = false;
            }
        }

        return $this->collFactures;
    }

    /**
     * Sets a collection of ChildFacture objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $factures A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setFactures(Collection $factures, ConnectionInterface $con = null)
    {
        /** @var ChildFacture[] $facturesToDelete */
        $facturesToDelete = $this->getFactures(new Criteria(), $con)->diff($factures);


        $this->facturesScheduledForDeletion = $facturesToDelete;

        foreach ($facturesToDelete as $factureRemoved) {
            $factureRemoved->setEtude(null);
        }

        $this->collFactures = null;
        foreach ($factures as $facture) {
            $this->addFacture($facture);
        }

        $this->collFactures = $factures;
        $this->collFacturesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Facture objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related Facture objects.
     * @throws PropelException
     */
    public function countFactures(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collFacturesPartial && !$this->isNew();
        if (null === $this->collFactures || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collFactures) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getFactures());
            }

            $query = ChildFactureQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collFactures);
    }

    /**
     * Method called to associate a ChildFacture object to this object
     * through the ChildFacture foreign key attribute.
     *
     * @param  ChildFacture $l ChildFacture
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addFacture(ChildFacture $l)
    {
        if ($this->collFactures === null) {
            $this->initFactures();
            $this->collFacturesPartial = true;
        }

        if (!$this->collFactures->contains($l)) {
            $this->doAddFacture($l);

            if ($this->facturesScheduledForDeletion and $this->facturesScheduledForDeletion->contains($l)) {
                $this->facturesScheduledForDeletion->remove($this->facturesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildFacture $facture The ChildFacture object to add.
     */
    protected function doAddFacture(ChildFacture $facture)
    {
        $this->collFactures[]= $facture;
        $facture->setEtude($this);
    }

    /**
     * @param  ChildFacture $facture The ChildFacture object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeFacture(ChildFacture $facture)
    {
        if ($this->getFactures()->contains($facture)) {
            $pos = $this->collFactures->search($facture);
            $this->collFactures->remove($pos);
            if (null === $this->facturesScheduledForDeletion) {
                $this->facturesScheduledForDeletion = clone $this->collFactures;
                $this->facturesScheduledForDeletion->clear();
            }
            $this->facturesScheduledForDeletion[]= clone $facture;
            $facture->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Factures from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildFacture[] List of ChildFacture objects
     * @phpstan-return ObjectCollection&\Traversable<ChildFacture}> List of ChildFacture objects
     */
    public function getFacturesJoinJob(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildFactureQuery::create(null, $criteria);
        $query->joinWith('Job', $joinBehavior);

        return $this->getFactures($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Factures from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildFacture[] List of ChildFacture objects
     * @phpstan-return ObjectCollection&\Traversable<ChildFacture}> List of ChildFacture objects
     */
    public function getFacturesJoinContact(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildFactureQuery::create(null, $criteria);
        $query->joinWith('Contact', $joinBehavior);

        return $this->getFactures($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Factures from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildFacture[] List of ChildFacture objects
     * @phpstan-return ObjectCollection&\Traversable<ChildFacture}> List of ChildFacture objects
     */
    public function getFacturesJoinDocument(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildFactureQuery::create(null, $criteria);
        $query->joinWith('Document', $joinBehavior);

        return $this->getFactures($query, $con);
    }

    /**
     * Clears out the collJobEtudes collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addJobEtudes()
     */
    public function clearJobEtudes()
    {
        $this->collJobEtudes = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collJobEtudes collection loaded partially.
     */
    public function resetPartialJobEtudes($v = true)
    {
        $this->collJobEtudesPartial = $v;
    }

    /**
     * Initializes the collJobEtudes collection.
     *
     * By default this just sets the collJobEtudes collection to an empty array (like clearcollJobEtudes());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initJobEtudes($overrideExisting = true)
    {
        if (null !== $this->collJobEtudes && !$overrideExisting) {
            return;
        }

        $collectionClassName = JobTableMap::getTableMap()->getCollectionClassName();

        $this->collJobEtudes = new $collectionClassName;
        $this->collJobEtudes->setModel('\Model\Job');
    }

    /**
     * Gets an array of ChildJob objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob> List of ChildJob objects
     * @throws PropelException
     */
    public function getJobEtudes(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collJobEtudesPartial && !$this->isNew();
        if (null === $this->collJobEtudes || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collJobEtudes) {
                    $this->initJobEtudes();
                } else {
                    $collectionClassName = JobTableMap::getTableMap()->getCollectionClassName();

                    $collJobEtudes = new $collectionClassName;
                    $collJobEtudes->setModel('\Model\Job');

                    return $collJobEtudes;
                }
            } else {
                $collJobEtudes = ChildJobQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collJobEtudesPartial && count($collJobEtudes)) {
                        $this->initJobEtudes(false);

                        foreach ($collJobEtudes as $obj) {
                            if (false == $this->collJobEtudes->contains($obj)) {
                                $this->collJobEtudes->append($obj);
                            }
                        }

                        $this->collJobEtudesPartial = true;
                    }

                    return $collJobEtudes;
                }

                if ($partial && $this->collJobEtudes) {
                    foreach ($this->collJobEtudes as $obj) {
                        if ($obj->isNew()) {
                            $collJobEtudes[] = $obj;
                        }
                    }
                }

                $this->collJobEtudes = $collJobEtudes;
                $this->collJobEtudesPartial = false;
            }
        }

        return $this->collJobEtudes;
    }

    /**
     * Sets a collection of ChildJob objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $jobEtudes A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setJobEtudes(Collection $jobEtudes, ConnectionInterface $con = null)
    {
        /** @var ChildJob[] $jobEtudesToDelete */
        $jobEtudesToDelete = $this->getJobEtudes(new Criteria(), $con)->diff($jobEtudes);


        $this->jobEtudesScheduledForDeletion = $jobEtudesToDelete;

        foreach ($jobEtudesToDelete as $jobEtudeRemoved) {
            $jobEtudeRemoved->setEtude(null);
        }

        $this->collJobEtudes = null;
        foreach ($jobEtudes as $jobEtude) {
            $this->addJobEtude($jobEtude);
        }

        $this->collJobEtudes = $jobEtudes;
        $this->collJobEtudesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Job objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related Job objects.
     * @throws PropelException
     */
    public function countJobEtudes(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collJobEtudesPartial && !$this->isNew();
        if (null === $this->collJobEtudes || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collJobEtudes) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getJobEtudes());
            }

            $query = ChildJobQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collJobEtudes);
    }

    /**
     * Method called to associate a ChildJob object to this object
     * through the ChildJob foreign key attribute.
     *
     * @param  ChildJob $l ChildJob
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addJobEtude(ChildJob $l)
    {
        if ($this->collJobEtudes === null) {
            $this->initJobEtudes();
            $this->collJobEtudesPartial = true;
        }

        if (!$this->collJobEtudes->contains($l)) {
            $this->doAddJobEtude($l);

            if ($this->jobEtudesScheduledForDeletion and $this->jobEtudesScheduledForDeletion->contains($l)) {
                $this->jobEtudesScheduledForDeletion->remove($this->jobEtudesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildJob $jobEtude The ChildJob object to add.
     */
    protected function doAddJobEtude(ChildJob $jobEtude)
    {
        $this->collJobEtudes[]= $jobEtude;
        $jobEtude->setEtude($this);
    }

    /**
     * @param  ChildJob $jobEtude The ChildJob object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeJobEtude(ChildJob $jobEtude)
    {
        if ($this->getJobEtudes()->contains($jobEtude)) {
            $pos = $this->collJobEtudes->search($jobEtude);
            $this->collJobEtudes->remove($pos);
            if (null === $this->jobEtudesScheduledForDeletion) {
                $this->jobEtudesScheduledForDeletion = clone $this->collJobEtudes;
                $this->jobEtudesScheduledForDeletion->clear();
            }
            $this->jobEtudesScheduledForDeletion[]= clone $jobEtude;
            $jobEtude->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinUpdatedBy(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('UpdatedBy', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinProjectCordinator(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('ProjectCordinator', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinJobLocation(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('JobLocation', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinLocationPrefix(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('LocationPrefix', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinPlatform(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('Platform', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinJobProjectManager(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('JobProjectManager', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinJobTechnicalProjectManager(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('JobTechnicalProjectManager', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinFacilityRating(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('FacilityRating', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinFacilityStaff(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('FacilityStaff', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinProjectManagement(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('ProjectManagement', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinRecruitmentRating(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('RecruitmentRating', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinJobAccountManager(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('JobAccountManager', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinStatus(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('Status', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinCountry(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('Country', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinEndDateReason(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('EndDateReason', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinSite(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('Site', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinBidJob(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('BidJob', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinCallCenter(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('CallCenter', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related JobEtudes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildJob[] List of ChildJob objects
     * @phpstan-return ObjectCollection&\Traversable<ChildJob}> List of ChildJob objects
     */
    public function getJobEtudesJoinAmReasonType(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildJobQuery::create(null, $criteria);
        $query->joinWith('AmReasonType', $joinBehavior);

        return $this->getJobEtudes($query, $con);
    }

    /**
     * Clears out the collReglements collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addReglements()
     */
    public function clearReglements()
    {
        $this->collReglements = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collReglements collection loaded partially.
     */
    public function resetPartialReglements($v = true)
    {
        $this->collReglementsPartial = $v;
    }

    /**
     * Initializes the collReglements collection.
     *
     * By default this just sets the collReglements collection to an empty array (like clearcollReglements());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initReglements($overrideExisting = true)
    {
        if (null !== $this->collReglements && !$overrideExisting) {
            return;
        }

        $collectionClassName = ReglementTableMap::getTableMap()->getCollectionClassName();

        $this->collReglements = new $collectionClassName;
        $this->collReglements->setModel('\Model\Reglement');
    }

    /**
     * Gets an array of ChildReglement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildReglement[] List of ChildReglement objects
     * @phpstan-return ObjectCollection&\Traversable<ChildReglement> List of ChildReglement objects
     * @throws PropelException
     */
    public function getReglements(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collReglementsPartial && !$this->isNew();
        if (null === $this->collReglements || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collReglements) {
                    $this->initReglements();
                } else {
                    $collectionClassName = ReglementTableMap::getTableMap()->getCollectionClassName();

                    $collReglements = new $collectionClassName;
                    $collReglements->setModel('\Model\Reglement');

                    return $collReglements;
                }
            } else {
                $collReglements = ChildReglementQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collReglementsPartial && count($collReglements)) {
                        $this->initReglements(false);

                        foreach ($collReglements as $obj) {
                            if (false == $this->collReglements->contains($obj)) {
                                $this->collReglements->append($obj);
                            }
                        }

                        $this->collReglementsPartial = true;
                    }

                    return $collReglements;
                }

                if ($partial && $this->collReglements) {
                    foreach ($this->collReglements as $obj) {
                        if ($obj->isNew()) {
                            $collReglements[] = $obj;
                        }
                    }
                }

                $this->collReglements = $collReglements;
                $this->collReglementsPartial = false;
            }
        }

        return $this->collReglements;
    }

    /**
     * Sets a collection of ChildReglement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $reglements A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setReglements(Collection $reglements, ConnectionInterface $con = null)
    {
        /** @var ChildReglement[] $reglementsToDelete */
        $reglementsToDelete = $this->getReglements(new Criteria(), $con)->diff($reglements);


        $this->reglementsScheduledForDeletion = $reglementsToDelete;

        foreach ($reglementsToDelete as $reglementRemoved) {
            $reglementRemoved->setEtude(null);
        }

        $this->collReglements = null;
        foreach ($reglements as $reglement) {
            $this->addReglement($reglement);
        }

        $this->collReglements = $reglements;
        $this->collReglementsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related Reglement objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related Reglement objects.
     * @throws PropelException
     */
    public function countReglements(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collReglementsPartial && !$this->isNew();
        if (null === $this->collReglements || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collReglements) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getReglements());
            }

            $query = ChildReglementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collReglements);
    }

    /**
     * Method called to associate a ChildReglement object to this object
     * through the ChildReglement foreign key attribute.
     *
     * @param  ChildReglement $l ChildReglement
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addReglement(ChildReglement $l)
    {
        if ($this->collReglements === null) {
            $this->initReglements();
            $this->collReglementsPartial = true;
        }

        if (!$this->collReglements->contains($l)) {
            $this->doAddReglement($l);

            if ($this->reglementsScheduledForDeletion and $this->reglementsScheduledForDeletion->contains($l)) {
                $this->reglementsScheduledForDeletion->remove($this->reglementsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildReglement $reglement The ChildReglement object to add.
     */
    protected function doAddReglement(ChildReglement $reglement)
    {
        $this->collReglements[]= $reglement;
        $reglement->setEtude($this);
    }

    /**
     * @param  ChildReglement $reglement The ChildReglement object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeReglement(ChildReglement $reglement)
    {
        if ($this->getReglements()->contains($reglement)) {
            $pos = $this->collReglements->search($reglement);
            $this->collReglements->remove($pos);
            if (null === $this->reglementsScheduledForDeletion) {
                $this->reglementsScheduledForDeletion = clone $this->collReglements;
                $this->reglementsScheduledForDeletion->clear();
            }
            $this->reglementsScheduledForDeletion[]= clone $reglement;
            $reglement->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Reglements from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildReglement[] List of ChildReglement objects
     * @phpstan-return ObjectCollection&\Traversable<ChildReglement}> List of ChildReglement objects
     */
    public function getReglementsJoinDocument(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildReglementQuery::create(null, $criteria);
        $query->joinWith('Document', $joinBehavior);

        return $this->getReglements($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Reglements from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildReglement[] List of ChildReglement objects
     * @phpstan-return ObjectCollection&\Traversable<ChildReglement}> List of ChildReglement objects
     */
    public function getReglementsJoinBanque(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildReglementQuery::create(null, $criteria);
        $query->joinWith('Banque', $joinBehavior);

        return $this->getReglements($query, $con);
    }

    /**
     * Clears out the collSectors collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addSectors()
     */
    public function clearSectors()
    {
        $this->collSectors = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collSectors collection loaded partially.
     */
    public function resetPartialSectors($v = true)
    {
        $this->collSectorsPartial = $v;
    }

    /**
     * Initializes the collSectors collection.
     *
     * By default this just sets the collSectors collection to an empty array (like clearcollSectors());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initSectors($overrideExisting = true)
    {
        if (null !== $this->collSectors && !$overrideExisting) {
            return;
        }

        $collectionClassName = RefSalesForceEtudeSectorTableMap::getTableMap()->getCollectionClassName();

        $this->collSectors = new $collectionClassName;
        $this->collSectors->setModel('\Model\RefSalesForceEtudeSector');
    }

    /**
     * Gets an array of ChildRefSalesForceEtudeSector objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildRefSalesForceEtudeSector[] List of ChildRefSalesForceEtudeSector objects
     * @phpstan-return ObjectCollection&\Traversable<ChildRefSalesForceEtudeSector> List of ChildRefSalesForceEtudeSector objects
     * @throws PropelException
     */
    public function getSectors(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collSectorsPartial && !$this->isNew();
        if (null === $this->collSectors || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collSectors) {
                    $this->initSectors();
                } else {
                    $collectionClassName = RefSalesForceEtudeSectorTableMap::getTableMap()->getCollectionClassName();

                    $collSectors = new $collectionClassName;
                    $collSectors->setModel('\Model\RefSalesForceEtudeSector');

                    return $collSectors;
                }
            } else {
                $collSectors = ChildRefSalesForceEtudeSectorQuery::create(null, $criteria)
                    ->filterByEtudeSector($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collSectorsPartial && count($collSectors)) {
                        $this->initSectors(false);

                        foreach ($collSectors as $obj) {
                            if (false == $this->collSectors->contains($obj)) {
                                $this->collSectors->append($obj);
                            }
                        }

                        $this->collSectorsPartial = true;
                    }

                    return $collSectors;
                }

                if ($partial && $this->collSectors) {
                    foreach ($this->collSectors as $obj) {
                        if ($obj->isNew()) {
                            $collSectors[] = $obj;
                        }
                    }
                }

                $this->collSectors = $collSectors;
                $this->collSectorsPartial = false;
            }
        }

        return $this->collSectors;
    }

    /**
     * Sets a collection of ChildRefSalesForceEtudeSector objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $sectors A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setSectors(Collection $sectors, ConnectionInterface $con = null)
    {
        /** @var ChildRefSalesForceEtudeSector[] $sectorsToDelete */
        $sectorsToDelete = $this->getSectors(new Criteria(), $con)->diff($sectors);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->sectorsScheduledForDeletion = clone $sectorsToDelete;

        foreach ($sectorsToDelete as $sectorRemoved) {
            $sectorRemoved->setEtudeSector(null);
        }

        $this->collSectors = null;
        foreach ($sectors as $sector) {
            $this->addSector($sector);
        }

        $this->collSectors = $sectors;
        $this->collSectorsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related RefSalesForceEtudeSector objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related RefSalesForceEtudeSector objects.
     * @throws PropelException
     */
    public function countSectors(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collSectorsPartial && !$this->isNew();
        if (null === $this->collSectors || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collSectors) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getSectors());
            }

            $query = ChildRefSalesForceEtudeSectorQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtudeSector($this)
                ->count($con);
        }

        return count($this->collSectors);
    }

    /**
     * Method called to associate a ChildRefSalesForceEtudeSector object to this object
     * through the ChildRefSalesForceEtudeSector foreign key attribute.
     *
     * @param  ChildRefSalesForceEtudeSector $l ChildRefSalesForceEtudeSector
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addSector(ChildRefSalesForceEtudeSector $l)
    {
        if ($this->collSectors === null) {
            $this->initSectors();
            $this->collSectorsPartial = true;
        }

        if (!$this->collSectors->contains($l)) {
            $this->doAddSector($l);

            if ($this->sectorsScheduledForDeletion and $this->sectorsScheduledForDeletion->contains($l)) {
                $this->sectorsScheduledForDeletion->remove($this->sectorsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildRefSalesForceEtudeSector $sector The ChildRefSalesForceEtudeSector object to add.
     */
    protected function doAddSector(ChildRefSalesForceEtudeSector $sector)
    {
        $this->collSectors[]= $sector;
        $sector->setEtudeSector($this);
    }

    /**
     * @param  ChildRefSalesForceEtudeSector $sector The ChildRefSalesForceEtudeSector object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeSector(ChildRefSalesForceEtudeSector $sector)
    {
        if ($this->getSectors()->contains($sector)) {
            $pos = $this->collSectors->search($sector);
            $this->collSectors->remove($pos);
            if (null === $this->sectorsScheduledForDeletion) {
                $this->sectorsScheduledForDeletion = clone $this->collSectors;
                $this->sectorsScheduledForDeletion->clear();
            }
            $this->sectorsScheduledForDeletion[]= clone $sector;
            $sector->setEtudeSector(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related Sectors from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildRefSalesForceEtudeSector[] List of ChildRefSalesForceEtudeSector objects
     * @phpstan-return ObjectCollection&\Traversable<ChildRefSalesForceEtudeSector}> List of ChildRefSalesForceEtudeSector objects
     */
    public function getSectorsJoinRefSalesForceEtudeRefSector(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildRefSalesForceEtudeSectorQuery::create(null, $criteria);
        $query->joinWith('RefSalesForceEtudeRefSector', $joinBehavior);

        return $this->getSectors($query, $con);
    }

    /**
     * Clears out the collEtudeCheckListValidations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEtudeCheckListValidations()
     */
    public function clearEtudeCheckListValidations()
    {
        $this->collEtudeCheckListValidations = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEtudeCheckListValidations collection loaded partially.
     */
    public function resetPartialEtudeCheckListValidations($v = true)
    {
        $this->collEtudeCheckListValidationsPartial = $v;
    }

    /**
     * Initializes the collEtudeCheckListValidations collection.
     *
     * By default this just sets the collEtudeCheckListValidations collection to an empty array (like clearcollEtudeCheckListValidations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEtudeCheckListValidations($overrideExisting = true)
    {
        if (null !== $this->collEtudeCheckListValidations && !$overrideExisting) {
            return;
        }

        $collectionClassName = EtudeCheckListValidationTableMap::getTableMap()->getCollectionClassName();

        $this->collEtudeCheckListValidations = new $collectionClassName;
        $this->collEtudeCheckListValidations->setModel('\Model\EtudeCheckListValidation');
    }

    /**
     * Gets an array of ChildEtudeCheckListValidation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEtudeCheckListValidation[] List of ChildEtudeCheckListValidation objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeCheckListValidation> List of ChildEtudeCheckListValidation objects
     * @throws PropelException
     */
    public function getEtudeCheckListValidations(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeCheckListValidationsPartial && !$this->isNew();
        if (null === $this->collEtudeCheckListValidations || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEtudeCheckListValidations) {
                    $this->initEtudeCheckListValidations();
                } else {
                    $collectionClassName = EtudeCheckListValidationTableMap::getTableMap()->getCollectionClassName();

                    $collEtudeCheckListValidations = new $collectionClassName;
                    $collEtudeCheckListValidations->setModel('\Model\EtudeCheckListValidation');

                    return $collEtudeCheckListValidations;
                }
            } else {
                $collEtudeCheckListValidations = ChildEtudeCheckListValidationQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEtudeCheckListValidationsPartial && count($collEtudeCheckListValidations)) {
                        $this->initEtudeCheckListValidations(false);

                        foreach ($collEtudeCheckListValidations as $obj) {
                            if (false == $this->collEtudeCheckListValidations->contains($obj)) {
                                $this->collEtudeCheckListValidations->append($obj);
                            }
                        }

                        $this->collEtudeCheckListValidationsPartial = true;
                    }

                    return $collEtudeCheckListValidations;
                }

                if ($partial && $this->collEtudeCheckListValidations) {
                    foreach ($this->collEtudeCheckListValidations as $obj) {
                        if ($obj->isNew()) {
                            $collEtudeCheckListValidations[] = $obj;
                        }
                    }
                }

                $this->collEtudeCheckListValidations = $collEtudeCheckListValidations;
                $this->collEtudeCheckListValidationsPartial = false;
            }
        }

        return $this->collEtudeCheckListValidations;
    }

    /**
     * Sets a collection of ChildEtudeCheckListValidation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $etudeCheckListValidations A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setEtudeCheckListValidations(Collection $etudeCheckListValidations, ConnectionInterface $con = null)
    {
        /** @var ChildEtudeCheckListValidation[] $etudeCheckListValidationsToDelete */
        $etudeCheckListValidationsToDelete = $this->getEtudeCheckListValidations(new Criteria(), $con)->diff($etudeCheckListValidations);


        $this->etudeCheckListValidationsScheduledForDeletion = $etudeCheckListValidationsToDelete;

        foreach ($etudeCheckListValidationsToDelete as $etudeCheckListValidationRemoved) {
            $etudeCheckListValidationRemoved->setEtude(null);
        }

        $this->collEtudeCheckListValidations = null;
        foreach ($etudeCheckListValidations as $etudeCheckListValidation) {
            $this->addEtudeCheckListValidation($etudeCheckListValidation);
        }

        $this->collEtudeCheckListValidations = $etudeCheckListValidations;
        $this->collEtudeCheckListValidationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EtudeCheckListValidation objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EtudeCheckListValidation objects.
     * @throws PropelException
     */
    public function countEtudeCheckListValidations(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeCheckListValidationsPartial && !$this->isNew();
        if (null === $this->collEtudeCheckListValidations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEtudeCheckListValidations) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEtudeCheckListValidations());
            }

            $query = ChildEtudeCheckListValidationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collEtudeCheckListValidations);
    }

    /**
     * Method called to associate a ChildEtudeCheckListValidation object to this object
     * through the ChildEtudeCheckListValidation foreign key attribute.
     *
     * @param  ChildEtudeCheckListValidation $l ChildEtudeCheckListValidation
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addEtudeCheckListValidation(ChildEtudeCheckListValidation $l)
    {
        if ($this->collEtudeCheckListValidations === null) {
            $this->initEtudeCheckListValidations();
            $this->collEtudeCheckListValidationsPartial = true;
        }

        if (!$this->collEtudeCheckListValidations->contains($l)) {
            $this->doAddEtudeCheckListValidation($l);

            if ($this->etudeCheckListValidationsScheduledForDeletion and $this->etudeCheckListValidationsScheduledForDeletion->contains($l)) {
                $this->etudeCheckListValidationsScheduledForDeletion->remove($this->etudeCheckListValidationsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEtudeCheckListValidation $etudeCheckListValidation The ChildEtudeCheckListValidation object to add.
     */
    protected function doAddEtudeCheckListValidation(ChildEtudeCheckListValidation $etudeCheckListValidation)
    {
        $this->collEtudeCheckListValidations[]= $etudeCheckListValidation;
        $etudeCheckListValidation->setEtude($this);
    }

    /**
     * @param  ChildEtudeCheckListValidation $etudeCheckListValidation The ChildEtudeCheckListValidation object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeEtudeCheckListValidation(ChildEtudeCheckListValidation $etudeCheckListValidation)
    {
        if ($this->getEtudeCheckListValidations()->contains($etudeCheckListValidation)) {
            $pos = $this->collEtudeCheckListValidations->search($etudeCheckListValidation);
            $this->collEtudeCheckListValidations->remove($pos);
            if (null === $this->etudeCheckListValidationsScheduledForDeletion) {
                $this->etudeCheckListValidationsScheduledForDeletion = clone $this->collEtudeCheckListValidations;
                $this->etudeCheckListValidationsScheduledForDeletion->clear();
            }
            $this->etudeCheckListValidationsScheduledForDeletion[]= clone $etudeCheckListValidation;
            $etudeCheckListValidation->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related EtudeCheckListValidations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEtudeCheckListValidation[] List of ChildEtudeCheckListValidation objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeCheckListValidation}> List of ChildEtudeCheckListValidation objects
     */
    public function getEtudeCheckListValidationsJoinEtudeCheckList(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEtudeCheckListValidationQuery::create(null, $criteria);
        $query->joinWith('EtudeCheckList', $joinBehavior);

        return $this->getEtudeCheckListValidations($query, $con);
    }

    /**
     * Clears out the collEtudeFichiers collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEtudeFichiers()
     */
    public function clearEtudeFichiers()
    {
        $this->collEtudeFichiers = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEtudeFichiers collection loaded partially.
     */
    public function resetPartialEtudeFichiers($v = true)
    {
        $this->collEtudeFichiersPartial = $v;
    }

    /**
     * Initializes the collEtudeFichiers collection.
     *
     * By default this just sets the collEtudeFichiers collection to an empty array (like clearcollEtudeFichiers());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEtudeFichiers($overrideExisting = true)
    {
        if (null !== $this->collEtudeFichiers && !$overrideExisting) {
            return;
        }

        $collectionClassName = EtudeFichierTableMap::getTableMap()->getCollectionClassName();

        $this->collEtudeFichiers = new $collectionClassName;
        $this->collEtudeFichiers->setModel('\Model\EtudeFichier');
    }

    /**
     * Gets an array of ChildEtudeFichier objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEtudeFichier[] List of ChildEtudeFichier objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeFichier> List of ChildEtudeFichier objects
     * @throws PropelException
     */
    public function getEtudeFichiers(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeFichiersPartial && !$this->isNew();
        if (null === $this->collEtudeFichiers || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEtudeFichiers) {
                    $this->initEtudeFichiers();
                } else {
                    $collectionClassName = EtudeFichierTableMap::getTableMap()->getCollectionClassName();

                    $collEtudeFichiers = new $collectionClassName;
                    $collEtudeFichiers->setModel('\Model\EtudeFichier');

                    return $collEtudeFichiers;
                }
            } else {
                $collEtudeFichiers = ChildEtudeFichierQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEtudeFichiersPartial && count($collEtudeFichiers)) {
                        $this->initEtudeFichiers(false);

                        foreach ($collEtudeFichiers as $obj) {
                            if (false == $this->collEtudeFichiers->contains($obj)) {
                                $this->collEtudeFichiers->append($obj);
                            }
                        }

                        $this->collEtudeFichiersPartial = true;
                    }

                    return $collEtudeFichiers;
                }

                if ($partial && $this->collEtudeFichiers) {
                    foreach ($this->collEtudeFichiers as $obj) {
                        if ($obj->isNew()) {
                            $collEtudeFichiers[] = $obj;
                        }
                    }
                }

                $this->collEtudeFichiers = $collEtudeFichiers;
                $this->collEtudeFichiersPartial = false;
            }
        }

        return $this->collEtudeFichiers;
    }

    /**
     * Sets a collection of ChildEtudeFichier objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $etudeFichiers A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setEtudeFichiers(Collection $etudeFichiers, ConnectionInterface $con = null)
    {
        /** @var ChildEtudeFichier[] $etudeFichiersToDelete */
        $etudeFichiersToDelete = $this->getEtudeFichiers(new Criteria(), $con)->diff($etudeFichiers);


        //since at least one column in the foreign key is at the same time a PK
        //we can not just set a PK to NULL in the lines below. We have to store
        //a backup of all values, so we are able to manipulate these items based on the onDelete value later.
        $this->etudeFichiersScheduledForDeletion = clone $etudeFichiersToDelete;

        foreach ($etudeFichiersToDelete as $etudeFichierRemoved) {
            $etudeFichierRemoved->setEtude(null);
        }

        $this->collEtudeFichiers = null;
        foreach ($etudeFichiers as $etudeFichier) {
            $this->addEtudeFichier($etudeFichier);
        }

        $this->collEtudeFichiers = $etudeFichiers;
        $this->collEtudeFichiersPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EtudeFichier objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EtudeFichier objects.
     * @throws PropelException
     */
    public function countEtudeFichiers(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeFichiersPartial && !$this->isNew();
        if (null === $this->collEtudeFichiers || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEtudeFichiers) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEtudeFichiers());
            }

            $query = ChildEtudeFichierQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collEtudeFichiers);
    }

    /**
     * Method called to associate a ChildEtudeFichier object to this object
     * through the ChildEtudeFichier foreign key attribute.
     *
     * @param  ChildEtudeFichier $l ChildEtudeFichier
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addEtudeFichier(ChildEtudeFichier $l)
    {
        if ($this->collEtudeFichiers === null) {
            $this->initEtudeFichiers();
            $this->collEtudeFichiersPartial = true;
        }

        if (!$this->collEtudeFichiers->contains($l)) {
            $this->doAddEtudeFichier($l);

            if ($this->etudeFichiersScheduledForDeletion and $this->etudeFichiersScheduledForDeletion->contains($l)) {
                $this->etudeFichiersScheduledForDeletion->remove($this->etudeFichiersScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEtudeFichier $etudeFichier The ChildEtudeFichier object to add.
     */
    protected function doAddEtudeFichier(ChildEtudeFichier $etudeFichier)
    {
        $this->collEtudeFichiers[]= $etudeFichier;
        $etudeFichier->setEtude($this);
    }

    /**
     * @param  ChildEtudeFichier $etudeFichier The ChildEtudeFichier object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeEtudeFichier(ChildEtudeFichier $etudeFichier)
    {
        if ($this->getEtudeFichiers()->contains($etudeFichier)) {
            $pos = $this->collEtudeFichiers->search($etudeFichier);
            $this->collEtudeFichiers->remove($pos);
            if (null === $this->etudeFichiersScheduledForDeletion) {
                $this->etudeFichiersScheduledForDeletion = clone $this->collEtudeFichiers;
                $this->etudeFichiersScheduledForDeletion->clear();
            }
            $this->etudeFichiersScheduledForDeletion[]= clone $etudeFichier;
            $etudeFichier->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related EtudeFichiers from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEtudeFichier[] List of ChildEtudeFichier objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeFichier}> List of ChildEtudeFichier objects
     */
    public function getEtudeFichiersJoinFichier(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEtudeFichierQuery::create(null, $criteria);
        $query->joinWith('Fichier', $joinBehavior);

        return $this->getEtudeFichiers($query, $con);
    }

    /**
     * Clears out the collLogProjectStatuses collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addLogProjectStatuses()
     */
    public function clearLogProjectStatuses()
    {
        $this->collLogProjectStatuses = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collLogProjectStatuses collection loaded partially.
     */
    public function resetPartialLogProjectStatuses($v = true)
    {
        $this->collLogProjectStatusesPartial = $v;
    }

    /**
     * Initializes the collLogProjectStatuses collection.
     *
     * By default this just sets the collLogProjectStatuses collection to an empty array (like clearcollLogProjectStatuses());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initLogProjectStatuses($overrideExisting = true)
    {
        if (null !== $this->collLogProjectStatuses && !$overrideExisting) {
            return;
        }

        $collectionClassName = LogProjectStatusTableMap::getTableMap()->getCollectionClassName();

        $this->collLogProjectStatuses = new $collectionClassName;
        $this->collLogProjectStatuses->setModel('\Model\LogProjectStatus');
    }

    /**
     * Gets an array of ChildLogProjectStatus objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildLogProjectStatus[] List of ChildLogProjectStatus objects
     * @phpstan-return ObjectCollection&\Traversable<ChildLogProjectStatus> List of ChildLogProjectStatus objects
     * @throws PropelException
     */
    public function getLogProjectStatuses(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collLogProjectStatusesPartial && !$this->isNew();
        if (null === $this->collLogProjectStatuses || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collLogProjectStatuses) {
                    $this->initLogProjectStatuses();
                } else {
                    $collectionClassName = LogProjectStatusTableMap::getTableMap()->getCollectionClassName();

                    $collLogProjectStatuses = new $collectionClassName;
                    $collLogProjectStatuses->setModel('\Model\LogProjectStatus');

                    return $collLogProjectStatuses;
                }
            } else {
                $collLogProjectStatuses = ChildLogProjectStatusQuery::create(null, $criteria)
                    ->filterByEtude($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collLogProjectStatusesPartial && count($collLogProjectStatuses)) {
                        $this->initLogProjectStatuses(false);

                        foreach ($collLogProjectStatuses as $obj) {
                            if (false == $this->collLogProjectStatuses->contains($obj)) {
                                $this->collLogProjectStatuses->append($obj);
                            }
                        }

                        $this->collLogProjectStatusesPartial = true;
                    }

                    return $collLogProjectStatuses;
                }

                if ($partial && $this->collLogProjectStatuses) {
                    foreach ($this->collLogProjectStatuses as $obj) {
                        if ($obj->isNew()) {
                            $collLogProjectStatuses[] = $obj;
                        }
                    }
                }

                $this->collLogProjectStatuses = $collLogProjectStatuses;
                $this->collLogProjectStatusesPartial = false;
            }
        }

        return $this->collLogProjectStatuses;
    }

    /**
     * Sets a collection of ChildLogProjectStatus objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $logProjectStatuses A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setLogProjectStatuses(Collection $logProjectStatuses, ConnectionInterface $con = null)
    {
        /** @var ChildLogProjectStatus[] $logProjectStatusesToDelete */
        $logProjectStatusesToDelete = $this->getLogProjectStatuses(new Criteria(), $con)->diff($logProjectStatuses);


        $this->logProjectStatusesScheduledForDeletion = $logProjectStatusesToDelete;

        foreach ($logProjectStatusesToDelete as $logProjectStatusRemoved) {
            $logProjectStatusRemoved->setEtude(null);
        }

        $this->collLogProjectStatuses = null;
        foreach ($logProjectStatuses as $logProjectStatus) {
            $this->addLogProjectStatus($logProjectStatus);
        }

        $this->collLogProjectStatuses = $logProjectStatuses;
        $this->collLogProjectStatusesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related LogProjectStatus objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related LogProjectStatus objects.
     * @throws PropelException
     */
    public function countLogProjectStatuses(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collLogProjectStatusesPartial && !$this->isNew();
        if (null === $this->collLogProjectStatuses || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collLogProjectStatuses) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getLogProjectStatuses());
            }

            $query = ChildLogProjectStatusQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtude($this)
                ->count($con);
        }

        return count($this->collLogProjectStatuses);
    }

    /**
     * Method called to associate a ChildLogProjectStatus object to this object
     * through the ChildLogProjectStatus foreign key attribute.
     *
     * @param  ChildLogProjectStatus $l ChildLogProjectStatus
     * @return $this|\Model\Etude The current object (for fluent API support)
     */
    public function addLogProjectStatus(ChildLogProjectStatus $l)
    {
        if ($this->collLogProjectStatuses === null) {
            $this->initLogProjectStatuses();
            $this->collLogProjectStatusesPartial = true;
        }

        if (!$this->collLogProjectStatuses->contains($l)) {
            $this->doAddLogProjectStatus($l);

            if ($this->logProjectStatusesScheduledForDeletion and $this->logProjectStatusesScheduledForDeletion->contains($l)) {
                $this->logProjectStatusesScheduledForDeletion->remove($this->logProjectStatusesScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildLogProjectStatus $logProjectStatus The ChildLogProjectStatus object to add.
     */
    protected function doAddLogProjectStatus(ChildLogProjectStatus $logProjectStatus)
    {
        $this->collLogProjectStatuses[]= $logProjectStatus;
        $logProjectStatus->setEtude($this);
    }

    /**
     * @param  ChildLogProjectStatus $logProjectStatus The ChildLogProjectStatus object to remove.
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function removeLogProjectStatus(ChildLogProjectStatus $logProjectStatus)
    {
        if ($this->getLogProjectStatuses()->contains($logProjectStatus)) {
            $pos = $this->collLogProjectStatuses->search($logProjectStatus);
            $this->collLogProjectStatuses->remove($pos);
            if (null === $this->logProjectStatusesScheduledForDeletion) {
                $this->logProjectStatusesScheduledForDeletion = clone $this->collLogProjectStatuses;
                $this->logProjectStatusesScheduledForDeletion->clear();
            }
            $this->logProjectStatusesScheduledForDeletion[]= clone $logProjectStatus;
            $logProjectStatus->setEtude(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related LogProjectStatuses from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildLogProjectStatus[] List of ChildLogProjectStatus objects
     * @phpstan-return ObjectCollection&\Traversable<ChildLogProjectStatus}> List of ChildLogProjectStatus objects
     */
    public function getLogProjectStatusesJoinJob(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildLogProjectStatusQuery::create(null, $criteria);
        $query->joinWith('Job', $joinBehavior);

        return $this->getLogProjectStatuses($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this Etude is new, it will return
     * an empty collection; or if this Etude has previously
     * been saved, it will retrieve related LogProjectStatuses from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in Etude.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildLogProjectStatus[] List of ChildLogProjectStatus objects
     * @phpstan-return ObjectCollection&\Traversable<ChildLogProjectStatus}> List of ChildLogProjectStatus objects
     */
    public function getLogProjectStatusesJoinUser(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildLogProjectStatusQuery::create(null, $criteria);
        $query->joinWith('User', $joinBehavior);

        return $this->getLogProjectStatuses($query, $con);
    }

    /**
     * Clears out the collSampleSources collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addSampleSources()
     */
    public function clearSampleSources()
    {
        $this->collSampleSources = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Initializes the collSampleSources crossRef collection.
     *
     * By default this just sets the collSampleSources collection to an empty collection (like clearSampleSources());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @return void
     */
    public function initSampleSources()
    {
        $collectionClassName = EtudeSampleSourceTableMap::getTableMap()->getCollectionClassName();

        $this->collSampleSources = new $collectionClassName;
        $this->collSampleSourcesPartial = true;
        $this->collSampleSources->setModel('\Model\SampleSource');
    }

    /**
     * Checks if the collSampleSources collection is loaded.
     *
     * @return bool
     */
    public function isSampleSourcesLoaded()
    {
        return null !== $this->collSampleSources;
    }

    /**
     * Gets a collection of ChildSampleSource objects related by a many-to-many relationship
     * to the current object by way of the etude_sample_source cross-reference table.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return ObjectCollection|ChildSampleSource[] List of ChildSampleSource objects
     * @phpstan-return ObjectCollection&\Traversable<ChildSampleSource> List of ChildSampleSource objects
     */
    public function getSampleSources(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collSampleSourcesPartial && !$this->isNew();
        if (null === $this->collSampleSources || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collSampleSources) {
                    $this->initSampleSources();
                }
            } else {

                $query = ChildSampleSourceQuery::create(null, $criteria)
                    ->filterByEtude($this);
                $collSampleSources = $query->find($con);
                if (null !== $criteria) {
                    return $collSampleSources;
                }

                if ($partial && $this->collSampleSources) {
                    //make sure that already added objects gets added to the list of the database.
                    foreach ($this->collSampleSources as $obj) {
                        if (!$collSampleSources->contains($obj)) {
                            $collSampleSources[] = $obj;
                        }
                    }
                }

                $this->collSampleSources = $collSampleSources;
                $this->collSampleSourcesPartial = false;
            }
        }

        return $this->collSampleSources;
    }

    /**
     * Sets a collection of SampleSource objects related by a many-to-many relationship
     * to the current object by way of the etude_sample_source cross-reference table.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param  Collection $sampleSources A Propel collection.
     * @param  ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setSampleSources(Collection $sampleSources, ConnectionInterface $con = null)
    {
        $this->clearSampleSources();
        $currentSampleSources = $this->getSampleSources();

        $sampleSourcesScheduledForDeletion = $currentSampleSources->diff($sampleSources);

        foreach ($sampleSourcesScheduledForDeletion as $toDelete) {
            $this->removeSampleSource($toDelete);
        }

        foreach ($sampleSources as $sampleSource) {
            if (!$currentSampleSources->contains($sampleSource)) {
                $this->doAddSampleSource($sampleSource);
            }
        }

        $this->collSampleSourcesPartial = false;
        $this->collSampleSources = $sampleSources;

        return $this;
    }

    /**
     * Gets the number of SampleSource objects related by a many-to-many relationship
     * to the current object by way of the etude_sample_source cross-reference table.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      boolean $distinct Set to true to force count distinct
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return int the number of related SampleSource objects
     */
    public function countSampleSources(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collSampleSourcesPartial && !$this->isNew();
        if (null === $this->collSampleSources || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collSampleSources) {
                return 0;
            } else {

                if ($partial && !$criteria) {
                    return count($this->getSampleSources());
                }

                $query = ChildSampleSourceQuery::create(null, $criteria);
                if ($distinct) {
                    $query->distinct();
                }

                return $query
                    ->filterByEtude($this)
                    ->count($con);
            }
        } else {
            return count($this->collSampleSources);
        }
    }

    /**
     * Associate a ChildSampleSource to this object
     * through the etude_sample_source cross reference table.
     *
     * @param ChildSampleSource $sampleSource
     * @return ChildEtude The current object (for fluent API support)
     */
    public function addSampleSource(ChildSampleSource $sampleSource)
    {
        if ($this->collSampleSources === null) {
            $this->initSampleSources();
        }

        if (!$this->getSampleSources()->contains($sampleSource)) {
            // only add it if the **same** object is not already associated
            $this->collSampleSources->push($sampleSource);
            $this->doAddSampleSource($sampleSource);
        }

        return $this;
    }

    /**
     *
     * @param ChildSampleSource $sampleSource
     */
    protected function doAddSampleSource(ChildSampleSource $sampleSource)
    {
        $etudeSampleSource = new ChildEtudeSampleSource();

        $etudeSampleSource->setSampleSource($sampleSource);

        $etudeSampleSource->setEtude($this);

        $this->addEtudeSampleSource($etudeSampleSource);

        // set the back reference to this object directly as using provided method either results
        // in endless loop or in multiple relations
        if (!$sampleSource->isEtudesLoaded()) {
            $sampleSource->initEtudes();
            $sampleSource->getEtudes()->push($this);
        } elseif (!$sampleSource->getEtudes()->contains($this)) {
            $sampleSource->getEtudes()->push($this);
        }

    }

    /**
     * Remove sampleSource of this object
     * through the etude_sample_source cross reference table.
     *
     * @param ChildSampleSource $sampleSource
     * @return ChildEtude The current object (for fluent API support)
     */
    public function removeSampleSource(ChildSampleSource $sampleSource)
    {
        if ($this->getSampleSources()->contains($sampleSource)) {
            $etudeSampleSource = new ChildEtudeSampleSource();
            $etudeSampleSource->setSampleSource($sampleSource);
            if ($sampleSource->isEtudesLoaded()) {
                //remove the back reference if available
                $sampleSource->getEtudes()->removeObject($this);
            }

            $etudeSampleSource->setEtude($this);
            $this->removeEtudeSampleSource(clone $etudeSampleSource);
            $etudeSampleSource->clear();

            $this->collSampleSources->remove($this->collSampleSources->search($sampleSource));

            if (null === $this->sampleSourcesScheduledForDeletion) {
                $this->sampleSourcesScheduledForDeletion = clone $this->collSampleSources;
                $this->sampleSourcesScheduledForDeletion->clear();
            }

            $this->sampleSourcesScheduledForDeletion->push($sampleSource);
        }


        return $this;
    }

    /**
     * Clears out the collMethodologies collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addMethodologies()
     */
    public function clearMethodologies()
    {
        $this->collMethodologies = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Initializes the collMethodologies crossRef collection.
     *
     * By default this just sets the collMethodologies collection to an empty collection (like clearMethodologies());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @return void
     */
    public function initMethodologies()
    {
        $collectionClassName = EtudeMethodologyTableMap::getTableMap()->getCollectionClassName();

        $this->collMethodologies = new $collectionClassName;
        $this->collMethodologiesPartial = true;
        $this->collMethodologies->setModel('\Model\Methodology');
    }

    /**
     * Checks if the collMethodologies collection is loaded.
     *
     * @return bool
     */
    public function isMethodologiesLoaded()
    {
        return null !== $this->collMethodologies;
    }

    /**
     * Gets a collection of ChildMethodology objects related by a many-to-many relationship
     * to the current object by way of the etude_methodology cross-reference table.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return ObjectCollection|ChildMethodology[] List of ChildMethodology objects
     * @phpstan-return ObjectCollection&\Traversable<ChildMethodology> List of ChildMethodology objects
     */
    public function getMethodologies(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collMethodologiesPartial && !$this->isNew();
        if (null === $this->collMethodologies || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collMethodologies) {
                    $this->initMethodologies();
                }
            } else {

                $query = ChildMethodologyQuery::create(null, $criteria)
                    ->filterByEtude($this);
                $collMethodologies = $query->find($con);
                if (null !== $criteria) {
                    return $collMethodologies;
                }

                if ($partial && $this->collMethodologies) {
                    //make sure that already added objects gets added to the list of the database.
                    foreach ($this->collMethodologies as $obj) {
                        if (!$collMethodologies->contains($obj)) {
                            $collMethodologies[] = $obj;
                        }
                    }
                }

                $this->collMethodologies = $collMethodologies;
                $this->collMethodologiesPartial = false;
            }
        }

        return $this->collMethodologies;
    }

    /**
     * Sets a collection of Methodology objects related by a many-to-many relationship
     * to the current object by way of the etude_methodology cross-reference table.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param  Collection $methodologies A Propel collection.
     * @param  ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setMethodologies(Collection $methodologies, ConnectionInterface $con = null)
    {
        $this->clearMethodologies();
        $currentMethodologies = $this->getMethodologies();

        $methodologiesScheduledForDeletion = $currentMethodologies->diff($methodologies);

        foreach ($methodologiesScheduledForDeletion as $toDelete) {
            $this->removeMethodology($toDelete);
        }

        foreach ($methodologies as $methodology) {
            if (!$currentMethodologies->contains($methodology)) {
                $this->doAddMethodology($methodology);
            }
        }

        $this->collMethodologiesPartial = false;
        $this->collMethodologies = $methodologies;

        return $this;
    }

    /**
     * Gets the number of Methodology objects related by a many-to-many relationship
     * to the current object by way of the etude_methodology cross-reference table.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      boolean $distinct Set to true to force count distinct
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return int the number of related Methodology objects
     */
    public function countMethodologies(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collMethodologiesPartial && !$this->isNew();
        if (null === $this->collMethodologies || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collMethodologies) {
                return 0;
            } else {

                if ($partial && !$criteria) {
                    return count($this->getMethodologies());
                }

                $query = ChildMethodologyQuery::create(null, $criteria);
                if ($distinct) {
                    $query->distinct();
                }

                return $query
                    ->filterByEtude($this)
                    ->count($con);
            }
        } else {
            return count($this->collMethodologies);
        }
    }

    /**
     * Associate a ChildMethodology to this object
     * through the etude_methodology cross reference table.
     *
     * @param ChildMethodology $methodology
     * @return ChildEtude The current object (for fluent API support)
     */
    public function addMethodology(ChildMethodology $methodology)
    {
        if ($this->collMethodologies === null) {
            $this->initMethodologies();
        }

        if (!$this->getMethodologies()->contains($methodology)) {
            // only add it if the **same** object is not already associated
            $this->collMethodologies->push($methodology);
            $this->doAddMethodology($methodology);
        }

        return $this;
    }

    /**
     *
     * @param ChildMethodology $methodology
     */
    protected function doAddMethodology(ChildMethodology $methodology)
    {
        $etudeMethodology = new ChildEtudeMethodology();

        $etudeMethodology->setMethodology($methodology);

        $etudeMethodology->setEtude($this);

        $this->addEtudeMethodology($etudeMethodology);

        // set the back reference to this object directly as using provided method either results
        // in endless loop or in multiple relations
        if (!$methodology->isEtudesLoaded()) {
            $methodology->initEtudes();
            $methodology->getEtudes()->push($this);
        } elseif (!$methodology->getEtudes()->contains($this)) {
            $methodology->getEtudes()->push($this);
        }

    }

    /**
     * Remove methodology of this object
     * through the etude_methodology cross reference table.
     *
     * @param ChildMethodology $methodology
     * @return ChildEtude The current object (for fluent API support)
     */
    public function removeMethodology(ChildMethodology $methodology)
    {
        if ($this->getMethodologies()->contains($methodology)) {
            $etudeMethodology = new ChildEtudeMethodology();
            $etudeMethodology->setMethodology($methodology);
            if ($methodology->isEtudesLoaded()) {
                //remove the back reference if available
                $methodology->getEtudes()->removeObject($this);
            }

            $etudeMethodology->setEtude($this);
            $this->removeEtudeMethodology(clone $etudeMethodology);
            $etudeMethodology->clear();

            $this->collMethodologies->remove($this->collMethodologies->search($methodology));

            if (null === $this->methodologiesScheduledForDeletion) {
                $this->methodologiesScheduledForDeletion = clone $this->collMethodologies;
                $this->methodologiesScheduledForDeletion->clear();
            }

            $this->methodologiesScheduledForDeletion->push($methodology);
        }


        return $this;
    }

    /**
     * Clears out the collRefSalesForceEtudeRefSectors collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addRefSalesForceEtudeRefSectors()
     */
    public function clearRefSalesForceEtudeRefSectors()
    {
        $this->collRefSalesForceEtudeRefSectors = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Initializes the collRefSalesForceEtudeRefSectors crossRef collection.
     *
     * By default this just sets the collRefSalesForceEtudeRefSectors collection to an empty collection (like clearRefSalesForceEtudeRefSectors());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @return void
     */
    public function initRefSalesForceEtudeRefSectors()
    {
        $collectionClassName = RefSalesForceEtudeSectorTableMap::getTableMap()->getCollectionClassName();

        $this->collRefSalesForceEtudeRefSectors = new $collectionClassName;
        $this->collRefSalesForceEtudeRefSectorsPartial = true;
        $this->collRefSalesForceEtudeRefSectors->setModel('\Model\RefSalesForce');
    }

    /**
     * Checks if the collRefSalesForceEtudeRefSectors collection is loaded.
     *
     * @return bool
     */
    public function isRefSalesForceEtudeRefSectorsLoaded()
    {
        return null !== $this->collRefSalesForceEtudeRefSectors;
    }

    /**
     * Gets a collection of ChildRefSalesForce objects related by a many-to-many relationship
     * to the current object by way of the sf_ref_salesforce_etude_sector cross-reference table.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtude is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return ObjectCollection|ChildRefSalesForce[] List of ChildRefSalesForce objects
     * @phpstan-return ObjectCollection&\Traversable<ChildRefSalesForce> List of ChildRefSalesForce objects
     */
    public function getRefSalesForceEtudeRefSectors(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collRefSalesForceEtudeRefSectorsPartial && !$this->isNew();
        if (null === $this->collRefSalesForceEtudeRefSectors || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collRefSalesForceEtudeRefSectors) {
                    $this->initRefSalesForceEtudeRefSectors();
                }
            } else {

                $query = ChildRefSalesForceQuery::create(null, $criteria)
                    ->filterByEtudeSector($this);
                $collRefSalesForceEtudeRefSectors = $query->find($con);
                if (null !== $criteria) {
                    return $collRefSalesForceEtudeRefSectors;
                }

                if ($partial && $this->collRefSalesForceEtudeRefSectors) {
                    //make sure that already added objects gets added to the list of the database.
                    foreach ($this->collRefSalesForceEtudeRefSectors as $obj) {
                        if (!$collRefSalesForceEtudeRefSectors->contains($obj)) {
                            $collRefSalesForceEtudeRefSectors[] = $obj;
                        }
                    }
                }

                $this->collRefSalesForceEtudeRefSectors = $collRefSalesForceEtudeRefSectors;
                $this->collRefSalesForceEtudeRefSectorsPartial = false;
            }
        }

        return $this->collRefSalesForceEtudeRefSectors;
    }

    /**
     * Sets a collection of RefSalesForce objects related by a many-to-many relationship
     * to the current object by way of the sf_ref_salesforce_etude_sector cross-reference table.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param  Collection $refSalesForceEtudeRefSectors A Propel collection.
     * @param  ConnectionInterface $con Optional connection object
     * @return $this|ChildEtude The current object (for fluent API support)
     */
    public function setRefSalesForceEtudeRefSectors(Collection $refSalesForceEtudeRefSectors, ConnectionInterface $con = null)
    {
        $this->clearRefSalesForceEtudeRefSectors();
        $currentRefSalesForceEtudeRefSectors = $this->getRefSalesForceEtudeRefSectors();

        $refSalesForceEtudeRefSectorsScheduledForDeletion = $currentRefSalesForceEtudeRefSectors->diff($refSalesForceEtudeRefSectors);

        foreach ($refSalesForceEtudeRefSectorsScheduledForDeletion as $toDelete) {
            $this->removeRefSalesForceEtudeRefSector($toDelete);
        }

        foreach ($refSalesForceEtudeRefSectors as $refSalesForceEtudeRefSector) {
            if (!$currentRefSalesForceEtudeRefSectors->contains($refSalesForceEtudeRefSector)) {
                $this->doAddRefSalesForceEtudeRefSector($refSalesForceEtudeRefSector);
            }
        }

        $this->collRefSalesForceEtudeRefSectorsPartial = false;
        $this->collRefSalesForceEtudeRefSectors = $refSalesForceEtudeRefSectors;

        return $this;
    }

    /**
     * Gets the number of RefSalesForce objects related by a many-to-many relationship
     * to the current object by way of the sf_ref_salesforce_etude_sector cross-reference table.
     *
     * @param      Criteria $criteria Optional query object to filter the query
     * @param      boolean $distinct Set to true to force count distinct
     * @param      ConnectionInterface $con Optional connection object
     *
     * @return int the number of related RefSalesForce objects
     */
    public function countRefSalesForceEtudeRefSectors(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collRefSalesForceEtudeRefSectorsPartial && !$this->isNew();
        if (null === $this->collRefSalesForceEtudeRefSectors || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collRefSalesForceEtudeRefSectors) {
                return 0;
            } else {

                if ($partial && !$criteria) {
                    return count($this->getRefSalesForceEtudeRefSectors());
                }

                $query = ChildRefSalesForceQuery::create(null, $criteria);
                if ($distinct) {
                    $query->distinct();
                }

                return $query
                    ->filterByEtudeSector($this)
                    ->count($con);
            }
        } else {
            return count($this->collRefSalesForceEtudeRefSectors);
        }
    }

    /**
     * Associate a ChildRefSalesForce to this object
     * through the sf_ref_salesforce_etude_sector cross reference table.
     *
     * @param ChildRefSalesForce $refSalesForceEtudeRefSector
     * @return ChildEtude The current object (for fluent API support)
     */
    public function addRefSalesForceEtudeRefSector(ChildRefSalesForce $refSalesForceEtudeRefSector)
    {
        if ($this->collRefSalesForceEtudeRefSectors === null) {
            $this->initRefSalesForceEtudeRefSectors();
        }

        if (!$this->getRefSalesForceEtudeRefSectors()->contains($refSalesForceEtudeRefSector)) {
            // only add it if the **same** object is not already associated
            $this->collRefSalesForceEtudeRefSectors->push($refSalesForceEtudeRefSector);
            $this->doAddRefSalesForceEtudeRefSector($refSalesForceEtudeRefSector);
        }

        return $this;
    }

    /**
     *
     * @param ChildRefSalesForce $refSalesForceEtudeRefSector
     */
    protected function doAddRefSalesForceEtudeRefSector(ChildRefSalesForce $refSalesForceEtudeRefSector)
    {
        $refSalesForceEtudeSector = new ChildRefSalesForceEtudeSector();

        $refSalesForceEtudeSector->setRefSalesForceEtudeRefSector($refSalesForceEtudeRefSector);

        $refSalesForceEtudeSector->setEtudeSector($this);

        $this->addSector($refSalesForceEtudeSector);

        // set the back reference to this object directly as using provided method either results
        // in endless loop or in multiple relations
        if (!$refSalesForceEtudeRefSector->isEtudeSectorsLoaded()) {
            $refSalesForceEtudeRefSector->initEtudeSectors();
            $refSalesForceEtudeRefSector->getEtudeSectors()->push($this);
        } elseif (!$refSalesForceEtudeRefSector->getEtudeSectors()->contains($this)) {
            $refSalesForceEtudeRefSector->getEtudeSectors()->push($this);
        }

    }

    /**
     * Remove refSalesForceEtudeRefSector of this object
     * through the sf_ref_salesforce_etude_sector cross reference table.
     *
     * @param ChildRefSalesForce $refSalesForceEtudeRefSector
     * @return ChildEtude The current object (for fluent API support)
     */
    public function removeRefSalesForceEtudeRefSector(ChildRefSalesForce $refSalesForceEtudeRefSector)
    {
        if ($this->getRefSalesForceEtudeRefSectors()->contains($refSalesForceEtudeRefSector)) {
            $refSalesForceEtudeSector = new ChildRefSalesForceEtudeSector();
            $refSalesForceEtudeSector->setRefSalesForceEtudeRefSector($refSalesForceEtudeRefSector);
            if ($refSalesForceEtudeRefSector->isEtudeSectorsLoaded()) {
                //remove the back reference if available
                $refSalesForceEtudeRefSector->getEtudeSectors()->removeObject($this);
            }

            $refSalesForceEtudeSector->setEtudeSector($this);
            $this->removeSector(clone $refSalesForceEtudeSector);
            $refSalesForceEtudeSector->clear();

            $this->collRefSalesForceEtudeRefSectors->remove($this->collRefSalesForceEtudeRefSectors->search($refSalesForceEtudeRefSector));

            if (null === $this->refSalesForceEtudeRefSectorsScheduledForDeletion) {
                $this->refSalesForceEtudeRefSectorsScheduledForDeletion = clone $this->collRefSalesForceEtudeRefSectors;
                $this->refSalesForceEtudeRefSectorsScheduledForDeletion->clear();
            }

            $this->refSalesForceEtudeRefSectorsScheduledForDeletion->push($refSalesForceEtudeRefSector);
        }


        return $this;
    }

    /**
     * Clears the current object, sets all attributes to their default values and removes
     * outgoing references as well as back-references (from other objects to this one. Results probably in a database
     * change of those foreign objects when you call `save` there).
     */
    public function clear()
    {
        if (null !== $this->aUsGlobalQualGms) {
            $this->aUsGlobalQualGms->removeEtudeRelatedByUsGlobalQualGmsId($this);
        }
        if (null !== $this->aAccountLeader) {
            $this->aAccountLeader->removeAccountLeader($this);
        }
        if (null !== $this->aAccountPM) {
            $this->aAccountPM->removeAccountPM($this);
        }
        if (null !== $this->aIntermediateClient) {
            $this->aIntermediateClient->removeEtudeRelatedByIntermediateClientId($this);
        }
        if (null !== $this->aEtape) {
            $this->aEtape->removeEtude($this);
        }
        if (null !== $this->aContact) {
            $this->aContact->removeEtudeRelatedByContactId($this);
        }
        if (null !== $this->aOpportunity) {
            $this->aOpportunity->removeEtude($this);
        }
        if (null !== $this->aJobStatusSf) {
            $this->aJobStatusSf->removeEtudeRelatedByJobStatusSfId($this);
        }
        if (null !== $this->aJobQualification) {
            $this->aJobQualification->removeEtudeRelatedByJobQualificationId($this);
        }
        if (null !== $this->aSiJobType) {
            $this->aSiJobType->removeEtude($this);
        }
        if (null !== $this->aEndClientContact) {
            $this->aEndClientContact->removeEtudeEndClientContact($this);
        }
        if (null !== $this->aGermanJobType) {
            $this->aGermanJobType->removeEtudeRelatedByGermanJobTypeId($this);
        }
        if (null !== $this->aEndClient) {
            $this->aEndClient->removeEtudeRelatedByEndClientId($this);
        }
        if (null !== $this->aAccount) {
            $this->aAccount->removeEtudeRelatedByAccountId($this);
        }
        if (null !== $this->aIndustry) {
            $this->aIndustry->removeEtude($this);
        }
        if (null !== $this->aEtudeLocation) {
            $this->aEtudeLocation->removeEtudeLocation($this);
        }
        if (null !== $this->aProjectLocationPrefix) {
            $this->aProjectLocationPrefix->removeProjectLocationPrefix($this);
        }
        if (null !== $this->aContactClientPm) {
            $this->aContactClientPm->removeEtudeContactClientPm($this);
        }
        if (null !== $this->aBM) {
            $this->aBM->removeEtudeRelatedByIdBm($this);
        }
        if (null !== $this->aEtudeProjectManager) {
            $this->aEtudeProjectManager->removeEtudeEtudeProjectManager($this);
        }
        if (null !== $this->aEtudeGroup) {
            $this->aEtudeGroup->removeEtude($this);
        }
        if (null !== $this->aEtudeArea) {
            $this->aEtudeArea->removeEtude($this);
        }
        if (null !== $this->aCurrencyIsoCode) {
            $this->aCurrencyIsoCode->removeEtudeRelatedByCurrencyIsoCodeId($this);
        }
        if (null !== $this->aClientListDeletion) {
            $this->aClientListDeletion->removeEtudeRelatedByClientListDeletionId($this);
        }
        if (null !== $this->aCreatedBy) {
            $this->aCreatedBy->removeEtudeRelatedByCreatedById($this);
        }
        if (null !== $this->aUpdatedBy) {
            $this->aUpdatedBy->removeEtudeRelatedByUpdatedById($this);
        }
        if (null !== $this->aIntermediateClientContact) {
            $this->aIntermediateClientContact->removeEtudeIntermediateClientContact($this);
        }
        if (null !== $this->aProjectAccountManager) {
            $this->aProjectAccountManager->removeProjectAccountManager($this);
        }
        if (null !== $this->aProjectSpecialtySponsor) {
            $this->aProjectSpecialtySponsor->removeProjectSpecialtySponsor($this);
        }
        if (null !== $this->aAmReasonType) {
            $this->aAmReasonType->removeEtude($this);
        }
        $this->id = null;
        $this->numero_etude = null;
        $this->reference_client = null;
        $this->master_project_sf_id = null;
        $this->theme = null;
        $this->date_debut = null;
        $this->date_fin = null;
        $this->annee = null;
        $this->rst = null;
        $this->cli = null;
        $this->gqs = null;
        $this->ins = null;
        $this->hut = null;
        $this->display_total_only = null;
        $this->id_pm = null;
        $this->id_etape = null;
        $this->prix_revient_initial = null;
        $this->prix_revient_actualise = null;
        $this->prix_vente_initial = null;
        $this->prix_vente_actualise = null;
        $this->consolidated_invoice = null;
        $this->send_csat_quest = null;
        $this->is_send_csat_quest_mail = null;
        $this->numero_facture = null;
        $this->dont_set_am_auto = null;
        $this->set_am_reason = null;
        $this->am_reason_type_id = null;
        $this->date_envoi_facture = null;
        $this->date_reglement = null;
        $this->commentaire = null;
        $this->industry_id = null;
        $this->periode_cutoff = null;
        $this->theme_br = null;
        $this->area_id = null;
        $this->id_sams_study = null;
        $this->recrutement_objectif = null;
        $this->id_location_pnl = null;
        $this->id_master_project_location_pnl = null;
        $this->recrutement_objectif_pr = null;
        $this->id_bm = null;
        $this->extra_info = null;
        $this->account_id = null;
        $this->account_manager_id = null;
        $this->project_specialty_sponsor_id = null;
        $this->language = null;
        $this->remise_taux = null;
        $this->client_discount_percentage = null;
        $this->end_client_discount_percentage = null;
        $this->client_quant_discount_percentage = null;
        $this->end_client_quant_discount_percentage = null;
        $this->sample_plan = null;
        $this->istoinvoice = null;
        $this->file_path = null;
        $this->account_leader_id = null;
        $this->account_pm_id = null;
        $this->am_email = null;
        $this->client_portal_ready = null;
        $this->length_of_interview = null;
        $this->sunshine_act = null;
        $this->is_consolidated = null;
        $this->sharepoint_folder = null;
        $this->multi_phase = null;
        $this->po_number = null;
        $this->currencies = null;
        $this->sms_relance = null;
        $this->id_etude_group = null;
        $this->gms = null;
        $this->kol = null;
        $this->room_rental = null;
        $this->recruits_offsite = null;
        $this->study_specification = null;
        $this->is_study_specification = null;
        $this->additional_notes = null;
        $this->project_comment = null;
        $this->end_client_id = null;
        $this->end_client_contact_id = null;
        $this->contact_id = null;
        $this->contact_client_pm_id = null;
        $this->master_project_number = null;
        $this->proposed_loi = null;
        $this->opportunity_id = null;
        $this->si_job_type_id = null;
        $this->best_effort = null;
        $this->job_status_sf_id = null;
        $this->booked_by_sf_id = null;
        $this->created_by_sf_id = null;
        $this->account_manager_sf_id = null;
        $this->created_date = null;
        $this->job_qualification_id = null;
        $this->proposed_n = null;
        $this->german_job_type_id = null;
        $this->created_by_comment = null;
        $this->focus_vision = null;
        $this->si_eu_job_type = null;
        $this->intermediate_client_id = null;
        $this->intermediate_client_contact_id = null;
        $this->us_global_qual_gms_id = null;
        $this->facilty_note = null;
        $this->currency_iso_code_id = null;
        $this->client_list_deletion_id = null;
        $this->created_by_id = null;
        $this->updated_by_id = null;
        $this->created_at = null;
        $this->updated_at = null;
        $this->alreadyInSave = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references and back-references to other model objects or collections of model objects.
     *
     * This method is used to reset all php object references (not the actual reference in the database).
     * Necessary for object serialisation.
     *
     * @param      boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep) {
            if ($this->collDernierAccess) {
                foreach ($this->collDernierAccess as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEtudeSampleSources) {
                foreach ($this->collEtudeSampleSources as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEtudeMethodologies) {
                foreach ($this->collEtudeMethodologies as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collFactures) {
                foreach ($this->collFactures as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collJobEtudes) {
                foreach ($this->collJobEtudes as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collReglements) {
                foreach ($this->collReglements as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collSectors) {
                foreach ($this->collSectors as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEtudeCheckListValidations) {
                foreach ($this->collEtudeCheckListValidations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collEtudeFichiers) {
                foreach ($this->collEtudeFichiers as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collLogProjectStatuses) {
                foreach ($this->collLogProjectStatuses as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collSampleSources) {
                foreach ($this->collSampleSources as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collMethodologies) {
                foreach ($this->collMethodologies as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collRefSalesForceEtudeRefSectors) {
                foreach ($this->collRefSalesForceEtudeRefSectors as $o) {
                    $o->clearAllReferences($deep);
                }
            }
        } // if ($deep)

        $this->collDernierAccess = null;
        $this->collEtudeSampleSources = null;
        $this->collEtudeMethodologies = null;
        $this->collFactures = null;
        $this->collJobEtudes = null;
        $this->collReglements = null;
        $this->collSectors = null;
        $this->collEtudeCheckListValidations = null;
        $this->collEtudeFichiers = null;
        $this->collLogProjectStatuses = null;
        $this->collSampleSources = null;
        $this->collMethodologies = null;
        $this->collRefSalesForceEtudeRefSectors = null;
        $this->aUsGlobalQualGms = null;
        $this->aAccountLeader = null;
        $this->aAccountPM = null;
        $this->aIntermediateClient = null;
        $this->aEtape = null;
        $this->aContact = null;
        $this->aOpportunity = null;
        $this->aJobStatusSf = null;
        $this->aJobQualification = null;
        $this->aSiJobType = null;
        $this->aEndClientContact = null;
        $this->aGermanJobType = null;
        $this->aEndClient = null;
        $this->aAccount = null;
        $this->aIndustry = null;
        $this->aEtudeLocation = null;
        $this->aProjectLocationPrefix = null;
        $this->aContactClientPm = null;
        $this->aBM = null;
        $this->aEtudeProjectManager = null;
        $this->aEtudeGroup = null;
        $this->aEtudeArea = null;
        $this->aCurrencyIsoCode = null;
        $this->aClientListDeletion = null;
        $this->aCreatedBy = null;
        $this->aUpdatedBy = null;
        $this->aIntermediateClientContact = null;
        $this->aProjectAccountManager = null;
        $this->aProjectSpecialtySponsor = null;
        $this->aAmReasonType = null;
    }

    /**
     * Return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(EtudeTableMap::DEFAULT_STRING_FORMAT);
    }

    // timestampable behavior

    /**
     * Mark the current object so that the update date doesn't get updated during next save
     *
     * @return     $this|ChildEtude The current object (for fluent API support)
     */
    public function keepUpdateDateUnchanged()
    {
        $this->modifiedColumns[EtudeTableMap::COL_UPDATED_AT] = true;

        return $this;
    }

    /**
     * Code to be run before persisting the object
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preSave(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after persisting the object
     * @param ConnectionInterface $con
     */
    public function postSave(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before inserting to database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preInsert(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after inserting to database
     * @param ConnectionInterface $con
     */
    public function postInsert(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before updating the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preUpdate(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after updating the object in database
     * @param ConnectionInterface $con
     */
    public function postUpdate(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before deleting the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preDelete(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after deleting the object in database
     * @param ConnectionInterface $con
     */
    public function postDelete(ConnectionInterface $con = null)
    {
            }


    /**
     * Derived method to catches calls to undefined methods.
     *
     * Provides magic import/export method support (fromXML()/toXML(), fromYAML()/toYAML(), etc.).
     * Allows to define default __call() behavior if you overwrite __call()
     *
     * @param string $name
     * @param mixed  $params
     *
     * @return array|string
     */
    public function __call($name, $params)
    {
        if (0 === strpos($name, 'get')) {
            $virtualColumn = substr($name, 3);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }

            $virtualColumn = lcfirst($virtualColumn);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }
        }

        if (0 === strpos($name, 'from')) {
            $format = substr($name, 4);
            $inputData = $params[0];
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->importFrom($format, $inputData, $keyType);
        }

        if (0 === strpos($name, 'to')) {
            $format = substr($name, 2);
            $includeLazyLoadColumns = $params[0] ?? true;
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->exportTo($format, $includeLazyLoadColumns, $keyType);
        }

        throw new BadMethodCallException(sprintf('Call to undefined method: %s.', $name));
    }

}
