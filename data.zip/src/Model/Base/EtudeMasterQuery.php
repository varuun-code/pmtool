<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EtudeMaster as ChildEtudeMaster;
use Model\EtudeMasterQuery as ChildEtudeMasterQuery;
use Model\Map\EtudeMasterTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'etude_master' table.
 *
 *
 *
 * @method     ChildEtudeMasterQuery orderById($order = Criteria::ASC) Order by the id column
 * @method     ChildEtudeMasterQuery orderByNumeroEtude($order = Criteria::ASC) Order by the numero_etude column
 * @method     ChildEtudeMasterQuery orderByReferenceClient($order = Criteria::ASC) Order by the reference_client column
 * @method     ChildEtudeMasterQuery orderByTheme($order = Criteria::ASC) Order by the theme column
 * @method     ChildEtudeMasterQuery orderByDateDebut($order = Criteria::ASC) Order by the date_debut column
 * @method     ChildEtudeMasterQuery orderByDateFin($order = Criteria::ASC) Order by the date_fin column
 * @method     ChildEtudeMasterQuery orderByAnnee($order = Criteria::ASC) Order by the annee column
 * @method     ChildEtudeMasterQuery orderByIdPm($order = Criteria::ASC) Order by the id_pm column
 * @method     ChildEtudeMasterQuery orderByIdEtape($order = Criteria::ASC) Order by the id_etape column
 * @method     ChildEtudeMasterQuery orderByPrixRevientInitial($order = Criteria::ASC) Order by the prix_revient_initial column
 * @method     ChildEtudeMasterQuery orderByPrixRevientActualise($order = Criteria::ASC) Order by the prix_revient_actualise column
 * @method     ChildEtudeMasterQuery orderByPrixVenteInitial($order = Criteria::ASC) Order by the prix_vente_initial column
 * @method     ChildEtudeMasterQuery orderByPrixVenteActualise($order = Criteria::ASC) Order by the prix_vente_actualise column
 * @method     ChildEtudeMasterQuery orderByNumeroFacture($order = Criteria::ASC) Order by the numero_facture column
 * @method     ChildEtudeMasterQuery orderByDateEnvoiFacture($order = Criteria::ASC) Order by the date_envoi_facture column
 * @method     ChildEtudeMasterQuery orderByDateReglement($order = Criteria::ASC) Order by the date_reglement column
 * @method     ChildEtudeMasterQuery orderByCommentaire($order = Criteria::ASC) Order by the commentaire column
 * @method     ChildEtudeMasterQuery orderByIndustryId($order = Criteria::ASC) Order by the industry_id column
 * @method     ChildEtudeMasterQuery orderByPeriodeCutoff($order = Criteria::ASC) Order by the periode_cutoff column
 * @method     ChildEtudeMasterQuery orderByThemeBr($order = Criteria::ASC) Order by the theme_br column
 * @method     ChildEtudeMasterQuery orderByAreaId($order = Criteria::ASC) Order by the area_id column
 * @method     ChildEtudeMasterQuery orderByIdQq($order = Criteria::ASC) Order by the id_qq column
 * @method     ChildEtudeMasterQuery orderByIdSamsStudy($order = Criteria::ASC) Order by the id_sams_study column
 * @method     ChildEtudeMasterQuery orderByRecrutementObjectif($order = Criteria::ASC) Order by the recrutement_objectif column
 * @method     ChildEtudeMasterQuery orderByIdLocationPnl($order = Criteria::ASC) Order by the id_location_pnl column
 * @method     ChildEtudeMasterQuery orderByDurationstudy($order = Criteria::ASC) Order by the durationStudy column
 * @method     ChildEtudeMasterQuery orderByRecrutementObjectifPr($order = Criteria::ASC) Order by the recrutement_objectif_pr column
 * @method     ChildEtudeMasterQuery orderByIdBm($order = Criteria::ASC) Order by the id_bm column
 * @method     ChildEtudeMasterQuery orderByAccountId($order = Criteria::ASC) Order by the account_id column
 * @method     ChildEtudeMasterQuery orderByRemiseTaux($order = Criteria::ASC) Order by the remise_taux column
 * @method     ChildEtudeMasterQuery orderByLanguage($order = Criteria::ASC) Order by the language column
 * @method     ChildEtudeMasterQuery orderByKol($order = Criteria::ASC) Order by the kol column
 * @method     ChildEtudeMasterQuery orderBySmsRelance($order = Criteria::ASC) Order by the sms_relance column
 * @method     ChildEtudeMasterQuery orderByGms($order = Criteria::ASC) Order by the gms column
 *
 * @method     ChildEtudeMasterQuery groupById() Group by the id column
 * @method     ChildEtudeMasterQuery groupByNumeroEtude() Group by the numero_etude column
 * @method     ChildEtudeMasterQuery groupByReferenceClient() Group by the reference_client column
 * @method     ChildEtudeMasterQuery groupByTheme() Group by the theme column
 * @method     ChildEtudeMasterQuery groupByDateDebut() Group by the date_debut column
 * @method     ChildEtudeMasterQuery groupByDateFin() Group by the date_fin column
 * @method     ChildEtudeMasterQuery groupByAnnee() Group by the annee column
 * @method     ChildEtudeMasterQuery groupByIdPm() Group by the id_pm column
 * @method     ChildEtudeMasterQuery groupByIdEtape() Group by the id_etape column
 * @method     ChildEtudeMasterQuery groupByPrixRevientInitial() Group by the prix_revient_initial column
 * @method     ChildEtudeMasterQuery groupByPrixRevientActualise() Group by the prix_revient_actualise column
 * @method     ChildEtudeMasterQuery groupByPrixVenteInitial() Group by the prix_vente_initial column
 * @method     ChildEtudeMasterQuery groupByPrixVenteActualise() Group by the prix_vente_actualise column
 * @method     ChildEtudeMasterQuery groupByNumeroFacture() Group by the numero_facture column
 * @method     ChildEtudeMasterQuery groupByDateEnvoiFacture() Group by the date_envoi_facture column
 * @method     ChildEtudeMasterQuery groupByDateReglement() Group by the date_reglement column
 * @method     ChildEtudeMasterQuery groupByCommentaire() Group by the commentaire column
 * @method     ChildEtudeMasterQuery groupByIndustryId() Group by the industry_id column
 * @method     ChildEtudeMasterQuery groupByPeriodeCutoff() Group by the periode_cutoff column
 * @method     ChildEtudeMasterQuery groupByThemeBr() Group by the theme_br column
 * @method     ChildEtudeMasterQuery groupByAreaId() Group by the area_id column
 * @method     ChildEtudeMasterQuery groupByIdQq() Group by the id_qq column
 * @method     ChildEtudeMasterQuery groupByIdSamsStudy() Group by the id_sams_study column
 * @method     ChildEtudeMasterQuery groupByRecrutementObjectif() Group by the recrutement_objectif column
 * @method     ChildEtudeMasterQuery groupByIdLocationPnl() Group by the id_location_pnl column
 * @method     ChildEtudeMasterQuery groupByDurationstudy() Group by the durationStudy column
 * @method     ChildEtudeMasterQuery groupByRecrutementObjectifPr() Group by the recrutement_objectif_pr column
 * @method     ChildEtudeMasterQuery groupByIdBm() Group by the id_bm column
 * @method     ChildEtudeMasterQuery groupByAccountId() Group by the account_id column
 * @method     ChildEtudeMasterQuery groupByRemiseTaux() Group by the remise_taux column
 * @method     ChildEtudeMasterQuery groupByLanguage() Group by the language column
 * @method     ChildEtudeMasterQuery groupByKol() Group by the kol column
 * @method     ChildEtudeMasterQuery groupBySmsRelance() Group by the sms_relance column
 * @method     ChildEtudeMasterQuery groupByGms() Group by the gms column
 *
 * @method     ChildEtudeMasterQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtudeMasterQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtudeMasterQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtudeMasterQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtudeMasterQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtudeMasterQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtudeMasterQuery leftJoinEtudeMasterArea($relationAlias = null) Adds a LEFT JOIN clause to the query using the EtudeMasterArea relation
 * @method     ChildEtudeMasterQuery rightJoinEtudeMasterArea($relationAlias = null) Adds a RIGHT JOIN clause to the query using the EtudeMasterArea relation
 * @method     ChildEtudeMasterQuery innerJoinEtudeMasterArea($relationAlias = null) Adds a INNER JOIN clause to the query using the EtudeMasterArea relation
 *
 * @method     ChildEtudeMasterQuery joinWithEtudeMasterArea($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the EtudeMasterArea relation
 *
 * @method     ChildEtudeMasterQuery leftJoinWithEtudeMasterArea() Adds a LEFT JOIN clause and with to the query using the EtudeMasterArea relation
 * @method     ChildEtudeMasterQuery rightJoinWithEtudeMasterArea() Adds a RIGHT JOIN clause and with to the query using the EtudeMasterArea relation
 * @method     ChildEtudeMasterQuery innerJoinWithEtudeMasterArea() Adds a INNER JOIN clause and with to the query using the EtudeMasterArea relation
 *
 * @method     ChildEtudeMasterQuery leftJoinAccount($relationAlias = null) Adds a LEFT JOIN clause to the query using the Account relation
 * @method     ChildEtudeMasterQuery rightJoinAccount($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Account relation
 * @method     ChildEtudeMasterQuery innerJoinAccount($relationAlias = null) Adds a INNER JOIN clause to the query using the Account relation
 *
 * @method     ChildEtudeMasterQuery joinWithAccount($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Account relation
 *
 * @method     ChildEtudeMasterQuery leftJoinWithAccount() Adds a LEFT JOIN clause and with to the query using the Account relation
 * @method     ChildEtudeMasterQuery rightJoinWithAccount() Adds a RIGHT JOIN clause and with to the query using the Account relation
 * @method     ChildEtudeMasterQuery innerJoinWithAccount() Adds a INNER JOIN clause and with to the query using the Account relation
 *
 * @method     ChildEtudeMasterQuery leftJoinIndustry($relationAlias = null) Adds a LEFT JOIN clause to the query using the Industry relation
 * @method     ChildEtudeMasterQuery rightJoinIndustry($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Industry relation
 * @method     ChildEtudeMasterQuery innerJoinIndustry($relationAlias = null) Adds a INNER JOIN clause to the query using the Industry relation
 *
 * @method     ChildEtudeMasterQuery joinWithIndustry($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Industry relation
 *
 * @method     ChildEtudeMasterQuery leftJoinWithIndustry() Adds a LEFT JOIN clause and with to the query using the Industry relation
 * @method     ChildEtudeMasterQuery rightJoinWithIndustry() Adds a RIGHT JOIN clause and with to the query using the Industry relation
 * @method     ChildEtudeMasterQuery innerJoinWithIndustry() Adds a INNER JOIN clause and with to the query using the Industry relation
 *
 * @method     ChildEtudeMasterQuery leftJoinEtape($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeMasterQuery rightJoinEtape($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etape relation
 * @method     ChildEtudeMasterQuery innerJoinEtape($relationAlias = null) Adds a INNER JOIN clause to the query using the Etape relation
 *
 * @method     ChildEtudeMasterQuery joinWithEtape($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etape relation
 *
 * @method     ChildEtudeMasterQuery leftJoinWithEtape() Adds a LEFT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeMasterQuery rightJoinWithEtape() Adds a RIGHT JOIN clause and with to the query using the Etape relation
 * @method     ChildEtudeMasterQuery innerJoinWithEtape() Adds a INNER JOIN clause and with to the query using the Etape relation
 *
 * @method     \Model\AreaQuery|\Model\AccountQuery|\Model\IndustryQuery|\Model\EtapeQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtudeMaster|null findOne(ConnectionInterface $con = null) Return the first ChildEtudeMaster matching the query
 * @method     ChildEtudeMaster findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtudeMaster matching the query, or a new ChildEtudeMaster object populated from the query conditions when no match is found
 *
 * @method     ChildEtudeMaster|null findOneById(int $id) Return the first ChildEtudeMaster filtered by the id column
 * @method     ChildEtudeMaster|null findOneByNumeroEtude(string $numero_etude) Return the first ChildEtudeMaster filtered by the numero_etude column
 * @method     ChildEtudeMaster|null findOneByReferenceClient(string $reference_client) Return the first ChildEtudeMaster filtered by the reference_client column
 * @method     ChildEtudeMaster|null findOneByTheme(string $theme) Return the first ChildEtudeMaster filtered by the theme column
 * @method     ChildEtudeMaster|null findOneByDateDebut(string $date_debut) Return the first ChildEtudeMaster filtered by the date_debut column
 * @method     ChildEtudeMaster|null findOneByDateFin(string $date_fin) Return the first ChildEtudeMaster filtered by the date_fin column
 * @method     ChildEtudeMaster|null findOneByAnnee(string $annee) Return the first ChildEtudeMaster filtered by the annee column
 * @method     ChildEtudeMaster|null findOneByIdPm(int $id_pm) Return the first ChildEtudeMaster filtered by the id_pm column
 * @method     ChildEtudeMaster|null findOneByIdEtape(int $id_etape) Return the first ChildEtudeMaster filtered by the id_etape column
 * @method     ChildEtudeMaster|null findOneByPrixRevientInitial(string $prix_revient_initial) Return the first ChildEtudeMaster filtered by the prix_revient_initial column
 * @method     ChildEtudeMaster|null findOneByPrixRevientActualise(string $prix_revient_actualise) Return the first ChildEtudeMaster filtered by the prix_revient_actualise column
 * @method     ChildEtudeMaster|null findOneByPrixVenteInitial(string $prix_vente_initial) Return the first ChildEtudeMaster filtered by the prix_vente_initial column
 * @method     ChildEtudeMaster|null findOneByPrixVenteActualise(string $prix_vente_actualise) Return the first ChildEtudeMaster filtered by the prix_vente_actualise column
 * @method     ChildEtudeMaster|null findOneByNumeroFacture(string $numero_facture) Return the first ChildEtudeMaster filtered by the numero_facture column
 * @method     ChildEtudeMaster|null findOneByDateEnvoiFacture(string $date_envoi_facture) Return the first ChildEtudeMaster filtered by the date_envoi_facture column
 * @method     ChildEtudeMaster|null findOneByDateReglement(string $date_reglement) Return the first ChildEtudeMaster filtered by the date_reglement column
 * @method     ChildEtudeMaster|null findOneByCommentaire(string $commentaire) Return the first ChildEtudeMaster filtered by the commentaire column
 * @method     ChildEtudeMaster|null findOneByIndustryId(int $industry_id) Return the first ChildEtudeMaster filtered by the industry_id column
 * @method     ChildEtudeMaster|null findOneByPeriodeCutoff(string $periode_cutoff) Return the first ChildEtudeMaster filtered by the periode_cutoff column
 * @method     ChildEtudeMaster|null findOneByThemeBr(string $theme_br) Return the first ChildEtudeMaster filtered by the theme_br column
 * @method     ChildEtudeMaster|null findOneByAreaId(int $area_id) Return the first ChildEtudeMaster filtered by the area_id column
 * @method     ChildEtudeMaster|null findOneByIdQq(int $id_qq) Return the first ChildEtudeMaster filtered by the id_qq column
 * @method     ChildEtudeMaster|null findOneByIdSamsStudy(string $id_sams_study) Return the first ChildEtudeMaster filtered by the id_sams_study column
 * @method     ChildEtudeMaster|null findOneByRecrutementObjectif(int $recrutement_objectif) Return the first ChildEtudeMaster filtered by the recrutement_objectif column
 * @method     ChildEtudeMaster|null findOneByIdLocationPnl(int $id_location_pnl) Return the first ChildEtudeMaster filtered by the id_location_pnl column
 * @method     ChildEtudeMaster|null findOneByDurationstudy(string $durationStudy) Return the first ChildEtudeMaster filtered by the durationStudy column
 * @method     ChildEtudeMaster|null findOneByRecrutementObjectifPr(int $recrutement_objectif_pr) Return the first ChildEtudeMaster filtered by the recrutement_objectif_pr column
 * @method     ChildEtudeMaster|null findOneByIdBm(int $id_bm) Return the first ChildEtudeMaster filtered by the id_bm column
 * @method     ChildEtudeMaster|null findOneByAccountId(int $account_id) Return the first ChildEtudeMaster filtered by the account_id column
 * @method     ChildEtudeMaster|null findOneByRemiseTaux(string $remise_taux) Return the first ChildEtudeMaster filtered by the remise_taux column
 * @method     ChildEtudeMaster|null findOneByLanguage(string $language) Return the first ChildEtudeMaster filtered by the language column
 * @method     ChildEtudeMaster|null findOneByKol(string $kol) Return the first ChildEtudeMaster filtered by the kol column
 * @method     ChildEtudeMaster|null findOneBySmsRelance(string $sms_relance) Return the first ChildEtudeMaster filtered by the sms_relance column
 * @method     ChildEtudeMaster|null findOneByGms(string $gms) Return the first ChildEtudeMaster filtered by the gms column *

 * @method     ChildEtudeMaster requirePk($key, ConnectionInterface $con = null) Return the ChildEtudeMaster by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOne(ConnectionInterface $con = null) Return the first ChildEtudeMaster matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeMaster requireOneById(int $id) Return the first ChildEtudeMaster filtered by the id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByNumeroEtude(string $numero_etude) Return the first ChildEtudeMaster filtered by the numero_etude column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByReferenceClient(string $reference_client) Return the first ChildEtudeMaster filtered by the reference_client column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByTheme(string $theme) Return the first ChildEtudeMaster filtered by the theme column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByDateDebut(string $date_debut) Return the first ChildEtudeMaster filtered by the date_debut column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByDateFin(string $date_fin) Return the first ChildEtudeMaster filtered by the date_fin column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByAnnee(string $annee) Return the first ChildEtudeMaster filtered by the annee column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdPm(int $id_pm) Return the first ChildEtudeMaster filtered by the id_pm column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdEtape(int $id_etape) Return the first ChildEtudeMaster filtered by the id_etape column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByPrixRevientInitial(string $prix_revient_initial) Return the first ChildEtudeMaster filtered by the prix_revient_initial column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByPrixRevientActualise(string $prix_revient_actualise) Return the first ChildEtudeMaster filtered by the prix_revient_actualise column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByPrixVenteInitial(string $prix_vente_initial) Return the first ChildEtudeMaster filtered by the prix_vente_initial column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByPrixVenteActualise(string $prix_vente_actualise) Return the first ChildEtudeMaster filtered by the prix_vente_actualise column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByNumeroFacture(string $numero_facture) Return the first ChildEtudeMaster filtered by the numero_facture column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByDateEnvoiFacture(string $date_envoi_facture) Return the first ChildEtudeMaster filtered by the date_envoi_facture column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByDateReglement(string $date_reglement) Return the first ChildEtudeMaster filtered by the date_reglement column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByCommentaire(string $commentaire) Return the first ChildEtudeMaster filtered by the commentaire column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIndustryId(int $industry_id) Return the first ChildEtudeMaster filtered by the industry_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByPeriodeCutoff(string $periode_cutoff) Return the first ChildEtudeMaster filtered by the periode_cutoff column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByThemeBr(string $theme_br) Return the first ChildEtudeMaster filtered by the theme_br column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByAreaId(int $area_id) Return the first ChildEtudeMaster filtered by the area_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdQq(int $id_qq) Return the first ChildEtudeMaster filtered by the id_qq column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdSamsStudy(string $id_sams_study) Return the first ChildEtudeMaster filtered by the id_sams_study column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByRecrutementObjectif(int $recrutement_objectif) Return the first ChildEtudeMaster filtered by the recrutement_objectif column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdLocationPnl(int $id_location_pnl) Return the first ChildEtudeMaster filtered by the id_location_pnl column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByDurationstudy(string $durationStudy) Return the first ChildEtudeMaster filtered by the durationStudy column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByRecrutementObjectifPr(int $recrutement_objectif_pr) Return the first ChildEtudeMaster filtered by the recrutement_objectif_pr column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByIdBm(int $id_bm) Return the first ChildEtudeMaster filtered by the id_bm column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByAccountId(int $account_id) Return the first ChildEtudeMaster filtered by the account_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByRemiseTaux(string $remise_taux) Return the first ChildEtudeMaster filtered by the remise_taux column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByLanguage(string $language) Return the first ChildEtudeMaster filtered by the language column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByKol(string $kol) Return the first ChildEtudeMaster filtered by the kol column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneBySmsRelance(string $sms_relance) Return the first ChildEtudeMaster filtered by the sms_relance column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeMaster requireOneByGms(string $gms) Return the first ChildEtudeMaster filtered by the gms column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeMaster[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtudeMaster objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> find(ConnectionInterface $con = null) Return ChildEtudeMaster objects based on current ModelCriteria
 * @method     ChildEtudeMaster[]|ObjectCollection findById(int $id) Return ChildEtudeMaster objects filtered by the id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findById(int $id) Return ChildEtudeMaster objects filtered by the id column
 * @method     ChildEtudeMaster[]|ObjectCollection findByNumeroEtude(string $numero_etude) Return ChildEtudeMaster objects filtered by the numero_etude column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByNumeroEtude(string $numero_etude) Return ChildEtudeMaster objects filtered by the numero_etude column
 * @method     ChildEtudeMaster[]|ObjectCollection findByReferenceClient(string $reference_client) Return ChildEtudeMaster objects filtered by the reference_client column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByReferenceClient(string $reference_client) Return ChildEtudeMaster objects filtered by the reference_client column
 * @method     ChildEtudeMaster[]|ObjectCollection findByTheme(string $theme) Return ChildEtudeMaster objects filtered by the theme column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByTheme(string $theme) Return ChildEtudeMaster objects filtered by the theme column
 * @method     ChildEtudeMaster[]|ObjectCollection findByDateDebut(string $date_debut) Return ChildEtudeMaster objects filtered by the date_debut column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByDateDebut(string $date_debut) Return ChildEtudeMaster objects filtered by the date_debut column
 * @method     ChildEtudeMaster[]|ObjectCollection findByDateFin(string $date_fin) Return ChildEtudeMaster objects filtered by the date_fin column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByDateFin(string $date_fin) Return ChildEtudeMaster objects filtered by the date_fin column
 * @method     ChildEtudeMaster[]|ObjectCollection findByAnnee(string $annee) Return ChildEtudeMaster objects filtered by the annee column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByAnnee(string $annee) Return ChildEtudeMaster objects filtered by the annee column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdPm(int $id_pm) Return ChildEtudeMaster objects filtered by the id_pm column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdPm(int $id_pm) Return ChildEtudeMaster objects filtered by the id_pm column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdEtape(int $id_etape) Return ChildEtudeMaster objects filtered by the id_etape column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdEtape(int $id_etape) Return ChildEtudeMaster objects filtered by the id_etape column
 * @method     ChildEtudeMaster[]|ObjectCollection findByPrixRevientInitial(string $prix_revient_initial) Return ChildEtudeMaster objects filtered by the prix_revient_initial column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByPrixRevientInitial(string $prix_revient_initial) Return ChildEtudeMaster objects filtered by the prix_revient_initial column
 * @method     ChildEtudeMaster[]|ObjectCollection findByPrixRevientActualise(string $prix_revient_actualise) Return ChildEtudeMaster objects filtered by the prix_revient_actualise column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByPrixRevientActualise(string $prix_revient_actualise) Return ChildEtudeMaster objects filtered by the prix_revient_actualise column
 * @method     ChildEtudeMaster[]|ObjectCollection findByPrixVenteInitial(string $prix_vente_initial) Return ChildEtudeMaster objects filtered by the prix_vente_initial column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByPrixVenteInitial(string $prix_vente_initial) Return ChildEtudeMaster objects filtered by the prix_vente_initial column
 * @method     ChildEtudeMaster[]|ObjectCollection findByPrixVenteActualise(string $prix_vente_actualise) Return ChildEtudeMaster objects filtered by the prix_vente_actualise column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByPrixVenteActualise(string $prix_vente_actualise) Return ChildEtudeMaster objects filtered by the prix_vente_actualise column
 * @method     ChildEtudeMaster[]|ObjectCollection findByNumeroFacture(string $numero_facture) Return ChildEtudeMaster objects filtered by the numero_facture column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByNumeroFacture(string $numero_facture) Return ChildEtudeMaster objects filtered by the numero_facture column
 * @method     ChildEtudeMaster[]|ObjectCollection findByDateEnvoiFacture(string $date_envoi_facture) Return ChildEtudeMaster objects filtered by the date_envoi_facture column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByDateEnvoiFacture(string $date_envoi_facture) Return ChildEtudeMaster objects filtered by the date_envoi_facture column
 * @method     ChildEtudeMaster[]|ObjectCollection findByDateReglement(string $date_reglement) Return ChildEtudeMaster objects filtered by the date_reglement column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByDateReglement(string $date_reglement) Return ChildEtudeMaster objects filtered by the date_reglement column
 * @method     ChildEtudeMaster[]|ObjectCollection findByCommentaire(string $commentaire) Return ChildEtudeMaster objects filtered by the commentaire column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByCommentaire(string $commentaire) Return ChildEtudeMaster objects filtered by the commentaire column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIndustryId(int $industry_id) Return ChildEtudeMaster objects filtered by the industry_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIndustryId(int $industry_id) Return ChildEtudeMaster objects filtered by the industry_id column
 * @method     ChildEtudeMaster[]|ObjectCollection findByPeriodeCutoff(string $periode_cutoff) Return ChildEtudeMaster objects filtered by the periode_cutoff column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByPeriodeCutoff(string $periode_cutoff) Return ChildEtudeMaster objects filtered by the periode_cutoff column
 * @method     ChildEtudeMaster[]|ObjectCollection findByThemeBr(string $theme_br) Return ChildEtudeMaster objects filtered by the theme_br column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByThemeBr(string $theme_br) Return ChildEtudeMaster objects filtered by the theme_br column
 * @method     ChildEtudeMaster[]|ObjectCollection findByAreaId(int $area_id) Return ChildEtudeMaster objects filtered by the area_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByAreaId(int $area_id) Return ChildEtudeMaster objects filtered by the area_id column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdQq(int $id_qq) Return ChildEtudeMaster objects filtered by the id_qq column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdQq(int $id_qq) Return ChildEtudeMaster objects filtered by the id_qq column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdSamsStudy(string $id_sams_study) Return ChildEtudeMaster objects filtered by the id_sams_study column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdSamsStudy(string $id_sams_study) Return ChildEtudeMaster objects filtered by the id_sams_study column
 * @method     ChildEtudeMaster[]|ObjectCollection findByRecrutementObjectif(int $recrutement_objectif) Return ChildEtudeMaster objects filtered by the recrutement_objectif column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByRecrutementObjectif(int $recrutement_objectif) Return ChildEtudeMaster objects filtered by the recrutement_objectif column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdLocationPnl(int $id_location_pnl) Return ChildEtudeMaster objects filtered by the id_location_pnl column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdLocationPnl(int $id_location_pnl) Return ChildEtudeMaster objects filtered by the id_location_pnl column
 * @method     ChildEtudeMaster[]|ObjectCollection findByDurationstudy(string $durationStudy) Return ChildEtudeMaster objects filtered by the durationStudy column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByDurationstudy(string $durationStudy) Return ChildEtudeMaster objects filtered by the durationStudy column
 * @method     ChildEtudeMaster[]|ObjectCollection findByRecrutementObjectifPr(int $recrutement_objectif_pr) Return ChildEtudeMaster objects filtered by the recrutement_objectif_pr column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByRecrutementObjectifPr(int $recrutement_objectif_pr) Return ChildEtudeMaster objects filtered by the recrutement_objectif_pr column
 * @method     ChildEtudeMaster[]|ObjectCollection findByIdBm(int $id_bm) Return ChildEtudeMaster objects filtered by the id_bm column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByIdBm(int $id_bm) Return ChildEtudeMaster objects filtered by the id_bm column
 * @method     ChildEtudeMaster[]|ObjectCollection findByAccountId(int $account_id) Return ChildEtudeMaster objects filtered by the account_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByAccountId(int $account_id) Return ChildEtudeMaster objects filtered by the account_id column
 * @method     ChildEtudeMaster[]|ObjectCollection findByRemiseTaux(string $remise_taux) Return ChildEtudeMaster objects filtered by the remise_taux column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByRemiseTaux(string $remise_taux) Return ChildEtudeMaster objects filtered by the remise_taux column
 * @method     ChildEtudeMaster[]|ObjectCollection findByLanguage(string $language) Return ChildEtudeMaster objects filtered by the language column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByLanguage(string $language) Return ChildEtudeMaster objects filtered by the language column
 * @method     ChildEtudeMaster[]|ObjectCollection findByKol(string $kol) Return ChildEtudeMaster objects filtered by the kol column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByKol(string $kol) Return ChildEtudeMaster objects filtered by the kol column
 * @method     ChildEtudeMaster[]|ObjectCollection findBySmsRelance(string $sms_relance) Return ChildEtudeMaster objects filtered by the sms_relance column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findBySmsRelance(string $sms_relance) Return ChildEtudeMaster objects filtered by the sms_relance column
 * @method     ChildEtudeMaster[]|ObjectCollection findByGms(string $gms) Return ChildEtudeMaster objects filtered by the gms column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeMaster> findByGms(string $gms) Return ChildEtudeMaster objects filtered by the gms column
 * @method     ChildEtudeMaster[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtudeMaster> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtudeMasterQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtudeMasterQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EtudeMaster', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtudeMasterQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtudeMasterQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtudeMasterQuery) {
            return $criteria;
        }
        $query = new ChildEtudeMasterQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtudeMaster|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeMasterTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtudeMasterTableMap::getInstanceFromPool(null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key)))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeMaster A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `id`, `numero_etude`, `reference_client`, `theme`, `date_debut`, `date_fin`, `annee`, `id_pm`, `id_etape`, `prix_revient_initial`, `prix_revient_actualise`, `prix_vente_initial`, `prix_vente_actualise`, `numero_facture`, `date_envoi_facture`, `date_reglement`, `commentaire`, `industry_id`, `periode_cutoff`, `theme_br`, `area_id`, `id_qq`, `id_sams_study`, `recrutement_objectif`, `id_location_pnl`, `durationStudy`, `recrutement_objectif_pr`, `id_bm`, `account_id`, `remise_taux`, `language`, `kol`, `sms_relance`, `gms` FROM `etude_master` WHERE `id` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtudeMaster $obj */
            $obj = new ChildEtudeMaster();
            $obj->hydrate($row);
            EtudeMasterTableMap::addInstanceToPool($obj, null === $key || is_scalar($key) || is_callable([$key, '__toString']) ? (string) $key : $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtudeMaster|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the id column
     *
     * Example usage:
     * <code>
     * $query->filterById(1234); // WHERE id = 1234
     * $query->filterById(array(12, 34)); // WHERE id IN (12, 34)
     * $query->filterById(array('min' => 12)); // WHERE id > 12
     * </code>
     *
     * @param     mixed $id The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterById($id = null, $comparison = null)
    {
        if (is_array($id)) {
            $useMinMax = false;
            if (isset($id['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $id['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($id['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $id['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $id, $comparison);
    }

    /**
     * Filter the query on the numero_etude column
     *
     * Example usage:
     * <code>
     * $query->filterByNumeroEtude('fooValue');   // WHERE numero_etude = 'fooValue'
     * $query->filterByNumeroEtude('%fooValue%', Criteria::LIKE); // WHERE numero_etude LIKE '%fooValue%'
     * $query->filterByNumeroEtude(['foo', 'bar']); // WHERE numero_etude IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $numeroEtude The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByNumeroEtude($numeroEtude = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($numeroEtude)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_NUMERO_ETUDE, $numeroEtude, $comparison);
    }

    /**
     * Filter the query on the reference_client column
     *
     * Example usage:
     * <code>
     * $query->filterByReferenceClient('fooValue');   // WHERE reference_client = 'fooValue'
     * $query->filterByReferenceClient('%fooValue%', Criteria::LIKE); // WHERE reference_client LIKE '%fooValue%'
     * $query->filterByReferenceClient(['foo', 'bar']); // WHERE reference_client IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $referenceClient The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByReferenceClient($referenceClient = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referenceClient)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_REFERENCE_CLIENT, $referenceClient, $comparison);
    }

    /**
     * Filter the query on the theme column
     *
     * Example usage:
     * <code>
     * $query->filterByTheme('fooValue');   // WHERE theme = 'fooValue'
     * $query->filterByTheme('%fooValue%', Criteria::LIKE); // WHERE theme LIKE '%fooValue%'
     * $query->filterByTheme(['foo', 'bar']); // WHERE theme IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $theme The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByTheme($theme = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($theme)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_THEME, $theme, $comparison);
    }

    /**
     * Filter the query on the date_debut column
     *
     * Example usage:
     * <code>
     * $query->filterByDateDebut('2011-03-14'); // WHERE date_debut = '2011-03-14'
     * $query->filterByDateDebut('now'); // WHERE date_debut = '2011-03-14'
     * $query->filterByDateDebut(array('max' => 'yesterday')); // WHERE date_debut > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateDebut The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByDateDebut($dateDebut = null, $comparison = null)
    {
        if (is_array($dateDebut)) {
            $useMinMax = false;
            if (isset($dateDebut['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_DEBUT, $dateDebut['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateDebut['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_DEBUT, $dateDebut['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_DEBUT, $dateDebut, $comparison);
    }

    /**
     * Filter the query on the date_fin column
     *
     * Example usage:
     * <code>
     * $query->filterByDateFin('2011-03-14'); // WHERE date_fin = '2011-03-14'
     * $query->filterByDateFin('now'); // WHERE date_fin = '2011-03-14'
     * $query->filterByDateFin(array('max' => 'yesterday')); // WHERE date_fin > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateFin The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByDateFin($dateFin = null, $comparison = null)
    {
        if (is_array($dateFin)) {
            $useMinMax = false;
            if (isset($dateFin['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_FIN, $dateFin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateFin['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_FIN, $dateFin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_FIN, $dateFin, $comparison);
    }

    /**
     * Filter the query on the annee column
     *
     * Example usage:
     * <code>
     * $query->filterByAnnee('fooValue');   // WHERE annee = 'fooValue'
     * $query->filterByAnnee('%fooValue%', Criteria::LIKE); // WHERE annee LIKE '%fooValue%'
     * $query->filterByAnnee(['foo', 'bar']); // WHERE annee IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $annee The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByAnnee($annee = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($annee)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ANNEE, $annee, $comparison);
    }

    /**
     * Filter the query on the id_pm column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPm(1234); // WHERE id_pm = 1234
     * $query->filterByIdPm(array(12, 34)); // WHERE id_pm IN (12, 34)
     * $query->filterByIdPm(array('min' => 12)); // WHERE id_pm > 12
     * </code>
     *
     * @param     mixed $idPm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdPm($idPm = null, $comparison = null)
    {
        if (is_array($idPm)) {
            $useMinMax = false;
            if (isset($idPm['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_PM, $idPm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPm['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_PM, $idPm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_PM, $idPm, $comparison);
    }

    /**
     * Filter the query on the id_etape column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtape(1234); // WHERE id_etape = 1234
     * $query->filterByIdEtape(array(12, 34)); // WHERE id_etape IN (12, 34)
     * $query->filterByIdEtape(array('min' => 12)); // WHERE id_etape > 12
     * </code>
     *
     * @see       filterByEtape()
     *
     * @param     mixed $idEtape The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdEtape($idEtape = null, $comparison = null)
    {
        if (is_array($idEtape)) {
            $useMinMax = false;
            if (isset($idEtape['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_ETAPE, $idEtape['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtape['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_ETAPE, $idEtape['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_ETAPE, $idEtape, $comparison);
    }

    /**
     * Filter the query on the prix_revient_initial column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixRevientInitial(1234); // WHERE prix_revient_initial = 1234
     * $query->filterByPrixRevientInitial(array(12, 34)); // WHERE prix_revient_initial IN (12, 34)
     * $query->filterByPrixRevientInitial(array('min' => 12)); // WHERE prix_revient_initial > 12
     * </code>
     *
     * @param     mixed $prixRevientInitial The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrixRevientInitial($prixRevientInitial = null, $comparison = null)
    {
        if (is_array($prixRevientInitial)) {
            $useMinMax = false;
            if (isset($prixRevientInitial['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixRevientInitial['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_INITIAL, $prixRevientInitial, $comparison);
    }

    /**
     * Filter the query on the prix_revient_actualise column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixRevientActualise(1234); // WHERE prix_revient_actualise = 1234
     * $query->filterByPrixRevientActualise(array(12, 34)); // WHERE prix_revient_actualise IN (12, 34)
     * $query->filterByPrixRevientActualise(array('min' => 12)); // WHERE prix_revient_actualise > 12
     * </code>
     *
     * @param     mixed $prixRevientActualise The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrixRevientActualise($prixRevientActualise = null, $comparison = null)
    {
        if (is_array($prixRevientActualise)) {
            $useMinMax = false;
            if (isset($prixRevientActualise['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixRevientActualise['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_REVIENT_ACTUALISE, $prixRevientActualise, $comparison);
    }

    /**
     * Filter the query on the prix_vente_initial column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixVenteInitial(1234); // WHERE prix_vente_initial = 1234
     * $query->filterByPrixVenteInitial(array(12, 34)); // WHERE prix_vente_initial IN (12, 34)
     * $query->filterByPrixVenteInitial(array('min' => 12)); // WHERE prix_vente_initial > 12
     * </code>
     *
     * @param     mixed $prixVenteInitial The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrixVenteInitial($prixVenteInitial = null, $comparison = null)
    {
        if (is_array($prixVenteInitial)) {
            $useMinMax = false;
            if (isset($prixVenteInitial['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixVenteInitial['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_INITIAL, $prixVenteInitial, $comparison);
    }

    /**
     * Filter the query on the prix_vente_actualise column
     *
     * Example usage:
     * <code>
     * $query->filterByPrixVenteActualise(1234); // WHERE prix_vente_actualise = 1234
     * $query->filterByPrixVenteActualise(array(12, 34)); // WHERE prix_vente_actualise IN (12, 34)
     * $query->filterByPrixVenteActualise(array('min' => 12)); // WHERE prix_vente_actualise > 12
     * </code>
     *
     * @param     mixed $prixVenteActualise The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPrixVenteActualise($prixVenteActualise = null, $comparison = null)
    {
        if (is_array($prixVenteActualise)) {
            $useMinMax = false;
            if (isset($prixVenteActualise['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($prixVenteActualise['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_PRIX_VENTE_ACTUALISE, $prixVenteActualise, $comparison);
    }

    /**
     * Filter the query on the numero_facture column
     *
     * Example usage:
     * <code>
     * $query->filterByNumeroFacture('fooValue');   // WHERE numero_facture = 'fooValue'
     * $query->filterByNumeroFacture('%fooValue%', Criteria::LIKE); // WHERE numero_facture LIKE '%fooValue%'
     * $query->filterByNumeroFacture(['foo', 'bar']); // WHERE numero_facture IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $numeroFacture The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByNumeroFacture($numeroFacture = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($numeroFacture)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_NUMERO_FACTURE, $numeroFacture, $comparison);
    }

    /**
     * Filter the query on the date_envoi_facture column
     *
     * Example usage:
     * <code>
     * $query->filterByDateEnvoiFacture('2011-03-14'); // WHERE date_envoi_facture = '2011-03-14'
     * $query->filterByDateEnvoiFacture('now'); // WHERE date_envoi_facture = '2011-03-14'
     * $query->filterByDateEnvoiFacture(array('max' => 'yesterday')); // WHERE date_envoi_facture > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateEnvoiFacture The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByDateEnvoiFacture($dateEnvoiFacture = null, $comparison = null)
    {
        if (is_array($dateEnvoiFacture)) {
            $useMinMax = false;
            if (isset($dateEnvoiFacture['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateEnvoiFacture['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_ENVOI_FACTURE, $dateEnvoiFacture, $comparison);
    }

    /**
     * Filter the query on the date_reglement column
     *
     * Example usage:
     * <code>
     * $query->filterByDateReglement('2011-03-14'); // WHERE date_reglement = '2011-03-14'
     * $query->filterByDateReglement('now'); // WHERE date_reglement = '2011-03-14'
     * $query->filterByDateReglement(array('max' => 'yesterday')); // WHERE date_reglement > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateReglement The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByDateReglement($dateReglement = null, $comparison = null)
    {
        if (is_array($dateReglement)) {
            $useMinMax = false;
            if (isset($dateReglement['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_REGLEMENT, $dateReglement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateReglement['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_REGLEMENT, $dateReglement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_DATE_REGLEMENT, $dateReglement, $comparison);
    }

    /**
     * Filter the query on the commentaire column
     *
     * Example usage:
     * <code>
     * $query->filterByCommentaire('fooValue');   // WHERE commentaire = 'fooValue'
     * $query->filterByCommentaire('%fooValue%', Criteria::LIKE); // WHERE commentaire LIKE '%fooValue%'
     * $query->filterByCommentaire(['foo', 'bar']); // WHERE commentaire IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $commentaire The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByCommentaire($commentaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($commentaire)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_COMMENTAIRE, $commentaire, $comparison);
    }

    /**
     * Filter the query on the industry_id column
     *
     * Example usage:
     * <code>
     * $query->filterByIndustryId(1234); // WHERE industry_id = 1234
     * $query->filterByIndustryId(array(12, 34)); // WHERE industry_id IN (12, 34)
     * $query->filterByIndustryId(array('min' => 12)); // WHERE industry_id > 12
     * </code>
     *
     * @see       filterByIndustry()
     *
     * @param     mixed $industryId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIndustryId($industryId = null, $comparison = null)
    {
        if (is_array($industryId)) {
            $useMinMax = false;
            if (isset($industryId['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_INDUSTRY_ID, $industryId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($industryId['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_INDUSTRY_ID, $industryId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_INDUSTRY_ID, $industryId, $comparison);
    }

    /**
     * Filter the query on the periode_cutoff column
     *
     * Example usage:
     * <code>
     * $query->filterByPeriodeCutoff('fooValue');   // WHERE periode_cutoff = 'fooValue'
     * $query->filterByPeriodeCutoff('%fooValue%', Criteria::LIKE); // WHERE periode_cutoff LIKE '%fooValue%'
     * $query->filterByPeriodeCutoff(['foo', 'bar']); // WHERE periode_cutoff IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $periodeCutoff The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByPeriodeCutoff($periodeCutoff = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($periodeCutoff)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_PERIODE_CUTOFF, $periodeCutoff, $comparison);
    }

    /**
     * Filter the query on the theme_br column
     *
     * Example usage:
     * <code>
     * $query->filterByThemeBr('fooValue');   // WHERE theme_br = 'fooValue'
     * $query->filterByThemeBr('%fooValue%', Criteria::LIKE); // WHERE theme_br LIKE '%fooValue%'
     * $query->filterByThemeBr(['foo', 'bar']); // WHERE theme_br IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $themeBr The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByThemeBr($themeBr = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($themeBr)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_THEME_BR, $themeBr, $comparison);
    }

    /**
     * Filter the query on the area_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAreaId(1234); // WHERE area_id = 1234
     * $query->filterByAreaId(array(12, 34)); // WHERE area_id IN (12, 34)
     * $query->filterByAreaId(array('min' => 12)); // WHERE area_id > 12
     * </code>
     *
     * @see       filterByEtudeMasterArea()
     *
     * @param     mixed $areaId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByAreaId($areaId = null, $comparison = null)
    {
        if (is_array($areaId)) {
            $useMinMax = false;
            if (isset($areaId['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_AREA_ID, $areaId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($areaId['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_AREA_ID, $areaId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_AREA_ID, $areaId, $comparison);
    }

    /**
     * Filter the query on the id_qq column
     *
     * Example usage:
     * <code>
     * $query->filterByIdQq(1234); // WHERE id_qq = 1234
     * $query->filterByIdQq(array(12, 34)); // WHERE id_qq IN (12, 34)
     * $query->filterByIdQq(array('min' => 12)); // WHERE id_qq > 12
     * </code>
     *
     * @param     mixed $idQq The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdQq($idQq = null, $comparison = null)
    {
        if (is_array($idQq)) {
            $useMinMax = false;
            if (isset($idQq['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_QQ, $idQq['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idQq['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_QQ, $idQq['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_QQ, $idQq, $comparison);
    }

    /**
     * Filter the query on the id_sams_study column
     *
     * Example usage:
     * <code>
     * $query->filterByIdSamsStudy('fooValue');   // WHERE id_sams_study = 'fooValue'
     * $query->filterByIdSamsStudy('%fooValue%', Criteria::LIKE); // WHERE id_sams_study LIKE '%fooValue%'
     * $query->filterByIdSamsStudy(['foo', 'bar']); // WHERE id_sams_study IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $idSamsStudy The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdSamsStudy($idSamsStudy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($idSamsStudy)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_SAMS_STUDY, $idSamsStudy, $comparison);
    }

    /**
     * Filter the query on the recrutement_objectif column
     *
     * Example usage:
     * <code>
     * $query->filterByRecrutementObjectif(1234); // WHERE recrutement_objectif = 1234
     * $query->filterByRecrutementObjectif(array(12, 34)); // WHERE recrutement_objectif IN (12, 34)
     * $query->filterByRecrutementObjectif(array('min' => 12)); // WHERE recrutement_objectif > 12
     * </code>
     *
     * @param     mixed $recrutementObjectif The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByRecrutementObjectif($recrutementObjectif = null, $comparison = null)
    {
        if (is_array($recrutementObjectif)) {
            $useMinMax = false;
            if (isset($recrutementObjectif['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($recrutementObjectif['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF, $recrutementObjectif, $comparison);
    }

    /**
     * Filter the query on the id_location_pnl column
     *
     * Example usage:
     * <code>
     * $query->filterByIdLocationPnl(1234); // WHERE id_location_pnl = 1234
     * $query->filterByIdLocationPnl(array(12, 34)); // WHERE id_location_pnl IN (12, 34)
     * $query->filterByIdLocationPnl(array('min' => 12)); // WHERE id_location_pnl > 12
     * </code>
     *
     * @param     mixed $idLocationPnl The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdLocationPnl($idLocationPnl = null, $comparison = null)
    {
        if (is_array($idLocationPnl)) {
            $useMinMax = false;
            if (isset($idLocationPnl['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_LOCATION_PNL, $idLocationPnl['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idLocationPnl['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_LOCATION_PNL, $idLocationPnl['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_LOCATION_PNL, $idLocationPnl, $comparison);
    }

    /**
     * Filter the query on the durationStudy column
     *
     * Example usage:
     * <code>
     * $query->filterByDurationstudy('fooValue');   // WHERE durationStudy = 'fooValue'
     * $query->filterByDurationstudy('%fooValue%', Criteria::LIKE); // WHERE durationStudy LIKE '%fooValue%'
     * $query->filterByDurationstudy(['foo', 'bar']); // WHERE durationStudy IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $durationstudy The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByDurationstudy($durationstudy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($durationstudy)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_DURATIONSTUDY, $durationstudy, $comparison);
    }

    /**
     * Filter the query on the recrutement_objectif_pr column
     *
     * Example usage:
     * <code>
     * $query->filterByRecrutementObjectifPr(1234); // WHERE recrutement_objectif_pr = 1234
     * $query->filterByRecrutementObjectifPr(array(12, 34)); // WHERE recrutement_objectif_pr IN (12, 34)
     * $query->filterByRecrutementObjectifPr(array('min' => 12)); // WHERE recrutement_objectif_pr > 12
     * </code>
     *
     * @param     mixed $recrutementObjectifPr The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByRecrutementObjectifPr($recrutementObjectifPr = null, $comparison = null)
    {
        if (is_array($recrutementObjectifPr)) {
            $useMinMax = false;
            if (isset($recrutementObjectifPr['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($recrutementObjectifPr['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_RECRUTEMENT_OBJECTIF_PR, $recrutementObjectifPr, $comparison);
    }

    /**
     * Filter the query on the id_bm column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBm(1234); // WHERE id_bm = 1234
     * $query->filterByIdBm(array(12, 34)); // WHERE id_bm IN (12, 34)
     * $query->filterByIdBm(array('min' => 12)); // WHERE id_bm > 12
     * </code>
     *
     * @param     mixed $idBm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIdBm($idBm = null, $comparison = null)
    {
        if (is_array($idBm)) {
            $useMinMax = false;
            if (isset($idBm['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_BM, $idBm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBm['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ID_BM, $idBm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ID_BM, $idBm, $comparison);
    }

    /**
     * Filter the query on the account_id column
     *
     * Example usage:
     * <code>
     * $query->filterByAccountId(1234); // WHERE account_id = 1234
     * $query->filterByAccountId(array(12, 34)); // WHERE account_id IN (12, 34)
     * $query->filterByAccountId(array('min' => 12)); // WHERE account_id > 12
     * </code>
     *
     * @see       filterByAccount()
     *
     * @param     mixed $accountId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByAccountId($accountId = null, $comparison = null)
    {
        if (is_array($accountId)) {
            $useMinMax = false;
            if (isset($accountId['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ACCOUNT_ID, $accountId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($accountId['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_ACCOUNT_ID, $accountId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_ACCOUNT_ID, $accountId, $comparison);
    }

    /**
     * Filter the query on the remise_taux column
     *
     * Example usage:
     * <code>
     * $query->filterByRemiseTaux(1234); // WHERE remise_taux = 1234
     * $query->filterByRemiseTaux(array(12, 34)); // WHERE remise_taux IN (12, 34)
     * $query->filterByRemiseTaux(array('min' => 12)); // WHERE remise_taux > 12
     * </code>
     *
     * @param     mixed $remiseTaux The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByRemiseTaux($remiseTaux = null, $comparison = null)
    {
        if (is_array($remiseTaux)) {
            $useMinMax = false;
            if (isset($remiseTaux['min'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_REMISE_TAUX, $remiseTaux['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($remiseTaux['max'])) {
                $this->addUsingAlias(EtudeMasterTableMap::COL_REMISE_TAUX, $remiseTaux['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_REMISE_TAUX, $remiseTaux, $comparison);
    }

    /**
     * Filter the query on the language column
     *
     * Example usage:
     * <code>
     * $query->filterByLanguage('fooValue');   // WHERE language = 'fooValue'
     * $query->filterByLanguage('%fooValue%', Criteria::LIKE); // WHERE language LIKE '%fooValue%'
     * $query->filterByLanguage(['foo', 'bar']); // WHERE language IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $language The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByLanguage($language = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($language)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_LANGUAGE, $language, $comparison);
    }

    /**
     * Filter the query on the kol column
     *
     * Example usage:
     * <code>
     * $query->filterByKol('fooValue');   // WHERE kol = 'fooValue'
     * $query->filterByKol('%fooValue%', Criteria::LIKE); // WHERE kol LIKE '%fooValue%'
     * $query->filterByKol(['foo', 'bar']); // WHERE kol IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $kol The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByKol($kol = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($kol)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_KOL, $kol, $comparison);
    }

    /**
     * Filter the query on the sms_relance column
     *
     * Example usage:
     * <code>
     * $query->filterBySmsRelance('fooValue');   // WHERE sms_relance = 'fooValue'
     * $query->filterBySmsRelance('%fooValue%', Criteria::LIKE); // WHERE sms_relance LIKE '%fooValue%'
     * $query->filterBySmsRelance(['foo', 'bar']); // WHERE sms_relance IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $smsRelance The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterBySmsRelance($smsRelance = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($smsRelance)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_SMS_RELANCE, $smsRelance, $comparison);
    }

    /**
     * Filter the query on the gms column
     *
     * Example usage:
     * <code>
     * $query->filterByGms('fooValue');   // WHERE gms = 'fooValue'
     * $query->filterByGms('%fooValue%', Criteria::LIKE); // WHERE gms LIKE '%fooValue%'
     * $query->filterByGms(['foo', 'bar']); // WHERE gms IN ('foo', 'bar')
     * </code>
     *
     * @param     string|string[] $gms The value to use as filter.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByGms($gms = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($gms)) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeMasterTableMap::COL_GMS, $gms, $comparison);
    }

    /**
     * Filter the query by a related \Model\Area object
     *
     * @param \Model\Area|ObjectCollection $area The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByEtudeMasterArea($area, $comparison = null)
    {
        if ($area instanceof \Model\Area) {
            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_AREA_ID, $area->getId(), $comparison);
        } elseif ($area instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_AREA_ID, $area->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtudeMasterArea() only accepts arguments of type \Model\Area or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the EtudeMasterArea relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function joinEtudeMasterArea($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('EtudeMasterArea');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'EtudeMasterArea');
        }

        return $this;
    }

    /**
     * Use the EtudeMasterArea relation Area object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AreaQuery A secondary query class using the current class as primary query
     */
    public function useEtudeMasterAreaQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinEtudeMasterArea($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'EtudeMasterArea', '\Model\AreaQuery');
    }

    /**
     * Use the EtudeMasterArea relation Area object
     *
     * @param callable(\Model\AreaQuery):\Model\AreaQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeMasterAreaQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useEtudeMasterAreaQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the EtudeMasterArea relation to the Area table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AreaQuery The inner query object of the EXISTS statement
     */
    public function useEtudeMasterAreaExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('EtudeMasterArea', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the EtudeMasterArea relation to the Area table for a NOT EXISTS query.
     *
     * @see useEtudeMasterAreaExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AreaQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeMasterAreaNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('EtudeMasterArea', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Account object
     *
     * @param \Model\Account|ObjectCollection $account The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByAccount($account, $comparison = null)
    {
        if ($account instanceof \Model\Account) {
            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_ACCOUNT_ID, $account->getId(), $comparison);
        } elseif ($account instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_ACCOUNT_ID, $account->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByAccount() only accepts arguments of type \Model\Account or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Account relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function joinAccount($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Account');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Account');
        }

        return $this;
    }

    /**
     * Use the Account relation Account object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\AccountQuery A secondary query class using the current class as primary query
     */
    public function useAccountQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinAccount($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Account', '\Model\AccountQuery');
    }

    /**
     * Use the Account relation Account object
     *
     * @param callable(\Model\AccountQuery):\Model\AccountQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withAccountQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::LEFT_JOIN
    ) {
        $relatedQuery = $this->useAccountQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Account table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\AccountQuery The inner query object of the EXISTS statement
     */
    public function useAccountExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Account table for a NOT EXISTS query.
     *
     * @see useAccountExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\AccountQuery The inner query object of the NOT EXISTS statement
     */
    public function useAccountNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Account', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Industry object
     *
     * @param \Model\Industry|ObjectCollection $industry The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByIndustry($industry, $comparison = null)
    {
        if ($industry instanceof \Model\Industry) {
            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_INDUSTRY_ID, $industry->getId(), $comparison);
        } elseif ($industry instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_INDUSTRY_ID, $industry->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByIndustry() only accepts arguments of type \Model\Industry or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Industry relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function joinIndustry($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Industry');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Industry');
        }

        return $this;
    }

    /**
     * Use the Industry relation Industry object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\IndustryQuery A secondary query class using the current class as primary query
     */
    public function useIndustryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinIndustry($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Industry', '\Model\IndustryQuery');
    }

    /**
     * Use the Industry relation Industry object
     *
     * @param callable(\Model\IndustryQuery):\Model\IndustryQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withIndustryQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useIndustryQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Industry table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\IndustryQuery The inner query object of the EXISTS statement
     */
    public function useIndustryExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Industry', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Industry table for a NOT EXISTS query.
     *
     * @see useIndustryExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\IndustryQuery The inner query object of the NOT EXISTS statement
     */
    public function useIndustryNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Industry', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Etape object
     *
     * @param \Model\Etape|ObjectCollection $etape The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function filterByEtape($etape, $comparison = null)
    {
        if ($etape instanceof \Model\Etape) {
            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_ID_ETAPE, $etape->getId(), $comparison);
        } elseif ($etape instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeMasterTableMap::COL_ID_ETAPE, $etape->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtape() only accepts arguments of type \Model\Etape or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etape relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function joinEtape($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etape');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etape');
        }

        return $this;
    }

    /**
     * Use the Etape relation Etape object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtapeQuery A secondary query class using the current class as primary query
     */
    public function useEtapeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtape($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etape', '\Model\EtapeQuery');
    }

    /**
     * Use the Etape relation Etape object
     *
     * @param callable(\Model\EtapeQuery):\Model\EtapeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtapeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtapeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etape table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtapeQuery The inner query object of the EXISTS statement
     */
    public function useEtapeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etape table for a NOT EXISTS query.
     *
     * @see useEtapeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtapeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtapeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etape', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEtudeMaster $etudeMaster Object to remove from the list of results
     *
     * @return $this|ChildEtudeMasterQuery The current query, for fluid interface
     */
    public function prune($etudeMaster = null)
    {
        if ($etudeMaster) {
            $this->addUsingAlias(EtudeMasterTableMap::COL_ID, $etudeMaster->getId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the etude_master table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeMasterTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtudeMasterTableMap::clearInstancePool();
            EtudeMasterTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeMasterTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtudeMasterTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtudeMasterTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtudeMasterTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // EtudeMasterQuery
