<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\Etape as ChildEtape;
use Model\EtapeQuery as ChildEtapeQuery;
use Model\EtudeCheckListType as ChildEtudeCheckListType;
use Model\EtudeCheckListTypeQuery as ChildEtudeCheckListTypeQuery;
use Model\EtudeCheckListValidation as ChildEtudeCheckListValidation;
use Model\EtudeCheckListValidationQuery as ChildEtudeCheckListValidationQuery;
use Model\EtudeChecklist as ChildEtudeChecklist;
use Model\EtudeChecklistQuery as ChildEtudeChecklistQuery;
use Model\Groupe as ChildGroupe;
use Model\GroupeQuery as ChildGroupeQuery;
use Model\Map\EtudeCheckListValidationTableMap;
use Model\Map\EtudeChecklistTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveRecord\ActiveRecordInterface;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\BadMethodCallException;
use Propel\Runtime\Exception\LogicException;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Parser\AbstractParser;

/**
 * Base class that represents a row from the 'ref_etude_checklist' table.
 *
 *
 *
 * @package    propel.generator.src.Model.Base
 */
abstract class EtudeChecklist implements ActiveRecordInterface
{
    /**
     * TableMap class name
     */
    const TABLE_MAP = '\\Model\\Map\\EtudeChecklistTableMap';


    /**
     * attribute to determine if this object has previously been saved.
     * @var boolean
     */
    protected $new = true;

    /**
     * attribute to determine whether this object has been deleted.
     * @var boolean
     */
    protected $deleted = false;

    /**
     * The columns that have been modified in current object.
     * Tracking modified columns allows us to only update modified columns.
     * @var array
     */
    protected $modifiedColumns = array();

    /**
     * The (virtual) columns that are added at runtime
     * The formatters can add supplementary columns based on a resultset
     * @var array
     */
    protected $virtualColumns = array();

    /**
     * The value for the id field.
     *
     * @var        int
     */
    protected $id;

    /**
     * The value for the libelle field.
     *
     * @var        string
     */
    protected $libelle;

    /**
     * The value for the etude_etape_id field.
     *
     * @var        int|null
     */
    protected $etude_etape_id;

    /**
     * The value for the groupe_id field.
     *
     * @var        int|null
     */
    protected $groupe_id;

    /**
     * The value for the etude_checklist_type_id field.
     *
     * @var        int|null
     */
    protected $etude_checklist_type_id;

    /**
     * The value for the sort field.
     *
     * @var        int
     */
    protected $sort;

    /**
     * @var        ChildGroupe
     */
    protected $aGroupe;

    /**
     * @var        ChildEtape
     */
    protected $aEtape;

    /**
     * @var        ChildEtudeCheckListType
     */
    protected $aEtudeCheckListType;

    /**
     * @var        ObjectCollection|ChildEtudeCheckListValidation[] Collection to store aggregation of ChildEtudeCheckListValidation objects.
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeCheckListValidation> Collection to store aggregation of ChildEtudeCheckListValidation objects.
     */
    protected $collEtudeCheckListValidations;
    protected $collEtudeCheckListValidationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     *
     * @var boolean
     */
    protected $alreadyInSave = false;

    // sortable behavior

    /**
     * Queries to be executed in the save transaction
     * @var        array
     */
    protected $sortableQueries = array();

    /**
     * The old scope value.
     * @var        int
     */
    protected $oldScope;

    /**
     * An array of objects scheduled for deletion.
     * @var ObjectCollection|ChildEtudeCheckListValidation[]
     * @phpstan-var ObjectCollection&\Traversable<ChildEtudeCheckListValidation>
     */
    protected $etudeCheckListValidationsScheduledForDeletion = null;

    /**
     * Initializes internal state of Model\Base\EtudeChecklist object.
     */
    public function __construct()
    {
    }

    /**
     * Returns whether the object has been modified.
     *
     * @return boolean True if the object has been modified.
     */
    public function isModified()
    {
        return !!$this->modifiedColumns;
    }

    /**
     * Has specified column been modified?
     *
     * @param  string  $col column fully qualified name (TableMap::TYPE_COLNAME), e.g. Book::AUTHOR_ID
     * @return boolean True if $col has been modified.
     */
    public function isColumnModified($col)
    {
        return $this->modifiedColumns && isset($this->modifiedColumns[$col]);
    }

    /**
     * Get the columns that have been modified in this object.
     * @return array A unique list of the modified column names for this object.
     */
    public function getModifiedColumns()
    {
        return $this->modifiedColumns ? array_keys($this->modifiedColumns) : [];
    }

    /**
     * Returns whether the object has ever been saved.  This will
     * be false, if the object was retrieved from storage or was created
     * and then saved.
     *
     * @return boolean true, if the object has never been persisted.
     */
    public function isNew()
    {
        return $this->new;
    }

    /**
     * Setter for the isNew attribute.  This method will be called
     * by Propel-generated children and objects.
     *
     * @param boolean $b the state of the object.
     */
    public function setNew($b)
    {
        $this->new = (boolean) $b;
    }

    /**
     * Whether this object has been deleted.
     * @return boolean The deleted state of this object.
     */
    public function isDeleted()
    {
        return $this->deleted;
    }

    /**
     * Specify whether this object has been deleted.
     * @param  boolean $b The deleted state of this object.
     * @return void
     */
    public function setDeleted($b)
    {
        $this->deleted = (boolean) $b;
    }

    /**
     * Sets the modified state for the object to be false.
     * @param  string $col If supplied, only the specified column is reset.
     * @return void
     */
    public function resetModified($col = null)
    {
        if (null !== $col) {
            unset($this->modifiedColumns[$col]);
        } else {
            $this->modifiedColumns = array();
        }
    }

    /**
     * Compares this with another <code>EtudeChecklist</code> instance.  If
     * <code>obj</code> is an instance of <code>EtudeChecklist</code>, delegates to
     * <code>equals(EtudeChecklist)</code>.  Otherwise, returns <code>false</code>.
     *
     * @param  mixed   $obj The object to compare to.
     * @return boolean Whether equal to the object specified.
     */
    public function equals($obj)
    {
        if (!$obj instanceof static) {
            return false;
        }

        if ($this === $obj) {
            return true;
        }

        if (null === $this->getPrimaryKey() || null === $obj->getPrimaryKey()) {
            return false;
        }

        return $this->getPrimaryKey() === $obj->getPrimaryKey();
    }

    /**
     * Get the associative array of the virtual columns in this object
     *
     * @return array
     */
    public function getVirtualColumns()
    {
        return $this->virtualColumns;
    }

    /**
     * Checks the existence of a virtual column in this object
     *
     * @param  string  $name The virtual column name
     * @return boolean
     */
    public function hasVirtualColumn($name)
    {
        return array_key_exists($name, $this->virtualColumns);
    }

    /**
     * Get the value of a virtual column in this object
     *
     * @param  string $name The virtual column name
     * @return mixed
     *
     * @throws PropelException
     */
    public function getVirtualColumn($name)
    {
        if (!$this->hasVirtualColumn($name)) {
            throw new PropelException(sprintf('Cannot get value of inexistent virtual column %s.', $name));
        }

        return $this->virtualColumns[$name];
    }

    /**
     * Set the value of a virtual column in this object
     *
     * @param string $name  The virtual column name
     * @param mixed  $value The value to give to the virtual column
     *
     * @return $this The current object, for fluid interface
     */
    public function setVirtualColumn($name, $value)
    {
        $this->virtualColumns[$name] = $value;

        return $this;
    }

    /**
     * Logs a message using Propel::log().
     *
     * @param  string  $msg
     * @param  int     $priority One of the Propel::LOG_* logging levels
     * @return void
     */
    protected function log($msg, $priority = Propel::LOG_INFO)
    {
        Propel::log(get_class($this) . ': ' . $msg, $priority);
    }

    /**
     * Export the current object properties to a string, using a given parser format
     * <code>
     * $book = BookQuery::create()->findPk(9012);
     * echo $book->exportTo('JSON');
     *  => {"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * @param  mixed   $parser                 A AbstractParser instance, or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param  boolean $includeLazyLoadColumns (optional) Whether to include lazy load(ed) columns. Defaults to TRUE.
     * @param  string  $keyType                (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM. Defaults to TableMap::TYPE_PHPNAME.
     * @return string  The exported data
     */
    public function exportTo($parser, $includeLazyLoadColumns = true, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        return $parser->fromArray($this->toArray($keyType, $includeLazyLoadColumns, array(), true));
    }

    /**
     * Clean up internal collections prior to serializing
     * Avoids recursive loops that turn into segmentation faults when serializing
     */
    public function __sleep()
    {
        $this->clearAllReferences();

        $cls = new \ReflectionClass($this);
        $propertyNames = [];
        $serializableProperties = array_diff($cls->getProperties(), $cls->getProperties(\ReflectionProperty::IS_STATIC));

        foreach($serializableProperties as $property) {
            $propertyNames[] = $property->getName();
        }

        return $propertyNames;
    }

    /**
     * Get the [id] column value.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the [libelle] column value.
     *
     * @return string
     */
    public function getLibelle()
    {
        return $this->libelle;
    }

    /**
     * Get the [etude_etape_id] column value.
     *
     * @return int|null
     */
    public function getEtudeEtapeId()
    {
        return $this->etude_etape_id;
    }

    /**
     * Get the [groupe_id] column value.
     *
     * @return int|null
     */
    public function getGroupeId()
    {
        return $this->groupe_id;
    }

    /**
     * Get the [etude_checklist_type_id] column value.
     *
     * @return int|null
     */
    public function getEtudeChecklistTypeId()
    {
        return $this->etude_checklist_type_id;
    }

    /**
     * Get the [sort] column value.
     *
     * @return int
     */
    public function getSort()
    {
        return $this->sort;
    }

    /**
     * Set the value of [id] column.
     *
     * @param int $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->id !== $v) {
            $this->id = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_ID] = true;
        }

        return $this;
    } // setId()

    /**
     * Set the value of [libelle] column.
     *
     * @param string $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setLibelle($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->libelle !== $v) {
            $this->libelle = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_LIBELLE] = true;
        }

        return $this;
    } // setLibelle()

    /**
     * Set the value of [etude_etape_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setEtudeEtapeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->etude_etape_id !== $v) {
            $this->etude_etape_id = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID] = true;
        }

        if ($this->aEtape !== null && $this->aEtape->getId() !== $v) {
            $this->aEtape = null;
        }

        return $this;
    } // setEtudeEtapeId()

    /**
     * Set the value of [groupe_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setGroupeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->groupe_id !== $v) {
            $this->groupe_id = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_GROUPE_ID] = true;
        }

        if ($this->aGroupe !== null && $this->aGroupe->getId() !== $v) {
            $this->aGroupe = null;
        }

        return $this;
    } // setGroupeId()

    /**
     * Set the value of [etude_checklist_type_id] column.
     *
     * @param int|null $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setEtudeChecklistTypeId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->etude_checklist_type_id !== $v) {
            // sortable behavior
            $this->oldScope = $this->etude_checklist_type_id;

            $this->etude_checklist_type_id = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID] = true;
        }

        if ($this->aEtudeCheckListType !== null && $this->aEtudeCheckListType->getId() !== $v) {
            $this->aEtudeCheckListType = null;
        }

        return $this;
    } // setEtudeChecklistTypeId()

    /**
     * Set the value of [sort] column.
     *
     * @param int $v New value
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function setSort($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->sort !== $v) {
            $this->sort = $v;
            $this->modifiedColumns[EtudeChecklistTableMap::COL_SORT] = true;
        }

        return $this;
    } // setSort()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return TRUE
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array   $row       The row returned by DataFetcher->fetch().
     * @param int     $startcol  0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @param string  $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                  One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                            TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false, $indexType = TableMap::TYPE_NUM)
    {
        try {

            $col = $row[TableMap::TYPE_NUM == $indexType ? 0 + $startcol : EtudeChecklistTableMap::translateFieldName('Id', TableMap::TYPE_PHPNAME, $indexType)];
            $this->id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 1 + $startcol : EtudeChecklistTableMap::translateFieldName('Libelle', TableMap::TYPE_PHPNAME, $indexType)];
            $this->libelle = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 2 + $startcol : EtudeChecklistTableMap::translateFieldName('EtudeEtapeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->etude_etape_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 3 + $startcol : EtudeChecklistTableMap::translateFieldName('GroupeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->groupe_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 4 + $startcol : EtudeChecklistTableMap::translateFieldName('EtudeChecklistTypeId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->etude_checklist_type_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 5 + $startcol : EtudeChecklistTableMap::translateFieldName('Sort', TableMap::TYPE_PHPNAME, $indexType)];
            $this->sort = (null !== $col) ? (int) $col : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }

            return $startcol + 6; // 6 = EtudeChecklistTableMap::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException(sprintf('Error populating %s object', '\\Model\\EtudeChecklist'), 0, $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {
        if ($this->aEtape !== null && $this->etude_etape_id !== $this->aEtape->getId()) {
            $this->aEtape = null;
        }
        if ($this->aGroupe !== null && $this->groupe_id !== $this->aGroupe->getId()) {
            $this->aGroupe = null;
        }
        if ($this->aEtudeCheckListType !== null && $this->etude_checklist_type_id !== $this->aEtudeCheckListType->getId()) {
            $this->aEtudeCheckListType = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param      boolean $deep (optional) Whether to also de-associated any related objects.
     * @param      ConnectionInterface $con (optional) The ConnectionInterface connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $dataFetcher = ChildEtudeChecklistQuery::create(null, $this->buildPkeyCriteria())->setFormatter(ModelCriteria::FORMAT_STATEMENT)->find($con);
        $row = $dataFetcher->fetch();
        $dataFetcher->close();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true, $dataFetcher->getIndexType()); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aGroupe = null;
            $this->aEtape = null;
            $this->aEtudeCheckListType = null;
            $this->collEtudeCheckListValidations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param      ConnectionInterface $con
     * @return void
     * @throws PropelException
     * @see EtudeChecklist::setDeleted()
     * @see EtudeChecklist::isDeleted()
     */
    public function delete(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con) {
            $deleteQuery = ChildEtudeChecklistQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            // sortable behavior

            ChildEtudeChecklistQuery::sortableShiftRank(-1, $this->getSort() + 1, null, $this->getScopeValue(), $con);
            EtudeChecklistTableMap::clearInstancePool();

            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $this->setDeleted(true);
            }
        });
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see doSave()
     */
    public function save(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($this->alreadyInSave) {
            return 0;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        return $con->transaction(function () use ($con) {
            $ret = $this->preSave($con);
            $isInsert = $this->isNew();
            // sortable behavior
            $this->processSortableQueries($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
                // sortable behavior
                if (!$this->isColumnModified(EtudeChecklistTableMap::RANK_COL)) {
                    $this->setSort(ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con) + 1);
                }

            } else {
                $ret = $ret && $this->preUpdate($con);
                // sortable behavior
                // if scope has changed and rank was not modified (if yes, assuming superior action)
                // insert object to the end of new scope and cleanup old one
                if (($this->isColumnModified(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID)) && !$this->isColumnModified(EtudeChecklistTableMap::RANK_COL)) { ChildEtudeChecklistQuery::sortableShiftRank(-1, $this->getSort() + 1, null, $this->oldScope, $con);
                    $this->insertAtBottom($con);
                }

            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                EtudeChecklistTableMap::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }

            return $affectedRows;
        });
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see save()
     */
    protected function doSave(ConnectionInterface $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aGroupe !== null) {
                if ($this->aGroupe->isModified() || $this->aGroupe->isNew()) {
                    $affectedRows += $this->aGroupe->save($con);
                }
                $this->setGroupe($this->aGroupe);
            }

            if ($this->aEtape !== null) {
                if ($this->aEtape->isModified() || $this->aEtape->isNew()) {
                    $affectedRows += $this->aEtape->save($con);
                }
                $this->setEtape($this->aEtape);
            }

            if ($this->aEtudeCheckListType !== null) {
                if ($this->aEtudeCheckListType->isModified() || $this->aEtudeCheckListType->isNew()) {
                    $affectedRows += $this->aEtudeCheckListType->save($con);
                }
                $this->setEtudeCheckListType($this->aEtudeCheckListType);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                    $affectedRows += 1;
                } else {
                    $affectedRows += $this->doUpdate($con);
                }
                $this->resetModified();
            }

            if ($this->etudeCheckListValidationsScheduledForDeletion !== null) {
                if (!$this->etudeCheckListValidationsScheduledForDeletion->isEmpty()) {
                    \Model\EtudeCheckListValidationQuery::create()
                        ->filterByPrimaryKeys($this->etudeCheckListValidationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->etudeCheckListValidationsScheduledForDeletion = null;
                }
            }

            if ($this->collEtudeCheckListValidations !== null) {
                foreach ($this->collEtudeCheckListValidations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @throws PropelException
     * @see doSave()
     */
    protected function doInsert(ConnectionInterface $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[EtudeChecklistTableMap::COL_ID] = true;
        if (null !== $this->id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . EtudeChecklistTableMap::COL_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ID)) {
            $modifiedColumns[':p' . $index++]  = '`id`';
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_LIBELLE)) {
            $modifiedColumns[':p' . $index++]  = '`libelle`';
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`etude_etape_id`';
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_GROUPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`groupe_id`';
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID)) {
            $modifiedColumns[':p' . $index++]  = '`etude_checklist_type_id`';
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_SORT)) {
            $modifiedColumns[':p' . $index++]  = '`sort`';
        }

        $sql = sprintf(
            'INSERT INTO `ref_etude_checklist` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`id`':
                        $stmt->bindValue($identifier, $this->id, PDO::PARAM_INT);
                        break;
                    case '`libelle`':
                        $stmt->bindValue($identifier, $this->libelle, PDO::PARAM_STR);
                        break;
                    case '`etude_etape_id`':
                        $stmt->bindValue($identifier, $this->etude_etape_id, PDO::PARAM_INT);
                        break;
                    case '`groupe_id`':
                        $stmt->bindValue($identifier, $this->groupe_id, PDO::PARAM_INT);
                        break;
                    case '`etude_checklist_type_id`':
                        $stmt->bindValue($identifier, $this->etude_checklist_type_id, PDO::PARAM_INT);
                        break;
                    case '`sort`':
                        $stmt->bindValue($identifier, $this->sort, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), 0, $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', 0, $e);
        }
        $this->setId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @return Integer Number of updated rows
     * @see doSave()
     */
    protected function doUpdate(ConnectionInterface $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();

        return $selectCriteria->doUpdate($valuesCriteria, $con);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param      string $name name
     * @param      string $type The type of fieldname the $name is of:
     *                     one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                     TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                     Defaults to TableMap::TYPE_PHPNAME.
     * @return mixed Value of field.
     */
    public function getByName($name, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EtudeChecklistTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param      int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getId();
                break;
            case 1:
                return $this->getLibelle();
                break;
            case 2:
                return $this->getEtudeEtapeId();
                break;
            case 3:
                return $this->getGroupeId();
                break;
            case 4:
                return $this->getEtudeChecklistTypeId();
                break;
            case 5:
                return $this->getSort();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     *                    TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                    Defaults to TableMap::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to TRUE.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = TableMap::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {

        if (isset($alreadyDumpedObjects['EtudeChecklist'][$this->hashCode()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['EtudeChecklist'][$this->hashCode()] = true;
        $keys = EtudeChecklistTableMap::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getId(),
            $keys[1] => $this->getLibelle(),
            $keys[2] => $this->getEtudeEtapeId(),
            $keys[3] => $this->getGroupeId(),
            $keys[4] => $this->getEtudeChecklistTypeId(),
            $keys[5] => $this->getSort(),
        );
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }

        if ($includeForeignObjects) {
            if (null !== $this->aGroupe) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'groupe';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'groupe';
                        break;
                    default:
                        $key = 'Groupe';
                }

                $result[$key] = $this->aGroupe->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtape) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etape';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_etape';
                        break;
                    default:
                        $key = 'Etape';
                }

                $result[$key] = $this->aEtape->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aEtudeCheckListType) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeCheckListType';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'ref_etude_checklist_type';
                        break;
                    default:
                        $key = 'EtudeCheckListType';
                }

                $result[$key] = $this->aEtudeCheckListType->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->collEtudeCheckListValidations) {

                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'etudeCheckListValidations';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'etude_checklist_validations';
                        break;
                    default:
                        $key = 'EtudeCheckListValidations';
                }

                $result[$key] = $this->collEtudeCheckListValidations->toArray(null, false, $keyType, $includeLazyLoadColumns, $alreadyDumpedObjects);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param  string $name
     * @param  mixed  $value field value
     * @param  string $type The type of fieldname the $name is of:
     *                one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                Defaults to TableMap::TYPE_PHPNAME.
     * @return $this|\Model\EtudeChecklist
     */
    public function setByName($name, $value, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = EtudeChecklistTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);

        return $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param  int $pos position in xml schema
     * @param  mixed $value field value
     * @return $this|\Model\EtudeChecklist
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setId($value);
                break;
            case 1:
                $this->setLibelle($value);
                break;
            case 2:
                $this->setEtudeEtapeId($value);
                break;
            case 3:
                $this->setGroupeId($value);
                break;
            case 4:
                $this->setEtudeChecklistTypeId($value);
                break;
            case 5:
                $this->setSort($value);
                break;
        } // switch()

        return $this;
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param      array  $arr     An array to populate the object from.
     * @param      string $keyType The type of keys the array uses.
     * @return     $this|\Model\EtudeChecklist
     */
    public function fromArray($arr, $keyType = TableMap::TYPE_PHPNAME)
    {
        $keys = EtudeChecklistTableMap::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) {
            $this->setId($arr[$keys[0]]);
        }
        if (array_key_exists($keys[1], $arr)) {
            $this->setLibelle($arr[$keys[1]]);
        }
        if (array_key_exists($keys[2], $arr)) {
            $this->setEtudeEtapeId($arr[$keys[2]]);
        }
        if (array_key_exists($keys[3], $arr)) {
            $this->setGroupeId($arr[$keys[3]]);
        }
        if (array_key_exists($keys[4], $arr)) {
            $this->setEtudeChecklistTypeId($arr[$keys[4]]);
        }
        if (array_key_exists($keys[5], $arr)) {
            $this->setSort($arr[$keys[5]]);
        }

        return $this;
    }

     /**
     * Populate the current object from a string, using a given parser format
     * <code>
     * $book = new Book();
     * $book->importFrom('JSON', '{"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param mixed $parser A AbstractParser instance,
     *                       or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param string $data The source data to import from
     * @param string $keyType The type of keys the array uses.
     *
     * @return $this|\Model\EtudeChecklist The current object, for fluid interface
     */
    public function importFrom($parser, $data, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        $this->fromArray($parser->toArray($data), $keyType);

        return $this;
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(EtudeChecklistTableMap::DATABASE_NAME);

        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ID)) {
            $criteria->add(EtudeChecklistTableMap::COL_ID, $this->id);
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_LIBELLE)) {
            $criteria->add(EtudeChecklistTableMap::COL_LIBELLE, $this->libelle);
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID)) {
            $criteria->add(EtudeChecklistTableMap::COL_ETUDE_ETAPE_ID, $this->etude_etape_id);
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_GROUPE_ID)) {
            $criteria->add(EtudeChecklistTableMap::COL_GROUPE_ID, $this->groupe_id);
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID)) {
            $criteria->add(EtudeChecklistTableMap::COL_ETUDE_CHECKLIST_TYPE_ID, $this->etude_checklist_type_id);
        }
        if ($this->isColumnModified(EtudeChecklistTableMap::COL_SORT)) {
            $criteria->add(EtudeChecklistTableMap::COL_SORT, $this->sort);
        }

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @throws LogicException if no primary key is defined
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = ChildEtudeChecklistQuery::create();
        $criteria->add(EtudeChecklistTableMap::COL_ID, $this->id);

        return $criteria;
    }

    /**
     * If the primary key is not null, return the hashcode of the
     * primary key. Otherwise, return the hash code of the object.
     *
     * @return int Hashcode
     */
    public function hashCode()
    {
        $validPk = null !== $this->getId();

        $validPrimaryKeyFKs = 0;
        $primaryKeyFKs = [];

        if ($validPk) {
            return crc32(json_encode($this->getPrimaryKey(), JSON_UNESCAPED_UNICODE));
        } elseif ($validPrimaryKeyFKs) {
            return crc32(json_encode($primaryKeyFKs, JSON_UNESCAPED_UNICODE));
        }

        return spl_object_hash($this);
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getId();
    }

    /**
     * Generic method to set the primary key (id column).
     *
     * @param       int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {
        return null === $this->getId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param      object $copyObj An object of \Model\EtudeChecklist (or compatible) type.
     * @param      boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param      boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setLibelle($this->getLibelle());
        $copyObj->setEtudeEtapeId($this->getEtudeEtapeId());
        $copyObj->setGroupeId($this->getGroupeId());
        $copyObj->setEtudeChecklistTypeId($this->getEtudeChecklistTypeId());
        $copyObj->setSort($this->getSort());

        if ($deepCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);

            foreach ($this->getEtudeCheckListValidations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addEtudeCheckListValidation($relObj->copy($deepCopy));
                }
            }

        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param  boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return \Model\EtudeChecklist Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Declares an association between this object and a ChildGroupe object.
     *
     * @param  ChildGroupe|null $v
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     * @throws PropelException
     */
    public function setGroupe(ChildGroupe $v = null)
    {
        if ($v === null) {
            $this->setGroupeId(NULL);
        } else {
            $this->setGroupeId($v->getId());
        }

        $this->aGroupe = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildGroupe object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeChecklist($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildGroupe object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildGroupe|null The associated ChildGroupe object.
     * @throws PropelException
     */
    public function getGroupe(ConnectionInterface $con = null)
    {
        if ($this->aGroupe === null && ($this->groupe_id != 0)) {
            $this->aGroupe = ChildGroupeQuery::create()->findPk($this->groupe_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aGroupe->addEtudeChecklists($this);
             */
        }

        return $this->aGroupe;
    }

    /**
     * Declares an association between this object and a ChildEtape object.
     *
     * @param  ChildEtape|null $v
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtape(ChildEtape $v = null)
    {
        if ($v === null) {
            $this->setEtudeEtapeId(NULL);
        } else {
            $this->setEtudeEtapeId($v->getId());
        }

        $this->aEtape = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildEtape object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeChecklist($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildEtape object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildEtape|null The associated ChildEtape object.
     * @throws PropelException
     */
    public function getEtape(ConnectionInterface $con = null)
    {
        if ($this->aEtape === null && ($this->etude_etape_id != 0)) {
            $this->aEtape = ChildEtapeQuery::create()->findPk($this->etude_etape_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtape->addEtudeChecklists($this);
             */
        }

        return $this->aEtape;
    }

    /**
     * Declares an association between this object and a ChildEtudeCheckListType object.
     *
     * @param  ChildEtudeCheckListType|null $v
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     * @throws PropelException
     */
    public function setEtudeCheckListType(ChildEtudeCheckListType $v = null)
    {
        if ($v === null) {
            $this->setEtudeChecklistTypeId(NULL);
        } else {
            $this->setEtudeChecklistTypeId($v->getId());
        }

        $this->aEtudeCheckListType = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildEtudeCheckListType object, it will not be re-added.
        if ($v !== null) {
            $v->addEtudeChecklist($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildEtudeCheckListType object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildEtudeCheckListType|null The associated ChildEtudeCheckListType object.
     * @throws PropelException
     */
    public function getEtudeCheckListType(ConnectionInterface $con = null)
    {
        if ($this->aEtudeCheckListType === null && ($this->etude_checklist_type_id != 0)) {
            $this->aEtudeCheckListType = ChildEtudeCheckListTypeQuery::create()->findPk($this->etude_checklist_type_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aEtudeCheckListType->addEtudeChecklists($this);
             */
        }

        return $this->aEtudeCheckListType;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param      string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('EtudeCheckListValidation' === $relationName) {
            $this->initEtudeCheckListValidations();
            return;
        }
    }

    /**
     * Clears out the collEtudeCheckListValidations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return void
     * @see        addEtudeCheckListValidations()
     */
    public function clearEtudeCheckListValidations()
    {
        $this->collEtudeCheckListValidations = null; // important to set this to NULL since that means it is uninitialized
    }

    /**
     * Reset is the collEtudeCheckListValidations collection loaded partially.
     */
    public function resetPartialEtudeCheckListValidations($v = true)
    {
        $this->collEtudeCheckListValidationsPartial = $v;
    }

    /**
     * Initializes the collEtudeCheckListValidations collection.
     *
     * By default this just sets the collEtudeCheckListValidations collection to an empty array (like clearcollEtudeCheckListValidations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param      boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initEtudeCheckListValidations($overrideExisting = true)
    {
        if (null !== $this->collEtudeCheckListValidations && !$overrideExisting) {
            return;
        }

        $collectionClassName = EtudeCheckListValidationTableMap::getTableMap()->getCollectionClassName();

        $this->collEtudeCheckListValidations = new $collectionClassName;
        $this->collEtudeCheckListValidations->setModel('\Model\EtudeCheckListValidation');
    }

    /**
     * Gets an array of ChildEtudeCheckListValidation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this ChildEtudeChecklist is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @return ObjectCollection|ChildEtudeCheckListValidation[] List of ChildEtudeCheckListValidation objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeCheckListValidation> List of ChildEtudeCheckListValidation objects
     * @throws PropelException
     */
    public function getEtudeCheckListValidations(Criteria $criteria = null, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeCheckListValidationsPartial && !$this->isNew();
        if (null === $this->collEtudeCheckListValidations || null !== $criteria || $partial) {
            if ($this->isNew()) {
                // return empty collection
                if (null === $this->collEtudeCheckListValidations) {
                    $this->initEtudeCheckListValidations();
                } else {
                    $collectionClassName = EtudeCheckListValidationTableMap::getTableMap()->getCollectionClassName();

                    $collEtudeCheckListValidations = new $collectionClassName;
                    $collEtudeCheckListValidations->setModel('\Model\EtudeCheckListValidation');

                    return $collEtudeCheckListValidations;
                }
            } else {
                $collEtudeCheckListValidations = ChildEtudeCheckListValidationQuery::create(null, $criteria)
                    ->filterByEtudeCheckList($this)
                    ->find($con);

                if (null !== $criteria) {
                    if (false !== $this->collEtudeCheckListValidationsPartial && count($collEtudeCheckListValidations)) {
                        $this->initEtudeCheckListValidations(false);

                        foreach ($collEtudeCheckListValidations as $obj) {
                            if (false == $this->collEtudeCheckListValidations->contains($obj)) {
                                $this->collEtudeCheckListValidations->append($obj);
                            }
                        }

                        $this->collEtudeCheckListValidationsPartial = true;
                    }

                    return $collEtudeCheckListValidations;
                }

                if ($partial && $this->collEtudeCheckListValidations) {
                    foreach ($this->collEtudeCheckListValidations as $obj) {
                        if ($obj->isNew()) {
                            $collEtudeCheckListValidations[] = $obj;
                        }
                    }
                }

                $this->collEtudeCheckListValidations = $collEtudeCheckListValidations;
                $this->collEtudeCheckListValidationsPartial = false;
            }
        }

        return $this->collEtudeCheckListValidations;
    }

    /**
     * Sets a collection of ChildEtudeCheckListValidation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param      Collection $etudeCheckListValidations A Propel collection.
     * @param      ConnectionInterface $con Optional connection object
     * @return $this|ChildEtudeChecklist The current object (for fluent API support)
     */
    public function setEtudeCheckListValidations(Collection $etudeCheckListValidations, ConnectionInterface $con = null)
    {
        /** @var ChildEtudeCheckListValidation[] $etudeCheckListValidationsToDelete */
        $etudeCheckListValidationsToDelete = $this->getEtudeCheckListValidations(new Criteria(), $con)->diff($etudeCheckListValidations);


        $this->etudeCheckListValidationsScheduledForDeletion = $etudeCheckListValidationsToDelete;

        foreach ($etudeCheckListValidationsToDelete as $etudeCheckListValidationRemoved) {
            $etudeCheckListValidationRemoved->setEtudeCheckList(null);
        }

        $this->collEtudeCheckListValidations = null;
        foreach ($etudeCheckListValidations as $etudeCheckListValidation) {
            $this->addEtudeCheckListValidation($etudeCheckListValidation);
        }

        $this->collEtudeCheckListValidations = $etudeCheckListValidations;
        $this->collEtudeCheckListValidationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related EtudeCheckListValidation objects.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct
     * @param      ConnectionInterface $con
     * @return int             Count of related EtudeCheckListValidation objects.
     * @throws PropelException
     */
    public function countEtudeCheckListValidations(Criteria $criteria = null, $distinct = false, ConnectionInterface $con = null)
    {
        $partial = $this->collEtudeCheckListValidationsPartial && !$this->isNew();
        if (null === $this->collEtudeCheckListValidations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collEtudeCheckListValidations) {
                return 0;
            }

            if ($partial && !$criteria) {
                return count($this->getEtudeCheckListValidations());
            }

            $query = ChildEtudeCheckListValidationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByEtudeCheckList($this)
                ->count($con);
        }

        return count($this->collEtudeCheckListValidations);
    }

    /**
     * Method called to associate a ChildEtudeCheckListValidation object to this object
     * through the ChildEtudeCheckListValidation foreign key attribute.
     *
     * @param  ChildEtudeCheckListValidation $l ChildEtudeCheckListValidation
     * @return $this|\Model\EtudeChecklist The current object (for fluent API support)
     */
    public function addEtudeCheckListValidation(ChildEtudeCheckListValidation $l)
    {
        if ($this->collEtudeCheckListValidations === null) {
            $this->initEtudeCheckListValidations();
            $this->collEtudeCheckListValidationsPartial = true;
        }

        if (!$this->collEtudeCheckListValidations->contains($l)) {
            $this->doAddEtudeCheckListValidation($l);

            if ($this->etudeCheckListValidationsScheduledForDeletion and $this->etudeCheckListValidationsScheduledForDeletion->contains($l)) {
                $this->etudeCheckListValidationsScheduledForDeletion->remove($this->etudeCheckListValidationsScheduledForDeletion->search($l));
            }
        }

        return $this;
    }

    /**
     * @param ChildEtudeCheckListValidation $etudeCheckListValidation The ChildEtudeCheckListValidation object to add.
     */
    protected function doAddEtudeCheckListValidation(ChildEtudeCheckListValidation $etudeCheckListValidation)
    {
        $this->collEtudeCheckListValidations[]= $etudeCheckListValidation;
        $etudeCheckListValidation->setEtudeCheckList($this);
    }

    /**
     * @param  ChildEtudeCheckListValidation $etudeCheckListValidation The ChildEtudeCheckListValidation object to remove.
     * @return $this|ChildEtudeChecklist The current object (for fluent API support)
     */
    public function removeEtudeCheckListValidation(ChildEtudeCheckListValidation $etudeCheckListValidation)
    {
        if ($this->getEtudeCheckListValidations()->contains($etudeCheckListValidation)) {
            $pos = $this->collEtudeCheckListValidations->search($etudeCheckListValidation);
            $this->collEtudeCheckListValidations->remove($pos);
            if (null === $this->etudeCheckListValidationsScheduledForDeletion) {
                $this->etudeCheckListValidationsScheduledForDeletion = clone $this->collEtudeCheckListValidations;
                $this->etudeCheckListValidationsScheduledForDeletion->clear();
            }
            $this->etudeCheckListValidationsScheduledForDeletion[]= clone $etudeCheckListValidation;
            $etudeCheckListValidation->setEtudeCheckList(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this EtudeChecklist is new, it will return
     * an empty collection; or if this EtudeChecklist has previously
     * been saved, it will retrieve related EtudeCheckListValidations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in EtudeChecklist.
     *
     * @param      Criteria $criteria optional Criteria object to narrow the query
     * @param      ConnectionInterface $con optional connection object
     * @param      string $joinBehavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return ObjectCollection|ChildEtudeCheckListValidation[] List of ChildEtudeCheckListValidation objects
     * @phpstan-return ObjectCollection&\Traversable<ChildEtudeCheckListValidation}> List of ChildEtudeCheckListValidation objects
     */
    public function getEtudeCheckListValidationsJoinEtude(Criteria $criteria = null, ConnectionInterface $con = null, $joinBehavior = Criteria::LEFT_JOIN)
    {
        $query = ChildEtudeCheckListValidationQuery::create(null, $criteria);
        $query->joinWith('Etude', $joinBehavior);

        return $this->getEtudeCheckListValidations($query, $con);
    }

    /**
     * Clears the current object, sets all attributes to their default values and removes
     * outgoing references as well as back-references (from other objects to this one. Results probably in a database
     * change of those foreign objects when you call `save` there).
     */
    public function clear()
    {
        if (null !== $this->aGroupe) {
            $this->aGroupe->removeEtudeChecklist($this);
        }
        if (null !== $this->aEtape) {
            $this->aEtape->removeEtudeChecklist($this);
        }
        if (null !== $this->aEtudeCheckListType) {
            $this->aEtudeCheckListType->removeEtudeChecklist($this);
        }
        $this->id = null;
        $this->libelle = null;
        $this->etude_etape_id = null;
        $this->groupe_id = null;
        $this->etude_checklist_type_id = null;
        $this->sort = null;
        $this->alreadyInSave = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references and back-references to other model objects or collections of model objects.
     *
     * This method is used to reset all php object references (not the actual reference in the database).
     * Necessary for object serialisation.
     *
     * @param      boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep) {
            if ($this->collEtudeCheckListValidations) {
                foreach ($this->collEtudeCheckListValidations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
        } // if ($deep)

        $this->collEtudeCheckListValidations = null;
        $this->aGroupe = null;
        $this->aEtape = null;
        $this->aEtudeCheckListType = null;
    }

    /**
     * Return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(EtudeChecklistTableMap::DEFAULT_STRING_FORMAT);
    }

    // sortable behavior

    /**
     * Wrap the getter for rank value
     *
     * @return    int
     */
    public function getRank()
    {
        return $this->sort;
    }

    /**
     * Wrap the setter for rank value
     *
     * @param     int
     * @return    $this|ChildEtudeChecklist
     */
    public function setRank($v)
    {
        return $this->setSort($v);
    }

    /**
     * Wrap the getter for scope value
     *
     * @param boolean $returnNulls If true and all scope values are null, this will return null instead of a array full with nulls
     *
     * @return    mixed A array or a native type
     */
    public function getScopeValue($returnNulls = true)
    {


        return $this->getEtudeChecklistTypeId();

    }

    /**
     * Wrap the setter for scope value
     *
     * @param     mixed A array or a native type
     * @return    $this|ChildEtudeChecklist
     */
    public function setScopeValue($v)
    {


        return $this->setEtudeChecklistTypeId($v);

    }

    /**
     * Check if the object is first in the list, i.e. if it has 1 for rank
     *
     * @return    boolean
     */
    public function isFirst()
    {
        return $this->getSort() == 1;
    }

    /**
     * Check if the object is last in the list, i.e. if its rank is the highest rank
     *
     * @param     ConnectionInterface  $con      optional connection
     *
     * @return    boolean
     */
    public function isLast(ConnectionInterface $con = null)
    {
        return $this->getSort() == ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con);
    }

    /**
     * Get the next item in the list, i.e. the one for which rank is immediately higher
     *
     * @param     ConnectionInterface  $con      optional connection
     *
     * @return    ChildEtudeChecklist
     */
    public function getNext(ConnectionInterface $con = null)
    {

        $query = ChildEtudeChecklistQuery::create();

        $scope = $this->getScopeValue();

        $query->filterByRank($this->getSort() + 1, $scope);


        return $query->findOne($con);
    }

    /**
     * Get the previous item in the list, i.e. the one for which rank is immediately lower
     *
     * @param     ConnectionInterface  $con      optional connection
     *
     * @return    ChildEtudeChecklist
     */
    public function getPrevious(ConnectionInterface $con = null)
    {

        $query = ChildEtudeChecklistQuery::create();

        $scope = $this->getScopeValue();

        $query->filterByRank($this->getSort() - 1, $scope);


        return $query->findOne($con);
    }

    /**
     * Insert at specified rank
     * The modifications are not persisted until the object is saved.
     *
     * @param     integer    $rank rank value
     * @param     ConnectionInterface  $con      optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     *
     * @throws    PropelException
     */
    public function insertAtRank($rank, ConnectionInterface $con = null)
    {
        $maxRank = ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con);
        if ($rank < 1 || $rank > $maxRank + 1) {
            throw new PropelException('Invalid rank ' . $rank);
        }
        // move the object in the list, at the given rank
        $this->setSort($rank);
        if ($rank != $maxRank + 1) {
            // Keep the list modification query for the save() transaction
            $this->sortableQueries []= array(
                'callable'  => array('\Model\EtudeChecklistQuery', 'sortableShiftRank'),
                'arguments' => array(1, $rank, null, $this->getScopeValue())
            );
        }

        return $this;
    }

    /**
     * Insert in the last rank
     * The modifications are not persisted until the object is saved.
     *
     * @param ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     *
     * @throws    PropelException
     */
    public function insertAtBottom(ConnectionInterface $con = null)
    {
        $this->setSort(ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con) + 1);

        return $this;
    }

    /**
     * Insert in the first rank
     * The modifications are not persisted until the object is saved.
     *
     * @return    $this|ChildEtudeChecklist the current object
     */
    public function insertAtTop()
    {
        return $this->insertAtRank(1);
    }

    /**
     * Move the object to a new rank, and shifts the rank
     * Of the objects inbetween the old and new rank accordingly
     *
     * @param     integer   $newRank rank value
     * @param     ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     *
     * @throws    PropelException
     */
    public function moveToRank($newRank, ConnectionInterface $con = null)
    {
        if ($this->isNew()) {
            throw new PropelException('New objects cannot be moved. Please use insertAtRank() instead');
        }
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        if ($newRank < 1 || $newRank > ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con)) {
            throw new PropelException('Invalid rank ' . $newRank);
        }

        $oldRank = $this->getSort();
        if ($oldRank == $newRank) {
            return $this;
        }

        $con->transaction(function () use ($con, $oldRank, $newRank) {
            // shift the objects between the old and the new rank
            $delta = ($oldRank < $newRank) ? -1 : 1;
            ChildEtudeChecklistQuery::sortableShiftRank($delta, min($oldRank, $newRank), max($oldRank, $newRank), $this->getScopeValue(), $con);

            // move the object to its new rank
            $this->setSort($newRank);
            $this->save($con);
        });

        return $this;
    }

    /**
     * Exchange the rank of the object with the one passed as argument, and saves both objects
     *
     * @param     ChildEtudeChecklist $object
     * @param     ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     *
     * @throws Exception if the database cannot execute the two updates
     */
    public function swapWith($object, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        $con->transaction(function () use ($con, $object) {
            $oldScope = $this->getScopeValue();
            $newScope = $object->getScopeValue();
            if ($oldScope != $newScope) {
                $this->setScopeValue($newScope);
                $object->setScopeValue($oldScope);
            }
            $oldRank = $this->getSort();
            $newRank = $object->getSort();

            $this->setSort($newRank);
            $object->setSort($oldRank);

            $this->save($con);
            $object->save($con);
        });

        return $this;
    }

    /**
     * Move the object higher in the list, i.e. exchanges its rank with the one of the previous object
     *
     * @param     ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     */
    public function moveUp(ConnectionInterface $con = null)
    {
        if ($this->isFirst()) {
            return $this;
        }
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        $con->transaction(function () use ($con) {
            $prev = $this->getPrevious($con);
            $this->swapWith($prev, $con);
        });

        return $this;
    }

    /**
     * Move the object higher in the list, i.e. exchanges its rank with the one of the next object
     *
     * @param     ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     */
    public function moveDown(ConnectionInterface $con = null)
    {
        if ($this->isLast($con)) {
            return $this;
        }
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }
        $con->transaction(function () use ($con) {
            $next = $this->getNext($con);
            $this->swapWith($next, $con);
        });

        return $this;
    }

    /**
     * Move the object to the top of the list
     *
     * @param     ConnectionInterface $con optional connection
     *
     * @return    $this|ChildEtudeChecklist the current object
     */
    public function moveToTop(ConnectionInterface $con = null)
    {
        if ($this->isFirst()) {
            return $this;
        }

        return $this->moveToRank(1, $con);
    }

    /**
     * Move the object to the bottom of the list
     *
     * @param     ConnectionInterface $con optional connection
     *
     * @return integer the old object's rank
     */
    public function moveToBottom(ConnectionInterface $con = null)
    {
        if ($this->isLast($con)) {
            return false;
        }
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeChecklistTableMap::DATABASE_NAME);
        }

        return $con->transaction(function () use ($con) {
            $bottom = ChildEtudeChecklistQuery::create()->getMaxRankArray($this->getScopeValue(), $con);

            return $this->moveToRank($bottom, $con);
        });
    }

    /**
     * Removes the current object from the list (moves it to the null scope).
     * The modifications are not persisted until the object is saved.
     *
     * @return    $this|ChildEtudeChecklist the current object
     */
    public function removeFromList()
    {
        // check if object is already removed
        if ($this->getScopeValue() === null) {
            throw new PropelException('Object is already removed (has null scope)');
        }

        // move the object to the end of null scope
        $this->setScopeValue(null);

        return $this;
    }

    /**
     * Execute queries that were saved to be run inside the save transaction
     */
    protected function processSortableQueries($con)
    {
        foreach ($this->sortableQueries as ['callable' => $callable, 'arguments' => $arguments]) {
            $arguments[] = $con;
            $callable(...$arguments);
        }
        $this->sortableQueries = array();
    }

    /**
     * Code to be run before persisting the object
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preSave(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after persisting the object
     * @param ConnectionInterface $con
     */
    public function postSave(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before inserting to database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preInsert(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after inserting to database
     * @param ConnectionInterface $con
     */
    public function postInsert(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before updating the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preUpdate(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after updating the object in database
     * @param ConnectionInterface $con
     */
    public function postUpdate(ConnectionInterface $con = null)
    {
            }

    /**
     * Code to be run before deleting the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preDelete(ConnectionInterface $con = null)
    {
                return true;
    }

    /**
     * Code to be run after deleting the object in database
     * @param ConnectionInterface $con
     */
    public function postDelete(ConnectionInterface $con = null)
    {
            }


    /**
     * Derived method to catches calls to undefined methods.
     *
     * Provides magic import/export method support (fromXML()/toXML(), fromYAML()/toYAML(), etc.).
     * Allows to define default __call() behavior if you overwrite __call()
     *
     * @param string $name
     * @param mixed  $params
     *
     * @return array|string
     */
    public function __call($name, $params)
    {
        if (0 === strpos($name, 'get')) {
            $virtualColumn = substr($name, 3);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }

            $virtualColumn = lcfirst($virtualColumn);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }
        }

        if (0 === strpos($name, 'from')) {
            $format = substr($name, 4);
            $inputData = $params[0];
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->importFrom($format, $inputData, $keyType);
        }

        if (0 === strpos($name, 'to')) {
            $format = substr($name, 2);
            $includeLazyLoadColumns = $params[0] ?? true;
            $keyType = $params[1] ?? TableMap::TYPE_PHPNAME;

            return $this->exportTo($format, $includeLazyLoadColumns, $keyType);
        }

        throw new BadMethodCallException(sprintf('Call to undefined method: %s.', $name));
    }

}
