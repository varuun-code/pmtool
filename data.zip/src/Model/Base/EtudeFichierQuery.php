<?php

namespace Model\Base;

use \Exception;
use \PDO;
use Model\EtudeFichier as ChildEtudeFichier;
use Model\EtudeFichierQuery as ChildEtudeFichierQuery;
use Model\Map\EtudeFichierTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'etude_fichier' table.
 *
 *
 *
 * @method     ChildEtudeFichierQuery orderByEtudeId($order = Criteria::ASC) Order by the etude_id column
 * @method     ChildEtudeFichierQuery orderByFichierId($order = Criteria::ASC) Order by the fichier_id column
 *
 * @method     ChildEtudeFichierQuery groupByEtudeId() Group by the etude_id column
 * @method     ChildEtudeFichierQuery groupByFichierId() Group by the fichier_id column
 *
 * @method     ChildEtudeFichierQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildEtudeFichierQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildEtudeFichierQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildEtudeFichierQuery leftJoinWith($relation) Adds a LEFT JOIN clause and with to the query
 * @method     ChildEtudeFichierQuery rightJoinWith($relation) Adds a RIGHT JOIN clause and with to the query
 * @method     ChildEtudeFichierQuery innerJoinWith($relation) Adds a INNER JOIN clause and with to the query
 *
 * @method     ChildEtudeFichierQuery leftJoinEtude($relationAlias = null) Adds a LEFT JOIN clause to the query using the Etude relation
 * @method     ChildEtudeFichierQuery rightJoinEtude($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Etude relation
 * @method     ChildEtudeFichierQuery innerJoinEtude($relationAlias = null) Adds a INNER JOIN clause to the query using the Etude relation
 *
 * @method     ChildEtudeFichierQuery joinWithEtude($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Etude relation
 *
 * @method     ChildEtudeFichierQuery leftJoinWithEtude() Adds a LEFT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtudeFichierQuery rightJoinWithEtude() Adds a RIGHT JOIN clause and with to the query using the Etude relation
 * @method     ChildEtudeFichierQuery innerJoinWithEtude() Adds a INNER JOIN clause and with to the query using the Etude relation
 *
 * @method     ChildEtudeFichierQuery leftJoinFichier($relationAlias = null) Adds a LEFT JOIN clause to the query using the Fichier relation
 * @method     ChildEtudeFichierQuery rightJoinFichier($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Fichier relation
 * @method     ChildEtudeFichierQuery innerJoinFichier($relationAlias = null) Adds a INNER JOIN clause to the query using the Fichier relation
 *
 * @method     ChildEtudeFichierQuery joinWithFichier($joinType = Criteria::INNER_JOIN) Adds a join clause and with to the query using the Fichier relation
 *
 * @method     ChildEtudeFichierQuery leftJoinWithFichier() Adds a LEFT JOIN clause and with to the query using the Fichier relation
 * @method     ChildEtudeFichierQuery rightJoinWithFichier() Adds a RIGHT JOIN clause and with to the query using the Fichier relation
 * @method     ChildEtudeFichierQuery innerJoinWithFichier() Adds a INNER JOIN clause and with to the query using the Fichier relation
 *
 * @method     \Model\EtudeQuery|\Model\FichierQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildEtudeFichier|null findOne(ConnectionInterface $con = null) Return the first ChildEtudeFichier matching the query
 * @method     ChildEtudeFichier findOneOrCreate(ConnectionInterface $con = null) Return the first ChildEtudeFichier matching the query, or a new ChildEtudeFichier object populated from the query conditions when no match is found
 *
 * @method     ChildEtudeFichier|null findOneByEtudeId(int $etude_id) Return the first ChildEtudeFichier filtered by the etude_id column
 * @method     ChildEtudeFichier|null findOneByFichierId(int $fichier_id) Return the first ChildEtudeFichier filtered by the fichier_id column *

 * @method     ChildEtudeFichier requirePk($key, ConnectionInterface $con = null) Return the ChildEtudeFichier by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeFichier requireOne(ConnectionInterface $con = null) Return the first ChildEtudeFichier matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeFichier requireOneByEtudeId(int $etude_id) Return the first ChildEtudeFichier filtered by the etude_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildEtudeFichier requireOneByFichierId(int $fichier_id) Return the first ChildEtudeFichier filtered by the fichier_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildEtudeFichier[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildEtudeFichier objects based on current ModelCriteria
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeFichier> find(ConnectionInterface $con = null) Return ChildEtudeFichier objects based on current ModelCriteria
 * @method     ChildEtudeFichier[]|ObjectCollection findByEtudeId(int $etude_id) Return ChildEtudeFichier objects filtered by the etude_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeFichier> findByEtudeId(int $etude_id) Return ChildEtudeFichier objects filtered by the etude_id column
 * @method     ChildEtudeFichier[]|ObjectCollection findByFichierId(int $fichier_id) Return ChildEtudeFichier objects filtered by the fichier_id column
 * @psalm-method ObjectCollection&\Traversable<ChildEtudeFichier> findByFichierId(int $fichier_id) Return ChildEtudeFichier objects filtered by the fichier_id column
 * @method     ChildEtudeFichier[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 * @psalm-method \Propel\Runtime\Util\PropelModelPager&\Traversable<ChildEtudeFichier> paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class EtudeFichierQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Model\Base\EtudeFichierQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'default', $modelName = '\\Model\\EtudeFichier', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildEtudeFichierQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildEtudeFichierQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildEtudeFichierQuery) {
            return $criteria;
        }
        $query = new ChildEtudeFichierQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$etude_id, $fichier_id] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildEtudeFichier|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(EtudeFichierTableMap::DATABASE_NAME);
        }

        $this->basePreSelect($con);

        if (
            $this->formatter || $this->modelAlias || $this->with || $this->select
            || $this->selectColumns || $this->asColumns || $this->selectModifiers
            || $this->map || $this->having || $this->joins
        ) {
            return $this->findPkComplex($key, $con);
        }

        if ((null !== ($obj = EtudeFichierTableMap::getInstanceFromPool(serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]))))) {
            // the object is already in the instance pool
            return $obj;
        }

        return $this->findPkSimple($key, $con);
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeFichier A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT `etude_id`, `fichier_id` FROM `etude_fichier` WHERE `etude_id` = :p0 AND `fichier_id` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_INT);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildEtudeFichier $obj */
            $obj = new ChildEtudeFichier();
            $obj->hydrate($row);
            EtudeFichierTableMap::addInstanceToPool($obj, serialize([(null === $key[0] || is_scalar($key[0]) || is_callable([$key[0], '__toString']) ? (string) $key[0] : $key[0]), (null === $key[1] || is_scalar($key[1]) || is_callable([$key[1], '__toString']) ? (string) $key[1] : $key[1])]));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildEtudeFichier|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(EtudeFichierTableMap::COL_ETUDE_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(EtudeFichierTableMap::COL_FICHIER_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the etude_id column
     *
     * Example usage:
     * <code>
     * $query->filterByEtudeId(1234); // WHERE etude_id = 1234
     * $query->filterByEtudeId(array(12, 34)); // WHERE etude_id IN (12, 34)
     * $query->filterByEtudeId(array('min' => 12)); // WHERE etude_id > 12
     * </code>
     *
     * @see       filterByEtude()
     *
     * @param     mixed $etudeId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByEtudeId($etudeId = null, $comparison = null)
    {
        if (is_array($etudeId)) {
            $useMinMax = false;
            if (isset($etudeId['min'])) {
                $this->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $etudeId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etudeId['max'])) {
                $this->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $etudeId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $etudeId, $comparison);
    }

    /**
     * Filter the query on the fichier_id column
     *
     * Example usage:
     * <code>
     * $query->filterByFichierId(1234); // WHERE fichier_id = 1234
     * $query->filterByFichierId(array(12, 34)); // WHERE fichier_id IN (12, 34)
     * $query->filterByFichierId(array('min' => 12)); // WHERE fichier_id > 12
     * </code>
     *
     * @see       filterByFichier()
     *
     * @param     mixed $fichierId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByFichierId($fichierId = null, $comparison = null)
    {
        if (is_array($fichierId)) {
            $useMinMax = false;
            if (isset($fichierId['min'])) {
                $this->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $fichierId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($fichierId['max'])) {
                $this->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $fichierId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $fichierId, $comparison);
    }

    /**
     * Filter the query by a related \Model\Etude object
     *
     * @param \Model\Etude|ObjectCollection $etude The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByEtude($etude, $comparison = null)
    {
        if ($etude instanceof \Model\Etude) {
            return $this
                ->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $etude->getId(), $comparison);
        } elseif ($etude instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeFichierTableMap::COL_ETUDE_ID, $etude->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByEtude() only accepts arguments of type \Model\Etude or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Etude relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function joinEtude($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Etude');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Etude');
        }

        return $this;
    }

    /**
     * Use the Etude relation Etude object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\EtudeQuery A secondary query class using the current class as primary query
     */
    public function useEtudeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinEtude($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Etude', '\Model\EtudeQuery');
    }

    /**
     * Use the Etude relation Etude object
     *
     * @param callable(\Model\EtudeQuery):\Model\EtudeQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withEtudeQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useEtudeQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Etude table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\EtudeQuery The inner query object of the EXISTS statement
     */
    public function useEtudeExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Etude table for a NOT EXISTS query.
     *
     * @see useEtudeExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\EtudeQuery The inner query object of the NOT EXISTS statement
     */
    public function useEtudeNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Etude', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Filter the query by a related \Model\Fichier object
     *
     * @param \Model\Fichier|ObjectCollection $fichier The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function filterByFichier($fichier, $comparison = null)
    {
        if ($fichier instanceof \Model\Fichier) {
            return $this
                ->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $fichier->getId(), $comparison);
        } elseif ($fichier instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(EtudeFichierTableMap::COL_FICHIER_ID, $fichier->toKeyValue('PrimaryKey', 'Id'), $comparison);
        } else {
            throw new PropelException('filterByFichier() only accepts arguments of type \Model\Fichier or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Fichier relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function joinFichier($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Fichier');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Fichier');
        }

        return $this;
    }

    /**
     * Use the Fichier relation Fichier object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \Model\FichierQuery A secondary query class using the current class as primary query
     */
    public function useFichierQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinFichier($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Fichier', '\Model\FichierQuery');
    }

    /**
     * Use the Fichier relation Fichier object
     *
     * @param callable(\Model\FichierQuery):\Model\FichierQuery $callable A function working on the related query
     *
     * @param string|null $relationAlias optional alias for the relation
     *
     * @param string|null $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this
     */
    public function withFichierQuery(
        callable $callable,
        string $relationAlias = null,
        ?string $joinType = Criteria::INNER_JOIN
    ) {
        $relatedQuery = $this->useFichierQuery(
            $relationAlias,
            $joinType
        );
        $callable($relatedQuery);
        $relatedQuery->endUse();

        return $this;
    }
    /**
     * Use the relation to Fichier table for an EXISTS query.
     *
     * @see \Propel\Runtime\ActiveQuery\ModelCriteria::useExistsQuery()
     *
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string $typeOfExists Either ExistsCriterion::TYPE_EXISTS or ExistsCriterion::TYPE_NOT_EXISTS
     *
     * @return \Model\FichierQuery The inner query object of the EXISTS statement
     */
    public function useFichierExistsQuery($modelAlias = null, $queryClass = null, $typeOfExists = 'EXISTS')
    {
        return $this->useExistsQuery('Fichier', $modelAlias, $queryClass, $typeOfExists);
    }

    /**
     * Use the relation to Fichier table for a NOT EXISTS query.
     *
     * @see useFichierExistsQuery()
     *
     * @param string|null $modelAlias sets an alias for the nested query
     * @param string|null $queryClass Allows to use a custom query class for the exists query, like ExtendedBookQuery::class
     *
     * @return \Model\FichierQuery The inner query object of the NOT EXISTS statement
     */
    public function useFichierNotExistsQuery($modelAlias = null, $queryClass = null)
    {
        return $this->useExistsQuery('Fichier', $modelAlias, $queryClass, 'NOT EXISTS');
    }
    /**
     * Exclude object from result
     *
     * @param   ChildEtudeFichier $etudeFichier Object to remove from the list of results
     *
     * @return $this|ChildEtudeFichierQuery The current query, for fluid interface
     */
    public function prune($etudeFichier = null)
    {
        if ($etudeFichier) {
            $this->addCond('pruneCond0', $this->getAliasedColName(EtudeFichierTableMap::COL_ETUDE_ID), $etudeFichier->getEtudeId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(EtudeFichierTableMap::COL_FICHIER_ID), $etudeFichier->getFichierId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the etude_fichier table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeFichierTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            EtudeFichierTableMap::clearInstancePool();
            EtudeFichierTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(EtudeFichierTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(EtudeFichierTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows

            EtudeFichierTableMap::removeInstanceFromPool($criteria);

            $affectedRows += ModelCriteria::delete($con);
            EtudeFichierTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // EtudeFichierQuery
