<?php

namespace Model;

use DateTime;
use Model\Base\Etude as BaseEtude;
use Model\Map\EtudeTableMap;
use Model\Map\JobCostTableMap;
use Model\Map\RefSalesForceTableMap;
use PDO;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Propel;

class Etude extends BaseEtude
{
    private static $qualificationQualType;
    private static $qualificationQuantType;
    private static $qualificationSyndicatedType;
    private static $qualificationQuantOnLineType;
    private static $etudes = [];
    private static $instances;
    private static $cutoffs;
    private static $instancesByYear = [];

    private $initial_margin_percentage;
    private $actual_margin_percentage;
    private $initial_margin_amount;
    private $actual_margin_amount;
    private $isMedical;
    private $prev;
    private $next;

    const SYNDICATED = 350; // FIXME create memoized function to get this from DB

    const ONGOING_ORDRE = 4; // To filter by etape order workflow.
    const PROJECT_TYPES = ['rst', 'cli', 'gqs', 'ins', 'hut'];

    const TABLETTER = [
        'Zero',
        'One',
        'Two',
        'Three',
        'Four',
        'Five',
        'Six',
        'Seven',
        'Eight',
        'Nine',
    ];

    public static function getById($id): ?Etude
    {
        return self::$etudes[$id] ?? self::$etudes[$id] = EtudeQuery::create()->findOneById($id);
    }

    public static function getCutoffs(): ObjectCollection
    {
        // "SELECT distinct periode_cutoff FROM etude WHERE periode_cutoff <> 'inf2011' GROUP BY periode_cutoff DESC"
        return self::$cutoffs ?? self::$cutoffs = EtudeQuery::create()
            ->filterByPeriodeCutoff('inf2011', Criteria::NOT_EQUAL)
            ->groupBy('PeriodeCutoff')
            ->orderByPeriodeCutoff(Criteria::DESC)
            ->find();
    }

    public static function getAll(): ObjectCollection
    {
        return self::$instances ?? self::$instances = EtudeQuery::create()->find();
    }

    public static function getQualificationQualType(): array
    {
        return self::$qualificationQualType ?? self::$qualificationQualType = RefSalesForceQuery::create()
            ->distinct()
            ->useMethodologyQuery()
                ->filterById(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField('job_qualification_id')
            ->filterByActif(true)
            ->filterByValue('Qual')
            ->find()->toKeyValue('Id', 'Id');
    }

    public static function getQualificationQuantType(): array
    {
        return self::$qualificationQuantType ?? self::$qualificationQuantType = RefSalesForceQuery::create()
            ->distinct()
            ->useMethodologyQuery()
                ->filterById(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField('job_qualification_id')
            ->filterByActif(true)
            ->filterByValue('Quant%', Criteria::LIKE)
            ->find()->toKeyValue('Id', 'Id');
    }

    public static function getQualificationQuantOnLineType(): int
    {
        $qualificationQuantOnLineType = self::$qualificationQuantOnLineType ?: self::$qualificationQuantOnLineType = RefSalesForceQuery::create()
            ->useMethodologyQuery()
                ->filterById(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField('job_qualification_id')
            ->filterByActif(true)
            ->filterByValue('Quant - Online')
            ->findOne();

        return $qualificationQuantOnLineType ? $qualificationQuantOnLineType->getId() : 0;
    }

    public static function getQualificationSyndicatedType(): ?RefSalesForce
    {
        return self::$qualificationSyndicatedType ?: self::$qualificationSyndicatedType = RefSalesForceQuery::create()
            ->useMethodologyQuery()
                ->filterById(null, Criteria::ISNOTNULL)
            ->endUse()
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField('job_qualification_id')
            ->filterByActif(true)
            ->filterByValue('Syndicated')
            ->findOne();
    }

    private static function getNumeroFromId($id): string
    {
        $etude = self::getById($id);

        return $etude ? $etude->getNumeroEtude() : '';
    }

    public static function getNumerosFromIds($listeId): string
    {
        $result = '';
        if ($listeId) {
            $liste_ids = explode(';', $listeId);
            $liste_ids = array_filter($liste_ids);
            foreach ($liste_ids as $id) {
                if ($num = self::getNumeroFromId($id)) {
                    $result .= ($liste_ids[0] == $id
                        ? '<span style="color:red;">'.$num.'</span> '
                        : '<span>'.$num.'</span> ');
                }
            }
            $result .= '('.count($liste_ids).' studies)';
        }

        return $result;
    }

    public function __toString(): string
    {
        return $this->getNumeroEtude();
    }

    public function getContactsList(): string
    {
        $contacts = $this->getAccount()->getContacts()->toKeyValue('Id', 'LastNameAndFirstName');

        sort($contacts);

        return implode('<br/>', $contacts);
    }

    public function isSyndicated(): bool
    {
        return self::SYNDICATED === $this->getJobQualificationId();
    }

    public function getLinkedUsers(): array
    {
        $users = [];

        foreach ($this->getJobEtudes() as $job) {
            if ($localPm = $job->getJobProjectManager()) {
                $email = $localPm->getMail();
                if (isset($users[$email])) {
                    $users[$email][] = 'LocalPM';
                } else {
                    $users[$email] = ['LocalPM'];
                }
            }
        }
        if ($masterPm = $this->getEtudeProjectManager()) {
            $email = $masterPm->getMail();
            if (isset($users[$email])) {
                $users[$email][] = 'MasterPM';
            } else {
                $users[$email] = ['MasterPM'];
            }
        }

        if ($salesManager = $this->getBM()) {
            $email = $salesManager->getMail();
            if (isset($users[$email])) {
                $users[$email][] = 'Owner';
            } else {
                $users[$email] = ['Owner'];
            }
        }

        return $users;
    }

    public function getLinkedUsersAsString(): string
    {
        $parts = [];
        foreach ($this->getLinkedUsers() as $email => $roles) {
            $parts[] = $email.' ('.implode(', ', $roles).')';
        }

        return implode(', ', $parts);
    }

    public function getLocations(): array
    {
        $result = [];
        foreach ($this->getJobEtudes() as $job) {
            $location = $job->getJobLocation();
            $result[$location->getId()] = $location->getLibelle();
        }

        return $result;
    }

    public function getSitesFromModules(): array
    {
        $result = [];

        foreach ($this->getJobEtudes() as $job) {
            foreach ($job->getEvents() as $event) {
                foreach ($event->getModules() as $module) {
                    if ('Y' != $module->getAnnule() && $site = $module->getSite()) {
                        $result[$site->getId()] = $site;
                    }
                }
            }
        }

        return $result;
    }

    public function getSuppliersFromModules(): array
    {
        $result = [];

        foreach ($this->getJobEtudes() as $job) {
            foreach ($job->getEvents() as $event) {
                foreach ($event->getModules() as $module) {
                    foreach ($module->getModuleFournisseurs() as $moduleFournisseur) {
                        if ('Y' != $module->getAnnule()
                            && 'O' == $moduleFournisseur->getPaiement()
                            && $supplier = $moduleFournisseur->getFournisseur()) {
                            $result[$supplier->getId()] = $supplier;
                        }
                    }
                }
            }
        }

        return $result;
    }

    public function majNotation(): void
    {
        $suppliers = $this->getSuppliersFromModules();
        foreach ($suppliers as $supplier) {
            $countFournisseurNotation = $supplier->countFournisseurNotations();
            if (($countFournisseurNotation > 0 && $supplier->getPtControleNbEtude() >= 10) ||
                (0 == $countFournisseurNotation && $supplier->getPtControleNbEtude() >= 4)) {
                // Shuffle current pt_controle_ids_etude for the supplier.
                $ptControleIdsEtudes = explode(';', $supplier->getPtControleIdsEtude());
                $ptControleIdsEtudes = array_filter($ptControleIdsEtudes);
                shuffle($ptControleIdsEtudes);
                $chosenEtude = Etude::getById($ptControleIdsEtudes[0]);
                $supplier->setPtControleNbEtude(0)->setPtControleIdsEtude('')->save();
                $fournisseurNotation = new FournisseurNotation();
                $fournisseurNotation->setFournisseur($supplier);
                $fournisseurNotation->setDate(new DateTime());
                $fournisseurNotation->setPmId($chosenEtude->getIdPm());
                $fournisseurNotation->setNoteQualitePrestation(0);
                $fournisseurNotation->setNoteRapiditeAction(0);
                $fournisseurNotation->setNoteRespectDelai(0);
                $fournisseurNotation->setNoteCommunication(0);
                $fournisseurNotation->setNoteRapportQualitePrix(0);
                $fournisseurNotation->setNoteFlexibilite(0);
                $fournisseurNotation->setValidation('');
                $fournisseurNotation->setListeIdEtude(implode(';', $ptControleIdsEtudes));
                $fournisseurNotation->save();
            } else {
                $ptControleIdsEtudes = explode(';', $supplier->getPtControleIdsEtude());
                $ptControleIdsEtudes = array_filter($ptControleIdsEtudes);
                $ptControleIdsEtudes = array_combine($ptControleIdsEtudes, $ptControleIdsEtudes);
                $ptControleIdsEtudes[$this->getId()] = $this->getId();
                $supplier->setPtControleNbEtude(count($ptControleIdsEtudes))
                    ->setPtControleIdsEtude(implode(';', $ptControleIdsEtudes))
                    ->save();
            }
        }

        $sites = $this->getSitesFromModules();
        foreach ($sites as $site) {
            $countSiteNotations = $site->countSiteNotations();
            // From 5 and then every 10 (5, 15, 25 ...) pt_controle_nb_etude on insert notation
            if (($countSiteNotations > 0 && $site->getPtControleNbEtude() >= 10) ||
                (0 == $countSiteNotations && $site->getPtControleNbEtude() >= 4)) {
                // Shuffle current pt_controle_ids_etude for the site.
                $ptControleIdsEtudes = explode(';', $site->getPtControleIdsEtude());
                $ptControleIdsEtudes = array_filter($ptControleIdsEtudes);
                shuffle($ptControleIdsEtudes);
                $chosenEtude = Etude::getById($ptControleIdsEtudes[0]);
                $site->setPtControleNbEtude(0)->setPtControleIdsEtude('')->save();
                $siteNotation = new SiteNotation();
                $siteNotation->setSite($site);
                $siteNotation->setDate(new DateTime());
                $siteNotation->setPmId($chosenEtude->getIdPm());
                $siteNotation->setNoteQualitePrestation(0);
                $siteNotation->setNoteRapiditeAction(0);
                $siteNotation->setNoteRespectDelai(0);
                $siteNotation->setNoteCommunication(0);
                $siteNotation->setNoteRapportQualitePrix(0);
                $siteNotation->setNoteFlexibilite(0);
                $siteNotation->setValidation('');
                $siteNotation->setListeIdEtude(implode(';', $ptControleIdsEtudes));
                $siteNotation->save();
            } else {
                $ptControleIdsEtudes = explode(';', $site->getPtControleIdsEtude());
                $ptControleIdsEtudes = array_filter($ptControleIdsEtudes);
                $ptControleIdsEtudes = array_combine($ptControleIdsEtudes, $ptControleIdsEtudes);
                $ptControleIdsEtudes[$this->getId()] = $this->getId();
                $site->setPtControleNbEtude(count($ptControleIdsEtudes))
                    ->setPtControleIdsEtude(implode(';', $ptControleIdsEtudes))
                    ->save();
            }
        }
    }

    /**
     * Code to be run before persisting the object.
     *
     * @return bool
     */
    public function preSave(ConnectionInterface $con = null)
    {
        if (!$this->getDateReglement() && count($this->getReglements())) {
            $this->setDateReglement($this->getReglements()->getFirst()->getDate());
        } elseif ($this->getDateReglement() && !count($this->getReglements())) {
            $this->setDateReglement(null);
        }

        if (!$this->getDateEnvoiFacture() && count($this->getFactures())) {
            $this->setDateEnvoiFacture($this->getFactures()->getFirst()->getDate());
        }

        $this->actualiseCoutsEtude();
        $this->setSfIdsFromPmTool();

        $totalRecrutementObjectif = 0;
        foreach ($this->getJobEtudes() as $job) {
            $totalRecrutementObjectif += $job->getOffSiteRecruits() + $job->getOnSiteRecruits();
        }
        $this->setRecrutementObjectif($totalRecrutementObjectif);

        if (!$this->getSharepointFolder() && ($oppty = $this->getOpportunity()) && $oppty->getSharepointFolder()) {
            $this->setSharepointFolder($oppty->getSharepointFolder());
        }

        return parent::preSave($con);
    }

    public function hasQuota(): bool
    {
        return $this->isMedical();
    }

    public function hasSyntec(): bool
    {
        return !$this->isMedical();
    }

    public function isMedical(): bool
    {
        if (isset($this->isMedical)) {
            return $this->isMedical;
        }

        $sector = null;
        foreach ($this->getRefSalesForceEtudeRefSectors() as $sectors) {
            $sector = $sectors->getValue(); // seems incorrect to overwrite
        }

        return $this->isMedical = in_array($sector, RefSalesForce::RESP_TYPE_CATEGORY);
    }

    public function isQual(): bool
    {
        return in_array($this->job_qualification_id, self::getQualificationQualType());
    }

    public function isQuant(): bool
    {
        return in_array($this->job_qualification_id, self::getQualificationQuantType());
    }

    public function isQuantOnline(): bool
    {
        return $this->job_qualification_id == self::getQualificationQuantOnLineType();
    }

    /**
     * Persiste les coûts dans l'étude.
     */
    public function actualiseCoutsEtude(): self
    {
        $revenue = $budgetCost = $actualCost = 0;
        $ordreEtape = $this->getEtape() ? $this->getEtape()->getOrdre() : null;

        foreach ($this->getJobEtudes() as $job) {
            $revenue += $job->getBudgetRevenue();
            $budgetCost += $job->getBudgetCost(); // job_item
            $actualCost += $job->getActualCost(); // job_cost
        }

        $this->setPrixRevientActualise($actualCost);
        $this->setPrixVenteActualise($revenue);

        if ($ordreEtape && $ordreEtape < self::ONGOING_ORDRE) {
            $this->setPrixVenteInitial($revenue);
            $this->setPrixRevientInitial($budgetCost);
        }

        return $this;
    }

    public function setDateFin($v): self
    {
        if ($v) {
            $this->setAnnee($v->format('Y'));
        }

        return parent::setDateFin($v);
    }

    public function getMontantReglement(): string
    {
        $total = 0;
        foreach ($this->getReglements() as $reglement) {
            $total += $reglement->getMontant();
        }

        return number_format($total, 2, '.', ' ');
    }

    public function getMontantFacture(): string
    {
        $total = 0;
        foreach ($this->getFactures() as $facture) {
            $total += $facture->getMontant();
        }

        return number_format($total, 2, '.', ' ');
    }

    /**
     * Generates study number (17/1234 for Schmiedl; Cxxxxx for Consumed).
     */
    public function generateStudyNumber(string $instance = ''): self
    {
        $numeroEtude = '';
        $con = Propel::getConnection();

        switch ($instance) {
            case 'fr':
                $init = 'C';
                $type = 'consumed';
                if ($this->getRoomRental()) {
                    $init = 'F';
                    $type = 'room_rental';
                } elseif (self::getQualificationSyndicatedType() && $this->getJobQualificationId() === self::getQualificationSyndicatedType()->getId()) {
                    $init = 'V';
                    $type = 'vigie';
                } elseif ('Healthcare' == $this->getIndustry()->getLibelle()) {
                    $init = 'M';
                    $type = 'medical';
                }
                $numero = NumeroQuery::create()
                    ->filterByType($type)
                    ->findOne();
                if (!$numero) {
                    $numero = new Numero();
                    $numero->setType($type);
                    $numero->setNumero(0);
                    $numero->save();
                }
                $num = $numero->getNumero() + 1;
                $numero->setNumero($num)->save();
                $numeroEtude = sprintf($init.'%05d', $num);
                break;
            case 'de':
                $annee_souche = $this->getDateDebut('y');
                $query = 'SELECT max(numero_etude) AS last_number FROM etude WHERE numero_etude LIKE ? LIMIT 1';
                $stmt = $con->prepare($query);
                $stmt->bindValue(1, $annee_souche.'%', PDO::PARAM_STR);
                $stmt->execute();
                $last_number = $stmt->fetchColumn();
                $numeroEtude = substr($last_number, 3, 4);
                ++$numeroEtude;
                $numeroEtude = $annee_souche.'-'.sprintf('%04d', $numeroEtude);
                break;
            case 'uk':
                $annee_souche = $this->getRoomRental() ? 'FAC' : 'LON';
                $annee_souche .= $this->getDateDebut('y');
                $query = 'SELECT max(numero_etude) AS last_number FROM etude WHERE numero_etude LIKE ? LIMIT 1';
                $stmt = $con->prepare($query);
                $stmt->bindValue(1, $annee_souche.'%', PDO::PARAM_STR);
                $stmt->execute();
                $last_number = $stmt->fetchColumn();
                $numeroEtude = substr($last_number, 6, 4);
                ++$numeroEtude;
                $numeroEtude = $annee_souche.'P'.sprintf('%04d', $numeroEtude);
                break;
            case 'es':
                $annee_souche = '2'.$this->getDateDebut('y');
                $query = 'SELECT max(numero_etude) AS last_number FROM etude WHERE numero_etude LIKE ? LIMIT 1';
                $stmt = $con->prepare($query);
                $stmt->bindValue(1, $annee_souche.'%', PDO::PARAM_STR);
                $stmt->execute();
                $last_number = $stmt->fetchColumn();
                $numeroEtude = substr($last_number, 4, 4);
                ++$numeroEtude;
                $numeroEtude = $annee_souche.sprintf('%04d', $numeroEtude);
                break;
            default:
                $numero = NumeroQuery::create()
                    ->filterByType('default')
                    ->findOne();
                if (!$numero) {
                    $numero = new Numero();
                    $numero->setType('default');
                    $numero->setNumero(0);
                    $numero->save();
                }
                $num = $numero->getNumero() + 1;
                $numero->setNumero($num)->save();
                $numeroEtude = sprintf('%05d', $num);
                break;
        }

        return $this->setNumeroEtude($numeroEtude);
    }

    public function resetConsolidationTs(): void
    {
        foreach ($this->getJobEtudes() as $job) {
            $job->resetConsolidationTimesheet();
        }
    }

    public function resetConsolidationPr(): void
    {
        foreach ($this->getJobEtudes() as $job) {
            $job->resetConsolidationPhoneRoom();
        }
    }

    public function getSummary(ConnectionInterface $con = null): array
    {
        $con = $con ?: Propel::getConnection();
        $summary = [];
        $query = 'SELECT DISTINCT libelle AS location, categorie AS section, consolidation AS category,
            SUM(quantite_pv) AS qtePv,
            SUM(prix_vente) AS prixVente
            FROM categorie_prestation cp
            JOIN job_item ji ON ji.categorie_prestation_id = cp.id
            JOIN job j ON j.id = ji.job_id
            JOIN ref_location l ON l.id = j.location_id
            WHERE devis_ok < 5
            AND j.etude_id = ?
            GROUP BY libelle,categorie';
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $this->getId(), PDO::PARAM_INT);
        $stmt->execute();
        $results = $stmt->fetchAll();
        foreach ($results as $result) {
            $summary[$result['category']][$result['location']][$result['section']]['qtePv'] = $result['qtePv'];
            $summary[$result['category']][$result['location']][$result['section']]['prixVente'] = $result['prixVente'];
        }

        if (in_array($this->getIdEtape(), [ // per #12706
            Etape::STUDY_CREATION,
            Etape::BUDGET_CREATION,
            Etape::TO_CONFIRM,
        ])) {
            $query = 'SELECT DISTINCT libelle AS location,categorie AS section, consolidation AS category,
                SUM(quantite_pr) AS qtePr,
                SUM(prix_revient) AS prixRevient
                FROM categorie_prestation cp
                JOIN job_item ji ON ji.categorie_prestation_id = cp.id
                JOIN job j ON j.id = ji.job_id
                JOIN ref_location l ON l.id = j.location_id
                WHERE devis_ok < 5
                AND j.etude_id = ?
                GROUP BY libelle,categorie';
            $stmt = $con->prepare($query);
            $stmt->bindValue(1, $this->getId(), PDO::PARAM_INT);
            $stmt->execute();
            $results = $stmt->fetchAll();
            foreach ($results as $result) {
                $summary[$result['category']][$result['location']][$result['section']]['qtePr'] = $result['qtePr'];
                $summary[$result['category']][$result['location']][$result['section']]['prixRevient'] = $result['prixRevient'];
            }

            return $summary;
        }

        $query = 'SELECT DISTINCT libelle AS location, categorie AS section, consolidation AS category,
            SUM(quantite_pr) AS qtePr,
            SUM(prix_revient) AS prixRevient
            FROM categorie_prestation cp
            JOIN job_costs jc ON jc.categorie_prestation_id = cp.id
            JOIN job j ON j.id = jc.job_id
            JOIN ref_location l ON l.id = j.location_id
            WHERE devis_ok < 5
            AND j.etude_id = ?
            GROUP BY libelle,categorie';
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $this->getId(), PDO::PARAM_INT);
        $stmt->execute();
        $results = $stmt->fetchAll();

        foreach ($results as $result) {
            $summary[$result['category']][$result['location']][$result['section']]['qtePr'] = $result['qtePr'];
            $summary[$result['category']][$result['location']][$result['section']]['prixRevient'] = $result['prixRevient'];
        }

        return $summary;
    }

    public function resetConsolidationInterviewer(): void
    {
        foreach ($this->getJobEtudes() as $job) {
            $job->resetConsolidationInterviewer();
        }
    }

    public function canUpdateCosts(): bool
    {
        return in_array($this->getIdEtape(), [
            Etape::STUDY_CREATION,
            Etape::ONGOING,
            Etape::BUDGET_CREATION,
            Etape::TO_CONFIRM,
        ]);
    }

    public function recalculCostsEtude(): self
    {
        // Calcul du Prix de revient
        $pv = 0;

        foreach ($this->getJobEtudes() as $job) {
            $recalculPr = JobCostQuery::create()
                ->filterByJob($job)
                ->withColumn('SUM('.JobCostTableMap::COL_PRIX_REVIENT.')', 'summpv')
                ->findOne();
            if ($recalculPr) {
                $pv = (int) $recalculPr->getVirtualColumn('summpv');
            }
        }

        return $this->setPrixVenteActualise($pv);
    }

    public function getPrev(): ?self
    {
        return $this->prev ?: $this->prev = EtudeQuery::create()
            ->filterById($this->getId(), Criteria::LESS_THAN)
            ->orderById(Criteria::DESC)
            ->findOne();
    }

    public function getNext(): ?self
    {
        return $this->next ?: $this->next = EtudeQuery::create()
            ->filterById($this->getId(), Criteria::GREATER_THAN)
            ->orderById()
            ->findOne();
    }

    public function getPrixRevientActualise(): string
    {
        return number_format($this->prix_revient_actualise, '2', '.', '');
    }

    public function getPrixRevientInitial(): string
    {
        return number_format($this->prix_revient_initial, '2', '.', '');
    }

    public function getPrixVenteActualise(): string
    {
        return number_format($this->prix_vente_actualise, '2', '.', '');
    }

    public function getPrixVenteInitial(): string
    {
        return number_format($this->prix_vente_initial, '2', '.', '');
    }

    public function getInitialMarginPercentage(): string
    {
        if ($this->initial_margin_percentage) {
            return $this->initial_margin_percentage;
        }
        $margin = 0;

        if (0 != $this->getPrixRevientInitial() && 0 != $this->getPrixVenteInitial()) {
            $margin = 100 * ($this->getPrixVenteInitial() - $this->getPrixRevientInitial()) / $this->getPrixVenteInitial();
        }

        return $this->initial_margin_percentage = number_format($margin, '2', '.', '');
    }

    public function getInvoicesList(): string
    {
        $result = [];
        foreach ($this->getFactures() as $facture) {
            if (!$facture->isDeleted()) {
                $result[] = $facture->getNumeroFacture();
            }
        }

        return implode('<br/>', $result);
    }

    public function getListeRemise(): string
    {
        $remises = JobItemQuery::create()
            ->useJobQuery()
                ->filterByEtude($this)
            ->endUse()
            ->filterByDevisOk(5, Criteria::LESS_THAN)
            ->useCategoriePrestationQuery()
                ->filterByRemise(1)
            ->endUse()
            ->find();

        $result = [];
        foreach ($remises as $remise) {
            $result[] = $remise->getCategoriePrestation()->getCategorie();
        }

        return implode('<br/>', $result);
    }

    public function getActualMarginPercentage(): string
    {
        if ($this->actual_margin_percentage) {
            return $this->actual_margin_percentage;
        }
        $margin = 0;

        if (0 != $this->getPrixRevientActualise() && 0 != $this->getPrixVenteActualise()) {
            $margin = 100 * ($this->getPrixVenteActualise() - $this->getPrixRevientActualise()) / $this->getPrixVenteActualise();
        }

        return $this->actual_margin_percentage = number_format($margin, '2', '.', '');
    }

    public function getInitialMarginAmount(): string
    {
        if ($this->initial_margin_amount) {
            return $this->initial_margin_amount;
        }
        $margin = $this->getPrixVenteInitial() - $this->getPrixRevientInitial();

        return $this->initial_margin_amount = number_format($margin, '2', '.', '');
    }

    public function getActualMarginAmount(): string
    {
        if ($this->actual_margin_amount) {
            return $this->actual_margin_amount;
        }

        $margin = $this->getPrixVenteActualise() - $this->getPrixRevientActualise();

        return $this->actual_margin_amount = number_format($margin, '2', '.', '');
    }

    public function getMissingEtudeCheckList(): Collection
    {
        $etudeChecklists = EtudeChecklistQuery::create()
            ->useEtudeCheckListTypeQuery()
            ->orderBySort()
            ->endUse()
            ->orderBySort()
            ->find();
        $collection = new ObjectCollection();
        foreach ($this->getEtudeCheckListValidations() as $validation) {
            $etudeCheckList = $validation->getEtudeChecklist();
            $collection->append($etudeCheckList);
        }

        return $etudeChecklists->diff($collection);
    }

    public function getCheckListValidationGroupesId(): array
    {
        $groupes = [];
        foreach ($this->getEtudeCheckListValidations() as $validation) {
            $etudeCheckList = $validation->getEtudeChecklist();
            $groupe = $etudeCheckList->getGroupeId();
            if (!in_array($groupe, $groupes)) {
                $groupes[] = $groupe;
            }
        }

        return $groupes;
    }

    public static function getPMToolFieldName($fieldName): string
    {
        return EtudeTableMap::translateFieldName($fieldName, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME);
    }

    public function getNumberAndAccountName(): string
    {
        return $this->numero_etude.' '.$this->getAccount()->getName();
    }

    public function getFullName(): string
    {
        return $this->getNumeroEtude().' ('.$this->reference_client.')';
    }

    public function getDisplayName(): string
    {
        return $this->getNumeroEtude().' - '.$this->getTheme();
    }

    /**
     * FIXME don't do that! Field will be truncated in forms!
     */
    public function getReferenceClient(): string
    {
        return mb_substr(parent::getReferenceClient(), 0, 30);
    }

    public function getReferenceClientWithNotLimitSize(): string
    {
        return parent::getReferenceClient();
    }

    public function getMethodologiesNames(): array
    {
        $res = [];
        foreach ($this->getMethodologies() as $methodology) {
            $res[] = $methodology->getTypeetudebr();
        }

        return $res;
    }

    public function getSectorsNames(): array
    {
        $res = [];
        foreach ($this->getRefSalesForceEtudeRefSectors() as $sector) {
            $res[] = $sector->getValue();
        }

        return $res;
    }

    public function getRemise(): float
    {
        $con = Propel::getConnection();
        $query = 'SELECT DISTINCT categorie_prestation_id,categorie,category,
            cp.remise*((SUM(ji.prix_vente)/(1-(sfr.value/100)))-SUM(ji.prix_vente)) AS montantRemise
            FROM etude e
            JOIN job j ON j.etude_id = e.id
            JOIN job_item ji ON ji.job_id = j.id
            JOIN categorie_prestation cp ON ji.categorie_prestation_id =cp.id
            JOIN sf_account sfa ON sfa.id = e.account_id
            JOIN sf_ref_salesforce sfr ON sfr.id = sfa.discount_percentage_id
            WHERE devis_ok < 5
            AND e.id = ?
            GROUP BY categorie_prestation_id';

        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $this->getId(), PDO::PARAM_INT);
        $stmt->execute();
        $results = $stmt->fetchAll();

        $total = 0;
        foreach ($results as $result) {
            $total += $result['montantRemise'];
        }

        return $total;
    }

    public function getEventsForDocuments(): array
    {
        $events = EventQuery::create()
            ->useRefEventStatusQuery()
                ->filterByName([RefEventStatus::RELEASED, RefEventStatus::TENTATIVE], Criteria::NOT_IN)
            ->endUse()
            ->useJobQuery()
                ->filterByEtude($this)
                ->useStatusQuery()
                    ->filterByValue(RefSalesForce::JOB_STATUSES_DOCUMENTS, Criteria::IN)
                ->endUse()
            ->endUse()
            ->filterByIsDeletedC(false)
            ->filterByCancelled(false)
            ->orderByJobId()
            ->useSiteQuery()
                ->orderByLieu()
            ->endUse()
            ->orderByDate()
            ->orderByStartDateTime()
            ->find();

        $siteEvents = [];
        foreach ($events as $event) {
            if ($site = $event->getSite()) {
                $manager = $event->getJob() ? $event->getJob()->getJobProjectManager() : null;
                $localProjectNumber = $event->getJob() ? $event->getJob()->getIdSamsJob() : '-';
                $indexId = $localProjectNumber.'-'.$site->getId();
                $cityAndZip = $site->getVille() ? $site->getVille()->getVille().' '.$site->getVille()->getCp() : '';
                if (!isset($siteEvents[$indexId])) {
                    $siteEvents[$indexId] = [
                        'address' => $site->getLieu().' - '.$site->getAdresse().' '.$cityAndZip,
                        'project_number' => $localProjectNumber,
                        'local_contact' => $manager ? $manager->getNomComplet() : '-',
                        'platform' => $event->getJob() && $event->getJob()->getPlatform() ? $event->getJob()->getPlatform()->getName() : '',
                        'events' => [],
                    ];
                }
                $siteEvents[$indexId]['events'][] = $event;
            }
        }

        krsort($siteEvents);

        return $siteEvents;
    }

    public function getIncentivesForDocuments(): ObjectCollection
    {
        return JobItemQuery::create()
            ->useJobQuery()
                ->filterByEtude($this)
                ->useStatusQuery()
                    ->filterByValue(RefSalesForce::JOB_STATUSES_DOCUMENTS, Criteria::IN)
                ->endUse()
            ->endUse()
            ->useCategoriePrestationQuery()
                ->filterByConsolidation('Incentives')
            ->endUse()
            ->find();
    }

    public static function getSiEuJobTypTypes(): array
    {
        $types = EtudeTableMap::getValueSet(EtudeTableMap::COL_SI_EU_JOB_TYPE);

        return array_combine($types, $types);
    }

    public function getModulePaymentDefaultValue(string $instance = ''): string
    {
        switch ($instance) {
            case 'de':
                return 'B'; // Bank tr.
            case 'fr': // per #12624
                $qualifId = self::getQualificationSyndicatedType() ? self::getQualificationSyndicatedType()->getId() : '';

                return $this->getJobQualificationId() === $qualifId ? 'B' : 'O'; // Check
            case 'es':
                return 'D'; // Card
            case 'uk':
                return 'A'; // PayPal
            case 'us':
                return 'D'; // Card
            default:
                break;
        }

        return '';
    }

    public function setSfIdsFromPmTool(): void
    {
        if ($manager = $this->getProjectAccountManager()) {
            $this->setAccountManagerSfId($manager->getSfIdOrDefault());
        }
    }

    public function getDefaultSponsorSfId(): string
    {
        $account = $this->getAccount();
        if ($this->isQual() && $account && $account->getSponsor()) {
            return (string) $account->getSponsor();
        }

        if ($this->isQuant() && $account && $account->getQuantSponsor()) {
            return (string) $account->getQuantSponsor();
        }

        return User::getDefaultSfId();
    }

    public function getFromYear($year): ObjectCollection
    {
        return self::$instancesByYear[$year] ?? self::$instancesByYear[$year] = JobQuery::create()
            ->orderById(Criteria::DESC)->filterByApiCreatedDate([
                'min' => $year.'-01-01 00:00:00',
                'max' => $year.'-12-31 23:59:59',
            ])->find();
    }

    public function haveBadPayer(): bool
    {
        $endClient = $this->getEndClient() ? $this->getEndClient()->getBadPayer() : '';
        $intermediateClient = $this->getIntermediateClient() ? $this->getIntermediateClient()->getBadPayer() : '';
        $account = $this->getAccount() ? $this->getAccount()->getBadPayer() : '';

        return 'Y' === $endClient || 'Y' === $intermediateClient || 'Y' === $account;
    }

    public function addProjectStatusLog(User $user = null): void
    {
        (new LogProjectStatus())
            ->setEtude($this)
            ->setStatus($this->getEtape() ? $this->getEtape()->getEtape() : '-')
            ->setDate(new DateTime())
            ->setUser($user);
    }

    public function addStopAMCheckedAutomaticallyHistory(User $user, string $status): void
    {
        (new LogProjectStatus())
            ->setEtude($this)
            ->setStatus($status)
            ->setDate(new DateTime())
            ->setUser($user);
    }

    public function addConsolidatedInvoiceLogHistory(User $user, string $logStatusVaue): void
    {
        (new LogProjectStatus())
            ->setEtude($this)
            ->setStatus($logStatusVaue)
            ->setDate(new DateTime())
            ->setUser($user);
    }

    /**
     * Returns the part of numero_etude before the '-'.
     */
    public function getRootProjectNumber(): string
    {
        return explode('-', $this->getNumeroEtude())[0];
    }

    public function getEtapeRank(): int
    {
        return $this->getEtape() ? $this->getEtape()->getRank() : 0;
    }

    public function canChangeEtape(int $etapeId): bool
    {
        $ordre = Etape::get($etapeId);

        return $ordre && $this->getEtapeRank() < $ordre->getRank();
    }

    public function getEvents(): array
    {
        $allEvents = [];

        foreach ($this->getJobEtudes() as $job) {
            $jobEvents = $job->getEvents();
            foreach ($jobEvents as $jobEvent) {
                $allEvents[] = $jobEvent;
            }
        }

        return $allEvents;
    }

    public function serializeForSalesforce(): array
    {
        return [
            'Specialty_Sales_Rep__c' => $this->getProjectSpecialtySponsor() ? $this->getProjectSpecialtySponsorSfId() : '',
            'Assigned_MC_Manager__c' => $this->getProjectAccountManager() ? $this->getAccountManagerSfId() : '',
            'Field_End_Date__c' => $this->getDateFin('Y-m-d'),
            'Field_Start_Date__c' => $this->getDateDebut('Y-m-d'),
            'Account_Team_2__c' => $this->getAccountPM() ? $this->getAccountPMSfId() : '',
            'Account_Team_1__c' => $this->getAccountLeader() ? $this->getAccountLeaderSfId() : '',
            'AM_Email__c' => $this->getAmEmail() ? $this->getAmEmail() : '',
            'Revised_Location_Prefix__c' => $this->getProjectLocationPrefix() ? $this->getProjectLocationPrefix()->getPrefix() : '',
            'Job_Description__c' => $this->getTheme(),
            'Job_Status__c' => $this->getEtape() ? $this->getEtape()->getSfLabel() : '',
            'INS__c' => $this->getIns(),
            'RST__c' => $this->getRst(),
            'CLI__c' => $this->getCli(),
            'GQS__c' => $this->getGqs(),
            'HUT__c' => $this->getHut(),
        ];
    }

    public function getProjectSpecialtySponsorSfId(): string
    {
        return $this->getProjectSpecialtySponsor() ? $this->getProjectSpecialtySponsor()->getSfIdOrDefault() : '';
    }

    public function getAccountLeaderSfId(): string
    {
        return $this->getAccountLeader() ? $this->getAccountLeader()->getSfIdOrDefault() : '';
    }

    public function getAccountManagerSfId(): string
    {
        return $this->getProjectAccountManager() ? $this->getProjectAccountManager()->getSfIdOrDefault() : '';
    }

    public function getAccountPMSfId(): string
    {
        return $this->getAccountPM() ? $this->getAccountPM()->getSfIdOrDefault() : '';
    }

    public function checkPriceValue()
    {
        foreach ($this->getJobEtudes() as $job) {
            if (RefSalesForce::JOB_STATUS_CANCELLED_NON_BILLED != $job->getStatus()) {
                foreach ($job->getJobItems() as $jobItem) {
                    if (($job->getPmChecked() || $job->getAmChecked()) && !$jobItem->getPrixVente() && !$jobItem->getZeroValueConfirmed()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public function checkActiveConfirmedEvents(): bool
    {
        foreach ($this->getJobEtudes() as $job) {
            foreach ($job->getEvents() as $event) {
                if (in_array($event->getRefEventStatus(), [RefEventStatus::ACTIVE, RefEventStatus::CONFIRMED])) {
                    return true;
                }
            }
        }

        return false;
    }

    public function getInvoiceTabColor(): string
    {
        $color = '';
        $invoices = $this->getFactures();
        foreach ($invoices as $invoice) {
            if ($invoice->getDocument() && in_array($invoice->getDocument()->getDocumentBr(), Facture::DOCUMENT_TYPE)) {
                if (!$invoice->isSend()) {
                    $color = Facture::ORANGE;
                    break;
                } else {
                    if (0 == $invoice->getPaidAmount() || !$invoice->getPaymentDate()) {
                        $color = Facture::YELLOW;
                        break;
                    } else {
                        $color = Facture::GREEN;
                    }
                }
            }
        }

        return $color;
    }

    public function setEventsClosedForFdOrPmCheckedJob()
    {
        $eventStatusClosed = RefEventStatusQuery::create()->filterByName(RefEventStatus::CLOSED)->findOne();

        foreach ($this->getJobEtudes() as $job) {
            if ($job->getFdChecked() || $job->getPmChecked()) {
                foreach ($job->getEvents() as $event) {
                    if ($event->getRefEventStatus() && RefEventStatus::ACTIVE == $event->getRefEventStatus()->getName() && !$event->isDeletedC()) {
                        $event->setRefEventStatus($eventStatusClosed);
                        $event->save();
                    }
                }
            }
        }
    }

    public function getNameForPDF(string $pdfType, Collection $jobs = null)
    {
        $separator = '_';
        $allIdSamsJob = [];
        $theme = null !== $this->getTheme() ? str_replace(' ', '_', trim($this->getTheme())) : '';
        $masterProjectNumber = null !== $this->getMasterProjectNumber() ? str_replace(' ', $separator, trim($this->getMasterProjectNumber())) : '';
        if (null !== $jobs) {
            foreach ($jobs as $job) {
                if ($job instanceof Job) {
                    $allIdSamsJob[] = null !== $job && null !== $job->getIdSamsJob() ? str_replace(' ', $separator, trim($job->getIdSamsJob())) : '';
                }
            }
        }

        $finalProjectNumber = strlen($masterProjectNumber) > 0 ? '['.$masterProjectNumber.']' : '';
        $finalTheme = strlen($theme) > 0 ? '['.$theme.']' : '';
        $finalIdSamsJob = count($allIdSamsJob) > 0 ? implode($separator, $allIdSamsJob) : '';

        if ('job-alert' == $pdfType) {
            $prefix = 'JA';
            $finaleName = [$prefix, $finalProjectNumber, $finalTheme];

            return implode($separator, $finaleName);
        } elseif ('job_advanced_invoice' == $pdfType) {
            $prefix = 'AII';
            $finaleName = [$prefix, $finalIdSamsJob, $finalTheme];

            return implode($separator, $finaleName);
        } elseif ('etude_advanced_invoice' == $pdfType) {
            $prefix = 'AII';
            $finaleName = [$prefix, $finalProjectNumber, $finalTheme];

            return implode($separator, $finaleName);
        } else {
            return 'export';
        }
    }

    public function addPmEmailDefintionLogHistory(User $user, string $logStatusVaue): void
    {
        (new LogProjectStatus())
            ->setEtude($this)
            ->setStatus($logStatusVaue)
            ->setDate(new DateTime())
            ->setUser($user);
    }
}
