<?php

namespace Model;

use Model\Base\RefSalesForceOpportunitySector as BaseRefSalesForceOpportunitySector;

class RefSalesForceOpportunitySector extends BaseRefSalesForceOpportunitySector
{
}
