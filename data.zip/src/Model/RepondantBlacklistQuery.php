<?php

namespace Model;

use Model\Base\RepondantBlacklistQuery as BaseRepondantBlacklistQuery;

class RepondantBlacklistQuery extends BaseRepondantBlacklistQuery
{
}
