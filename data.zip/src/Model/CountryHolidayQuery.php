<?php

namespace Model;

use Model\Base\CountryHolidayQuery as BaseCountryHolidayQuery;

class CountryHolidayQuery extends BaseCountryHolidayQuery
{
}
