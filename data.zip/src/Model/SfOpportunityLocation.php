<?php

namespace Model;

use Model\Base\SfOpportunityLocation as BaseSfOpportunityLocation;

class SfOpportunityLocation extends BaseSfOpportunityLocation
{
}
