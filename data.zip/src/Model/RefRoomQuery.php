<?php

namespace Model;

use Model\Base\RefRoomQuery as BaseRefRoomQuery;

class RefRoomQuery extends BaseRefRoomQuery
{
}
