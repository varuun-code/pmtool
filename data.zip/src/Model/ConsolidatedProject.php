<?php

namespace Model;

use Model\Base\ConsolidatedProject as BaseConsolidatedProject;
use SpocBundle\Manager\DatabaseManager;

class ConsolidatedProject extends BaseConsolidatedProject
{
    public function setFrProject(Etude $projet = null)
    {
        return parent::setFrProjectId($projet ? $projet->getId() : null);
    }

    public function setEsProject(Etude $projet = null)
    {
        return parent::setEsProjectId($projet ? $projet->getId() : null);
    }

    public function setDeProject(Etude $projet = null)
    {
        return parent::setDeProjectId($projet ? $projet->getId() : null);
    }

    public function setUkProject(Etude $projet = null)
    {
        return parent::setUkProjectId($projet ? $projet->getId() : null);
    }

    public function setUsProject(Etude $projet = null)
    {
        return parent::setUsProjectId($projet ? $projet->getId() : null);
    }

    public function getFrProject()
    {
        return ($id = parent::getFrProjectId()) ? (new EtudeQuery(DatabaseManager::PMTOOL_FR))->findOneById($id) : null;
    }

    public function getEsProject()
    {
        return ($id = parent::getEsProjectId()) ? (new EtudeQuery(DatabaseManager::PMTOOL_ES))->findOneById($id) : null;
    }

    public function getDeProject()
    {
        return ($id = parent::getDeProjectId()) ? (new EtudeQuery(DatabaseManager::PMTOOL_DE))->findOneById($id) : null;
    }

    public function getUkProject()
    {
        return ($id = parent::getUkProjectId()) ? (new EtudeQuery(DatabaseManager::PMTOOL_UK))->findOneById($id) : null;
    }

    public function getUsProject()
    {
        return ($id = parent::getUsProjectId()) ? (new EtudeQuery(DatabaseManager::PMTOOL_US))->findOneById($id) : null;
    }
}
