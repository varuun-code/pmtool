<?php

namespace Model;

use Model\Base\EventBidJobItemQuery as BaseEventBidJobItemQuery;

class EventBidJobItemQuery extends BaseEventBidJobItemQuery
{
}
