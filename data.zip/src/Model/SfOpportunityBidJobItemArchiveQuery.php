<?php

namespace Model;

use Model\Base\SfOpportunityBidJobItemArchiveQuery as BaseSfOpportunityBidJobItemArchiveQuery;

class SfOpportunityBidJobItemArchiveQuery extends BaseSfOpportunityBidJobItemArchiveQuery
{
}
