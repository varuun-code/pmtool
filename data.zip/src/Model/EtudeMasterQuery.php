<?php

namespace Model;

use Model\Base\EtudeMasterQuery as BaseEtudeMasterQuery;

class EtudeMasterQuery extends BaseEtudeMasterQuery
{
}
