<?php

namespace Model;

use Model\Base\Repondant as BaseRepondant;
use Model\Map\RepondantTableMap;

class Repondant extends BaseRepondant
{
    const PRACTICE_TYPES = [
        RepondantTableMap::COL_PRACTICE_TYPE_MIXTE => 'mixte',
        RepondantTableMap::COL_PRACTICE_TYPE_HOSPITALIERE => 'hospitalière',
        RepondantTableMap::COL_PRACTICE_TYPE_LIBERALE => 'libérale',
    ];

    private static $instances;

    public static function getById($id): ?self
    {
        return self::$instances[$id] ?? self::$instances[$id] = RepondantQuery::create()->findOneById($id);
    }

    public static function getCivilities(string $config = ''): array
    {
        if ('de' == $config) {
            return [
                '' => '',
                'Familie' => 'Familie',
                'Firma' => 'Firma',
                'Frau' => 'Frau',
                'Frau Dr.' => 'Frau Dr.',
                'Frau PD' => 'Frau PD',
                'Frau Professor' => 'Frau Professor',
                'Herr' => 'Herr',
                'Herr Dr.' => 'Herr Dr.',
                'Herr PD' => 'Herr PD',
                'Herr Professor' => 'Herr Professor',
            ];
        } elseif ('fr' == $config) {
            return [
                '' => '',
                'M.' => 'M.',
                'Mme' => 'Mme',
                'Dr' => 'Dr',
                'Pr' => 'Pr',
                'Mlle' => 'Mlle',
            ];
        }

        return [
            '' => '',
            'Mr' => 'Mr',
            'Mrs' => 'Mrs',
            'Ms' => 'Ms',
        ];
    }

    public static function findOneOrCreate($firstName, $lastName, $email, $email2, $landline, $mobile)
    {
        /*
         * Two repondents are the same person if and only if:
         * - their firstname and lastname match
         * - AND at least one of the four among (email, email2, landline, mobile) match, if defined
         */
        $repondent = RepondantQuery::create()
            ->filterByNom($lastName)
            ->filterByPrenom($firstName)
            ->_if($email)
            ->filterByEmail($email)
            ->_or()
            ->filterByEmail('')
            ->_or()
            ->filterByEmail2($email)
            ->_endif()
            ->_or()
            ->_if($email2)
            ->filterByEmail($email2)
            ->_or()
            ->filterByEmail2('')
            ->_or()
            ->filterByEmail2($email2)
            ->_endif()
            ->_or()
            ->_if($landline)
            ->filterByTel($landline)
            ->_or()
            ->filterByTel('')
            ->_or()
            ->filterByPortable($landline)
            ->_endif()
            ->_or()
            ->_if($mobile)
            ->filterByPortable($mobile)
            ->_or()
            ->filterByPortable('')
            ->_or()
            ->filterByTel($mobile)
            ->_endif()
            ->findOne();

        return $repondent ?: new self();
    }

    public function __toString(): string
    {
        return $this->getNomComplet();
    }

    public function isBlackListed()
    {
        $isBlacklisted = RepondantBlacklistQuery::create()
            ->filterByRepondantId($this->getId())
            ->findOne();
        if (null != $isBlacklisted) {
            return true;
        } else {
            return false;
        }
    }

    public function getColor()
    {
        if ($this->isBlackListed()) {
            return '#000000';
        }
        if ('+' == $this->getRating()) {
            return '#0f0';
        }
        if ('-' == $this->getRating()) {
            return '#FF8000';
        }
        if ('B' == $this->getRating()) {
            return '#f00';
        }

        return ''; // transparent
    }

    public function getFullname(string $instance = '')
    {
        return $this->getQualiteNomLong($instance).' '.$this->getNom().' '.$this->getPrenom();
    }

    public function getNomComplet()
    {
        $fullName = [];

        if ($this->qualite) {
            $fullName[] = $this->qualite;
        }
        if ($this->nom) {
            $fullName[] = $this->nom;
        }
        if ($this->prenom) {
            $fullName[] = $this->prenom;
        }

        return implode(' ', $fullName);
    }

    public function getInfo()
    {
        $ville = $this->getVille() ? $this->getVille()->getCpAndVille() : '';

        return $this->getNomComplet().' '.$this->getTel().' '.$this->getPortable().' '.$this->getAdresse().' '.$ville;
    }

    public function getQualiteNomLong(string $instance = '')
    {
        $qualites = self::getCivilities($instance);

        return $qualites[$this->getQualite()] ?? '';
    }

    public function setPhoneNumbersformat()
    {
        $tel = trim($this->getTel());
        if (10 == strlen($tel)) {
            $this->setTel(chunk_split($this->getTel(), 2, ' '));
        }
        $portable = trim($this->getPortable());
        if (10 == strlen($portable)) {
            $this->setPortable(chunk_split($this->getPortable(), 2, ' '));
        }
        $fax = trim($this->getFax());
        if (10 == strlen($fax)) {
            $this->setFax(chunk_split($this->getFax(), 2, ' '));
        }
    }
}
