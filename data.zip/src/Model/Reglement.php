<?php

namespace Model;

use Model\Base\Reglement as BaseReglement;
use Propel\Runtime\Connection\ConnectionInterface;

class Reglement extends BaseReglement
{
    public function preSave(ConnectionInterface $con = null)
    {
        if (!$this->getEtude()->getDateReglement()) {
            $this->getEtude()->setDateReglement($this->getDate());
        }

        return parent::preSave($con);
    }
}
