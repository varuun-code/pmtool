<?php

namespace Model;

use Model\Base\ContactQuery as BaseContactQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Util\PropelCacheTrait;

class ContactQuery extends BaseContactQuery
{
    use PropelCacheTrait;

    public function filterByContactStatus($refSalesForce, $comparison = null): self
    {
        if (count($refSalesForce) > 0) {
            parent::filterByContactStatus($refSalesForce, Criteria::IN);
        }

        return $this;
    }

    public function filterByLanguagePreference($refSalesForce, $comparison = null): self
    {
        if (count($refSalesForce) > 0) {
            parent::filterByLanguagePreference($refSalesForce, Criteria::IN);
        }

        return $this;
    }

    public function filterNameByTerm(array $term): self
    {
        return $this
            ->filterByFirstName($term, Criteria::IN)
            ->_or()
            ->filterByLastName($term, Criteria::IN)
        ;
    }

    public function filterByIsActive(): self
    {
        return $this
            ->useContactStatusQuery()
                ->filterByValue('Active')
            ->endUse();
    }

    public function searchByTerm(string $term): self
    {
        $firstOcc = explode(' ', $term);
        $lastOcc = null;
        $specialChars = ['(', '+'];
        if (is_string($term) && !in_array($term[0], $specialChars)) {
            $lastOcc = (count($firstOcc) > 1) ? trim(str_replace($firstOcc[0], '', $term)) : '';
        }

        return $this
            ->filterByFirstName('%'.$firstOcc[0].'%', Criteria::LIKE)
            ->_or()
            ->filterByLastName('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->_if($lastOcc)
            ->_and()
            ->filterByLastName('%'.$lastOcc.'%', Criteria::LIKE)
            ->_else()
            ->_or()
            ->filterByLastName('%'.$term.'%', Criteria::LIKE)
            ->_endif()
            ->_or()
            ->filterByAccountName('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByTitle('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByEmail('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByAdditionalEmail('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByPhone('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingStreet('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingAddress('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingCity('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingState('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingCountry('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByMailingPostalCode('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherStreet('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherAddress('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherCity('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherState('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherCountry('%'.$term.'%', Criteria::LIKE)
            ->_or()
            ->filterByOtherPostalCode('%'.$term.'%', Criteria::LIKE)
        ;
    }
}
