<?php

namespace Model;

use Model\Base\SiteNotation as BaseSiteNotation;

class SiteNotation extends BaseSiteNotation
{
    private static $instances;

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = SiteNotationQuery::create()->findOneById($id);
    }
}
