<?php

namespace Model;

use Model\Base\Etape as BaseEtape;
use PDO;
use Propel\Runtime\Propel;

class Etape extends BaseEtape
{
    // Values for id column (not ordre)
    const STUDY_CREATION = 1; // to budget
    const ONGOING = 2; // ongoing
    const INVOICED = 3; // invoiced
    const PAID = 4; // paid
    const BUDGET_CREATION = 8; // to confirm
    const TO_INVOICE = 10; // to invoice
    const CANCELLED = 11; // canceled
    const STANDBY = 12; // standby
    const STUDY_FINISHED = 13; // master project finished
    const TO_CONFIRM = 14; // not paid
    // Values for ordre column
    const STUDY_CREATION_ORDER = 1;
    const BUDGET_CREATION_ORDER = 2;
    const TO_CONFIRM_ORDER = 3;
    const ONGOING_ORDER = 4;
    const TO_INVOICE_ORDER = 6;
    const INVOICED_ORDER = 7;
    const PAID_ORDER = 8;
    const CANCELLED_ORDER = 99;
    const STANDBY_ORDER = 98;
    const STUDY_FINISHED_ORDER = 5;

    // FIXME refactor
    const STEPS = ['', 'Master Project Creation', 'Budget creation', 'To Confirm', 'Ongoing', 'Master Project Finished', 'To invoice', 'Invoiced', 'Paid', '', ''];
    const ALLOWED_STEPS = ['Master Project Creation', 'Budget creation', 'To Confirm'];

    private static $etapes = [];
    private static $instances;

    public function __toString(): string
    {
        return $this->etape;
    }

    public static function get($id)
    {
        return self::$etapes[$id] ?? self::$etapes[$id] = EtapeQuery::create()->findOneById($id);
    }

    public static function getAll()
    {
        return self::$instances ?? self::$instances = EtapeQuery::create()
            ->orderByOrdre()
            ->find();
    }

    public function getIdNexEtapeByIdOfCurrentEtape()
    {
        $con = Propel::getConnection();
        $query = 'SELECT ordre FROM ref_etape WHERE ref_etape.id = ?;';
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, $this->id, PDO::PARAM_INT);
        $stmt->execute();
        $ordre = $stmt->fetchColumn();

        $query = 'SELECT id FROM ref_etape WHERE ref_etape.ordre = ?;';
        $stmt = $con->prepare($query);
        $stmt->bindValue(1, ($ordre + 1), PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchColumn();
    }
}
