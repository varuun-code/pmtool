<?php

namespace Model;

use Model\Base\RefSalesForceEtudeSector as BaseRefSalesForceEtudeSector;

class RefSalesForceEtudeSector extends BaseRefSalesForceEtudeSector
{
}
