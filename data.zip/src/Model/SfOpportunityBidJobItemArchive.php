<?php

namespace Model;

use Model\Base\SfOpportunityBidJobItemArchive as BaseSfOpportunityBidJobItemArchive;

class SfOpportunityBidJobItemArchive extends BaseSfOpportunityBidJobItemArchive
{
}
