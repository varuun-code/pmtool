<?php

namespace Model;

use Model\Base\RepondantQuery as BaseRepondantQuery;
use PDO;
use Util\PropelCacheTrait;

class RepondantQuery extends BaseRepondantQuery
{
    use PropelCacheTrait;

    public function filterByNomPrenom($term): self
    {
        return $this
            ->where('CONCAT(nom, " ", prenom) LIKE ?', $term, PDO::PARAM_STR)
            ->_or()
            ->where('CONCAT(prenom, " ", nom) LIKE ?', $term, PDO::PARAM_STR)
        ;
    }
}
