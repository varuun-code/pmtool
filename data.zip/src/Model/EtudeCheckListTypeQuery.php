<?php

namespace Model;

use Model\Base\EtudeCheckListTypeQuery as BaseEtudeCheckListTypeQuery;

class EtudeCheckListTypeQuery extends BaseEtudeCheckListTypeQuery
{
}
