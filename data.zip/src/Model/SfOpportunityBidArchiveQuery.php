<?php

namespace Model;

use Model\Base\SfOpportunityBidArchiveQuery as BaseSfOpportunityBidArchiveQuery;

class SfOpportunityBidArchiveQuery extends BaseSfOpportunityBidArchiveQuery
{
}
