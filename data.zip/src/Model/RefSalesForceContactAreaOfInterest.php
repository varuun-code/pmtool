<?php

namespace Model;

use Model\Base\RefSalesForceContactAreaOfInterest as BaseRefSalesForceContactAreaOfInterest;

class RefSalesForceContactAreaOfInterest extends BaseRefSalesForceContactAreaOfInterest
{
}
