<?php

namespace Model;

use Model\Base\VilleQuery as BaseVilleQuery;

class VilleQuery extends BaseVilleQuery
{
}
