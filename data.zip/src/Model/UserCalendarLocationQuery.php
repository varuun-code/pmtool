<?php

namespace Model;

use Model\Base\UserCalendarLocationQuery as BaseUserCalendarLocationQuery;

class UserCalendarLocationQuery extends BaseUserCalendarLocationQuery
{
}
