<?php

namespace Model;

use Model\Base\SuiviMajTableQuery as BaseSuiviMajTableQuery;

class SuiviMajTableQuery extends BaseSuiviMajTableQuery
{
}
