<?php

namespace Model;

use Model\Base\SiJobTypeQuery as BaseSiJobTypeQuery;
use Propel\Runtime\ActiveQuery\Criteria;

class SiJobTypeQuery extends BaseSiJobTypeQuery
{
    public function filterAndOrderForChoice(): self
    {
        return $this->filterByActive(true)->orderByRank(Criteria::ASC);
    }
}
