<?php

namespace Model;

use Model\Base\ConfirmationQuery as BaseConfirmationQuery;
use Util\PropelFullCacheTrait;

class ConfirmationQuery extends BaseConfirmationQuery
{
    use PropelFullCacheTrait;
}
