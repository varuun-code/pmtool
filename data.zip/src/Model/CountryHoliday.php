<?php

namespace Model;

use Model\Base\CountryHoliday as BaseCountryHoliday;

class CountryHoliday extends BaseCountryHoliday
{
    const CONTRIES_CODE_API_GOOGLE_CALENDAR = [
        'CA' => 'canadian',
        'FR' => 'french',
        'DE' => 'german',
        'ES' => 'spain',
        'US' => 'usa',
        'UK' => 'uk',
        ]
    ;
}
