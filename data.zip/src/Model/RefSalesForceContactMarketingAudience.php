<?php

namespace Model;

use Model\Base\RefSalesForceContactMarketingAudience as BaseRefSalesForceContactMarketingAudience;

class RefSalesForceContactMarketingAudience extends BaseRefSalesForceContactMarketingAudience
{
}
