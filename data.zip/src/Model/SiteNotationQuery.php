<?php

namespace Model;

use Model\Base\SiteNotationQuery as BaseSiteNotationQuery;

class SiteNotationQuery extends BaseSiteNotationQuery
{
}
