<?php

namespace Model;

use Model\Base\RefSalesForceContactMethodologyQuery as BaseRefSalesForceContactMethodologyQuery;

class RefSalesForceContactMethodologyQuery extends BaseRefSalesForceContactMethodologyQuery
{
}
