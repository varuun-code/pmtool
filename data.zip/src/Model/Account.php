<?php

namespace Model;

use Model\Base\Account as BaseAccount;
use Model\Map\AccountTableMap;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Map\TableMap;

class Account extends BaseAccount
{
    const EDITABLE_FIELDS = [
        AccountTableMap::COL_VAT,
        AccountTableMap::COL_DISCOUNT_PROGRAM_ID,
        AccountTableMap::COL_DISCOUNT_PERCENTAGE_ID,
        AccountTableMap::COL_EU_DISCOUNT_PERCENTAGE_ID,
        AccountTableMap::COL_QUANT_DISCOUNT_PERCENTAGE_ID,
        AccountTableMap::COL_DISCOUNT_NOTES,
        AccountTableMap::COL_ACCOUNTING_NOTE,
    ];

    const FIELDS_ISO_DATE = [
        'agreement_start_date',
        'agreement_end_date',
        'last_activity_date',
        'created_date',
        'last_modified_date',
    ];

    const FIELDS_MULTIPICKLIST = [
        'areas_of_researches',
        'country_of_uses',
        'regularly_uses_another_vendor_fors',
        'regularly_uses_sa_fors',
        'products_and_services_useds',
        'agreement_types',
        'sub_types',
    ];

    const FIELDS_PICKLIST = [
        'client_type_id',
        'industry_id',
        'client_source_id',
        'status_id',
        'relationship_status_id',
        'discount_program_id',
        'discount_percentage_id',
        'eu_discount_percentage_id',
        'receive_invoice_via_id',
        'end_client_vertical_id',
        'currency_iso_code_id',
        'quant_discount_percentage_id',
        'pod_quant',
        'pod_qual',
        'quant_discount_program',
        'ar_payment_terms',
        'ai_payment_terms',
    ];

    private static $accounts;
    private static $instances;
    private static $notApplicable;

    private $parent;

    public function __toString(): string
    {
        return (string) $this->getName();
    }

    /**
     * Do NOT use! Load Accounts asynchronously as they are too many!
     */
    public static function getAll()
    {
        return self::$accounts ?? self::$accounts = AccountQuery::create()->orderByName()->find();
    }

    public static function getNotApplicable()
    {
        return self::$notApplicable ?? self::$notApplicable = AccountQuery::create()->findOneByName('Not Applicable');
    }

    public function getAlert()
    {
        $result = [];

        if ($this->getSpreadsheetSops()) {
            $result[] = $this->getSpreadsheetSops();
        }

        if ($this->getFinancialAlert()) {
            $result[] = $this->getFinancialAlert();
        }

        if ($this->getFacilitySops()) {
            $result[] = $this->getFacilitySops();
        }

        return implode("\n", $result);
    }

    public function checkAdressAndDebtorNumber(string $instance = '')
    {
        return !(!$this->getBillingStreet() && !$this->getBillingAddress()) && !('de' == $instance
           && (!$this->getAccountDetail() || ($this->getAccountDetail() && empty($this->getAccountDetail()->getDebtorNumber()))));
    }

    public function getNameforPicklist()
    {
        $fullName = [];

        if (($accountDetail = $this->getAccountDetail()) && $accountDetail->getDebtorNumber()) {
            $fullName[] = $accountDetail->getDebtorNumber();
        }
        if ($this->name) {
            $fullName[] = $this->name;
        }
        if ($this->billing_city) {
            $fullName[] = $this->billing_city;
        }
        if ($this->billing_country) {
            $fullName[] = $this->billing_country;
        }

        return implode(' | ', $fullName);
    }

    public function getParentAccount()
    {
        return $this->parent ?? $this->parent = AccountQuery::create()->filterBySfId($this->parent_id)->findOne();
    }

    public function getIdAndParentIdsAndChildrenIds(): array
    {
        $result = [$this->getId()];

        // we get the parent by **SF** id
        $accountParent = $this->getParentId()
            ? AccountQuery::create()->filterBySfId($this->getParentId())->findOne()
            : null;

        if (null !== $accountParent) {
            $result[] = $accountParent->getId();
        }

        // we get childrens by sf id
        $accountChildrens = $this->getSfId()
            ? AccountQuery::create()->filterByParentId($this->getSfId())->find()
            : [];

        foreach ($accountChildrens as $accountChildren) {
            $result[] = $accountChildren->getId();
        }

        return $result;
    }

    public function preSave(ConnectionInterface $con = null)
    {
        if ('Vendor' == $this->getType() || 'Client/Vendor' == $this->getType()) {
            $city = null;
            if (($zip = $this->getBillingZip()) && $ville = $this->getBillingCity()) {
                $city = VilleQuery::create()
                    ->filterByCp($zip)
                    ->filterByVille($ville)
                    ->findOne();

                if (!$city) {
                    $city = (new Ville())
                        ->setCp($zip)
                        ->setVille($ville);
                    $city->save();
                }
            }
            $fournisseur = $this->getFournisseurs()->getFirst();
            if (!$fournisseur) {
                $fournisseur = (new Fournisseur())
                    ->setAccount($this)
                    ->setActive('Y')
                    ->setEmploye(Fournisseur::EXTERNAL_SUPPLIER)
                    ->setCoefficientId(Coefficient::getIdFromValue('1.00'))
                ;
            }
            $fournisseur
                ->setSociete($this->getNameLegal())
                ->setNom($this->getName())
                ->setTel($this->getPhone())
                ->setFax($this->getFax())
                ->setAdresse($this->getBillingStreet())
                ->setVille($city)
                ->setNumeroEntreprise($this->getVat())
                ->setNationalite($this->getBillingCountry())
                ->save()
            ;
        }

        return parent::preSave();
    }

    /**
     * Retourne l'Account à partir de son id.
     *
     * @param int $id
     */
    public static function getById($id): ?Account
    {
        return self::$instances[$id] ?? self::$instances[$id] = AccountQuery::create()->findOneById($id);
    }

    public static function fieldsScribeToPMTool(): array
    {
        return [
            'Id' => self::getPMToolFieldName(AccountTableMap::COL_SF_ID),
            'RecordTypeId' => self::getPMToolFieldName(AccountTableMap::COL_RECORD_TYPE),
            'Name' => self::getPMToolFieldName(AccountTableMap::COL_NAME),
            'Bad_Payer__c' => self::getPMToolFieldName(AccountTableMap::COL_BAD_PAYER),
            'Legal_Account_Name__c' => self::getPMToolFieldName(AccountTableMap::COL_NAME_LEGAL),
            'ParentId' => self::getPMToolFieldName(AccountTableMap::COL_PARENT_ID),
            'Client_Type__c' => self::getPMToolFieldName(AccountTableMap::COL_CLIENT_TYPE_ID),
            'Multimarket__c' => self::getPMToolFieldName(AccountTableMap::COL_MULTIMARKET),
            'Industry' => self::getPMToolFieldName(AccountTableMap::COL_INDUSTRY_ID),
            'Client_Source__c' => self::getPMToolFieldName(AccountTableMap::COL_CLIENT_SOURCE_ID),
            'Client_Portal_Ready__c' => self::getPMToolFieldName(AccountTableMap::COL_CLIENT_PORTAL_READY),
            'Phone' => self::getPMToolFieldName(AccountTableMap::COL_PHONE),
            'Fax' => self::getPMToolFieldName(AccountTableMap::COL_FAX),
            'Website' => self::getPMToolFieldName(AccountTableMap::COL_WEBSITE),
            'Account_Status__c' => self::getPMToolFieldName(AccountTableMap::COL_STATUS_ID),
            'Last_Job_Completed__c' => self::getPMToolFieldName(AccountTableMap::COL_LAST_JOB_COMPLETED),
            'BillingStreet' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_STREET),
            'BillingAddress' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_ADDRESS),
            'BillingCity' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_CITY),
            'BillingState' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_STATE),
            'BillingPostalCode' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_ZIP),
            'BillingCountry' => self::getPMToolFieldName(AccountTableMap::COL_BILLING_COUNTRY),
            'Account_Team_Lisa__c' => self::getPMToolFieldName(AccountTableMap::COL_TEAM_LISA),
            'Account_Sponsor__c' => self::getPMToolFieldName(AccountTableMap::COL_SPONSOR),
            'X2nd_Qual_Sponsor__c' => self::getPMToolFieldName(AccountTableMap::COL_X2ND_QUAL_SPONSOR),
            'Quant_Sponsor__c' => self::getPMToolFieldName(AccountTableMap::COL_QUANT_SPONSOR),
            'X2nd_Quant_Sponsor__c' => self::getPMToolFieldName(AccountTableMap::COL_X2ND_QUANT_SPONSOR),
            'Relationship_Status__c' => self::getPMToolFieldName(AccountTableMap::COL_RELATIONSHIP_STATUS_ID),
            'Areas_of_Research__c' => 'areas_of_researches',
            'Country_of_Use__c' => 'country_of_uses',
            'Lead_PM__c' => self::getPMToolFieldName(AccountTableMap::COL_LEAD_PM),
            'Regularly_Uses_Another_Vendor_for__c' => 'regularly_uses_another_vendor_fors',
            'Regularly_Uses_SA_for__c' => 'regularly_uses_sa_fors',
            'Products_and_Services_Used__c' => 'products_and_services_useds',
            'NumberOfEmployees' => self::getPMToolFieldName(AccountTableMap::COL_NUMBER_OF_EMPLOYEES),
            'Discount_Program__c' => self::getPMToolFieldName(AccountTableMap::COL_DISCOUNT_PROGRAM_ID),
            'Discount_Percentage__c' => self::getPMToolFieldName(AccountTableMap::COL_DISCOUNT_PERCENTAGE_ID),
            'EU_Discount_Percentage__c' => self::getPMToolFieldName(AccountTableMap::COL_EU_DISCOUNT_PERCENTAGE_ID),
            'Quant_Discount_Percentage__c' => self::getPMToolFieldName(AccountTableMap::COL_QUANT_DISCOUNT_PERCENTAGE_ID),
            'Discount_Notes__c' => self::getPMToolFieldName(AccountTableMap::COL_DISCOUNT_NOTES),
            'PM_Team__c' => self::getPMToolFieldName(AccountTableMap::COL_PM_TEAM),
            'PM_Account_Type__c' => self::getPMToolFieldName(AccountTableMap::COL_PM_ACCOUNT_TYPE),
            'AnnualRevenue' => self::getPMToolFieldName(AccountTableMap::COL_ANNUAL_REVENUE),
            'Field_Manager__c' => self::getPMToolFieldName(AccountTableMap::COL_FIELD_MANAGER),
            'Need_for_PO_Numbers_to_start_recruiting__c' => self::getPMToolFieldName(AccountTableMap::COL_NEED_FOR_PO_NUMBERS_TO_START_RECRUITING),
            'MAS_500_ID__c' => self::getPMToolFieldName(AccountTableMap::COL_MAS_500_ID),
            'AccountNumber' => self::getPMToolFieldName(AccountTableMap::COL_NUMBER),
            'X90_Days_Since_Last_Bid__c' => self::getPMToolFieldName(AccountTableMap::COL_X90_DAYS_SINCE_LAST_BID),
            'X4_Year_Bid__c' => self::getPMToolFieldName(AccountTableMap::COL_X4_YEAR_BID),
            'Bid_Discount_Comments__c' => self::getPMToolFieldName(AccountTableMap::COL_BID_DISCOUNT_COMMENTS),
            'Description' => self::getPMToolFieldName(AccountTableMap::COL_DESCRIPTION),
            'Receive_Invoice_Via__c' => self::getPMToolFieldName(AccountTableMap::COL_RECEIVE_INVOICE_VIA_ID),
            'Do_Not_Solicit__c' => self::getPMToolFieldName(AccountTableMap::COL_DO_NOT_SOLICIT),
            'Free_DVD__c' => self::getPMToolFieldName(AccountTableMap::COL_FREE_DVD),
            'Credit_Hold__c' => self::getPMToolFieldName(AccountTableMap::COL_CREDIT_HOLD),
            'Credit_Terms__c' => self::getPMToolFieldName(AccountTableMap::COL_CREDIT_TERMS),
            'VAT__c' => self::getPMToolFieldName(AccountTableMap::COL_VAT),
            'Facility_Average_Score__c' => self::getPMToolFieldName(AccountTableMap::COL_FACILITY_AVERAGE_SCORE),
            'Recruit_Average_Score__c' => self::getPMToolFieldName(AccountTableMap::COL_RECRUIT_AVERAGE_SCORE),
            'PM_Average_Score__c' => self::getPMToolFieldName(AccountTableMap::COL_PM_AVERAGE_SCORE),
            'Conversion_Rate__c' => self::getPMToolFieldName(AccountTableMap::COL_CONVERSION_RATE),
            'Facility_Average_Score3__c' => self::getPMToolFieldName(AccountTableMap::COL_FACILITY_AVERAGE_SCORE_3),
            'Recruit_Average_Score3__c' => self::getPMToolFieldName(AccountTableMap::COL_RECRUIT_AVERAGE_SCORE_3),
            'PM_Average_Score3__c' => self::getPMToolFieldName(AccountTableMap::COL_PM_AVERAGE_SCORE_3),
            'Agreement_Type__c' => 'agreement_types',
            'Terms_Conditions__c' => self::getPMToolFieldName(AccountTableMap::COL_TERMS_CONDITIONS),
            'Agreement_Start_Date__c' => self::getPMToolFieldName(AccountTableMap::COL_AGREEMENT_START_DATE),
            'Agreement_End_Date__c' => self::getPMToolFieldName(AccountTableMap::COL_AGREEMENT_END_DATE),
            'Spreadsheet_SOPs__c' => self::getPMToolFieldName(AccountTableMap::COL_SPREADSHEET_SOPS),
            'Financial_Alert__c' => self::getPMToolFieldName(AccountTableMap::COL_FINANCIAL_ALERT),
            'Facility_SOPs__c' => self::getPMToolFieldName(AccountTableMap::COL_FACILITY_SOPS),
            'Training_Information__c' => self::getPMToolFieldName(AccountTableMap::COL_TRAINING_INFORMATION),
            'RR__c' => self::getPMToolFieldName(AccountTableMap::COL_RR),
            'SS__c' => self::getPMToolFieldName(AccountTableMap::COL_SS),
            'High_Alert__c' => self::getPMToolFieldName(AccountTableMap::COL_HIGH_ALERT),
            'Notes__c' => self::getPMToolFieldName(AccountTableMap::COL_NOTES),
            'No_AI_Needed__c' => self::getPMToolFieldName(AccountTableMap::COL_NO_AI_NEEDED),
            'Octopuce_Record_ID__c' => self::getPMToolFieldName(AccountTableMap::COL_OCTOPUCE_RECORD_ID),
            'Top_150__c' => self::getPMToolFieldName(AccountTableMap::COL_TOP_150),
            'Team__c' => self::getPMToolFieldName(AccountTableMap::COL_TEAM),
            'COE__c' => self::getPMToolFieldName(AccountTableMap::COL_COE),
            'End_Client_Vertical__c' => self::getPMToolFieldName(AccountTableMap::COL_END_CLIENT_VERTICAL_ID),
            'Account_Owner_Profile_Name__c' => self::getPMToolFieldName(AccountTableMap::COL_OWNER_PROFILE_NAME),
            'Other__c' => self::getPMToolFieldName(AccountTableMap::COL_OTHER),
            'CurrencyIsoCode' => self::getPMToolFieldName(AccountTableMap::COL_CURRENCY_ISO_CODE_ID),
            'Account_Division__c' => self::getPMToolFieldName(AccountTableMap::COL_DIVISION),
            'IsPersonAccount' => self::getPMToolFieldName(AccountTableMap::COL_IS_PERSON_ACCOUNT),
            'of_Bids_YTD__c' => self::getPMToolFieldName(AccountTableMap::COL_OF_BIDS_YTD),
            'rrpu__Alert_Message__c' => self::getPMToolFieldName(AccountTableMap::COL_ALERT_MESSAGE),
            'Pharmaceutical__c' => self::getPMToolFieldName(AccountTableMap::COL_PHARMACEUTICAL),
            'Average_Rating__c' => self::getPMToolFieldName(AccountTableMap::COL_AVERAGE_RATING),
            'Client_ID__c' => self::getPMToolFieldName(AccountTableMap::COL_CLIENT_ID),
            'CMS_Client_ID__c' => self::getPMToolFieldName(AccountTableMap::COL_CMS_CLIENT_ID),
            'CreatedById' => self::getPMToolFieldName(AccountTableMap::COL_CREATE_BY_ID),
            'CreatedDate' => self::getPMToolFieldName(AccountTableMap::COL_CREATED_DATE),
            'LastModifiedById' => self::getPMToolFieldName(AccountTableMap::COL_LAST_MODIFIED_BY_ID),
            'LastActivityDate' => self::getPMToolFieldName(AccountTableMap::COL_LAST_ACTIVITY_DATE),
            'LastModifiedDate' => self::getPMToolFieldName(AccountTableMap::COL_LAST_MODIFIED_DATE),
            'Staff_Preferences__c' => self::getPMToolFieldName(AccountTableMap::COL_STAFF_PREFERENCES),
            'SicDesc' => self::getPMToolFieldName(AccountTableMap::COL_SIC_DESCRIPTION),
            'AccountSource' => self::getPMToolFieldName(AccountTableMap::COL_SOURCE),
            'Rebate' => self::getPMToolFieldName(AccountTableMap::COL_REBATE),
            'Type' => self::getPMToolFieldName(AccountTableMap::COL_TYPE),
            'accounting_note' => self::getPMToolFieldName(AccountTableMap::COL_ACCOUNTING_NOTE),
            'flat_rate' => self::getPMToolFieldName(AccountTableMap::COL_FLAT_RATE),
            'discount_token_max' => self::getPMToolFieldName(AccountTableMap::COL_DISCOUNT_TOKEN_MAX),
            'discount_token_count' => self::getPMToolFieldName(AccountTableMap::COL_DISCOUNT_TOKEN_COUNT),
        ];
    }

    public static function getPMToolFieldName($fieldName)
    {
        return AccountTableMap::translateFieldName($fieldName, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME);
    }

    public function getFullName()
    {
        return $this->getSfId().' ('.$this->getName().')';
    }

    public function isDeleteable()
    {
        if ($this->countEtudesRelatedByAccountId()) {
            return false;
        }

        if ($this->countEtudesRelatedByEndClientId()) {
            return false;
        }

        if ($this->countEtudesRelatedByIntermediateClientId()) {
            return false;
        }

        if ($this->countEtudeMasters()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByAccountId()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByEndClientId()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByEndClientRepId()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByIntermediateClientId()) {
            return false;
        }

        if ($this->countCalculs()) {
            return false;
        }

        return !$this->countRepondantBlacklistRepondants();
    }

    public function replaceBy(Account $account): self
    {
        $sfId = $account->getSfId();

        foreach ($this->getEtudesRelatedByAccountId() as $etude) {
            $etude->setAccount($account)->save();
        }

        foreach ($this->getEtudesRelatedByEndClientId() as $etude) {
            $etude->setEndClient($account)->save();
        }

        foreach ($this->getEtudesRelatedByIntermediateClientId() as $etude) {
            $etude->setIntermediateClient($this)->save();
        }

        foreach ($this->getEtudeMasters() as $etude) {
            $etude->setAccount($account)->save();
        }

        foreach ($this->getOpportunitiesRelatedByAccountId() as $opportunity) {
            $opportunity->setAccount($account)->setAccountSfId($sfId)->save();
        }

        foreach ($this->getOpportunitiesRelatedByEndClientId() as $opportunity) {
            $opportunity->setEndClient($account)->setEndClientSfId($sfId)->save();
        }

        foreach ($this->getOpportunitiesRelatedByEndClientRepId() as $opportunity) {
            $opportunity->setEndClientRep($account)->setEndClientRepSfId($sfId)->save();
        }

        foreach ($this->getOpportunitiesRelatedByIntermediateClientId() as $opportunity) {
            $opportunity->setIntermediateClient($account)->save();
        }

        foreach ($this->getContacts() as $contact) {
            $contact->setAccount($account)->setAccountSfId($sfId)->setAccountName($account->getName())->save();
        }

        foreach ($this->getCalculs() as $calcul) {
            $calcul->setAccount($account)->save();
        }

        foreach ($this->getAccountBlacklistRepondants() as $blacklist) {
            $blacklist->setRepondantBlacklistAccount($account)->save();
        }

        foreach ($this->getEvents() as $event) {
            $event->setAccount($account)->setAccountSfId($sfId)->save();
        }

        if ($newFournisseur = $account->getFournisseurs()->getFirst()) {
            foreach ($this->getFournisseurs() as $fournisseur) {
                $fournisseur->replaceBy($newFournisseur)->delete();
            }
        } else {
            foreach ($this->getFournisseurs() as $fournisseur) {
                $fournisseur->setAccount($account)->save();
            }
        }

        $this->reload(true);

        return $this;
    }

    public function toXMLForSalesForce()
    {
        $array = [];
        foreach ($this->toArrayWithCollection() as $key => $value) {
            if (is_bool($value)) {
                $value = (int) $value;
            } elseif ($value instanceof \DateTime) {
                $value = in_array($key, self::FIELDS_ISO_DATE) ? $value->format('Y-m-d\TH:i:s.uP') : $value->format('Y-m-d');
            } elseif (in_array($key, self::FIELDS_MULTIPICKLIST)) {
                if ($value) {
                    $multiplePickListValues = [];
                    $refs = RefSalesForceQuery::create()->filterById($value)->find();
                    foreach ($refs as $ref) {
                        $multiplePickListValues[] = $ref->getValue();
                    }
                    $value = implode(';', $multiplePickListValues);
                } else {
                    $value = '';
                }
            } elseif (in_array($key, self::FIELDS_PICKLIST) && $value) {
                if ($ref = RefSalesForceQuery::create()->filterById($value)->findOne()) {
                    $value = $ref->getValue();
                }
            }
            $array[self::getFieldNamePmtoolToSalesForce($key)] = $value;
        }

        $xml = PHP_EOL.'<Account>'.PHP_EOL;
        foreach ($array as $key => $value) {
            $xml .= (null === $value || '' === $value || 'pmtool_id' == $key) ? "<{$key}>{$value}</{$key}>".PHP_EOL : "<{$key}><![CDATA[{$value}]]></{$key}>".PHP_EOL;
        }

        return $xml.'</Account>';
    }

    public function toArrayForForm(): array
    {
        $array = [];

        foreach ($this->toArrayWithCollection() as $key => $value) {
            if ($value instanceof \DateTime) {
                $value = in_array($key, self::FIELDS_ISO_DATE) ? $value->format('Y-m-d\TH:i:s.uP') : $value->format('Y-m-d');
            }
            $array[$key] = $value;
        }

        return $array;
    }

    public static function getFieldNamePmtoolToSalesForce($consumedField)
    {
        $scribeFields = array_flip(self::fieldsScribeToPMTool());
        $scribeFields[self::getPMToolFieldName(AccountTableMap::COL_ID)] = 'pmtool_id';

        return isset($scribeFields[$consumedField]) && $scribeFields[$consumedField] ? $scribeFields[$consumedField] : $consumedField;
    }

    public static function getFieldNameSalesForceToPmtool($salesForceField)
    {
        $PMToolFields = self::fieldsScribeToPMTool();

        return isset($PMToolFields[$salesForceField]) && $PMToolFields[$salesForceField] ? $PMToolFields[$salesForceField] : $salesForceField;
    }

    public function toArrayWithCollection()
    {
        $result = [
            'id' => $this->getId(),
            'api_created_date' => $this->getApiCreatedDate(),
            'api_updated_date' => $this->getApiUpdatedDate(),
            'pmtool_created_date' => $this->getPmtoolCreatedDate(),
            'pmtool_updated_date' => $this->getPmtoolUpdatedDate(),
            'sf_id' => $this->getSfId(),
            'parent_id' => $this->getParentId(),
            'is_person_account' => $this->getIsPersonAccount(),
            'record_type' => $this->getRecordType(),
            'name' => $this->getName(),
            'name_legal' => $this->getNameLegal(),
            'owner_profile_name' => $this->getOwnerProfileName(),
            'type' => $this->getType(),
            'cms_client_id' => $this->getCmsClientId(),
            'client_id' => $this->getClientId(),
            'client_type_id' => $this->getClientTypeId(),
            'client_source_id' => $this->getClientSourceId(),
            'client_portal_ready' => $this->getClientPortalReady(),
            'multimarket' => $this->getMultimarket(),
            'industry_id' => $this->getIndustryId(),
            'phone' => $this->getPhone(),
            'fax' => $this->getFax(),
            'website' => $this->getWebSite(),
            'status_id' => $this->getStatusId(),
            'bad_payer' => $this->getBadPayer(),
            'last_job_completed' => $this->getLastJobCompleted(),
            'number_of_employees' => $this->getNumberOfEmployees(),
            'staff_preferences' => $this->getStaffPreferences(),
            'billing_street' => $this->getBillingStreet(),
            'billing_address' => $this->getBillingAddress(),
            'billing_city' => $this->getBillingCity(),
            'billing_state' => $this->getBillingState(),
            'billing_zip' => $this->getBillingZip(),
            'billing_country' => $this->getBillingCountry(),
            'team' => $this->getTeam(),
            'team_lisa' => $this->getTeamLisa(),
            'sponsor' => $this->getSponsor(),
            'quant_sponsor' => $this->getQuantSponsor(),
            'x2nd_qual_sponsor' => $this->getX2ndQualSponsor(),
            'x2nd_quant_sponsor' => $this->getX2ndQuantSponsor(),
            'relationship_status_id' => $this->getRelationshipStatusId(),
            'discount_program_id' => $this->getDiscountProgramId(),
            'discount_percentage_id' => $this->getDiscountPercentageId(),
            'eu_discount_percentage_id' => $this->getEuDiscountPercentageId(),
            'quant_discount_percentage_id' => $this->getQuantDiscountPercentageId(),
            'discount_notes' => $this->getDiscountNotes(),
            'lead_pm' => $this->getLeadPm(),
            'pm_team' => $this->getPmTeam(),
            'pm_account_type' => $this->getPmAccountType(),
            'pm_average_score' => $this->getPmAverageScore(),
            'pm_average_score_3' => $this->getPmAverageScore3(),
            'annual_revenue' => $this->getAnnualRevenue(),
            'annual_revenue_converted' => $this->getAnnualRevenueConverted(),
            'annual_revenue_currency' => $this->getAnnualRevenueCurrency(),
            'annual_revenue_converted_currency' => $this->getAnnualRevenueConvertedCurrency(),
            'field_Manager' => $this->getFieldManager(),
            'mas_500_id' => $this->getMas500Id(),
            'number' => $this->getNumber(),
            'x90_days_since_last_bid' => $this->getX90DaysSinceLastBid(),
            'x4_year_bid' => $this->getX4YearBid(),
            'bid_discount_comments' => $this->getBidDiscountComments(),
            'of_bids_ytd' => $this->getOfBidsYtd(),
            'description' => $this->getDescription(),
            'receive_invoice_via_id' => $this->getReceiveInvoiceViaId(),
            'do_not_solicit' => $this->getDoNotSolicit(),
            'free_dvd' => $this->getFreeDvd(),
            'credit_hold' => $this->getCreditHold(),
            'credit_terms' => $this->getCreditTerms(),
            'vat' => $this->getVat(),
            'conversion_rate' => $this->getConversionRate(),
            'facility_average_score' => $this->getFacilityAverageScore(),
            'facility_average_score_3' => $this->getFacilityAverageScore3(),
            'recruit_average_score' => $this->getRecruitAverageScore(),
            'recruit_average_score_3' => $this->getRecruitAverageScore3(),
            'average_rating' => $this->getAverageRating(),
            'need_for_po_numbers_to_start_recruiting' => $this->getNeedForPoNumbersToStartRecruiting(),
            'terms_conditions' => $this->getTermsConditions(),
            'agreement_start_date' => $this->getAgreementStartDate(),
            'agreement_end_date' => $this->getAgreementEndDate(),
            'spreadsheet_sops' => $this->getSpreadsheetSops(),
            'financial_alert' => $this->getFinancialAlert(),
            'facility_sops' => $this->getFacilitySops(),
            'training_information' => $this->getTrainingInformation(),
            'rr' => $this->getRR(),
            'ss' => $this->getSS(),
            'notes' => $this->getNotes(),
            'no_ai_needed' => $this->getNoAiNeeded(),
            'octopuce_record_id' => $this->getOctopuceRecordId(),
            'top_150' => $this->getTop150(),
            'coe' => $this->getCoe(),
            'end_client_vertical_id' => $this->getEndClientVerticalId(),
            'other' => $this->getOther(),
            'currency_iso_code_id' => $this->getCurrencyIsoCodeId(),
            'division' => $this->getDivision(),
            'high_alert' => $this->getHighAlert(),
            'alert_message' => $this->getAlertMessage(),
            'pharmaceutical' => $this->getPharmaceutical(),
            'rebate' => $this->getRebate(),
            'last_modified_by_id' => $this->getLastModifiedById(),
            'source' => $this->getSource(),
            'sic_description' => $this->getSicDescription(),
            'last_activity_date' => $this->getLastActivityDate(),
            'last_modified_date' => $this->getLastModifiedDate(),
            'create_by_id' => $this->getCreateById(),
            'created_date' => $this->getCreatedDate(),
            'pmtool_updated' => $this->getPmtoolUpdated(),
            'accounting_note' => $this->getAccountingNote(),
            'flat_rate' => $this->getFlatRate(),
            'sponsor_2020' => $this->getSponsor2020(),
            'aspen_finn_sponsor' => $this->getAspenFinnSponsor(),
            'accounting_email' => $this->getAccountingEmail(),
            'accounting_attn' => $this->getAccountingAttn(),
            'pod_qual' => $this->getPodQualId(),
            'pod_quant' => $this->getPodQuantId(),
            'quant_discount_program' => $this->getQuantDiscountProgram() ? $this->getQuantDiscountProgram()->getValue() : '',
            'discount_token_count' => $this->getDiscountTokenCount(),
            'discount_token_max' => $this->getDiscountTokenMax(),
            'ar_payment_terms' => $this->getArPaymentTerms(),
            'ai_payment_terms' => $this->getAiPaymentTerms(),
        ];
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }
        $result['areas_of_researches'] = [];
        $result['country_of_uses'] = [];
        $result['regularly_uses_another_vendor_fors'] = [];
        $result['regularly_uses_sa_fors'] = [];
        $result['products_and_services_useds'] = [];
        $result['agreement_types'] = [];
        $result['sub_types'] = [];
        foreach ($this->getRefSalesForceAccountRefAreasOfResearches() as $value) {
            $result['areas_of_researches'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefCountryOfUses() as $value) {
            $result['country_of_uses'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefRegularlyUsesAnotherVendorFors() as $value) {
            $result['regularly_uses_another_vendor_fors'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefRegularlyUsesSaFors() as $value) {
            $result['regularly_uses_sa_fors'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefProductsAndServicesUseds() as $value) {
            $result['products_and_services_useds'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefAgreementTypes() as $value) {
            $result['agreement_types'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceAccountRefSubTypes() as $value) {
            $result['sub_types'][] = $value->getId();
        }

        return $result;
    }

    public function getClientDiscountPercentageByInstance(string $instance = '')
    {
        $discountPercentage = 0;
        $endClientdiscountProgram = $this->getDiscountProgram() ? $this->getDiscountProgram()->getValue() : null;
        if ('us' == $instance || !in_array($endClientdiscountProgram, Job::QUAL_EU_PROGRAMS)) {
            if ($this->getDiscountPercentage()) {
                $discountPercentage = $this->getDiscountPercentage()->getValue();
            }
        } else {
            if ($this->getEuDiscountPercentage()) {
                $discountPercentage = $this->getEuDiscountPercentage()->getValue();
            }
        }

        return $discountPercentage;
    }
}
