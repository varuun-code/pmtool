<?php

namespace Model;

use Model\Base\EtudeMaster as BaseEtudeMaster;

class EtudeMaster extends BaseEtudeMaster
{
}
