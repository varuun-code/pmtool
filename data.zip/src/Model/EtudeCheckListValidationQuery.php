<?php

namespace Model;

use Model\Base\EtudeCheckListValidationQuery as BaseEtudeCheckListValidationQuery;

class EtudeCheckListValidationQuery extends BaseEtudeCheckListValidationQuery
{
}
