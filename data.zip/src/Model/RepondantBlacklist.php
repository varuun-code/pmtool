<?php

namespace Model;

use Model\Base\RepondantBlacklist as BaseRepondantBlacklist;

class RepondantBlacklist extends BaseRepondantBlacklist
{
}
