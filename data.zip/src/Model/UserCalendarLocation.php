<?php

namespace Model;

use Model\Base\UserCalendarLocation as BaseUserCalendarLocation;

class UserCalendarLocation extends BaseUserCalendarLocation
{
}
