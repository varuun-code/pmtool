<?php

namespace Model;

use Model\Base\SfOpportunityBidArchive as BaseSfOpportunityBidArchive;

class SfOpportunityBidArchive extends BaseSfOpportunityBidArchive
{
}
