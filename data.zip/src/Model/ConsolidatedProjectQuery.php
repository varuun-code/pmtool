<?php

namespace Model;

use Model\Base\ConsolidatedProjectQuery as BaseConsolidatedProjectQuery;

class ConsolidatedProjectQuery extends BaseConsolidatedProjectQuery
{
}
