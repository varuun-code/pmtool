<?php

namespace Model;

use Model\Base\SpocDatas as BaseSpocDatas;

class SpocDatas extends BaseSpocDatas
{
}
