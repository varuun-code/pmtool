<?php

namespace Model;

use Model\Base\EventMethodologyQuery as BaseEventMethodologyQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Util\PropelFullCacheTrait;

class EventMethodologyQuery extends BaseEventMethodologyQuery
{
    use PropelFullCacheTrait;

    public function filterAndOrderForChoice(): self
    {
        return $this->filterByActive(true)->orderByRank(Criteria::ASC);
    }
}
