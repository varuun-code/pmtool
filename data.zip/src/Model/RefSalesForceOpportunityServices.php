<?php

namespace Model;

use Model\Base\RefSalesForceOpportunityServices as BaseRefSalesForceOpportunityServices;

class RefSalesForceOpportunityServices extends BaseRefSalesForceOpportunityServices
{
}
