<?php

namespace Model;

use Model\Base\SampleSourceQuery as BaseSampleSourceQuery;
use Propel\Runtime\ActiveQuery\Criteria;

class SampleSourceQuery extends BaseSampleSourceQuery
{
    public function filterAndOrderForChoice(): self
    {
        return $this->filterByActif(true)->orderByRank(Criteria::ASC);
    }
}
