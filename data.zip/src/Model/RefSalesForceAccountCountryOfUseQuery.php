<?php

namespace Model;

use Model\Base\RefSalesForceAccountCountryOfUseQuery as BaseRefSalesForceAccountCountryOfUseQuery;

class RefSalesForceAccountCountryOfUseQuery extends BaseRefSalesForceAccountCountryOfUseQuery
{
}
