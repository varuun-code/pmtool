<?php

namespace Model;

use Model\Base\RefSalesForceContactContactSource as BaseRefSalesForceContactContactSource;

class RefSalesForceContactContactSource extends BaseRefSalesForceContactContactSource
{
}
