<?php

namespace Model;

use Model\Base\CoefficientQuery as BaseCoefficientQuery;

class CoefficientQuery extends BaseCoefficientQuery
{
}
