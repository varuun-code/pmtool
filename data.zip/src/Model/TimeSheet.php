<?php

namespace Model;

use Model\Base\TimeSheet as BaseTimeSheet;

class TimeSheet extends BaseTimeSheet
{
}
