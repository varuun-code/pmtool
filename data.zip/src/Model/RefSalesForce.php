<?php

namespace Model;

use Model\Base\RefSalesForce as BaseRefSalesForce;
use Model\Map\RefSalesForceTableMap;

class RefSalesForce extends BaseRefSalesForce
{
    const SECTOR_MEDICAL = 'Medical';
    const SECTOR_B2B = 'B2B';
    const RESP_TYPE_CATEGORY = ['Medical', 'Payer', 'Patient', 'B2B'];

    const JOB_QUALIFICATION_KOL = 'KOL (MedQuery/Advisors)';
    const JOB_QUALIFICATION_QUAL = 'Qual';
    const JOB_QUALIFICATION_QUANT = 'Quantitative';
    const JOB_QUALIFICATION_QUANT_TRADITIONAL = 'Quant - Traditional - Field';
    const JOB_QUALIFICATION_QUANT_ONLINE = 'Quant - Online';

    const JOB_STATUS_ACTIVE = 'Active';
    const JOB_STATUS_CANCELLED_BILLED = 'Cancelled-Billed';
    const JOB_STATUS_CANCELLED_NON_BILLED = 'Cancelled-Non-Billed';
    const JOB_STATUS_CLOSED = 'Closed';
    const JOB_STATUS_CONFIRMED = 'Confirmed';
    const JOB_STATUS_POSTPONED = 'Postponed';
    const JOB_STATUS_TENTATIVE = 'Tentative';

    const JOB_STATUSES_DOCUMENTS = [
        self::JOB_STATUS_ACTIVE,
        self::JOB_STATUS_CANCELLED_BILLED,
        self::JOB_STATUS_CONFIRMED,
        self::JOB_STATUS_CLOSED,
    ];

    const JOB_STATUSES_SALESFORCE = [
        self::JOB_STATUS_ACTIVE,
        self::JOB_STATUS_CANCELLED_BILLED,
        self::JOB_STATUS_CONFIRMED,
    ];

    private static $closedWon;
    private static $currency = [];
    private static $respondentTypeCategories;
    private static $respondentLocation;

    public static function getRespondentTypeCategories()
    {
        return self::$respondentTypeCategories ?? self::$respondentTypeCategories = RefSalesForceQuery::create()
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField('sectors')
            ->filterByActif(true)
            ->find();
    }

    public static function getInstanceRespLocation(string $instance = '')
    {
        switch ($instance) {
            case 'fr':
                $respLocation = 'FR';
                break;
            case 'de':
                $respLocation = 'DE';
                break;
            case 'es':
                $respLocation = 'ES';
                break;
            case 'us':
                $respLocation = 'US';
                break;
            case 'uk':
            default:
                $respLocation = null;
                break;
        }

        return self::$respondentLocation ?? self::$respondentLocation = RefSalesForceQuery::create()
            ->filterByActif(true)
            ->filterByField('respondent_location_id')
            ->filterByValue($respLocation)
            ->findOne();
    }

    public static function getCurrencyCode(string $instance = '')
    {
        switch ($instance) {
            case 'fr':
                return 'EUR';
            case 'de':
                return 'EUR';
            case 'es':
                return 'EUR';
            case 'uk':
                return 'GBP';
            case 'us':
                return 'USD';
            default:
                return '';
        }
    }

    public static function getCurrency(string $instance = '')
    {
        $currency_val = self::getCurrencyCode($instance);

        return self::$currency[$instance] ?? self::$currency[$instance] = RefSalesForceQuery::create()->filterByTable('opportunity')->findOneByValue($currency_val);
    }

    /**
     * @return string
     */
    public function __toString(): string
    {
        return $this->getValue();
    }

    public static function findRefSalesforceId($table, $field, $value)
    {
        $ref = RefSalesForceQuery::create()
            ->filterByTable($table)
            ->filterByField($field)
            ->filterByValue($value)
            ->findOne();

        return $ref ? $ref->getId() : null;
    }

    public static function getClosedWon()
    {
        return self::$closedWon ?: self::$closedWon = self::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'Closed Won');
    }

    public static function getNoBidId()
    {
        return self::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'No Bid');
    }

    public static function getMCBidId()
    {
        return self::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'MC Bid');
    }

    public static function getMCWonId()
    {
        return self::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'MC Won');
    }

    public static function getJobQualification(string $value)
    {
        return RefSalesForceQuery::create()
            ->select('id')
            ->filterByField('job_qualification_id')
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->findByValue($value)->getFirst();
    }

    public static function getCountryCode()
    {
        $countyCodes = RefSalesForceQuery::create()->filterByActif(true)->filterByField('respondent_location_id');
        $countryOptions = [];
        foreach ($countyCodes as $code) {
            $countryOptions[$code->getValue()] = $code->getValue();
        }

        return $countryOptions;
    }
}
