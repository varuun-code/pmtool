<?php

namespace Model;

use Model\Base\RefSalesForceAccountSubType as BaseRefSalesForceAccountSubType;

class RefSalesForceAccountSubType extends BaseRefSalesForceAccountSubType
{
}
