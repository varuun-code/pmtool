<?php

namespace Model;

use Model\Base\RepondantQuotaQuery as BaseRepondantQuotaQuery;

class RepondantQuotaQuery extends BaseRepondantQuotaQuery
{
}
