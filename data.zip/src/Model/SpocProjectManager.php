<?php

namespace Model;

use Model\Base\SpocProjectManager as BaseSpocProjectManager;

class SpocProjectManager extends BaseSpocProjectManager
{
}
