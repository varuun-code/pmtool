<?php

namespace Model;

use Model\Base\EventQuery as BaseEventQuery;

class EventQuery extends BaseEventQuery
{
}
