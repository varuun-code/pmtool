<?php

namespace Model;

use Model\Base\RefSalesForceQuery as BaseRefSalesForceQuery;
use Model\Map\RefSalesForceTableMap;
use Util\PropelFullCacheTrait;

class RefSalesForceQuery extends BaseRefSalesForceQuery
{
    use PropelFullCacheTrait;

    public function filterByActiveAccountField(string $field): self
    {
        return $this
            ->filterByAccountField($field)
            ->filterByActif(true)
        ;
    }

    public function filterByActiveContactField(string $field): self
    {
        return $this
            ->filterByContactField($field)
            ->filterByActif(true)
        ;
    }

    public function filterByAccountField(string $field): self
    {
        return $this
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
            ->filterByField($field)
        ;
    }

    public function filterByActiveOpportunityField(string $field): self
    {
        return $this
            ->filterByOpportunityField($field)
            ->filterByActif(true)
        ;
    }

    public function filterByActiveProjectField(string $field): self
    {
        return $this
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_ETUDE)
            ->filterByField($field)
            ->filterByActif(true)
        ;
    }

    public function filterByContactField(string $field): self
    {
        return $this
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
            ->filterByField($field)
        ;
    }

    public function filterByOpportunityField(string $field): self
    {
        return $this
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
            ->filterByField($field)
        ;
    }
}
