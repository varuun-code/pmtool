<?php

namespace Model;

use Model\Base\RefSalesForceAccountSubTypeQuery as BaseRefSalesForceAccountSubTypeQuery;

class RefSalesForceAccountSubTypeQuery extends BaseRefSalesForceAccountSubTypeQuery
{
}
