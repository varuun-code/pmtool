<?php

namespace Model;

use Model\Base\RefSalesForceContactContactSourceQuery as BaseRefSalesForceContactContactSourceQuery;

class RefSalesForceContactContactSourceQuery extends BaseRefSalesForceContactContactSourceQuery
{
}
