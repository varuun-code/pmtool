<?php

namespace Model;

use Model\Base\Contact as BaseContact;
use Model\Map\ContactTableMap;
use Propel\Runtime\Map\TableMap;

class Contact extends BaseContact
{
    const FIELDS_ISO_DATE = [
        'birthdate',
        'last_activity',
        'last_modified_dts',
        'last_cu_request_date',
        'last_cu_update_date',
        'created_date',
        'last_modified_date',
        'last_activity_date',
        'last_modified_dts',
        'system_modstamp',
    ];

    const FIELDS_MULTIPICKLIST = [
        'schlesinger_eventss',
        'possible_primary_job_locations',
        'area_of_interests',
        'methodologies',
        'contact_sources',
        'marketing_audiences',
    ];

    const FIELDS_PICKLIST = [
        'salutation_id',
        'added_by_id',
        'contact_status_id',
        'language_preference_id',
        'the_wall_id',
        'gift_code_id',
        'lead_source_id',
        'currency_iso_code_id',
        'tw_lead_source_id',
    ];

    private static $instances;

    public static function getById($id)
    {
        return self::$instances[$id] ?? self::$instances[$id] = ContactQuery::create()->findOneById($id);
    }

    public function __toString(): string
    {
        return $this->getNomComplet();
    }

    public static function fieldsScribeToPMTool()
    {
        return [
            'Id' => self::getPMToolFieldName(ContactTableMap::COL_SF_ID),
            'AccountId' => self::getPMToolFieldName(ContactTableMap::COL_ACCOUNT_SF_ID),
            'Salutation' => self::getPMToolFieldName(ContactTableMap::COL_SALUTATION_ID),
            'FirstName' => self::getPMToolFieldName(ContactTableMap::COL_FIRST_NAME),
            'LastName' => self::getPMToolFieldName(ContactTableMap::COL_LAST_NAME),
            'Added_By__c' => self::getPMToolFieldName(ContactTableMap::COL_ADDED_BY_ID),
            'AccountName__c' => self::getPMToolFieldName(ContactTableMap::COL_ACCOUNT_NAME),
            'Title' => self::getPMToolFieldName(ContactTableMap::COL_TITLE),
            'LinkedIn__c' => self::getPMToolFieldName(ContactTableMap::COL_LINKEDIN),
            'Contact_Status__c' => self::getPMToolFieldName(ContactTableMap::COL_CONTACT_STATUS_ID),
            'Primary_Contact__c' => self::getPMToolFieldName(ContactTableMap::COL_PRIMARY_CONTACT),
            'Image_Name__c' => self::getPMToolFieldName(ContactTableMap::COL_IMAGE_NAME),
            'Contact_Preferences__c' => self::getPMToolFieldName(ContactTableMap::COL_CONTACT_PREFERENCES),
            'Moderator__c' => self::getPMToolFieldName(ContactTableMap::COL_MODERATOR),
            'No_Client_Portal__c' => self::getPMToolFieldName(ContactTableMap::COL_NO_CLIENT_PORTAL),
            'Phone' => self::getPMToolFieldName(ContactTableMap::COL_PHONE),
            'Fax' => self::getPMToolFieldName(ContactTableMap::COL_FAX),
            'MobilePhone' => self::getPMToolFieldName(ContactTableMap::COL_MOBILE_PHONE),
            'Email' => self::getPMToolFieldName(ContactTableMap::COL_EMAIL),
            'CanBeDuplicated' => self::getPMToolFieldName(ContactTableMap::COL_CAN_BE_DUPLICATED),
            'Company_Influencer__c' => self::getPMToolFieldName(ContactTableMap::COL_COMPANY_INFLUENCER),
            'Additional_Email__c' => self::getPMToolFieldName(ContactTableMap::COL_ADDITIONAL_EMAIL),
            'ReportsToId' => self::getPMToolFieldName(ContactTableMap::COL_REPORTS_TO_ID),
            'HasOptedOutOfEmail' => self::getPMToolFieldName(ContactTableMap::COL_HAS_OPTED_OUT_OF_EMAIL),
            'Do_Not_Solicit__c' => self::getPMToolFieldName(ContactTableMap::COL_DO_NOT_SOLICIT),
            'Client_Space_Log_In__c' => self::getPMToolFieldName(ContactTableMap::COL_CLIENT_SPACE_LOG_IN),
            'Client_Space_Tour__c' => self::getPMToolFieldName(ContactTableMap::COL_CLIENT_SPACE_TOUR),
            'MailingStreet' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_STREET),
            'MailingAddress' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_ADDRESS),
            'MailingCity' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_CITY),
            'MailingState' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_STATE),
            'MailingPostalCode' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_POSTAL_CODE),
            'MailingCountry' => self::getPMToolFieldName(ContactTableMap::COL_MAILING_COUNTRY),
            'OtherStreet' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_STREET),
            'OtherAddress' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_ADDRESS),
            'OtherCity' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_CITY),
            'OtherState' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_STATE),
            'OtherPostalCode' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_POSTAL_CODE),
            'OtherCountry' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_COUNTRY),
            'HomePhone' => self::getPMToolFieldName(ContactTableMap::COL_HOME_PHONE),
            'OtherPhone' => self::getPMToolFieldName(ContactTableMap::COL_OTHER_PHONE),
            'AssistantName' => self::getPMToolFieldName(ContactTableMap::COL_ASSISTANT_NAME),
            'AssistantPhone' => self::getPMToolFieldName(ContactTableMap::COL_ASSISTANT_PHONE),
            'Field_Management__c' => self::getPMToolFieldName(ContactTableMap::COL_FIELD_MANAGEMENT),
            'Language_preference__c' => self::getPMToolFieldName(ContactTableMap::COL_LANGUAGE_PREFERENCE_ID),
            'Schlesinger_Events__c' => 'schlesinger_eventss',
            'The_Wall__c' => self::getPMToolFieldName(ContactTableMap::COL_THE_WALL_ID),
            'Description' => self::getPMToolFieldName(ContactTableMap::COL_DESCRIPTION),
            'Possible_Primary_Job_Location__c' => 'possible_primary_job_locations',
            'Area_of_Interest__c' => 'area_of_interests',
            'Methodology__c' => 'methodologies',
            'Gift_Code__c' => self::getPMToolFieldName(ContactTableMap::COL_GIFT_CODE_ID),
            'LeadSource' => self::getPMToolFieldName(ContactTableMap::COL_LEAD_SOURCE_ID),
            'Lead_Source_description__c' => self::getPMToolFieldName(ContactTableMap::COL_LEAD_SOURCE_DESCRIPTION),
            'LastCURequestDate' => self::getPMToolFieldName(ContactTableMap::COL_LAST_CU_REQUEST_DATE),
            'LastCUUpdateDate' => self::getPMToolFieldName(ContactTableMap::COL_LAST_CU_UPDATE_DATE),
            'Birthdate' => self::getPMToolFieldName(ContactTableMap::COL_BIRTHDATE),
            'rrpu__Alert_Message__c' => self::getPMToolFieldName(ContactTableMap::COL_ALERT_MESSAGE),
            'CreatedById' => self::getPMToolFieldName(ContactTableMap::COL_CREATED_BY_ID),
            'CreatedDate' => self::getPMToolFieldName(ContactTableMap::COL_CREATED_DATE),
            'LastModifiedById' => self::getPMToolFieldName(ContactTableMap::COL_LAST_MODIFIED_BY_ID),
            'LastModifiedDate' => self::getPMToolFieldName(ContactTableMap::COL_LAST_MODIFIED_DATE),
            'IsPersonAccount' => self::getPMToolFieldName(ContactTableMap::COL_IS_PERSON_ACCOUNT),
            'LastActivity' => self::getPMToolFieldName(ContactTableMap::COL_LAST_ACTIVITY),
            'LastActivityDate' => self::getPMToolFieldName(ContactTableMap::COL_LAST_ACTIVITY_DATE),
            'CurrencyIsoCode' => self::getPMToolFieldName(ContactTableMap::COL_CURRENCY_ISO_CODE_ID),
            'IsEmailBounced' => self::getPMToolFieldName(ContactTableMap::COL_IS_EMAIL_BOUNCED),
            'Act_On_lead_Score__c' => self::getPMToolFieldName(ContactTableMap::COL_ACT_ON_LEAD_SCORE),
            'CLIENTID__c' => self::getPMToolFieldName(ContactTableMap::COL_CLIENT_ID),
            'CMS_Contact_ID__c' => self::getPMToolFieldName(ContactTableMap::COL_CMS_CONTACT_ID),
            'Contact_Source__c' => 'contact_sources',
            'Created_by_Profile_Name__c' => self::getPMToolFieldName(ContactTableMap::COL_CREATED_BY_PROFILE_NAME),
            'Department__c' => self::getPMToolFieldName(ContactTableMap::COL_DEPARTMENT),
            'Direct_Number__c' => self::getPMToolFieldName(ContactTableMap::COL_DIRECT_NUMBER),
            'hidden_dupecheck__c' => self::getPMToolFieldName(ContactTableMap::COL_HIDDEN_DUPECHECK),
            'Import_ID__c' => self::getPMToolFieldName(ContactTableMap::COL_IMPORT_ID),
            'Last_Activity_Date__c' => self::getPMToolFieldName(ContactTableMap::COL_LAST_ACTIVITY_DATE),
            'LastModifiedDTS__c' => self::getPMToolFieldName(ContactTableMap::COL_LAST_MODIFIED_DTS),
            'Owner_Id__c' => self::getPMToolFieldName(ContactTableMap::COL_OWNER_ID),
            'TW_Lead_Source__c' => self::getPMToolFieldName(ContactTableMap::COL_TW_LEAD_SOURCE_ID),
            'SystemModstamp' => self::getPMToolFieldName(ContactTableMap::COL_SYSTEM_MODSTAMP),
        ];
    }

    public static function getPMToolFieldName($fieldName)
    {
        return ContactTableMap::translateFieldName($fieldName, TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME);
    }

    public function getLastNameAndFirstName()
    {
        return $this->getLastName().' '.$this->getFirstName();
    }

    public function getFullName()
    {
        return $this->getSfId().' ('.$this->getNomComplet().')';
    }

    public function getNomComplet($showCivilite = true)
    {
        $fullName = [];

        if ($this->getSalutation() && $showCivilite) {
            $fullName[] = $this->getSalutation()->getValue();
        }

        if ($this->first_name) {
            $fullName[] = $this->first_name;
        }
        if ($this->last_name) {
            $fullName[] = $this->last_name;
        }

        return implode(' ', $fullName);
    }

    public function toXMLForSalesForce()
    {
        $array = [];
        foreach ($this->toArrayWithCollection() as $key => $value) {
            if (is_bool($value)) {
                $value = (int) $value;
            } elseif ($value instanceof \DateTime) {
                $value = in_array($key, self::FIELDS_ISO_DATE) ? $value->format('Y-m-d\TH:i:s.uP') : $value->format('Y-m-d');
            } elseif (in_array($key, self::FIELDS_MULTIPICKLIST)) {
                if ($value) {
                    $multiplePickListValues = [];
                    $refs = RefSalesForceQuery::create()->filterById($value)->find();
                    foreach ($refs as $ref) {
                        $multiplePickListValues[] = $ref->getValue();
                    }
                    $value = implode(';', $multiplePickListValues);
                } else {
                    $value = '';
                }
            }

            if (in_array($key, self::FIELDS_PICKLIST) && $value) {
                if ($ref = RefSalesForceQuery::create()->filterById($value)->findOne()) {
                    $value = $ref->getValue();
                }
            }

            $array[self::getFieldNamePmtoolToSalesForce($key)] = $value;
        }

        $xml = PHP_EOL.'<Contact>'.PHP_EOL;
        foreach ($array as $key => $value) {
            $xml .= (null === $value || '' === $value) ? "<{$key}>{$value}</{$key}>".PHP_EOL : "<{$key}><![CDATA[{$value}]]></{$key}>".PHP_EOL;
        }

        return $xml.'</Contact>';
    }

    public function isDeleteable()
    {
        if ($this->countEtudesRelatedByContactId()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByContactId()) {
            return false;
        }

        if ($this->countOpportunitiesRelatedByEndClientContactId()) {
            return false;
        }

        if ($this->countEtudeEndClientContacts()) {
            return false;
        }

        if ($this->countEtudeIntermediateClientContacts()) {
            return false;
        }

        return !$this->countEtudeContactClientPms();
    }

    public function replaceBy(Contact $contact): self
    {
        foreach ($this->getEtudesRelatedByContactId() as $etude) {
            $etude->setContact($contact)->save();
        }

        foreach ($this->getOpportunitiesRelatedByContactId() as $opportunity) {
            $opportunity->setContact($contact)->save();
        }

        foreach ($this->getOpportunitiesRelatedByEndClientContactId() as $opportunity) {
            $opportunity->setEndClientContact($contact)->save();
        }

        foreach ($this->getEtudeEndClientContacts() as $etude) {
            $etude->setEndClientContact($contact)->save();
        }

        foreach ($this->getEtudeContactClientPms() as $etude) {
            $etude->setContactClientPm($contact)->save();
        }

        foreach ($this->getEtudeIntermediateClientContacts() as $etude) {
            $etude->setIntermediateClientContact($contact)->save();
        }

        foreach ($this->getFactures() as $facture) {
            $facture->setContact($contact);
        }

        $this->reload(true);

        return $this;
    }

    public function toArrayForForm()
    {
        $array = [];
        foreach ($this->toArrayWithCollection() as $key => $value) {
            if ($value instanceof \DateTime) {
                $value = in_array($key, self::FIELDS_ISO_DATE) ? $value->format('Y-m-d\TH:i:s.uP') : $value->format('Y-m-d');
            }
            $array[$key] = $value;
        }

        return $array;
    }

    public static function getFieldNamePmtoolToSalesForce($consumedField)
    {
        $scribeFields = array_flip(self::fieldsScribeToPMTool());
        $scribeFields[self::getPMToolFieldName(ContactTableMap::COL_ID)] = 'pmtool_id';

        return isset($scribeFields[$consumedField]) && $scribeFields[$consumedField] ? $scribeFields[$consumedField] : $consumedField;
    }

    public static function getFieldNameSalesForceToPmtool($salesForceField)
    {
        $PMToolFields = self::fieldsScribeToPMTool();

        return isset($PMToolFields[$salesForceField]) && $PMToolFields[$salesForceField] ? $PMToolFields[$salesForceField] : $salesForceField;
    }

    public function toArrayWithCollection()
    {
        $result = [
            'id' => $this->getId(),
            'api_created_date' => $this->getApiCreatedDate(),
            'api_updated_date' => $this->getApiUpdatedDate(),
            'pmtool_created_date' => $this->getPmtoolCreatedDate(),
            'pmtool_updated_date' => $this->getPmtoolUpdatedDate(),
            'sf_id' => $this->getSfId(),
            'account_sf_id' => $this->getAccountSfId(),
            'account_id' => $this->getAccountId(),
            'client_id' => $this->getClientId(),
            'cms_contact_id' => $this->getCmsContactId(),
            'title' => $this->getTitle(),
            'first_name' => $this->getFirstName(),
            'last_name' => $this->getLastName(),
            'account_name' => $this->getAccountName(),
            'primary_contact' => $this->getPrimaryContact(),
            'owner' => $this->getOwner(),
            'owner_alias' => $this->getOwnerAlias(),
            'created_alias' => $this->getCreatedAlias(),
            'last_modified_alias' => $this->getLastModifiedAlias(),
            'owner_role_display' => $this->getOwnerRoleDisplay(),
            'owner_role_name' => $this->getOwnerRoleName(),
            'data_com_key' => $this->getDataComKey(),
            'email_bounced_reason' => $this->getEmailBouncedReason(),
            'email_bounced_date' => $this->getEmailBouncedDate(),
            'is_person_account' => $this->getIsPersonAccount(),
            'birthdate' => $this->getBirthdate(),
            'phone' => $this->getPhone(),
            'mobile_phone' => $this->getMobilePhone(),
            'fax' => $this->getFax(),
            'email' => $this->getEmail(),
            'can_be_duplicated' => $this->getCanBeDuplicated(),
            'is_email_bounced' => $this->getIsEmailBounced(),
            'home_phone' => $this->getHomePhone(),
            'other_phone' => $this->getOtherPhone(),
            'assistant_name' => $this->getAssistantName(),
            'assistant_phone' => $this->getAssistantPhone(),
            'salutation_id' => $this->getSalutationId(),
            'linkedin' => $this->getLinkedin(),
            'contact_status_id' => $this->getContactStatusId(),
            'image_name' => $this->getImageName(),
            'contact_preferences' => $this->getContactPreferences(),
            'moderator' => $this->getModerator(),
            'no_client_portal' => $this->getNoClientPortal(),
            'company_influencer' => $this->getCompanyInfluencer(),
            'additional_email' => $this->getAdditionalEmail(),
            'reports_to_id' => $this->getReportsToId(),
            'has_opted_out_of_email' => $this->getHasOptedOutOfEmail(),
            'do_not_solicit' => $this->getDoNotSolicit(),
            'client_space_log_in' => $this->getClientSpaceLogIn(),
            'client_space_tour' => $this->getClientSpaceTour(),
            'department' => $this->getDepartment(),
            'mailing_street' => $this->getMailingStreet(),
            'mailing_address' => $this->getMailingAddress(),
            'mailing_city' => $this->getMailingCity(),
            'mailing_state' => $this->getMailingState(),
            'mailing_postal_code' => $this->getMailingPostalCode(),
            'mailing_country' => $this->getMailingCountry(),
            'other_street' => $this->getOtherStreet(),
            'other_address' => $this->getOtherAddress(),
            'other_city' => $this->getOtherCity(),
            'other_state' => $this->getOtherState(),
            'other_postal_code' => $this->getOtherPostalCode(),
            'other_country' => $this->getOtherCountry(),
            'language_preference_id' => $this->getLanguagePreferenceId(),
            'the_wall_id' => $this->getTheWallId(),
            'description' => $this->getDescription(),
            'field_management' => $this->getFieldManagement(),
            'gift_code_id' => $this->getGiftCodeId(),
            'lead_source_id' => $this->getLeadSourceId(),
            'lead_source_description' => $this->getLeadSourceDescription(),
            'alert_message' => $this->getAlertMessage(),
            'currency_iso_code_id' => $this->getCurrencyIsoCodeId(),
            'act_on_lead_score' => $this->getActOnLeadScore(),
            'direct_number' => $this->getDirectNumber(),
            'hidden_dupecheck' => $this->getHiddenDupecheck(),
            'tw_lead_source_id' => $this->getTwLeadSourceId(),
            'import_id' => $this->getImportId(),
            'owner_id' => $this->getOwnerId(),
            'last_modified_by_id' => $this->getLastModifiedById(),
            'last_modified_date' => $this->getLastModifiedDate(),
            'last_cu_request_date' => $this->getLastCuRequestDate(),
            'last_cu_update_date' => $this->getlastCuUpdateDate(),
            'last_activity' => $this->getLastActivity(),
            'last_activity_date' => $this->getLastActivityDate(),
            'last_modified_dts' => $this->getLastModifiedDts(),
            'created_by_profile_name' => $this->getCreatedByProfileName(),
            'created_by_id' => $this->getCreatedById(),
            'created_date' => $this->getCreatedDate(),
            'added_by_id' => $this->getAddedById(),
            'system_modstamp' => $this->getSystemModstamp(),
            'pmtool_updated' => $this->getPmtoolUpdated(),
        ];
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }
        $result['schlesinger_eventss'] = [];
        $result['possible_primary_job_locations'] = [];
        $result['area_of_interests'] = [];
        $result['methodologies'] = [];
        $result['contact_sources'] = [];
        $result['marketing_audiences'] = [];
        foreach ($this->getRefSalesForceContactRefSchlesingerEventss() as $value) {
            $result['schlesinger_eventss'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceContactRefPossiblePrimaryJobLocations() as $value) {
            $result['possible_primary_job_locations'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceContactRefAreaOfInterests() as $value) {
            $result['area_of_interests'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceContactRefMethodologies() as $value) {
            $result['methodologies'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceContactRefContactSources() as $value) {
            $result['contact_sources'][] = $value->getId();
        }
        foreach ($this->getRefSalesForceContactRefMarketingAudiences() as $value) {
            $result['marketing_audiences'][] = $value->getId();
        }

        return $result;
    }

    public function serializeForSalesforce(): array
    {
        $audiences = [];
        foreach ($this->getMarketingAudiences() as $audience) {
            if ($ref = $audience->getRefSalesForceContactRefMarketingAudience()) {
                $audiences[] = $ref->getValue();
            }
        }

        return [
            'AccountId' => $this->getAccountSfId(),
            'Salutation' => $this->getSalutation() ? $this->getSalutation()->getValue() : null,
            'FirstName' => $this->getFirstName(),
            'LastName' => $this->getLastName(),
            'Added_By__c' => $this->getAddedBy()->getValue(),
//             'AccountName__c' => $this->getAccount()->getName(),
            'Title' => $this->getTitle(),
            'LinkedIn__c' => $this->getLinkedin(),
            'Contact_Status__c' => $this->getContactStatus()->getValue(),
            'Primary_Contact__c' => $this->getPrimaryContact(),
            'Image_Name__c' => $this->getImageName(),
            'Contact_Preferences__c' => $this->getContactPreferences(),
            'Moderator__c' => $this->getModerator(),
            'No_Client_Portal__c' => $this->getNoClientPortal(),
            'Phone' => $this->getPhone(),
            'Fax' => $this->getFax(),
            'MobilePhone' => $this->getFax(),
            'Email' => $this->getEmail(),
            'Can_Contact_be_duplicate__c' => $this->getCanBeDuplicated(),
            'Company_Influencer__c' => $this->getCompanyInfluencer(),
            'Additional_Email__c' => $this->getAdditionalEmail(),
            'ReportsToId' => $this->getReportsToId(),
            'HasOptedOutOfEmail' => $this->getHasOptedOutOfEmail(),
            'Do_Not_Solicit__c' => $this->getDoNotSolicit(),
            'Client_Space_Log_In__c' => $this->getClientSpaceLogIn(),
            'Client_Space_Tour__c' => $this->getClientSpaceTour(),
            'MailingStreet' => $this->getMailingStreet(),
//             'MailingAddress' => $this->getMailingAddress(),
            'MailingCity' => $this->getMailingCity(),
            'MailingState' => $this->getMailingState(),
            'MailingPostalCode' => $this->getMailingPostalCode(),
            'MailingCountry' => $this->getMailingCountry(),
            'OtherStreet' => $this->getOtherStreet(),
//             'OtherAddress' => $this->getOtherAddress(),
            'OtherCity' => $this->getOtherCity(),
            'OtherState' => $this->getOtherState(),
            'OtherPostalCode' => $this->getOtherPostalCode(),
            'OtherCountry' => $this->getOtherCountry(),
            'HomePhone' => $this->getHomePhone(),
            'OtherPhone' => $this->getOtherPhone(),
            'AssistantName' => $this->getAssistantName(),
            'AssistantPhone' => $this->getAssistantPhone(),
            'Field_Management__c' => $this->getFieldManagement(),
            'Language_preference__c' => $this->getLanguagePreference()->getValue(),
            'Schlesinger_Events__c' => null,
            'The_Wall__c' => $this->getTheWall() ? $this->getTheWall()->getValue() : null,
            'Description' => $this->getDescription(),
            'Possible_Primary_Job_Location__c' => null,
            'Area_of_Interest__c' => null,
            'Methodology__c' => null,
            'Gift_Code__c' => null,
            'LeadSource' => $this->getLeadSource(),
            'Lead_Source_description__c' => $this->getLeadSourceDescription(),
            'Birthdate' => $this->getBirthdate(),
            'rrpu__Alert_Message__c' => $this->getAlertMessage(),
//             'CreatedById' => $this->getCreatedById(),
            'CurrencyIsoCode' => $this->getCurrencyIsoCode() ? $this->getCurrencyIsoCode()->getValue() : null,
            'Act_On_lead_Score__c' => $this->getActOnLeadScore(),
            'CLIENTID__c' => $this->getClientId(),
            'CMS_Contact_ID__c' => $this->getCmsContactId(),
            'Contact_Source__c' => null,
//             'Created_by_Profile_Name__c' => $this->getCreatedByProfileName(),
            'Department__c' => $this->getDepartment(),
            'Direct_Number__c' => $this->getDirectNumber(),
            'hidden_dupecheck__c' => $this->getHiddenDupecheck(),
            'Import_ID__c' => $this->getImportId(),
//             'Owner_Id__c' => $this->getOwnerId(),
            'TW_Lead_Source__c' => $this->getTwLeadSource() ? $this->getTwLeadSource()->getValue() : null,
            'marketing_audience__c' => implode(';', $audiences),
        ];
    }
}
