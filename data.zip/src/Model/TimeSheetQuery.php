<?php

namespace Model;

use Model\Base\TimeSheetQuery as BaseTimeSheetQuery;

class TimeSheetQuery extends BaseTimeSheetQuery
{
}
