<?php

namespace Model;

use Model\Base\EtudeCheckListType as BaseEtudeCheckListType;

class EtudeCheckListType extends BaseEtudeCheckListType
{
}
