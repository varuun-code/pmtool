<?php

namespace Util;

use Propel\Runtime\Connection\ConnectionInterface;

/**
 * Use this in a Propel query class to cache EVERY request made on the Propel class.
 * This can consume a lot of memory, so use it carefully.
 */
trait PropelFullCacheTrait
{
    private static $cache = [];

    public function find(ConnectionInterface $con = null)
    {
        $rawQuery = $this->addSelfSelectColumns()->toString();

        if (isset(self::$cache[$rawQuery])) {
            $this->setComment('hit');

            return self::$cache[$rawQuery];
        }

        $this->setComment('miss');

        return self::$cache[$rawQuery] = parent::find($con);
    }
}
