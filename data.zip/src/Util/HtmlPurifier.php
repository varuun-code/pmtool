<?php

namespace Util;

/**
 * FIXME transform into a proper service when possible.
 */
class HtmlPurifier
{
    public static function cleanForPdf(string $input): string
    {
        $config = \HTMLPurifier_Config::createDefault();
        $config->set('HTML.ForbiddenElements', ['dl']);
        $config->set('AutoFormat.RemoveEmpty', true);
        $filter = new \HTMLPurifier($config);

        return $filter->purify($input);
    }

    public static function get_string_between($string, $start, $end)
    {
        $string = ' '.$string;
        $ini = strpos($string, $start);
        if (0 == $ini) {
            return '';
        }
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;

        return substr($string, $ini, $len);
    }

    public static function getContents($str, $startDelimiter, $endDelimiter)
    {
        $contents = [];
        $startDelimiterLength = strlen($startDelimiter);
        $endDelimiterLength = strlen($endDelimiter);
        $startFrom = $contentStart = $contentEnd = 0;
        while (false !== ($contentStart = strpos($str, $startDelimiter, $startFrom))) {
            $contentStart += $startDelimiterLength;
            $contentEnd = strpos($str, $endDelimiter, $contentStart);
            if (false === $contentEnd) {
                break;
            }
            $contents[] = substr($str, $contentStart, $contentEnd - $contentStart);
            $startFrom = $contentEnd + $endDelimiterLength;
        }

        return $contents;
    }
}
