<?php

namespace Util\SEPA;

class SEPAException extends \Exception
{
}
