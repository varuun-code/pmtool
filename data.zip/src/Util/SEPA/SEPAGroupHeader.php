<?php

namespace Util\SEPA;

class SEPAGroupHeader
{
    /**
     * Point to point reference assigned by the instructing party and sent to the next party in the chain
     * to unambiguously identify the message. (Tag: <MsgId>).
     *
     * @var string
     */
    private $messageIdentification = '';

    /**
     * Date and time at which a (group of) payment instruction(s) was created
     * by the instructing party. (Tag: <CreDtTm>).
     *
     * @var ?\DateTime object
     */
    private $creationDateTime;

    /**
     * Number of individual transactions contained in the message. (Tag: <NbOfTxs>).
     *
     * @var int
     */
    private $numberOfTransactions = 0;

    /**
     * Total of all individual amounts included in the message. (Tag: <CtrlSum>).
     *
     * @var float
     */
    private $controlSum = 0.00;

    /**
     * Party that initiates the payment. This can either be the creditor or a party that initiates
     * the direct debit on behalf of the creditor. (Tag: <InitgPty->Nm>).
     *
     * @var string
     */
    private $initiatingPartyName = '';

    /**
     * Getter for Message Identification (MsgId).
     *
     * @return string
     */
    public function getMessageIdentification()
    {
        return $this->messageIdentification;
    }

    /**
     * Setter for Message Identification (MsgId).
     *
     * @throws SEPAException
     */
    public function setMessageIdentification($msgId)
    {
        $msgId = URLify::downcode($msgId, 'de');

        if (!preg_match("/^([A-Za-z0-9]|[\+|\?|\/|\-|:|\(|\)|\.|,|'| ]){1,35}\z/", $msgId)) {
            throw new SEPAException('MsgId empty, contains invalid characters or too long (max. 35).');
        }

        $this->messageIdentification = $msgId;
    }

    /**
     * Getter for Creation Date Time (CreDtTm).
     *
     * @return \DateTime object
     */
    public function getCreationDateTime()
    {
        return $this->creationDateTime ?? $this->creationDateTime = new \DateTime();
    }

    /**
     * Setter for Creation Date Time (CreDtTm).
     */
    public function setCreationDateTime($creDtTm)
    {
        $this->creationDateTime = $creDtTm;
    }

    /**
     * Getter for Number of Transactions (NbOfTxs).
     *
     * @return int
     */
    public function getNumberOfTransactions()
    {
        return $this->numberOfTransactions;
    }

    /**
     * Setter for Number of Transactions (NbOfTxs).
     *
     * @param int $nbOfTxs
     *
     * @throws SEPAException
     */
    public function setNumberOfTransactions($nbOfTxs)
    {
        if (!preg_match("/^[0-9]{1,15}\z/", $nbOfTxs)) {
            throw new SEPAException('Invalid NbOfTxs value (max. 15 digits).');
        }

        $this->numberOfTransactions = $nbOfTxs;
    }

    /**
     * Getter for ControlSum (CtrlSum).
     *
     * @return float
     */
    public function getControlSum()
    {
        return $this->controlSum;
    }

    /**
     * Setter for ControlSum (CtrlSum).
     *
     * @param float $ctrlSum
     */
    public function setControlSum($ctrlSum)
    {
        $this->controlSum = floatval($ctrlSum);
    }

    /**
     * Getter for Initiating Party Name (InitgPty->Nm).
     *
     * @return string
     */
    public function getInitiatingPartyName()
    {
        return $this->initiatingPartyName;
    }

    /**
     * Setter for Initiating Party Name (InitgPty->Nm).
     *
     * @param string $initgPty
     *
     * @throws SEPAException
     */
    public function setInitiatingPartyName($initgPty)
    {
        $initgPty = URLify::downcode($initgPty, 'de');

        if (0 == strlen($initgPty) || strlen($initgPty) > 70) {
            throw new SEPAException('Invalid initiating party name (max. 70).');
        }

        $this->initiatingPartyName = $initgPty;
    }

    /**
     * Returns a SimpleXMLElement for the SEPAGroupHeader object.
     *
     * @return \SimpleXMLElement object
     */
    public function getXmlGroupHeader()
    {
        $xml = new \SimpleXMLElement('<GrpHdr></GrpHdr>');
        $xml->addChild('MsgId', $this->getMessageIdentification());
        $xml->addChild('CreDtTm', $this->getCreationDateTime()->format('Y-m-d\TH:i:s'));
        $xml->addChild('NbOfTxs', $this->getNumberOfTransactions());
        $xml->addChild('CtrlSum', $this->getControlSum());
        $xml->addChild('InitgPty')->addChild('Nm', $this->getInitiatingPartyName());
        //$xml->InitgPty->addChild('PstlAdr')->addChild('AdrLine','10 RUE MERCOEUR');
        //$xml->InitgPty->PstlAdr->addChild('AdrLine','75011 PARIS');
        //$xml->InitgPty->PstlAdr->addChild('Ctry','FR');
        return $xml;
    }
}
