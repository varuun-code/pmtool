<?php

namespace Util;

class DateFormat
{
    /**
     * FIXME remove this. We shoud use (new \DateTime($date))->format('d/m/Y').
     *
     * Format : jj/mm/aaaa.
     */
    public static function getDateFrancaise($date)
    {
        if (!strstr($date, '/') && '' != $date) {
            $date = explode('-', $date);

            return $date[2].'/'.$date[1].'/'.$date[0];
        } else {
            return $date;
        }
    }

    /**
     * FIXME remove.
     *
     * Format : aaaammjj.
     */
    public static function getDateIcs($date)
    {
        if ('' != $date) {
            $date = explode('-', $date);

            return $date[0].$date[1].$date[2];
        } else {
            return $date;
        }
    }

    /**
     * Format : mardi 12 juin 2012.
     *
     * FIXME remove and use the following:
     *
     * setlocale(LC_TIME, 'fr_FR.utf8'); // in config.php
     *
     * $date = new DateTime($module->date);
     * return strftime('%A %e %B %Y', $date->getTimestamp());
     *
     * or
     *
     * return strftime('%A %e %B %Y');
     *
     * for current date
     */
    public static function getDateFrancaiseLongue(string $date, string $instance): string
    {
        if ('de' == $instance) {
            $jourSemaine = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
            $mois = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
        } elseif ('fr' == $instance) {
            $jourSemaine = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
            $mois = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
        } else {
            $jourSemaine = ['Sunday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            $mois = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        }

        $year = substr($date, 0, 4);
        $month = isset($mois[(int) substr($date, 5, 2) - 1]) ? $mois[(int) substr($date, 5, 2) - 1] : '';
        $day = substr($date, 8, 2);
        $js = $jourSemaine[jddayofweek(cal_to_jd(CAL_GREGORIAN, substr($date, 5, 2), $day, $year), 0)];

        return $js.' '.$day.' '.$month.' '.$year;
    }

    /**
     * Format : Dienstag 12. Juni 2012.
     */
    public static function getDateGermanLong($date)
    {
        $jourSemaine = ['Sonntag,', 'Montag,', 'Dienstag,', 'Mittwoch,', 'Donnerstag,', 'Freitag,', 'Samstag,'];
        $mois = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

        $year = substr($date, 0, 4);
        $month = isset($mois[(int) substr($date, 5, 2) - 1]) ? $mois[(int) substr($date, 5, 2) - 1] : '';
        $day = substr($date, 8, 2);
        $js = $jourSemaine[jddayofweek(cal_to_jd(CAL_GREGORIAN, substr($date, 5, 2), $day, $year), 0)];

        return $js.' '.$day.'. '.$month.' '.$year;
    }

    /**
     * FIXME remove.
     *
     * format : dd-mm-yyyy si vide retourne la date du jour.
     */
    public static function getDateSQL($date)
    {
        if (!strstr($date, '-') && '' != $date) {
            $date = explode('/', $date);

            return 3 == count($date) ? $date[2].'-'.$date[1].'-'.$date[0] : '';
        } else {
            return date('Y-m-d');
        }
    }

    /**
     * FIXME remove.
     *
     * Format : dd-mm-yyyy si vide retourne ''.
     */
    public static function getDateSQLvide($date): string
    {
        if (strstr($date, '-')) {
            return $date;
        }

        if ('' != $date) {
            $parts = explode('/', $date);

            return 3 == count($parts) ? $parts[2].'-'.$parts[1].'-'.$parts[0] : '';
        }

        return '';
    }

    /**
     * ajoute un délai à une date
     * DateAdd(2);  // 2 days after
     * DateAdd(-2,0,"Y-m-d") days before with gigen format
     * DateAdd(3,"01/01/2000");  // 3 days after given date.
     *
     * @return false|string
     */
    public static function DateAdd($v, $d = null, $f = 'd/m/Y')
    {
        $d = ($d ? $d : date('Y-m-d'));

        return date($f, strtotime($v.' days', strtotime($d)));
    }

    /**
     * Calcule le dernier jour du mois sous la forme aaaa-mm-jj.
     *
     * @return string
     */
    public static function lastdaymonth($month, $year)
    {
        $lastday = date('j', mktime(0, 0, 0, $month + 1, 0, $year));

        return $year.'-'.$month.'-'.$lastday;
    }

    /**
     * Calcule le dernier jour du mois sous la forme jj-mm-aaaa.
     *
     * @return string
     */
    public static function dernierJourMois($month, $year)
    {
        $lastday = date('j', mktime(0, 0, 0, $month + 1, 0, $year));

        return $lastday.'/'.$month.'/'.$year;
    }

    /**
     * FIXME remove.
     *
     * Format heure 085900 08:59:00.
     *
     * @return array|string
     */
    public static function getTimeIcs($heure)
    {
        if ('' != $heure) {
            $heure_ = explode(':', $heure);
            if (count($heure_) > 2) {
                return $heure_[0].$heure_[1].$heure_[2];
            }
        } else {
            return $heure;
        }

        return $heure;
    }

    /**
     * Calcule le nombre de jour entre 2 dates - format DB.
     */
    public static function NbJours($debut, $fin): float
    {
        $tDeb = explode('-', $debut);
        $tFin = explode('-', $fin);

        $diff = mktime(0, 0, 0, $tFin[1], $tFin[2], $tFin[0]) -
                mktime(0, 0, 0, $tDeb[1], $tDeb[2], $tDeb[0]);

        return round(($diff / 86400) + 1);
    }

    /**
     * Calcule le temps de jour entre 2 heures.
     */
    public static function NbHeures($debut, $fin, $pause): string
    {
        $tDeb = explode(':', $debut);
        $tFin = explode(':', $fin);

        if (count($tDeb) < 2 || count($tFin) < 2) {
            return '0';
        }

        $diff = ($tFin[0] * 60 + $tFin[1]) - ($tDeb[0] * 60 + $tDeb[1]) - $pause;

        return number_format(($diff / 60), 2, '.', '');
    }
}
