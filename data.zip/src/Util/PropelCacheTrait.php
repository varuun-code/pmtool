<?php

namespace Util;

use Propel\Runtime\Connection\ConnectionInterface;

/**
 * Use this in a Propel query class to cache request made on the Propel class if there is no WHERE clause.
 * This is quite reasonnable and is very useful if the ModelType class is used multiple times with the same query.
 */
trait PropelCacheTrait
{
    private static $cache = [];

    public function find(ConnectionInterface $con = null)
    {
        $rawQuery = $this->addSelfSelectColumns()->toString();

        if (false === strpos($rawQuery, ' WHERE ')) {
            if (isset(self::$cache[$rawQuery])) {
                return self::$cache[$rawQuery];
            }

            $this->setComment('cached');

            return self::$cache[$rawQuery] = parent::find($con);
        }

        $this->setComment('not cached');

        return parent::find($con);
    }
}
