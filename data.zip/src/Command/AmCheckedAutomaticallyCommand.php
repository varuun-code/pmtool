<?php

namespace Command;

use Manager\MailManager;
use Model\Etape;
use Model\JobQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class AmCheckedAutomaticallyCommand extends Command
{
    private $mailManager;
    private $amCheckedDelay;

    public function __construct(string $amCheckedDelay, MailManager $mailManager)
    {
        $this->mailManager = $mailManager;

        $this->amCheckedDelay = (int) $amCheckedDelay;

        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:am:checked')
            ->addArgument('instance', InputArgument::REQUIRED, 'It is required to know instance?')
            ->setDescription('Checked jobs AM checked')
            ->setHelp('This command checks all job AM field if PM was checked more than 27 hours ago')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        ini_set('memory_limit', '1G');

        // ==============================================
        // Règles de calcul de la relance
        // si on est entre mardi est vendredi, il faut prendre $dateTime égal à "il y a 27 h"
        // si on est samedi ou dimanche, prendre == vendredi dernier à 23:59:59 moins 27 h (ou samedi 00:00 moins 27 h)
        // si on est lundi, $dateTime == vendredi dernier à 23:59:59 moins N h (ou samedi 00:00 moins N h) avec N = 27 - l'heure courante
        // =============================================
        $instance = $input->getArgument('instance');
        $traitementDebute = date('Y-m-d H:i:s');
        $today = date('N');
        if (in_array($today, [6, 7])) {
            $dateTime = (new \DateTime('last Friday 23 hours 59 minutes 59 seconds'))->modify('-'.$this->amCheckedDelay.'hours');
        } elseif (1 == $today) {
            $time = (int) date('H');
            $hours = $this->amCheckedDelay > $time + 1 ? $this->amCheckedDelay - $time : $this->amCheckedDelay;
            $dateTime = (new \DateTime('last Friday 23 hours 59 minutes 59 seconds'))->modify("-$hours hours");
        } else {
            $dateTime = new \DateTime($this->amCheckedDelay.'hours ago');
        }

        $ids = JobQuery::create()
            ->filterByPmChecked(true)
            ->useEtudeQuery()
                ->filterByDontSetAmAuto(false)
            ->endUse()
            ->filterByPmCheckedAt($dateTime, Criteria::LESS_THAN)
            ->find()
            ->toKeyValue('Id', 'Id');

        $updatedJobs = JobQuery::create()->filterById($ids, Criteria::IN)->find();
        $etudes = [];
        foreach ($updatedJobs as $job) {
            if (!$job->getAmChecked()) {
                $value = ($job->getIdSamsJob() ?: $job->getJobLocation().'  '.$job->getName()).' - '.$job->getStatus()->getValue();
                $job->addCheckBoxHistory(null, $value.' - AM Checked');
                $job->setAmChecked(true)->save();
            }
            $etudes[] = $job->getEtude();
        }

        foreach ($etudes as $etude) {
            $amChecked = true;
            $jobsEtudes = $etude->getJobEtudes();
            foreach ($jobsEtudes as $jobEtude) {
                if (!$jobEtude->getAmChecked()) {
                    $amChecked = false;
                }
            }

            if ($amChecked && null !== $etude->getEtape() && $etude->getEtape()->getOrdre() < Etape::TO_INVOICE_ORDER) {
                $etude->setIdEtape(Etape::TO_INVOICE)->save();
                $etude->majNotation();
                $etude->addProjectStatusLog(null);
                $etude->save();
            }
            if (Etape::TO_INVOICE === $etude->getEtape()->getId() && $etude->getSendCsatQuest() && $etude->getIsSendCsatQuestMail() && !$etude->getIns()) {
                $this->mailManager->sendCsatQuestMail($etude, $instance);
                $etude->setIsSendCsatQuestMail(false)->save();
            }
        }

        if (!$input->getOption('quiet')) {
            $output->writeln('Job AM checked operation success for '.count($ids).' Jobs');
            $output->writeln("AM checked operation started at $traitementDebute, ended at ".date('Y-m-d H:i:s'));
        }

        return 0;
    }
}
