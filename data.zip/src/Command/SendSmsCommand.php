<?php

namespace Command;

use Manager\MailManager;
use Manager\SmsManager;
use Model\CategoriePrestation;
use Model\Site;
use Propel\Runtime\Propel;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SendSmsCommand extends Command
{
    private $mailManager;
    private $smsManager;

    public function __construct(MailManager $mailManager, SmsManager $smsManager)
    {
        $this->mailManager = $mailManager;
        $this->smsManager = $smsManager;

        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:sms:send')
            ->setDescription('Sends SMS for respondents')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $credits = $this->smsManager->checkCredits();
        $nbCreditsRestants = (int) $credits['sms']['LONG'] + (int) $credits['sms']['PREMIUM'];
        if ($nbCreditsRestants < 100) {
            $this->mailManager->sendSmsCreditWarning($nbCreditsRestants);
        }

        // ==============================================
        // Règles de calcul de la relance
        // Selon s'il s'agit du batch de 12:00 ou 20:00
        // 12:00 relance du lendemain de 00:00 à 18:00
        // 20:00 relance du landemain de 18:01 à 24:00
        // =============================================
        $traitementDebute = date('Y-m-d H:i:s');
        $message = '';
        $message_total = '';

        $heureRelance = date('H');
        $tomorrow = (new \DateTime('+1 day'))->format('Y-m-d');

        $mailForManagers = [];

        $recruitment = CategoriePrestation::getRecruitment();
        $query = "SELECT DISTINCT
            module.id AS idModule,
            module.date,
            module.debut,
            portable,
            tel,
            event_methodology_id,
            module.site_id,
            repondant.nom,
            repondant.prenom,
            repondant.qualite,
            theme_br AS theme,
            user.mail AS manager_mail,
            user.nom AS manager_nom,
            user.prenom AS manager_prenom
        FROM etude
        LEFT JOIN job ON job.etude_id = etude.id
        LEFT JOIN event ON event.job_id = job.id
        LEFT JOIN module ON module.event_id = event.id
        LEFT JOIN repondant ON module.repondant_id = repondant.id
        LEFT JOIN module_fournisseur ON module_fournisseur.module_id = module.id
        LEFT JOIN user ON user.id = etude.id_pm
        WHERE etude.sms_relance = 1
        AND etude.id_etape = 2
        AND (LEFT(tel,2) = '06' OR LEFT(tel,2) = '07' OR LEFT(portable,2) = '06' OR LEFT(portable,2) = '07')
        AND repondant_id <> 0
        AND annule <> 'O'
        AND module_fournisseur.categorie_prestation_id = :recruitment
        AND module.date = :date";

        $con = Propel::getConnection();
        $stmt = $con->prepare($query);
        $stmt->bindValue(':date', $tomorrow);
        $stmt->bindValue(':recruitment', $recruitment ? $recruitment->getId() : 0);
        $stmt->execute();
        $results = $stmt->fetchAll();

        if (!$results) {
            $message_total = 'No person to contact for this period : '.$tomorrow.' / '.$heureRelance.':00';
            if (!$input->getOption('quiet')) {
                $output->writeln($message_total);
            }
        }
        foreach ($results as $ligne) {
            $theme = $ligne['theme'];

            $date = $ligne['date'];
            $debut = $ligne['debut'];

            $qualite = $ligne['qualite'];
            $nom = $ligne['nom'];
            $prenom = $ligne['prenom'];

            $id_type = $ligne['event_methodology_id'];
            $id_lieu = $ligne['site_id'];

            $portable = $ligne['portable'];
            $tel = $ligne['tel'];
            $recipient = $portable ?: $tel;

            $site = $id_lieu ? Site::getById($id_lieu) : null;
            $lieu = $site ? $site->getLieu() : '';
            $plan = $site ? $site->getPlan() : '';
            $dateFr = $this->dateFrancaise($date); // FIXME

            $content = [];
            /* => CL IDI 12, DUO 8, FG 11, MG 14, Triad 18 et Workshop 20 => message 1 */
            $content[1] = 'Bonjour '.$qualite.' '.$prenom.' '.$nom.', nous vous rappelons votre rendez-vous prévu le '.
                $dateFr.' à '.$debut.' concernant l\'étude sur '.$theme.'. Voici l\'adresse : '.$lieu.' '.$plan.
                '. En cas d\'empêchement, contactez le 01 70 64 83 55 (de 10h à 18h). Par avance merci, l\'équipe Consumed Research';
            /* Pour le Diary 9 – OBB 16 – Online 15 – Quest 17 - Webcam 19  => message 2 */
            $content[2] = 'Bonjour '.$qualite.' '.$prenom.' '.$nom.', nous vous rappelons que votre étude portant sur '.$theme.' démarre le '.
                $dateFr.' à '.$debut.
                '. En cas d\'empêchement, contactez le 01 70 64 83 55 (de 10h à 18h). Par avance merci, l\'équipe Consumed Research';
            /* Pour l’Ethno 10 et le Field IDI 7 => message 3 */
            $content[3] = 'Bonjour '.$qualite.' '.$prenom.' '.$nom.', nous vous rappelons votre rendez-vous prévu le '.
                $dateFr.' à '.$debut.' concernant l\'étude sur '.$theme.
                '. En cas d\'empêchement, contactez le 01 70 64 83 55 (de 10h à 18h). Par avance merci, l\'équipe Consumed Research';
            /* Pour le TDI 13 – TDI Web 21 => message 4 */
            $content[4] = 'Bonjour '.$qualite.' '.$prenom.' '.$nom.', nous vous rappelons votre rendez-vous téléphonique (assisté d’internet à l’aide de votre ordinateur) prévu le '.
                $dateFr.' à '.$debut.' concernant l\'étude sur '.$theme.
                '. En cas d\'empêchement, contactez le 01 70 64 83 55 (de 10h à 18h) . Par avance merci, l\'équipe Consumed Research';

            $typeEtudeMessage = [
                7 => 3,
                8 => 1,
                9 => 2,
                10 => 3,
                11 => 1,
                12 => 1,
                13 => 4,
                14 => 1,
                15 => 2,
                16 => 2,
                17 => 2,
                18 => 1,
                19 => 2,
                20 => 1,
                21 => 4,
            ];

            $contentId = $typeEtudeMessage[$id_type] ?? null;
            $msg = $content[(int) $contentId] ?? null;

            if (!$msg) {
                continue;
            }

            $this->smsManager->sendSMS($recipient, $msg, 'LONG', '+33638085734', '', '', '', '');

            if (!$input->getOption('quiet')) {
                $output->writeln('Message envoyé : '.$msg);
            }

            $message = 'SMS send to '.$recipient.' : '.$msg;

            $mailForManagers[] = [
                'manager_mail' => $ligne['manager_mail'],
                'manager_nom' => $ligne['manager_nom'],
                'manager_prenom' => $ligne['manager_prenom'],
                'message' => $message,
            ];

            $message_total .= $message;

            $con = Propel::getConnection();
            $stmt = $con->prepare('UPDATE module SET sms_send = "Y" WHERE id = :id');
            $stmt->bindParam(':id', $ligne['idModule']);
            $stmt->execute();
        }

        $this->mailManager->sendSmsSentToAdmin($message_total);
        $this->mailManager->sendSmsSentToProjectManagers($mailForManagers);

        if (!$input->getOption('quiet')) {
            $output->writeln("Sent SMS started at $traitementDebute, ended at ".date('Y-m-d H:i:s'));
        }

        return 0;
    }

    protected function DateFrancaise($date)
    {
        if (!strstr($date, '/') && '' != $date) {
            $date = explode('-', $date);

            return $date[2].'/'.$date[1].'/'.$date[0];
        }

        return $date;
    }
}
