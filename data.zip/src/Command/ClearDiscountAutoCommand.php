<?php

namespace Command;

use Model\SfOpportunityBidJobItemArchiveQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ClearDiscountAutoCommand extends Command
{
    public function __construct()
    {
        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:clear:discount-auto')
            ->setDescription('Clear Bid Job Items Discount Auto')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->writeln('Start Clear Bid Job Items Discount Auto.');
        $lastWeek = date('Y-m-d', strtotime('-1 week'));
        SfOpportunityBidJobItemArchiveQuery::create()->filterByDiscountAuto(1)->filterByArchivedAt($lastWeek, Criteria::LESS_THAN)->delete();
        $output->writeln('End Clear Bid Job Items Discount Auto.');

        return 0;
    }
}
