<?php

namespace Command;

use Model\Calcul;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class AutoRefreshMonthlyCommand extends Command
{
    public function __construct()
    {
        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:report:refresh')
            ->setDescription('Auto Refresh Monthly Report')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $exec = Calcul::refreshTable();
        if ($exec) {
            $output->writeln('Auto Refresh Successfully.');
        }

        return 0;
    }
}
