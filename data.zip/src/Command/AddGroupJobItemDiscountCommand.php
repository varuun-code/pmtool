<?php

namespace Command;

use Model\BidJobItemQuery;
use Model\JobItemQuery;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class AddGroupJobItemDiscountCommand extends Command
{
    public function __construct()
    {
        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName('app:add:group-discount')
            ->setDescription('Add group  discount jobs items');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $output->writeln('Start Update Discount Auto');

        // job items etude
        $jobItems = JobItemQuery::create()->filterByDiscountAuto(1)->find();
        foreach ($jobItems as $jobItem) {
            $group = -1;
            if ($jobItem->getJob()) {
                foreach ($jobItem->getJob()->getJobItems() as $jobItemOther) {
                    if (!$jobItemOther->getDiscountAuto()) {
                        $group = max($group, $jobItemOther->getGroup());
                    }
                }
            }
            $jobItem->setGroupTitle('Discount Auto')
                ->setGroup($group + 1)
                ->save();
        }
        // job items opportunitites
        $jobItemsOpportunities = BidJobItemQuery::create()->filterByDiscountAuto(1)->find();
        foreach ($jobItemsOpportunities as $jobItem) {
            $group = -1;
            if ($jobItem->getBidJob()) {
                foreach ($jobItem->getBidJob()->getOpportunityBidJobItems() as $jobItemOther) {
                    if (!$jobItemOther->getDiscountAuto()) {
                        $group = max($group, $jobItemOther->getGroup());
                    }
                }
            }
            $jobItem->setGroupTitle('Discount Auto')
                ->setGroup($group + 1)
                ->save();
        }
        $output->writeln('Finished Update Discount Auto');

        return 0;
    }
}
