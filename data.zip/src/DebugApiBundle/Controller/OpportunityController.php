<?php

namespace DebugApiBundle\Controller;

use DebugApiBundle\Datagrid\OpportunityDatagrid;
use Model\Map\RefSalesForceTableMap;
use Model\Opportunity;
use Model\OpportunityQuery;
use Model\RefSalesForce;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class OpportunityController extends AbstractController
{
    /**
     * @Route(name="debug_opportunity_list", path="/opportunity/list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "param1": "", "param2": "", "datagrid": ""})
     */
    public function listAction(): Response
    {
        $datagrid = new OpportunityDatagrid($this->container);
        $datagrid->execute();

        $stageWonId = RefSalesForce::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'Closed Won');

        return $this->render('debug/Opportunity/list.html.twig', ['datagrid' => $datagrid, 'stageWonId' => $stageWonId]);
    }

    /**
     * @Route(name="debug_opportunity_show", path="/opportunity/{id}/show")
     */
    public function showAction(Request $request, Opportunity $opportunity): Response
    {
        return $this->render('debug/Opportunity/show.html.twig', ['opportunity' => $opportunity]);
    }

    /**
     * @Route(name="debug_opportunity_stage", path="/opportunity/{id}/stage")
     */
    public function stageAction(Request $request, Opportunity $opportunity): Response
    {
        $stageWonId = RefSalesForce::findRefSalesforceId(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY, 'stage_name_id', 'Closed Won');

        if ($stageWonId && $opportunity->getStageNameId() != $stageWonId) {
            $opportunity->setStageNameId($stageWonId);
            $opportunity->setPmtoolUpdated(true);
            $opportunity->save();
        }

        return $this->redirectToRoute('debug_opportunity_list');
    }

    /**
     * @Route(name="opportunity_name_autocompletion", path="/opportunity/search")
     */
    public function autocompletionAction(Request $request): Response
    {
        $data = [];
        $opportunities = OpportunityQuery::create()
            ->_if($request->get('value'))
                ->filterBySfId('%'.$request->get('value').'%', Criteria::LIKE)
            ->_endif()
            ->setLimit(100)
            ->find();

        foreach ($opportunities as $opportunity) {
            $data[] = [
                'value' => $opportunity->getId(),
                'label' => $opportunity->getFullName(),
            ];
        }

        return $this->json($data);
    }
}
