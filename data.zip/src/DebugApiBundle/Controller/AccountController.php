<?php

namespace DebugApiBundle\Controller;

use DebugApiBundle\Datagrid\AccountDatagrid;
use DebugApiBundle\Form\Type\AccountType;
use Model\Account;
use Model\AccountQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AccountController extends AbstractController
{
    /**
     * @Route(name="debug_homepage", path="/")
     * @Route(name="debug_account_list", path="/account/list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "param1": "", "param2": "", "datagrid": ""})
     */
    public function listAction(): Response
    {
        $datagrid = new AccountDatagrid($this->container);
        $datagrid->execute();

        return $this->render('debug/Account/list.html.twig', ['datagrid' => $datagrid]);
    }

    /**
     * @Route(name="debug_account_update", path="/account/{id}/update")
     */
    public function editAction(Request $request, Account $account): Response
    {
        $form = $this->createForm(AccountType::class, $account);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $account->setPmtoolUpdated(true);
                $account->save();
                $this->addFlash('success', 'Account updated');

                return $this->redirectToRoute('debug_account_list');
            } else {
                $this->addFlash('danger', 'Account validation errors.');
            }
        }

        return $this->render('debug/Account/edit.html.twig', [
            'form' => $form->createView(),
            'account' => $account,
        ]);
    }

    /**
     * @Route(name="debug_account_show", path="/account/{id}/show")
     */
    public function showAction(Request $request, Account $account): Response
    {
        return $this->render('debug/Account/show.html.twig', ['account' => $account]);
    }

    /**
     * @Route(name="account_name_autocompletion", path="/account/search")
     */
    public function autocompletionAction(Request $request): Response
    {
        $data = [];
        $accounts = AccountQuery::create()
            ->_if($request->get('value'))
                ->filterByName('%'.$request->get('value').'%', Criteria::LIKE)
                ->_or()
                ->filterbySfId('%'.$request->get('value').'%', Criteria::LIKE)
            ->_endif()
            ->setLimit(100)
            ->find();

        foreach ($accounts as $account) {
            $data[] = [
                'value' => $account->getId(),
                'label' => $account->getFullName(),
            ];
        }

        return $this->json($data);
    }
}
