<?php

namespace DebugApiBundle\Controller;

use DebugApiBundle\Datagrid\JobDatagrid;
use DebugApiBundle\Form\Type\JobType;
use Model\AccountQuery;
use Model\ContactQuery;
use Model\Job;
use Model\OpportunityQuery;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class JobController extends AbstractController
{
    /**
     * @Route(name="debug_job_list", path="/job/list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "param1": "", "param2": "", "datagrid": ""})
     */
    public function listAction(): Response
    {
        $datagrid = new JobDatagrid($this->container);
        $datagrid->execute();

        return $this->render('debug/Job/list.html.twig', ['datagrid' => $datagrid]);
    }

    /**
     * @Route(name="debug_job_show", path="/job/{id}/show")
     */
    public function showAction(Request $request, Job $job): Response
    {
        return $this->render('debug/Job/show.html.twig', ['job' => $job]);
    }

    /**
     * @Route(name="debug_job_update", path="/job/{id}/update")
     */
    public function editAction(Request $request, Job $job): Response
    {
        $form = $this->createForm(JobType::class, $job);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $job->setPmtoolUpdated(true);
                $job->save();
                $this->addFlash('success', 'Job updated.');

                return $this->redirectToRoute('debug_job_list');
            } else {
                $this->addFlash('danger', 'Job validation errors.');
            }
        }

        $listAccount = $listEndClient = $listEndClientContact = $listContact = $listOpportunity = $listContactClientPm = null;
        $etude = $job->getEtude();
        if ($etude) {
            $listAccount = AccountQuery::create()->findById($etude->getAccountId());
            $listEndClient = AccountQuery::create()->findById($etude->getEndClientId());
            $listEndClientContact = ContactQuery::create()->findById($etude->getEndClientContactId());
            $listContactClientPm = ContactQuery::create()->findById($etude->getContactClientPmId());
            $listContact = ContactQuery::create()->findById($etude->getContactId());
            $listOpportunity = OpportunityQuery::create()->findById($etude->getOpportunityId());
        }

        return $this->render('debug/Job/edit.html.twig', [
            'form' => $form->createView(),
            'job' => $job,
            'listAccount' => $listAccount,
            'listContact' => $listContact,
            'listEndClient' => $listEndClient,
            'listEndClientContact' => $listEndClientContact,
            'listContactClientPm' => $listContactClientPm,
            'listOpportunity' => $listOpportunity,
        ]);
    }

    /**
     * @Route(name="debug_job_new", path="/job/new")
     */
    public function newAction(Request $request): Response
    {
        $job = new Job();
        $form = $this->createForm(JobType::class, $job);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);

            if ($form->isSubmitted() && $form->isValid()) {
                $job = $form->getData();
                $job->setPmtoolUpdated(false);
                $job->getEtude()->setNew(false);
                $job->save();

                $this->addFlash('success', 'Job created.');

                return $this->redirectToRoute('debug_job_list');
            } else {
                $this->addFlash('danger', 'Job validation errors.');
            }
        }

        return $this->render('debug/Job/new.html.twig', [
            'form' => $form->createView(),
            'job' => $job,
        ]);
    }
}
