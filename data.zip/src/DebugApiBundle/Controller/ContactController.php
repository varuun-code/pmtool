<?php

namespace DebugApiBundle\Controller;

use DebugApiBundle\Datagrid\ContactDatagrid;
use DebugApiBundle\Form\Type\ContactType;
use Model\Contact;
use Model\ContactQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ContactController extends AbstractController
{
    /**
     * @Route(name="debug_contact_list", path="/contact/list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "param1": "", "param2": "", "datagrid": ""})
     */
    public function listAction(): Response
    {
        $datagrid = new ContactDatagrid($this->container);
        $datagrid->execute();

        return $this->render('debug/Contact/list.html.twig', ['datagrid' => $datagrid]);
    }

    /**
     * @Route(name="debug_contact_update", path="/contact/{id}/update")
     */
    public function editAction(Request $request, Contact $contact): Response
    {
        $form = $this->createForm(ContactType::class, $contact);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $contact->setPmtoolUpdated(true);
                $contact->save();
                $this->addFlash('success', 'Contact updated.');

                return $this->redirectToRoute('debug_contact_list');
            } else {
                $this->addFlash('danger', 'Contact validation errors.');
            }
        }

        return $this->render('debug/Contact/edit.html.twig', [
            'form' => $form->createView(),
            'contact' => $contact,
        ]);
    }

    /**
     * @Route(name="debug_contact_new", path="/contact/new")
     */
    public function newAction(Request $request): Response
    {
        $contact = new Contact();

        $form = $this->createForm(ContactType::class, $contact, []);

        if ($request->isMethod('post')) {
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()) {
                $contact->setPmtoolUpdated(false);
                $contact->save();
                $this->addFlash('success', 'Contact created.');

                return $this->redirectToRoute('debug_contact_list');
            } else {
                $this->addFlash('danger', 'Contact validation errors.');
            }
        }

        return $this->render('debug/Contact/new.html.twig', [
            'form' => $form->createView(),
            'contact' => $contact,
        ]);
    }

    /**
     * @Route(name="debug_contact_show", path="/contact/{id}/show")
     */
    public function showAction(Request $request, Contact $contact): Response
    {
        return $this->render('debug/Contact/show.html.twig', ['contact' => $contact]);
    }

    /**
     * @Route(name="contact_name_autocompletion", path="/contact/search")
     */
    public function autocompletionAction(Request $request): Response
    {
        $data = [];
        $contacts = ContactQuery::create()
            ->_if($request->get('value'))
                ->filterByFirstName('%'.$request->get('value').'%', Criteria::LIKE)
                ->_or()
                ->filterByLastName('%'.$request->get('value').'%', Criteria::LIKE)
                ->_or()
                ->filterbySfId('%'.$request->get('value').'%', Criteria::LIKE)
            ->_endif()
            ->setLimit(100)
            ->find();

        foreach ($contacts as $contact) {
            $data[] = [
                'value' => $contact->getId(),
                'label' => $contact->getFullName(),
            ];
        }

        return $this->json($data);
    }
}
