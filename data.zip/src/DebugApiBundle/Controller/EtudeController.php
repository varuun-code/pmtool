<?php

namespace DebugApiBundle\Controller;

use Model\EtudeQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Map\TableMap;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EtudeController extends AbstractController
{
    /**
     * @Route(name="etude_name_autocompletion", path="/etude/search")
     */
    public function autocompletionAction(Request $request): Response
    {
        $data = [];
        $etudes = EtudeQuery::create()
            ->distinct()
            ->_if($request->get('name'))
                ->filterByReferenceClient('%'.$request->get('name').'%', Criteria::LIKE)
                ->_or()
                ->filterByNumeroEtude('%'.$request->get('name').'%', Criteria::LIKE)
                 ->setLimit(100)
            ->_elseif($request->get('id'))
                ->joinWith('Account account', Criteria::LEFT_JOIN)
                ->joinWith('ContactClientPm contactclientpm', Criteria::LEFT_JOIN)
                ->joinWith('EndClient endclient', Criteria::LEFT_JOIN)
                ->joinWith('EndClientContact endclientcontact', Criteria::LEFT_JOIN)
                ->joinWith('Contact contact', Criteria::LEFT_JOIN)
                ->joinWith('Opportunity opportunity', Criteria::LEFT_JOIN)
                ->joinWith('Services', Criteria::LEFT_JOIN)
                ->joinWith('RespondentTypeCategory', Criteria::LEFT_JOIN)
                ->joinWith('SampleSource', Criteria::LEFT_JOIN)
                ->filterById($request->get('id'))
            ->_endif()
            ->filterByAccountId(null, Criteria::ISNOTNULL)
            ->find();

        foreach ($etudes as $etude) {
            if ($request->get('name')) {
                $data[] = [
                    'value' => $etude->getId(),
                    'label' => $etude->getFullName(),
                ];
            } elseif ($request->get('id')) {
                $data[] = $etude->toArray(TableMap::TYPE_PHPNAME, true, [], true);
            }
        }

        return $this->json($data);
    }
}
