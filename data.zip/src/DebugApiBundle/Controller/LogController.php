<?php

namespace DebugApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Finder\Finder;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class LogController extends AbstractController
{
    /**
     * @Route(name="debug_log_list", path="/log/list")
     */
    public function listAction(): Response
    {
        $path = $this->get('kernel')->getLogDir();
        $finder = new Finder();
        $finder->files()->in($path)->sort(
            function ($a, $b) {
                return $b->getMTime() - $a->getMTime();
            }
        );

        return $this->render('debug/Log/list.html.twig', ['files' => $finder]);
    }

    /**
     * @Route(name="debug_log_download", path="/log/{filename}/download")
     */
    public function downloadAction(Request $request): Response
    {
        ini_set('memory_limit', '2G'); // download of big files fail without this
        $filename = $request->get('filename');
        if (!$filename) {
            $this->addFlash('warning', 'This File not exist');

            return $this->redirectToRoute('debug_log_list');
        }
        $path = $this->get('kernel')->getLogDir();
        $finder = new Finder();
        $finder->files()->in($path)->name($filename);

        $log = null;
        foreach ($finder as $file) {
            $log = $file;
        }

        if (!$log) {
            throw $this->createNotFoundException();
        }

        $response = new Response();
        $response->headers->set('Cache-Control', 'private');
        $response->headers->set('Content-type', 'text/plain');
        $response->headers->set('Content-Disposition', 'attachment; filename="'.$filename.'";');
        $response->headers->set('Content-length', filesize($log->getRealPath()));
        $response->sendHeaders();
        $response->setContent(readfile($log->getRealPath()));

        return $response;
    }
}
