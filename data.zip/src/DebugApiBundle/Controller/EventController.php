<?php

namespace DebugApiBundle\Controller;

use DebugApiBundle\Datagrid\EventDatagrid;
use Model\Event;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EventController extends AbstractController
{
    /**
     * @Route(name="debug_event_list", path="/event/list/{action}/{datagrid}/{param1}/{param2}", defaults={"action": "", "param1": "", "param2": "", "datagrid": ""})
     */
    public function listAction(): Response
    {
        $datagrid = new EventDatagrid($this->container);
        $datagrid->execute();

        return $this->render('debug/Event/list.html.twig', ['datagrid' => $datagrid]);
    }

    /**
     * @Route(name="debug_event_show", path="/event/{id}/show")
     */
    public function showAction(Request $request, Event $event): Response
    {
        return $this->render('debug/Event/show.html.twig', ['event' => $event]);
    }
}
