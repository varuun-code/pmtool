<?php

namespace DebugApiBundle\Form\Type;

use Model\Contact;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ContactType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Contact::class,
            'name' => 'contact',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesYN = [
            'Y' => 'Y',
            'N' => 'N',
        ];

        $choicesBoolean = [
            '1' => '1',
            '0' => '0',
        ];

        $builder->add('sf_id', null, [
            'label' => 'Contact Sf Id',
            'required' => false,
            'property_path' => 'SfId',
        ]);
        $builder->add('account_sf_id', null, [
            'required' => false,
            'property_path' => 'AccountSfId',
        ]);
        $builder->add('is_person_account', ChoiceType::class, [
            'property_path' => 'IsPersonAccount',
            'required' => false,
            'choices' => $choicesBoolean,
        ]);

        $builder->add('salutation_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('salutation_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'Salutation',
        ]);

        $builder->add('first_name', null, [
            'property_path' => 'FirstName',
        ]);
        $builder->add('last_name', null, [
            'required' => true,
            'property_path' => 'LastName',
        ]);
        $builder->add('owner', null, ['property_path' => 'Owner', 'required' => false]);
        $builder->add('owner_alias', null, ['property_path' => 'OwnerAlias', 'required' => false]);
        $builder->add('owner_role_display', null, ['property_path' => 'OwnerRoleDisplay', 'required' => false]);
        $builder->add('owner_role_name', null, ['property_path' => 'OwnerRoleName', 'required' => false]);
        $builder->add('data_com_key', null, ['property_path' => 'DataComKey', 'required' => false]);
        $builder->add('email_bounced_reason', null, ['property_path' => 'EmailBouncedReason', 'required' => false]);

        $builder->add('email_bounced_date', DateTimeType::class, [
            'property_path' => 'EmailBouncedDate',
            'widget' => 'single_text',
            'label' => 'Email Bounced Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('created_alias', DateTimeType::class, [
            'property_path' => 'CreatedAlias',
            'widget' => 'single_text',
            'label' => 'Created Alias',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('last_modified_alias', DateTimeType::class, [
            'property_path' => 'LastModifiedAlias',
            'widget' => 'single_text',
            'label' => 'Last Modified Alias',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('added_by_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('added_by_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'AddedBy',
        ]);

        $builder->add('account_name', null, ['property_path' => 'AccountName']);
        $builder->add('title', null, ['property_path' => 'Title']);
        $builder->add('linkedin', null, ['property_path' => 'Linkedin']);

        $builder->add('contact_status_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('contact_status_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'ContactStatus',
        ]);

        $builder->add('primary_contact', ChoiceType::class, [
            'property_path' => 'PrimaryContact',
            'required' => false,
            'choices' => $choicesYN,
        ]);

        $builder->add('image_name', null, ['property_path' => 'ImageName']);
        $builder->add('contact_preferences', null, ['property_path' => 'ContactPreferences']);
        $builder->add('moderator', ChoiceType::class, [
            'property_path' => 'Moderator',
            'required' => true,
            'choices' => $choicesBoolean,
        ]);
        $builder->add('no_client_portal', null, ['property_path' => 'NoClientPortal']);
        $builder->add('phone', null, [
            'label' => 'Main Number',
            'property_path' => 'Phone',
        ]);
        $builder->add('fax', null, [
            'label' => 'Business Fax',
            'property_path' => 'Fax',
        ]);
        $builder->add('mobile_phone', null, ['property_path' => 'MobilePhone']);
        $builder->add('email', null, ['property_path' => 'Email']);
        $builder->add('company_influencer', null, ['property_path' => 'CompanyInfluencer']);

        $builder->add('additional_email', null, ['property_path' => 'AdditionalEmail']);
        $builder->add('reports_to_id', null, ['property_path' => 'ReportsToId']);
        $builder->add('has_opted_out_of_email', ChoiceType::class, [
            'property_path' => 'HasOptedOutOfEmail',
            'required' => true,
            'choices' => $choicesBoolean,
        ]);
        $builder->add('do_not_solicit', ChoiceType::class, [
            'property_path' => 'DoNotSolicit',
            'required' => true,
            'choices' => $choicesBoolean,
        ]);
        $builder->add('client_space_log_in', ChoiceType::class, [
            'property_path' => 'ClientSpaceLogIn',
            'required' => true,
            'choices' => $choicesBoolean,
        ]);
        $builder->add('client_space_tour', ChoiceType::class, [
            'property_path' => 'ClientSpaceTour',
            'required' => true,
            'choices' => $choicesBoolean,
        ]);
        $builder->add('mailing_street', null, ['property_path' => 'MailingStreet']);
        $builder->add('mailing_address', null, ['property_path' => 'MailingAddress']);
        $builder->add('mailing_city', null, ['property_path' => 'MailingCity']);
        $builder->add('mailing_state', null, ['property_path' => 'MailingState']);
        $builder->add('mailing_postal_code', null, ['property_path' => 'MailingPostalCode']);
        $builder->add('mailing_country', null, ['property_path' => 'MailingCountry']);

        $builder->add('other_street', null, ['property_path' => 'OtherStreet']);
        $builder->add('other_address', null, ['property_path' => 'OtherAddress']);
        $builder->add('other_city', null, ['property_path' => 'OtherCity']);
        $builder->add('other_state', null, ['property_path' => 'OtherState']);
        $builder->add('other_postal_code', null, ['property_path' => 'OtherPostalCode']);
        $builder->add('other_country', null, ['property_path' => 'OtherCountry']);

        $builder->add('home_phone', null, ['property_path' => 'HomePhone']);
        $builder->add('other_phone', null, ['property_path' => 'OtherPhone']);
        $builder->add('assistant_name', null, ['property_path' => 'AssistantName']);
        $builder->add('assistant_phone', null, ['property_path' => 'AssistantPhone']);
        $builder->add('field_management', ChoiceType::class, ['property_path' => 'FieldManagement',
            'required' => false,
            'choices' => $choicesYN,
        ]);

        $builder->add('language_preference_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('language_preference_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'LanguagePreference',
        ]);

        $builder->add('schlesinger_eventss', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('schlesinger_eventss')
                ->filterByActif(true),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceContactRefSchlesingerEventss',
        ]);

        $builder->add('the_wall_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('the_wall_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'TheWall',
        ]);

        $builder->add('description', null, ['property_path' => 'Description']);
        $builder->add('possible_primary_job_locations', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('possible_primary_job_locations')
                ->filterByActif(true),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceContactRefPossiblePrimaryJobLocations',
        ]);

        $builder->add('area_of_interests', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('area_of_interests')
                ->filterByActif(true),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceContactRefAreaOfInterests',
        ]);
        $builder->add('methodologies', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('methodologies')
                ->filterByActif(true),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceContactRefMethodologies',
        ]);
        $builder->add('gift_code_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('gift_code_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'GiftCode',
        ]);
        $builder->add('lead_source_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('lead_source_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'LeadSource',
        ]);
        $builder->add('lead_source_description', null, ['property_path' => 'LeadSourceDescription']);

        $builder->add('last_cu_request_date', DateTimeType::class, [
            'property_path' => 'LastCuRequestDate',
            'widget' => 'single_text',
            'label' => 'last Cu Request Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);
        $builder->add('last_cu_update_date', DateTimeType::class, [
            'property_path' => 'LastCuUpdateDate',
            'widget' => 'single_text',
            'label' => 'Last Cu Update Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('birthdate', DateTimeType::class, [
            'property_path' => 'Birthdate',
            'widget' => 'single_text',
            'label' => 'birthdate',
            'format' => 'YYYY-MM-DD',
            'required' => false,
        ]);

        $builder->add('alert_message', null, [
            'property_path' => 'AlertMessage',
        ]);
        $builder->add('created_by_id', null, [
            'required' => true,
            'property_path' => 'CreatedById',
        ]);
        $builder->add('created_date', DateTimeType::class, [
            'property_path' => 'CreatedDate',
            'widget' => 'single_text',
            'label' => 'created_date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);
        $builder->add('last_modified_by_id', null, ['property_path' => 'LastModifiedById']);
        $builder->add('last_modified_date', DateTimeType::class, [
            'property_path' => 'LastModifiedDate',
            'widget' => 'single_text',
            'label' => 'Last Modified Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);
        $builder->add('last_activity_date', DateTimeType::class, [
            'property_path' => 'LastActivityDate',
            'widget' => 'single_text',
            'label' => 'Last Activity Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);
        $builder->add('last_activity', DateTimeType::class, [
            'property_path' => 'LastActivity',
            'widget' => 'single_text',
            'label' => 'Last Activity',
            'format' => 'YYYY-MM-DD',
            'required' => false,
        ]);
        $builder->add('currency_iso_code_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('currency_iso_code_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'CurrencyIsoCode',
        ]);

        $builder->add('is_email_bounced', ChoiceType::class, [
            'property_path' => 'IsEmailBounced',
            'required' => false,
            'choices' => $choicesBoolean,
        ]);

        $builder->add('act_on_lead_score', null, ['property_path' => 'ActOnLeadScore']);
        $builder->add('client_id', null, ['property_path' => 'ClientId']);
        $builder->add('cms_contact_id', null, ['property_path' => 'CmsContactId']);
        $builder->add('contact_sources', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('contact_sources')
                ->filterByActif(true),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceContactRefContactSources',
        ]);

        $builder->add('created_by_profile_name', null, ['property_path' => 'CreatedByProfileName']);
        $builder->add('department', null, ['property_path' => 'Department']);
        $builder->add('direct_number', null, ['property_path' => 'DirectNumber']);
        $builder->add('hidden_dupecheck', null, ['property_path' => 'HiddenDupecheck']);
        $builder->add('import_id', null, ['property_path' => 'ImportId']);
        $builder->add('last_modified_dts', DateTimeType::class, [
            'property_path' => 'LastModifiedDts',
            'widget' => 'single_text',
            'label' => 'Last Modified Dts',
            'format' => 'YYYY-MM-DD',
            'required' => false,
        ]);
        $builder->add('owner_id', null, ['property_path' => 'OwnerId']);
        $builder->add('tw_lead_source_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('tw_lead_source_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'TwLeadSource',
        ]);
        $builder->add('system_modstamp', DateTimeType::class, [
            'property_path' => 'SystemModstamp',
            'widget' => 'single_text',
            'label' => 'System Modstamp',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);
    }
}
