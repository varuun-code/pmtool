<?php

namespace DebugApiBundle\Form\Type;

use Model\Account;
use Model\AccountQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\Etude;
use Model\Opportunity;
use Model\OpportunityQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class EtudeType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Etude::class,
            'name' => 'etude',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('id', HiddenType::class);

        $builder->add('reference_client', TextType::class, [
            'label' => 'Client Ref',
            'property_path' => 'referenceClient',
        ]);

        $builder->add('numero_etude', TextType::class, [
            'label' => 'Consumed Study',
            'property_path' => 'numeroEtude',
            'constraints' => [
                new NotBlank(),
            ],
            'disabled' => true,
        ]);

        $builder->add('theme', TextType::class, [
            'label' => 'Job Name Subject',
            'property_path' => 'theme',
            'required' => false,
        ]);

        $builder->add('date_debut', DateTimeType::class, [
            'property_path' => 'dateDebut',
            'widget' => 'single_text',
            'label' => 'Job Start Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('date_fin', DateTimeType::class, [
            'property_path' => 'dateFin',
            'widget' => 'single_text',
            'label' => 'Job End Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('gms', ChoiceType::class, [
            'label' => 'GMS Job',
            'property_path' => 'gms',
            'required' => true,
            'choices' => [
                'Y' => 'Y',
                'N' => 'N',
            ],
        ]);

        $builder->add('proposed_loi', IntegerType::class, [
            'label' => 'Proposed loi',
            'property_path' => 'proposedLoi',
            'required' => false,
        ]);

        $builder->add('proposed_n', IntegerType::class, [
            'label' => 'Proposed N',
            'property_path' => 'proposedN',
            'required' => false,
        ]);

        $builder->add('si_job_type_id', ModelType::class, [
            'label' => 'Si job Type',
            'query' => RefSalesForceQuery::create()->filterByActiveProjectField('si_job_type_id'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'siJobType',
        ]);

        $builder->add('sample_sources', ModelType::class, [
            'query' => RefSalesForceQuery::create()->filterByActiveProjectField('sample_sources'),
            'required' => false,
            'multiple' => true,
            'expanded' => true,
            'label' => 'Sample Sources',
            'class' => RefSalesForce::class,
        ]);

        $builder->add('best_effort_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()->filterByActiveProjectField('best_effort_id'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'bestEffort',
        ]);

        $builder->add('job_status_sf_id', ModelType::class, [
            'label' => 'Job Status',
            'query' => RefSalesForceQuery::create()->filterByActiveProjectField('job_status_sf_id'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'jobStatusSf',
        ]);

        $defaultUserSfId = '00530000005D9lj';
        $builder->add('booked_by_sf_id', TextType::class, [
            'label' => 'Booked By SF ID',
            'required' => false,
            'data' => $defaultUserSfId,
            'property_path' => 'bookedBySfId',
        ]);

        $builder->add('created_by_sf_id', TextType::class, [
            'label' => 'Created By SF ID',
            'required' => false,
            'data' => $defaultUserSfId,
            'property_path' => 'createdBySfId',
        ]);

        $builder->add('account_manager_sf_id', TextType::class, [
            'label' => 'Account Manager COE SF ID',
            'required' => false,
            'data' => $defaultUserSfId,
            'property_path' => 'accountManagerSfId',
        ]);

        $builder->add('created_date', DateTimeType::class, [
            'property_path' => 'createdDate',
            'widget' => 'single_text',
            'label' => 'Created Date',
            'format' => 'YYYY-MM-dd HH:mm:ss',
            'required' => false,
        ]);

        $builder->add('job_qualification_id', ModelType::class, [
            'label' => 'Job Qualification',
            'query' => RefSalesForceQuery::create()->filterByActiveProjectField('job_qualification_id'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'jobQualification',
        ]);

        $defaultEndClient = AccountQuery::create()->findOneBySfId('0013000000b3BZfAAM');

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($defaultEndClient) {
            $form = $event->getForm();
            $data = $event->getData();

            $defaultId = $data && $data->getAccountId() ? $data->getAccountId() : -1;
            $form->add('account', ModelType::class, [
                'label' => 'Account SF ID',
                'placeholder' => 'Enter SF ID or name account',
                'class' => Account::class,
                'query' => AccountQuery::create()->filterById($defaultId),
                'property' => 'fullName',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ]);

            $defaultId = $data && $data->getEndClientId() ? $data->getEndClientId() : $defaultEndClient->getId();
            $form->add('end_client', ModelType::class, [
                'label' => 'End Client SF ID',
                'placeholder' => 'Enter SF ID or name account',
                'class' => Account::class,
                'query' => AccountQuery::create()->filterById($defaultId),
                'property_path' => 'endClient',
                'constraints' => [
                    new NotBlank(),
                ],
                'required' => true,
                'data' => $defaultEndClient,
            ]);

            $defaultId = $data && $data->getEndCLientContactId() ? $data->getEndCLientContactId() : -1;
            $form->add('end_client_contact', ModelType::class, [
                'label' => 'End Client Contact SF ID',
                'class' => Contact::class,
                'query' => ContactQuery::create()->filterById($defaultId),
                'required' => false,
                'placeholder' => 'Enter SF ID or name contact',
                'property_path' => 'endClientContact',
            ]);

            $defaultId = $data && $data->getContactId() ? $data->getContactId() : -1;
            $form->add('contact', ModelType::class, [
                'label' => 'Contact SF ID',
                'class' => Contact::class,
                'query' => ContactQuery::create()->filterById($defaultId),
                'placeholder' => 'Enter SF ID or name contact',
                'property_path' => 'contact',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ]);

            $defaultId = $data && $data->getOpportunityId() ? $data->getOpportunityId() : -1;
            $form->add('opportunity', ModelType::class, [
                'label' => 'Opportunity SF ID',
                'placeholder' => 'Enter SF ID only for test',
                'class' => Opportunity::class,
                'query' => OpportunityQuery::create()->filterById($defaultId),
                'property' => 'fullName',
            ]);
        });

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) use ($defaultEndClient) {
            $form = $event->getForm();
            $data = $event->getData();

            $defaultId = isset($data['account']) && $data['account'] ? $data['account'] : -1;
            $form->add('account', ModelType::class, [
                'label' => 'Account SF ID',
                'placeholder' => 'Account',
                'class' => Account::class,
                'query' => AccountQuery::create()->filterById($defaultId),
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ]);

            $defaultId = isset($data['end_client']) && $data['end_client'] ? $data['end_client'] : $defaultEndClient->getId();
            $form->add('end_client', ModelType::class, [
                'label' => 'End Client SF ID',
                'placeholder' => 'Enter SF ID or name account',
                'class' => Account::class,
                'query' => AccountQuery::create()->filterById($defaultId),
                'property_path' => 'endClient',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
                'data' => $defaultEndClient,
            ]);

            $defaultId = isset($data['end_client_contact']) && $data['end_client_contact'] ? $data['end_client_contact'] : -1;
            $form->add('end_client_contact', ModelType::class, [
                'label' => 'End Client Contact SF ID',
                'class' => Contact::class,
                'query' => ContactQuery::create()->filterById($defaultId),
                'required' => false,
                'placeholder' => 'Enter SF ID or name contact',
                'property_path' => 'endClientContact',
            ]);

            $defaultId = isset($data['contact']) && $data['contact'] ? $data['contact'] : -1;
            $form->add('contact', ModelType::class, [
                'label' => 'Contact SF ID',
                'class' => Contact::class,
                'query' => ContactQuery::create()->filterById($defaultId),
                'placeholder' => 'Enter SF ID or name contact',
                'property_path' => 'contact',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ]);

            $defaultId = isset($data['opportunity']) && $data['opportunity'] ? $data['opportunity'] : -1;
            $form->add('opportunity', ModelType::class, [
                'label' => 'Opportunity SF ID',
                'placeholder' => 'Opportunity',
                'class' => Opportunity::class,
                'query' => OpportunityQuery::create()->filterById($defaultId),
            ]);
        });
    }
}
