<?php

namespace DebugApiBundle\Form\Type;

use Model\Account;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AccountType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Account::class,
            'name' => 'account',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('vat', null, ['property_path' => 'Vat']);
        $builder->add('discount_program_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                ->filterByField('discount_program_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'DiscountProgram',
        ]);

        $builder->add('discount_percentage_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                ->filterByField('discount_percentage_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'DiscountPercentage',
        ]);

        $builder->add('eu_discount_percentage_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                ->filterByField('eu_discount_percentage_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'EuDiscountPercentage',
        ]);

        $builder->add('quant_discount_percentage_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                ->filterByField('quant_discount_percentage_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'QuantDiscountPercentage',
        ]);

        $builder->add('discount_notes', TextareaType::class, [
            'property_path' => 'DiscountNotes',
            'required' => false,
        ]);
    }
}
