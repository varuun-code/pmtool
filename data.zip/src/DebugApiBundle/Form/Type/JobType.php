<?php

namespace DebugApiBundle\Form\Type;

use Model\Etude;
use Model\EtudeQuery;
use Model\Groupe;
use Model\Job;
use Model\Location;
use Model\LocationQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class JobType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Job::class,
            'name' => 'job',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('location_id', ModelType::class, [
            'label' => 'Location',
            'query' => LocationQuery::create()->filterByActive(1),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => Location::class,
            'property_path' => 'jobLocation',
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('id_pm', ModelType::class, [
            'query' => UserQuery::create()->filterByIdGroupe(Groupe::PROJECT_MANAGER),
            'label' => 'PM',
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => User::class,
            'property_path' => 'JobProjectManager',
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('etude', EtudeType::class, [
            'property_path' => 'etude',
        ]);

        $builder->add('on_site_recruits', IntegerType::class, [
            'label' => 'On Site Recruits',
            'property_path' => 'onSiteRecruits',
            'data' => 0,
            'required' => false,
        ]);
        $builder->add('off_site_recruits', IntegerType::class, [
            'label' => 'Off Site Recruits',
            'property_path' => 'offSiteRecruits',
            'data' => 0,
            'required' => false,
        ]);

        $builder->add('room_count', NumberType::class, [
            'label' => 'Room count',
            'required' => false,
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();

            $etudeId = $data && $data->getEtudeId() ? $data->getEtudeId() : -1;
            $etudeQuery = EtudeQuery::create()->filterById($etudeId);
            $etude = $etudeId > -1 ? $etudeQuery->findOne() : null;

            $choiceEtudeOption = [
                'label' => 'Study Number',
                'placeholder' => 'Choose Study',
                'class' => Etude::class,
                'query' => $etudeQuery,
                'property_path' => 'etudeId',
                'mapped' => false,
                'data' => $etude,
                'constraints' => [new NotBlank()],
            ];

            if ($data && $data->getId()) {
                $choiceEtudeOption['disabled'] = true;
                $choiceEtudeOption['constraints'] = [new NotBlank()];
            }

            $form->add('choice_etude', ModelType::class, $choiceEtudeOption);
        });

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();

            $etudeId = $data['choice_etude'] ?? -1;
            $etudeQuery = EtudeQuery::create()->filterById($etudeId);
            $etude = $etudeId > 0 ? $etudeQuery->findOne() : null;

            $choiceEtudeOption = [
                'label' => 'Study Number',
                'placeholder' => 'Choose Study',
                'class' => Etude::class,
                'query' => $etudeQuery,
                'property_path' => 'etudeId',
                'mapped' => false,
                'data' => $etude,
                'constraints' => [new NotBlank()],
            ];

            if ($form->getData()->getId()) {
                $choiceEtudeOption['disabled'] = true;
                $choiceEtudeOption['constraints'] = [];
            }

            $form->add('choice_etude', ModelType::class, $choiceEtudeOption);
        });
    }
}
