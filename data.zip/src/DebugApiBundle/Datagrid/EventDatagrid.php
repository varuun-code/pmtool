<?php

namespace DebugApiBundle\Datagrid;

use Model\EventQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class EventDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return EventQuery::create();
    }

    public function configureFilter()
    {
        return [
            'id' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'id';
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }

    public function getName()
    {
        return 'event';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
