<?php

namespace DebugApiBundle\Datagrid;

use Model\AccountQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class AccountDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return AccountQuery::create();
    }

    public function configureFilter()
    {
        return [
            'id' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'id';
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }

    public function getName()
    {
        return 'account';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
