<?php

namespace DebugApiBundle\Datagrid;

use Model\JobQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Spyrit\PropelDatagridBundle\Datagrid\PropelDatagrid;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class JobDatagrid extends PropelDatagrid
{
    public function configureQuery()
    {
        return JobQuery::create()->filterBySfIgnore(false);
    }

    public function configureFilter()
    {
        return [
            'id' => [
                'type' => TextType::class,
                'options' => ['required' => false],
            ],
        ];
    }

    public function getDefaultSortColumn()
    {
        return 'id';
    }

    public function getDefaultSortOrder()
    {
        return strtolower(Criteria::DESC);
    }

    public function getName()
    {
        return 'job';
    }

    public function getMaxPerPage()
    {
        return 15;
    }
}
