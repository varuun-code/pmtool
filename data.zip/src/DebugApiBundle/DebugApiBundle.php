<?php

namespace DebugApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DebugApiBundle extends Bundle
{
}
