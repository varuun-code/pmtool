/**
 * This class provide ajax datagrid features abstraction to dynamicaly refresh the datagrid.
 * It works well with the SpyritAdminBundle
 * @version 1.0.0
 * @param String identifier
 * @param Array options
 * @returns AjaxDatagridManager
 */
function Datagrid(identifier, options) 
{ 
    this.getParam = function(options, paramName, defaultValue)
    {
        if (options === undefined || options[paramName] === undefined) 
        { 
            if(defaultValue === undefined)
            {
                alert('The param "'+paramName+'" must be filled to the Datagrid.')
                return null;
            }
            return defaultValue;
        }
        else 
        { 
            return options[paramName]; 
        }
    }
    
    this.datagridAreaSelector           = identifier;
    this.datagridRefreshedAreaSelector  = this.getParam(options, 'datagridRefreshedAreaSelector', '.datagrid-table-and-pagination');
    this.datagridMaxPerPageLinkSelector = this.getParam(options, 'datagridMaxPerPageLinkSelector', '.max-per-page a');
    this.datagridSortLinkSelector       = this.getParam(options, 'datagridSortLinkSelector', 'table thead th a');
    this.datagridPaginationLinkSelector = this.getParam(options, 'datagridPaginationLinkSelector', '.pagination a');
    this.filterFormSelector             = this.getParam(options, 'filterFormSelector', 'form.filter-form');
    this.filterResetButtonSelector      = this.getParam(options, 'filterResetButtonSelector', 'form.filter-form a.reset');
    this.datagridLoaderClass            = this.getParam(options, 'datagridLoaderClass', 'datagrid-loader');
    this.callback                       = this.getParam(options, 'callback', function(){ })
    
    var self = this;
    
    this.init = function() 
    { 
        this.addSortListener();
        this.addMaxPerPageListener();
        this.addPaginationListener();
        this.addFilterResetButtonListener();
        this.addFilterSubmitListener();
    } 
    
    this.addSortListener = function()
    {
        this.addClickListener(this.datagridRefreshedAreaSelector, this.datagridAreaSelector, this.datagridSortLinkSelector);
    }
    
    this.addMaxPerPageListener = function()
    {
        this.addClickListener(this.datagridRefreshedAreaSelector, this.datagridAreaSelector, this.datagridMaxPerPageLinkSelector);
    }
    
    this.addPaginationListener = function()
    {
        this.addClickListener(this.datagridRefreshedAreaSelector, this.datagridAreaSelector, this.datagridPaginationLinkSelector);
    }
    
    this.addFilterResetButtonListener = function()
    {
        this.addClickListener(this.datagridRefreshedAreaSelector, this.datagridAreaSelector, this.filterResetButtonSelector);
        this.addResetListener(this.datagridAreaSelector, this.filterFormSelector, this.filterResetButtonSelector)
    }
    
    this.addFilterSubmitListener = function()
    {
        this.addSubmitListener(this.datagridRefreshedAreaSelector, this.datagridAreaSelector, this.filterFormSelector);
    }
    
    this.addSubmitListener = function (refreshedAreaSelector, datagridAreaSelector, linkPathSelector)
    {
        console.log(datagridAreaSelector);
        console.log(linkPathSelector);
        
        console.log('-----');
        $(datagridAreaSelector).on('submit', linkPathSelector, function(event){
            event.preventDefault();
            self.addLoader($(datagridAreaSelector).parent());
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                dataType: 'html',
                context: $(this),
                data: $(this).serialize()
            }).done(function(response) {
                $(this).next(datagridAreaSelector+' '+refreshedAreaSelector+':first').html(response);
                self.removeLoader($(datagridAreaSelector).parent());
                self.callback(response);
            });
        });
    }

    this.addClickListener = function (refreshedAreaSelector, datagridAreaSelector, linkPathSelector)
    {
        $(datagridAreaSelector).on('click', linkPathSelector, function(event){
            event.preventDefault();
            if($(this).attr('href') !== '' && $(this).attr('href') !== '#')
            {
                self.addLoader($(datagridAreaSelector).parent());
                $.ajax({
                    url: $(this).attr('href'),
                    dataType: 'html',
                    context: $(this)
                }).done(function(response) {
                    // Remove previous click delegation declared to avoid multiple ajax request for a same element
                    $(datagridAreaSelector).off('click', linkPathSelector);
                    $(datagridAreaSelector+' '+refreshedAreaSelector).html(response);
                    self.addClickListener(refreshedAreaSelector, datagridAreaSelector, linkPathSelector);
                    self.removeLoader($(datagridAreaSelector).parent());
                    self.callback(response);
                });
            }
        });
    }
    
    this.addResetListener = function(datagridAreaSelector, filterFormAreaSelector, filterButtonSelector)
    {
        $(datagridAreaSelector).on(filterButtonSelector, 'click', function(event){
            $(filterFormAreaSelector).find('input[type!="submit"],select,textarea').val('');
        });
    }
    
    this.addLoader = function ($containerElement)
    {
        var elt = $('<div></div>').addClass(this.datagridLoaderClass);
        $containerElement.append(elt);
        elt.fadeIn();
    }

    this.removeLoader = function ($containerElement)
    {
        $containerElement.find('.'+this.datagridLoaderClass).fadeOut(500,function(){
            $(this).remove();
        });
    }
} 
