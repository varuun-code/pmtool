/**
 * jQuery Datagrid Plugin v1.0.0
 * This class provide javascript datagrid handler features
 * 
 * Copyright 2013, 2014 Maxime CORSON <maxime.corson@spyrit.net>
 * 
 * Released under the MIT license
 */
(function ($) {
    $.fn.datagrid = function( options ) {
        
        var defaults = {
            filtersSelector: '.datagrid-filters',
            tableSelector: '.datagrid-table',
            filterSubmitMethod: 'post',
            submitOnChange: false,
            onUpdate: function($scope){},
        };
        
        return this.each(function() {
            var $this = $(this);
            var settings = $.extend(true, {}, defaults, options, $this.data());
 
            function addClickListener()
            {
                $this.on('click', settings.filtersSelector+ ' a, '+ settings.tableSelector+ ' a:not("tr td a")', function(e) {
                    e.preventDefault();
                    $.ajax({
                       url: $(this).attr('href'),
                       method: 'GET',
                    }).done(function(html){
                        $this.html(html);
                        settings.onUpdate($this);
                    });
                });
            };
            
            function addSubmitListener()
            {
                action = function(e) {
                    console.log($(settings.filtersSelector+ ' form').attr('action'));
                    e.preventDefault();
                    $.ajax({
                        url: $this.find(settings.filtersSelector + ' form').attr('action'),
                        method: settings.filterSubmitMethod,
                        data: $this.find(settings.filtersSelector + ' form').serialize()
                    }).done(function(html){
                        $this.html(html);
                        settings.onUpdate($this);
                    });
                };
                if(settings.submitOnChange === true)
                {
                    $this.on('change', settings.filtersSelector+ ' form :input', action);
                }
                $this.on('submit', settings.filtersSelector+ ' form', action);
            };
            
            addSubmitListener();
            addClickListener();
        });
    };
}( jQuery ));