<?php

namespace Form\Propel\ChoiceList;

use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\Collection\ObjectCollection;
use Symfony\Component\Form\ChoiceList\ArrayChoiceList;
use Symfony\Component\Form\ChoiceList\ChoiceListInterface;

/**
 * ModelNewChoiceList choice list used for some autocomplete type
 * with new propel object to create if not found.
 *
 * bad hack : duplicated code from Propel\PropelBundle\Form\ChoiceList\ModelChoiceList
 * used for autocomplete (need to access some private properties)
 *
 * @author William Durand <william.durand1@gmail.com>
 * @author Charles SANQUER <charles.sanquer@spyrit.net>
 */
class ModelNewChoiceList extends ArrayChoiceList
{
    /**
     * check if we can add new Propel object to the choices.
     *
     * @var bool
     */
    protected $addNew;

    protected $class;

    /**
     * PHP Propel ColumnName used to set not found value on new object.
     *
     * @var string
     */
    protected $newValueColumn;

    /**
     * The fields of which the identifier of the underlying class consists.
     *
     * This property should only be accessed through identifier.
     *
     * @var array
     */
    private $identifier = [];

    /**
     * Query.
     */
    private $query;

    /**
     * Query.
     */
    private $queryCriteria;

    /**
     * @param string        $class
     * @param array         $choices
     * @param ModelCriteria $queryCriteria
     * @param bool          $addNew
     * @param string        $newValueColumn
     */
    public function __construct($class, $choices = null, $queryCriteria = null, $addNew = null, $newValueColumn = null)
    {
        $this->class = $class;

        $queryClass = $this->class.'Query';
        $query = new $queryClass();

        $this->identifier = $query->getTableMap()->getPrimaryKeys();
        $this->query = $query;
        $this->queryCriteria = $queryCriteria;

        $choices = is_iterable($choices) ? $choices : [];

        $this->addNew = (bool) $addNew;
        $this->newValueColumn = $newValueColumn;

        parent::__construct($choices);
    }

    /**
     * Returns the class name.
     *
     * @return string
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Returns the model objects corresponding to the given values.
     *
     * @param array $values
     *
     * @return array
     *
     * @see ChoiceListInterface
     */
    public function getChoicesForValues(array $values)
    {
        if (1 === count($this->identifier)) {
            $identifierPhpName = current($this->identifier)->getPhpName();
            $filterBy = 'filterBy'.$identifierPhpName;
            $results = $this->query->create(null, $this->queryCriteria)
                ->$filterBy($values)
                ->find();

            if ($this->addNew && !empty($this->newValueColumn)) {
                $getMethod = 'get'.$identifierPhpName;
                $resultIds = [];
                foreach ($results as $result) {
                    $resultIds[] = $result->$getMethod();
                }

                $setterMethod = 'set'.$this->newValueColumn;
                foreach ($values as $value) {
                    if (!in_array($value, $resultIds)) {
                        $obj = new $this->class();
                        $obj->$setterMethod($value);
                        $results[] = $obj;
                    }
                }
            }

            return $results ? $results->getData() : [];
        }

        return parent::getChoicesForValues($values);
    }

    /**
     * Returns the values corresponding to the given model objects.
     *
     * @param array $models
     *
     * @return array
     *
     * @see ChoiceListInterface
     */
    public function getValuesForChoices(array $models)
    {
        // Optimize performance for single-field identifiers. We already
        // know that the IDs are used as values

        // Attention: This optimization does not check choices for existence
        if (1 === count($this->identifier)) {
            $values = [];
            foreach ($models as $model) {
                if ($model instanceof $this->class) {
                    // Make sure to convert to the right format
                    $values[] = (string) current($this->getIdentifierValues($model));
                }
            }

            return $values;
        }

        return parent::getValuesForChoices($models);
    }

    /**
     * Returns the values of the identifier fields of an model.
     *
     * Propel must know about this model, that is, the model must already
     * be persisted or added to the idmodel map before. Otherwise an
     * exception is thrown.
     *
     * @param object $model The model for which to get the identifier
     */
    private function getIdentifierValues($model)
    {
        if (method_exists($model, 'getPrimaryKey')) {
            return [$model->getPrimaryKey()];
        }

        // readonly="true" models do not implement Persistent.
        if (!($model instanceof ObjectCollection) && method_exists($model, 'getPrimaryKey')) {
            return [$model->getPrimaryKey()];
        }

        return $model->getPrimaryKeys();
    }

    /**
     * Fixes the data type of the given choice index to avoid comparison
     * problems.
     *
     * @param mixed $index the choice index
     *
     * @return int|string the index as PHP array key
     */
    protected function fixIndex($index)
    {
        if (is_bool($index) || (string) (int) $index === (string) $index) {
            return (int) $index;
        }

        return (string) $index;
    }
}
