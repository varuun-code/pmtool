<?php

namespace Form\Propel;

use Form\Propel\ChoiceList\ModelNewChoiceList;
use Form\Propel\DataTransformer\ArrayToSeparatedStringTransformer;
use Propel\Bundle\PropelBundle\Form\DataTransformer\CollectionToArrayTransformer;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\DataTransformer\ChoicesToValuesTransformer;
use Symfony\Component\Form\Extension\Core\DataTransformer\ChoiceToValueTransformer;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\Options;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\PropertyAccess\PropertyAccessor;

class Select2HiddenPropelType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if ($options['multiple']) {
            $builder
                ->addViewTransformer(new CollectionToArrayTransformer(), true)
                ->addViewTransformer(new ChoicesToValuesTransformer($options['choice_list']))
                ->addViewTransformer(new ArrayToSeparatedStringTransformer($options['separator'], null, false))
            ;
        } else {
            $builder
                ->addViewTransformer(new ChoiceToValueTransformer($options['choice_list']));
        }
    }

    protected function buildPropelInitSource($values, $initValues, $property = null)
    {
        $values = explode(',', $values);
        $data = [];
        foreach ($initValues as $key => $value) {
            if (in_array($key, $values)) {
                $data[$key] = $value;
            }
        }

        return $this->buildPropelSelect2Data($data, $property);
    }

    protected function buildPropelSelect2Data($values, $property = null)
    {
        $propertyPath = null;
        if (!empty($property)) {
            $propertyPath = new PropertyAccessor();
        }

        $data = [];
        foreach ($values as $key => $value) {
            $data[] = ['id' => $key, 'text' => ($propertyPath ? $propertyPath->getValue($value, $property) : (string) $value)];
        }

        return $data;
    }

    protected function buildCommonJsConfig(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['customAjaxJson'] = $options['custom_ajax_json'];

        $view->vars['js_config'] = [
            'separator' => $options['separator'],
            'minimumInputLength' => $options['min_input_length'],
            'maximumSelectionSize' => $options['max_selection_size'],
            'multiple' => $options['multiple'],
            'closeOnSelect' => !$options['multiple'],
        ];

        if (!empty($options['formatSelection'])) {
            $view->vars['formatSelection'] = $options['formatSelection'];
        }

        if (!empty($options['formatResult'])) {
            $view->vars['formatResult'] = $options['formatResult'];
        }

        if (in_array($options['width'], ['resolve', 'copy'])) {
            $view->vars['js_config']['width'] = $options['width'];
        } elseif (!empty($options['width'])) {
            $view->vars['js_config']['width'] = 'copy';
            $view->vars['attr']['style'] = 'width: '.$options['width'];
        } else {
            $view->vars['js_config']['width'] = 'resolve';
        }

        if (!empty($options['empty_value'])) {
            $view->vars['js_config']['placeholder'] = $options['empty_value'];
            if (!$options['multiple']) {
                $view->vars['js_config']['allowClear'] = $options['allow_clear'];
            }
        }
    }

    protected function buildSourceData(FormView $view, FormInterface $form, array $options)
    {
        $view->vars['useTags'] = $options['use_tags'];
        $view->vars['maxPerPage'] = $options['max_per_page'];
        $view->vars['initSource'] = null;

        $choices = empty($options['class']) ? null : $options['choice_list'];

        $options['choices'] = empty($options['choices']) ? [] : $options['choices'];
        $options['init_choices'] = empty($options['init_choices']) ? $options['choices'] : $options['init_choices'];

        $view->vars['sourceType'] = is_array($options['choices']) ? 'values' : 'route';
        $view->vars['initSourceType'] = is_array($options['init_choices']) ? 'values' : 'route';

        if ($options['use_tags']) {
            $view->vars['js_config']['tokenSeparators'] = [',', ' '];
            $view->vars['js_config']['tags'] = is_array($options['choices']) && $choices ? $this->buildPropelSelect2Data($choices->getChoices(), $options['property']) : true;
        }

        if (is_array($options['choices']) && $choices) {
            if (!$options['use_tags']) {
                $view->vars['js_config']['data'] = $this->buildPropelSelect2Data($choices->getChoices(), $options['property']);
            }
        } else {
            $view->vars['source'] = $options['choices'];
        }
        if (null !== $view->vars['value'] && '' !== $view->vars['value']) {
            if (is_array($options['init_choices'])) {
                $view->vars['initSource'] = $this->buildPropelInitSource($view->vars['value'], $options['init_choices'], $options['property']);
            } else {
                $view->vars['initSource'] = $options['init_choices'];
            }
        } elseif (is_array($options['init_choices'])) {
            $initChoices = $options['init_choices'];
            reset($options['init_choices']);
            $view->vars['initSource'] = $this->buildPropelInitSource(key($options['init_choices']), $initChoices, $options['property']);
        }
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $choiceList = function (Options $options) {
            return new ModelNewChoiceList(
                $options['class'],
                is_array($options['choices']) ? $options['choices'] : null,
                $options['query'],
                $options['use_tags'],
                $options['tag_column']
            );
        };

        $resolver
            ->setDefaults([
                'multiple' => false,
                'separator' => ',',
                'min_input_length' => null,
                'max_selection_size' => null,
                'allow_clear' => true,
                'empty_value' => null,
                'width' => 'resolve',
                'init_choices' => null,
                'max_per_page' => 10,
                'use_tags' => false,
                'formatSelection' => null,
                'formatResult' => null,
                'label_attr' => ['class' => 'select2_label'],
                // Propel
                'tag_column' => null,
                'class' => null,
                'property' => null,
                'query' => null,
                'choices' => null,
                'group_by' => null,
                'choice_list' => $choiceList,
                'index_property' => null,
                'custom_ajax_json' => null,
            ])
            ->setAllowedTypes('init_choices', ['array', 'string', 'null'])
            ->setAllowedTypes('choices', ['array', 'string', 'null'])
        ;
    }

    public function buildView(FormView $view, FormInterface $form, array $options)
    {
        $this->buildCommonJsConfig($view, $form, $options);
        $this->buildSourceData($view, $form, $options);
    }

    public function getParent()
    {
        return TextType::class;
    }

    public function getName()
    {
        return 'select2_hidden_propel';
    }
}
