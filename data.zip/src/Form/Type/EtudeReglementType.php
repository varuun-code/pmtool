<?php

namespace Form\Type;

use Model\Banque;
use Model\Document;
use Model\Reglement;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class EtudeReglementType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Reglement::class,
            'name' => 'etude_reglement',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'bank_query' => null,
            'document_query' => null,
        ]);
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('date', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('banque', ModelType::class, [
            'query' => $options['bank_query'],
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a bank',
            'class' => Banque::class,
//            'constraints' => [ new NotBlank(), ],
        ]);

        $builder->add('document', ModelType::class, [
            'query' => $options['document_query'],
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a document',
            'class' => Document::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('reference', TextType::class, [
            'required' => false,
        ]);

        $builder->add('montant', NumberType::class, [
            'required' => true,
        ]);
    }
}
