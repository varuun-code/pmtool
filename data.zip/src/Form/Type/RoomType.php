<?php

namespace Form\Type;

use Model\Location;
use Model\LocationQuery;
use Model\RefRoom;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class RoomType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => RefRoom::class,
            'name' => 'room',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'Name',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('active', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('location', ModelType::class, [
                'label' => 'Location',
                'placeholder' => 'Select a location',
                'query' => LocationQuery::create()->filterByActive(true)->orderByLibelle(),
                'multiple' => false,
                'expanded' => false,
                'required' => true,
                'constraints' => [new NotBlank()],
                'class' => Location::class,
            ])
            ->add('roomCount', NumberType::class, [
                'label' => 'Room Count',
                'required' => false,
            ])
        ;
    }
}
