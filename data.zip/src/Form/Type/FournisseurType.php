<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Banque;
use Model\BanqueQuery;
use Model\Coefficient;
use Model\CoefficientQuery;
use Model\Fournisseur;
use Model\Pays;
use Model\PaysQuery;
use Model\User;
use Model\Ville;
use Model\VilleQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class FournisseurType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
          'data_class' => Fournisseur::class,
          'name' => 'fournisseur',
          'csrf_protection' => false,
          'cascade_validation' => true,
          'parent_data' => [],
          'event_dispatcher' => null,
      ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('numero_entreprise', TextType::class, [
                'label' => 'Number',
                'required' => false,
            ])
            ->add('id_sams', TextType::class, [
                'label' => 'Sams Id',
                'required' => false,
            ])
            ->add('numero_ss', TextType::class, [
                'label' => 'Tax N.',
                'required' => false,
            ])
            ->add('notes', TextareaType::class, [
                'label' => 'Notes',
                'required' => false,
            ])
            ->add('tarif', TextType::class, [
                'label' => 'Rate',
                'required' => false,
            ])
            ->add('societe', TextType::class, [
                'label' => 'Company',
                'required' => false,
            ])
            ->add('nom', TextType::class, [
                'label' => 'Lastname',
                'required' => true,
            ])
            ->add('prenom', TextType::class, [
                'label' => 'Firstname',
                'required' => true,
            ])
            ->add('tel', TextType::class, [
                'label' => 'Phone',
                'required' => false,
            ])
            ->add('portable', TextType::class, [
                'label' => 'Mobile',
                'required' => false,
            ])
            ->add('fax', TextType::class, [
                'label' => 'Fax',
                'required' => false,
            ])
            ->add('ne_le', DateType::class, [
                'widget' => 'single_text',
                'label' => 'Born',
                'format' => 'dd/MM/yyyy',
                'html5' => false,
                'required' => false,
            ])
            ->add('ne_a', TextType::class, [
                'label' => 'At',
                'required' => false,
            ])
            ->add('email', TextType::class, [
                'label' => 'Email',
                'required' => false,
            ])
            ->add('adresse2', TextType::class, [
                'label' => 'Adresse 2',
                'required' => false,
            ])
            ->add('adresse', TextType::class, [
                'label' => 'Adresse',
                'required' => true,
            ])
            ->add('email2', TextType::class, [
                'label' => 'E-mail 2',
                'required' => false,
            ])
            ->add('nationalite', TextType::class, [
                'label' => 'Nationality',
                'required' => false,
            ])
            ->add('taux_horaire', TextType::class, [
                'label' => 'Hourly Rate',
                'required' => false,
            ])
            ->add('phoneroom_hourly_rate', TextType::class, [
                'label' => 'PhoneRoom Hourly Rate',
                'required' => false,
            ])
            ->add('discount_exclude', CheckboxType::class, [
                'label' => 'Exclude from Discount',
                'required' => false,
                'value' => 0,
            ])
            ->add('nom_compte', TextType::class, [
                'label' => 'Account Name',
                'required' => false,
            ])
            ->add('banque_code', TextType::class, [
                'label' => 'Bank Code',
                'required' => false,
            ])
            ->add('numero_compte', TextType::class, [
                'label' => 'Account Number',
                'required' => false,
            ])
            ->add('iban', TextType::class, [
                'label' => 'IBAN',
                'required' => false,
            ])
            ->add('bic', TextType::class, [
                'label' => 'BIC',
                'required' => false,
            ])
            ->add('avg_hours_per_day', NumberType::class, [
                'label' => 'Avg hours per day',
                'required' => false,
            ])
            ->add('holidays_per_year', NumberType::class, [
                'label' => 'holidays per year',
                'required' => false,
            ])
            ->add('correction_extra_hours', NumberType::class, [
                'label' => 'Start extra hours',
                'required' => false,
            ])
            ->add('start_extra_hours', NumberType::class, [
                'label' => 'Start extra hours',
                'required' => false,
            ])
            ->add('debit_hours_monday', NumberType::class, [
                'label' => 'Debit hours Monday',
                'required' => false,
            ])
            ->add('debit_hours_tuesday', NumberType::class, [
                'label' => 'Debit hours Tuesday',
                'required' => false,
            ])
            ->add('debit_hours_wednesday', NumberType::class, [
                'label' => 'Debit hours Wednesday',
                'required' => false,
            ])
            ->add('debit_hours_thursday', NumberType::class, [
                'label' => 'Debit hours Thursday',
                'required' => false,
            ])
            ->add('debit_hours_friday', NumberType::class, [
                'label' => 'Debit hours Friday',
                'required' => false,
            ])
            ->add('max_hours_per_week', NumberType::class, [
                'label' => 'Max hours per week',
                'required' => false,
            ])
            ->add('max_hours_per_month', NumberType::class, [
                'label' => 'Max hours per month',
                'required' => false,
            ])
            ->add('including_extra_hours', NumberType::class, [
                'label' => 'Including extra hours',
                'required' => false,
            ])
            ->add('debit_hours_saturday', NumberType::class, [
                'label' => 'Debit hours Saturday',
                'required' => false,
            ])
            ->add('debit_hours_sunday', NumberType::class, [
                'label' => 'Debit hours Sunday',
                'required' => false,
            ])
            ->add('agreement', ChoiceType::class, [
                'label' => 'Agreement',
                'choices' => [
                    'No' => 'N',
                    'Yes' => 'Y',
                ],
                'preferred_choices' => 'N',
                'required' => false,
            ])
            ->add('numero_credit', TextType::class, [
                'label' => 'Creditor no',
                'required' => false,
            ])
            ->add('employe', ChoiceType::class, [
                'label' => 'Empl.',
                'required' => false,
                'choices' => array_flip(Fournisseur::TYPES),
            ])
            ->add('qualite', ChoiceType::class, [
                'label' => 'Civ.',
                'required' => false,
                'choices' => User::getListeQualite($this->instance),
            ])
            ->add('taxable', ChoiceType::class, [
                'label' => 'Taxable',
                'required' => false,
                'choices' => [
                    'No' => 'N',
                    'Yes' => 'Y',
                ],
            ])
            ->add('active', ChoiceType::class, [
                'label' => 'active',
                'required' => true,
                'choices' => [
                    'No' => 'N',
                    'Yes' => 'Y',
                ],
            ])
            ->add('coefficient', ModelType::class, [
                'query' => CoefficientQuery::create(),
                'preferred_choices' => ['1.00'],
                'class' => Coefficient::class,
            ])
            ->add('ville', Select2HiddenPropelType::class, [
                'label' => 'City',
                'multiple' => false,
                'required' => true,
                'property' => 'id',
                'constraints' => new NotBlank(),
                'empty_value' => 'Select a city',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => VilleQuery::create(),
                'choices' => 'city_search_by_name',
                'init_choices' => 'city_search_by_name_init',
                'class' => Ville::class,
            ])
            ->add('banque', ModelType::class, [
                'label' => 'Bank',
                'query' => BanqueQuery::create(),
                'required' => false,
                'multiple' => false,
                'placeholder' => 'Select a bank',
                'class' => Banque::class,
            ])
            ->add('banque', Select2HiddenPropelType::class, [
                'label' => 'Bank',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select a bank',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => BanqueQuery::create(),
                'choices' => 'bank_search_by_name',
                'init_choices' => 'bank_search_by_name_init',
                'class' => Banque::class,
            ])
            ->add('pays', ModelType::class, [
                'label' => 'Country',
                'query' => PaysQuery::create()->filterByGeneric(true)->orderByPays(),
                'required' => false,
                'multiple' => false,
                'placeholder' => 'Select a country',
                'class' => Pays::class,
            ])
            ->add('account', Select2HiddenPropelType::class, [
                'label' => 'Account',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select an account',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => AccountQuery::create(),
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])
        ;
    }
}
