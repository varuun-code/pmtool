<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Etude;
use Model\EtudeQuery;
use Model\LocationQuery;
use Model\PhoneroomActivity;
use Model\PhoneroomTarget;
use Model\PhoneroomTargetQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\ChoiceList\Loader\CallbackChoiceLoader;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class MyPhoneRoomActivityType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => PhoneroomActivity::class,
            'name' => 'phoneroom_activity',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('categorie_prestation', ModelType::class, [
                'query' => CategoriePrestationQuery::create()->filterByPractivityOk('Y')->orderByCategorie(),
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
                'multiple' => false,
                'expanded' => false,
                'label' => false,
                'placeholder' => 'Select a category',
                'class' => CategoriePrestation::class,
            ])
            ->add('id_location_pr', ChoiceType::class, [
                 'required' => false,
                 'choice_loader' => new CallbackChoiceLoader(function () {
                     return LocationQuery::create()->find()->toKeyValue('Libelle', 'Id');
                 }),
             ])
            ->add('phoneroom_target', ModelType::class, [
                'query' => PhoneroomTargetQuery::create()->orderByTarget(),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'label' => false,
                'class' => PhoneroomTarget::class,
            ])
            ->add('nb_heure', NumberType::class, [
                'label' => false,
                'required' => true,
                'attr' => [
                    'autocomplete' => 'off',
                ],
            ])
            ->add('nb_recruitment', NumberType::class, [
                'label' => false,
                'empty_data' => 0,
                'required' => false,
                'attr' => [
                    'autocomplete' => 'off',
                ],
            ])
            ->add('bonus', NumberType::class, [
                'label' => false,
                'empty_data' => 0,
                'required' => false,
                'attr' => [
                    'autocomplete' => 'off',
                ],
            ])
            ->add('valide', ChoiceType::class, [
                 'label' => false,
                 'choices' => [
                     'No' => 'N',
                     'Yes' => 'Y',
                 ],
            ])
            ->add('job_id', HiddenType::class, [
                 'label' => false,
            ])
        ;

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();

            $job = $data ? $data->getJob() : null;
            $initChoices = $job ? [$job->getEtudeId() => $job->getProjectName()] : 'job_search';
            $value = $job ? $job->getEtudeId() : '';

            $form->add('etude', Select2HiddenPropelType::class, [
                'query' => EtudeQuery::create(),
                'mapped' => false,
                'required' => false,
                'multiple' => false,
                'label' => false,
                'formatSelection' => 'formatSelectedJobPhoneroom',
                'formatResult' => 'formatResultPerson',
                'class' => Etude::class,
                'choices' => 'job_search',
                'init_choices' => $initChoices,
                'attr' => ['data-value' => $value],
            ]);
        });
    }
}
