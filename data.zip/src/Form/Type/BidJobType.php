<?php

namespace Form\Type;

use Model\BidJob;
use Model\Location;
use Model\LocationQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class BidJobType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => BidJob::class,
            'name' => 'bid_job',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'allow_extra_fields' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if ($builder->getData() && $builder->getData()->isNew()) {
            $builder
                ->add('location', ModelType::class, [
                    'label' => 'Location',
                    'query' => LocationQuery::create()->filterByActive(1),
                    'required' => true,
                    'multiple' => false,
                    'expanded' => false,
                    'placeholder' => 'Select a location',
                    'class' => Location::class,
                    'constraints' => [
                        new NotBlank(),
                    ],
                ]);
        }
        $builder->add('IsMultimarket', TextType::class, [
                'label' => false,
                'required' => false,
            ])
            ->add('PerHour', TextType::class, [
                'label' => false,
                'required' => false,
                'empty_data' => '0',
            ])
            ->add('PerGroup', TextType::class, [
                'label' => false,
                'required' => false,
                'empty_data' => 0,
            ])
            ->add('PerDay', TextType::class, [
                'label' => false,
                'required' => false,
                'empty_data' => 0,
            ])
            ->add('MultimarketInCalculation', TextType::class, [
                'label' => false,
                'required' => false,
            ])
            ->add('name', TextType::class, [
                'label' => false,
                'required' => false,
            ])
        ;
    }
}
