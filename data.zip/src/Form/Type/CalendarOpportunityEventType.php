<?php

namespace Form\Type;

use Model\EventMethodology;
use Model\EventMethodologyQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoom;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class CalendarOpportunityEventType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'allow_extra_fields' => true,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                // $data = $event->getData();
                $form = $event->getForm();
                $choicesSelection = RefRoom::getRoomsNamesAndLocationsForChoiceSelection();

                $form->add('status', ModelType::class, [
                    'label' => 'Event status',
                    'placeholder' => 'Select a status',
                    'query' => RefEventStatusQuery::create(),
                    'multiple' => false,
                    'expanded' => false,
                    'required' => true,
                    'data' => RefEventStatusQuery::create()->filterByName(RefEventStatus::TENTATIVE)->findOne(),
                    'attr' => [
                        'placeholder' => 'status',
                    ],
                    'class' => RefEventStatus::class,
                ])
                ->add('ref_room_id', ChoiceType::class, [
                     'choices' => $choicesSelection,
                     'placeholder' => 'Select a Room',
                     'attr' => ['placeholder' => 'Select a Room'],
                     'label' => 'Room',
                     'required' => true,
                     'disabled' => true,
                ])
                ->add('event_methodology', ModelType::class, [
                    'query' => EventMethodologyQuery::create()->filterAndOrderForChoice(),
                    'required' => true,
                    'constraints' => [new NotBlank()],
                    'multiple' => false,
                    'expanded' => false,
                    'label' => 'Event methodology',
                    'placeholder' => 'Select a methodology',
                    'class' => EventMethodology::class,
                ])
                ->add('facility_note', TextareaType::class, [
                    'label' => 'Facility Note',
                    'required' => false,
                ])
                ->add('save', SubmitType::class, [
                    'label' => 'Save',
                    'attr' => ['class' => 'btn-success'],
                ]);
            }
        );
    }
}
