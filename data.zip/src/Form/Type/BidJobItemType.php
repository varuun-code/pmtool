<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\BidJobItem;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class BidJobItemType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => BidJobItem::class,
            'name' => 'bid_job_item',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'allow_extra_fields' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('title', TextType::class, [
                'label' => false,
                'required' => false,
            ])
            ->add('date', DateType::class, [
                'label' => 'Date',
                'widget' => 'single_text',
                'format' => 'dd/MM/yyyy',
                'required' => false,
                'html5' => false,
            ])
            ->add('selling_qty', NumberType::class, [
                'label' => 'Qty',
                'required' => false,
            ])
            ->add('selling_unit_price', NumberType::class, [
                'label' => 'Local Unit',
                'required' => false,
                'scale' => 2,
            ])
//            ->add('unit', NumberType::class, [
//                'label' => 'Unit',
//                'required' => false,
//                'scale' => 2,
//            ])
            ->add('selling_price', NumberType::class, [
                'label' => 'Price',
                'required' => false,
                'scale' => 2,
            ])
            ->add('cost_qty', NumberType::class, [
                'label' => 'Qty',
                'required' => false,
            ])
            ->add('cost_unit_price', NumberType::class, [
                'label' => 'Unit price',
                'required' => false,
                'scale' => 2,
            ])
            ->add('cost_location_unit_price', NumberType::class, [
                'label' => 'Resp. Location Unit',
                'required' => false,
                'scale' => 2,
            ])
            ->add('cost_rate', NumberType::class, [
                'label' => 'Price',
                'empty_data' => 1,
                'required' => false,
                'scale' => 2,
            ])
            ->add('discount_auto', HiddenType::class)
            ->add('cost_price', NumberType::class, [
                'label' => 'Price',
                'required' => false,
                'scale' => 2,
            ])
            ->add('pm_comment', TextareaType::class, [
                'label' => 'Discount comment',
                'required' => false,
            ])
            ->add('discount_comment', TextareaType::class, [
                'label' => 'Discount comment',
                'required' => false,
                'constraints' => [
                    new Length([
                        'max' => 255,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                    ],
            ])
            ->add('discount_percent', NumberType::class, [
                'label' => 'Price',
                'required' => false,
                'scale' => 2,
            ])
            ->add('discount_exclude', CheckboxType::class, [
                'label' => 'Discount exclude',
                'required' => false,
                'value' => 0,
            ])
            ->add('order', HiddenType::class)
            ->add('group', HiddenType::class)
            ->add('group_title', HiddenType::class)
            ->add('super_group', HiddenType::class)
            ->add('super_group_title', HiddenType::class)
            ->add('methodology', ModelType::class, [
                'label' => 'Methodology',
                'query' => RefSalesForceQuery::create()->filterByfield('methodology'),
                'required' => false,
                'multiple' => false,
                'placeholder' => 'Select a methodology',
                'class' => RefSalesForce::class,
            ])
            ->add('category', ChoiceType::class, [
                'choices' => CategoriePrestationQuery::create()->withColumn('consolidation', 'id')->withColumn('consolidation', 'value')->select('consolidation')->find()->toKeyValue('id', 'value'),
                'placeholder' => 'Select a category',
            ])
            ->add('resp_location', ModelType::class, [
                'label' => 'Resp. Location',
                'query' => RefSalesForceQuery::create()->filterByfield('respondent_location_id')->filterByActif(true)->orderBy('value', Criteria::ASC),
                'required' => false,
                'multiple' => false,
                'placeholder' => 'Select a resp. location',
                'class' => RefSalesForce::class,
            ])
            ->add('respondent_type', ModelType::class, [
                'label' => 'Respondent type',
                'query' => RefSalesForceQuery::create()->filterByfield('respondent_type'),
                'required' => false,
                'multiple' => false,
                'placeholder' => 'Select a respondent type',
                'class' => RefSalesForce::class,
            ])
        ;

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                $form = $event->getForm();
                $data = $event->getData();
                $sectionInitChoices = ($data && $section = $data->getSection()) ? [$section->getId() => $section->getCategory()] : [];
                $vendorInitChoices = ($data && $vendor = $data->getVendor()) ? [$vendor->getId() => $vendor->getFullnameOrCompany()] : [];

                $form->add('section', Select2HiddenPropelType::class, [
                    'label' => 'Section',
                    'query' => CategoriePrestationQuery::create(),
                    'required' => true,
                    'multiple' => false,
                    'constraints' => new NotBlank(),
                    'empty_value' => 'Select a section',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'choices' => 'categorie_prestation_search_by_consolidation',
                    'init_choices' => $sectionInitChoices,
                    'class' => CategoriePrestation::class,
                    'custom_ajax_json' => 'ajax: window.searchCategoryByConsolidation, initSelection: window.categoryInitSelection',
                ])->add('vendor', Select2HiddenPropelType::class, [
                    'label' => 'supplier',
                    'query' => FournisseurQuery::create(),
                    'required' => false,
                    'multiple' => false,
                    'empty_value' => 'Select a supplier',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'choices' => 'fourniseur_search_by_name_vendor',
                    'init_choices' => $vendorInitChoices,
                    'class' => Fournisseur::class,
                    'custom_ajax_json' => 'ajax: window.searchFournisseurByName, initSelection: window.supplierInitSelection',
                ]);
            }
        );
    }
}
