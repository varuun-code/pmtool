<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Coefficient;
use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\JobCost;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class JobCostType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => JobCost::class,
            'name' => 'job_cost',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'allow_extra_fields' => true, // silently ignore submitted supplier if PO number was just created
            'parent_data' => [],
        ]);
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('sous_type_prestation', TextType::class, [
            'label' => false,
            'required' => false,
        ]);

        $builder->add('category', ChoiceType::class, [
            'choices' => CategoriePrestationQuery::create()->withColumn('consolidation', 'id')->withColumn('consolidation', 'value')->select('consolidation')->find()->toKeyValue('id', 'value'),
            'placeholder' => 'Select a category',
        ]);

        $builder->add('quantite_pr', NumberType::class, [
            'label' => false,
            'required' => false,
        ]);

        $builder->add('order', HiddenType::class);

        $builder->add('group', HiddenType::class);

        $builder->add('group_title', HiddenType::class);

        $builder->add('unit_price', NumberType::class, [
            'label' => false,
            'required' => false,
        ]);

        $builder->add('paid', NumberType::class, [
            'label' => false,
            'required' => false,
        ]);

        $builder->add('coefficiant', ChoiceType::class, [
            'choices' => Coefficient::getCoefficients(),
            'preferred_choices' => ['1.00'],
        ]);

        $builder->add('prix_revient', NumberType::class, [
            'attr' => [
                'readonly' => true,
            ],
            'label' => false,
            'required' => false,
        ]);

        $builder->add('prix_vente_unitaire_location', NumberType::class, [
            'attr' => [
                'readonly' => true,
            ],
            'label' => 'Resp. location Unit',
            'required' => false,
        ]);

        $builder->add('comment_pm', HiddenType::class);

        $builder->add('comment_fnr', HiddenType::class);

        $builder->add('supplier_ref', HiddenType::class);

        $builder->add('internal_ref', HiddenType::class);

        $builder->add('invoice_received_date', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('date_entry_fnr', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('period_of_performance', TextType::class, [
            'label' => false,
            'required' => false,
        ]);

        $builder->add('payment_date', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('invoice_date', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('date', DateType::class, [
            'label' => 'Date',
            'widget' => 'single_text',
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('resp_location', ModelType::class, [
            'label' => 'Resp. Location',
            'query' => RefSalesForceQuery::create()->filterByfield('respondent_location_id')->orderBy('value', Criteria::ASC),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a resp. location',
            'class' => RefSalesForce::class,
        ]);

        $builder->add('respondent_type', ModelType::class, [
            'label' => 'Respondent type',
            'query' => RefSalesForceQuery::create()->filterByfield('respondent_type'),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a respondent type',
            'class' => RefSalesForce::class,
        ]);

        $builder->add('methodology', ModelType::class, [
            'label' => 'Methodology',
            'query' => RefSalesForceQuery::create()->filterByfield('methodology'),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a methodology',
            'class' => RefSalesForce::class,
        ]);

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                $form = $event->getForm();
                $data = $event->getData();
                $categoryInitChoices = ($data && $category = $data->getCategoriePrestation()) ? [$category->getId() => $category->getCategory()] : [];
                $form->add('categorie_prestation', Select2HiddenPropelType::class, [
                    'label' => 'Section',
                    'query' => CategoriePrestationQuery::create(),
                    'required' => true,
                    'multiple' => false,
                    'constraints' => new NotBlank(),
                    'empty_value' => 'Select a section',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'choices' => 'categorie_prestation_search_by_consolidation_for_jobcost',
                    'init_choices' => $categoryInitChoices,
                    'class' => CategoriePrestation::class,
                    'custom_ajax_json' => 'ajax: window.searchCategoryByConsolidationForJobCost, initSelection: window.categoryInitSelection',
                ]);
                if ($data && $fournisseur = $data->getFournisseur()) {
                    if (!$data->getPoNumber() && !$data->isSourceAuto()) {
                        $form->add('fournisseur', Select2HiddenPropelType::class, [
                            'label' => false,
                            'multiple' => false,
                            'required' => false,
                            'property' => 'getFullnameOrCompany',
                            'empty_value' => 'Select a supplier',
                            'formatSelection' => 'formatSelectedPerson',
                            'formatResult' => 'formatResultPerson',
                            'query' => FournisseurQuery::create(),
                            'choices' => 'fournisseur_search_for_job_cost',
                            'init_choices' => [$fournisseur->getId() => $fournisseur],
                            'class' => Fournisseur::class,
                        ]);
                    }
                } elseif (!$data || (!$data->getPoNumber() && !$data->isSourceAuto())) {
                    $form->add('fournisseur', Select2HiddenPropelType::class, [
                        'label' => false,
                        'multiple' => false,
                        'required' => false,
                        'property' => 'getFullnameOrCompany',
                        'empty_value' => 'Select a supplier',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => FournisseurQuery::create(),
                        'choices' => 'fournisseur_search_for_job_cost',
                        'init_choices' => 'fournisseur_search_by_name_init',
                        'class' => Fournisseur::class,
                    ]);
                }
            }
        );
    }
}
