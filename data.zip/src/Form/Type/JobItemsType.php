<?php

namespace Form\Type;

use Model\BidJobItem;
use Model\Job;
use Model\User;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Validator\Constraints\Count;

class JobItemsType extends AbstractType
{
    private $user;

    public function __construct(TokenStorageInterface $tokenStorage)
    {
        /** @var User */
        $user = $tokenStorage->getToken()->getUser();
        $this->user = $user;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Job::class,
            'name' => 'job_items',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'costs_enabled' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('hash', HiddenType::class, ['mapped' => false]) // to check that Collection has not been modified in-between
        ;
        $builder
            ->add('field', HiddenType::class, ['mapped' => false]) // to allow posting empty collection
            ->add('job_items', CollectionType::class, [
                'label' => false,
                'entry_type' => JobItemType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
                'by_reference' => false,
                'entry_options' => [
                    'label' => false,
                    'parent_data' => $builder->getData(),
                    'costs_enabled' => $options['costs_enabled'],
                ],
                'constraints' => [
                    new Count([
                        'max' => BidJobItem::MAX_COUNT,
                    ]),
                ],
            ])
        ;
        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $formEvent) {
            $form = $formEvent->getForm();
            $job = $formEvent->getData();
            $form->get('hash')->setData($job->getJobItemsHash());
        });

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $formEvent) {
            $form = $formEvent->getForm();
            $job = $formEvent->getData();
            $newHash = $form->get('hash')->getData();
            if ($newHash != $job->getJobItemsHash() && $job->getUpdatedById() && $job->getUpdatedById() !== $this->user->getId()) {
                $error = new FormError('The job have been modified since you started editing. Please refresh the page before saving!');
                $form->addError($error);
            }
        });
    }
}
