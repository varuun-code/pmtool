<?php

namespace Form\Type;

use Model\Job;
use Model\Site;
use Model\SiteQuery;
use Model\User;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class JobEventsType extends AbstractType
{
    private string $instance;
    private User $user;

    public function __construct(TokenStorageInterface $tokenStorage, string $instance)
    {
        /** @var User */
        $user = $tokenStorage->getToken()->getUser();
        $this->user = $user;
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Job::class,
            'name' => 'job_events',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'user' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('hash', HiddenType::class, ['mapped' => false]) // to check that Collection has not been modified in-between
        ;

        $builder
                ->add('site', ModelType::class, [
                    'required' => false,
                    'label' => 'Offsite location',
                    'label_attr' => ['style' => 'margin-left: 25px;font-weight: bold'],
                    'class' => Site::class,
                    'query' => SiteQuery::create()->filterBySamsLocation('')->_or()
                        ->filterBySamsLocation(null, Criteria::ISNULL)->orderByLieu(),
                    'choice_label' => 'Lieu',
                ])
            ;

        $builder
            ->add('events', CollectionType::class, [
                'label' => false,
                'entry_type' => JobEventType::class,
                'allow_add' => true,
                'allow_delete' => false,
                'delete_empty' => false,
                'by_reference' => false,
                'entry_options' => [
                    'label' => false,
                    'parent_data' => $builder->getData(),
                    'user' => $options['user'],
                ],
            ])
        ;

        $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $formEvent) {
            $form = $formEvent->getForm();
            $job = $formEvent->getData();
            $form->get('hash')->setData($job->getEventsHash());
        });

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $formEvent) {
            $form = $formEvent->getForm();
            $job = $formEvent->getData();
            $newHash = $form->get('hash')->getData();
            if ($newHash != $job->getEventsHash() && $job->getUpdatedById() && $job->getUpdatedById() !== $this->user->getId()) {
                $error = new FormError('The events have been modified since you started editing. Please refresh the page before saving!');
                $form->addError($error);
            }
        });
    }

    // Reorder modules by Date in view.
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        usort($view['events']->children, function (FormView $a, FormView $b) {
            $posA = $a->vars['data']->getDate();
            $posB = $b->vars['data']->getDate();

            if ($posA == $posB) {
                $posA = $a->vars['data']->getId();
                $posB = $b->vars['data']->getId();

                if ($posA == $posB) {
                    return 0;
                }
            }

            return ($posA < $posB) ? -1 : 1;
        });
    }
}
