<?php

namespace Form\Type;

use Model\Contact;
use Model\ContactQuery;
use Model\Map\RefSalesForceTableMap;
use Model\Pays;
use Model\PaysQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;

class ContactType extends AbstractType
{
    private string $instance;
    private User $user;

    public function __construct(TokenStorageInterface $tokenStorage, string $instance)
    {
        /** @var User */
        $user = $tokenStorage->getToken()->getUser();
        $this->user = $user;
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Contact::class,
            'name' => 'contact',
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $choicesYN = [
            'Y' => 'Y',
            'N' => 'N',
        ];

        $builder->add('mailing_street', TextType::class, [
            'required' => false,
            'property_path' => 'mailing_street',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('mailing_postal_code', TextType::class, [
            'required' => false,
            'property_path' => 'mailing_postal_code',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('mailing_city', TextType::class, [
            'required' => false,
            'property_path' => 'mailing_city',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('mailing_country', TextType::class, [
            'required' => true,
            'property_path' => 'mailing_country',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('mailing_state', TextType::class, [
            'required' => false,
            'property_path' => 'mailing_state',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('other_street', TextType::class, [
            'required' => false,
            'property_path' => 'other_street',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('other_city', TextType::class, [
            'required' => false,
            'property_path' => 'other_city',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('other_state', TextType::class, [
            'required' => false,
            'property_path' => 'other_state',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('other_postal_code', TextType::class, [
            'required' => false,
            'property_path' => 'other_postal_code',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('other_country', TextType::class, [
            'required' => false,
            'property_path' => 'other_country',
            'attr' => ['class' => 'form-control input-sm presetData'],
        ]);

        $builder->add('field_management', ChoiceType::class, [
            'property_path' => 'FieldManagement',
            'required' => false,
            'choices' => $choicesYN,
        ]);

        $builder->add('title', TextType::class, [
            'required' => true,
            'property_path' => 'Title',
            'empty_data' => 'Unknown',
            'constraints' => new NotBlank(),
        ]);

        $builder->add('first_name', TextType::class, [
            'required' => true,
            'property_path' => 'FirstName',
            'constraints' => new NotBlank(),
        ]);

        $builder->add('last_name', TextType::class, [
            'required' => true,
            'property_path' => 'LastName',
            'constraints' => new NotBlank(),
        ]);

        $builder->add('salutation_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('salutation_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'Salutation',
        ]);

        $builder->add('pay_id', ModelType::class, [
            'label' => 'Validate Country Name',
            'query' => PaysQuery::create()->filterByIsContact(true)->orderByPays(),
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'class' => Pays::class,
            'property_path' => 'Pay',
            'constraints' => [
                new NotBlank(),
            ],
            'placeholder' => 'Select Validate Country',
        ]);
        $builder->add('main_number', TextType::class, [
            'required' => true,
            'property_path' => 'Phone',
            'constraints' => new NotBlank(),
        ]);

        $builder->add('fax', TextType::class, [
            'required' => false,
            'property_path' => 'Fax',
        ]);

        $builder->add('mobile', TextType::class, [
            'required' => false,
            'property_path' => 'MobilePhone',
        ]);

        $builder->add('email', EmailType::class, [
            'required' => true,
            'property_path' => 'Email',
            'constraints' => [
                new NotBlank(),
                new Email([
                    'mode' => Email::VALIDATION_MODE_STRICT,
                ]),
            ],
        ]);

        $builder->add('can_be_duplicated', CheckboxType::class, [
            'required' => false,
            'label' => 'Can contact be duplicate?',
            'disabled' => $this->user->getAllowDuplicateContacts() ? false : 'disabled',
        ]);

        $builder->add('additional_email', EmailType::class, [
            'required' => false,
            'property_path' => 'AdditionalEmail',
            'constraints' => [
                new Email([
                    'mode' => Email::VALIDATION_MODE_STRICT,
                ]),
            ],
        ]);

        $builder->add('department', TextType::class, [
            'required' => false,
            'property_path' => 'Department',
        ]);

        $builder->add('assistant_name', TextType::class, [
            'required' => false,
            'property_path' => 'AssistantName',
        ]);

        $builder->add('assistant_phone', TextType::class, [
            'required' => false,
            'property_path' => 'AssistantPhone',
        ]);

        $builder->add('language_preference_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('language_preference_id')
                ->filterByActif(true),
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'label' => 'Preferred language',
            'class' => RefSalesForce::class,
            'property_path' => 'LanguagePreference',
            'constraints' => new NotBlank(),
        ]);

        $builder->add('contact_status_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('contact_status_id')
                ->filterByActif(true),
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'label' => 'Status',
            'constraints' => new NotBlank(),
            'class' => RefSalesForce::class,
            'property_path' => 'contactStatus',
        ]);

        $builder->add('currency_iso_code_id', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('currency_iso_code_id')
                ->filterByActif(true),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'label' => 'Currency',
            'constraints' => new NotBlank(),
            'class' => RefSalesForce::class,
            'property_path' => 'currencyIsoCode',
        ]);

        $builder->add('ref_sales_force_contact_ref_marketing_audiences', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                ->filterByField('marketing_audiences')
                ->filterByActif(true),
            'required' => true,
            'multiple' => true,
            'expanded' => false,
            'label' => 'Marketing Audiences',
            'constraints' => [
                new NotBlank(),
            ],
            'class' => RefSalesForce::class,
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();

            $defaultInstance = '';
            if ('us' == $this->instance) {
                $defaultInstance = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true)
                    ->findByValue('Schlesinger')
                    ->getFirst();
            } elseif ('uk' == $this->instance) {
                $defaultInstance = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true)
                    ->findByValue('Research house')
                    ->getFirst();
            } elseif ('de' == $this->instance) {
                $defaultInstance = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true)
                    ->findByValue('Schmiedl')
                    ->getFirst();
            } elseif ('es' == $this->instance) {
                $defaultInstance = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true)
                    ->findByValue('BDI')
                    ->getFirst();
            } elseif ('fr' == $this->instance) {
                $defaultInstance = RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true)
                    ->findByValue('Consumed')
                    ->getFirst();
            }

            $form->add('AddedBy', ModelType::class, [
                'query' => RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_CONTACT)
                    ->filterByField('added_by_id')
                    ->filterByActif(true),
                'data' => $defaultInstance,
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'label' => 'Added By',
                'placeholder' => '(please select)',
                'constraints' => new NotBlank(),
                'class' => RefSalesForce::class,
                'property_path' => 'AddedBy',
            ]);
        });

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();

            $canBeDuplicated = $data->getCanBeDuplicated();
            $form->getData()->getCanBeDuplicated();
            $activeEmailNb = ContactQuery::create()
                ->filterByEmail($data->getEmail())
                ->filterByIsActive()
                ->filterById($data->getId(), Criteria::NOT_EQUAL)
                ->count();
            if (0 < $activeEmailNb && !$canBeDuplicated) {
                $form->addError(new FormError('This email already exists in the system. If it is necessary to have the same email please contact your team leader.'));
            }
        });
    }
}
