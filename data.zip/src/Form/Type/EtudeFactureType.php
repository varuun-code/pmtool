<?php

namespace Form\Type;

use Model\Contact;
use Model\Document;
use Model\Facture;
use Model\Job;
use Model\JobQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class EtudeFactureType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Facture::class,
            'name' => 'etude_facture',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'contact_query' => null,
            'document_query' => null,
            'choice_monnaie' => [],
        ]);
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $languages = ['EN' => 'EN', 'DE' => 'DE', 'FR' => 'FR'];
        if ('fr' == $this->instance) {
            $languages = ['FR' => 'FR', 'EN' => 'EN', 'DE' => 'DE'];
        } elseif ('de' == $this->instance) {
            $languages = ['DE' => 'DE', 'FR' => 'FR', 'EN' => 'EN'];
        }

        $etude = $options['parent_data'];
        $builder->add('date', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('monnaie', ChoiceType::class, [
            'mapped' => false,
            'label' => false,
            'placeholder' => 'Select a currency',
            'required' => false,
            'choices' => $options['choice_monnaie'],
        ]);

        $builder->add('taux_change', NumberType::class, [
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('paid_amount', NumberType::class, [
            'required' => false,
        ]);
        $builder->add('payment_date', DateType::class, [
            'required' => false,
            'widget' => 'single_text',
        ]);

        $builder->add('symbole_monnaie', TextType::class, [
            'required' => false,
            'attr' => [
                'readonly' => true,
            ],
        ]);

        $builder->add('language', ChoiceType::class, [
            'label' => false,
            'required' => true,
            'choices' => $languages,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('document', ModelType::class, [
            'query' => $options['document_query'],
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a document',
            'class' => Document::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('job', ModelType::class, [
            'property_path' => 'job',
            'query' => JobQuery::create()->filterByEtudeId($etude->getId()),
            'required' => true,
            'placeholder' => 'select a job',
            'property' => 'idSamsJob',
            'multiple' => false,
            'expanded' => false,
            'label' => 'Job',
            'class' => Job::class,
         ]);

        $builder->add('project_invoice_type', ChoiceType::class, [
            'label' => 'Invoice on project',
            'placeholder' => 'Invoice on project type',
            'multiple' => false,
            'expanded' => false,
            'choices' => Facture::getProjectInvoiceTypes(),
            'required' => false,
        ]);

        $builder->add('montant', NumberType::class, [
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('external_reference', TextType::class, [
            'required' => false,
            'constraints' => [
                new Length([
                    'max' => 18,
                    'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                ]),
            ],
        ]);

        $builder->add('contact', ModelType::class, [
            'query' => $options['contact_query'],
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'class' => Contact::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('is_send', ChoiceType::class, [
            'label' => false,
            'required' => false,
            'choices' => ['yes' => '1', 'no' => '0'],
        ]);
    }
}
