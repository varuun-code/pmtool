<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Opportunity;
use Model\OpportunityQuery;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OpportunityMergeType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Opportunity::class,
            'csrf_protection' => false,
            'allow_extra_fields' => true,
            'auto_initialize' => false,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('id', TextType::class, [
                'required' => false,
                'label' => false,
                'disabled' => true,
            ])
            ->add('opportunities', Select2HiddenPropelType::class, [
            'label' => false,
            'query' => OpportunityQuery::create(),
            'required' => false,
            'multiple' => false,
            'empty_value' => 'Select an opportunity',
            'mapped' => false,
            'class' => Opportunity::class,
            'choices' => 'oppt_search_by_account_or_subject',
        ])
        ;
    }
}
