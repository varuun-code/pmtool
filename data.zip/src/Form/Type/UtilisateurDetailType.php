<?php

namespace Form\Type;

use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\Groupe;
use Model\GroupeQuery;
use Model\Location;
use Model\LocationQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;

class UtilisateurDetailType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => User::class,
            'name' => 'utilisateur',
            'csrf_protection' => false,
            'cascade_validation' => true,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('statut', ChoiceType::class, [
                'label' => 'Status',
                'required' => false,
                'placeholder' => false,
                'choices' => [
                    'Active' => User::STATUS_ACTIVE,
                    'Out' => User::STATUS_EXPIRED,
                    'Violation' => User::STATUS_LOCKED,
                ],
            ])
            ->add('employe', ChoiceType::class, [
                'label' => 'Employee',
                'required' => false,
                'placeholder' => false,
                'choices' => [
                   'Yes' => 'Y',
                   'No' => 'N',
                ],
            ])
            ->add('nom', TextType::class, [
                'label' => 'Last Name',
                'required' => true,
            ])
            ->add('prenom', TextType::class, [
                'label' => 'Surname',
                'required' => true,
            ])
            ->add('initials', TextType::class, [
                'label' => 'Initials',
                'required' => false,
            ])
            ->add('mail', EmailType::class, [
                'label' => 'E-Mail',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                    new Email([
                        'mode' => Email::VALIDATION_MODE_STRICT,
                    ]),
                ],
            ])
            ->add('phone', TextType::class, [
                'label' => 'Phone',
                'required' => false,
            ])
            ->add('raw_roles', ChoiceType::class, [
                'label' => 'User access',
                'multiple' => true,
                'expanded' => true,
                'choices' => [
                    'PMTool' => 'ROLE_USER',
                    'SPOC' => 'ROLE_SPOC_USER',
                    'Debug' => 'ROLE_SOAP_USER',
                ],
            ])
            ->add('groupe', ModelType::class, [
                'label' => 'Group',
                'query' => GroupeQuery::create()->orderById(),
                'class' => Groupe::class,
            ])
            ->add('is_seller', CheckboxType::class, [
                'label' => 'Can sale',
                'required' => false,
            ])
            ->add('can_edit_event', CheckboxType::class, [
                'label' => 'Can edit events',
                'required' => false,
            ])
            ->add('allow_duplicate_contacts', CheckboxType::class, [
                'label' => 'Allow duplicate contacts',
                'required' => false,
            ])
            ->add('coordinateur', ModelType::class, [
                'label' => 'Coordinator',
                'required' => false,
                'query' => UserQuery::create(),
                'class' => User::class,
            ])
            ->add('ref_location', ModelType::class, [
                'label' => 'Location',
                'required' => true,
                'query' => LocationQuery::create()->orderById(),
                'class' => Location::class,
            ])
            ->add('LocationRelatedByIdLocationPr', ModelType::class, [
                'label' => 'Location Phoneroom',
                'required' => true,
                'query' => LocationQuery::create()->orderById(),
                'class' => Location::class,
            ])
            ->add('fournisseur', ModelType::class, [
                'label' => 'Link with Suplier data',
                'required' => false,
                'query' => FournisseurQuery::create()->filterByEmploye(['E', 'R'])->orderByNom('asc'),
                'class' => Fournisseur::class,
            ])
            ->add('sf_id', TextType::class, [
                'label' => 'SalesForce ID',
                'required' => false,
                'empty_data' => '',
            ])
            ->add('default_sf', ChoiceType::class, [
                'label' => 'Salesforce default user',
                'required' => false,
                'placeholder' => false,
                'choices' => [
                    'No' => '0',
                    'Yes' => '1',
                ],
            ])
            ->add('is_bad_payer_mail_receiver', ChoiceType::class, [
                'label' => 'bad payer mail receiver',
                'required' => false,
                'placeholder' => false,
                'choices' => [
                    'No' => '0',
                    'Yes' => '1',
                ],
            ])
            ->add('is_account_change_mail_receiver', ChoiceType::class, [
                'label' => 'Account change mail receiver',
                'required' => false,
                'placeholder' => false,
                'choices' => [
                    'No' => '0',
                    'Yes' => '1',
                ],
            ])
        ;
    }
}
