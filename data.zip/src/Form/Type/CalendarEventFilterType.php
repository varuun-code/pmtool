<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Job;
use Model\JobQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Opportunity;
use Model\OpportunityQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CalendarEventFilterType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('location', ModelType::class, [
            'label' => false,
            'query' => LocationQuery::create()->filterByActive(true)->orderByLibelle(),
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'mapped' => false,
            'class' => Location::class,
            'attr' => ['class' => 'form-control'],
        ])
        ->add('location2', ModelType::class, [
            'label' => false,
            'query' => LocationQuery::create()->filterByActive(true)->orderByLibelle(),
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'mapped' => false,
            'class' => Location::class,
            'attr' => ['class' => 'form-control'],
        ])
        ->add('opportunities', Select2HiddenPropelType::class, [
            'label' => false,
            'query' => OpportunityQuery::create(),
            'required' => false,
            'multiple' => false,
            'empty_value' => 'Select an opportunity',
            'mapped' => false,
            'class' => Opportunity::class,
            'choices' => 'oppt_search_by_account_or_subject',
        ])
        ->add('jobs', Select2HiddenPropelType::class, [
            'query' => JobQuery::create(),
            'mapped' => false,
            'required' => false,
            'multiple' => false,
            'label' => false,
            'empty_value' => 'Select a job',
            'class' => Job::class,
            'choices' => 'job_search_by_sams_id',
        ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'allow_extra_fields' => true,
            'auto_initialize' => false,
        ]);
    }
}
