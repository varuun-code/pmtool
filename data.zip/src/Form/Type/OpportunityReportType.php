<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Map\RefSalesForceTableMap;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OpportunityReportType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => null,
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('account', Select2HiddenPropelType::class, [
            'label' => 'Client',
            'multiple' => false,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select an account',
            'formatSelection' => 'formatSelectedAccount',
            'formatResult' => 'formatResultPerson',
            'query' => AccountQuery::create(),
            'choices' => 'account_search_by_name',
            'init_choices' => 'account_search_by_name_init',
            'class' => Account::class,
        ])->add('contact', Select2HiddenPropelType::class, [
            'label' => 'Contact',
            'multiple' => false,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select a contact',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => ContactQuery::create(),
            'choices' => 'contact_search_by_name',
            'init_choices' => 'contact_search_by_name_init',
            'class' => Contact::class,
        ])->add('end_client', Select2HiddenPropelType::class, [
            'label' => 'End Client',
            'multiple' => false,
            'required' => false,
            'property' => 'getNameforPicklist',
            'empty_value' => 'Select a client',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => AccountQuery::create(),
            'choices' => 'account_search_by_name',
            'init_choices' => 'account_search_by_name_init',
            'class' => Account::class,
        ])->add('pmtool_created_by', ModelType::class, [
            'multiple' => true,
            'required' => false,
            'label' => 'Owner',
            'query' => UserQuery::create()->filterByStatut('A')->filterByisSeller(true)->orderByPrenom(Criteria::ASC)->orderByNom(Criteria::ASC),
            'class' => User::class,
        ])->add('first_created_by', ModelType::class, [
            'multiple' => true,
            'required' => false,
            'label' => 'Created By',
            'query' => UserQuery::create()->filterByStatut('A')->orderByPrenom(Criteria::ASC)->orderByNom(Criteria::ASC),
            'class' => User::class,
        ])->add('account_manager', ModelType::class, [
            'label' => 'Sales Rep',
            'multiple' => true,
            'required' => false,
            'query' => UserQuery::create()
                ->filterBySfId('', Criteria::NOT_EQUAL)->orderByPrenom(Criteria::ASC)->orderByNom(Criteria::ASC),
            'class' => User::class,
        ])->add('stage_name', ModelType::class, [
            'label' => 'Stage',
            'query' => RefSalesForceQuery::create()->filterByOpportunityField('stage_name_id'),
            'multiple' => true,
            'required' => false,
            'class' => RefSalesForce::class,
        ])->add('platform_id', ModelType::class, [
            'label' => 'Product',
            'query' => RefSalesForceQuery::create()->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)->filterByField('platform_id'),
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'class' => RefSalesForce::class,
        ])->add('us_global_qual_gms', ModelType::class, [
            'label' => 'GQS',
            'multiple' => false,
            'required' => false,
            'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('us_global_qual_gms_id')->filterByTable('opportunity'),
            'empty_data' => '',
            'class' => RefSalesForce::class,
        ])->add('job_qualification', ModelType::class, [
            'label' => 'Job Qualification',
            'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('job_qualification_id')->filterByTable('opportunity'),
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'class' => RefSalesForce::class,
        ])->add('industry', ModelType::class, [
            'label' => 'Industry',
            'multiple' => true,
            'required' => false,
            'query' => IndustryQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel('', Criteria::NOT_EQUAL),
            'class' => Industry::class,
        ])->add('methodology', ModelType::class, [
            'label' => 'Methodology',
            'multiple' => true,
            'required' => false,
            'query' => MethodologyQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel(null, Criteria::ISNOTNULL),
            'class' => Methodology::class,
        ])->add('managing_locations', ModelType::class, [
            'query' => LocationQuery::create()
                ->filterByLibelle('Not Applicable', Criteria::NOT_EQUAL)
                ->filterBySfLabel(null, Criteria::ISNOTNULL)
                ->filterByActive(true)
                ->orderByLibelle(),
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'label' => 'Locations',
            'class' => Location::class,
            'choice_attr' => function (Location $location) {
                return [
                    'data-active' => $location->getActive() ? 'Y' : 'N',
                    'data-gqs' => $location->getGqsAvailable() ? 'Y' : 'N',
                ];
            },
        ])->add('opportunity_s_date', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Oppt Created Date between',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('opportunity_e_date', DateType::class, [
            'widget' => 'single_text',
            'label' => 'And',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('estimated_commissioning_date_start', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Est Commission Date between',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('estimated_commissioning_date_end', DateType::class, [
            'widget' => 'single_text',
            'label' => 'And',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('close_date_start', DateType::class, [
                'widget' => 'single_text',
                'label' => 'Oppt Close Date between',
                'attr' => ['autocomplete' => 'off'],
                'format' => 'yyyy-MM-dd',
                'required' => false,
        ])->add('close_date_end', DateType::class, [
                'widget' => 'single_text',
                'label' => 'And',
                'attr' => ['autocomplete' => 'off'],
                'format' => 'yyyy-MM-dd',
                'required' => false,
            ]);
    }
}
