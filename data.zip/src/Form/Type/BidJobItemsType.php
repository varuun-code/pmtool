<?php

namespace Form\Type;

use Model\BidJob;
use Model\BidJobItem;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Count;

class BidJobItemsType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => BidJob::class,
            'name' => 'bid_job',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'allow_extra_fields' => true,
            'parent_data' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
          ->add('field', HiddenType::class, ['mapped' => false]) // to allow posting empty collection
          ->add('bid_job_items', CollectionType::class, [
              'label' => false,
              'property_path' => 'opportunityBidJobItems',
              'entry_type' => BidJobItemType::class,
              'entry_options' => [
                  'label' => false,
                  'parent_data' => $builder->getData(),
              ],
              'allow_add' => true,
              'allow_delete' => true,
              'by_reference' => false,
              'delete_empty' => true,
              'constraints' => [
                  new Count([
                      'max' => BidJobItem::MAX_COUNT,
                  ]),
              ],
          ])
      ;
    }
}
