<?php

namespace Form\Type;

use Model\DiscountProgram;
use Model\Map\DiscountProgramTableMap;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class DiscountProgramType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => DiscountProgram::class,
            'name' => 'discount-program',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', TextType::class, [
                'label' => 'name',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('active', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('groupe', ChoiceType::class, [
                'label' => 'Groupe',
                'required' => true,
                'choices' => [
                    DiscountProgramTableMap::COL_GROUPE_PREFERRED => DiscountProgramTableMap::COL_GROUPE_PREFERRED,
                    DiscountProgramTableMap::COL_GROUPE_REBATE_AMOUNT => DiscountProgramTableMap::COL_GROUPE_REBATE_AMOUNT,
                    DiscountProgramTableMap::COL_GROUPE_CREDIT => DiscountProgramTableMap::COL_GROUPE_CREDIT,
                ],
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('type', ChoiceType::class, [
                'label' => 'Type',
                'required' => true,
                'choices' => [
                    DiscountProgramTableMap::COL_TYPE_QUAL => DiscountProgramTableMap::COL_TYPE_QUAL,
                    DiscountProgramTableMap::COL_TYPE_QUANT => DiscountProgramTableMap::COL_TYPE_QUANT,
                ],
                'constraints' => [
                    new NotBlank(),
                ],
            ])
        ;
    }
}
