<?php

namespace Form\Type;

use Model\Event;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoom;
use Model\RefRoomQuery;
use Model\RefTimeSlot;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BidJobEventType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Event::class,
            'name' => 'bid_job_event',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'allow_extra_fields' => true,
            'user' => [],
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $firstBidJobLocation = $options['parent_data']->getLocation() ? $options['parent_data']->getLocation()->getLibelle() : '';

        $builder->add('id', TextType::class, [
            'label' => false,
            'required' => true,
            'disabled' => 'disabled',
        ]);
        $builder->add('location', TextType::class, [
            'label' => false,
            'required' => false,
            'mapped' => false,
            'disabled' => 'disabled',
            'data' => $firstBidJobLocation,
        ]);
        $builder->add('created_date', DateTimeType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'disabled' => 'disabled',
            'required' => false,
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($options) {
            $form = $event->getForm();

            if ($data = $event->getData()) {
                $eventRoom = $data->getRefRoom();
                $location = $eventRoom ? $eventRoom->getLocation() : $data->getBidJob()->getLocation();
                $canUserEditEvent = $options['user'] && $options['user']->getcanEditEvent();

                $form->add('isDeleted', HiddenType::class, [
                    'label' => false,
                    'required' => true,
                    'data' => (int) $data->getIsDeletedC(),
                ]);
                $canEdit = $options['user'] && $options['user']->getcanEditEvent();
                if (($canEdit || $data->isOffsite()) && !$data->getIsDeletedC()) {
                    $form
                        ->add('refRoom', ModelType::class, [
                            'label' => false,
                            'multiple' => false,
                            'expanded' => false,
                            'disabled' => $canUserEditEvent ? false : 'disabled',
                            'query' => RefRoomQuery::create()->filterByLocation($location)->filterByActive(true),
                            'class' => RefRoom::class,
                        ])
                        ->add('refEventStatus', ModelType::class, [
                            'label' => false,
                            'multiple' => false,
                            'expanded' => false,
                            'required' => true,
                            'disabled' => false,
                            'query' => RefEventStatusQuery::create(),
                            'class' => RefEventStatus::class,
                        ])
                        ->add('date', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy',
                            'disabled' => false,
                            'required' => true,
                        ])
                        ->add('start_date_time', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy HH:mm',
                            'disabled' => false,
                            'required' => true,
                        ])
                        ->add('end_date_time', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy HH:mm',
                            'disabled' => false,
                            'required' => true,
                             'attr' => [
                                'placeholder' => 'Start Datetime',
                                'eventCreateDate' => $data->getCreatedDate() ? $data->getCreatedDate('d-m-Y') : '',
                            ],
                        ])
                        ->add('refTimeSlot', ModelType::class, [
                            'label' => false,
                            'required' => false,
                            'multiple' => false,
                            'expanded' => false,
                            'disabled' => false,
                            'placeholder' => 'Select',
                            'class' => RefTimeSlot::class,
                        ])
                        ->add('description', TextType::class, [
                            'label' => false,
                            'required' => false,
                            'disabled' => false,
                        ])
                        ->add('facility_note', TextareaType::class, [
                            'label' => 'Facility Note',
                            'required' => false,
                        ])
                    ;
                }
            }
        });
    }
}
