<?php

namespace Form\Type;

use Model\Groupe;
use Model\Industry;
use Model\IndustryQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;

class BilanAvancementRecrutementType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('sectors', ModelType::class, [
                'class' => Industry::class,
                'query' => IndustryQuery::create()->orderByLibelle(),
                'placeholder' => 'Select industries',
                'multiple' => true,
                'required' => false,
            ])
            ->add('coordinators', ModelType::class, [
                'class' => User::class,
                'query' => UserQuery::create()->filterByIdGroupe(Groupe::PROJECT_MANAGER)->orderByPrenom()->orderByNom(),
                'placeholder' => 'No Coordinator',
                'multiple' => true,
                'required' => false,
            ])
        ;
    }
}
