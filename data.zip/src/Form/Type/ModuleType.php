<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Confirmation;
use Model\ConfirmationQuery;
use Model\Duree;
use Model\DureeQuery;
use Model\Module;
use Model\Quota;
use Model\QuotaQuery;
use Model\Repondant;
use Model\RepondantQuery;
use Model\Site;
use Model\SiteQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class ModuleType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Module::class,
            'name' => 'module',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'job_data' => [],
            'parent_data' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if ('us' !== $this->instance) {
            $paymentType = Module::PAYMENT_TYPES;
            if ('fr' === $this->instance) {
                $paymentType['En attente'] = 'E';
            }

            $builder->add('annule', ChoiceType::class, [
                'label' => false,
                'choices' => [
                    'No' => 'N',
                    'Yes' => 'O',
                ],
                'preferred_choices' => 'N',
                'required' => true,
            ]);

            $builder->add('date', DateType::class, [
                'widget' => 'single_text',
                'label' => false,
                'format' => 'dd/MM/yyyy',
                'required' => false,
                'html5' => false,
                'attr' => [
                    'readonly' => true, // needs to be posted to avoid erasing the value
                ],
            ]);

            $builder->add('status', ChoiceType::class, [
                'label' => false,
                'choices' => [
                    'OK' => 'OK',
                    'No Show' => 'NS',
                    'Misrecruitment' => 'MR',
                    'New Check' => 'NC',
                    'Other' => 'O',
                ],
                'required' => false,
            ]);

            $builder->add('id_client', TextType::class, [
                'label' => false,
            ]);

            $builder->add('duree', ModelType::class, [
                'query' => DureeQuery::create(),
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
                'multiple' => false,
                'expanded' => false,
                'label' => false,
                'class' => Duree::class,
            ]);

            $builder->add('numero_ligne', IntegerType::class, [
                'label' => false,
            ]);

            $builder->add('debut', TextType::class, [
                'label' => false,
            ]);

            $builder->add('site', ModelType::class, [
                'query' => SiteQuery::create(),
                'required' => false,
                'constraints' => [],
                'multiple' => false,
                'expanded' => false,
                'label' => false,
                'class' => Site::class,
            ]);
            if ($options['job_data'] && ($etude = $options['job_data']->getEtude()) && $etude->hasQuota()) {
                $builder->add('quota', ModelType::class, [
                    'query' => QuotaQuery::create(),
                    'required' => false,
                    'constraints' => [],
                    'multiple' => false,
                    'expanded' => false,
                    'label' => false,
                    'class' => Quota::class,
                ]);
            }
            $builder->add('incentive', NumberType::class, [
                'label' => false,
                'required' => false,
            ]);

            $builder->add('paiement', ChoiceType::class, [
                'label' => false,
                'choices' => $paymentType,
                'required' => true,
                'placeholder' => '',
                'constraints' => [
                    new NotBlank(),
                ],
            ]);

            $builder->add('confirmation', ModelType::class, [
                'query' => ConfirmationQuery::create(),
                'required' => false,
                'constraints' => [],
                'multiple' => false,
                'expanded' => false,
                'label' => false,
                'class' => Confirmation::class,
            ]);

            $builder->add('date_confirmation', DateType::class, [
                'widget' => 'single_text',
                'label' => false,
                'format' => 'dd/MM/yyyy',
                'required' => false,
                'html5' => false,
            ]);

            $builder->add('date_rescreening', DateType::class, [
                'widget' => 'single_text',
                'label' => false,
                'format' => 'dd/MM/yyyy',
                'required' => false,
                'html5' => false,
            ]);

            if ($options['job_data'] && ($etude = $options['job_data']->getEtude()) && $etude->hasSyntec()) {
                $builder->add('date_scintex', DateType::class, [
                    'widget' => 'single_text',
                    'label' => false,
                    'format' => 'dd/MM/yyyy',
                    'required' => false,
                    'html5' => false,
                ]);
            }

            $builder->add('quality_check', ChoiceType::class, [
                'label' => false,
                'choices' => ['' => '', 'OK' => 'O', 'N/A' => 'N'],
                'required' => false,
            ]);

            $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
                $form = $event->getForm();
                $data = $event->getData();
                if (!$data) {
                    $form->add('repondant', Select2HiddenPropelType::class, [
                        'label' => false,
                        'multiple' => false,
                        'required' => false,
                        'property' => 'id',
                        'empty_value' => 'Select a respondent',
                        'formatSelection' => 'formatSelectedRespondent',
                        'formatResult' => 'formatResultRespondent',
                        'query' => RepondantQuery::create(),
                        'choices' => 'repondant_search_by_name',
                        'init_choices' => 'repondant_search_by_name_init',
                        'class' => Repondant::class,
                        'custom_ajax_json' => 'ajax: window.searchRespondentByName, initSelection: window.repondentInitSelection',
                    ]);
                // cannot change respondent if check was emitted or if it comes from SAMS
                } elseif (!$data->getNoCheque() && !$data->getSamsModuleId()) {
                    $initChoices = ($repondant = $data->getRepondant()) ? [$repondant->getId() => $repondant] : [];
                    $form->add('repondant', Select2HiddenPropelType::class, [
                        'label' => false,
                        'multiple' => false,
                        'required' => true,
                        'property' => 'getNomComplet',
                        'empty_value' => 'Select a respondent',
                        'formatSelection' => 'formatSelectedRespondent',
                        'formatResult' => 'formatResultRespondent',
                        'query' => RepondantQuery::create(),
                        'choices' => 'repondant_search_by_name',
                        'init_choices' => $initChoices,
                        'class' => Repondant::class,
                        'custom_ajax_json' => 'ajax: window.searchRespondentByName, initSelection: window.repondentInitSelection',
                    ]);
                }
            });

            $builder->addEventListener(FormEvents::POST_SET_DATA, function (FormEvent $event) {
                $form = $event->getForm();
                $parent = $form->getParent();
                if ($parent && ($parentParent = $parent->getParent()) && $parentParent->getData() && $parentParent->getData()->getIsDeletedC()) {
                    $form
                        ->add('paiement', TextType::class) // keep value whatever it is
                        ->add('duree', ModelType::class, [
                            'query' => DureeQuery::create(),
                            'class' => Duree::class,
                        ])
                    ;
                }
            });
        }
    }
}
