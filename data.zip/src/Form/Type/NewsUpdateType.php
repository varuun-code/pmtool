<?php

namespace Form\Type;

use Model\NewsImages;
use Model\NewsUpdate;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class NewsUpdateType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => NewsUpdate::class,
            'name' => 'news_update',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('news_title', TextType::class, [
                'label' => 'News Title',
                'required' => true,
                'constraints' => new NotBlank(),
            ])
            ->add('site_name', TextType::class, [
                'label' => 'Site Name',
                'required' => true,
                'constraints' => new NotBlank(),
            ])
            ->add('news_text', TextareaType::class, [
                'label' => 'News Text',
                'required' => true,
                'constraints' => new NotBlank(),
            ])
            ->add('news_url', TextType::class, [
                'label' => 'News URL',
                'required' => false,
            ])
            ->add('picture_id', ChoiceType::class, [
                'label' => 'News Image',
                'multiple' => false,
                'required' => true,
                'constraints' => new NotBlank(),
                'choices' => NewsImages::getAll()->toKeyValue('ImageName', 'Id'),
            ])
            ->add('status', ChoiceType::class, [
                'label' => 'Status',
                'multiple' => false,
                'required' => true,
                'constraints' => new NotBlank(),
                'choices' => NewsUpdate::getStatusTypes(),
            ])
        ;
    }
}
