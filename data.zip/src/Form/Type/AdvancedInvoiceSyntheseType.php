<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AdvancedInvoiceSyntheseType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('dateDebut', DateType::class, [
                'label' => 'Start date',
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('dateFin', DateType::class, [
                'label' => 'End date',
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('accounts', Select2HiddenPropelType::class, [
                'label' => 'Client',
                'multiple' => true,
                'required' => true,
                'property' => 'id',
                'empty_value' => 'Select an account',
                'query' => AccountQuery::create()->filterByActiveStatusId()->orderByName(Criteria::ASC),
                'attr' => ['class' => 'advancedInvoiceSynthese_accounts'],
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])->add('send', ChoiceType::class, [
                 'label' => 'Send',
                 'required' => false,
                 'choices' => ['yes' => '1', 'no' => '0'],
             ])->add('export', SubmitType::class, [
                 'label' => 'export Invoices',
            ]);
    }
}
