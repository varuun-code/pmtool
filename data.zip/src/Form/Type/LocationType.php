<?php

namespace Form\Type;

use Model\Location;
use Model\RefSalesForce;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class LocationType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Location::class,
            'name' => 'location',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('libelle', TextType::class, [
                'label' => 'Label',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('active', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('on_site', CheckboxType::class, [
                'label' => 'OnSite/Not OnSite',
                'required' => false,
            ])
            ->add('sf_label', TextType::class, [
                'label' => 'Salesforce Label',
                'required' => false,
            ])
            ->add('gqs_available', CheckboxType::class, [
                'label' => 'GQS Active/Inactive',
                'required' => false,
            ])
             ->add('country_code', ChoiceType::class, [
                'label' => 'Country Code',
                'required' => false,
                'choices' => RefSalesForce::getCountryCode(),
                'placeholder' => 'Select a Country Code',
             ])
             ->add('location_group', ChoiceType::class, [
                'label' => 'Location Group',
                'required' => false,
                'choices' => Location::GROUP_LOCATION,
                'placeholder' => 'Select a Location Group',
             ]);
    }
}
