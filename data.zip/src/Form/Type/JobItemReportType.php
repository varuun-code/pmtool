<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Etude;
use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\Groupe;
use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Map\RefSalesForceTableMap;
use Model\Platforms;
use Model\PlatformsQuery;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Propel;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class JobItemReportType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => null,
            'csrf_protection' => false,
            'isJobCost' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $isJobCost = $options['isJobCost'];
        $cutoffs = ['' => ''] + Etude::getCutoffs()->toKeyValue('PeriodeCutoff', 'PeriodeCutoff');

        $con = Propel::getConnection();
        $stmt1 = $con->prepare('SELECT DISTINCT account_manager_id FROM etude');
        $stmt1->execute();
        $ids1 = $stmt1->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        $stmt2 = $con->prepare('SELECT DISTINCT account_manager_id FROM sf_opportunity');
        $stmt2->execute();
        $ids2 = $stmt2->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        $accountManagerIds = array_unique(array_merge($ids1, $ids2));

        $builder->add('location_group', ChoiceType::class, [
            'label' => 'Location Group',
            'multiple' => true,
            'expanded' => false,
            'choices' => Location::GROUP_LOCATION,
            'required' => false,
            'placeholder' => 'Select Location Group',
        ])->add('job_location', ModelType::class, [
            'label' => 'Location',
            'query' => LocationQuery::create()->useJobLocationQuery()->endUse()->orderByLibelle(), // only those used by Jobs
            'multiple' => true,
            'expanded' => false,
            'required' => false,
            'placeholder' => 'Select locations',
            'class' => Location::class,
        ])->add('job_status', ModelType::class, [
            'label' => 'Job status',
            'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('status_id')->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB)->filterByValue('Cancelled-Billed', Criteria::NOT_EQUAL), // only those used by Jobs
            'multiple' => true,
            'expanded' => false,
            'required' => false,
            'placeholder' => 'Select job staus',
            'class' => RefSalesForce::class,
        ])->add('job_project_manager', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR, Groupe::MANAGEMENT])
                ->filterByStatut('A')
                ->orderByPrenom(Criteria::ASC),
            'label' => 'Project Manager',
            'multiple' => true,
            'expanded' => false,
            'required' => false,
            'placeholder' => 'Select a PM',
            'class' => User::class,
        ])->add('industry', ModelType::class, [
            'class' => Industry::class,
            'query' => IndustryQuery::create()->orderByLibelle()->orderByLibelle(Criteria::ASC),
            'placeholder' => 'Select industries',
            'multiple' => true,
            'required' => false,
            'expanded' => false,
        ])->add('section', ModelType::class, [
            'class' => CategoriePrestation::class,
            'query' => CategoriePrestationQuery::create()->filterByCostOk('Y')->orderByCategory(Criteria::ASC),
            'placeholder' => 'Select sections',
            'multiple' => true,
            'required' => false,
            'expanded' => false,
        ])->add('salesManagers', ModelType::class, [
            'label' => 'Project Setup Owner',
            'query' => UserQuery::create()
                ->useEtudeRelatedByIdBmQuery()
                ->filterById(null, Criteria::ISNOTNULL)
                ->endUse()
                ->orderByNom(Criteria::ASC),
            'expanded' => false,
            'required' => false,
            'multiple' => true,
            'class' => User::class,
        ])->add('accountManagers', ModelType::class, [
            'label' => 'Sales Rep',
            'query' => UserQuery::create()
                ->filterById($accountManagerIds)
                ->orderByNom(Criteria::ASC),
            'multiple' => true,
            'required' => false,
            'expanded' => false,
            'class' => User::class,
        ])->add('account', Select2HiddenPropelType::class, [
            'label' => 'Client',
            'multiple' => true,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select clients',
            'query' => AccountQuery::create()->orderByName(Criteria::ASC),
            'choices' => 'account_search_by_name',
            'init_choices' => 'account_search_by_name_init',
            'class' => Account::class,
        ])->add('jobQualifications', ModelType::class, [
            'query' => RefSalesForceQuery::create()
                ->useMethodologyQuery()
                ->filterById(null, Criteria::ISNOTNULL)
                ->endUse()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                ->filterByField('job_qualification_id')
                ->filterByActif(true)
                ->orderByLabel(),
            'multiple' => true,
            'expanded' => false,
            'required' => false,
            'class' => RefSalesForce::class,
        ])->add('cutt_off', ChoiceType::class, [
            'choices' => $cutoffs,
            'multiple' => true,
            'expanded' => false,
            'required' => false,
        ])->add('sdate', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Job End Date between',
            'attr' => ['autocomplete' => 'off'],
            'required' => false,
        ])->add('edate', DateType::class, [
            'widget' => 'single_text',
            'label' => 'And',
            'attr' => ['autocomplete' => 'off'],
            'required' => false,
        ])->add('etude_s_date', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Project End Date between',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('etude_e_date', DateType::class, [
            'widget' => 'single_text',
            'label' => 'And',
            'attr' => ['autocomplete' => 'off'],
            'format' => 'yyyy-MM-dd',
            'required' => false,
        ])->add('product_type', ModelType::class, [
            'label' => 'Job Product Type',
            'query' => PlatformsQuery::create(),
            'property' => 'name',
            'required' => false,
            'multiple' => true,
            'expanded' => false,
            'placeholder' => 'Select a Product Type',
            'class' => Platforms::class,
        ])->add('etude_type', ChoiceType::class, [
            'label' => 'Master Project Type',
            'multiple' => true,
            'expanded' => false,
            'choices' => [
                'CLI' => 'cli',
                'RST' => 'rst',
                'GQS' => 'gqs',
                'INS' => 'ins',
                'HUT' => 'hut',
            ],
            'required' => false,
        ]);
        if ($isJobCost) {
            $builder
                ->add('vendor', ModelType::class, [
                    'label' => 'Supplier/Vendor',
                    'query' => FournisseurQuery::create()
                        ->orderByNom(Criteria::ASC),
                    'multiple' => true,
                    'required' => false,
                    'expanded' => false,
                    'class' => Fournisseur::class,
                ])
            ;
        } else {
            $builder
                ->add('am_unchecked_s_date', DateType::class, [
                    'widget' => 'single_text',
                    'label' => 'Job AM Unchecked between',
                    'attr' => ['autocomplete' => 'off'],
                    'format' => 'yyyy-MM-dd',
                    'required' => false,
                ])
                ->add('am_unchecked_e_date', DateType::class, [
                    'widget' => 'single_text',
                    'label' => 'And',
                    'attr' => ['autocomplete' => 'off'],
                    'format' => 'yyyy-MM-dd',
                    'required' => false,
                ])
            ;
        }
    }
}
