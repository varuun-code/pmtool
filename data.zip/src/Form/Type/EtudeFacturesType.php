<?php

namespace Form\Type;

use Model\Etude;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EtudeFacturesType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Etude::class,
            'name' => 'job_factures',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'contact_query' => null,
            'document_query' => null,
            'choice_monnaie' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('field', HiddenType::class, ['mapped' => false]) // to allow posting empty collection
            ->add('factures', CollectionType::class, [
                'label' => false,
                'entry_type' => EtudeFactureType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
                'by_reference' => false,
                'entry_options' => [
                    'label' => false,
                    'contact_query' => $options['contact_query'],
                    'document_query' => $options['document_query'],
                    'parent_data' => $builder->getData(),
                    'choice_monnaie' => $options['choice_monnaie'],
                ],
            ])
        ;
    }
}
