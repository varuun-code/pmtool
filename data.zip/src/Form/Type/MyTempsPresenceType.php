<?php

namespace Form\Type;

use Model\TempsPresence;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Time;

class MyTempsPresenceType extends AbstractType
{
    const DUREE_PAUSE = [
        '0' => '0 h',
        '15' => '0.25 h',
        '30' => '0.5 h',
        '45' => '0.75 h',
        '60' => '1 h',
        '75' => '1.25 h',
        '90' => '1.5 h',
        '105' => '1.75 h',
        '120' => '2 h',
        '135' => '2.25 h',
        '150' => '2.5 h',
        '165' => '2.75 h',
        '180' => '3 h',
        '195' => '3.25 h',
        '210' => '3.5 h',
        '225' => '3.75 h',
        '240' => '4 h',
        '255' => '4.25 h',
        '270' => '4.5 h',
        '285' => '4.75 h',
        '300' => '5 h',
        '315' => '5.25 h',
        '330' => '5.5 h',
        '345' => '5.75 h',
        '360' => '6 h',
        '375' => '6.25 h',
        '390' => '6.5 h',
        '405' => '6.75 h',
        '420' => '7 h',
        '435' => '7.25 h',
        '450' => '7.5 h',
        '465' => '7.75 h',
        '480' => '8 h',
        '495' => '8.25 h',
        '510' => '8.5 h',
        '525' => '8.75 h',
        '540' => '9 h',
        '555' => '9.25 h',
        '570' => '9.5 h',
        '585' => '9.75 h',
        '600' => '10 h',
        '615' => '10.25 h',
        '630' => '10.5 h',
        '645' => '10.75 h',
        '660' => '11 h',
        '675' => '11.25 h',
        '690' => '11.5 h',
        '705' => '11.75 h',
        '720' => '12 h',
        '735' => '12.25 h',
        '750' => '12.5 h',
        '765' => '12.75 h',
        '780' => '13 h',
        '795' => '13.25 h',
        '810' => '13.5 h',
        '825' => '13.75 h',
        '840' => '14 h',
        '855' => '14.25 h',
        '870' => '14.5 h',
        '885' => '14.75 h',
        '900' => '15 h',
    ];

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $isHoliday = $options['holiday'];
        $tempsPresenceExtra = $options['tempsPresenceExtra'];
        $constraint = $isHoliday ? [] : [new NotBlank(), new Time()];
        $builder
            ->add('day_type', ChoiceType::class, [
                'label' => 'Type',
                'required' => true,
                'choices' => TempsPresence::DAY_TYPE,
            ]
        )->add('heure_arrivee', TimeType::class, [
            'label' => 'Arrived at',
            'widget' => 'single_text',
            'html5' => false,
            'required' => true,
            'attr' => [
                'autocomplete' => 'off',
            ],
            'constraints' => $constraint,
        ])->add('heure_depart', TimeType::class, [
            'label' => 'Leaved at',
            'widget' => 'single_text',
            'html5' => false,
            'required' => true,
            'attr' => [
                'autocomplete' => 'off',
            ],
            'constraints' => $constraint,
        ])->add('duree_pause', ChoiceType::class, [
            'label' => 'Pause',
            'required' => true,
            'choices' => array_flip(self::DUREE_PAUSE),
            'constraints' => [
                new NotBlank(),
            ],
        ])
            ->add('extra_day_type', ChoiceType::class, [
                    'label' => 'Type Extra Hours',
                    'required' => true,
                    'mapped' => false,
                    'data' => $tempsPresenceExtra ? $tempsPresenceExtra->getDayType() : '',
                    'choices' => TempsPresence::DAY_TYPE_EXTRA,
                    'attr' => [
                        'readonly' => !$options['canAddExtraHours'],
                    ],
                ]
            )->add('extra_extra_hours', NumberType::class, [
                'label' => 'Extra hours:',
                'required' => false,
                'mapped' => false,
                'data' => $tempsPresenceExtra ? $tempsPresenceExtra->getExtraHours() : 0,
                'attr' => [
                    'autocomplete' => 'off',
                    'readonly' => !$options['canAddExtraHours'],
                ],
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => TempsPresence::class,
            'csrf_protection' => false,
            'method' => 'POST',
            'holiday' => false,
            'tempsPresenceExtra' => null,
            'canAddExtraHours' => false,
        ]);
    }
}
