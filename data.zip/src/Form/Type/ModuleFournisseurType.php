<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Coefficient;
use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\ModuleFournisseur;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class ModuleFournisseurType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => ModuleFournisseur::class,
            'name' => 'module_fournisseur',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
        ]);
    }

    /**
     * @param FormBuilderInterface $builder
     * @param array                $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('paiement', ChoiceType::class, [
            'label' => false,
            'choices' => [
                'Yes' => 'O',
                'No' => 'N',
            ],
            'preferred_choices' => ['Yes'],
            'required' => true,
        ]);

        $builder->add('fournisseur', Select2HiddenPropelType::class, [
            'label' => false,
            'multiple' => false,
            'required' => true,
            'property' => 'id',
            'empty_value' => 'Select a supplier',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => FournisseurQuery::create(),
            'choices' => 'fournisseur_search_for_module_fournisseur',
            'init_choices' => 'fournisseur_search_by_name_init',
            'class' => Fournisseur::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('categorie_prestation', ModelType::class, [
            'query' => CategoriePrestationQuery::create()->filterByModuleOk('Y', Criteria::EQUAL),
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
            'multiple' => false,
            'expanded' => false,
            'label' => false,
            'placeholder' => 'Select a category',
            'class' => CategoriePrestation::class,
        ]);

        $builder->add('quantite', NumberType::class, [
            'label' => false,
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('unit_price', NumberType::class, [
            'label' => false,
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('coefficient', ChoiceType::class, [
            'choices' => Coefficient::getCoefficients(),
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('cout', NumberType::class, [
            'attr' => [
                'readonly' => true,
            ],
            'label' => false,
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);
        $builder->add('frais', NumberType::class, [
            'label' => false,
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('date_debut', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);

        $builder->add('date_fin', DateType::class, [
            'widget' => 'single_text',
            'label' => false,
            'format' => 'dd/MM/yyyy',
            'required' => false,
            'html5' => false,
        ]);
    }
}
