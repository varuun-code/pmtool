<?php

namespace Form\Type;

use Model\Etude;
use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\Propel;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class OpportunityFilterType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $cutoffs = ['' => ''] + Etude::getCutoffs()->toKeyValue('PeriodeCutoff', 'PeriodeCutoff');

        $con = Propel::getConnection();
        $stmt1 = $con->prepare('SELECT DISTINCT account_manager_id FROM etude');
        $stmt1->execute();
        $ids1 = $stmt1->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        $stmt2 = $con->prepare('SELECT DISTINCT account_manager_id FROM sf_opportunity');
        $stmt2->execute();
        $ids2 = $stmt2->fetchAll(\PDO::FETCH_COLUMN) ?: [];
        $accountManagerIds = array_unique(array_merge($ids1, $ids2));

        $builder
            ->add('industry', ModelType::class, [
                'query' => IndustryQuery::create()->filterByActif(true)->orderByLibelle(),
                'required' => false,
                'multiple' => true,
                'class' => Industry::class,
            ])
            ->add('location', ModelType::class, [
                'query' => LocationQuery::create()->distinct()
                    ->useJobLocationQuery(null, Criteria::LEFT_JOIN)->filterById(null, Criteria::ISNOTNULL)->endUse()
                    ->_or()
                    ->useBidJobLocationQuery(null, Criteria::LEFT_JOIN)->filterById(null, Criteria::ISNOTNULL)->endUse()
                    ->orderByLibelle(), // only those used by BidJobs
                'required' => false,
                'multiple' => true,
                'class' => Location::class,
            ])
            ->add('salesManagers', ModelType::class, [
                'query' => UserQuery::create()
                    ->useEtudeRelatedByIdBmQuery()
                    ->filterById(null, Criteria::ISNOTNULL)
                    ->endUse()
                    ->orderByNom(Criteria::ASC),
                'required' => false,
                'multiple' => true,
                'class' => User::class,
            ])
            ->add('accountManagers', ModelType::class, [
                'query' => UserQuery::create()
                    ->filterById($accountManagerIds)
                    ->orderByNom(Criteria::ASC),
                'multiple' => true,
                'required' => false,
                'class' => User::class,
            ])
            ->add('projectManagers', ModelType::class, [
                'query' => UserQuery::create()
                    ->useEtudeEtudeProjectManagerQuery()
                    ->filterById(null, Criteria::ISNOTNULL)
                    ->endUse()
                    ->orderByNom(Criteria::ASC),
                'multiple' => true,
                'required' => false,
                'class' => User::class,
            ])
            ->add('jobQualifications', ModelType::class, [
                'query' => RefSalesForceQuery::create()
                    ->useMethodologyQuery()
                        ->filterById(null, Criteria::ISNOTNULL)
                    ->endUse()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                    ->filterByField('job_qualification_id')
                    ->filterByActif(true),
                'multiple' => true,
                'required' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('period1', ChoiceType::class, [
                'choices' => $cutoffs,
                'multiple' => true,
                'required' => false,
            ])
            ->add('period2', ChoiceType::class, [
                'choices' => $cutoffs,
                'multiple' => true,
                'required' => false,
            ])
            ->add('dateDebut', DateType::class, [
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('dateDebut2', DateType::class, [
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('dateFin', DateType::class, [
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('dateFin2', DateType::class, [
                'widget' => 'single_text',
                'format' => 'yyyy-MM-dd',
                'required' => false,
                'attr' => ['class' => 'datePick'],
            ])
            ->add('gqs', ModelType::class, [
                'placeholder' => 'Select a GQS',
                'query' => RefSalesForceQuery::create()
                    ->filterByField('us_global_qual_gms_id')
                    ->filterByActif(true),
                'multiple' => true,
                'expanded' => false,
                'required' => false,
                'class' => RefSalesForce::class,
            ])
            ->add('include_empty_gqs', CheckboxType::class, [
                'label' => 'Display opportunities with empty GQS',
                'required' => false,
            ])
            ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
        ]);
    }
}
