<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\EventMethodology;
use Model\EventMethodologyQuery;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoom;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Count;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class QuickOpportunityType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'allow_extra_fields' => true,
            'user' => '',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $user = $options['user'];
        $isFacilityOnly = $user && $user->getisRoomRental();
        $isFacilityOnlyChecked = ($isFacilityOnly ? ['checked' => 'checked', 'value' => '1'] : ['checked' => false, 'value' => '0']);
        $defaultCheckboxValue = ['style' => 'display:none;', 'checked' => false, 'value' => '0'];

        $builder->add('status', ModelType::class, [
                'label' => 'Event status',
                'placeholder' => 'Select a status',
                'query' => RefEventStatusQuery::create(),
                'multiple' => false,
                'expanded' => false,
                'required' => true,
                'data' => RefEventStatusQuery::create()->filterByName(RefEventStatus::TENTATIVE)->findOne(),
                'attr' => [
                    'placeholder' => 'status',
                ],
                'class' => RefEventStatus::class,
            ])
            ->add('event_methodology', ModelType::class, [
                'query' => EventMethodologyQuery::create()->filterAndOrderForChoice(),
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
                'multiple' => false,
                'expanded' => false,
                'label' => 'Event methodology',
                'placeholder' => 'Select a methodology',
                'class' => EventMethodology::class,
            ])
            ->add('account', Select2HiddenPropelType::class, [
                'label' => 'Client',
                'multiple' => false,
                'required' => true,
                'property' => 'id',
                'empty_value' => 'Select an account',
                'query' => AccountQuery::create(),
                'constraints' => new NotBlank(),
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'mapped' => false,
                'class' => Account::class,
            ])
            ->add('contact', Select2HiddenPropelType::class, [
                'label' => 'Bid contact',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select a contact',
                'query' => ContactQuery::create(),
                'constraints' => new NotBlank(),
                'choices' => 'contact_search_by_name',
                'init_choices' => 'contact_search_by_name_init',
                'mapped' => false,
                'class' => Contact::class,
            ])
            ->add('account_manager', ModelType::class, [
                'label' => 'Sales Rep',
                'property_path' => 'opportunity_account_manager',
                 'query' => UserQuery::create()
                    ->filterBySfId('', Criteria::NOT_EQUAL)
                    ->orderByPrenom(Criteria::ASC)
                    ->orderByNom(Criteria::ASC),
                'required' => true,
                'placeholder' => '(use sponsor from Account)',
                'mapped' => false,
                'class' => User::class,
            ])
            ->add('methodologies', ModelType::class, [
                'property_path' => 'SalesForceOpportunityMethodologies',
                'query' => MethodologyQuery::create()
                    ->orderByOrdre()->filterByActif(true)
                    ->filterBySfLabel(null, Criteria::ISNOTNULL),
                'required' => true,
                'multiple' => true,
                'expanded' => false,
                'constraints' => [
                    new Count([
                        'min' => 1,
                        'minMessage' => 'You must specify at least one methodology',
                    ]),
                ],
                'label' => 'Opportunity Methodologies',
                'mapped' => false,
                'class' => Methodology::class,
            ])
            ->add('opportunity_subject', TextType::class, [
                'label' => 'opportunity subject',
                'required' => true,
                'constraints' => [
                    new Length([
                        'max' => 80,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                    new NotBlank(),
                ],
                'mapped' => false,
            ])
            ->add('job_qualification', ModelType::class, [
                'label' => 'Job Qualification',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('job_qualification_id')->filterByTable('opportunity'),
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a job qualification',
                'data' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('job_qualification_id')->filterByTable('opportunity')->filterByValue('QUal')->findOne(),
                'class' => RefSalesForce::class,
            ])
            ->add('pmtool_created_by', ModelType::class, [
                'label' => 'Opportunity Owner',
                'query' => UserQuery::create()
                    ->filterByStatut('A')
                    ->filterByisSeller(true)
                    ->orderByPrenom(Criteria::ASC)
                    ->orderByNom(Criteria::ASC),
                'required' => false,
                'placeholder' => 'Opportunity Owner',
                'data' => $user,
                'class' => User::class,
            ])
            ->add('facility_only', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $isFacilityOnlyChecked,
            ])
            ->add('facilty_note', TextareaType::class, [
                'label' => 'Facility Note',
                'required' => false,
            ])
            ->add('translator_equipment', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('Streaming', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('pc_rental', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('usabilty_lab', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('simtrans', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('note_taker', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('additional_qa', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('catering_respondent', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('catering_client', CheckboxType::class, [
                'label' => false,
                'required' => false,
                'attr' => $defaultCheckboxValue,
            ])
            ->add('save', SubmitType::class, [
                'label' => 'Save',
                'attr' => ['class' => 'btn-success'],
            ])
        ;

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($user) {
            $form = $event->getForm();
            if ($user) {
                $choicesSelection = RefRoom::getRoomsNamesAndLocationsForChoiceSelection();
                $form->add('ref_room_id', ChoiceType::class, [
                    'choices' => $choicesSelection,
                    'placeholder' => 'Select a Room',
                    'attr' => ['placeholder' => 'Select a Room'],
                    'label' => 'Room',
                    'required' => true,
                    'disabled' => true,
                ]);
            }
        });
    }
}
