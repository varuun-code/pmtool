<?php

namespace Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AccountDetailType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'name' => 'account_detail',
            'csrf_protection' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add(
            'key_account_manager',
            TextType::class,
        [
            'label' => 'Key account manager',
            'property_path' => 'KeyAccountManager',
            'required' => false,
        ]
        );

        $builder->add(
            'debtor_number',
            TextType::class,
        [
            'label' => 'Debtor Number',
            'property_path' => 'DebtorNumber',
            'required' => false,
        ]
        );

        $builder->add(
            'special_client_billing_information',
            TextareaType::class,
        [
            'label' => 'Special client Billing Information',
            'property_path' => 'SpecialClientBillingInformation',
            'required' => false,
            'attr' => ['rows' => '9'],
        ]
        );

        $builder->add(
            'most_important_criteria',
            TextType::class,
        [
            'label' => 'Most Important Criteria',
            'property_path' => 'MostImportantCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'project_manager_criteria',
            TextType::class,
        [
            'label' => 'Project Manager Criteria',
            'property_path' => 'ProjectManagerCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'updates_criteria',
            TextType::class,
        [
            'label' => 'Updates Criteria',
            'property_path' => 'UpdatesCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'negative_check_criteria',
            TextType::class,
        [
            'label' => 'Negative Check Criteria',
            'property_path' => 'NegativeCheckCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'incentive_criteria',
            TextType::class,
        [
            'label' => 'Incentive Criteria',
            'property_path' => 'IncentiveCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'send_criteria',
            TextType::class,
        [
            'label' => 'Labeling/send out data (A/V/Consent Forms) Criteria',
            'property_path' => 'SendCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'translator_criteria',
            TextType::class,
        [
            'label' => 'Translator Criteria',
            'property_path' => 'TranslatorCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'moderator_criteria',
            TextType::class,
        [
            'label' => 'Moderator Criteria',
            'property_path' => 'ModeratorCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'others_criteria',
            TextType::class,
        [
            'label' => 'Others Criteria',
            'property_path' => 'OthersCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'documents_criteria',
            TextType::class,
        [
            'label' => 'Documents Criteria',
            'property_path' => 'DocumentsCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'sales_criteria',
            TextType::class,
        [
            'label' => 'Sales Criteria',
            'property_path' => 'SalesCriteria',
            'required' => false,
        ]
        );

        $builder->add(
            'discount_on',
            TextType::class,
            [
                'label' => 'Discount On',
                'property_path' => 'DiscountOn',
                'required' => false,
            ]
        );
    }
}
