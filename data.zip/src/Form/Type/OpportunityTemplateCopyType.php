<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Opportunity;
use Model\OpportunityQuery;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class OpportunityTemplateCopyType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Opportunity::class,
            'csrf_protection' => false,
            'allow_extra_fields' => true,
            'auto_initialize' => false,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
             ->add('id', HiddenType::class, [
                'required' => false,
                'label' => false,
            ])
            ->add('templates', Select2HiddenPropelType::class, [
                'label' => false,
                'query' => OpportunityQuery::create()
                          ->filterByIsTemplate(true)
                          ->find(),
                'required' => true,
                'multiple' => false,
                'empty_value' => 'Select a full template',
                'mapped' => false,
                'constraints' => [
                        new NotBlank(),
                    ],
                'class' => Opportunity::class,
                'choices' => 'oppt_search_by_template_type_full',
            ]);
    }
}
