<?php

namespace Form\Type;

use Model\Event;
use Model\EventMethodology;
use Model\EventMethodologyQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoom;
use Model\RefRoomQuery;
use Model\RefTimeSlot;
use Model\Site;
use Model\SiteQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class JobEventType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Event::class,
            'name' => 'job_event',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'allow_extra_fields' => true,
            'parent_data' => [],
            'user' => [],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($options) {
            $form = $event->getForm();
            $data = $event->getData();

            if ($data && $data->getRefRoom()) {
                $location = $options['parent_data']->getJobLocation();
                $jobLocation = $location ? $options['parent_data']->getJobLocation()->getLibelle() : '';
                $isDeleted = $data->getIsDeletedC();
                $canUserEditEvent = $options['user'] && $options['user']->getcanEditEvent();

                $form->add('isDeleted', HiddenType::class, [
                    'label' => false,
                    'required' => true,
                    'data' => $isDeleted ? 1 : 0,
                ]);

                if (($canUserEditEvent || $data->isOffsite()) && !$data->getIsDeletedC()) {
                    $form
                        ->add('isDeleted', HiddenType::class, [
                            'label' => false,
                            'required' => true,
                            'data' => $isDeleted ? 1 : 0,
                        ])
                        ->add('location', TextType::class, [
                            'label' => false,
                            'required' => false,
                            'mapped' => false,
                            'disabled' => 'disabled',
                            'data' => $jobLocation,
                        ])
                        ->add('created_date', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy',
                            'disabled' => 'disabled',
                            'required' => false,
                        ])
                        ->add('ref_room', ModelType::class, [
                            'required' => true,
                            'class' => RefRoom::class,
                            'query' => RefRoomQuery::create()->filterByLocation($location)->filterByActive(true)->orderByName(),
                            'multiple' => false,
                            'expanded' => false,
                            'label' => false,
                            'disabled' => $canUserEditEvent ? false : 'disabled',
                        ])
                        ->add('date', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy',
                            'required' => false,
                            'disabled' => 'disabled',
                        ])
                        ->add('start_date_time', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy HH:mm',
                            'required' => false,
                            'attr' => [
                                'placeholder' => 'Start Datetime',
                                'job_start_date' => $data->getJob() ? $data->getJob()->getStartDate('d-m-Y') : '',
                                'job_end_date' => $data->getJob() ? $data->getJob()->getEndDate('d-m-Y') : '',
                            ],
                        ])
                        ->add('end_date_time', DateTimeType::class, [
                            'widget' => 'single_text',
                            'label' => false,
                            'format' => 'dd/MM/yyyy HH:mm',
                            'required' => false,
                            'attr' => [
                                'placeholder' => 'End Datetime',
                                'job_start_date' => $data->getJob() ? $data->getJob()->getStartDate('d-m-Y') : '',
                                'job_end_date' => $data->getJob() ? $data->getJob()->getEndDate('d-m-Y') : '',
                                'eventCreateDate' => $data->getCreatedDate() ? $data->getCreatedDate('d-m-Y') : '',
                            ],
                        ])
                        ->add('event_methodology', ModelType::class, [
                            'query' => EventMethodologyQuery::create()->filterAndOrderForChoice(),
                            'required' => true,
                            'constraints' => [new NotBlank()],
                            'multiple' => false,
                            'expanded' => false,
                            'label' => false,
                            'placeholder' => 'Select a methodology',
                            'class' => EventMethodology::class,
                        ])
                        ->add('site', ModelType::class, [
                            'query' => SiteQuery::create(),
                            'required' => true,
                            'preferred_choices' => SiteQuery::create()->filterBySamsLocation($jobLocation)->find()->getData(),
                            'multiple' => false,
                            'expanded' => false,
                            'label' => false,
                            'class' => Site::class,
                        ])
                        ->add('refEventStatus', ModelType::class, [
                            'label' => false,
                            'multiple' => false,
                            'expanded' => false,
                            'required' => true,
                            'disabled' => false,
                            'query' => RefEventStatusQuery::create(),
                            'class' => RefEventStatus::class,
                        ])
                        ->add('refTimeSlot', ModelType::class, [
                            'label' => false,
                            'required' => false,
                            'multiple' => false,
                            'expanded' => false,
                            'disabled' => false,
                            'placeholder' => 'Select time slot',
                            'class' => RefTimeSlot::class,
                        ])
                        ->add('description', TextType::class, [
                            'label' => 'description',
                            'required' => false,
                            'disabled' => false,
                        ])
                        ->add('facility_note', TextareaType::class, [
                            'label' => 'Facility Note',
                            'required' => false,
                        ])
                    ;
                }
            }
        });

        $builder->add('modules', CollectionType::class, [
            'label' => false,
            'entry_type' => ModuleType::class,
            'allow_add' => true,
            'allow_delete' => false, // avoid unwanted Module deletion
            'delete_empty' => false,
            'by_reference' => false,
            'entry_options' => [
                'label' => false,
                'parent_data' => $builder->getData(),
                'job_data' => $options['parent_data'],
            ],
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();
            if ($data) {
                $display = ('us' == $this->instance || $data->getIsDeletedC()) ? 'none' : 'display';
                if ($data->getEventMethodologyId()) {
                    $caseACocher = [];
                    foreach ($data->getModules() as $module) {
                        $caseACocher[$module->getNumeroLigne()] = $module->getId();
                    }
                    $form->add('case_a_cocher', ChoiceType::class, [
                        'mapped' => false,
                        'label' => false,
                        'multiple' => true,
                        'attr' => [
                            'style' => 'display:'.$display,
                        ],
                        'expanded' => false,
                        'choices' => $caseACocher,
                        'required' => false,
                    ]);
                }
            }

            if ($data && $data->getIsDeletedC()) { // make Methodology optional for deleted Events
                $form
                    ->add('event_methodology', ModelType::class, [
                        'query' => EventMethodologyQuery::create()->filterAndOrderForChoice(),
                        'required' => true,
                        'constraints' => [],
                        'multiple' => false,
                        'expanded' => false,
                        'label' => false,
                        'placeholder' => 'Select a methodology',
                        'class' => EventMethodology::class,
                    ])
                ;
            }
        });
    }

    // Reorder modules by NumeroLigne (or id) in view.
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        usort($view['modules']->children, function (FormView $a, FormView $b) {
            $posA = $a->vars['data']->getNumeroLigne();
            $posB = $b->vars['data']->getNumeroLigne();

            if ($posA == $posB) {
                $posA = $a->vars['data']->getId();
                $posB = $b->vars['data']->getId();

                if ($posA == $posB) {
                    return 0;
                }
            }

            return ($posA < $posB) ? -1 : 1;
        });
    }
}
