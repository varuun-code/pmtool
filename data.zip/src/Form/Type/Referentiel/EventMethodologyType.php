<?php

namespace Form\Type\Referentiel;

use Model\EventMethodology;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class EventMethodologyType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => EventMethodology::class,
            'name' => 'event-methodology',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('label', TextType::class, [
                'label' => 'Event Methodology Label',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('active', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('sams_label', TextType::class, [
                'label' => 'Sams Label',
                'required' => false,
            ])
            ->add('rank', TextType::class, [
                'label' => 'Rank',
                'required' => false,
            ])
        ;
    }
}
