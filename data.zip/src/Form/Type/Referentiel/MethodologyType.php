<?php

namespace Form\Type\Referentiel;

use Model\Duree;
use Model\DureeQuery;
use Model\Methodology;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class MethodologyType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Methodology::class,
            'name' => 'methodology',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('typeEtudeOrdre', TextType::class, [
                'label' => 'Order',
                'required' => false,
            ])
            ->add('methodology_job_qualification', ModelType::class, [
                'label' => 'Job Qualification',
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'query' => RefSalesForceQuery::create()
                    ->filterByField('job_qualification_id')
                    ->filterByActif(true),
                'class' => RefSalesForce::class,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('ordre', TextType::class, [
                'label' => 'Rank',
                'required' => false,
            ])
            ->add('typeEtude', TextType::class, [
                'label' => 'Methodology German',
                'required' => false,
            ])
            ->add('typeEtudeBr', TextType::class, [
                'label' => 'Methodology English',
                'required' => false,
                'empty_data' => '',
            ])
            ->add('duree', ModelType::class, [
                'label' => 'Standard Duration',
                'query' => DureeQuery::create(),
                'multiple' => false,
                'class' => Duree::class,
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('typeEtudeAlias', TextType::class, [
                'label' => 'Alias',
                'required' => false,
                'empty_data' => '',
            ])
            ->add('consolidation', TextType::class, [
                'label' => 'Consolidation',
                'required' => false,
            ])
            ->add('actif', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('sf_label', TextType::class, [
                'label' => 'SalesForce LAbel',
                'required' => false,
            ])
        ;
    }
}
