<?php

namespace Form\Type\Referentiel;

use Model\Area;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class AreaType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Area::class,
            'name' => 'area',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('libelle', TextType::class, [
                'label' => 'Area Label',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('actif', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('sf_label', TextType::class, [
                'label' => 'Salesforce Label',
                'required' => false,
            ])
            ->add('ordre', TextType::class, [
                'label' => 'Rank',
                'required' => false,
            ])
            ->add('sector', ModelType::class, [
                'label' => 'Respondent type category',
                'query' => RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                    ->filterByField('sectors')
                    ->filterByActif(true),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'class' => RefSalesForce::class,
            ])
        ;
    }
}
