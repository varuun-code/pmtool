<?php

namespace Form\Type\Referentiel;

use Model\SampleSource;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class SampleSourceType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => SampleSource::class,
            'name' => 'sample-source',
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('libelle', TextType::class, [
                'label' => 'Sample Source Label',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('actif', CheckboxType::class, [
                'label' => 'Active/Inactive',
                'required' => false,
            ])
            ->add('sf_label', TextType::class, [
                'label' => 'Salesforce Label',
                'required' => false,
            ])
            ->add('ordre', TextType::class, [
                'label' => 'Rank',
                'required' => false,
            ])
        ;
    }
}
