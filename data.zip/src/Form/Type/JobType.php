<?php

namespace Form\Type;

use Model\AmReasonType;
use Model\AmReasonTypeQuery;
use Model\Etude;
use Model\Groupe;
use Model\Job;
use Model\Location;
use Model\LocationQuery;
use Model\Map\RefSalesForceTableMap;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\Platforms;
use Model\PlatformsQuery;
use Model\RefEventStatus;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Count;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class JobType extends AbstractType
{
    private string $currency;
    private string $instance;

    public function __construct(string $currency, string $instance)
    {
        $this->currency = $currency;
        $this->instance = $instance;
    }

    const TENTATIVE_OPTIONAL = [
        'job_project_manager' => ModelType::class,
        'off_site_recruits' => NumberType::class,
        'on_site_recruits' => NumberType::class,
        'start_date' => DateType::class,
        'end_date' => DateType::class,
        'call_center' => ModelType::class,
    ];

    protected $optionsMethodologies = [];
    protected $optionsServices = [];
    protected $optionsOnSiteRecruits = [];
    protected $optionsOffSiteRecruits = [];
    protected $optionsSampleSize = [];

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Job::class,
            'name' => 'job',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'event_dispatcher' => null,
            'user' => '',
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $actualUser = $options['user'];

        $auditCompleteClass = null == $options['parent_data']->getId() ? 'hidden' : '';

        $this->optionsOnSiteRecruits = [
            'label' => 'on-site recruits',
            'required' => false,
        ];
        $this->optionsOffSiteRecruits = [
            'label' => 'off-site recruits',
            'required' => false,
        ];
        $this->optionsSampleSize = [
            'label' => 'Sample size',
            'required' => false,
        ];
        $isRequired = false;
        $color = [''];
        $bonus_per_recruit = 'Bonus per recruit ('.$this->currency.')';
        if ('us' == $this->instance) {
            $isRequired = true;
            $color = ['style' => 'color:#ab556b'];
        }
        $canStatusBeDisabled = false;
        $statusQuery = RefSalesForceQuery::create()
            ->filterByActif(true)
            ->filterByField('status_id')
            ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB)
            ->filterByValue('Cancelled-Billed', Criteria::NOT_EQUAL);
        if (in_array($actualUser->getIdGroupe(), [Groupe::SALES_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::ACCOUNTING, Groupe::SYSTEM_ADMINISTRATOR])) {
            $statusQuery = RefSalesForceQuery::create()
                ->filterByActif(true)
                ->filterByField('status_id')
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB);
            $canStatusBeDisabled = false;
        }
        if (!in_array($actualUser->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING, Groupe::MANAGING_DIRECTOR])) {
            $statusQuery = RefSalesForceQuery::create()
                ->filterByActif(true)
                ->filterByField('status_id')
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB);
            $canStatusBeDisabled = true;
        }

        $builder->add('country', ModelType::class, [
            'label' => 'Country',
            'query' => RefSalesForceQuery::create()
                ->filterByActif(true)
                ->filterByField('country')
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a country',
            'class' => RefSalesForce::class,
        ]);

        $builder->add('sample_sources', ModelType::class, [
            'label' => 'Sample Sources',
            'query' => RefSalesForceQuery::create()
                ->filterByActif(true)
                ->filterByField('sample_sources')
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB),
            'required' => true,
            'multiple' => true,
            'expanded' => false,
            'placeholder' => 'Select sample sources',
            'class' => RefSalesForce::class,
        ]);

        $builder
           ->add('job_technical_project_manager', ModelType::class, [
                'query' => UserQuery::create()
                    ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR, Groupe::MANAGEMENT])
                    ->filterByStatut('A')
                        ->_or()
                    ->filterById(isset($options['parent_data']) ? $options['parent_data']->getIdPm() : null)
                    ->orderByPrenom()
                    ->orderByNom(),
                'label' => 'Job Platform PM',
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a Platform Job PM',
                'class' => User::class,
            ])->add('bonus_per_recruit', MoneyType::class, [
                'label' => $bonus_per_recruit,
                'required' => false,
                'currency' => '',
            ])->add('lost_revenue', MoneyType::class, [
                'label' => 'Lost Revenue',
                'required' => false,
                'currency' => '',
            ])->add('start_date', DateType::class, [
                'widget' => 'single_text',
                'label' => 'Job Start Date',
                'format' => 'dd/MM/yyyy',
                'html5' => false,
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])->add('end_date', DateType::class, [
                'widget' => 'single_text',
                'label' => 'Job End Date',
                'format' => 'dd/MM/yyyy',
                'html5' => false,
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])->add('client_project_number', TextType::class, [
                'label' => 'Client project number',
                'required' => false,
                'constraints' => [
                    new Length([
                        'max' => 30,
                        'maxMessage' => 'The value cannot be longer than 30 characters',
                    ]),
                ],
            ])->add('po_job_number', TextType::class, [
                'label' => 'Po number',
                'required' => false,
                'constraints' => [
                    new Length([
                        'max' => 45,
                        'maxMessage' => 'The value cannot be longer than 45 characters',
                    ]),
                ],
            ])->add('room_count', NumberType::class, [
                'label' => 'Room count',
                'required' => true,
            ])->add('per_group', TextType::class, [
                'required' => $isRequired,
                'label_attr' => $color,
            ])->add('per_day', TextType::class, [
                'required' => $isRequired,
                'label_attr' => $color,
            ])->add('per_hour', TextType::class, [
                'required' => $isRequired,
                'label_attr' => $color,
            ])->add('name', TextType::class, [
                'label' => 'Name',
                'required' => false,
            ])->add('coronavirus_effected', CheckboxType::class, [
                'label' => 'Coronavirus Effected',
                'required' => false,
            ])->add('proposed_billing_date', DateType::class, [
                'widget' => 'single_text',
                'label' => 'Proposed Billing Date',
                'format' => 'dd/MM/yyyy',
                'required' => false,
                'html5' => false,
            ])->add('job_comments', TextareaType::class, [
                'required' => false,
            ])->add('end_date_reason', ModelType::class, [
                'label' => 'Job end date reason',
                'required' => false,
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('end_date_reason')->filterByTable('job'),
                'class' => RefSalesForce::class,
            ])->add('job_account_manager', ModelType::class, [
                'label' => 'Sales Rep',
                'property_path' => 'job_account_manager',
                'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT])
                ->filterByStatut('A')
                ->orderByPrenom()
                ->orderByNom(),
                'required' => true,
                 'constraints' => [
                    new NotBlank(),
                ],
                'placeholder' => '(use account Sales Rep)',
                'class' => User::class,
            ])->add('platform', ModelType::class, [
                'label' => 'Products',
                'query' => PlatformsQuery::create(),
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select Products',
                'class' => Platforms::class,
                'constraints' => [
                    new NotBlank(),
                ],
                'choice_label' => 'name',
                'choice_attr' => function ($platform) {
                    return [
                           'style' => $platform->getActive() ? '' : 'display:none',
                        ];
                },
            ]);

        $builder->add('pm_reason_type_id', ModelType::class, [
            'label' => 'PM Stop Reason',
            'placeholder' => 'PM Stop Reason',
            'multiple' => false,
            'expanded' => false,
            'query' => AmReasonTypeQuery::create()->filterByIsPm(1, Criteria::EQUAL),
            'required' => false,
            'class' => AmReasonType::class,
            'property_path' => 'amReasonType', // FIXME remove
        ]);

        $builder->add('set_pm_reason', TextType::class, [
            'label' => 'Other PM Stop Reason',
            'required' => false,
            'constraints' => [
                new Length([
                    'max' => 30,
                    'maxMessage' => 'The value cannot be longer than 30 characters',
                ]),
            ],
        ]);

        $builder->add('number_shows', IntegerType::class, [
            'label' => '# Shows',
            'required' => true,
            'empty_data' => '',
            'label_attr' => ['style' => 'color:#ab556b'],
            'constraints' => [
                new NotBlank(),
            ],
        ]);
        $builder->add('audit_complete', CheckboxType::class, [
            'label' => 'Audit Complete',
            'required' => false,
            'attr' => ['class' => $auditCompleteClass],
        ]);
        if (isset($options['parent_data']) && !$options['parent_data']->isNew()) {
            $builder
                ->add('fd_checked', CheckboxType::class, [
                    'label' => 'FD',
                    'required' => false,
                ])->add('pm_checked', CheckboxType::class, [
                    'label' => 'PM',
                    'required' => false,
                ])->add('acct_checked', CheckboxType::class, [
                    'label' => 'Acct',
                    'required' => false,
                ])->add('acct_invoiced', CheckboxType::class, [
                    'label' => 'Acct Invoiced',
                    'required' => false,
                ])->add('am_checked', CheckboxType::class, [
                    'label' => 'AM',
                    'required' => false,
                ])->add('project_cordinator', ModelType::class, [
                    'query' => UserQuery::create()
                        ->filterByIdGroupe([Groupe::PROJECT_MANAGER])
                        ->filterByStatut('A')
                        ->orderByPrenom()
                        ->orderByNom(),
                    'label' => 'Project Coordinator',
                    'required' => false,
                    'multiple' => false,
                    'expanded' => false,
                    'placeholder' => 'Select a Project Coordinator',
                    'class' => User::class,
                ])
            ;
        }
        if (in_array($actualUser->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING, Groupe::MANAGING_DIRECTOR])) {
            $builder
                ->add('invoice_number', TextType::class, [
                    'required' => false,
                ])->add('invoice_date', DateType::class, [
                    'widget' => 'single_text',
                    'label' => 'Invoice Date',
                    'format' => 'dd/MM/yyyy',
                    'required' => false,
                    'html5' => false,
                ])
            ;
        }

        $this->optionsMethodologies = [
            'query' => MethodologyQuery::create()->filterById(null)->filterAndOrderForChoice(),
            'required' => true,
            'constraints' => [
                new Count(['min' => 1]),
            ],
            'multiple' => true,
            'expanded' => false,
            'label' => 'Methodologies',
            'class' => Methodology::class,
        ];

        $this->optionsServices = [
            'label' => 'Services',
            'query' => RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                ->filterByField('servicess')
                ->filterByActif(true),
            'required' => true,
            'constraints' => [
                new Count(['min' => 1]),
            ],
            'multiple' => true,
            'expanded' => false,
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceJobRefServicess',
        ];

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) {
            $datas = $event->getData();
            $form = $event->getForm();
            $idSalesForce = RefSalesForceQuery::create()
                ->filterByLabel('Status')
                ->filterByActif(true)
                ->filterByTable('job')
                ->filterByValue('Active')
                ->findOne();
            $idSalesForce = $idSalesForce ? $idSalesForce->getId() : 0;
            $isOtherMonth = null;
            if ($form->getData() && isset($datas['end_date'])) {
                $oldEndDate = $form->getData()->getEndDate();
                $newEndDate = date_create_from_format('d/m/Y', $datas['end_date']);
                if ($oldEndDate && $newEndDate) {
                    $isOtherMonth = $oldEndDate->format('m') != $newEndDate->format('m');
                }
                if ($oldEndDate && $newEndDate && $oldEndDate->format('d/m/Y') != $newEndDate->format('d/m/Y')) {
                    $form->add('end_date_reason', ModelType::class, [
                        'required' => false,
                        'constraints' => new NotBlank(['message' => 'If the date of the end date changed, this field is mandatory']),
                        'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('end_date_reason')->filterByTable('job'),
                        'class' => RefSalesForce::class,
                    ]);
                }
            }

            if (isset($datas['status']) && $datas['status'] == $idSalesForce && $isOtherMonth) {
                $form->add('end_date_reason', ModelType::class, [
                    'label' => 'Job end date reason',
                    'required' => false,
                    'constraints' => new NotBlank(['message' => 'If the month of the end date changed, this field is mandatory']),
                    'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('end_date_reason')->filterByTable('job'),
                    'class' => RefSalesForce::class,
                ]);
            }
        });

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) {
            $data = $event->getData();
            $form = $event->getForm();
            $tentative = RefSalesForceQuery::create()
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB)
                ->filterByField('status_id')
                ->filterByValue('Tentative')
                ->findOne();
            if ($tentative && isset($data['status']) && $data['status'] == $tentative->getId()) {
                foreach (self::TENTATIVE_OPTIONAL as $field => $type) {
                    if (!isset($data['on_site_recruits']) && 'on_site_recruits' == $field) {
                        continue;
                    }
                    $data[$field] = null;
                    $config = $form->get($field)->getConfig();
                    $options = $config->getOptions();
                    $options['constraints'] = [];
                    $form->add($field, $type, $options);
                }

                $event->setData($data);
            }
        });

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($statusQuery, $canStatusBeDisabled, $actualUser, $options) {
            $data = $event->getData();
            $form = $event->getForm();
            $status = $data ? $data->getStatus() : '';

            $jobCallCenterStatus = RefSalesForceQuery::create()
                ->filterByActif(true)
                ->filterByField('call_center')
                ->filterByTable(RefSalesForceTableMap::COL_TABLE_JOB)
                ->filterByValue('Not Applicable')
                ->findOne();

            $form->add('job_project_manager', ModelType::class, [
                'query' => UserQuery::create()
                    ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, Groupe::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR, Groupe::MANAGEMENT])
                    ->filterByStatut('A')
                    ->_or()
                    ->filterById(isset($options['parent_data']) ? $options['parent_data']->getIdPm() : null)
                    ->orderByPrenom()
                    ->orderByNom(),
                'label' => 'Job PM',
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a Job PM',
                'class' => User::class,
                'data' => $data && $data->getJobProjectManager() ? $data->getJobProjectManager() : (isset($options['parent_data']) ? $options['parent_data']->getEtudeProjectManager() : null),
                    'constraints' => [
                    new NotBlank(),
                ],
            ]);
            $form->add('call_center', ModelType::class, [
                'label' => 'Call Center',
                'required' => true,
                'constraints' => [new NotBlank()],
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('call_center')->filterByTable('job'),
                'class' => RefSalesForce::class,
                'placeholder' => 'Select a call center',
                'data' => $data && $data->getCallCenter() ? $data->getCallCenter() : $jobCallCenterStatus,
            ]);

            $form->add('status', ModelType::class, [
                'label' => 'Status',
                'required' => true,
                'constraints' => [new NotBlank()],
                'query' => $statusQuery,
                'disabled' => 'Closed' == $status && $canStatusBeDisabled,
                'class' => RefSalesForce::class,
                'placeholder' => 'Select a status',
            ]);
            $form->add('current_status', HiddenType::class, [
                'mapped' => false,
                'data' => $status ? $status->getValue() : '',
            ]);

            if ($data && !$data->isNew()) {
                $form->add('location_prefix', ModelType::class, [
                    'label' => 'Location Prefix',
                    'query' => LocationQuery::create()->filterByPrefix(null, Criteria::ISNOTNULL),
                    'required' => false,
                    'multiple' => false,
                    'expanded' => false,
                    'placeholder' => 'Select location prefix',
                    'class' => Location::class,
                    'choice_label' => 'prefix',
                ]);
                $form->add('rush_request_checked', CheckboxType::class, [
                    'label' => 'Rush Request',
                    'required' => false,
                ]);
                if (in_array($actualUser->getIdGroupe(), [Groupe::SYSTEM_ADMINISTRATOR, Groupe::ACCOUNTING, Groupe::MANAGING_DIRECTOR])) {
                    $form->add('rejected_checked', CheckboxType::class, [
                    'label' => 'Rejected',
                    'required' => false,
                ]);
                    $form->add('rejected_reason', TextareaType::class, [
                    'label' => 'Rejected Reason',
                    'required' => false,
                ]);
                }
                $form->add('unlock_request_checked', CheckboxType::class, [
                    'label' => 'Unlock Request',
                    'required' => false,
                ]);

                $form->add('unlock_reason', TextareaType::class, [
                    'label' => 'Unlock Reason',
                    'required' => false,
                ]);
            } else {
                $form->add('job_location', ModelType::class, [
                    'label' => 'Location',
                    'query' => LocationQuery::create()
                        ->filterByLibelle('Not Applicable', Criteria::NOT_EQUAL)
                        ->filterByActive(true)
                        ->_or()
                            ->filterByGqsAvailable(true)
                        ->orderByLibelle(),
                    'required' => true,
                    'multiple' => false,
                    'expanded' => false,
                    'placeholder' => 'Select a location',
                    'class' => Location::class,
                    'constraints' => [
                        new NotBlank(),
                    ],
                    'choice_attr' => function ($location) {
                        return [
                            'data-active' => $location->getActive() ? 'Y' : 'N',
                            'data-gqs-available' => $location->getGqsAvailable() ? 'Y' : 'N',
                            'data-onsite' => $location->getOnSite() ? 'Y' : 'N',
                        ];
                    },
                ]);
            }
        });

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($options) {
            $form = $event->getForm();
            $data = $event->getData();
            $etudeData = $data && $data->getEtude() ? $data->getEtude() : $options['parent_data'];
            if ($etudeData && (!$etudeData->isNew() || $etudeData->getOpportunity())) {
                $roomRentalOnly = ($data && $data->getRoomRentalOnly()) || ($etudeData->isNew() && $etudeData->getOpportunity()->getRoomRental());
                $form->add('room_rental_only', CheckboxType::class, [
                    'label' => 'Room Rental Only',
                    'required' => false,
                    'data' => $roomRentalOnly,
                ]);
            }
            if ($etudeData) {
                if ($qualificationId = $etudeData->getJobQualificationId()) {
                    $methodologyQuery = MethodologyQuery::create()
                        ->_if($qualificationId)
                            ->filterByMethodologyJobQualificationId($qualificationId)
                        ->_endif()
                        ->filterAndOrderForChoice();
                    $this->optionsMethodologies['query'] = $methodologyQuery;

                    if (in_array($qualificationId, Etude::getQualificationQuantType())) {
                        $this->optionsOnSiteRecruits['required'] = false;
                        $this->optionsOnSiteRecruits['constraints'] = [];
                        $this->optionsOffSiteRecruits['required'] = false;
                        $this->optionsOffSiteRecruits['constraints'] = [];
                        $this->optionsSampleSize['required'] = true;
                        $this->optionsSampleSize['constraints'] = [new NotBlank()];
                    } else {
                        $this->optionsOnSiteRecruits['required'] = true;
                        $this->optionsOnSiteRecruits['constraints'] = [new NotBlank()];
                        $this->optionsOffSiteRecruits['required'] = true;
                        $this->optionsOffSiteRecruits['constraints'] = [new NotBlank()];
                        $this->optionsSampleSize['required'] = false;
                        $this->optionsSampleSize['constraints'] = [];
                    }
                }
                $etudeMethodologies = $etudeData->getMethodologies();
                if ((!$data || ($data && 0 == $data->getMethodologies()->count())) && $etudeMethodologies) {
                    $this->optionsMethodologies['data'] = $etudeMethodologies;
                }
                $opportunityServices = $etudeData->getOpportunity() ? $etudeData->getOpportunity()->getRefSalesForceOpportunityRefServicess() : null;
                if ((!$data || ($data && 0 == $data->getRefSalesForceJobRefServicess()->count())) && $opportunityServices) {
                    $this->optionsServices['data'] = $opportunityServices;
                }
            }

            $this->optionsOnSiteRecruits['disabled'] = $data && $data->isOnSite() && $data->getOffSiteRecruits() && !$data->getOnSiteRecruits() ? true : false;
            $this->optionsOffSiteRecruits['disabled'] = $data && $data->isOnSite() && $data->getOnSiteRecruits() && !$data->getOffSiteRecruits() ? true : false;

            if (!$data || ($data && $data->isOnSite()) || $data->isNew()) {
                $form->add('on_site_recruits', NumberType::class, $this->optionsOnSiteRecruits);
            }
            $form->add('off_site_recruits', NumberType::class, $this->optionsOffSiteRecruits);

            $form->add('sample_size', TextType::class, $this->optionsSampleSize);
            $form->add('methodologies', ModelType::class, $this->optionsMethodologies);
            $form->add('servicess', ModelType::class, $this->optionsServices);
            if ($data && 'Closed' == $data->getStatus()) {
                $form->add('start_date', DateType::class, [
                    'widget' => 'single_text',
                    'label' => 'Job Start Date',
                    'format' => 'dd/MM/yyyy',
                    'html5' => false,
                    'disabled' => 'disabled',
                    'constraints' => [
                        new NotBlank(),
                    ],
                ]);
                $form->add('end_date', DateType::class, [
                    'widget' => 'single_text',
                    'label' => 'Job End Date',
                    'format' => 'dd/MM/yyyy',
                    'html5' => false,
                    'disabled' => 'disabled',
                    'constraints' => [
                        new NotBlank(),
                    ],
                ]);
            }
        });

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $event->getData();
            $triggerOnSiteFdError = $triggerOnSitePmError = false;

            foreach ($data->getEvents() as $event) {
                if (!$event->getIsDeletedC() && in_array($event->getRefEventStatus(), [RefEventStatus::CONFIRMED, RefEventStatus::TENTATIVE, RefEventStatus::ON_HOLD])) {
                    $triggerOnSiteFdError = $data->isOnSite() && $data->getFdChecked();
                    $triggerOnSitePmError = !$data->isOnSite() && $data->getPmChecked();
                }
            }
            if ($triggerOnSiteFdError) {
                $form->get('fd_checked')->addError(new FormError('There are still confirmed/tentative or on hold events on this job. Please update those status before checking FD box. Thanks'));
            }
            if ($triggerOnSitePmError) {
                $form->get('pm_checked')->addError(new FormError('There are still confirmed/tentative or on hold events on this job. Please update those status before checking PM box. Thanks'));
            }

            $beginDate = $form->get('start_date')->getData();
            $endDate = $form->get('end_date')->getData();

            if ($beginDate > $endDate) {
                $form->get('end_date')->addError(new FormError('Job end date must be after job start date!'));
            }
            if ($endDate && $endDate->format('Y-m-d') > date('Y-m-d') && $data->getStatus() && $form->get('current_status')->getData() !== $data->getStatus()->getValue() && 'Closed' === $data->getStatus()->getValue()) {
                $form->get('status')->addError(new FormError('Cannot set status closed  because job end date greater than current date'));
            }

            if ($beginDate && $endDate) {
                $areJobDatesInBetweenEventDates = true;
                foreach ($data->getEvents() as $event) {
                    if (!$event->isDeletedC() && !in_array($event->getRefEventStatus(), [RefEventStatus::RELEASED, RefEventStatus::CANCELLED_NON_BILLED]) && (
                        !($event->getStartDateTime('Y-m-d') >= $beginDate->format('Y-m-d') && $event->getStartDateTime('Y-m-d') <= $endDate->format('Y-m-d')) ||
                        !($event->getEndDateTime('Y-m-d') >= $beginDate->format('Y-m-d') && $event->getEndDateTime('Y-m-d') <= $endDate->format('Y-m-d')))) {
                        $areJobDatesInBetweenEventDates = false;
                        break;
                    }
                }
                if (!$areJobDatesInBetweenEventDates) {
                    $form->get('start_date')->addError(new FormError('Job start and end dates must be between event dates.'));
                }
            }

            $setPmReasonType = $form->get('pm_reason_type_id')->getData();
            $setPmReason = $form->get('set_pm_reason')->getData();
            $jobStatus = $form->get('status')->getData();
            if (RefSalesForce::JOB_STATUS_POSTPONED == $jobStatus && null === $setPmReasonType) {
                $form->get('pm_reason_type_id')->addError(new FormError('A reason type is mandatory if you choose Postponed status'));
            }

            if (null !== $setPmReasonType && AmReasonType::OTHER == $setPmReasonType->getLabel() && (null === $setPmReason || '' === $setPmReason)) {
                $form->get('set_pm_reason')->addError(new FormError('An explanation is mandatory if you choose "Others" for PM Stop reason'));
            }

            if (!$data->isNew() && $form->get('unlock_request_checked')->getData() && null === $form->get('unlock_reason')->getData()) {
                $form->get('unlock_reason')->addError(new FormError('An unlock reason is mandatory if you choose "Unlock Request" '));
            }
        });
    }
}
