<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Map\OpportunityTableMap;
use Model\Map\RefSalesForceTableMap;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\Opportunity;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\SampleSource;
use Model\SampleSourceQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Count;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Range;

class OpportunityType extends AbstractType
{
    protected $optionsEndClientContact;

    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Opportunity::class,
            'name' => 'etude',
            'csrf_protection' => false,
            'cascade_validation' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $required = !$builder->getData()->getIsTemplate();

        $builder
            ->add('account', Select2HiddenPropelType::class, [
                'label' => 'Client',
                'multiple' => false,
                'required' => $required,
                'property' => 'id',
                'empty_value' => 'Select an account',
                'formatSelection' => 'formatSelectedAccount',
                'formatResult' => 'formatResultPerson',
                'query' => AccountQuery::create(),
                'constraints' => $required ? new NotBlank() : [],
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])
            ->add('end_client_contact', Select2HiddenPropelType::class, [
                'label' => 'End Client Contact',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select a contact',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => ContactQuery::create(),
                'choices' => 'contact_search_by_name',
                'init_choices' => 'contact_search_by_name_init',
                'class' => Contact::class,
                'custom_ajax_json' => "
                ajax: {
                    url: '/index.php/contact/search-by-name',
                    datatype: 'jsonp',
                    quietMillis: 100,
                    data: function(term, page) {
                        return {
                            filters: {'AccountId': $('#opportunity_end_client').val() },
                            term: term,
                            page: page,
                            max_per_page: 10
                        };
                    },
                    results: function(data, page) {
                        var more = false;
                        if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                            more = (page * data.maxPerPage) < data.total;
                        }
                        return {
                            results: data.results,
                            more: more
                        };
                    }
                }",
            ])
            ->add('contact', Select2HiddenPropelType::class, [
                'label' => 'Bid contact',
                'multiple' => false,
                'required' => $required,
                'property' => 'id',
                'empty_value' => 'Select a contact',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => ContactQuery::create(),
                'constraints' => $required ? new NotBlank() : [],
                'choices' => 'contact_search_by_name',
                'init_choices' => 'contact_search_by_name_init',
                'class' => Contact::class,
                'custom_ajax_json' => "
                ajax: {
                    url: '/index.php/contact/search-by-name',
                    datatype: 'jsonp',
                    quietMillis: 100,
                    data: function(term, page) {
                        return {
                            filters: {'AccountId': $('#opportunity_account').val() },
                            term: term,
                            page: page,
                            max_per_page: 10
                        };
                    },
                    results: function(data, page) {
                        var more = false;
                        if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                            more = (page * data.maxPerPage) < data.total;
                        }
                        return {
                            results: data.results,
                            more: more
                        };
                    }
                }",
            ])
            ->add('client_type', ModelType::class, [
                'label' => 'Client Type',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('client_type_id')->filterByTable('opportunity'),
                'required' => false,
                'empty_data' => '',
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a client type',
                'class' => RefSalesForce::class,
            ])
            ->add('us_global_qual_gms', ModelType::class, [
                'label' => 'GQS',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('us_global_qual_gms_id')->filterByTable('opportunity'),
                'required' => false,
                'empty_data' => '',
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a GQS',
                'class' => RefSalesForce::class,
            ])
            ->add('job_qualification', ModelType::class, [
                'label' => 'Job Qualification',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('job_qualification_id')->filterByTable('opportunity'),
                'required' => $required,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a job qualification',
                'constraints' => $required ? [new NotBlank()] : [],
                'class' => RefSalesForce::class,
            ])
            ->add('print_currency', ChoiceType::class, [
                'label' => 'Currency Excel/PDF',
                'choices' => [
                     OpportunityTableMap::COL_PRINT_CURRENCY_EUR => OpportunityTableMap::COL_PRINT_CURRENCY_EUR,
                    OpportunityTableMap::COL_PRINT_CURRENCY_USD => OpportunityTableMap::COL_PRINT_CURRENCY_USD,
                    OpportunityTableMap::COL_PRINT_CURRENCY_GBP => OpportunityTableMap::COL_PRINT_CURRENCY_GBP,
                    OpportunityTableMap::COL_PRINT_CURRENCY_CAD => OpportunityTableMap::COL_PRINT_CURRENCY_CAD,
                ],
                'required' => false,
                'empty_data' => '',
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a currency',
            ])
            ->add('sectors', ModelType::class, [
                'label' => 'Respondent type category',
                'property_path' => 'refSalesForceOpportunityRefSectors',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('sectors')->filterByTable('opportunity'),
                'required' => $required,
                'multiple' => true,
                'expanded' => false,
                'constraints' => $required ? [
                    new Count([
                        'min' => 1,
                        'minMessage' => 'You must specify at least one sector',
                    ]),
                ] : [],
                'class' => RefSalesForce::class,
            ])
            ->add('methodologies', ModelType::class, [
                'property_path' => 'SalesForceOpportunityMethodologies',
                'query' => MethodologyQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel(null, Criteria::ISNOTNULL),
                'required' => $required,
                'multiple' => true,
                'expanded' => false,
                'constraints' => $required ? [
                    new Count([
                        'min' => 1,
                        'minMessage' => 'You must specify at least one methodology',
                    ]),
                ] : [],
                'label' => 'Methodologies',
                'class' => Methodology::class,
            ])
            ->add('managing_locations', ModelType::class, [
                'property_path' => 'SalesForceOpportunityLocations',
                'query' => LocationQuery::create()
                    ->filterByLibelle('Not Applicable', Criteria::NOT_EQUAL)
                    ->filterBySfLabel(null, Criteria::ISNOTNULL)
                    ->filterByActive(true)
                    ->orderByLibelle(),
                'required' => $required,
                'multiple' => true,
                'expanded' => false,
                'constraints' => $required ? [
                    new Count([
                        'min' => 1,
                        'minMessage' => 'You must specify at least one location',
                    ]),
                ] : [],
                'label' => 'Locations',
                'class' => Location::class,
                'choice_attr' => function (Location $location) {
                    return [
                        'data-active' => $location->getActive() ? 'Y' : 'N',
                        'data-gqs' => $location->getGqsAvailable() ? 'Y' : 'N',
                    ];
                },
            ])
            ->add('platform_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                    ->filterByField('platform_id'),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Platform',
            ])
            ->add('specifics_id', ModelType::class, [
                'query' => RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_OPPORTUNITY)
                    ->filterByField('specifics_id'),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Specifics',
            ])
            ->add('industry', ModelType::class, [
                'label' => 'industry',
                'query' => IndustryQuery::create()->orderByOrdre()->filterByActif(true)->filterBySfLabel('', Criteria::NOT_EQUAL),
                'required' => $required,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select an industry',
                'constraints' => $required ? [
                    new NotBlank(),
                ] : [],
                'class' => Industry::class,
            ])
            ->add('services', ModelType::class, [
                'property_path' => 'refSalesForceOpportunityRefServicess',
                'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('servicess'),
                'required' => false,
                'multiple' => true,
                'expanded' => false,
                'label' => 'Services',
                'class' => RefSalesForce::class,
            ])
            ->add('bid_revenue', TextType::class, [
                'label' => 'Bid Revenue',
                'required' => $required,
                'constraints' => $required ? [
                    new NotBlank(),
                ] : [],
            ])
            ->add('client_bid_number', TextType::class, [
                'label' => 'Client Bid Number',
                'required' => false,
                'empty_data' => '',
                'constraints' => $required ? [
                    new Length([
                        'max' => 255,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                ] : [],
            ])
            ->add('project_number', TextType::class, [
                'label' => 'Client Project Number',
                'required' => false,
                'constraints' => [
                    new Length([
                        'max' => 30,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                ],
            ])
            ->add('loi_option_1', NumberType::class, [
                'label' => 'Proposed LOI 1',
                'required' => false,
                'empty_data' => '',
                'scale' => 2,
            ])
            ->add('loi_option_2', NumberType::class, [
                'label' => 'Proposed LOI 2',
                'required' => false,
                'empty_data' => '',
                'scale' => 2,
            ])
            ->add('max_ir', NumberType::class, [
                'label' => 'Max IR',
                'required' => false,
                'empty_data' => '',
                'scale' => 2,
            ])
            ->add('min_ir', NumberType::class, [
                'label' => 'Min IR',
                'required' => false,
                'empty_data' => '',
                'scale' => 2,
            ])
            ->add('n_sample_size', NumberType::class, [
                'label' => '(N) Sample Size',
                'required' => false,
                'scale' => 2,
            ])
            ->add('incidence_rate', NumberType::class, [
                'label' => 'Incidence Rate',
                'required' => false,
                'empty_data' => '0',
                'constraints' => [
                    new Range([
                        'min' => 0,
                        'max' => 100,
                    ]),
                ],
            ])
            ->add('nb_of_survey', NumberType::class, [
                'label' => 'Number of Surveys',
                'required' => false,
                'empty_data' => '0',
            ])
            ->add('programming_complexity', ChoiceType::class, [
                'label' => 'Programming Complexity',
                'required' => true,
                'choices' => Opportunity::getProgrammingComplexities(),
                'constraints' => [
                    new NotBlank(),
                ],
            ])
            ->add('notes_or_comments', TextType::class, [
                'label' => 'Comments',
                'required' => false,
                'empty_data' => '',
            ])
            ->add('sample_plan', TextareaType::class, [
                'label' => 'Sample Plan',
                'required' => false,
            ])
            ->add('opportunity_subject', TextType::class, [
                'label' => 'Opportunity Subject',
                'required' => $required,
                'constraints' => $required ? [
                    new Length([
                        'max' => 80,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                    new NotBlank(),
                ] : [],
            ])
            ->add('other_location', TextType::class, [
                'label' => 'Other Location',
                'required' => false,
                'empty_data' => '',
                'constraints' => [
                    new Length([
                        'max' => 50,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                ],
            ])
            ->add('include_account_manager', CheckboxType::class, [
                'label' => 'Include Account Manager on Bid',
                'required' => false,
            ])
            ->add('include_opp_owner', CheckboxType::class, [
                'label' => 'Include Opportunity Owner on Bid',
                'required' => false,
            ])
            ->add('recruits_offsite', CheckboxType::class, [
                'label' => 'recruits offsite only',
                'required' => false,
            ])
            ->add('translator_equipment', CheckboxType::class, [
                'label' => 'translator equipement ',
                'required' => false,
            ])
            ->add('streaming', CheckboxType::class, [
                'label' => 'streaming ',
                'required' => false,
            ])
            ->add('pc_rental', CheckboxType::class, [
                'label' => 'pc rental ',
                'required' => false,
            ])
            ->add('usability_lab', CheckboxType::class, [
                'label' => 'usability lab ',
                'required' => false,
            ])
            ->add('simtrans', CheckboxType::class, [
                'label' => 'simtrans ',
                'required' => false,
            ])
            ->add('note_taker', CheckboxType::class, [
                'label' => 'note_taker ',
                'required' => false,
            ])
            ->add('additional_QA', CheckboxType::class, [
                'label' => 'additional QA ',
                'required' => false,
            ])
            ->add('catering_resp', CheckboxType::class, [
                'label' => 'catering resp ',
                'required' => false,
            ])
            ->add('catering_client', CheckboxType::class, [
                'label' => 'catering_client ',
                'required' => false,
            ])
            ->add('apply_discount', CheckboxType::class, [
                'label' => 'Apply Discount',
                'required' => false,
            ])
            ->add('response_time', IntegerType::class, [
                'label' => 'Response Time',
                'required' => false,
                'empty_data' => '',
                'constraints' => [
                    new Length([
                        'max' => 255,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                ],
            ])
            ->add('close_date', DateType::class, [
                'label' => 'Close Date',
                'widget' => 'single_text',
                'format' => 'dd/MM/yyyy',
                'required' => false,
            ])
            ->add('estimated_commissioning_date', DateType::class, [
                'label' => 'Est. Commission Date',
                'widget' => 'single_text',
                'format' => 'dd/MM/yyyy',
                'required' => false,
            ])
            ->add('account_manager', ModelType::class, [
                'label' => 'Sales Rep',
                'property_path' => 'opportunity_account_manager',
                'query' => UserQuery::create()
                    ->filterBySfId('', Criteria::NOT_EQUAL)
                    ->orderByPrenom(Criteria::ASC)
                    ->orderByNom(Criteria::ASC),
                'required' => $required,
                'constraints' => $required ? [
                    new NotBlank(),
                ] : [],
                'placeholder' => '(use sponsor from Account)',
                'class' => User::class,
            ])
            ->add('pmtool_created_by', ModelType::class, [
                'label' => 'Opportunity Owner',
                'query' => UserQuery::create()
                    ->filterByStatut('A')
                    ->filterByisSeller(true)
                    ->orderByPrenom(Criteria::ASC)
                    ->orderByNom(Criteria::ASC),
                'required' => false,
                'placeholder' => 'Opportunity Owner',
                'class' => User::class,
            ])
            ->add('end_client_rep', Select2HiddenPropelType::class, [
                'label' => 'End Client Report',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select a contact',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => AccountQuery::create(),
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])
            ->add('intermediate_client', Select2HiddenPropelType::class, [
                'label' => 'Intermediate Client',
                'multiple' => false,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select a client',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => AccountQuery::create(),
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])
            ->add('is_study_specification', CheckboxType::class, [
                'label' => 'Use study specification',
                'required' => false,
            ])
            ->add('study_specification', TextareaType::class, [
                'label' => 'Study Specification',
                'required' => false,
            ])
            ->add('client_discount_percentage', NumberType::class, [
                'label' => 'Client Qual discount percentage',
                'required' => false,
            ])
            ->add('end_client_discount_percentage', NumberType::class, [
                'label' => 'End client Qual discount percentage',
                'required' => false,
            ])->add('client_quant_discount_percentage', NumberType::class, [
                'label' => 'Client Quant discount percentage',
                'required' => false,
            ])
            ->add('end_client_quant_discount_percentage', NumberType::class, [
                'label' => 'End client Quant discount percentage',
                'required' => false,
            ])->add('coronavirus_effected', CheckboxType::class, [
                'label' => 'Coronavirus Effected',
                'required' => false,
            ])->add('lost_revenue', MoneyType::class, [
                'label' => 'Lost Revenue',
                'required' => false,
                'currency' => '',
            ])->add('copied_template_id', HiddenType::class, [
                'mapped' => true,
            ])->add('facilty_note', TextareaType::class, [
                'label' => 'Facility Note',
                'required' => false,
            ])->add('sample_sources', ModelType::class, [
                'query' => SampleSourceQuery::create()->filterAndOrderForChoice(),
                'required' => false,
                'multiple' => true,
                'expanded' => false,
                'label' => 'Sample Sources',
                'class' => SampleSource::class,
            ]);

        if ($builder->getData()->getId()) {
            $builder->add('specialty_sponsor', ModelType::class, [
                'label' => 'Specialty Sales Rep',
                'property_path' => 'opportunity_specialty_sponsor',
                'query' => UserQuery::create()
                    ->filterBySfId('', Criteria::NOT_EQUAL)
                    ->orderByPrenom(Criteria::ASC)
                    ->orderByNom(Criteria::ASC),
                'required' => false,
                'placeholder' => '(use sponsor from Specialty Sales Rep)',
                'class' => User::class,
            ]);
        }

        if (!$required) {
            $builder
              ->add('template_title', TextType::class, [
                'label' => 'Template Title',
                'required' => !$required,
                'constraints' => !$required ? [
                    new Length([
                        'max' => 255,
                        'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                    ]),
                    new NotBlank(),
                ] : [],
            ])
            ->add('template_scope', ChoiceType::class, [
                'label' => 'Template Scope',
                'choices' => Opportunity::getTemplateScopes(),
                'placeholder' => 'Select a template Scope',
                'required' => !$required,
                'expanded' => false,
                'constraints' => !$required ? [
                    new NotBlank(),
                ] : [],
            ])
            ->add('template_type', ChoiceType::class, [
                'label' => 'Template Type',
                'choices' => Opportunity::getTemplateTypes(),
                'required' => !$required,
                'constraints' => !$required ? [
                    new NotBlank(),
                ] : [],
                'expanded' => false,
            ]);
        }

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                $form = $event->getForm();
                $data = $event->getData();

                $required = !$data->getIsTemplate();
                if ($data) {
                    $isRoomRental = $data->getRoomRental();
                    $defaultRoomRentalValue = ($isRoomRental ? ['checked' => 'checked', 'value' => '1'] : ['checked' => false, 'value' => '0']);

                    $form->add('room_rental', CheckboxType::class, [
                        'label' => 'room rental only ',
                        'required' => false,
                        'attr' => $defaultRoomRentalValue,
                    ]);
                }
                if ($data && $endClient = $data->getEndClient()) {
                    $this->optionsEndClientContact['query'] = ContactQuery::create()
                        ->_if($endClient)
                        ->filterByAccount($endClient)
                        ->_endif();
                    $form->add('end_client', Select2HiddenPropelType::class, [
                        'label' => 'End Client',
                        'multiple' => false,
                        'required' => $required,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select a client',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'constraints' => new NotBlank(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => 'account_search_by_name_init',
                        'class' => Account::class,
                    ]);
                } else {
                    $endClient = AccountQuery::create()->filterByActiveStatusId()->findOneByName('Not Applicable');

                    $data->setEndClient($endClient);
                    $form->add('end_client', Select2HiddenPropelType::class, [
                        'label' => 'End Client',
                        'multiple' => false,
                        'required' => $required,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select a client',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => $endClient ? [$endClient->getId() => $endClient] : [],
                        'class' => Account::class,
                    ]);

                    $data->setEndClientRep($endClient);
                    $form->add('end_client_rep', Select2HiddenPropelType::class, [
                        'label' => 'End Client Report',
                        'multiple' => false,
                        'required' => false,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select a contact',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => $endClient ? [$endClient->getId() => $endClient] : [],
                        'class' => Account::class,
                    ]);

                    $data->setIntermediateClient($endClient);
                    $form->add('intermediate_client', Select2HiddenPropelType::class, [
                        'label' => 'Intermediate Client',
                        'multiple' => false,
                        'required' => false,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select a client',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => $endClient ? [$endClient->getId() => $endClient] : [],
                        'class' => Account::class,
                    ]);
                    $currency = RefSalesForce::getCurrency($this->instance);
                    $data->setCurrencyIsoCode($currency);
                    $data->setPrintCurrency($currency->getValue());
                }
            });
    }
}
