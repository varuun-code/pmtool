<?php

namespace Form\Type;

use Model\Account;
use Model\AccountDetail;
use Model\Map\RefSalesForceTableMap;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class AccountType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setRequired(['with_status']);
        $resolver->setDefaults([
            'data_class' => Account::class,
            'name' => 'account',
            'csrf_protection' => true,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('vat', TextType::class, [
            'label' => 'VAT',
            'required' => false,
        ]);
        if ($options['with_status']) {
            $builder->add('status_id', ModelType::class, [
                'label' => 'Status',
                'query' => RefSalesForceQuery::create()
                    ->filterByTable(RefSalesForceTableMap::COL_TABLE_ACCOUNT)
                    ->filterByField('status_id')
                    ->filterByActif(true),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'class' => RefSalesForce::class,
                'property_path' => 'Status',
            ]);
        }

        $builder->add('account_detail', AccountDetailType::class, [
            'data_class' => AccountDetail::class,
        ]);
    }
}
