<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\CategoriePrestation;
use Model\CategoriePrestationQuery;
use Model\Coefficient;
use Model\Fournisseur;
use Model\FournisseurQuery;
use Model\JobItem;
use Model\Markup;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class JobItemType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => JobItem::class,
            'name' => 'job_item',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'costs_enabled' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('devis_ok', HiddenType::class, [
            'label' => false,
            'required' => false,
        ])->add('category', ChoiceType::class, [
            'choices' => CategoriePrestationQuery::create()->withColumn('consolidation', 'id')->withColumn('consolidation', 'value')->select('consolidation')->find()->toKeyValue('id', 'value'),
            'placeholder' => 'Select a category',
        ])->add('sous_type_prestation', TextType::class, [
            'label' => false,
            'required' => false,
        ]);

        if ($options['costs_enabled']) {
            $builder->add('quantite_pr', NumberType::class, [
                'label' => false,
                'required' => false,
            ]);

            $builder->add('prix_revient', NumberType::class, [
                'attr' => [
                    'readonly' => true,
                ],
                'label' => false,
                'required' => false,
            ]);

            $builder->add('prix_revient_unitaire', NumberType::class, [
                'label' => false,
                'required' => false,
            ]);

            $builder->add('coefficiant_pr', ChoiceType::class, [
                'choices' => Coefficient::getCoefficients(),
                'preferred_choices' => ['1.00'],
            ]);

            $builder->add('prix_vente_unitaire_location', NumberType::class, [
                'label' => false,
                'required' => false,
            ]);
        }

        $builder->add('markup', ChoiceType::class, [
            'choices' => Markup::getCoefficients(),
            'required' => true,
        ]);

        $builder->add('quantite_pv', NumberType::class, [
            'label' => false,
            'required' => false,
        ])->add('prix_vente', NumberType::class, [
            'attr' => [
                'readonly' => true,
            ],
            'label' => false,
            'required' => false,
        ])->add('comment_pm', HiddenType::class)
        ->add('discount_comment', HiddenType::class, [
            'label' => 'Discount comment',
            'attr' => [
                'class' => 'discount_comment',
            ],
            'constraints' => [
                new Length([
                    'max' => 255,
                    'maxMessage' => 'The value cannot be longer than {{ limit }} characters',
                ]),
            ],
            'required' => false,
        ])->add('discount_percent', HiddenType::class, [
            'label' => 'Price',
            'attr' => [
                'class' => 'discount_percent',
            ],
            'required' => false,
        ])->add('discount_exclude', HiddenType::class, [
            'label' => 'Discount exclude',
            'attr' => [
                'class' => 'discount_exclude',
            ],
            'required' => false,
        ])->add('zero_value_confirmed', HiddenType::class, [
                'label' => '0 value confirmed',
                'attr' => [
                    'class' => 'zero_value_confirmed',
                ],
                'required' => false,
        ])->add('prix_vente_unitaire', NumberType::class, [
            'label' => false,
            'required' => false,
        ])->add('date', DateType::class, [
            'label' => 'Date',
            'widget' => 'single_text',
            'format' => 'dd/MM/yyyy',
            'html5' => false,
            'required' => false,
        ])
        ->add('order', HiddenType::class)
        ->add('group', HiddenType::class)
        ->add('group_title', HiddenType::class)
        ->add('super_group', HiddenType::class)
        ->add('super_group_title', HiddenType::class)
        ->add('methodology', ModelType::class, [
            'label' => 'Methodology',
            'query' => RefSalesForceQuery::create()->filterByfield('methodology'),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a methodology',
            'class' => RefSalesForce::class,
        ])
        ->add('resp_location', ModelType::class, [
            'label' => 'Resp. Location',
            'query' => RefSalesForceQuery::create()->filterByfield('respondent_location_id')->orderBy('value', Criteria::ASC),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a resp. location',
            'class' => RefSalesForce::class,
        ])
        ->add('respondent_type', ModelType::class, [
            'label' => 'Respondent type',
            'query' => RefSalesForceQuery::create()->filterByfield('respondent_type'),
            'required' => false,
            'multiple' => false,
            'placeholder' => 'Select a respondent type',
            'class' => RefSalesForce::class,
        ])
        ->add('down_payment', CheckboxType::class, [
            'required' => false,
            'label' => false,
        ]);

        $builder->addEventListener(
            FormEvents::PRE_SET_DATA,
            function (FormEvent $event) {
                $form = $event->getForm();
                $data = $event->getData();
                $categoryInitChoices = ($data && $category = $data->getCategoriePrestation()) ? [$category->getId() => $category->getCategory()] : [];
                $vendorInitChoices = ($data && $vendor = $data->getVendor()) ? [$vendor->getId() => $vendor->getFullnameOrCompany()] : [];

                $form->add('categorie_prestation', Select2HiddenPropelType::class, [
                    'label' => 'Section',
                    'query' => CategoriePrestationQuery::create(),
                    'required' => true,
                    'multiple' => false,
                    'constraints' => new NotBlank(),
                    'empty_value' => 'Select a section',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'choices' => 'categorie_prestation_search_by_consolidation',
                    'init_choices' => $categoryInitChoices,
                    'class' => CategoriePrestation::class,
                    'custom_ajax_json' => 'ajax: window.searchCategoryByConsolidation, initSelection: window.categoryInitSelection',
                ])->add('vendor', Select2HiddenPropelType::class, [
                    'label' => 'supplier',
                    'query' => FournisseurQuery::create(),
                    'required' => false,
                    'multiple' => false,
                    'empty_value' => 'Select a supplier',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'choices' => 'fourniseur_search_by_name_vendor',
                    'init_choices' => $vendorInitChoices,
                    'class' => Fournisseur::class,
                    'custom_ajax_json' => 'ajax: window.searchFournisseurByName, initSelection: window.supplierInitSelection',
                ]);
            }
        );
    }
}
