<?php

namespace Form\Type;

use Model\BidJob;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\OptionsResolver\OptionsResolver;

class BidJobEventsType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => BidJob::class,
            'name' => 'bid_job',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'allow_extra_fields' => true,
            'parent_data' => [],
            'user' => [],
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('field', HiddenType::class, ['mapped' => false]) // to allow posting empty collection
            ->add('events', CollectionType::class, [
                'label' => false,
                'entry_type' => BidJobEventType::class,
                'entry_options' => [
                    'label' => false,
                    'parent_data' => $builder->getData(),
                    'user' => $options['user'],
                ],
                'allow_add' => true,
                'allow_delete' => false,
                'by_reference' => false,
                'delete_empty' => true,
            ]);

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) {
            $form = $event->getForm();
            $data = $form->getData()->getEvents();
            $formStatus = false;
            if ($data) {
                foreach ($data as $event) {
                    if (!$event->getRefRoom()) {
                        $formStatus = true;
                    }
                }
            }
            if ($formStatus) {
                $form->addError(new FormError('Event page is required to (reload/refresh) again.'));
            }
        });
    }

    // Reorder events by Date and StartDate in view.
    public function finishView(FormView $view, FormInterface $form, array $options)
    {
        usort($view['events']->children, function (FormView $a, FormView $b) {
            $pos1A = $a->vars['data']->getDate();
            $pos1B = $b->vars['data']->getDate();

            if ($pos1A == $pos1B) {
                $startDateA = $a->vars['data']->getStartDateTime();
                $pos2A = $startDateA ? $startDateA : 0;

                $startDateB = $b->vars['data']->getStartDateTime();
                $pos2B = $startDateB ? $startDateB : 0;

                if ($pos2A == $pos2B) {
                    return 0;
                }

                return ($pos2A < $pos2B) ? -1 : 1;
            }

            return ($pos1A < $pos1B) ? -1 : 1;
        });
    }
}
