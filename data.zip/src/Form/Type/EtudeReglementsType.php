<?php

namespace Form\Type;

use Model\Etude;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EtudeReglementsType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Etude::class,
            'name' => 'etude_reglements',
            'csrf_protection' => false,
            'cascade_validation' => true,
            'parent_data' => [],
            'bank_query' => null,
            'document_query' => null,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('field', HiddenType::class, ['mapped' => false]) // to allow posting empty collection
            ->add('reglements', CollectionType::class, [
                'label' => false,
                'entry_type' => EtudeReglementType::class,
                'allow_add' => true,
                'allow_delete' => true,
                'delete_empty' => true,
                'by_reference' => false,
                'entry_options' => [
                    'label' => false,
                    'bank_query' => $options['bank_query'],
                    'document_query' => $options['document_query'],
                    'parent_data' => $builder->getData(),
                ],
            ])
        ;
    }
}
