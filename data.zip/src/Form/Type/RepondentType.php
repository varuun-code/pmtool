<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\Quota;
use Model\QuotaQuery;
use Model\Repondant;
use Model\Ville;
use Model\VilleQuery;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class RepondentType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Repondant::class,
            'csrf_protection' => false,
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('qualite', ChoiceType::class, [
                'label' => 'Title',
                'choices' => Repondant::getCivilities($this->instance),
                'required' => false,
            ])->add('nom', TextType::class, [
                'label' => 'Last Name',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])->add('prenom', TextType::class, [
                'label' => 'First Name',
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
            ])->add('tel', TextType::class, [
                'label' => 'Phone',
                'required' => false,
            ])->add('portable', TextType::class, [
                'label' => 'Mobile',
                'required' => false,
            ])->add('fax', TextType::class, [
                'label' => 'Fax',
                'required' => false,
            ])->add('adresse', TextType::class, [
                'label' => 'Address',
                'required' => false,
            ])->add('email', EmailType::class, [
                'label' => 'E-mail',
                'required' => false,
            ])->add('email2', EmailType::class, [
                'label' => 'E-mail2',
                'required' => false,
            ])->add('societe', TextType::class, [
                'label' => 'Company',
                'required' => false,
            ])->add('notes', TextareaType::class, [
                'label' => 'Notes',
                'required' => false,
            ])->add('active', ChoiceType::class, [
                'label' => 'Active',
                'choices' => ['' => '', 'Y' => 'Y', 'N' => 'N'],
                'required' => false,
            ])->add('rating', ChoiceType::class, [
                'label' => 'Rating',
                'choices' => ['' => '', '+' => '+', '-' => '-'],
                'required' => false,
            ])->add('practice_type', ChoiceType::class, [
                'label' => 'Practice type',
                'placeholder' => 'select',
                'choices' => array_flip(Repondant::PRACTICE_TYPES),
                'required' => false,
            ])->add('no_rpps', TextType::class, [
                'label' => 'RPPS NB',
                'required' => false,
            ])->add('bic', TextType::class, [
                'label' => 'Bic',
                'required' => false,
            ])->add('iban', TextType::class, [
                'label' => 'IBAN',
                'required' => false,
            ])->add('ville', Select2HiddenPropelType::class, [
                'label' => 'City',
                'multiple' => false,
                'required' => true,
                'property' => 'id',
                'constraints' => new NotBlank(),
                'empty_value' => 'Select a city',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => VilleQuery::create(),
                'choices' => 'city_search_by_name',
                'init_choices' => 'city_search_by_name_init',
                'class' => Ville::class,
            ])->add('repondantBlacklistAccounts', Select2HiddenPropelType::class, [
                'multiple' => true,
                'required' => false,
                'label' => false,
                'property' => 'id',
                'empty_value' => 'Select an account(s)',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => AccountQuery::create(),
                'choices' => 'account_search_by_name',
                'init_choices' => 'account_search_by_name_init',
                'class' => Account::class,
            ])->add('repondantForQuotas', Select2HiddenPropelType::class, [
                'label' => 'Quotas',
                'multiple' => true,
                'required' => false,
                'property' => 'id',
                'empty_value' => 'Select Specialities',
                'formatSelection' => 'formatSelectedPerson',
                'formatResult' => 'formatResultPerson',
                'query' => QuotaQuery::create(),
                'choices' => 'quota_search_by_name',
                'init_choices' => 'quota_search_by_name_init',
                'class' => Quota::class,
            ])
        ;

        $submitListener = function (FormEvent $event) {
            $form = $event->getForm();

            /** @var Repondant $data */
            $data = $event->getData();

            if (('Dr' == $data->getQualite() || 'Pr' == $data->getQualite()) && !$data->getPracticeType()) {
                $error = new FormError('Practice type must be filled!');
                $form->get('practice_type')->addError($error);
            }
        };
        $builder->addEventListener(FormEvents::SUBMIT, $submitListener);
    }
}
