<?php

namespace Form\Type;

use Form\Propel\Select2HiddenPropelType;
use Model\Account;
use Model\AccountQuery;
use Model\AmReasonType;
use Model\AmReasonTypeQuery;
use Model\Area;
use Model\AreaQuery;
use Model\Contact;
use Model\ContactQuery;
use Model\Etape;
use Model\Etude;
use Model\Groupe;
use Model\Industry;
use Model\IndustryQuery;
use Model\Location;
use Model\LocationQuery;
use Model\Methodology;
use Model\MethodologyQuery;
use Model\ProjectLocationPrefix;
use Model\ProjectLocationPrefixQuery;
use Model\RefEventStatus;
use Model\RefSalesForce;
use Model\RefSalesForceQuery;
use Model\SampleSource;
use Model\SampleSourceQuery;
use Model\SiJobType;
use Model\SiJobTypeQuery;
use Model\User;
use Model\UserQuery;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Propel\Runtime\ActiveQuery\Criteria;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Count;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;

class EtudeType extends AbstractType
{
    private string $instance;

    public function __construct(string $instance)
    {
        $this->instance = $instance;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Etude::class,
            'name' => 'etude',
            'user' => User::class,
            'opportunity' => null,
            'csrf_protection' => false,
            'cascade_validation' => true,
        ]);
    }

    protected $optionsEndClientContact = [];
    protected $optionsIntermediateClientContact = [];
    protected $optionsJobMethodologies = [];
    protected $optionsJobOnSiteRecruits = [];
    protected $optionsJobOffSiteRecruits = [];
    protected $optionsJobSampleSize = [];

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $opportunity = $options['opportunity'];
        $etude = $builder->getData();
        $etape = $etude ? $etude->getEtape() : Etape::get(Etape::STUDY_CREATION);

        $this->optionsJobOnSiteRecruits = [
            'label' => 'on-site recruits',
            'required' => false,
            'empty_data' => '',
        ];
        $this->optionsJobOffSiteRecruits = [
            'label' => 'off-site recruits',
            'required' => false,
            'empty_data' => '',
        ];
        $this->optionsJobSampleSize = [
            'label' => 'Sample size',
            'required' => false,
            'empty_data' => '',
        ];

        $builder->add('reference_client', TextType::class, [
            'label' => 'Client Project Number',
            'required' => false,
            'empty_data' => '',
            'constraints' => [
                new Length([
                    'max' => 30,
                    'maxMessage' => 'The value cannot be longer than 30 characters',
                ]),
            ],
        ]);

        $builder->add('extra_info', TextareaType::class, [
            'label' => 'Special project billing information',
            'attr' => ['rows' => '3'],
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('study_specification', TextareaType::class, [
            'label' => 'Study Specification (client facing)',
            'required' => false,
        ]);

        $builder->add('project_comment', TextareaType::class, [
            'label' => 'Project Comment (internal)',
            'required' => false,
        ]);

        $builder->add('additional_notes', TextareaType::class, [
            'label' => 'Additional Notes (client facing)',
            'required' => false,
        ]);

        $builder->add('am_email', TextType::class, [
            'label' => 'AM email',
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('consolidated_invoice', CheckboxType::class, [
            'label' => 'Consolidated Invoice',
            'required' => false,
        ]);

        $builder->add('send_csat_quest', CheckboxType::class, [
            'label' => 'Send CSat Quest',
            'required' => false,
        ]);

        $builder->add('sunshine_act', ChoiceType::class, [
            'label' => 'Sunshine act',
            'multiple' => false,
            'expanded' => false,
            'choices' => ['N/A' => 'N/A', 'Blinded' => 'Blinded', 'Unblinded' => 'Unblinded'],
            'required' => true,
        ]);

        if ($builder->getData() && $builder->getData()->isNew()) {
            $builder->add('client_portal_ready', CheckboxType::class, [
            'label' => 'Client Portal Ready',
            'required' => false,
             'data' => false,
             'attr' => ['class' => 'tinymce'],
             'row_attr' => ['class' => 'text-editor', 'id' => 'newId'],
            ]);
        } else {
            $builder->add('client_portal_ready', CheckboxType::class, [
            'label' => 'Client Portal Ready',
            'required' => false,
        ]);
        }

        $builder->add('length_of_interview', TextType::class, [
            'label' => 'Length of Interview',
            'required' => false,
        ]);

        $builder->add('dont_set_am_auto', CheckboxType::class, [
            'label' => 'AM Stop',
            'required' => false,
        ]);

        $builder->add('set_am_reason_type', ModelType::class, [
            'label' => 'Why do you want to stop AM auto ?',
            'placeholder' => 'AM Stop Reason type',
            'multiple' => false,
            'expanded' => false,
            'query' => AmReasonTypeQuery::create()->filterByIsAm(1, Criteria::EQUAL),
            'required' => false,
            'class' => AmReasonType::class,
            'property_path' => 'amReasonType', // FIXME remove
        ]);

        $builder->add('set_am_reason', TextType::class, [
            'label' => 'AM Stop Reason',
            'required' => false,
            'constraints' => [
                new Length([
                    'max' => 30,
                    'maxMessage' => 'The value cannot be longer than 30 characters',
                ]),
            ],
        ]);

        $builder->add('etude_project_manager', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR, Groupe::MANAGEMENT, Groupe::FACILITY_DIRECTOR, Groupe::OPERATION_MANAGER, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER])
                ->filterByStatut('A')
                ->_or()
                ->filterById($builder->getData()->getIdPm())
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Master PM',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a master PM',
            'class' => User::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('project_account_manager', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT, Groupe::FACILITY_DIRECTOR, Groupe::OPERATION_MANAGER, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER])
                ->filterByStatut('A')
                ->_or()
                ->filterById($builder->getData()->getIdPm())
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Sales Rep',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a Sales Rep',
            'class' => User::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('project_specialty_sponsor', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT, Groupe::FACILITY_DIRECTOR, Groupe::OPERATION_MANAGER, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER])
                ->filterByStatut('A')
                ->_or()
                ->filterById($builder->getData()->getIdPm())
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Specialty Sales Rep',
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a specialty Sales Rep',
            'class' => User::class,
        ]);

        $builder->add('account_leader', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT, Groupe::FACILITY_DIRECTOR, Groupe::OPERATION_MANAGER, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER])
                ->filterByStatut('A')
                ->_or()
                ->filterById($builder->getData()->getIdPm())
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Account Leader',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select an account leader',
            'class' => User::class,
            'constraints' => [
                new NotBlank(),
            ],
            'choice_attr' => function ($choice) {
                return ['data-email' => $choice->getMail()];
            },
        ]);

        $builder->add('account_pm', ModelType::class, [
            'query' => UserQuery::create()
                ->filterByIdGroupe([Groupe::PROJECT_MANAGER, Groupe::MANAGING_DIRECTOR, GROUPE::PROJECT_DIRECTOR, Groupe::SALES_MANAGER, Groupe::MANAGEMENT, Groupe::FACILITY_DIRECTOR, Groupe::OPERATION_MANAGER, Groupe::BUSINESS_DEVELOPER, Groupe::FACILITY_MANAGER, Groupe::PHONE_ROOM_SUPERVISOR])
                ->filterByStatut('A')
                ->_or()
                ->filterById($builder->getData()->getIdPm())
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Account PM',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select an account PM',
            'class' => User::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('industry', ModelType::class, [
            'query' => IndustryQuery::create()->filterAndOrderForChoice(),
            'label' => 'Industry',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select an industry',
            'class' => Industry::class,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $attr = ($etape && $etape->getOrdre() < Etape::get(Etape::INVOICED)->getOrdre()) ? [] : ['readonly' => 'readonly'];
        $builder->add('account', Select2HiddenPropelType::class, [
            'label' => 'Client',
            'multiple' => false,
            'required' => true,
            'property' => 'getNameforPicklist',
            'empty_value' => 'Select a client',
            'formatSelection' => 'formatSelectedAccount',
            'formatResult' => 'formatResultAccount',
            'query' => AccountQuery::create(),
            'constraints' => new NotBlank(),
            'choices' => 'account_search_by_name',
            'init_choices' => 'account_search_by_name_init',
            'class' => Account::class,
            'attr' => $attr,
        ]);

        $builder->add('contact', Select2HiddenPropelType::class, [
            'label' => 'Bid contact',
            'multiple' => false,
            'required' => true,
            'property' => 'id',
            'empty_value' => 'Select a contact',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => ContactQuery::create(),
            'constraints' => new NotBlank(),
            'choices' => 'contact_search_by_name',
            'init_choices' => 'contact_search_by_name_init',
            'class' => Contact::class,
            'custom_ajax_json' => "
            ajax: {
                url: '/index.php/contact/search-by-name',
                datatype: 'jsonp',
                quietMillis: 100,
                data: function(term, page) {
                    return {
                        filters: {'AccountId': $('#etude_account').val() },
                        term: term,
                        page: page,
                        max_per_page: 10
                    };
                },
                results: function(data, page) {
                    var more = false;
                    if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                        more = (page * data.maxPerPage) < data.total;
                    }
                    return {
                        results: data.results,
                        more: more
                    };
                }
            }",
        ]);

        $builder->add('contact_client_pm', Select2HiddenPropelType::class, [
            'label' => 'PM contact',
            'multiple' => false,
            'required' => true,
            'property' => 'id',
            'empty_value' => 'Select a contact',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => ContactQuery::create(),
            'constraints' => new NotBlank(),
            'choices' => 'contact_search_by_name',
            'init_choices' => 'contact_search_by_name_init',
            'class' => Contact::class,
            'custom_ajax_json' => "
            ajax: {
                url: '/index.php/contact/search-by-name',
                datatype: 'jsonp',
                quietMillis: 100,
                data: function(term, page) {
                    return {
                        filters: {'AccountId': $('#etude_account').val() },
                        term: term,
                        page: page,
                        max_per_page: 10
                    };
                },
                results: function(data, page) {
                    var more = false;
                    if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                        more = (page * data.maxPerPage) < data.total;
                    }
                    return {
                        results: data.results,
                        more: more
                    };
                }
            }",
        ]);

        $this->optionsEndClientContact = [
            'label' => 'End Client Contact',
            'multiple' => false,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select a contact',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => ContactQuery::create(),
            'choices' => 'contact_search_by_name',
            'init_choices' => 'contact_search_by_name_init',
            'class' => Contact::class,
            'custom_ajax_json' => "
            ajax: {
                url: '/index.php/contact/search-by-name',
                datatype: 'jsonp',
                quietMillis: 100,
                data: function(term, page) {
                    return {
                        filters: {'AccountId': $('#etude_end_client').val() },
                        term: term,
                        page: page,
                        max_per_page: 10
                    };
                },
                results: function(data, page) {
                    var more = false;
                    if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                        more = (page * data.maxPerPage) < data.total;
                    }
                    return {
                        results: data.results,
                        more: more
                    };
                }
            }",
        ];

        $builder->add('end_client_contact', Select2HiddenPropelType::class, $this->optionsEndClientContact);

        $this->optionsIntermediateClientContact = [
            'label' => 'Intermediate Client Contact',
            'multiple' => false,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select an intermediate contact',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => ContactQuery::create(),
            'choices' => 'contact_search_by_name',
            'init_choices' => 'contact_search_by_name_init',
            'class' => Contact::class,
            'custom_ajax_json' => "
            ajax: {
                url: '/index.php/contact/search-by-name',
                datatype: 'jsonp',
                quietMillis: 100,
                data: function(term, page) {
                    return {
                        filters: {'AccountId': $('#etude_intermediate_client').val() },
                        term: term,
                        page: page,
                        max_per_page: 10
                    };
                },
                results: function(data, page) {
                    var more = false;
                    if (typeof(data.maxPerPage) != 'undefined' && typeof(data.total) != 'undefined') {
                        more = (page * data.maxPerPage) < data.total;
                    }
                    return {
                        results: data.results,
                        more: more
                    };
                }
            }",
        ];
        $builder->add('intermediate_client_contact', Select2HiddenPropelType::class, $this->optionsIntermediateClientContact);

        $builder->add('theme', TextType::class, [
            'label' => 'Client Subject',
            'required' => true,
            'constraints' => [
                new NotBlank(),
            ],
        ]);

        $builder->add('theme_br', TextType::class, [
            'label' => 'Help Search Subject',
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('currencies', HiddenType::class, [
            'label' => 'Currencies',
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('multi_phase', CheckboxType::class, [
            'label' => 'Multi Phase In Progress',
            'required' => false,
        ]);

        $builder->add('date_debut', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Project Start Date',
            'format' => 'dd/MM/yyyy',
            'html5' => false,
            'required' => false,
        ]);

        $builder->add('date_fin', DateType::class, [
            'widget' => 'single_text',
            'label' => 'Project End Date',
            'format' => 'dd/MM/yyyy',
            'html5' => false,
            'required' => false,
        ]);

        $builder->add('sectors', ModelType::class, [
            'label' => 'Respondent type category',
            'query' => RefSalesForceQuery::create()->filterByOpportunityField('sectors'),
            'required' => true,
            'multiple' => true,
            'expanded' => false,
            'constraints' => [
                new Count(['min' => 1]),
            ],
            'class' => RefSalesForce::class,
            'property_path' => 'RefSalesForceEtudeRefSectors',
        ]);

        $builder->add('sample_plan', TextareaType::class, [
            'label' => 'Sample Plan (internal)',
            'required' => false,
        ]);

        $builder->add('etude_location', ModelType::class, [
            'query' => LocationQuery::create()->filterByActive(true)->_or()->filterByGqsAvailable(true)->orderByLibelle(),
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a location',
            'label' => 'Managing location',
            'constraints' => [
                new NotBlank(),
            ],
            'class' => Location::class,
            'choice_attr' => function (Location $location) {
                return [
                    'data-project-location-prefix' => $location->getProjectLocationPrefixId(),
                    'data-active' => $location->getActive() ? 'Y' : 'N',
                    'data-gqs-available' => $location->getGqsAvailable() ? 'Y' : 'N',
                ];
            },
        ]);
        $builder->add('facilty_note', TextareaType::class, [
        'label' => 'Facility Note',
        'required' => false,
    ]);
        if ($builder->getData()->getId()) {
            $builder->add('project_location_prefix', ModelType::class, [
                'query' => ProjectLocationPrefixQuery::create(),
                'required' => false,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select a prefix',
                'label' => 'Master location prefix',
                'class' => ProjectLocationPrefix::class,
                'choice_label' => 'prefix',
            ]);
        }

        $builder->add('bm', ModelType::class, [
            'query' => UserQuery::create()
                ->filterById($builder->getData()->getIdBm())
                ->_or()
                ->filterByisSeller(true)
                ->filterByStatut('A')
                ->orderByPrenom()
                ->orderByNom(),
            'label' => 'Project Setup Owner',
            'placeholder' => 'Select a Project Setup',
            'required' => true,
            'multiple' => false,
            'expanded' => false,
            'constraints' => new NotBlank(),
            'class' => User::class,
        ]);

        $builder->add('sample_sources', ModelType::class, [
            'query' => SampleSourceQuery::create()->filterAndOrderForChoice(),
            'required' => true,
            'multiple' => true,
            'expanded' => false,
            'label' => 'Sample Sources',
            'constraints' => [
                new Count(['min' => 1]),
            ],
            'class' => SampleSource::class,
        ]);
        $builder->add('po_number', TextType::class, [
            'required' => false,
            'label' => 'PO Number',
        ]);
        $builder->add('best_effort', CheckboxType::class, [
            'label' => 'Best effort',
            'required' => false,
        ]);

        $builder->add('room_rental', CheckboxType::class, [
            'label' => 'Room rental',
            'required' => false,
        ]);

        $builder->add('sms_relance', CheckboxType::class, [
            'label' => 'SMS',
            'required' => false,
        ]);

        $builder->add('recruits_offsite', CheckboxType::class, [
            'label' => 'Recruits offsite',
            'required' => false,
        ]);

        $builder->add('focus_vision', CheckboxType::class, [
            'label' => 'Focus vision',
            'required' => false,
        ]);

        $builder->add('si_job_type', ModelType::class, [
            'label' => 'Si Job Type',
            'query' => SiJobTypeQuery::create()->filterAndOrderForChoice(),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'class' => SiJobType::class,
        ]);

        $builder->add('si_eu_job_type', ChoiceType::class, [
            'label' => 'SI EU Job Type',
            'multiple' => false,
            'expanded' => false,
            'choices' => Etude::getSiEuJobTypTypes(),
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('proposed_loi', IntegerType::class, [
            'label' => 'Proposed loi',
            'required' => false,
            'empty_data' => '',
        ]);

        $builder->add('client_discount_percentage', NumberType::class, [
            'label' => 'Client Qual discount percentage',
            'required' => false,
        ]);

        $builder->add('end_client_discount_percentage', NumberType::class, [
            'label' => 'End Client Qual discount percentage',
            'required' => false,
        ]);

        $builder->add('client_quant_discount_percentage', NumberType::class, [
            'label' => 'Client Quant discount percentage',
            'required' => false,
        ])->add('end_client_quant_discount_percentage', NumberType::class, [
            'label' => 'End client Quant discount percentage',
            'required' => false,
        ]);

        $builder->add('job_etudes', CollectionType::class, [
            'label' => false,
            'entry_type' => JobType::class,
            'allow_add' => true,
            'allow_delete' => false,
            'delete_empty' => true,
            'by_reference' => false,
            'entry_options' => [
                'label' => false,
                'parent_data' => $builder->getData(),
                'event_dispatcher' => $builder->getEventDispatcher(),
                'user' => $options['user'],
            ],
        ]);

        $builder->add('intermediate_client', Select2HiddenPropelType::class, [
            'label' => 'Intermediate Client',
            'multiple' => false,
            'required' => false,
            'property' => 'id',
            'empty_value' => 'Select a client',
            'formatSelection' => 'formatSelectedPerson',
            'formatResult' => 'formatResultPerson',
            'query' => AccountQuery::create(),
            'choices' => 'account_search_by_name',
            'init_choices' => 'account_search_by_name_init',
            'class' => Account::class,
        ]);

        $builder->add('us_global_qual_gms', ModelType::class, [
            'label' => 'GQS',
            'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('us_global_qual_gms_id')->filterByTable('opportunity'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select a GQS',
            'class' => RefSalesForce::class,
       ]);

        $builder->add('client_list_deletion', ModelType::class, [
            'label' => 'Client List Deletion',
            'query' => RefSalesForceQuery::create()->filterByActif(true)->filterByField('client_list_deletion')->filterByTable('etude'),
            'required' => false,
            'multiple' => false,
            'expanded' => false,
            'placeholder' => 'Select Client List Deletion',
            'class' => RefSalesForce::class,
        ]);

        $builder->add('rst', CheckboxType::class, [
            'label' => 'RST',
            'required' => false,
        ]);
        $builder->add('cli', CheckboxType::class, [
            'label' => 'CLI',
            'required' => false,
        ]);
        $builder->add('gqs', CheckboxType::class, [
            'label' => 'GQS',
            'required' => false,
        ]);
        $builder->add('ins', CheckboxType::class, [
            'label' => 'INS',
            'required' => false,
        ]);
        $builder->add('hut', CheckboxType::class, [
            'label' => 'HUT',
            'required' => false,
        ]);

        $builder->add('display_total_only', CheckboxType::class, [
            'label' => 'Display Total Only',
            'required' => false,
        ]);

        $builder->add('jobs_fd_checked_by_system', HiddenType::class, [
            'required' => false,
            'mapped' => false,
        ])->add('jobs_pm_checked_by_system', HiddenType::class, [
            'required' => false,
            'mapped' => false,
        ])->add('jobs_acct_checked_by_system', HiddenType::class, [
            'required' => false,
            'mapped' => false,
        ])->add('jobs_am_checked_by_system', HiddenType::class, [
            'required' => false,
            'mapped' => false,
        ]);

        $builder->addEventListener(FormEvents::PRE_SET_DATA, function (FormEvent $event) use ($options) {
            $form = $event->getForm();
            $data = $event->getData();
            $actualUser = $options['user'];
            if ($data) {
                $form->add('send_csat_quest', CheckboxType::class, [
                    'label' => 'Send CSat Quest',
                    'required' => false,
                ]);
            }

            if ($data && $endClient = $data->getEndClient()) {
                $endClientAndEndClientParent = $endClient->getIdAndParentIdsAndChildrenIds();
                $this->optionsEndClientContact['query'] = ContactQuery::create()->filterByAccountId($endClientAndEndClientParent, Criteria::IN);
                $form->add('end_client_contact', Select2HiddenPropelType::class, $this->optionsEndClientContact);
                $form->add('end_client', Select2HiddenPropelType::class, [
                    'label' => 'End Client',
                    'multiple' => false,
                    'required' => true,
                    'property' => 'getNameforPicklist',
                    'empty_value' => 'Select a client',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => AccountQuery::create(),
                    'constraints' => new NotBlank(),
                    'choices' => 'account_search_by_name',
                    'init_choices' => 'account_search_by_name_init',
                    'class' => Account::class,
                ]);
            } else {
                // see ticket #20578
                $endClient = AccountQuery::create()->filterByActiveStatusId()->findOneByName('Not Applicable');
                $data->setEndClient($endClient);
                $form->add('end_client', Select2HiddenPropelType::class, [
                    'label' => 'End Client',
                    'multiple' => false,
                    'required' => true,
                    'property' => 'getNameforPicklist',
                    'empty_value' => 'Select a client',
                    'formatSelection' => 'formatSelectedPerson',
                    'formatResult' => 'formatResultPerson',
                    'query' => AccountQuery::create(),
                    'constraints' => new NotBlank(),
                    'choices' => 'account_search_by_name',
                    'init_choices' => $endClient ? [$endClient->getId() => $endClient] : [],
                    'class' => Account::class,
                ]);
                if ($data && $intermediateClient = $data->getIntermediateClient()) {
                    $this->optionsIntermediateClientContact['query'] = ContactQuery::create()->filterByAccount($intermediateClient);
                    $form->add('intermediate_client_contact', Select2HiddenPropelType::class, $this->optionsIntermediateClientContact);
                    $form->add('intermediate_client', Select2HiddenPropelType::class, [
                        'label' => 'Intermediate Client',
                        'multiple' => false,
                        'required' => false,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select an intermediate client',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'constraints' => new NotBlank(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => 'account_search_by_name_init',
                        'class' => Account::class,
                    ]);
                } else {
                    $data->setIntermediateClient($endClient);
                    $form->add('intermediate_client', Select2HiddenPropelType::class, [
                        'label' => 'Intermediate Client',
                        'multiple' => false,
                        'required' => false,
                        'property' => 'getNameforPicklist',
                        'empty_value' => 'Select a client',
                        'formatSelection' => 'formatSelectedPerson',
                        'formatResult' => 'formatResultPerson',
                        'query' => AccountQuery::create(),
                        'choices' => 'account_search_by_name',
                        'init_choices' => $endClient ? [$endClient->getId() => $endClient] : [],
                        'class' => Account::class,
                    ]);
                }
            }

            if ($actualUser && $data && !$data->getBm()) {
                $data->setBm($actualUser);
                $form->add('bm', ModelType::class, [
                    'query' => UserQuery::create()
                        ->filterById($actualUser->getId())
                        ->_or()
                        ->filterByisSeller(true)
                        ->filterByStatut('A'),
                    'label' => 'Project Setup Owner',
                    'placeholder' => 'Select a Project Setup ',
                    'required' => true,
                    'multiple' => false,
                    'expanded' => false,
                    'constraints' => new NotBlank(),
                    'class' => User::class,
                ]);
            }

            if ($data && !$data->getJobQualificationId()) {
                $jobQualificationQual = RefSalesForceQuery::create()
                    ->filterByActiveOpportunityField('job_qualification_id')
                    ->useMethodologyQuery()
                        ->filterById(null, Criteria::ISNOTNULL)
                    ->endUse()
                    ->filterByValue('Qual')
                    ->findOne();

                $data->setJobQualification($jobQualificationQual);
            }

            $form->add('job_qualification', ModelType::class, [
                'label' => 'Job Qualification',
                'placeholder' => 'Select a job qualification',
                'query' => RefSalesForceQuery::create()
                    ->filterByActiveOpportunityField('job_qualification_id')
                    ->useMethodologyQuery()
                        ->filterById(null, Criteria::ISNOTNULL)
                    ->endUse(),
                'required' => true,
                'constraints' => new NotBlank(),
                'multiple' => false,
                'expanded' => false,
                'class' => RefSalesForce::class,
            ]);

            $sectorIds = $data && count($data->getRefSalesForceEtudeRefSectors()) > 0 ? $data->getRefSalesForceEtudeRefSectors()->toKeyValue('Id', 'Id') : null;
            $form->add('etude_area', ModelType::class, [
                'query' => AreaQuery::create()->filterBySectorOrNull($sectorIds)->filterAndOrderForChoice(),
                'label' => 'Area',
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'placeholder' => 'Select an area',
                'constraints' => [
                    new NotBlank(),
                ],
                'class' => Area::class,
            ]);

            $methodologies = MethodologyQuery::create()->filterById(null)->filterAndOrderForChoice();
            if ($data && $qualificationId = $data->getJobQualificationId()) {
                $methodologyQuery = MethodologyQuery::create()
                    ->_if($qualificationId)
                         ->filterByMethodologyJobQualificationId($qualificationId)
                    ->_endif()
                    ->filterAndOrderForChoice();

                $methodologies = $methodologyQuery;
            }

            $form->add('methodologies', ModelType::class, [
                'query' => $methodologies,
                'required' => true,
                'multiple' => true,
                'expanded' => false,
                'constraints' => [
                    new Count(['min' => 1]),
                ],
                'label' => 'Methodologies',
                'class' => Methodology::class,
            ]);

            if (!$data->getCurrencyIsoCode()) {
                $data->setCurrencyIsoCode(RefSalesForce::getCurrency($this->instance));
            }
        });

        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) use ($builder) {
            $form = $event->getForm();
            $data = $event->getData();
            $sectorIds = isset($data['sectors']) && $data['sectors'] ? $data['sectors'] : null;
            $form->add('etude_area', ModelType::class, [
                'query' => AreaQuery::create()->filterBySectorOrNull($sectorIds)->filterAndOrderForChoice(),
                'label' => 'Area',
                'required' => true,
                'multiple' => false,
                'expanded' => false,
                'constraints' => [
                    new NotBlank(),
                ],
                'class' => Area::class,
            ]);

            if ($endClientId = $data['end_client'] ?? null) {
                $endClient = null !== $endClientId ? AccountQuery::create()->filterById($endClientId)->findOne() : null;
                $endClientAndEndClientParentIds = null !== $endClient ? $endClient->getIdAndParentIdsAndChildrenIds() : [];

                $this->optionsEndClientContact['query'] = ContactQuery::create()->filterByAccountId($endClientAndEndClientParentIds, Criteria::IN);
                $form->add('end_client_contact', Select2HiddenPropelType::class, $this->optionsEndClientContact);
            }

            $methodologies = MethodologyQuery::create()->filterById(null)->filterAndOrderForChoice();
            if (isset($data['job_qualification']) && $data['job_qualification']) {
                $methodologies = MethodologyQuery::create()
                    ->_if($data['job_qualification'])
                         ->filterByMethodologyJobQualificationId($data['job_qualification'])
                    ->_endif()
                    ->filterAndOrderForChoice();
            }
            $form->add('methodologies', ModelType::class, [
                'query' => $methodologies,
                'required' => true,
                'multiple' => true,
                'expanded' => false,
                'constraints' => [
                    new Count(['min' => 1]),
                ],
                'label' => 'Methodologies',
                'class' => Methodology::class,
            ]);

            $this->optionsJobMethodologies = [
                'query' => MethodologyQuery::create()->filterById(null)->filterAndOrderForChoice(),
                'required' => true,
                'constraints' => [
                    new Count(['min' => 1]),
                ],
                'multiple' => true,
                'expanded' => false,
                'label' => 'Methodologies',
                'class' => Methodology::class,
            ];

            // why is this in a callback?
            $builder->get('job_etudes')->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) use ($data) {
                $etudeData = $data;
                $form = $event->getForm();
                foreach ($form->all() as $formChild) {
                    //Model Job
                    $this->optionsJobMethodologies['query'] = MethodologyQuery::create()->filterAndOrderForChoice();
                    if ($jobQualificationId = $etudeData['job_qualification']) {
                        $methodologyQuery = MethodologyQuery::create()
                            ->_if($jobQualificationId)
                                ->filterByMethodologyJobQualificationId($jobQualificationId)
                            ->_endif()
                            ->filterAndOrderForChoice();
                        $this->optionsJobMethodologies['query'] = $methodologyQuery;
                        if (in_array($jobQualificationId, Etude::getQualificationQuantType())) {
                            $this->optionsJobOnSiteRecruits['required'] = false;
                            $this->optionsJobOnSiteRecruits['constraints'] = [];
                            $this->optionsJobOffSiteRecruits['required'] = false;
                            $this->optionsJobOffSiteRecruits['constraints'] = [];
                            $this->optionsJobSampleSize['required'] = true;
                            $this->optionsJobSampleSize['constraints'] = [new NotBlank()];
                        } else {
                            $this->optionsJobOnSiteRecruits['required'] = true;
                            $this->optionsJobOnSiteRecruits['constraints'] = [new NotBlank()];
                            $this->optionsJobOffSiteRecruits['required'] = true;
                            $this->optionsJobOffSiteRecruits['constraints'] = [new NotBlank()];
                            $this->optionsJobSampleSize['required'] = false;
                            $this->optionsJobSampleSize['constraints'] = [];
                        }

                        $this->optionsJobOnSiteRecruits['disabled'] = $formChild->getData() && $formChild->getData()->isOnSite() && $formChild->getData()->getOffSiteRecruits() && !$formChild->getData()->getOnSiteRecruits() ? true : false;
                        $this->optionsJobOffSiteRecruits['disabled'] = $formChild->getData() && $formChild->getData()->isOnSite() && $formChild->getData()->getOnSiteRecruits() && !$formChild->getData()->getOffSiteRecruits() ? true : false;

                        if ($formChild->getData() && $formChild->getData()->isOnSite()) {
                            $formChild->add('on_site_recruits', NumberType::class, $this->optionsJobOnSiteRecruits);
                        }

                        $formChild->add('off_site_recruits', NumberType::class, $this->optionsJobOffSiteRecruits);
                        $formChild->add('sample_size', TextType::class, $this->optionsJobSampleSize);
                    }
                    $formChild->add('methodologies', ModelType::class, $this->optionsJobMethodologies);
                }
            });
        });

        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) use ($opportunity) {
            $form = $event->getForm();
            $beginDate = $form->get('date_debut')->getData();
            $endDate = $form->get('date_fin')->getData();
            $location = $form->get('etude_location')->getData();
            $gqs = $form->get('us_global_qual_gms')->getData();
            if ($gqs && 'Y' === $gqs->getValue() && $location && !$location->isGqsAvailable()) {
                $form->addError(new FormError('Location is not GQS available'));
            }
            if ($beginDate > $endDate) {
                $form->addError(new FormError('End date must be after begin date!'));
            }
            $client = $form->get('account')->getData();
            $endClient = $form->has('end_client') ? $form->get('end_client')->getData() : null;
            if ($client == $endClient) {
                $form->addError(new FormError('The Account can´t match the End Client. If the Account is an End Client enter "Not Applicable" under End Client.'));
            }

            if ($opportunity && $beginDate && $endDate) {
                $areEventsDatesBetweenEtudeDates = true;
                foreach ($opportunity->getEventsNotDeleted() as $event) {
                    if (!in_array($event->getRefEventStatus(), [RefEventStatus::RELEASED, RefEventStatus::CANCELLED_NON_BILLED]) && (
                        !($event->getStartDateTime('Y-m-d') >= $beginDate->format('Y-m-d') && $event->getStartDateTime('Y-m-d') <= $endDate->format('Y-m-d')) ||
                        !($event->getEndDateTime('Y-m-d') >= $beginDate->format('Y-m-d') && $event->getEndDateTime('Y-m-d') <= $endDate->format('Y-m-d')))) {
                        $areEventsDatesBetweenEtudeDates = false;
                        break;
                    }
                }
                if (!$areEventsDatesBetweenEtudeDates) {
                    $form->get('date_debut')->addError(new FormError('Events start and end dates must be between Project dates.'));
                }
            }

            $setAmReasonType = $form->get('set_am_reason_type')->getData();
            $dontSetAmAuto = $form->has('dont_set_am_auto') ? $form->get('dont_set_am_auto')->getData() : null;
            $setAmReason = $form->get('set_am_reason')->getData();
            if ($dontSetAmAuto && null === $setAmReasonType) {
                $form->get('set_am_reason_type')->addError(new FormError('A reason type is mandatory if you want to stop AM auto'));
            }
            if ($dontSetAmAuto && AmReasonType::OTHERS == $setAmReasonType && (null === $setAmReason || '' === $setAmReason)) {
                $form->get('set_am_reason')->addError(new FormError('An explanation is mandatory if you want to stop AM auto for "Others reason type"'));
            }
        });

        $builder->get('job_etudes')->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) {
            $form = $event->getForm();
            if (count($form->all()) < 1) {
                $form->addError(new FormError('A minimum of 1 job is required !'));
            }
        });
    }
}
