<?php

namespace Form\Type;

use Model\EventMethodology;
use Model\EventMethodologyQuery;
use Model\RefEventStatus;
use Model\RefEventStatusQuery;
use Model\RefRoom;
use Propel\Bundle\PropelBundle\Form\Type\ModelType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class MultipleEventsType extends AbstractType
{
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'csrf_protection' => false,
            'allow_extra_fields' => true,
            'job' => null,
        ]);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $locationIds = $options['job'] ? [$options['job']->getLocationId()] : [];

        $choicesSelection = RefRoom::getRoomsNamesAndLocationsForChoiceSelection($locationIds);

        $builder->add('status', ModelType::class, [
            'label' => 'Event status',
            'placeholder' => 'Select a status',
            'query' => RefEventStatusQuery::create(),
            'multiple' => false,
            'expanded' => false,
            'required' => true,
            'attr' => [
                'placeholder' => 'status',
            ],
            'class' => RefEventStatus::class,
        ])
            ->add('ref_room_ids', ChoiceType::class, [
                'choices' => $choicesSelection,
                'placeholder' => 'Select a Room',
                'attr' => ['placeholder' => 'Select a Room'],
                'label' => 'Room',
                'required' => true,
                'multiple' => true,
                'expanded' => false,
            ])
            ->add('event_methodology', ModelType::class, [
                'query' => EventMethodologyQuery::create()->filterAndOrderForChoice(),
                'required' => true,
                'constraints' => [
                    new NotBlank(),
                ],
                'multiple' => false,
                'expanded' => false,
                'label' => 'Event methodology',
                'placeholder' => 'Select a methodology',
                'class' => EventMethodology::class,
            ])
            ->add('start_date', DateTimeType::class, [
                'widget' => 'single_text',
                'label' => 'Start Date',
                'format' => 'dd/MM/yyyy',
                'required' => true,
                'attr' => [
                    'placeholder' => 'Start Date',
                ],
            ])
            ->add('end_date', DateTimeType::class, [
                'widget' => 'single_text',
                'label' => 'End Date',
                'format' => 'dd/MM/yyyy',
                'required' => true,
                'attr' => [
                    'placeholder' => 'End Date',
                ],
            ])
           ->add('start_time', TimeType::class, [
                'input' => 'datetime',
                'widget' => 'choice',
            ])
            ->add('end_time', TimeType::class, [
                'input' => 'datetime',
                'widget' => 'choice',
            ])
            ->add('save', SubmitType::class, [
                'label' => 'Save',
                'attr' => ['class' => 'btn-success'],
            ]);
        $builder->addEventListener(FormEvents::SUBMIT, function (FormEvent $event) use ($options) {
            $form = $event->getForm();
            $data = $event->getData();

            if ($data['start_date']->format('Y-m-d') < date('Y-m-d')) {
                $form->get('start_date')->addError(new FormError('Start date must be greater than todays date.'));
            }
            if ($data['start_date'] > $data['end_date']) {
                $form->get('start_date')->addError(new FormError('Start date must be less than end date.'));
            }
            if ($data['start_time'] > $data['end_time']) {
                $form->get('start_time')->addError(new FormError('Start time must be less than end time.'));
            }
            if ($options['job']) {
                if ($options['job']->getStartDate() > $data['start_date'] || $options['job']->getEndDate() < $data['end_date']) {
                    $form->get('start_date')->addError(new FormError('Start date and end date must be between job dates.'));
                }
            }
        });
    }
}
